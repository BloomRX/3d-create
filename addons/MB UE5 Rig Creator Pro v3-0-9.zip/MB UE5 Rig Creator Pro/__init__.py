# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Magic Bone UE5 Rig Creator Pro",
    "author" : "MagicBoneTools",
    "description" : "Magic Bone UE5 Rig Creator Pro",
    "blender" : (4, 0, 0),
    "version" : (3, 0, 9),
    "location" : "View3D",
    "warning" : "",
    "category" : "Generic"
}


import bpy
from bpy.props import FloatProperty
 
#########
from . CreateRig import CreatRig_OT_my_op

 




from . ShoulderFix import Getue_Shoulderfix
from . GetAnimInRigCrea import getanim_rig_in
from . ApplyScalear import autoscale_OT_op
from . ApplyScalear import autoscaleroot_OT_op


 

from . helperT import helper_OT_op


from . FixHeadRot import fixhedrot_roto_in






#########




from . MagicBoneTop_Panel import MyProperties

from . MagicBoneTop_Panel import MBPanel
from . MagicBoneTop_Panel import rig_creation_op

from . MagicBoneTop_Panel import Scale_Cat_p
from . MagicBoneTop_Panel import Bone_Cat_b4
from . MagicBoneTop_Panel import Bone_Cat_b5


from . MagicBoneTop_Panel import Bone_Cat_b1
from . MagicBoneTop_Panel import Bone_Cat_b2
from . MagicBoneTop_Panel import Bone_Cat_b3
from . MagicBoneTop_Panel import Bone_Cat_b6




from . MagicBoneTop_Panel import Right_HandFingers_Fingers
from . MagicBoneTop_Panel import Left_HandFingers_Fingers
from . MagicBoneTop_Panel import MB_Panel_PoseEditor
 
 
from . MagicBoneTop_Panel import Button_footfixpm
from . MagicBoneTop_Panel import Button_fixfootroto



from . MagicBoneTop_Panel import MB_Panel_direc

 



from . MagicBoneTop_Panel import Button_MakeDEF_Bones
from . MagicBoneTop_Panel import SetTargetName_OT_my_op
from . MagicBoneTop_Panel import SetSourceName_OT_my_op

from . MagicBoneTop_Panel import Button_SetScalerf
from . MagicBoneTop_Panel import Button_Checkbones

from . MagicBoneTop_Panel import Save_OT_my_op
from . MagicBoneTop_Panel import Load_OT_my_op

from . MagicBoneTop_Panel import ExportSomeData

from . MagicBoneTop_Panel import menu_func_export

from . MagicBoneTop_Panel import clr_map_an

from . MagicBoneTop_Panel import arma_items

from . MagicBoneTop_Panel import arma_upd

from . MagicBoneTop_Panel import bone_items

 
from . MagicBoneTop_Panel import Button_footuezz
from . MagicBoneTop_Panel import rig_fy_rigfy
from . MagicBoneTop_Panel import root_SP_main_panel
from . MagicBoneTop_Panel import bone_liss_my_op
from . MagicBoneTop_Panel import rigs_liss_my_op

from . MagicBoneTop_Panel import scaandloco_save_op
from . MagicBoneTop_Panel import scaandloco_apply_op

from . MagicBoneTop_Panel import rig_adjusspine_op
from . MagicBoneTop_Panel import rig_adjustment_op

from . MagicBoneTop_Panel import adjustment_save_op

from . MagicBoneTop_Panel import adjustment_apply_op

from . MagicBoneTop_Panel import fbatch_aexport_op



from . helperT import apply_scaleonly_op
from . helperT import removeac_OT_op







from . MBRigfy import MB_OT_Op







from . MBRigfy import Unlink_Anim_an
from . MBRigfy import link_Anim_an
from . MBRigfy import move_tolayer_an

from . MBRigfy import show_tolayer_an
from . MBRigfy import hide_tolayer_an



from . fingersnewup import fingersnew_OT_op
from . fingersnewup import fingersdirec_OT_op

from . fingersnewup import indexDir_op
from . fingersnewup import middleDir_op

from . fingersnewup import ringDir_op

from . fingersnewup import pinkyDir_op

from . fingersnewup import hand_op

from . rootmake import rootmak_op

 
from . MagicBoneTop_Panel import MB_Panel_Posemake

from . MagicBoneTop_Panel import MB_Panel_applycur

from . MagicBoneTop_Panel import MBPanel_fbatch

from . MagicBoneTop_Panel import MB_About_Posemake

# from . MagicBoneTop_Panel import rigfy_Panel_a







from . MagicBoneTop_Panel import finger_save_op
from . MagicBoneTop_Panel import finger_apply_op

from . MagicBoneTop_Panel import fix_twist_op
from . MagicBoneTop_Panel import fix_twistback_op


 
 
from . naming import namingfix_op
from . naming import namingfixnoid_op
from . naming import setnameue_op



from . handfingerfix import lefthand_new_op
from . handfingerfix import rigthand_new_op

from . handfingerfix import lefthand_rot_op
from . handfingerfix import rigthand_rot_op
from . spinnew import spine_newss_op
from . spinnew import spine_rotoo_op




from . handfingerfix import showaxx_op

from . selectdele import deletttmup_op



#######################################################
from . namingbonebutt import Button_SetBoneName01
from . namingbonebutt import Button_SetBoneName02
from . namingbonebutt import Button_SetBoneName03
from . namingbonebutt import Button_SetBoneName04
from . namingbonebutt import Button_SetBoneName05
from . namingbonebutt import Button_SetBoneName06butt
from . namingbonebutt import Button_SetBoneName07
from . namingbonebutt import Button_SetBoneName08butt
from . namingbonebutt import Button_SetBoneName09
from . namingbonebutt import Button_SetBoneName010
from . namingbonebutt import Button_SetBoneName011
from . namingbonebutt import Button_SetBoneName012
from . namingbonebutt import Button_SetBoneName013
from . namingbonebutt import Button_SetBoneName014
from . namingbonebutt import Button_SetBoneName015
from . namingbonebutt import Button_SetBoneName016
from . namingbonebutt import Button_SetBoneName017
from . namingbonebutt import Button_SetBoneName018
from . namingbonebutt import Button_SetBoneName019
from . namingbonebutt import Button_SetBoneName020
from . namingbonebutt import Button_SetBoneName021
from . namingbonebutt import Button_SetBoneName022
from . namingbonebutt import Button_SetBoneName023
from . namingbonebutt import Button_SetBoneName024
from . namingbonebutt import Button_SetBoneName025
from . namingbonebutt import Button_SetBoneName026
from . namingbonebutt import Button_SetBoneName027
from . namingbonebutt import Button_SetBoneName028
from . namingbonebutt import Button_SetBoneName029
from . namingbonebutt import Button_SetBoneName030
from . namingbonebutt import Button_SetBoneName031
from . namingbonebutt import Button_SetBoneName032
from . namingbonebutt import Button_SetBoneName033
from . namingbonebutt import Button_SetBoneName034
from . namingbonebutt import Button_SetBoneName035
from . namingbonebutt import Button_SetBoneName036
from . namingbonebutt import Button_SetBoneName037
from . namingbonebutt import Button_SetBoneName038
from . namingbonebutt import Button_SetBoneName039
from . namingbonebutt import Button_SetBoneName040
from . namingbonebutt import Button_SetBoneName041
from . namingbonebutt import Button_SetBoneName042
from . namingbonebutt import Button_SetBoneName043
from . namingbonebutt import Button_SetBoneName044
from . namingbonebutt import Button_SetBoneName045
from . namingbonebutt import Button_SetBoneName046
from . namingbonebutt import Button_SetBoneName047
from . namingbonebutt import Button_SetBoneName048
from . namingbonebutt import Button_SetBoneName049
from . namingbonebutt import Button_SetBoneName050
from . namingbonebutt import Button_SetBoneName051
from . namingbonebutt import Button_SetBoneName052
from . namingbonebutt import Button_SetBoneName053
from . namingbonebutt import Button_SetBoneName054
from . namingbonebutt import Button_SetBoneName055
from . namingbonebutt import Button_SetBoneName056
from . namingbonebutt import Button_SetBoneName057
from . namingbonebutt import Button_SetBoneName058
from . namingbonebutt import Button_SetBoneName059
from . namingbonebutt import Button_SetBoneName060
from . namingbonebutt import Button_SetBoneName061
from . namingbonebutt import Button_SetBoneName062
from . namingbonebutt import Button_SetBoneName063
from . namingbonebutt import Button_SetBoneName064
from . namingbonebutt import Button_SetBoneName065
from . namingbonebutt import Button_SetBoneName066
from . namingbonebutt import Button_SetBoneName067
from . namingbonebutt import Button_SetBoneName068
from . namingbonebutt import Button_SetBoneName069
from . namingbonebutt import Button_SetBoneName070
from . namingbonebutt import Button_SetBoneName071


from . namingbonebutt import Button_SetBoneName072
from . namingbonebutt import Button_SetBoneName073
from . namingbonebutt import Button_SetBoneName074
from . namingbonebutt import Button_SetBoneName075
from . namingbonebutt import Button_SetBoneName076
from . namingbonebutt import Button_SetBoneName077
from . namingbonebutt import Button_SetBoneName078
from . namingbonebutt import Button_SetBoneName079





from . Centermake import center_OT_op
from . MBRigfy import mbmute_co_Op
from . MBRigfy import mbunmute_co_Op

from . uevspicur import spine_curuev_op


from . dazApplyL import daz_OT_op
from . dazApplyL import fixloc_OT_op

from . AutoScalenew import Auto_SetScalerf
from . AutoScalenew import Offist_SetScalerf

from . PoseUE import posemake_op
from . PoseUE import animpose_only_op
from . GetAnimInWPose import getanimwpose_rig_in

from . PoseUE import expoer_fbx_op

 


  
def register():

    bpy.types.WindowManager.progress = FloatProperty(default=0.0, min=0.0, max=1.0)
    

    bpy.types.Scene.armature_object = bpy.props.PointerProperty(type=bpy.types.Object)

    bpy.types.Scene.armature_blenrig = bpy.props.PointerProperty(type=bpy.types.Object)
    
    bpy.utils.register_class(MBPanel)

    bpy.utils.register_class(rig_creation_op)

    
    bpy.utils.register_class(autoscaleroot_OT_op)

    bpy.utils.register_class(helper_OT_op)

    bpy.utils.register_class(fixhedrot_roto_in)

    bpy.utils.register_class(bone_liss_my_op)

    bpy.utils.register_class(rigs_liss_my_op)

    bpy.utils.register_class(link_Anim_an)

    bpy.utils.register_class(fingersnew_OT_op)
    bpy.utils.register_class(fingersdirec_OT_op)

    

    

    
 
    
    bpy.utils.register_class(MyProperties)
    bpy.utils.register_class(Save_OT_my_op)
    bpy.utils.register_class(Load_OT_my_op)
    bpy.types.Scene.my_tool = bpy.props.PointerProperty(type= MyProperties) 
    bpy.utils.register_class(ExportSomeData)
    bpy.types.TOPBAR_MT_file_export.append(menu_func_export)

    bpy.types.Scene.my_path = bpy.props.StringProperty(name="File", subtype='FILE_PATH')
    
    bpy.types.Scene.my_filepath = bpy.props.StringProperty(subtype='FILE_PATH')
    

     
    bpy.utils.register_class(clr_map_an)

    bpy.utils.register_class(Scale_Cat_p)

    bpy.utils.register_class(root_SP_main_panel)
    
    
    
    bpy.utils.register_class(Button_SetScalerf)

    bpy.utils.register_class(getanim_rig_in)

    bpy.utils.register_class(autoscale_OT_op)
    
    

     


    #//////////////////////////////////////////category

    bpy.utils.register_class(Bone_Cat_b4)
    bpy.utils.register_class(Bone_Cat_b5)
 



    
    
    bpy.utils.register_class(Bone_Cat_b2)
    bpy.utils.register_class(Bone_Cat_b3)
    bpy.utils.register_class(Bone_Cat_b6)
    
    bpy.utils.register_class(Left_HandFingers_Fingers)
    bpy.utils.register_class(Right_HandFingers_Fingers)
 

    
    
    
    bpy.utils.register_class(CreatRig_OT_my_op)
    
    bpy.utils.register_class(Button_MakeDEF_Bones)
    
    bpy.utils.register_class(MB_Panel_PoseEditor)
    
 
    
    bpy.utils.register_class(Button_footfixpm)
    bpy.utils.register_class(Button_fixfootroto)
 
    




    

    
    #new
    bpy.utils.register_class(SetTargetName_OT_my_op)
    bpy.utils.register_class(SetSourceName_OT_my_op)

    bpy.utils.register_class(Button_Checkbones)
 

    bpy.utils.register_class(Button_footuezz)
    

    

    bpy.types.Scene.arma = bpy.props.EnumProperty(items=arma_items, update=arma_upd)
    bpy.types.Scene.bone = bpy.props.EnumProperty(items=bone_items)
    bpy.types.Scene.arma_coll = bpy.props.CollectionProperty(type=bpy.types.PropertyGroup)
    
    
    
    
    
    #Armaure 1
    bpy.types.Scene.Armature_Source = bpy.props.StringProperty()
    #Armaure 2
    bpy.types.Scene.Armature_Target = bpy.props.StringProperty()

    bpy.types.Scene.Your_Animation = bpy.props.StringProperty()
   
    
    
    #thigh.L
    bpy.types.Scene.bone_target1 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target2 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target3 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target4 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target5 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target6 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target7 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target8 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target9 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target10 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target11 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target12 = bpy.props.StringProperty()




    #thigh.R
    bpy.types.Scene.bone_target13 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target14 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target15 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target16 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target17 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target18 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target19 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target20 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target21 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target22 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target23 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target24 = bpy.props.StringProperty()




    #Arm.L
    bpy.types.Scene.bone_target25 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target26 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target27 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target28 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target29 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target30 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target31 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target32 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target33 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target34 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target35 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target36 = bpy.props.StringProperty()



    #Arm.R
    bpy.types.Scene.bone_target37 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target38 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target39 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target40 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target41 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target42 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target43 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target44 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target45 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target46 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target47 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target48 = bpy.props.StringProperty()



    #Spine
    bpy.types.Scene.bone_target49 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target50 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target51 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target52 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target53 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target54 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target55 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target56 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target57 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target58 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target59 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target60 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target61 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target62 = bpy.props.StringProperty()

    bpy.types.Scene.bone_targetHip = bpy.props.StringProperty()
    bpy.types.Scene.bone_sourceHip = bpy.props.StringProperty()



    #fingers.R
    bpy.types.Scene.bone_target63 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target64 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target65 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target66 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target67 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target68 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target69 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target70 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target71 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target72 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target73 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target74 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target75 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target76 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target77 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target78 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target79 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target80 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target81 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target82 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target83 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target84 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target85 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target86 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target87 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target88 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target89 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target90 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target91 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target92 = bpy.props.StringProperty()

 

    #fingers.L
    bpy.types.Scene.bone_target93 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target94 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target95 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target96 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target97 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target98 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target99 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target100 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target101 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target102 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target103 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target104 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target105 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target106 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target107 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target108 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target109 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target110 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target111 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target112 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target113 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target114 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target115 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target116 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target117 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target118 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target119 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target120 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target121 = bpy.props.StringProperty()
    bpy.types.Scene.bone_target122 = bpy.props.StringProperty()

    
   
    bpy.utils.register_class(Getue_Shoulderfix)

    
    
    bpy.utils.register_class(rig_fy_rigfy)
    


    



    bpy.utils.register_class(MB_OT_Op)





    
    bpy.utils.register_class(Unlink_Anim_an)

    bpy.utils.register_class(MB_Panel_direc)

    bpy.utils.register_class(indexDir_op)
    bpy.utils.register_class(middleDir_op)

    bpy.utils.register_class(ringDir_op)
    bpy.utils.register_class(pinkyDir_op)
    
    bpy.utils.register_class(hand_op)

    bpy.utils.register_class(rootmak_op)
   
    bpy.utils.register_class(MB_Panel_Posemake)

    bpy.utils.register_class(MB_Panel_applycur)
    
    
    

    bpy.utils.register_class(scaandloco_save_op)
    bpy.utils.register_class(scaandloco_apply_op)

    
    
    ###############################################################
    ###############################################################
    ###############################################################
    
   
    bpy.utils.register_class(Button_SetBoneName01)
    bpy.utils.register_class(Button_SetBoneName02)
    bpy.utils.register_class(Button_SetBoneName03)
    bpy.utils.register_class(Button_SetBoneName04)
    bpy.utils.register_class(Button_SetBoneName05)
    bpy.utils.register_class(Button_SetBoneName06butt)
    bpy.utils.register_class(Button_SetBoneName07)
    bpy.utils.register_class(Button_SetBoneName08butt)
    bpy.utils.register_class(Button_SetBoneName09)
    bpy.utils.register_class(Button_SetBoneName010)
    bpy.utils.register_class(Button_SetBoneName011)
    bpy.utils.register_class(Button_SetBoneName012)
    bpy.utils.register_class(Button_SetBoneName013)
    bpy.utils.register_class(Button_SetBoneName014)
    bpy.utils.register_class(Button_SetBoneName015)
    bpy.utils.register_class(Button_SetBoneName016)
    bpy.utils.register_class(Button_SetBoneName017)
    bpy.utils.register_class(Button_SetBoneName018)
    bpy.utils.register_class(Button_SetBoneName019)
    bpy.utils.register_class(Button_SetBoneName020)
    bpy.utils.register_class(Button_SetBoneName021)
    bpy.utils.register_class(Button_SetBoneName022)
    bpy.utils.register_class(Button_SetBoneName023)
    bpy.utils.register_class(Button_SetBoneName024)
    bpy.utils.register_class(Button_SetBoneName025)
    bpy.utils.register_class(Button_SetBoneName026)
    bpy.utils.register_class(Button_SetBoneName027)
    bpy.utils.register_class(Button_SetBoneName028)
    bpy.utils.register_class(Button_SetBoneName029)
    bpy.utils.register_class(Button_SetBoneName030)
    bpy.utils.register_class(Button_SetBoneName031)
    bpy.utils.register_class(Button_SetBoneName032)
    bpy.utils.register_class(Button_SetBoneName033)
    bpy.utils.register_class(Button_SetBoneName034)
    bpy.utils.register_class(Button_SetBoneName035)
    bpy.utils.register_class(Button_SetBoneName036)
    bpy.utils.register_class(Button_SetBoneName037)
    bpy.utils.register_class(Button_SetBoneName038)
    bpy.utils.register_class(Button_SetBoneName039)
    bpy.utils.register_class(Button_SetBoneName040)
    bpy.utils.register_class(Button_SetBoneName041)
    bpy.utils.register_class(Button_SetBoneName042)
    bpy.utils.register_class(Button_SetBoneName043)
    bpy.utils.register_class(Button_SetBoneName044)
    bpy.utils.register_class(Button_SetBoneName045)
    bpy.utils.register_class(Button_SetBoneName046)
    bpy.utils.register_class(Button_SetBoneName047)
    bpy.utils.register_class(Button_SetBoneName048)
    bpy.utils.register_class(Button_SetBoneName049)
    bpy.utils.register_class(Button_SetBoneName050)
    bpy.utils.register_class(Button_SetBoneName051)
    bpy.utils.register_class(Button_SetBoneName052)
    bpy.utils.register_class(Button_SetBoneName053)
    bpy.utils.register_class(Button_SetBoneName054)
    bpy.utils.register_class(Button_SetBoneName055)
    bpy.utils.register_class(Button_SetBoneName056)
    bpy.utils.register_class(Button_SetBoneName057)
    bpy.utils.register_class(Button_SetBoneName058)
    bpy.utils.register_class(Button_SetBoneName059)
    bpy.utils.register_class(Button_SetBoneName060)
    bpy.utils.register_class(Button_SetBoneName061)
    bpy.utils.register_class(Button_SetBoneName062)
    bpy.utils.register_class(Button_SetBoneName063)
    bpy.utils.register_class(Button_SetBoneName064)
    bpy.utils.register_class(Button_SetBoneName065)
    bpy.utils.register_class(Button_SetBoneName066)
    bpy.utils.register_class(Button_SetBoneName067)
    bpy.utils.register_class(Button_SetBoneName068)
    bpy.utils.register_class(Button_SetBoneName069)
    bpy.utils.register_class(Button_SetBoneName070)
    bpy.utils.register_class(Button_SetBoneName071)

    bpy.utils.register_class(Button_SetBoneName072)
    bpy.utils.register_class(Button_SetBoneName073)
    bpy.utils.register_class(Button_SetBoneName074)
    bpy.utils.register_class(Button_SetBoneName075)

    bpy.utils.register_class(Button_SetBoneName076)
    bpy.utils.register_class(Button_SetBoneName077)
    bpy.utils.register_class(Button_SetBoneName078)
    bpy.utils.register_class(Button_SetBoneName079)



    bpy.utils.register_class(apply_scaleonly_op)
    
    bpy.utils.register_class(MBPanel_fbatch)

    

    bpy.utils.register_class(move_tolayer_an)

    bpy.utils.register_class(show_tolayer_an)

    bpy.utils.register_class(hide_tolayer_an)

    
    
    
    
    bpy.utils.register_class(center_OT_op)

    


    bpy.utils.register_class(removeac_OT_op)

    bpy.utils.register_class(namingfix_op)

    bpy.utils.register_class(setnameue_op)



    # bpy.utils.register_class(rigfy_Panel_a)

   

    bpy.utils.register_class(namingfixnoid_op)

    bpy.utils.register_class(finger_save_op)
    bpy.utils.register_class(finger_apply_op)

    bpy.utils.register_class(rig_adjusspine_op)
    bpy.utils.register_class(rig_adjustment_op)


    bpy.utils.register_class(adjustment_save_op)

    bpy.utils.register_class(adjustment_apply_op)


    bpy.utils.register_class(lefthand_new_op)
    bpy.utils.register_class(rigthand_new_op)

    bpy.utils.register_class(lefthand_rot_op)

    bpy.utils.register_class(rigthand_rot_op)
    
    
    bpy.utils.register_class(showaxx_op)
    bpy.utils.register_class(deletttmup_op)

    bpy.utils.register_class(spine_newss_op)

     
    bpy.utils.register_class(spine_rotoo_op)

    bpy.utils.register_class(fix_twist_op)
    bpy.utils.register_class(fix_twistback_op)

    bpy.utils.register_class(fbatch_aexport_op)

    bpy.types.Scene.armature_objectrfy = bpy.props.PointerProperty(type=bpy.types.Object)

    bpy.types.Scene.armature_objtem = bpy.props.PointerProperty(type=bpy.types.Object)
    
    bpy.types.Scene.my_toolgrue = bpy.props.PointerProperty(type= MyProperties) 

    
     

 
    bpy.utils.register_class(MB_About_Posemake)

    bpy.utils.register_class(mbmute_co_Op)
    bpy.utils.register_class(mbunmute_co_Op)
    bpy.utils.register_class(spine_curuev_op)

    bpy.utils.register_class(daz_OT_op)
    bpy.utils.register_class(fixloc_OT_op)

    bpy.utils.register_class(Auto_SetScalerf)
    bpy.utils.register_class(Offist_SetScalerf)

    bpy.utils.register_class(posemake_op)
    bpy.utils.register_class(getanimwpose_rig_in)
    bpy.utils.register_class(animpose_only_op)
    bpy.utils.register_class(expoer_fbx_op)


    
     
     
    
    
    

    



    
 



    
  
def unregister():
    
    bpy.utils.unregister_class(namingfix_op)

    bpy.utils.unregister_class(setnameue_op)

    bpy.utils.unregister_class(MB_About_Posemake)

    bpy.utils.unregister_class(scaandloco_save_op)
    bpy.utils.unregister_class(scaandloco_apply_op)

    bpy.utils.unregister_class(apply_scaleonly_op)

    bpy.utils.unregister_class(move_tolayer_an)

    bpy.utils.unregister_class(show_tolayer_an)

    bpy.utils.unregister_class(hide_tolayer_an)

    # bpy.utils.unregister_class(rigfy_Panel_a)

 


    
    


    bpy.utils.unregister_class(center_OT_op)


   
      

    bpy.utils.unregister_class(removeac_OT_op)

    bpy.utils.unregister_class(namingfixnoid_op)

      
    bpy.utils.unregister_class(hand_op)
    bpy.utils.unregister_class(MBPanel)
    
   
    
    bpy.utils.unregister_class(fixhedrot_roto_in)
     
   
    

    bpy.utils.unregister_class(Button_Checkbones) 

    bpy.utils.unregister_class(rootmak_op)

    bpy.utils.unregister_class(indexDir_op)
    bpy.utils.unregister_class(middleDir_op)

    bpy.utils.unregister_class(ringDir_op)
    bpy.utils.unregister_class(pinkyDir_op)
    
    bpy.utils.unregister_class(finger_save_op)
    bpy.utils.unregister_class(finger_apply_op)



    bpy.utils.unregister_class(MB_Panel_applycur)

    bpy.utils.unregister_class(MB_Panel_direc)

    bpy.utils.unregister_class(fingersdirec_OT_op)

    bpy.utils.unregister_class(bone_liss_my_op)

    bpy.utils.unregister_class(rigs_liss_my_op)
    
    bpy.utils.unregister_class(MB_Panel_Posemake)

    bpy.utils.unregister_class(rig_fy_rigfy)
    
    bpy.utils.unregister_class(MB_OT_Op)

    


     
    bpy.utils.unregister_class(Unlink_Anim_an)
 
    bpy.utils.unregister_class(link_Anim_an)



    bpy.utils.unregister_class(fingersnew_OT_op)

    bpy.utils.unregister_class(root_SP_main_panel)

   
    
    bpy.utils.unregister_class(helper_OT_op)

    bpy.utils.unregister_class(MyProperties)
    bpy.utils.unregister_class(Save_OT_my_op)
    bpy.utils.unregister_class(Load_OT_my_op)
    bpy.types.Scene.my_tool
    bpy.utils.unregister_class(ExportSomeData)
    bpy.types.TOPBAR_MT_file_export.remove(menu_func_export)
    
    
    bpy.utils.unregister_class(clr_map_an)
  
   
     
    #///////////////////////////////category

    bpy.utils.unregister_class(Scale_Cat_p)
  
    bpy.utils.unregister_class(Bone_Cat_b2)
    bpy.utils.unregister_class(Bone_Cat_b3)
    bpy.utils.unregister_class(Bone_Cat_b4)
    bpy.utils.unregister_class(Bone_Cat_b5)
    bpy.utils.unregister_class(Bone_Cat_b6)
    bpy.utils.unregister_class(Right_HandFingers_Fingers)
    bpy.utils.unregister_class(Left_HandFingers_Fingers)
    bpy.utils.unregister_class(Button_SetScalerf)  
   
    
    bpy.utils.unregister_class(Button_footfixpm)
    
    bpy.utils.unregister_class(Button_fixfootroto)


    bpy.utils.unregister_class(autoscaleroot_OT_op)

    bpy.utils.unregister_class(Button_footuezz)

    bpy.utils.unregister_class(getanim_rig_in)
    
    bpy.utils.unregister_class(autoscale_OT_op)
    
    #buttons
    
     
 
    
    
    
    bpy.utils.unregister_class(CreatRig_OT_my_op)
    
    bpy.utils.unregister_class(Button_MakeDEF_Bones)



    #new
    bpy.utils.unregister_class(SetTargetName_OT_my_op)
    bpy.utils.unregister_class(SetSourceName_OT_my_op)

    bpy.utils.unregister_class(MB_Panel_PoseEditor)      

    
  

    bpy.utils.unregister_class(Getue_Shoulderfix)  

 
    bpy.utils.unregister_class(rig_creation_op) 
    
    del bpy.types.Scene.my_filepath
    
    ###############################################################
    ###############################################################
    ###############################################################
    
    
    
    bpy.utils.unregister_class(Button_SetBoneName01)
    bpy.utils.unregister_class(Button_SetBoneName02)
    bpy.utils.unregister_class(Button_SetBoneName03)
    bpy.utils.unregister_class(Button_SetBoneName04)
    bpy.utils.unregister_class(Button_SetBoneName05)
    bpy.utils.unregister_class(Button_SetBoneName06butt)
    bpy.utils.unregister_class(Button_SetBoneName07)
    bpy.utils.unregister_class(Button_SetBoneName08butt)
    bpy.utils.unregister_class(Button_SetBoneName09)
    bpy.utils.unregister_class(Button_SetBoneName010)
    bpy.utils.unregister_class(Button_SetBoneName011)
    bpy.utils.unregister_class(Button_SetBoneName012)
    bpy.utils.unregister_class(Button_SetBoneName013)
    bpy.utils.unregister_class(Button_SetBoneName014)
    bpy.utils.unregister_class(Button_SetBoneName015)
    bpy.utils.unregister_class(Button_SetBoneName016)
    bpy.utils.unregister_class(Button_SetBoneName017)
    bpy.utils.unregister_class(Button_SetBoneName018)
    bpy.utils.unregister_class(Button_SetBoneName019)
    bpy.utils.unregister_class(Button_SetBoneName020)
    bpy.utils.unregister_class(Button_SetBoneName021)
    bpy.utils.unregister_class(Button_SetBoneName022)
    bpy.utils.unregister_class(Button_SetBoneName023)
    bpy.utils.unregister_class(Button_SetBoneName024)
    bpy.utils.unregister_class(Button_SetBoneName025)
    bpy.utils.unregister_class(Button_SetBoneName026)
    bpy.utils.unregister_class(Button_SetBoneName027)
    bpy.utils.unregister_class(Button_SetBoneName028)
    bpy.utils.unregister_class(Button_SetBoneName029)
    bpy.utils.unregister_class(Button_SetBoneName030)
    bpy.utils.unregister_class(Button_SetBoneName031)
    bpy.utils.unregister_class(Button_SetBoneName032)
    bpy.utils.unregister_class(Button_SetBoneName033)
    bpy.utils.unregister_class(Button_SetBoneName034)
    bpy.utils.unregister_class(Button_SetBoneName035)
    bpy.utils.unregister_class(Button_SetBoneName036)
    bpy.utils.unregister_class(Button_SetBoneName037)
    bpy.utils.unregister_class(Button_SetBoneName038)
    bpy.utils.unregister_class(Button_SetBoneName039)
    bpy.utils.unregister_class(Button_SetBoneName040)
    bpy.utils.unregister_class(Button_SetBoneName041)
    bpy.utils.unregister_class(Button_SetBoneName042)
    bpy.utils.unregister_class(Button_SetBoneName043)
    bpy.utils.unregister_class(Button_SetBoneName044)
    bpy.utils.unregister_class(Button_SetBoneName045)
    bpy.utils.unregister_class(Button_SetBoneName046)
    bpy.utils.unregister_class(Button_SetBoneName047)
    bpy.utils.unregister_class(Button_SetBoneName048)
    bpy.utils.unregister_class(Button_SetBoneName049)
    bpy.utils.unregister_class(Button_SetBoneName050)
    bpy.utils.unregister_class(Button_SetBoneName051)
    bpy.utils.unregister_class(Button_SetBoneName052)
    bpy.utils.unregister_class(Button_SetBoneName053)
    bpy.utils.unregister_class(Button_SetBoneName054)
    bpy.utils.unregister_class(Button_SetBoneName055)
    bpy.utils.unregister_class(Button_SetBoneName056)
    bpy.utils.unregister_class(Button_SetBoneName057)
    bpy.utils.unregister_class(Button_SetBoneName058)
    bpy.utils.unregister_class(Button_SetBoneName059)
    bpy.utils.unregister_class(Button_SetBoneName060)
    bpy.utils.unregister_class(Button_SetBoneName061)
    bpy.utils.unregister_class(Button_SetBoneName062)
    bpy.utils.unregister_class(Button_SetBoneName063)
    bpy.utils.unregister_class(Button_SetBoneName064)
    bpy.utils.unregister_class(Button_SetBoneName065)
    bpy.utils.unregister_class(Button_SetBoneName066)
    bpy.utils.unregister_class(Button_SetBoneName067)
    bpy.utils.unregister_class(Button_SetBoneName068)
    bpy.utils.unregister_class(Button_SetBoneName069)
    bpy.utils.unregister_class(Button_SetBoneName070)
    bpy.utils.unregister_class(Button_SetBoneName071)


    bpy.utils.unregister_class(Button_SetBoneName072)
    bpy.utils.unregister_class(Button_SetBoneName073)
    bpy.utils.unregister_class(Button_SetBoneName074)
    bpy.utils.unregister_class(Button_SetBoneName075)

    bpy.utils.unregister_class(Button_SetBoneName076)
    bpy.utils.unregister_class(Button_SetBoneName077)
    bpy.utils.unregister_class(Button_SetBoneName078)
    bpy.utils.unregister_class(Button_SetBoneName079)

    bpy.utils.unregister_class(rig_adjustment_op)

    bpy.utils.unregister_class(rig_adjusspine_op)

    bpy.utils.unregister_class(adjustment_save_op)

    bpy.utils.unregister_class(adjustment_apply_op)


    bpy.utils.unregister_class(lefthand_new_op)
    bpy.utils.unregister_class(rigthand_new_op)
    bpy.utils.unregister_class(lefthand_rot_op)
    bpy.utils.unregister_class(rigthand_rot_op)

    bpy.utils.unregister_class(showaxx_op)
    bpy.utils.unregister_class(deletttmup_op)

    bpy.utils.unregister_class(spine_newss_op)
    bpy.utils.unregister_class(spine_rotoo_op)


    bpy.utils.unregister_class(fix_twist_op)
    
    bpy.utils.unregister_class(fix_twistback_op)
 

    bpy.utils.unregister_class(fbatch_aexport_op)

    bpy.utils.unregister_class(MBPanel_fbatch)

 


    
    del bpy.types.Scene.Armature_Source
    del bpy.types.Scene.Armature_Target

    #thigh.L
    del bpy.types.Scene.bone_target1  
    del bpy.types.Scene.bone_target2
    del bpy.types.Scene.bone_target3  
    del bpy.types.Scene.bone_target4
    del bpy.types.Scene.bone_target5  
    del bpy.types.Scene.bone_target6
    del bpy.types.Scene.bone_target7 
    del bpy.types.Scene.bone_target8
    del bpy.types.Scene.bone_target9  
    del bpy.types.Scene.bone_target10
    del bpy.types.Scene.bone_target11  
    del bpy.types.Scene.bone_target12

    #thigh.R
    del bpy.types.Scene.bone_target13  
    del bpy.types.Scene.bone_target14
    del bpy.types.Scene.bone_target15 
    del bpy.types.Scene.bone_target16
    del bpy.types.Scene.bone_target17  
    del bpy.types.Scene.bone_target18
    del bpy.types.Scene.bone_target19 
    del bpy.types.Scene.bone_target20
    del bpy.types.Scene.bone_target21  
    del bpy.types.Scene.bone_target22
    del bpy.types.Scene.bone_target23  
    del bpy.types.Scene.bone_target24



    #Arm.L
    del bpy.types.Scene.bone_target25  
    del bpy.types.Scene.bone_target26
    del bpy.types.Scene.bone_target27
    del bpy.types.Scene.bone_target28
    del bpy.types.Scene.bone_target29  
    del bpy.types.Scene.bone_target30
    del bpy.types.Scene.bone_target31 
    del bpy.types.Scene.bone_target32
    del bpy.types.Scene.bone_target33  
    del bpy.types.Scene.bone_target34
    del bpy.types.Scene.bone_target35
    del bpy.types.Scene.bone_target36




    #Arm.R
    del bpy.types.Scene.bone_target37  
    del bpy.types.Scene.bone_target38
    del bpy.types.Scene.bone_target39
    del bpy.types.Scene.bone_target40
    del bpy.types.Scene.bone_target41  
    del bpy.types.Scene.bone_target42
    del bpy.types.Scene.bone_target43
    del bpy.types.Scene.bone_target44
    del bpy.types.Scene.bone_target45  
    del bpy.types.Scene.bone_target46
    del bpy.types.Scene.bone_target47
    del bpy.types.Scene.bone_target48



    #Spine

    del bpy.types.Scene.bone_target49  
    del bpy.types.Scene.bone_target50
    del bpy.types.Scene.bone_target51
    del bpy.types.Scene.bone_target52
    del bpy.types.Scene.bone_target53  
    del bpy.types.Scene.bone_target54
    del bpy.types.Scene.bone_target55
    del bpy.types.Scene.bone_target56
    del bpy.types.Scene.bone_target57  
    del bpy.types.Scene.bone_target58
    del bpy.types.Scene.bone_target59
    del bpy.types.Scene.bone_target60
    del bpy.types.Scene.bone_target61
    del bpy.types.Scene.bone_target62

    del bpy.types.Scene.bone_targetHip
    del bpy.types.Scene.bone_sourceHip


 


    #Fingers.R

    del bpy.types.Scene.bone_target63  
    del bpy.types.Scene.bone_target64
    del bpy.types.Scene.bone_target65
    del bpy.types.Scene.bone_target66
    del bpy.types.Scene.bone_target67
    del bpy.types.Scene.bone_target68
    del bpy.types.Scene.bone_target69
    del bpy.types.Scene.bone_target70
    del bpy.types.Scene.bone_target71
    del bpy.types.Scene.bone_target72
    del bpy.types.Scene.bone_target73
    del bpy.types.Scene.bone_target74
    del bpy.types.Scene.bone_target75
    del bpy.types.Scene.bone_target76
    del bpy.types.Scene.bone_target77  
    del bpy.types.Scene.bone_target78
    del bpy.types.Scene.bone_target79
    del bpy.types.Scene.bone_target80
    del bpy.types.Scene.bone_target81
    del bpy.types.Scene.bone_target82
    del bpy.types.Scene.bone_target83
    del bpy.types.Scene.bone_target84
    del bpy.types.Scene.bone_target85  
    del bpy.types.Scene.bone_target86
    del bpy.types.Scene.bone_target87
    del bpy.types.Scene.bone_target88
    del bpy.types.Scene.bone_target89
    del bpy.types.Scene.bone_target90
    del bpy.types.Scene.bone_target91
    del bpy.types.Scene.bone_target92

   

    #Fingers./

    del bpy.types.Scene.bone_target93  
    del bpy.types.Scene.bone_target94
    del bpy.types.Scene.bone_target95
    del bpy.types.Scene.bone_target96
    del bpy.types.Scene.bone_target97
    del bpy.types.Scene.bone_target98
    del bpy.types.Scene.bone_target99
    del bpy.types.Scene.bone_target100
    del bpy.types.Scene.bone_target101
    del bpy.types.Scene.bone_target102
    del bpy.types.Scene.bone_target103
    del bpy.types.Scene.bone_target104
    del bpy.types.Scene.bone_target105
    del bpy.types.Scene.bone_target106
    del bpy.types.Scene.bone_target107  
    del bpy.types.Scene.bone_target108
    del bpy.types.Scene.bone_target109
    del bpy.types.Scene.bone_target110
    del bpy.types.Scene.bone_target111
    del bpy.types.Scene.bone_target112
    del bpy.types.Scene.bone_target113
    del bpy.types.Scene.bone_target114
    del bpy.types.Scene.bone_target115  
    del bpy.types.Scene.bone_target116
    del bpy.types.Scene.bone_target117
    del bpy.types.Scene.bone_target118
    del bpy.types.Scene.bone_target119
    del bpy.types.Scene.bone_target120
    del bpy.types.Scene.bone_target121
    del bpy.types.Scene.bone_target122


    del bpy.types.Scene.armature_objectrfy
    del bpy.types.Scene.armature_objtem
 


    bpy.utils.unregister_class(mbmute_co_Op)
    bpy.utils.unregister_class(mbunmute_co_Op)
    bpy.utils.unregister_class(spine_curuev_op)

    bpy.utils.unregister_class(daz_OT_op)
    bpy.utils.unregister_class(fixloc_OT_op)


    bpy.utils.unregister_class(Auto_SetScalerf)
    bpy.utils.unregister_class(Offist_SetScalerf)

    bpy.utils.unregister_class(posemake_op)
    bpy.utils.unregister_class(getanimwpose_rig_in)
    bpy.utils.unregister_class(animpose_only_op)

    bpy.utils.unregister_class(expoer_fbx_op)

   


     
    
     
    
  

   



    




    

     
    
    
    
     