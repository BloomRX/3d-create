import bpy
import math
  
 


class getanim_rig_in(bpy.types.Operator):
    bl_label = "Get Animation "
    bl_idname = "animrigin.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        context.window_manager.progress = 0.0
        bpy.context.window_manager.progress_begin(0.0, 100.0)

        
        
        bpy.context.window_manager.progress_update(71.0)

        mytool.my_int_famee = bpy.context.scene.frame_end 


        
        



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_Anime_"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.context.object.hide_viewport = False
        bpy.context.object.hide_render = False
        bpy.context.object.hide_set(False)
        bpy.context.object.hide_select = False

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["Rig_AnimRF"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.context.object.hide_viewport = False
        bpy.context.object.hide_render = False
        bpy.context.object.hide_set(False)
        bpy.context.object.hide_select = False





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_For_Animation"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.context.object.hide_viewport = False
        bpy.context.object.hide_render = False
        bpy.context.object.hide_set(False)
        bpy.context.object.hide_select = False 

        objects = bpy.context.scene.objects.keys()
        if  'Rig_AnimRF_root' in objects:


            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Rig_AnimRF_root"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.context.object.hide_viewport = False
            bpy.context.object.hide_render = False
            bpy.context.object.hide_set(False)
            bpy.context.object.hide_select = False


 











        
      
        
        
        armatureFrom = bpy.data.objects["RF_Anime_"]
        armatureTo = bpy.data.objects["RF_For_Animation"]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)
            #copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
            copy_con = boneTo.constraints.new('COPY_ROTATION')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name
            copy_con2 = boneTo.constraints.new('COPY_LOCATION')
            copy_con2.target = armatureFrom
            copy_con2.subtarget = boneFrom.name
            
            
            copy_con3 = boneTo.constraints.new('COPY_SCALE')
            copy_con3.target = armatureFrom
            copy_con3.subtarget = boneFrom.name
            copy_con3.target_space = 'LOCAL'
            copy_con3.owner_space = 'LOCAL'








        ##Rest
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["RF_For_Animation"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.ops.object.location_clear(clear_delta=False)


    

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'root_Tempp'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root_Tempp"] # "root.001"
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

    
        
        for obj in bpy.context.selected_objects:
            obj.name = "Your_Rig_For_Aninm"
            obj.data.name = "Your_Rig_For_Aninm"
            
            

       
        
        armatureFrom = bpy.data.objects['Your_Rig_For_Aninm']
        armatureTo = bpy.data.objects["RF_For_Animation"]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)

            copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name
            copy_con.target_space = 'POSE'
            copy_con.owner_space = 'POSE'


        
       

       
       
        ##Join Rigs
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["Your_Rig_For_Aninm"] 
        objectToSelect2 = bpy.data.objects["RF_For_Animation"] 
        objectToSelect.select_set(True)    
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.ops.object.join()




        
        
        ##Rest
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["Your_Rig_For_Aninm"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.ops.object.location_clear(clear_delta=False)

        
        
        
        
        
        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["Your_Rig_For_Aninm"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects["Your_Rig_For_Aninm"] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.loc_clear()
        bpy.ops.pose.rot_clear()

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')






        #Setup 

        #//////////////////////////////////////////////  #Setup   #////////////////////////////////////////////// 



        bpy.ops.object.select_all(action='DESELECT')
        ob = bpy.data.objects["Your_Rig_For_Aninm"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        arm = bpy.data.objects["Your_Rig_For_Aninm"]

 
        arm.data.edit_bones['clavicle_l'].parent = arm.data.edit_bones[sce.bone_target17]
        
        if sce.bone_target17 !="": 
            arm.data.edit_bones['upperarm_twist_01_l'].parent = arm.data.edit_bones[sce.bone_target18]

        if sce.bone_target20 !="": 
            arm.data.edit_bones['upperarm_twist_02_l'].parent = arm.data.edit_bones[sce.bone_target20]
        
        if sce.bone_target21 !="": 
            arm.data.edit_bones['lowerarm_twist_02_l'].parent = arm.data.edit_bones[sce.bone_target21]
           
        if sce.bone_target23 !="": 
            arm.data.edit_bones['lowerarm_twist_01_l'].parent = arm.data.edit_bones[sce.bone_target23]

        if sce.bone_target24 !="": 
            arm.data.edit_bones['hand_l'].parent = arm.data.edit_bones[sce.bone_target24]
            
        if sce.bone_target1 !="": 
            
            arm.data.edit_bones['thigh_twist_01_l'].parent = arm.data.edit_bones[sce.bone_target1]

        if sce.bone_target3 !="": 
            arm.data.edit_bones['thigh_twist_02_l'].parent = arm.data.edit_bones[sce.bone_target3]
   
        if sce.bone_target4 !="": 
            arm.data.edit_bones['calf_twist_02_l'].parent = arm.data.edit_bones[sce.bone_target4]
 
        if sce.bone_target6 !="": 
            arm.data.edit_bones['calf_twist_01_l'].parent = arm.data.edit_bones[sce.bone_target6]
  
        if sce.bone_target7 !="": 
            arm.data.edit_bones['foot_l'].parent = arm.data.edit_bones[sce.bone_target7]
    

        if sce.bone_target8 !="": 
            arm.data.edit_bones['ball_l'].parent = arm.data.edit_bones[sce.bone_target8]
            
        ###New/////////////////////////////////////////////////

        if sce.bone_target4 !="": 
            arm.data.edit_bones['calf_l'].parent = arm.data.edit_bones[sce.bone_target4]
 

        if sce.bone_target12 !="": 
            arm.data.edit_bones['calf_r'].parent = arm.data.edit_bones[sce.bone_target12]
 

        ###New/////////////////////////////////////////////

        if sce.bone_target25 !="":       
            arm.data.edit_bones['clavicle_r'].parent = arm.data.edit_bones[sce.bone_target25]
         
        if sce.bone_target26 !="": 
            arm.data.edit_bones['upperarm_twist_01_r'].parent = arm.data.edit_bones[sce.bone_target26]

             

        if sce.bone_target28 !="": 
            arm.data.edit_bones['upperarm_twist_02_r'].parent = arm.data.edit_bones[sce.bone_target28]
 
        if sce.bone_target29 !="": 
            arm.data.edit_bones['lowerarm_twist_02_r'].parent = arm.data.edit_bones[sce.bone_target29]
 

        if sce.bone_target31 !="": 
            arm.data.edit_bones['lowerarm_twist_01_r'].parent = arm.data.edit_bones[sce.bone_target31]

           

        if sce.bone_target32 !="": 
            arm.data.edit_bones['hand_r'].parent = arm.data.edit_bones[sce.bone_target32]
 

        if sce.bone_target9 !="": 
            arm.data.edit_bones['thigh_twist_01_r'].parent = arm.data.edit_bones[sce.bone_target9]
 


        if sce.bone_target11 !="": 
            arm.data.edit_bones['thigh_twist_02_r'].parent = arm.data.edit_bones[sce.bone_target11]

         

        if sce.bone_target12 !="": 
            arm.data.edit_bones['calf_twist_02_r'].parent = arm.data.edit_bones[sce.bone_target12]
 
        if sce.bone_target14 !="": 
            arm.data.edit_bones['calf_twist_01_r'].parent = arm.data.edit_bones[sce.bone_target14]
 

        if sce.bone_target15 !="": 
            arm.data.edit_bones['foot_r'].parent = arm.data.edit_bones[sce.bone_target15]

            

        if sce.bone_target16 !="": 
            arm.data.edit_bones['ball_r'].parent = arm.data.edit_bones[sce.bone_target16]
 

        #fingers
        if sce.bone_target63 !="": 

            arm.data.edit_bones['index_metacarpal_l'].parent = arm.data.edit_bones[sce.bone_target63]


        if sce.bone_target62 !="": 
            arm.data.edit_bones['middle_metacarpal_l'].parent = arm.data.edit_bones[sce.bone_target62]
 

        if sce.bone_target61 !="": 
            arm.data.edit_bones['ring_metacarpal_l'].parent = arm.data.edit_bones[sce.bone_target61]
             
         

        if sce.bone_target60 !="": 
            arm.data.edit_bones['pinky_metacarpal_l'].parent = arm.data.edit_bones[sce.bone_target60]
 

        if sce.bone_target64 !="":

            arm.data.edit_bones['thumb_01_l'].parent = arm.data.edit_bones[sce.bone_target64] 

             

        if sce.bone_target65 !="": 

            arm.data.edit_bones['thumb_02_l'].parent = arm.data.edit_bones[sce.bone_target65] 
         

        if sce.bone_target66 !="": 
            arm.data.edit_bones['thumb_03_l'].parent = arm.data.edit_bones[sce.bone_target66] 

            

        if sce.bone_target67 !="":
            arm.data.edit_bones['index_01_l'].parent = arm.data.edit_bones[sce.bone_target67]  
 
        if sce.bone_target68 !="": 

            arm.data.edit_bones['index_02_l'].parent = arm.data.edit_bones[sce.bone_target68]  
 


        if sce.bone_target69 !="": 

            arm.data.edit_bones['index_03_l'].parent = arm.data.edit_bones[sce.bone_target69]  
 

        if sce.bone_target70 !="": 

            arm.data.edit_bones['middle_01_l'].parent = arm.data.edit_bones[sce.bone_target70]  


        if sce.bone_target71 !="": 

            arm.data.edit_bones['middle_02_l'].parent = arm.data.edit_bones[sce.bone_target71]  
 
        if sce.bone_target72 !="": 

            arm.data.edit_bones['middle_03_l'].parent = arm.data.edit_bones[sce.bone_target72]  

 

        if sce.bone_target73 !="": 


            arm.data.edit_bones['ring_01_l'].parent = arm.data.edit_bones[sce.bone_target73]  

 

        if sce.bone_target74 !="": 

            arm.data.edit_bones['ring_02_l'].parent = arm.data.edit_bones[sce.bone_target74]  
 

        if sce.bone_target75 !="":

            arm.data.edit_bones['ring_03_l'].parent = arm.data.edit_bones[sce.bone_target75]      
  
        if sce.bone_target76 !="": 


            arm.data.edit_bones['pinky_01_l'].parent = arm.data.edit_bones[sce.bone_target76]  
 
        if sce.bone_target77 !="": 

            arm.data.edit_bones['pinky_02_l'].parent = arm.data.edit_bones[sce.bone_target77]  
 

        if sce.bone_target78 !="": 

            arm.data.edit_bones['pinky_03_l'].parent = arm.data.edit_bones[sce.bone_target78]  
  


        #fingers RRRRRRRR

        if sce.bone_target44 !="": 

            arm.data.edit_bones['index_metacarpal_r'].parent = arm.data.edit_bones[sce.bone_target44]  
 

        if sce.bone_target43 !="": 

            arm.data.edit_bones['middle_metacarpal_r'].parent = arm.data.edit_bones[sce.bone_target43]  

            

        if sce.bone_target42 !="": 

            arm.data.edit_bones['ring_metacarpal_r'].parent = arm.data.edit_bones[sce.bone_target42]  
        
        bpy.context.window_manager.progress_update(72.0)

        if sce.bone_target41 !="": 

            arm.data.edit_bones['pinky_metacarpal_r'].parent = arm.data.edit_bones[sce.bone_target41]  
 

        if sce.bone_target45 !="":


            arm.data.edit_bones['thumb_01_r'].parent = arm.data.edit_bones[sce.bone_target45]   

            


        if sce.bone_target46 !="": 

            arm.data.edit_bones['thumb_02_r'].parent = arm.data.edit_bones[sce.bone_target46]   
 

        if sce.bone_target47 !="": 


            arm.data.edit_bones['thumb_03_r'].parent = arm.data.edit_bones[sce.bone_target47]   

            

        if sce.bone_target48 !="": 

            arm.data.edit_bones['index_01_r'].parent = arm.data.edit_bones[sce.bone_target48]   

            

        if sce.bone_target49 !="": 

             arm.data.edit_bones['index_02_r'].parent = arm.data.edit_bones[sce.bone_target49]   
 

        if sce.bone_target50 !="": 

             arm.data.edit_bones['index_03_r'].parent = arm.data.edit_bones[sce.bone_target50]   

  


        if sce.bone_target51 !="": 

            arm.data.edit_bones['middle_01_r'].parent = arm.data.edit_bones[sce.bone_target51] 

             


        if sce.bone_target52 !="": 


            arm.data.edit_bones['middle_02_r'].parent = arm.data.edit_bones[sce.bone_target52] 

            

        if sce.bone_target53 !="": 

            arm.data.edit_bones['middle_03_r'].parent = arm.data.edit_bones[sce.bone_target53] 

            
 

        if sce.bone_target54 !="": 

            arm.data.edit_bones['ring_01_r'].parent = arm.data.edit_bones[sce.bone_target54] 

         

        if sce.bone_target55 !="": 

            arm.data.edit_bones['ring_02_r'].parent = arm.data.edit_bones[sce.bone_target55] 
 


        if sce.bone_target56 !="": 

            arm.data.edit_bones['ring_03_r'].parent = arm.data.edit_bones[sce.bone_target56] 


            

        if sce.bone_target57 !="": 

            arm.data.edit_bones['pinky_01_r'].parent = arm.data.edit_bones[sce.bone_target57] 


             

        if sce.bone_target58 !="": 

            arm.data.edit_bones['pinky_02_r'].parent = arm.data.edit_bones[sce.bone_target58] 

            

        
        if sce.bone_target59 !="": 

            arm.data.edit_bones['pinky_03_r'].parent = arm.data.edit_bones[sce.bone_target59] 

             
 



        ##Spine

        if sce.bone_targetHip !="": 


            arm.data.edit_bones['pelvis'].parent = arm.data.edit_bones[sce.bone_targetHip] 


             

        if sce.bone_target40 !="":


            arm.data.edit_bones['spine_01'].parent = arm.data.edit_bones[sce.bone_target40] 

           

        if sce.bone_target39 !="":

            arm.data.edit_bones['spine_02'].parent = arm.data.edit_bones[sce.bone_target39] 



 


        if sce.bone_target38 !="":


            arm.data.edit_bones['spine_03'].parent = arm.data.edit_bones[sce.bone_target38] 

             

        if sce.bone_target37 !="":


            arm.data.edit_bones['spine_04'].parent = arm.data.edit_bones[sce.bone_target37] 
        
            


        if sce.bone_target36 !="":


            arm.data.edit_bones['spine_05'].parent = arm.data.edit_bones[sce.bone_target36] 



        if sce.bone_target35 !="":


            arm.data.edit_bones['neck_01'].parent = arm.data.edit_bones[sce.bone_target35] 

            


        if sce.bone_target34 !="":


            arm.data.edit_bones['neck_02'].parent = arm.data.edit_bones[sce.bone_target34] 


 

        if sce.bone_target33 !="":

            arm.data.edit_bones['head'].parent = arm.data.edit_bones[sce.bone_target33] 
 
 

        ##New lowerarm_l

        if sce.bone_target21 !="":


            arm.data.edit_bones['lowerarm_l'].parent = arm.data.edit_bones[sce.bone_target21] 
 


        

        ##lowerarm_r

        if sce.bone_target29 !="":

            arm.data.edit_bones['lowerarm_r'].parent = arm.data.edit_bones[sce.bone_target29]
        
     


        ##thigh_r

        if sce.bone_target9 !="":

            arm.data.edit_bones['thigh_r'].parent = arm.data.edit_bones[sce.bone_target9]
           


        ##thigh_l

        if sce.bone_target1 !="":

            arm.data.edit_bones['thigh_l'].parent = arm.data.edit_bones[sce.bone_target1]
            
             


        ##upperarm_r
        if sce.bone_target26 !="":

            arm.data.edit_bones['upperarm_r'].parent = arm.data.edit_bones[sce.bone_target26]
            
            



        ##upperarm_l

        if sce.bone_target18 !="":

             arm.data.edit_bones['upperarm_l'].parent = arm.data.edit_bones[sce.bone_target18]
         


        ##IK
        if sce.bone_target24 !="":

            arm.data.edit_bones['ik_hand_l'].parent = arm.data.edit_bones[sce.bone_target24]
             


        ##IK
        if sce.bone_target32 !="":


            arm.data.edit_bones['ik_hand_r'].parent = arm.data.edit_bones[sce.bone_target32]
             

        if sce.bone_target32 !="":

            arm.data.edit_bones['ik_hand_gun'].parent = arm.data.edit_bones[sce.bone_target32]
          



        if sce.bone_target7 !="":

            arm.data.edit_bones['ik_foot_l'].parent = arm.data.edit_bones[sce.bone_target7]
             


        if sce.bone_target15 !="":

            arm.data.edit_bones['ik_foot_r'].parent = arm.data.edit_bones[sce.bone_target15]
            
 
        bpy.ops.object.mode_set(mode='OBJECT')

        bpy.context.window_manager.progress_update(73.0)
        ##Rest
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["RF_Anime_"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.ops.object.location_clear(clear_delta=False)

        
        
        
        
        
        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_Anime_"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects["RF_Anime_"] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.loc_clear()
        bpy.ops.pose.rot_clear()

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


      

        armatureFrom = bpy.data.objects['Your_Rig_For_Aninm']
        armatureTo = bpy.data.objects["root"]  

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)

            copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name
            #copy_con.target_space = 'POSE'
            #copy_con.owner_space = 'POSE'

 





         

        armatureFrom = bpy.data.objects['Rig_AnimRF']
        armatureTo = bpy.data.objects["root"]  

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)

            copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name
            #copy_con.target_space = 'POSE'
            #copy_con.owner_space = 'POSE'


        
        
        
        
    
        #NEW COPY ROTO
    
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['lowerarm_twist_01_l']
        myBone2 = armature.edit_bones['lowerarm_twist_02_l']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_ROTATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



        






        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['lowerarm_twist_01_r']
        myBone2 = armature.edit_bones['lowerarm_twist_02_r']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_ROTATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')




        #add Root Bone //////////////////////////////////////////////////////////////////////////
        objects = bpy.context.scene.objects.keys()
        if  'Rig_AnimRF_root' in objects and mytool.my_bool36 ==False:

         

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_Anime_"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.constraint_add(type='COPY_LOCATION')

            bpy.context.object.constraints["Copy Location"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Location"].subtarget = sce.bone_target79
            # bpy.context.object.constraints["Copy Location"].use_x = False
            # bpy.context.object.constraints["Copy Location"].use_z = False


            bpy.ops.object.constraint_add(type='COPY_ROTATION')

            bpy.context.object.constraints["Copy Rotation"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Rotation"].subtarget = sce.bone_target79



            if mytool.my_boolXRroot ==False :
            
                bpy.context.object.constraints["Copy Rotation"].use_x = False

           
            if mytool.my_boolYRroot ==False :
                
                bpy.context.object.constraints["Copy Rotation"].use_y = False
            

            if mytool.my_boolZRroot ==False :
                bpy.context.object.constraints["Copy Rotation"].use_z = False






            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Rig_AnimRF"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.constraint_add(type='COPY_LOCATION')

            bpy.context.object.constraints["Copy Location"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Location"].subtarget = sce.bone_target79
            # bpy.context.object.constraints["Copy Location"].use_x = False
            # bpy.context.object.constraints["Copy Location"].use_z = False

            bpy.ops.object.constraint_add(type='COPY_ROTATION')

            bpy.context.object.constraints["Copy Rotation"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Rotation"].subtarget = sce.bone_target79


            if mytool.my_boolXRroot ==False :
            
                bpy.context.object.constraints["Copy Rotation"].use_x = False

           
            if mytool.my_boolYRroot ==False :
                
                bpy.context.object.constraints["Copy Rotation"].use_y = False
            

            if mytool.my_boolZRroot ==False :
                bpy.context.object.constraints["Copy Rotation"].use_z = False





            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Rig_AnimRF_Fix"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.constraint_add(type='COPY_LOCATION')

            bpy.context.object.constraints["Copy Location"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Location"].subtarget = sce.bone_target79
            # bpy.context.object.constraints["Copy Location"].use_x = False
            # bpy.context.object.constraints["Copy Location"].use_z = False


            bpy.ops.object.constraint_add(type='COPY_ROTATION')

            bpy.context.object.constraints["Copy Rotation"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Rotation"].subtarget = sce.bone_target79

            if mytool.my_boolXRroot ==False :
            
                bpy.context.object.constraints["Copy Rotation"].use_x = False

           
            if mytool.my_boolYRroot ==False :
                
                bpy.context.object.constraints["Copy Rotation"].use_y = False
            

            if mytool.my_boolZRroot ==False :
                bpy.context.object.constraints["Copy Rotation"].use_z = False








            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Rig_AnimRF_root"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.constraint_add(type='COPY_LOCATION')

            bpy.context.object.constraints["Copy Location"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Location"].subtarget = sce.bone_target79
            # bpy.context.object.constraints["Copy Location"].use_x = False
            # bpy.context.object.constraints["Copy Location"].use_z = False


            bpy.ops.object.constraint_add(type='COPY_ROTATION')

            bpy.context.object.constraints["Copy Rotation"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Rotation"].subtarget = sce.bone_target79


            if mytool.my_boolXRroot ==False :
            
                bpy.context.object.constraints["Copy Rotation"].use_x = False

           
            if mytool.my_boolYRroot ==False :
                
                bpy.context.object.constraints["Copy Rotation"].use_y = False
            

            if mytool.my_boolZRroot ==False :
                bpy.context.object.constraints["Copy Rotation"].use_z = False






            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Your_Rig_For_Aninm"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.constraint_add(type='COPY_LOCATION')

            bpy.context.object.constraints["Copy Location"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Location"].subtarget = sce.bone_target79
            # bpy.context.object.constraints["Copy Location"].use_x = False
            # bpy.context.object.constraints["Copy Location"].use_z = False


            bpy.ops.object.constraint_add(type='COPY_ROTATION')

            bpy.context.object.constraints["Copy Rotation"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Rotation"].subtarget = sce.bone_target79

            if mytool.my_boolXRroot ==False :
            
                bpy.context.object.constraints["Copy Rotation"].use_x = False

           
            if mytool.my_boolYRroot ==False :
                
                bpy.context.object.constraints["Copy Rotation"].use_y = False
            

            if mytool.my_boolZRroot ==False :
                bpy.context.object.constraints["Copy Rotation"].use_z = False






            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["root"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.constraint_add(type='COPY_LOCATION')

            bpy.context.object.constraints["Copy Location"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Location"].subtarget = sce.bone_target79
            # bpy.context.object.constraints["Copy Location"].use_x = False
            # bpy.context.object.constraints["Copy Location"].use_z = False


            bpy.ops.object.constraint_add(type='COPY_ROTATION')

            bpy.context.object.constraints["Copy Rotation"].target = bpy.data.objects["Rig_AnimRF_root"]
            bpy.context.object.constraints["Copy Rotation"].subtarget = sce.bone_target79

            if mytool.my_boolXRroot ==False :
            
                bpy.context.object.constraints["Copy Rotation"].use_x = False

           
            if mytool.my_boolYRroot ==False :
                
                bpy.context.object.constraints["Copy Rotation"].use_y = False
            

            if mytool.my_boolZRroot ==False :
                bpy.context.object.constraints["Copy Rotation"].use_z = False

            
            
             
        bpy.context.window_manager.progress_update(75.0)

            

            

            










        # #bake

        if mytool.my_bool33 !=False :
            objectToSelect = bpy.data.objects["root"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect


            ob = bpy.data.objects['root']
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='SELECT')
            myBone = armature.edit_bones["pelvis"]
            myBone.select = True
            armature.edit_bones.active = myBone
            bpy.ops.object.mode_set(mode='POSE')
            bpy.ops.nla.bake(frame_start=mytool.my_int_feames, frame_end=mytool.my_int_famee, step=1, only_selected=True, visual_keying=True, clear_constraints=True, clear_parents=True, use_current_action=True, clean_curves=True, bake_types={'POSE'})
            bpy.ops.object.mode_set(mode='OBJECT')


        objects = bpy.context.scene.objects.keys()
        if  'Rig_AnimRF_root' in objects and mytool.my_bool36 ==False and mytool.my_bool33 !=False:
        
        
            # #bake
            objectToSelect = bpy.data.objects["root"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.ops.nla.bake(frame_start=mytool.my_int_feames, frame_end=mytool.my_int_famee, step=1, only_selected=True, visual_keying=True, clear_constraints=True, clear_parents=True, use_current_action=True, clean_curves=True, bake_types={'OBJECT'})
        








        objects = bpy.context.scene.objects.keys()
        if  'RF_Anime_' in objects:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_Anime_"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')


        objects = bpy.context.scene.objects.keys()
        if  'Rig_AnimRF' in objects:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Rig_AnimRF"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')


        objects = bpy.context.scene.objects.keys()
        if  'Your_Rig_For_Aninm' in objects:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Your_Rig_For_Aninm"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')
            

        
        objects = bpy.context.scene.objects.keys()
        if  'Rig_AnimRF_Fix' in objects:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Rig_AnimRF_Fix"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')
        
        
        
        
        
        
        
        
        
        objects = bpy.context.scene.objects.keys()
        if   sce.Armature_Target  in objects:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')



        
        
        objects = bpy.context.scene.objects.keys()
        if  'Rig_AnimRF_root' in objects :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["root"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
        
        
            # /////////////delete Bones RF
            bpy.ops.object.select_all(action='DESELECT')
            ob = bpy.data.objects["root"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')

            ob = bpy.context.object
            assert ob.type == 'ARMATURE'
            arma = ob.data
            bpy.ops.object.mode_set(mode='EDIT') # ensure edit mode
            bpy.ops.armature.select_all(action='DESELECT')
        
         
            bonein =bpy.data.objects["root"].data.bones.get("root")
            if  bonein is not None :

                bone = arma.edit_bones['root']
                arma.edit_bones.remove(bone)
 
        
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')
        
        
        
        
        objects = bpy.context.scene.objects.keys()
        if  'Rig_AnimRF_root' in objects :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Rig_AnimRF_root"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')



                


        #bpy.ops.headrotof.myop_operator()



        objects = bpy.context.scene.objects.keys()
        if  'RF_Rig' in objects:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_Rig"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')

        if mytool.my_boolremoveuaction !=False : 
                    
            bpy.ops.removeac.myop_operator()
 

        
        if mytool.my_string54 !=False :

            bpy.ops.fixtwistoback.myop_operator()

        bpy.context.window_manager.progress_update(76.0)

        
        return {'FINISHED'}

    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)




