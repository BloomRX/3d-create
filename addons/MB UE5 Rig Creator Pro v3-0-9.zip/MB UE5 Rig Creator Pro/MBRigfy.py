

import bpy
import math


def boneSetupBody():


    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["rig_deform"]
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2 

    from bpy import context

    obj = context.object

    bpy.ops.object.mode_set(mode='EDIT')

    for bone in obj.data.edit_bones:
        bone.use_connect = False
    
    bpy.ops.object.mode_set(mode='OBJECT')




    ob = bpy.data.objects["rig_deform"]
    armature = ob.data
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    arm = bpy.data.objects['rig_deform']
   
    arm.data.edit_bones['DEF-shoulder.L'].parent = arm.data.edit_bones['DEF-spine.003']
    arm.data.edit_bones['DEF-shoulder.R'].parent = arm.data.edit_bones['DEF-spine.003']
    arm.data.edit_bones['DEF-upper_arm.L'].parent = arm.data.edit_bones['DEF-shoulder.L']
    arm.data.edit_bones['DEF-upper_arm.R'].parent = arm.data.edit_bones['DEF-shoulder.R']
    arm.data.edit_bones['DEF-thigh.L'].parent = arm.data.edit_bones['DEF-spine']
    arm.data.edit_bones['DEF-thigh.R'].parent = arm.data.edit_bones['DEF-spine']


    bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-pelvis.L")
    bonein2 =bpy.data.objects["rig_deform"].data.bones.get("DEF-pelvis.R")
    if  bonein is not None and bonein2 is not None :       
        
        arm.data.edit_bones['DEF-pelvis.L'].parent = arm.data.edit_bones['DEF-spine']
        arm.data.edit_bones['DEF-pelvis.R'].parent = arm.data.edit_bones['DEF-spine']

    bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-breast.L")
    if  bonein is not None :
        arm.data.edit_bones['DEF-breast.L'].parent = arm.data.edit_bones['DEF-spine.003']

    bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-breast.R")
    if  bonein is not None :       
        
        arm.data.edit_bones['DEF-breast.R'].parent = arm.data.edit_bones['DEF-spine.003']


    #Face
    bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-jaw")
    bonein2 =bpy.data.objects["rig_deform"].data.bones.get("DEF-chin")
    if  bonein is not None and bonein2 is not None:

        arm.data.edit_bones['DEF-jaw'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-chin'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-chin.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-nose.004'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-nose.004'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-nose.003'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-nose.002'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-nose.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-nose'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-tongue'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-tongue.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-tongue.002'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-chin.L'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-jaw.L.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-jaw.L'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-temple.L'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-cheek.B.L'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-cheek.B.L.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-nose.L.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-nose.L'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-cheek.T.L.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-cheek.T.L'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.T.L'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-forehead.L.002'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-forehead.L.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-forehead.L'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.T.L.003'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.T.L.002'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.T.L.001'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-brow.B.L.003'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.B.L.002'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.B.L.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.B.L'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-lid.T.L.003'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-lid.T.L.002'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-lid.T.L.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-lid.T.L'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-lid.B.L'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lid.B.L.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lid.B.L.002'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-lid.B.L.003'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-ear.L'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-ear.L.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-ear.L.002'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-ear.L.003'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-ear.L.004'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lip.T.L'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-lip.T.L.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lip.B.L.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lip.B.L'].parent = arm.data.edit_bones['DEF-spine.006']

        # Right

        arm.data.edit_bones['DEF-chin.R'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-jaw.R.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-jaw.R'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-temple.R'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-cheek.B.R'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-cheek.B.R.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-nose.R.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-nose.R'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-cheek.T.R.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-cheek.T.R'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.T.R'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-forehead.R.002'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-forehead.R.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-forehead.R'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.T.R.003'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.T.R.002'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.T.R.001'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-brow.B.R.003'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.B.R.002'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.B.R.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-brow.B.R'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-lid.T.R.003'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-lid.T.R.002'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-lid.T.R.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-lid.T.R'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-lid.B.R'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lid.B.R.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lid.B.R.002'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-lid.B.R.003'].parent = arm.data.edit_bones['DEF-spine.006']


        arm.data.edit_bones['DEF-ear.R'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-ear.R.001'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-ear.R.002'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-ear.R.003'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-ear.R.004'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lip.T.R'].parent = arm.data.edit_bones['DEF-spine.006']
        arm.data.edit_bones['DEF-lip.T.R.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lip.B.R.001'].parent = arm.data.edit_bones['DEF-spine.006']

        arm.data.edit_bones['DEF-lip.B.R'].parent = arm.data.edit_bones['DEF-spine.006']

        #add_new_for_Blender 3 New Face update

        bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-jaw_master")
        if  bonein is not None :


            arm.data.edit_bones['DEF-jaw_master'].parent = arm.data.edit_bones['DEF-spine.006']
            
            arm.data.edit_bones['DEF-teeth.B'].parent = arm.data.edit_bones['DEF-spine.006']

            arm.data.edit_bones['DEF-teeth.T'].parent = arm.data.edit_bones['DEF-spine.006']
            
            arm.data.edit_bones['DEF-eye_master.L'].parent = arm.data.edit_bones['DEF-spine.006']

            arm.data.edit_bones['DEF-eye_master.R'].parent = arm.data.edit_bones['DEF-spine.006']

            arm.data.edit_bones['DEF-eye.L'].parent = arm.data.edit_bones['DEF-spine.006']
            arm.data.edit_bones['DEF-eye.R'].parent = arm.data.edit_bones['DEF-spine.006']

            arm.data.edit_bones['DEF-brow.B.L.004'].parent = arm.data.edit_bones['DEF-spine.006']
            arm.data.edit_bones['DEF-brow.B.R.004'].parent = arm.data.edit_bones['DEF-spine.006']
    
     
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')

def movetolayers():

    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["rig"]
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    
    collections = bpy.context.object.data.collections

    for layer in range(len(collections)):
        collections[layer].is_visible = True


     

    # Add a new armature object to the scene
    bpy.ops.armature.collection_add()

    # Access the collections of the active armature
    collections = bpy.context.object.data.collections

    # Add a new bone collection and name it "ccc"
    new_collection = collections.new(name="RF_FACE_duplicate")

    # Update the active bone collection to the newly created collection
    collections.active = new_collection



    armature = bpy.data.objects['rig']
    bpy.context.view_layer.objects.active = armature
    bpy.ops.object.mode_set(mode='EDIT')

    # Deselect all bones
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')
    # Get the active object
    obj = bpy.context.active_object


    # Loop through all bones in the object
    for bone in obj.data.bones:

        # If the bone name is in the list of bones to delete
        if bone.name in ['DEF-spine.006', 'DEF-nose', 'DEF-nose.001', 
        'DEF-nose.002', 'DEF-nose.003', 'DEF-nose.004', 'DEF-lip.T.L',
        'DEF-lip.T.L.001', 'DEF-lip.B.L', 'DEF-lip.B.L.001', 'DEF-jaw',
        'DEF-chin', 'DEF-chin.001', 'DEF-ear.L', 'DEF-ear.L.001', 
        'DEF-ear.L.002', 'DEF-ear.L.003', 'DEF-ear.L.004', 'DEF-ear.R',
        'DEF-ear.R.001', 'DEF-ear.R.002', 'DEF-ear.R.003', 'DEF-ear.R.004',
            'DEF-lip.T.R', 'DEF-lip.T.R.001', 'DEF-lip.B.R', 'DEF-lip.B.R.001',
            'DEF-brow.B.L', 'DEF-brow.B.L.001', 'DEF-brow.B.L.002', 'DEF-brow.B.L.003',
            'DEF-lid.T.L', 'DEF-lid.T.L.001', 'DEF-lid.T.L.002', 'DEF-lid.T.L.003', 
            'DEF-lid.B.L', 'DEF-lid.B.L.001', 'DEF-lid.B.L.002', 'DEF-lid.B.L.003',
            'DEF-brow.B.R', 'DEF-brow.B.R.001', 'DEF-brow.B.R.002', 'DEF-brow.B.R.003',
                'DEF-lid.T.R', 'DEF-lid.T.R.001', 'DEF-lid.T.R.002', 'DEF-lid.T.R.003',
                'DEF-lid.B.R', 'DEF-lid.B.R.001', 'DEF-lid.B.R.002', 'DEF-lid.B.R.003',
                'DEF-forehead.L', 'DEF-forehead.L.001', 'DEF-forehead.L.002', 'DEF-temple.L',
                'DEF-jaw.L', 'DEF-jaw.L.001', 'DEF-chin.L', 'DEF-cheek.B.L', 'DEF-cheek.B.L.001',
                    'DEF-brow.T.L', 'DEF-brow.T.L.001', 'DEF-brow.T.L.002', 'DEF-brow.T.L.003',
                    'DEF-forehead.R', 'DEF-forehead.R.001', 'DEF-forehead.R.002', 'DEF-temple.R',
                    'DEF-jaw.R', 'DEF-jaw.R.001', 'DEF-chin.R', 'DEF-cheek.B.R', 'DEF-cheek.B.R.001',
                    'DEF-brow.T.R', 'DEF-brow.T.R.001', 'DEF-brow.T.R.002', 'DEF-brow.T.R.003',
                        'DEF-eye.L', 'DEF-eye.R', 'DEF-cheek.T.L', 'DEF-cheek.T.L.001', 'DEF-nose.L',
                        'DEF-nose.L.001', 'DEF-cheek.T.R', 'DEF-cheek.T.R.001', 'DEF-nose.R',
                        'DEF-nose.R.001', 'DEF-teeth.T', 'DEF-teeth.B', 'DEF-tongue', 'DEF-tongue.001'
                        , 'DEF-tongue.002','DEF-brow.B.L.004','DEF-brow.B.R.004']:
            # Select the bone
            bone.select = True
    # Delete the selected bones
    bpy.ops.object.mode_set(mode='EDIT')
    

    bpy.ops.armature.duplicate_move(ARMATURE_OT_duplicate={"do_flip_names":False})

    bpy.ops.object.mode_set(mode='POSE')

    armature = bpy.context.object

    # Check if the active object is an armature
    if armature and armature.type == 'ARMATURE':
        # Select the armature and enter Pose Mode
        bpy.context.view_layer.objects.active = armature
        bpy.ops.object.mode_set(mode='POSE')

        # Loop through all bones in Pose Mode
        for bone in armature.pose.bones:
            if bone.bone.select:  # Check if the bone is selected
                # Set the bone's layer to the desired layer number (Layer 29 in this case)
                bpy.ops.armature.collection_assign()

        bpy.ops.object.mode_set(mode='OBJECT')

        armature = bpy.context.object

        # Check if the active object is an armature
        if armature and armature.type == 'ARMATURE':
            # Select the armature and enter Pose Mode
            bpy.context.view_layer.objects.active = armature
            bpy.ops.object.mode_set(mode='POSE')

            # Loop through all bones in Pose Mode
            for bone in armature.pose.bones:
                if bone.bone.select:  # Check if the bone is selected
                    # Set the bone's layer to the desired layer number (Layer 29 in this case)
                    for con in bone.constraints:
                        bone.constraints.remove(con)

   
        armature = bpy.context.object

        # Check if the active object is an armature
        if armature and armature.type == 'ARMATURE':
            # Select the armature and enter Pose Mode
            bpy.context.view_layer.objects.active = armature
            bpy.ops.object.mode_set(mode='POSE')

            # Loop through all bones in Pose Mode
            for bone in armature.pose.bones:
                if bone.bone.select:  # Check if the bone is selected
                    # Set the bone's layer to the desired layer number (Layer 29 in this case)
                    bone.lock_location[0] = False # x
                    bone.lock_location[1] = False # y
                    bone.lock_location[2] = False # z
                    
                    bone.lock_rotation[0] = False # x
                    bone.lock_rotation[1] = False # y
                    bone.lock_rotation[2] = False # z
                    bone.lock_rotation_w = False # z

            bpy.ops.object.mode_set(mode='OBJECT')


        collections = bpy.context.object.data.collections

        for layer in range(len(collections)):
            collections[layer].is_visible = False





        # Set the layer visibility
        bpy.context.object.data.collections["RF_FACE_duplicate"].is_visible = True
        bpy.ops.object.mode_set(mode='POSE')

        # Select all bones in the specified layer
        

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        bpy.ops.armature.parent_clear(type='CLEAR')
        bpy.ops.object.mode_set(mode='OBJECT')



        collections = bpy.context.object.data.collections

        for layer in range(len(collections)):
            collections[layer].is_visible = True



        # Access the collections of the active armature
        collections = bpy.context.object.data.collections

        # Check if the "ccc" collection exists
        if "RF_FACE_duplicate" in collections:
            # Remove the "ccc" collection
            collections.remove(collections["RF_FACE_duplicate"])
        else:
            print("Collection 'ccc' not found.")


        # Check if the "ccc" collection exists
        if "Bones" in collections:
            # Remove the "ccc" collection
            collections.remove(collections["Bones"])
        else:
            print("Collection 'ccc' not found.")

        bpy.context.object.data.collections["DEF"].is_visible = False
        bpy.context.object.data.collections["MCH"].is_visible = False
        bpy.context.object.data.collections["ORG"].is_visible = False

def setupf():
    ob = bpy.data.objects["rig"]
    armature = ob.data
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    arm = bpy.data.objects["rig"]

    #moth


    arm.data.edit_bones['DEF-nose.007'].parent = arm.data.edit_bones['nose']
    arm.data.edit_bones['DEF-nose.008'].parent = arm.data.edit_bones['nose.001']
    arm.data.edit_bones['DEF-nose.005'].parent = arm.data.edit_bones['nose.002']
    arm.data.edit_bones['DEF-nose.006'].parent = arm.data.edit_bones['nose.003']
    arm.data.edit_bones['DEF-nose.009'].parent = arm.data.edit_bones['nose.004']
    arm.data.edit_bones['DEF-chin.003'].parent = arm.data.edit_bones['chin.001']
    arm.data.edit_bones['DEF-chin.002'].parent = arm.data.edit_bones['chin']
    arm.data.edit_bones['DEF-jaw.001'].parent = arm.data.edit_bones['jaw']







    arm.data.edit_bones['DEF-lip.T.L.002'].parent = arm.data.edit_bones['lip.T']
    arm.data.edit_bones['DEF-lip.T.R.002'].parent = arm.data.edit_bones['lip.T']
    arm.data.edit_bones['DEF-lip.B.L.002'].parent = arm.data.edit_bones['lip.B']
    arm.data.edit_bones['DEF-lip.B.R.002'].parent = arm.data.edit_bones['lip.B']



    arm.data.edit_bones['DEF-lip.T.L.003'].parent = arm.data.edit_bones['lip.T.L.001']
    arm.data.edit_bones['DEF-lip.B.L.003'].parent = arm.data.edit_bones['lip.B.L.001']
    arm.data.edit_bones['DEF-lip.T.R.003'].parent = arm.data.edit_bones['lip.T.R.001']
    arm.data.edit_bones['DEF-lip.B.R.003'].parent = arm.data.edit_bones['lip.B.R.001']

    arm.data.edit_bones['DEF-brow.T.L.007'].parent = arm.data.edit_bones['brow.T.L.003']
    arm.data.edit_bones['DEF-brow.T.L.006'].parent = arm.data.edit_bones['brow.T.L.002']
    arm.data.edit_bones['DEF-brow.T.L.005'].parent = arm.data.edit_bones['brow.T.L.001']
    arm.data.edit_bones['DEF-brow.T.L.004'].parent = arm.data.edit_bones['brow.T.L']
    arm.data.edit_bones['DEF-cheek.T.L.002'].parent = arm.data.edit_bones['brow.T.L']
    arm.data.edit_bones['DEF-cheek.T.L.003'].parent = arm.data.edit_bones['cheek.T.L.001']
    arm.data.edit_bones['DEF-nose.L.003'].parent = arm.data.edit_bones['nose.L']
    arm.data.edit_bones['DEF-nose.L.002'].parent = arm.data.edit_bones['nose.L.001']
    arm.data.edit_bones['DEF-chin.L.001'].parent = arm.data.edit_bones['chin.L']
    arm.data.edit_bones['DEF-jaw.L.003'].parent = arm.data.edit_bones['jaw.L.001']
    


    arm.data.edit_bones['DEF-temple.L.001'].parent = arm.data.edit_bones['temple.L']
    arm.data.edit_bones['DEF-jaw.L.002'].parent = arm.data.edit_bones['jaw.L']
    arm.data.edit_bones['DEF-forehead.L.005'].parent = arm.data.edit_bones['forehead.L.002']
    arm.data.edit_bones['DEF-forehead.L.004'].parent = arm.data.edit_bones['forehead.L.001']
    arm.data.edit_bones['DEF-forehead.L.003'].parent = arm.data.edit_bones['forehead.L']



    arm.data.edit_bones['DEF-brow.B.L.008'].parent = arm.data.edit_bones['brow.B.L.003']
    arm.data.edit_bones['DEF-brow.B.L.007'].parent = arm.data.edit_bones['brow.B.L.002']
    arm.data.edit_bones['DEF-brow.B.L.006'].parent = arm.data.edit_bones['brow.B.L.001']
    arm.data.edit_bones['DEF-brow.B.L.005'].parent = arm.data.edit_bones['brow.B.L']



    arm.data.edit_bones['DEF-lid.T.L.007'].parent = arm.data.edit_bones['lid.T.L.003']
    arm.data.edit_bones['DEF-lid.T.L.006'].parent = arm.data.edit_bones['lid.T.L.002']
    arm.data.edit_bones['DEF-lid.T.L.005'].parent = arm.data.edit_bones['lid.T.L.001']
    arm.data.edit_bones['DEF-lid.T.L.004'].parent = arm.data.edit_bones['lid.T.L']
    arm.data.edit_bones['DEF-lid.B.L.004'].parent = arm.data.edit_bones['lid.B.L']
    arm.data.edit_bones['DEF-lid.B.L.005'].parent = arm.data.edit_bones['lid.B.L.001']
    arm.data.edit_bones['DEF-lid.B.L.006'].parent = arm.data.edit_bones['lid.B.L.002']
    arm.data.edit_bones['DEF-lid.B.L.007'].parent = arm.data.edit_bones['lid.B.L.003']

    #RRRR


    arm.data.edit_bones['DEF-brow.T.R.007'].parent = arm.data.edit_bones['brow.T.R.003']
    arm.data.edit_bones['DEF-brow.T.R.006'].parent = arm.data.edit_bones['brow.T.R.002']
    arm.data.edit_bones['DEF-brow.T.R.005'].parent = arm.data.edit_bones['brow.T.R.001']
    arm.data.edit_bones['DEF-brow.T.R.004'].parent = arm.data.edit_bones['brow.T.R']
    arm.data.edit_bones['DEF-cheek.T.R.002'].parent = arm.data.edit_bones['brow.T.R']
    arm.data.edit_bones['DEF-cheek.T.R.003'].parent = arm.data.edit_bones['cheek.T.R.001']
    arm.data.edit_bones['DEF-nose.R.003'].parent = arm.data.edit_bones['nose.R']
    arm.data.edit_bones['DEF-nose.R.002'].parent = arm.data.edit_bones['nose.R.001']
    arm.data.edit_bones['DEF-chin.R.001'].parent = arm.data.edit_bones['chin.R']
    arm.data.edit_bones['DEF-jaw.R.003'].parent = arm.data.edit_bones['jaw.R.001']
    


    arm.data.edit_bones['DEF-temple.R.001'].parent = arm.data.edit_bones['temple.R']
    arm.data.edit_bones['DEF-jaw.R.002'].parent = arm.data.edit_bones['jaw.R']
    arm.data.edit_bones['DEF-forehead.R.005'].parent = arm.data.edit_bones['forehead.R.002']
    arm.data.edit_bones['DEF-forehead.R.004'].parent = arm.data.edit_bones['forehead.R.001']
    arm.data.edit_bones['DEF-forehead.R.003'].parent = arm.data.edit_bones['forehead.R']



    arm.data.edit_bones['DEF-brow.B.R.008'].parent = arm.data.edit_bones['brow.B.R.003']
    arm.data.edit_bones['DEF-brow.B.R.007'].parent = arm.data.edit_bones['brow.B.R.002']
    arm.data.edit_bones['DEF-brow.B.R.006'].parent = arm.data.edit_bones['brow.B.R.001']
    arm.data.edit_bones['DEF-brow.B.R.005'].parent = arm.data.edit_bones['brow.B.R']



    arm.data.edit_bones['DEF-lid.T.R.007'].parent = arm.data.edit_bones['lid.T.R.003']
    arm.data.edit_bones['DEF-lid.T.R.006'].parent = arm.data.edit_bones['lid.T.R.002']
    arm.data.edit_bones['DEF-lid.T.R.005'].parent = arm.data.edit_bones['lid.T.R.001']
    arm.data.edit_bones['DEF-lid.T.R.004'].parent = arm.data.edit_bones['lid.T.R']
    arm.data.edit_bones['DEF-lid.B.R.004'].parent = arm.data.edit_bones['lid.B.R']
    arm.data.edit_bones['DEF-lid.B.R.005'].parent = arm.data.edit_bones['lid.B.R.001']
    arm.data.edit_bones['DEF-lid.B.R.006'].parent = arm.data.edit_bones['lid.B.R.002']
    arm.data.edit_bones['DEF-lid.B.R.007'].parent = arm.data.edit_bones['lid.B.R.003']



    arm.data.edit_bones['DEF-cheek.B.R.002'].parent = arm.data.edit_bones['lip_end.R.001']
    arm.data.edit_bones['DEF-cheek.B.R.003'].parent = arm.data.edit_bones['cheek.B.R.001']
    arm.data.edit_bones['DEF-nose.R.002'].parent = arm.data.edit_bones['nose.R.001']
    arm.data.edit_bones['DEF-nose.R.003'].parent = arm.data.edit_bones['nose.R']
    arm.data.edit_bones['DEF-temple.R.001'].parent = arm.data.edit_bones['temple.R']
    arm.data.edit_bones['DEF-ear.R.008'].parent = arm.data.edit_bones['ear.R.003']
    arm.data.edit_bones['DEF-ear.R.007'].parent = arm.data.edit_bones['ear.R.002']
    arm.data.edit_bones['DEF-ear.R.006'].parent = arm.data.edit_bones['ear.R.001']
    arm.data.edit_bones['DEF-ear.R.005'].parent = arm.data.edit_bones['ear_end.R.004']
    arm.data.edit_bones['DEF-ear.R.009'].parent = arm.data.edit_bones['ear.R.004']



    arm.data.edit_bones['DEF-cheek.B.L.002'].parent = arm.data.edit_bones['lip_end.L.001']
    arm.data.edit_bones['DEF-cheek.B.L.003'].parent = arm.data.edit_bones['cheek.B.L.001']
    arm.data.edit_bones['DEF-nose.L.002'].parent = arm.data.edit_bones['nose.L.001']
    arm.data.edit_bones['DEF-nose.L.003'].parent = arm.data.edit_bones['nose.L']
    arm.data.edit_bones['DEF-temple.L.001'].parent = arm.data.edit_bones['temple.L']
    arm.data.edit_bones['DEF-ear.L.008'].parent = arm.data.edit_bones['ear.L.003']
    arm.data.edit_bones['DEF-ear.L.007'].parent = arm.data.edit_bones['ear.L.002']
    arm.data.edit_bones['DEF-ear.L.006'].parent = arm.data.edit_bones['ear.L.001']
    arm.data.edit_bones['DEF-ear.L.005'].parent = arm.data.edit_bones['ear_end.L.004']
    arm.data.edit_bones['DEF-ear.L.009'].parent = arm.data.edit_bones['ear.L.004']


    arm.data.edit_bones['DEF-tongue.003'].parent = arm.data.edit_bones['tweak_tongue']
    arm.data.edit_bones['DEF-tongue.004'].parent = arm.data.edit_bones['tweak_tongue.001']
    arm.data.edit_bones['DEF-tongue.005'].parent = arm.data.edit_bones['tweak_tongue.002']

    arm.data.edit_bones['DEF-brow.B.L.009'].parent = arm.data.edit_bones['brow.B.L.004']
    arm.data.edit_bones['DEF-brow.B.R.009'].parent = arm.data.edit_bones['brow.B.R.004']
    
    
    
    
    
    
    
    
    
    
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')

def facenewtransformation():

    armatureFrom = bpy.data.objects['rig']
    armatureTo = bpy.data.objects['MB_RFRig']

    # Specify the names of bones you want to copy
    bones_to_copy = ['DEF-spine.006', 'DEF-nose', 'DEF-nose.001', 
            'DEF-nose.002', 'DEF-nose.003', 'DEF-nose.004', 'DEF-lip.T.L',
            'DEF-lip.T.L.001', 'DEF-lip.B.L', 'DEF-lip.B.L.001', 'DEF-jaw',
            'DEF-chin', 'DEF-chin.001', 'DEF-ear.L', 'DEF-ear.L.001', 
            'DEF-ear.L.002', 'DEF-ear.L.003', 'DEF-ear.L.004', 'DEF-ear.R',
            'DEF-ear.R.001', 'DEF-ear.R.002', 'DEF-ear.R.003', 'DEF-ear.R.004',
                'DEF-lip.T.R', 'DEF-lip.T.R.001', 'DEF-lip.B.R', 'DEF-lip.B.R.001',
                'DEF-brow.B.L', 'DEF-brow.B.L.001', 'DEF-brow.B.L.002', 'DEF-brow.B.L.003',
                'DEF-lid.T.L', 'DEF-lid.T.L.001', 'DEF-lid.T.L.002', 'DEF-lid.T.L.003', 
                'DEF-lid.B.L', 'DEF-lid.B.L.001', 'DEF-lid.B.L.002', 'DEF-lid.B.L.003',
                'DEF-brow.B.R', 'DEF-brow.B.R.001', 'DEF-brow.B.R.002', 'DEF-brow.B.R.003',
                    'DEF-lid.T.R', 'DEF-lid.T.R.001', 'DEF-lid.T.R.002', 'DEF-lid.T.R.003',
                    'DEF-lid.B.R', 'DEF-lid.B.R.001', 'DEF-lid.B.R.002', 'DEF-lid.B.R.003',
                    'DEF-forehead.L', 'DEF-forehead.L.001', 'DEF-forehead.L.002', 'DEF-temple.L',
                    'DEF-jaw.L', 'DEF-jaw.L.001', 'DEF-chin.L', 'DEF-cheek.B.L', 'DEF-cheek.B.L.001',
                        'DEF-brow.T.L', 'DEF-brow.T.L.001', 'DEF-brow.T.L.002', 'DEF-brow.T.L.003',
                        'DEF-forehead.R', 'DEF-forehead.R.001', 'DEF-forehead.R.002', 'DEF-temple.R',
                        'DEF-jaw.R', 'DEF-jaw.R.001', 'DEF-chin.R', 'DEF-cheek.B.R', 'DEF-cheek.B.R.001',
                        'DEF-brow.T.R', 'DEF-brow.T.R.001', 'DEF-brow.T.R.002', 'DEF-brow.T.R.003',
                            'DEF-eye.L', 'DEF-eye.R', 'DEF-cheek.T.L', 'DEF-cheek.T.L.001', 'DEF-nose.L',
                            'DEF-nose.L.001', 'DEF-cheek.T.R', 'DEF-cheek.T.R.001', 'DEF-nose.R',
                            'DEF-nose.R.001', 'DEF-teeth.T', 'DEF-teeth.B', 'DEF-tongue', 'DEF-tongue.001'
                            , 'DEF-tongue.002','DEF-brow.B.L.004','DEF-brow.B.R.004']

    for bone_name in bones_to_copy:
        boneTo = armatureTo.pose.bones.get(bone_name)
        
        if boneTo is not None:
            boneFrom = armatureFrom.pose.bones.get(bone_name)

            # Check if the corresponding bone exists in the source armature
            if boneFrom is not None:
                # Remove existing constraints on the destination bone
                for con in boneTo.constraints:
                    boneTo.constraints.remove(con)

                # Add a new 'COPY_TRANSFORMS' constraint to copy transforms
                copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
                copy_con.target = armatureFrom
                copy_con.subtarget = boneFrom.name

def newrota():
    # Replace "MB_RFRig" with the actual name of your armature object
    armature = bpy.data.objects["MB_RFRig"]
    # Define the bone pairs where the first bone is the bone name and the second bone is the target bone name
    bone_pairs = [
        ("DEF-cheek.T.L", "DEF-cheek.T.L.002"),
        ("DEF-cheek.T.L.001", "DEF-cheek.T.L.003"),
        ("DEF-nose.L", "DEF-nose.L.003"),
        ("DEF-nose.L.001", "DEF-nose.L.002"),
        ("DEF-lip.T.L", "DEF-lip.T.L.002"),
        ("DEF-lip.T.L.001", "DEF-lip.T.L.003"),
        ("DEF-lip.B.L", "DEF-lip.B.L.002"),
        ("DEF-lip.B.L.001", "DEF-lip.B.L.003"),
        ("DEF-cheek.B.L", "DEF-cheek.B.L.002"),
        ("DEF-cheek.B.L.001", "DEF-cheek.B.L.003"),
        ("DEF-brow.T.L", "DEF-brow.T.L.004"),
        ("DEF-brow.T.L.001", "DEF-brow.T.L.005"),
        ("DEF-brow.T.L.002", "DEF-brow.T.L.006"),
        ("DEF-brow.T.L.003", "DEF-brow.T.L.007"),
        ("DEF-brow.B.L", "DEF-brow.B.L.005"),
        ("DEF-brow.B.L.001", "DEF-brow.B.L.006"),
        ("DEF-brow.B.L.002", "DEF-brow.B.L.007"),
        ("DEF-brow.B.L.003", "DEF-brow.B.L.008"),
        ("DEF-brow.B.L.004", "DEF-brow.B.L.009"),
        ("DEF-lid.T.L", "DEF-lid.T.L.004"),
        ("DEF-lid.T.L.001", "DEF-lid.T.L.005"),
        ("DEF-lid.T.L.002", "DEF-lid.T.L.006"),
        ("DEF-lid.T.L.003", "DEF-lid.T.L.007"),
        ("DEF-lid.B.L", "DEF-lid.B.L.004"),
        ("DEF-lid.B.L.001", "DEF-lid.B.L.005"),
        ("DEF-lid.B.L.002", "DEF-lid.B.L.006"),
        ("DEF-lid.B.L.003", "DEF-lid.B.L.007"),
        ("DEF-chin.L", "DEF-chin.L.001"),
        ("DEF-jaw.L.001", "DEF-jaw.L.003"),
        ("DEF-jaw.L", "DEF-jaw.L.002"),
        ("DEF-temple.L", "DEF-temple.L.001"),
        ("DEF-ear.L.003", "DEF-ear.L.008"),
        ("DEF-ear.L.002", "DEF-ear.L.007"),
        ("DEF-ear.L.001", "DEF-ear.L.006"),
        ("DEF-ear.L", "DEF-ear.L.005"),
        ("DEF-ear.L.004", "DEF-ear.L.009"),
        ("DEF-forehead.L.002", "DEF-forehead.L.005"),
        ("DEF-forehead.L.001", "DEF-forehead.L.004"),
        ("DEF-forehead.L", "DEF-forehead.L.003"),
        ("DEF-nose", "DEF-nose.007"),
        ("DEF-nose.001", "DEF-nose.008"),
        ("DEF-nose.002", "DEF-nose.005"),
        ("DEF-nose.003", "DEF-nose.006"),
        ("DEF-nose.004", "DEF-nose.009"),
        ("DEF-chin.001", "DEF-chin.003"),
        ("DEF-chin", "DEF-chin.002"),
        ("DEF-jaw", "DEF-jaw.001"),
        ("DEF-cheek.T.R", "DEF-cheek.T.R.002"),
        ("DEF-cheek.T.R.001", "DEF-cheek.T.R.003"),
        ("DEF-nose.R", "DEF-nose.R.003"),
        ("DEF-nose.R.001", "DEF-nose.R.002"),
        ("DEF-lip.T.R", "DEF-lip.T.R.002"),
        ("DEF-lip.T.R.001", "DEF-lip.T.R.003"),
        ("DEF-lip.B.R", "DEF-lip.B.R.002"),
        ("DEF-lip.B.R.001", "DEF-lip.B.R.003"),
        ("DEF-cheek.B.R", "DEF-cheek.B.R.002"),
        ("DEF-cheek.B.R.001", "DEF-cheek.B.R.003"),
        ("DEF-brow.T.R", "DEF-brow.T.R.004"),
        ("DEF-brow.T.R.001", "DEF-brow.T.R.005"),
        ("DEF-brow.T.R.002", "DEF-brow.T.R.006"),
        ("DEF-brow.T.R.003", "DEF-brow.T.R.007"),
        ("DEF-brow.B.R", "DEF-brow.B.R.005"),
        ("DEF-brow.B.R.001", "DEF-brow.B.R.006"),
        ("DEF-brow.B.R.002", "DEF-brow.B.R.007"),
        ("DEF-brow.B.R.003", "DEF-brow.B.R.008"),
        ("DEF-brow.B.R.004", "DEF-brow.B.R.009"),
        ("DEF-lid.T.R", "DEF-lid.T.R.004"),
        ("DEF-lid.T.R.001", "DEF-lid.T.R.005"),
        ("DEF-lid.T.R.002", "DEF-lid.T.R.006"),
        ("DEF-lid.T.R.003", "DEF-lid.T.R.007"),
        ("DEF-lid.B.R", "DEF-lid.B.R.004"),
        ("DEF-lid.B.R.001", "DEF-lid.B.R.005"),
        ("DEF-lid.B.R.002", "DEF-lid.B.R.006"),
        ("DEF-lid.B.R.003", "DEF-lid.B.R.007"),
        ("DEF-chin.R", "DEF-chin.R.001"),
        ("DEF-jaw.R.001", "DEF-jaw.R.003"),
        ("DEF-jaw.R", "DEF-jaw.R.002"),
        ("DEF-temple.R", "DEF-temple.R.001"),
        ("DEF-ear.R.003", "DEF-ear.R.008"),
        ("DEF-ear.R.002", "DEF-ear.R.007"),
        ("DEF-ear.R.001", "DEF-ear.R.006"),
        ("DEF-ear.R", "DEF-ear.R.005"),
        ("DEF-ear.R.004", "DEF-ear.R.009"),
        ("DEF-forehead.R.002", "DEF-forehead.R.005"),
        ("DEF-forehead.R.001", "DEF-forehead.R.004"),
        ("DEF-forehead.R", "DEF-forehead.R.003"),
        ("DEF-nose", "DEF-nose.007"),
        ("DEF-nose.001", "DEF-nose.008"),
        ("DEF-nose.002", "DEF-nose.005"),
        ("DEF-nose.003", "DEF-nose.006"),
        ("DEF-nose.004", "DEF-nose.009"),
        ("DEF-chin.001", "DEF-chin.003"),
        ("DEF-chin", "DEF-chin.002"),
        ("DEF-jaw", "DEF-jaw.001"),
    ]

    # Loop through each bone pair and set the subtarget for the "Copy Rotation" constraint
    for bone_name, target_bone_name in bone_pairs:
        if bone_name in armature.pose.bones:
            bone = armature.pose.bones[bone_name]
            constraint = bone.constraints.get("Copy Rotation")
            if constraint:
                constraint.subtarget = target_bone_name

def adddumb():
    armature_name = "MB_RFRig"
    upperarm_l_bone_name = "DEF-lip.T.L"
    upperarm_twist_01_l_bone_name = "DEF-lip.T.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'

    


    upperarm_l_bone_name = "DEF-lip.T.R"
    upperarm_twist_01_l_bone_name = "DEF-lip.T.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'



    upperarm_l_bone_name = "DEF-lip.T.L.001"
    upperarm_twist_01_l_bone_name = "DEF-cheek.B.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'

    upperarm_l_bone_name = "DEF-lip.T.R.001"
    upperarm_twist_01_l_bone_name = "DEF-cheek.B.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        
        
        
        
    upperarm_l_bone_name = "DEF-lip.B.L"
    upperarm_twist_01_l_bone_name = "DEF-lip.B.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'    
        
        
        
    upperarm_l_bone_name = "DEF-lip.B.R"
    upperarm_twist_01_l_bone_name = "DEF-lip.B.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     
        
        
        
    upperarm_l_bone_name = "DEF-lip.B.L.001"
    upperarm_twist_01_l_bone_name = "DEF-cheek.B.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'        
        
        
    upperarm_l_bone_name = "DEF-lip.B.R.001"
    upperarm_twist_01_l_bone_name = "DEF-cheek.B.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'       



    
    #eyes #eyes #eyes #eyes #eyes
    #eyes #eyes #eyes #eyes #eyes
    #eyes #eyes #eyes #eyes #eyes
    #eyes #eyes #eyes #eyes #eyes
    upperarm_l_bone_name = "DEF-lid.T.L"
    upperarm_twist_01_l_bone_name = "DEF-lid.T.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'

    
    upperarm_l_bone_name = "DEF-lid.T.L.001"
    upperarm_twist_01_l_bone_name = "DEF-lid.T.L.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        





    upperarm_l_bone_name = "DEF-lid.T.L.002"
    upperarm_twist_01_l_bone_name = "DEF-lid.T.L.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'    
        
        
    upperarm_l_bone_name = "DEF-lid.T.L.003"
    upperarm_twist_01_l_bone_name = "DEF-lid.B.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'    
        
        
        
    upperarm_l_bone_name = "DEF-lid.B.L"
    upperarm_twist_01_l_bone_name = "DEF-lid.B.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     
        
        
        
    upperarm_l_bone_name = "DEF-lid.B.L.001"
    upperarm_twist_01_l_bone_name = "DEF-lid.B.L.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     
            
        
        
    upperarm_l_bone_name = "DEF-lid.B.L.002"
    upperarm_twist_01_l_bone_name = "DEF-lid.B.L.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'       
        


    upperarm_l_bone_name = "DEF-lid.B.L.003"
    upperarm_twist_01_l_bone_name = "DEF-lid.T.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 
        
        
        
        
        
        
    upperarm_l_bone_name = "DEF-lid.T.R"
    upperarm_twist_01_l_bone_name = "DEF-lid.T.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'

    
    upperarm_l_bone_name = "DEF-lid.T.R.001"
    upperarm_twist_01_l_bone_name = "DEF-lid.T.R.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        





    upperarm_l_bone_name = "DEF-lid.T.R.002"
    upperarm_twist_01_l_bone_name = "DEF-lid.T.R.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'    
        
        
    upperarm_l_bone_name = "DEF-lid.T.R.003"
    upperarm_twist_01_l_bone_name = "DEF-lid.B.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'    
        
        
        
    upperarm_l_bone_name = "DEF-lid.B.R"
    upperarm_twist_01_l_bone_name = "DEF-lid.B.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     
        
        
        
    upperarm_l_bone_name = "DEF-lid.B.R.001"
    upperarm_twist_01_l_bone_name = "DEF-lid.B.R.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     
            
        
        
    upperarm_l_bone_name = "DEF-lid.B.R.002"
    upperarm_twist_01_l_bone_name = "DEF-lid.B.R.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'       
        


    upperarm_l_bone_name = "DEF-lid.B.R.003"
    upperarm_twist_01_l_bone_name = "DEF-lid.T.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'   





    #/////////////////////////////////////
    
   
    upperarm_l_bone_name = "DEF-brow.B.L"
    upperarm_twist_01_l_bone_name = "DEF-brow.B.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'

    

    upperarm_l_bone_name = "DEF-brow.B.L.002"
    upperarm_twist_01_l_bone_name = "DEF-brow.B.L.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        
        
        
        
    upperarm_l_bone_name = "DEF-brow.B.L.003"
    upperarm_twist_01_l_bone_name = "DEF-brow.B.L.004"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'    
        
        
        
        
    upperarm_l_bone_name = "DEF-brow.B.L.004"
    upperarm_twist_01_l_bone_name = "DEF-nose.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'       
        
        
        
    upperarm_l_bone_name = "DEF-brow.T.L"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'         
        



    upperarm_l_bone_name = "DEF-brow.T.L.001"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.L.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'   
        
        
        
        
    upperarm_l_bone_name = "DEF-brow.T.L.002"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.L.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     
        
        
        
        
    upperarm_l_bone_name = "DEF-brow.T.L.003"
    upperarm_twist_01_l_bone_name = "DEF-nose"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     
            
        
        
        
    upperarm_l_bone_name = "DEF-brow.B.R"
    upperarm_twist_01_l_bone_name = "DEF-brow.B.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'

    

    upperarm_l_bone_name = "DEF-brow.B.R.002"
    upperarm_twist_01_l_bone_name = "DEF-brow.B.R.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        
        
        
        
    upperarm_l_bone_name = "DEF-brow.B.R.003"
    upperarm_twist_01_l_bone_name = "DEF-brow.B.R.004"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'    
        
        
        
        
    upperarm_l_bone_name = "DEF-brow.B.R.004"
    upperarm_twist_01_l_bone_name = "DEF-nose.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'       
        
        
        
    upperarm_l_bone_name = "DEF-brow.T.R"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'         
        



    upperarm_l_bone_name = "DEF-brow.T.R.001"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.R.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'   
        
        
        
        
    upperarm_l_bone_name = "DEF-brow.T.R.002"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.R.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     
        
        
        
        
    upperarm_l_bone_name = "DEF-brow.T.R.003"
    upperarm_twist_01_l_bone_name = "DEF-nose"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'           
        
        
        
        


    upperarm_l_bone_name = "DEF-tongue"
    upperarm_twist_01_l_bone_name = "DEF-tongue.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'        
        
        
    upperarm_l_bone_name = "DEF-tongue.001"
    upperarm_twist_01_l_bone_name = "DEF-tongue.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'           
      
      
      
    #////////////////////////

    armature_name = "MB_RFRig"
    upperarm_l_bone_name = "DEF-cheek.B.L"
    upperarm_twist_01_l_bone_name = "DEF-cheek.B.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        
        
        
    
    
    upperarm_l_bone_name = "DEF-cheek.B.L.001"
    upperarm_twist_01_l_bone_name = "DEF-cheek.T.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'        
        
        

    
    upperarm_l_bone_name = "DEF-cheek.T.L.001"
    upperarm_twist_01_l_bone_name = "DEF-nose.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     




    upperarm_l_bone_name = "DEF-cheek.T.L"
    upperarm_twist_01_l_bone_name = "DEF-cheek.T.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 



    upperarm_l_bone_name = "DEF-jaw.L"
    upperarm_twist_01_l_bone_name = "DEF-jaw.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 




    upperarm_l_bone_name = "DEF-nose.L"
    upperarm_twist_01_l_bone_name = "DEF-nose.L.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 


    
    upperarm_l_bone_name = "DEF-nose.L.001"
    upperarm_twist_01_l_bone_name = "DEF-nose.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 


    #//////////////

    armature_name = "MB_RFRig"
    upperarm_l_bone_name = "DEF-cheek.B.R"
    upperarm_twist_01_l_bone_name = "DEF-cheek.B.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        
        
        
    
    
    upperarm_l_bone_name = "DEF-cheek.B.R.001"
    upperarm_twist_01_l_bone_name = "DEF-cheek.T.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'        
        
        

    
    upperarm_l_bone_name = "DEF-cheek.T.R.001"
    upperarm_twist_01_l_bone_name = "DEF-nose.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'     




    upperarm_l_bone_name = "DEF-cheek.T.R"
    upperarm_twist_01_l_bone_name = "DEF-cheek.T.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 



    upperarm_l_bone_name = "DEF-jaw.R"
    upperarm_twist_01_l_bone_name = "DEF-jaw.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 




    upperarm_l_bone_name = "DEF-nose.R"
    upperarm_twist_01_l_bone_name = "DEF-nose.R.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 


    
    upperarm_l_bone_name = "DEF-nose.R.001"
    upperarm_twist_01_l_bone_name = "DEF-nose.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'


    upperarm_l_bone_name = "DEF-jaw.L.001"
    upperarm_twist_01_l_bone_name = "DEF-chin.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        
        
        
     
    upperarm_l_bone_name = "DEF-jaw.R.001"
    upperarm_twist_01_l_bone_name = "DEF-chin.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'  




    upperarm_l_bone_name = "DEF-chin.L"
    upperarm_twist_01_l_bone_name = "DEF-cheek.B.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
        
        
        
     
    upperarm_l_bone_name = "DEF-chin.R"
    upperarm_twist_01_l_bone_name = "DEF-cheek.B.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'   



    upperarm_l_bone_name = "DEF-jaw"
    upperarm_twist_01_l_bone_name = "DEF-chin"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'


    upperarm_l_bone_name = "DEF-temple.L"
    upperarm_twist_01_l_bone_name = "DEF-jaw.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
    
    
    upperarm_l_bone_name = "DEF-temple.R"
    upperarm_twist_01_l_bone_name = "DEF-jaw.R"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'   
      
    
    
     
    upperarm_l_bone_name = "DEF-forehead.L.002"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.L.001"
    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 

    
    
    upperarm_l_bone_name = "DEF-forehead.R.002"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.R.001"
    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 
    
    
    upperarm_l_bone_name = "DEF-forehead.L.001"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.L.002"
    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 
    
    
    
    
    upperarm_l_bone_name = "DEF-forehead.R.001"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.R.002"
    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 
    
    
    
    
    upperarm_l_bone_name = "DEF-forehead.L"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.L.003"
    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y' 
    
    
    
    upperarm_l_bone_name = "DEF-forehead.R"
    upperarm_twist_01_l_bone_name = "DEF-brow.T.R.003"
    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'



    armature_name = "MB_RFRig"
    upperarm_l_bone_name = "DEF-nose"
    upperarm_twist_01_l_bone_name = "DEF-nose.001"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
    
    
    
    
    
    upperarm_l_bone_name = "DEF-nose.001"
    upperarm_twist_01_l_bone_name = "DEF-nose.002"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
    
    
    
    upperarm_l_bone_name = "DEF-nose.002"
    upperarm_twist_01_l_bone_name = "DEF-nose.003"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
    
    
    
    
    
    upperarm_l_bone_name = "DEF-nose.003"
    upperarm_twist_01_l_bone_name = "DEF-nose.004"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
    
    
    upperarm_l_bone_name = "DEF-nose.003"
    upperarm_twist_01_l_bone_name = "DEF-nose.004"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'
    
    
    
    upperarm_l_bone_name = "DEF-nose.004"
    upperarm_twist_01_l_bone_name = "DEF-lip.T.L"

    # Get the armature object
    armature_obj = bpy.data.objects[armature_name]

    # Get the pose object
    pose_obj = armature_obj.pose

    # Get the pose bones
    upperarm_l_bone = pose_obj.bones.get(upperarm_l_bone_name)
    upperarm_twist_01_l_bone = pose_obj.bones.get(upperarm_twist_01_l_bone_name)

    if upperarm_l_bone and upperarm_twist_01_l_bone:
        # Create the "Damped Track" constraint
        constraint = upperarm_l_bone.constraints.new('DAMPED_TRACK')

        # Set the target bone
        constraint.target = armature_obj
        constraint.subtarget = upperarm_twist_01_l_bone_name

        # Set the track axis
        constraint.track_axis = 'TRACK_Y'

def Deletunbones():
    
    
    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect = bpy.data.objects["MB_RFRig"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.editmode_toggle()
    
    
    bpy.context.object.data.collections["Face"].is_visible = False
    bpy.context.object.data.collections["Face (Primary)"].is_visible = False
    bpy.context.object.data.collections["Face (Secondary)"].is_visible = False
    bpy.context.object.data.collections["Torso"].is_visible = False
    bpy.context.object.data.collections["Torso (Tweak)"].is_visible = False
    bpy.context.object.data.collections["Fingers"].is_visible = False
    bpy.context.object.data.collections["Fingers (Detail)"].is_visible = False
    bpy.context.object.data.collections["Arm.L (IK)"].is_visible = False
    bpy.context.object.data.collections["Arm.L (FK)"].is_visible = False
    bpy.context.object.data.collections["Arm.L (Tweak)"].is_visible = False
    bpy.context.object.data.collections["Arm.R (IK)"].is_visible = False
    bpy.context.object.data.collections["Arm.R (FK)"].is_visible = False
    bpy.context.object.data.collections["Arm.R (Tweak)"].is_visible = False
    bpy.context.object.data.collections["Leg.L (IK)"].is_visible = False
    bpy.context.object.data.collections["Leg.L (FK)"].is_visible = False
    bpy.context.object.data.collections["Leg.L (Tweak)"].is_visible = False
    bpy.context.object.data.collections["Leg.R (IK)"].is_visible = False
    bpy.context.object.data.collections["Leg.R (FK)"].is_visible = False
    bpy.context.object.data.collections["Leg.R (Tweak)"].is_visible = False
    bpy.context.object.data.collections["Root"].is_visible = False
    bpy.context.object.data.collections["ORG"].is_visible = False
    bpy.context.object.data.collections["MCH"].is_visible = False
    bpy.ops.armature.select_all(action='SELECT')


    bpy.context.object.data.collections["MCH"].is_visible = True
    bpy.context.object.data.collections["ORG"].is_visible = True
    bpy.context.object.data.collections["Root"].is_visible = True
    bpy.context.object.data.collections["Leg.R (Tweak)"].is_visible = True
    bpy.context.object.data.collections["Leg.R (FK)"].is_visible = True
    bpy.context.object.data.collections["Leg.R (IK)"].is_visible = True
    bpy.context.object.data.collections["Leg.L (Tweak)"].is_visible = True
    bpy.context.object.data.collections["Leg.L (FK)"].is_visible = True
    bpy.context.object.data.collections["Leg.L (IK)"].is_visible = True
    bpy.context.object.data.collections["Arm.R (Tweak)"].is_visible = True
    bpy.context.object.data.collections["Arm.R (FK)"].is_visible = True
    bpy.context.object.data.collections["Arm.R (IK)"].is_visible = True
    bpy.context.object.data.collections["Arm.L (Tweak)"].is_visible = True
    bpy.context.object.data.collections["Arm.L (FK)"].is_visible = True
    bpy.context.object.data.collections["Arm.L (IK)"].is_visible = True
    bpy.context.object.data.collections["Fingers (Detail)"].is_visible = True
    bpy.context.object.data.collections["Fingers"].is_visible = True
    bpy.context.object.data.collections["Torso (Tweak)"].is_visible = True
    bpy.context.object.data.collections["Torso"].is_visible = True
    bpy.context.object.data.collections["Face (Secondary)"].is_visible = True
    bpy.context.object.data.collections["Face (Primary)"].is_visible = True
    bpy.context.object.data.collections["Face"].is_visible = True

    bpy.ops.armature.select_all(action='INVERT')
    bpy.ops.armature.delete()

    bpy.ops.object.mode_set(mode='OBJECT')


    bpy.ops.armature.collection_remove_unused()

 

     

class MB_OT_Op(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Create Rig"
    bl_idname = "mb.op"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        sce = context.scene
        scene = context.scene
        mytool = scene.my_tool
        objects = bpy.context.scene.objects.keys()
        if not 'rig_deform' in objects and sce.Armature_Target !="" :

            bpy.context.scene.tool_settings.use_keyframe_insert_auto = False

            #show all hide
            for ob in bpy.context.scene.objects:
                if ob.type=='MESH':
                    ob.hide_viewport = False
                    ob.hide_select = False


            bpy.ops.object.select_all(action='DESELECT')

            rig = bpy.data.objects[sce.Armature_Target]
            for obj in bpy.data.objects:
                if (obj.type == 'MESH' and
                    rig in [m.object for m in obj.modifiers if m.type == 'ARMATURE']
                    ):
                    #bpy.ops.object.parent_clear(type='CLEAR')
                    obj.select_set(obj.type == "MESH") 
                    pass        

            for obj in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = obj
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE':
                    
                        modifier.name ='Armature'


            

            ##Rest in pose mode
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.posemode_toggle()
            bpy.ops.pose.select_all(action='SELECT')
            bpy.ops.pose.rot_clear()
            bpy.ops.pose.loc_clear()
            bpy.ops.pose.scale_clear()
            bpy.ops.object.mode_set(mode='OBJECT')


           
            
            #duplicate rig
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            
            bpy.ops.object.duplicate()
           
            #Select
            bpy.context.active_object.name = 'new_rig'
            
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["new_rig"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            #show all bone layers for delete except layer 29 the rig and layer 28 the  root

            if mytool.my_string62 !=False :
            
            
                #New NewNew
                # Get the armature object
                arm = bpy.data.objects['new_rig']
                bpy.ops.object.editmode_toggle()

                for bone in arm.data.edit_bones:
                    # Skip bones without parents or non-deform bones
                    if bone.parent is None or not bone.use_deform:
                        continue
                    # Check if the parent bone's name starts with "ORG-"
                    if not bone.parent.name.startswith("ORG-"):
                        continue
                    # Get the name of the parent bone
                    r = bone.parent.name
                    # Remove the first four characters from the name
                    r = r[4:]
                    # Add the string "DEF-" to the beginning of the name
                    r = "DEF-" + r
                    # Check if the edit bone with the modified name exists
                    if r not in arm.data.edit_bones:
                        continue
                    # Reassign the parent of the bone
                    bone.parent = arm.data.edit_bones[r]

                bpy.ops.object.mode_set(mode='OBJECT')









            collections = bpy.context.object.data.collections

            for layer in range(len(collections)):
                collections[layer].is_visible = True
            
             

            
            
            bpy.ops.object.editmode_toggle()
           


            #delete Unselected Bones
            ob = bpy.context.object
            assert ob.type == 'ARMATURE'
            arma = ob.data
            bpy.ops.object.mode_set(mode='EDIT') # ensure edit mode
            bpy.ops.armature.select_all(action='DESELECT')
            bone = arma.edit_bones['VIS_upper_arm_ik_pole.L']
            arma.edit_bones.remove(bone)
            bone = arma.edit_bones['VIS_upper_arm_ik_pole.R']
            arma.edit_bones.remove(bone)
            bone = arma.edit_bones['VIS_thigh_ik_pole.R']
            arma.edit_bones.remove(bone)
            bone = arma.edit_bones['VIS_thigh_ik_pole.L']
            arma.edit_bones.remove(bone)

            



            
             

            #select old rig and name it to rig
            bpy.ops.object.editmode_toggle()
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            


            # Get the active object
            active_object = bpy.context.active_object

                 
            active_object.name = "rig"
            active_object.data.name = "rig"


            active_object = bpy.context.active_object

                 
            active_object.name = "rig"
            active_object.data.name = "rig"


            #select the new rig and name  it to rig_deform   
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["new_rig"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            objectToSelect2 = bpy.data.objects["new_rig"].name = "rig_deform"


            #Unhide
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["rig"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.context.object.hide_viewport = False
            bpy.context.object.hide_render = False
            bpy.context.object.hide_set(False)
            bpy.context.object.hide_select = False




            #Get Anim

            armatureFrom = bpy.data.objects['rig']
            armatureTo = bpy.data.objects['rig_deform']

            for boneTo in armatureTo.pose.bones:
                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                if boneFrom == None:
                    continue

                for con in boneTo.constraints:
                    boneTo.constraints.remove(con)
                copy_con = boneTo.constraints.new('COPY_ROTATION')
                copy_con.target = armatureFrom
                copy_con.subtarget = boneFrom.name
                copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                copy_con2.target = armatureFrom
                copy_con2.subtarget = boneFrom.name


                copy_con3 = boneTo.constraints.new('COPY_SCALE')
                copy_con3.target = armatureFrom
                copy_con3.subtarget = boneFrom.name
                copy_con3.target_space = 'LOCAL'
                copy_con3.owner_space = 'LOCAL'
                        

            


            if mytool.my_string58 ==False :

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["rig_deform"]
                objectToSelect2.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect2

                armature = bpy.data.objects['rig_deform']
                # List of bone names to remove constraints from
                bone_names = ['DEF-thigh.R', 'DEF-thigh.L','DEF-thigh.L.001','DEF-shin.L','DEF-shin.L.001','DEF-foot.L','DEF-thigh.R.001','DEF-shin.R'
                ,'DEF-shin.R.001','DEF-foot.R','DEF-toe.R','DEF-toe.L','DEF-spine','DEF-spine.001','DEF-spine.002'
                ,'DEF-spine.002','DEF-spine.003','DEF-spine.004','DEF-spine.005','DEF-spine.006'
                ,'DEF-shoulder.L','DEF-upper_arm.L','DEF-upper_arm.L.001','DEF-forearm.L','DEF-forearm.L.001','DEF-hand.L'
                ,'DEF-shoulder.R','DEF-upper_arm.R','DEF-upper_arm.R.001','DEF-forearm.R','DEF-forearm.R.001','DEF-hand.R'
                 ]
                
                # Loop through the bone names
                for bone_name in bone_names:
                    # Get the bone
                    bone = armature.pose.bones[bone_name]
                    # Remove the scale constraint from the bone
                    for constraint in bone.constraints:
                        if constraint.type == 'COPY_SCALE':
                            bone.constraints.remove(constraint)



                
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-breast.R")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-breast.R']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)



                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-pelvis.L")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-pelvis.L']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)






                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-palm.01.R")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-palm.01.R','DEF-f_index.01.R','DEF-f_index.02.R','DEF-f_index.03.R']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)




                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-palm.02.R")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-palm.02.R','DEF-f_middle.01.R','DEF-f_middle.02.R','DEF-f_middle.03.R']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)







                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-palm.03.R")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-palm.03.R','DEF-f_ring.01.R','DEF-f_ring.02.R','DEF-f_ring.03.R']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)









                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-palm.04.R")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-palm.04.R','DEF-f_pinky.01.R','DEF-f_pinky.02.R','DEF-f_pinky.03.R']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)



                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-thumb.01.R")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-thumb.01.R','DEF-thumb.02.R','DEF-thumb.03.R']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)

                


                ##RRR

                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-palm.01.L")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-palm.01.L','DEF-f_index.01.L','DEF-f_index.02.L','DEF-f_index.03.L']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)




                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-palm.02.L")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-palm.02.L','DEF-f_middle.01.L','DEF-f_middle.02.L','DEF-f_middle.03.L']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)







                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-palm.03.L")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-palm.03.L','DEF-f_ring.01.L','DEF-f_ring.02.L','DEF-f_ring.03.L']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)









                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-palm.04.L")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-palm.04.L','DEF-f_pinky.01.L','DEF-f_pinky.02.L','DEF-f_pinky.03.L']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)



                #fingers
                bonein =bpy.data.objects["rig_deform"].data.bones.get("DEF-thumb.01.L")
                if  bonein is not None :   
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    armature = bpy.data.objects['rig_deform']
                    # List of bone names to remove constraints from
                    bone_names = ['DEF-thumb.01.L','DEF-thumb.02.L','DEF-thumb.03.L']
                    # Loop through the bone names
                    for bone_name in bone_names:
                        # Get the bone
                        bone = armature.pose.bones[bone_name]
                        # Remove the scale constraint from the bone
                        for constraint in bone.constraints:
                            if constraint.type == 'COPY_SCALE':
                                bone.constraints.remove(constraint)




            # armatureFrom = bpy.data.objects['rig']
            # armatureTo = bpy.data.objects['rig_deform']

            # for boneTo in armatureTo.pose.bones:
            #     boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            #     if boneFrom == None:
            #         continue

            #     for con in boneTo.constraints:
            #         boneTo.constraints.remove(con)

            #     copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
            #     copy_con.target = armatureFrom
            #     copy_con.subtarget = boneFrom.name
            
            
            
            
            
            
            boneSetupBody()     


            
            

            ###meshSetup
            bpy.ops.object.select_all(action='DESELECT')

            rig = bpy.data.objects["rig"]
            for obj in bpy.data.objects:
                if (obj.type == 'MESH' and
                    rig in [m.object for m in obj.modifiers if m.type == 'ARMATURE']
                    ):
                    #bpy.ops.object.parent_clear(type='CLEAR')
                    obj.select_set(obj.type == "MESH") 
                    pass        

            for obj in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = obj
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE':
                        obj.modifiers["Armature"].object = None
                        obj.modifiers["Armature"].object = bpy.data.objects["rig_deform"]


            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["rig_deform"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            

            

            
                
                
            # clear parent
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["rig"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            for obj in bpy.data.objects:
                if obj.parent == rig:
                    obj.select_set(obj.type == "MESH")
                    bpy.ops.object.parent_clear(type='CLEAR')
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_deform"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2      
                
                
                    
                
            
            
            ###pairntSetup
            bpy.ops.object.select_all(action='DESELECT')
           
            rig = bpy.data.objects["rig_deform"]
            for obj in bpy.data.objects:
                if (obj.type == 'MESH' and
                    rig in [m.object for m in obj.modifiers if m.type == 'ARMATURE']
                    ):
                    #bpy.ops.object.parent_clear(type='CLEAR')
                    obj.select_set(obj.type == "MESH") 
                    pass        

            for obj in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = obj
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE': 
                        obj.select_set(obj.type == "MESH")    
                        

            
            objectToSelect2 = bpy.data.objects["rig_deform"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2


             
            bpy.ops.object.parent_set(type='ARMATURE')
            
                        
                
        
                
                
                
                

            
            
            
            
            
            
            
            
            
            
             
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["rig_deform"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.context.object.show_in_front = True
            bpy.ops.object.select_all(action='DESELECT')    




            # ### NEW Rigyfy Look
            # ### NEW Rigyfy Look

            bpy.ops.object.select_all(action='DESELECT')
            arm = bpy.data.objects['rig_deform']
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')

            bones_to_select = ['DEF-foot.L','DEF-foot.R','DEF-shin.L.001','DEF-shin.R.001','DEF-thigh.L.001',
            'DEF-thigh.R.001','DEF-hand.L','DEF-hand.R','DEF-forearm.L.001','DEF-forearm.R.001',
            'DEF-upper_arm.L.001','DEF-upper_arm.R.001','DEF-shin.L','DEF-shin.R','DEF-forearm.L','DEF-forearm.R']
            
            for bone in arm.data.edit_bones:
                if bone.name in bones_to_select:
                    bone.select = True
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.parent_clear(type='CLEAR')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            objectToSelect = bpy.data.objects["rig_deform"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         

            #select_head  Hand.L
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-hand.L"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            
            
        
            #Snip 
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-forearm.L"]    
            myBone.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #select_head  forearm.L
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-forearm.L"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            
            
        
            #Snip 
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-upper_arm.L"]    
            myBone.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #select_head  Hand.R
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-hand.R"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            
            
        
            #Snip 
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-forearm.R"]    
            myBone.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #select_head  forearm.L
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-forearm.R"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            
            
        
            #Snip 
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-upper_arm.R"]    
            myBone.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            ## Legs ## Legs ## Legs ## Legs ## Legs


            #select_head  shin.L
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-shin.L"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            
            
        
            #Snip 
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-thigh.L"]    
            myBone.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #select_head  foot.L
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-foot.L"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            
            
        
            #Snip 
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-shin.L"]    
            myBone.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #select_head  shin.R
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-shin.R"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            
            
        
            #Snip 
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-thigh.R"]    
            myBone.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #select_head  foot.R
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-foot.R"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            
            
        
            #Snip 
            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["DEF-shin.R"]    
            myBone.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            # ########## Setup


            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["rig_deform"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2 


            ob = bpy.data.objects["rig_deform"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            arm = bpy.data.objects['rig_deform']
        
            arm.data.edit_bones['DEF-hand.L'].parent = arm.data.edit_bones['DEF-forearm.L']
            arm.data.edit_bones['DEF-forearm.L.001'].parent = arm.data.edit_bones['DEF-forearm.L']
            arm.data.edit_bones['DEF-forearm.L'].parent = arm.data.edit_bones['DEF-upper_arm.L']
            arm.data.edit_bones['DEF-upper_arm.L.001'].parent = arm.data.edit_bones['DEF-upper_arm.L']

            arm.data.edit_bones['DEF-hand.R'].parent = arm.data.edit_bones['DEF-forearm.R']
            arm.data.edit_bones['DEF-forearm.R.001'].parent = arm.data.edit_bones['DEF-forearm.R']
            arm.data.edit_bones['DEF-forearm.R'].parent = arm.data.edit_bones['DEF-upper_arm.R']
            arm.data.edit_bones['DEF-upper_arm.R.001'].parent = arm.data.edit_bones['DEF-upper_arm.R']

            arm.data.edit_bones['DEF-foot.L'].parent = arm.data.edit_bones['DEF-shin.L']
            arm.data.edit_bones['DEF-shin.L.001'].parent = arm.data.edit_bones['DEF-shin.L']
            arm.data.edit_bones['DEF-shin.L'].parent = arm.data.edit_bones['DEF-thigh.L']
            arm.data.edit_bones['DEF-thigh.L.001'].parent = arm.data.edit_bones['DEF-thigh.L']


            arm.data.edit_bones['DEF-foot.R'].parent = arm.data.edit_bones['DEF-shin.R']
            arm.data.edit_bones['DEF-shin.R.001'].parent = arm.data.edit_bones['DEF-shin.R']
            arm.data.edit_bones['DEF-shin.R'].parent = arm.data.edit_bones['DEF-thigh.R']
            arm.data.edit_bones['DEF-thigh.R.001'].parent = arm.data.edit_bones['DEF-thigh.R']
            
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')

           


            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            #layer
             
                

            bpy.data.objects["rig_deform"].display_type = 'TEXTURED'   


            
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["rig_deform"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2


            bones = bpy.context.object.data.bones
            pose_bones = bpy.context.object.pose.bones
            for bone in pose_bones:
                bone.lock_location[0] = False # x
                bone.lock_location[1] = False # y
                bone.lock_location[2] = False # z
                
                bone.lock_rotation[0] = False # x
                bone.lock_rotation[1] = False # y
                bone.lock_rotation[2] = False # z
                bone.lock_rotation_w = False # z 
            



            ##new
            
            context = bpy.context
            for ob in context.selected_objects:
                ob.animation_data_clear()
            
            

            bpy.ops.settargetname.myop_operator() 


            ##new
                
            context = bpy.context
            for ob in context.selected_objects:
                ob.animation_data_clear()
            
            armature = bpy.data.objects['MB_RFRig']

            # Replace 'Bone' with the name of the bone you want to select
            bone_name = 'root'

            # Select the armature object
            bpy.context.view_layer.objects.active = armature
            armature.select_set(True)

            # Enter pose mode
            bpy.ops.object.mode_set(mode='POSE')

            # Select the specific bone
            bone = armature.pose.bones[bone_name]
            bone.bone.select = True

            # Set the custom shape to None
            bone.custom_shape = None
            bpy.ops.object.mode_set(mode='OBJECT')



            if mytool.faceadd_rotation !=False :

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["MB_RFRig"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                

                
                movetolayers()
                setupf()
                newrota()
                adddumb()   


                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["MB_RFRig"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                bpy.context.object.show_in_front = False

                bpy.context.object.pose.bones["DEF-nose.002"].constraints["Damped Track"].target = bpy.data.objects["rig"]
                bpy.context.object.pose.bones["DEF-lid.B.L"].constraints["Damped Track"].target = bpy.data.objects["rig"]
                bpy.context.object.pose.bones["DEF-lid.B.R"].constraints["Damped Track"].target = bpy.data.objects["rig"]

            if mytool.faceadd_rotation ==False :   

                facenewtransformation() 
             
             
            Deletunbones()       
                
                

       
       
        return {'FINISHED'}
    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
 

class Unlink_Anim_an(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Unlink rig_deform from control"
    bl_idname = "mb.unlink"
    bl_options = {'REGISTER', 'UNDO'} 
    

    
    def execute(self, context):

        scene = context.scene
        mytool = scene.my_tool

        
        
              

        #unhide
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["rig"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.context.object.hide_viewport = False
        bpy.context.object.hide_render = False
        bpy.context.object.hide_set(False)
        bpy.context.object.hide_select = False 


        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["rig"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.pose.scale_clear()
        bpy.ops.object.mode_set(mode='OBJECT')


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["MB_RFRig"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        bones = bpy.context.object.data.bones
        pose_bones = bpy.context.object.pose.bones
        for bone in pose_bones:
            bone.lock_location[0] = False # x
            bone.lock_location[1] = False # y
            bone.lock_location[2] = False # z
            
            bone.lock_rotation[0] = False # x
            bone.lock_rotation[1] = False # y
            bone.lock_rotation[2] = False # z
            bone.lock_rotation_w = False # z    


        
        
        armatureFrom = bpy.data.objects['MB_RFRig']
        armatureTo = bpy.data.objects['MB_RFRig']

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)
        
        
        

        # bpy.ops.object.select_all(action='DESELECT')
        # objectToSelect2 = bpy.data.objects["rig_deform"]
        # objectToSelect2.select_set(True)
        # bpy.context.view_layer.objects.active = objectToSelect2  

        # context = bpy.context
        # object = context.object
        # action = object.animation_data.action   
        # object.animation_data.action = None 


        mytool.my_unlink = True  
        
        mytool.my_link =True
                    
      
           
           
           
            
        return {'FINISHED'}
    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
    

class link_Anim_an(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "link rig_deform to control"
    bl_idname = "mb.link"
    bl_options = {'REGISTER', 'UNDO'} 
    

    
    def execute(self, context):

        scene = context.scene
        mytool = scene.my_tool
        
              

        #unhide
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["rig"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.context.object.hide_viewport = False
        bpy.context.object.hide_render = False
        bpy.context.object.hide_set(False)
        bpy.context.object.hide_select = False 


        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["rig"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.pose.scale_clear()
        bpy.ops.object.mode_set(mode='OBJECT')


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["MB_RFRig"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        bones = bpy.context.object.data.bones
        pose_bones = bpy.context.object.pose.bones
        for bone in pose_bones:
            bone.lock_location[0] = False # x
            bone.lock_location[1] = False # y
            bone.lock_location[2] = False # z
            
            bone.lock_rotation[0] = False # x
            bone.lock_rotation[1] = False # y
            bone.lock_rotation[2] = False # z
            bone.lock_rotation_w = False # z    


        
        
        #Get Anim

        armatureFrom = bpy.data.objects['rig']
        armatureTo = bpy.data.objects['MB_RFRig']

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)
            copy_con = boneTo.constraints.new('COPY_ROTATION')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name
            copy_con2 = boneTo.constraints.new('COPY_LOCATION')
            copy_con2.target = armatureFrom
            copy_con2.subtarget = boneFrom.name



            copy_con3 = boneTo.constraints.new('COPY_SCALE')
            copy_con3.target = armatureFrom
            copy_con3.subtarget = boneFrom.name
            copy_con3.target_space = 'LOCAL'
            copy_con3.owner_space = 'LOCAL'
        
        

        if mytool.my_string58 ==False :

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["rig_deform"]
                objectToSelect2.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect2

                armature = bpy.data.objects['rig_deform']
                # List of bone names to remove constraints from
                bone_names = ['DEF-thigh.R', 'DEF-thigh.L','DEF-thigh.L.001','DEF-shin.L','DEF-shin.L.001','DEF-foot.L','DEF-thigh.R.001','DEF-shin.R'
                ,'DEF-shin.R.001','DEF-foot.R','DEF-toe.R','DEF-pelvis.L','DEF-pelvis.R','DEF-spine','DEF-spine.001','DEF-spine.002'
                ,'DEF-spine.002','DEF-spine.003','DEF-spine.004','DEF-spine.005','DEF-spine.006','DEF-breast.L','DEF-breast.R'
                ,'DEF-shoulder.L','DEF-upper_arm.L','DEF-upper_arm.L.001','DEF-forearm.L','DEF-forearm.L.001','DEF-hand.L'
                ,'DEF-shoulder.R','DEF-upper_arm.R','DEF-upper_arm.R.001','DEF-forearm.R','DEF-forearm.R.001','DEF-hand.R'
                ,'DEF-palm.01.R','DEF-palm.02.R','DEF-palm.03.R','DEF-palm.04.R'
                ,'DEF-thumb.01.R','DEF-thumb.02.R','DEF-thumb.03.R'
                ,'DEF-f_index.01.R','DEF-f_index.02.R','DEF-f_index.03.R'
                ,'DEF-f_middle.01.R','DEF-f_middle.02.R','DEF-f_middle.03.R'
                ,'DEF-f_ring.01.R','DEF-f_ring.02.R','DEF-f_ring.03.R'
                ,'DEF-f_pinky.01.R','DEF-f_pinky.02.R','DEF-f_pinky.03.R','DEF-palm.01.L','DEF-palm.02.L','DEF-palm.03.L','DEF-palm.04.L'
                ,'DEF-thumb.01.L','DEF-thumb.02.L','DEF-thumb.03.L'
                ,'DEF-f_index.01.L','DEF-f_index.02.L','DEF-f_index.03.L'
                ,'DEF-f_middle.01.L','DEF-f_middle.02.L','DEF-f_middle.03.L'
                ,'DEF-f_ring.01.L','DEF-f_ring.02.L','DEF-f_ring.03.L'
                ,'DEF-f_pinky.01.L','DEF-f_pinky.02.L','DEF-f_pinky.03.L','DEF-toe.L']
                # Loop through the bone names
                for bone_name in bone_names:
                    # Get the bone
                    bone = armature.pose.bones[bone_name]
                    # Remove the scale constraint from the bone
                    for constraint in bone.constraints:
                        if constraint.type == 'COPY_SCALE':
                            bone.constraints.remove(constraint)





        
        
        
        
        
        mytool.my_unlink = False  
        
        mytool.my_link =False
        
                    
      
           
           
           
            
        return {'FINISHED'}
    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
    

class move_tolayer_an(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show"
    bl_idname = "mb.mtlayer"
    bl_options = {'REGISTER', 'UNDO'} 
    

    
    def execute(self, context):

        scene = context.scene
        mytool = scene.my_tool

        

        collections = bpy.context.object.data.collections

        for layer in range(len(collections)):
            collections[layer].is_visible = False
        
        bpy.context.object.data.collections["DEF"].is_visible = True

         

        


           
           
            
        return {'FINISHED'}
    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
    

class show_tolayer_an(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show"
    bl_idname = "mb.mshowtlayer"
    bl_options = {'REGISTER', 'UNDO'} 
    

    
    def execute(self, context):

        scene = context.scene
        mytool = scene.my_tool


        collections = bpy.context.object.data.collections

        for layer in range(len(collections)):
            collections[layer].is_visible = True
        
         
           
           
            
        return {'FINISHED'}
    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
    

class hide_tolayer_an(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Hide"
    bl_idname = "mb.mshidetlayer"
    bl_options = {'REGISTER', 'UNDO'} 
    

    
    def execute(self, context):

        scene = context.scene
        mytool = scene.my_tool
         
 
     
        
        bpy.context.object.data.collections["DEF"].is_visible = False

         
           
           
            
        return {'FINISHED'}
    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
    

class mbmute_co_Op(bpy.types.Operator):
    
    bl_idname = "mbobject.mute_op"
    bl_label = "Operator"
    
    def execute(self, context):

        
    


        
        
        
        
        
        
     
        obj = bpy.data.objects.get("MB_RFRig")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Rotation' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Rotation'].enabled = False
                    


        
        obj = bpy.data.objects.get("MB_RFRig")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Location' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Location'].enabled = False



        obj = bpy.data.objects.get("MB_RFRig")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Scale' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Scale'].enabled = False











        #/

        obj = bpy.data.objects.get("rig_deform")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Rotation' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Rotation'].enabled = False
                    


        
        obj = bpy.data.objects.get("rig_deform")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Location' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Location'].enabled = False



        obj = bpy.data.objects.get("rig_deform")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Scale' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Scale'].enabled = False


      
        
        return {'FINISHED'}


class mbunmute_co_Op(bpy.types.Operator):
    
    bl_idname = "mbobject.unmute_op"
    bl_label = "Operator"
    
    def execute(self, context):

        
        
        
     
        obj = bpy.data.objects.get("MB_RFRig")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Rotation' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Rotation'].enabled = True
                    


        
        obj = bpy.data.objects.get("MB_RFRig")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Location' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Location'].enabled = True



        obj = bpy.data.objects.get("MB_RFRig")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Scale' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Scale'].enabled = True


        #/


        obj = bpy.data.objects.get("rig_deform")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Rotation' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Rotation'].enabled = True
                    


        
        obj = bpy.data.objects.get("rig_deform")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Location' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Location'].enabled = True



        obj = bpy.data.objects.get("rig_deform")

        # Check if the object exists and is an armature
        if obj is not None and obj.type == 'ARMATURE' :
            # Iterate over each bone in the armature's pose
            for bone in obj.pose.bones:
                # Check if the bone has a "Copy Rotation" constraint
                if 'Copy Scale' in bone.constraints:
                    # Disable the "Copy Rotation" constraint
                    bone.constraints['Copy Scale'].enabled = True


      
        
        return {'FINISHED'}






















