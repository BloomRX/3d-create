import bpy

import math










 
class spine_newss_op(bpy.types.Operator):
    bl_label = "LFingers"
    bl_idname = "spinewsl.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene


        if mytool.my_bool33 ==False :
                     
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            
            
            for action in bpy.data.actions:
                bpy.data.actions.remove(action)


            ##Rest in pose mode
        
            bpy.ops.object.posemode_toggle()
            bpy.ops.pose.select_all(action='SELECT')
            bpy.ops.pose.rot_clear()
            bpy.ops.pose.loc_clear()
            bpy.ops.object.mode_set(mode='OBJECT')


        
        
        
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'ARSP_RFAR'



        ##Rest
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ARSP_RFAR"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        if mytool.my_bool33 !=False :

            context = bpy.context
            object = context.object

            #should put checks in to see if you have object animation_data etc

            action = object.animation_data.action  # this is the action that is shown in action editor.

            # the action can be unlinked using.

            object.animation_data.action = None


 
        
        
        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["ARSP_RFAR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.view3d.snap_cursor_to_center()


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'ARSP_RFAR2'

 


        ##Rest
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ARSP_RFAR2"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        if mytool.my_bool33 !=False :

            context = bpy.context
            object = context.object

            #should put checks in to see if you have object animation_data etc

            action = object.animation_data.action  # this is the action that is shown in action editor.

            # the action can be unlinked using.

            object.animation_data.action = None


 
        
        
        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["ARSP_RFAR2"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.view3d.snap_cursor_to_center()


        











        bpy.ops.object.select_all(action='DESELECT')
        bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'RF_fingers_AR'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_fingers_AR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        
        for obj in bpy.context.selected_objects:
            obj.name = "spinefix_ar"
            obj.data.name = "spinefix_ar"





        ##1111111
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["spinefix_ar"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("Spine_RF_Rot")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   


       


        if sce.bone_targetHip !="" :
            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_targetHip]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"

        if sce.bone_target40 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_target40]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"

        if sce.bone_target39 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_target39]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"


        if sce.bone_target38 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_target38]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"



        if sce.bone_target37 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_target37]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"


        if sce.bone_target36 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_target36]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"


        if sce.bone_target35 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_target35]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"



        if sce.bone_target34 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_target34]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"



        if sce.bone_target33 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['spinefix_ar']
                        
            selected_bone = armature1.pose.bones[sce.bone_target33]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "Spine_RF_Rot"





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["ARSP_RFAR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects["ARSP_RFAR"] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects["ARSP_RFAR"]
        armatureTo = bpy.data.objects["ARSP_RFAR"]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)





        #calculate_roll

        if sce.bone_target33 !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_target33] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target33] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




        if sce.bone_target34 !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_target34] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target34] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')  



        if sce.bone_target35 !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_target35] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target35] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')





        if sce.bone_target36 !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_target36] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target36] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')





        if sce.bone_target37 !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_target37] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target37] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



        if sce.bone_target38 !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_target38] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target38] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



        if sce.bone_target39 !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_target39] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target39] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




        if sce.bone_target40 !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_target40] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target40] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')





        if sce.bone_targetHip !="" :
                    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]  
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect2 = bpy.data.objects["ARSP_RFAR"] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["ARSP_RFAR"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones[sce.bone_targetHip] 
            b.select=True
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_targetHip] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.calculate_roll(type='ACTIVE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



        #Add bones #################################################################



        if sce.bone_target33 !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target33]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("head_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   





        if sce.bone_target34 !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target34]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("neck_02_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   



        if sce.bone_target35 !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target35]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("neck_01_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


        if sce.bone_target36 !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target36]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("spine_05_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   
        



        if sce.bone_target37 !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target37]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("spine_04_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



        if sce.bone_target38 !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target38]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("spine_03_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




        if sce.bone_target39 !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target39]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("spine_02_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




        if sce.bone_target40 !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target40]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("spine_01_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




        if sce.bone_targetHip !="" :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

         
            ob = bpy.data.objects["ARSP_RFAR"]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_targetHip]    
            myBone.select_head = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["ARSP_RFAR"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("pelvis_UE_RF")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')

        






        ##Fix Spines

        bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'RF_fixSpines_AR'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_fixSpines_AR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        
        for obj in bpy.context.selected_objects:
            obj.name = "RF_fixSpines_AR"
            obj.data.name = "RF_fixSpines_AR"







        ##1111111
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["RF_fixSpines_AR"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("fixSpines_bone")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   


        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_fixSpines_AR"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["RF_fixSpines_AR"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["fixSpines_bone"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'X'
        angle = -90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')




















        if sce.bone_targetHip !="" :
            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["pelvis_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"

        if sce.bone_target40 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["spine_01_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"

        if sce.bone_target39 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["spine_02_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"


        if sce.bone_target38 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["spine_03_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"



        if sce.bone_target37 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["spine_04_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"


        if sce.bone_target36 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["spine_05_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"


        if sce.bone_target35 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["neck_01_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"



        if sce.bone_target34 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["neck_02_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"



        if sce.bone_target33 !="" :

            armature1 = bpy.data.objects["ARSP_RFAR"]
            armature2 = bpy.data.objects['RF_fixSpines_AR']
                        
            selected_bone = armature1.pose.bones["head_UE_RF"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "fixSpines_bone"
    



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["ARSP_RFAR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects["ARSP_RFAR"] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects["ARSP_RFAR"]
        armatureTo = bpy.data.objects["ARSP_RFAR"]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)





        objectToSelect = bpy.data.objects["ARSP_RFAR"] 
        objectToSelect.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect
        
        
        ob = bpy.data.objects["ARSP_RFAR"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        arm = bpy.data.objects["ARSP_RFAR"]


        if sce.bone_target33 !="" :
        
            arm.data.edit_bones['head_UE_RF'].parent = arm.data.edit_bones[sce.bone_target33]
        
        if sce.bone_target34 !="" :
          
            arm.data.edit_bones['neck_02_UE_RF'].parent = arm.data.edit_bones[sce.bone_target34]
        
        if sce.bone_target35 !="" :

            arm.data.edit_bones['neck_01_UE_RF'].parent = arm.data.edit_bones[sce.bone_target35]

        if sce.bone_target36 !="" :

            arm.data.edit_bones['spine_05_UE_RF'].parent = arm.data.edit_bones[sce.bone_target36]

        if sce.bone_target37 !="" :
          
            arm.data.edit_bones['spine_04_UE_RF'].parent = arm.data.edit_bones[sce.bone_target37]
        
        if sce.bone_target38 !="" :      
       
            arm.data.edit_bones['spine_03_UE_RF'].parent = arm.data.edit_bones[sce.bone_target38]
       
        if sce.bone_target39 !="" :
        
            arm.data.edit_bones['spine_02_UE_RF'].parent = arm.data.edit_bones[sce.bone_target39]
       
        if sce.bone_target40 !="" :     
          
            arm.data.edit_bones['spine_01_UE_RF'].parent = arm.data.edit_bones[sce.bone_target40]
        
        
        if sce.bone_targetHip !="" :  
         
            arm.data.edit_bones['pelvis_UE_RF'].parent = arm.data.edit_bones[sce.bone_targetHip]

 


        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        


        armatureFrom = bpy.data.objects["ARSP_RFAR2"]
        armatureTo = bpy.data.objects["ARSP_RFAR"]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)
            #copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
            copy_con = boneTo.constraints.new('COPY_ROTATION')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["ARSP_RFAR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects["ARSP_RFAR"] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects["ARSP_RFAR"]
        armatureTo = bpy.data.objects["ARSP_RFAR"]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)
        



























        return {'FINISHED'}
  
  
class spine_rotoo_op(bpy.types.Operator):
    bl_label = "LFingers"
    bl_idname = "spinerotoo.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene


        if sce.bone_targetHip !="" and mytool.my_string37 !=False :
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["pelvis"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "pelvis_UE_RF"

        if sce.bone_target40 !="" and mytool.my_string36 !=False:

            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["spine_01"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "spine_01_UE_RF"

        if sce.bone_target39 !="" and mytool.my_string35 !=False:

            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["spine_02"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "spine_02_UE_RF"


        if sce.bone_target38 !="" and mytool.my_string34 !=False:

            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["spine_03"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "spine_03_UE_RF"



        if sce.bone_target37 !="" and mytool.my_string33 !=False :

            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["spine_04"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "spine_04_UE_RF"


        if sce.bone_target36 !="" and mytool.my_string32 !=False :

            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["spine_05"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "spine_05_UE_RF"


        if sce.bone_target35 !="" and mytool.my_string31 !=False :

            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["neck_01"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "neck_01_UE_RF"



        if sce.bone_target34 !="" and mytool.my_string30 !=False:

            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["neck_02"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "neck_02_UE_RF"



        if sce.bone_target33 !="" and mytool.my_string29 !=False:

            armature1 = bpy.data.objects[sce.Armature_Target] 
            armature2 = bpy.data.objects['ARSP_RFAR']
                        
            selected_bone = armature1.pose.bones["head"]
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "head_UE_RF"

 























        return {'FINISHED'}
  