import bpy



 
class namingfix_op(bpy.types.Operator):
    bl_label = "  "
    bl_idname = "namingfixname.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene
        
        
       
        
        bones = bpy.context.object.data.bones
        pose_bones = bpy.context.object.pose.bones
        for bone in pose_bones:
            print(bone.name)
            bpy.context.object.data.bones[bone.name].name = bone.name + sce.bone_target90.strip()
        
       

 
        
        if sce.bone_target1 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target1].name = sce.bone_target1 +sce.bone_target90.strip()
            bpy.context.scene.bone_target1 = sce.bone_target1+sce.bone_target90.strip()

 
        if sce.bone_target3 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target3].name = sce.bone_target3 +sce.bone_target90.strip()
            bpy.context.scene.bone_target3 = sce.bone_target3+sce.bone_target90.strip()
      

        if sce.bone_target4 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target4].name = sce.bone_target4 +sce.bone_target90.strip()
            bpy.context.scene.bone_target4 = sce.bone_target4+sce.bone_target90.strip()
 
 
        if sce.bone_target6 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target6].name = sce.bone_target6 +sce.bone_target90.strip()
            bpy.context.scene.bone_target6 = sce.bone_target6+sce.bone_target90.strip()
      
      
      
        if sce.bone_target7 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target7].name = sce.bone_target7 +sce.bone_target90.strip()
            bpy.context.scene.bone_target7 = sce.bone_target7+sce.bone_target90.strip()
      
      
      
        if sce.bone_target8 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target8].name = sce.bone_target8 +sce.bone_target90.strip()
            bpy.context.scene.bone_target8 = sce.bone_target8+sce.bone_target90.strip()
      
      

        if sce.bone_target9 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target9].name = sce.bone_target9 +sce.bone_target90.strip()
            bpy.context.scene.bone_target9 = sce.bone_target9+sce.bone_target90.strip() 
        
        
        
        
        if sce.bone_target11 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target11].name = sce.bone_target11 +sce.bone_target90.strip()
            bpy.context.scene.bone_target11 = sce.bone_target11+sce.bone_target90.strip() 
        
        
        
        
        if sce.bone_target12 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target12].name = sce.bone_target12 +sce.bone_target90.strip()
            bpy.context.scene.bone_target12 = sce.bone_target12+sce.bone_target90.strip()
        
        
        
        
        if sce.bone_target14 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target14].name = sce.bone_target14 +sce.bone_target90.strip()
            bpy.context.scene.bone_target14 = sce.bone_target14+sce.bone_target90.strip()
            
        
        
        
        
        if sce.bone_target15 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target15].name = sce.bone_target15 +sce.bone_target90.strip()
            bpy.context.scene.bone_target15 = sce.bone_target15+sce.bone_target90.strip() 
        
        
        if sce.bone_target16 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target16].name = sce.bone_target16 +sce.bone_target90.strip()
            bpy.context.scene.bone_target16 = sce.bone_target16+sce.bone_target90.strip() 
        
        
        if sce.bone_target17 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target17].name = sce.bone_target17 +sce.bone_target90.strip()
            bpy.context.scene.bone_target17 = sce.bone_target17+sce.bone_target90.strip()    
        
        
        if sce.bone_target18 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target18].name = sce.bone_target18 +sce.bone_target90.strip()
            bpy.context.scene.bone_target18 = sce.bone_target18+sce.bone_target90.strip()
        
        
        if sce.bone_target20 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target20].name = sce.bone_target20 +sce.bone_target90.strip()
            bpy.context.scene.bone_target20 = sce.bone_target20+sce.bone_target90.strip()
        
        
        
        if sce.bone_target21 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target21].name = sce.bone_target21 +sce.bone_target90.strip()
            bpy.context.scene.bone_target21 = sce.bone_target21+sce.bone_target90.strip()
        
        
        
        if sce.bone_target23 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target23].name = sce.bone_target23 +sce.bone_target90.strip()
            bpy.context.scene.bone_target23 = sce.bone_target23+sce.bone_target90.strip()
        
        
        
        if sce.bone_target24 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target24].name = sce.bone_target24 +sce.bone_target90.strip()
            bpy.context.scene.bone_target24 = sce.bone_target24+sce.bone_target90.strip() 
        
        
        
        
        if sce.bone_target25 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target25].name = sce.bone_target25 +sce.bone_target90.strip()
            bpy.context.scene.bone_target25 = sce.bone_target25+sce.bone_target90.strip()
        
        
        
        if sce.bone_target26 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target26].name = sce.bone_target26 +sce.bone_target90.strip()
            bpy.context.scene.bone_target26 = sce.bone_target26+sce.bone_target90.strip()
        
        
        if sce.bone_target28 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target28].name = sce.bone_target28 +sce.bone_target90.strip()
            bpy.context.scene.bone_target28 = sce.bone_target28+sce.bone_target90.strip()
        
        
        
        if sce.bone_target29 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target29].name = sce.bone_target29 +sce.bone_target90.strip()
            bpy.context.scene.bone_target29 = sce.bone_target29+sce.bone_target90.strip() 
        
        
        
        
        if sce.bone_target31 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target31].name = sce.bone_target31 +sce.bone_target90.strip()
            bpy.context.scene.bone_target31 = sce.bone_target31+sce.bone_target90.strip()
        
        
        
        
        
        if sce.bone_target32 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target32].name = sce.bone_target32 +sce.bone_target90.strip()
            bpy.context.scene.bone_target32 = sce.bone_target32+sce.bone_target90.strip()
        
        
        
        
        
        
        if sce.bone_target33 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target33].name = sce.bone_target33 +sce.bone_target90.strip()
            bpy.context.scene.bone_target33 = sce.bone_target33+sce.bone_target90.strip()
        
        
        
        if sce.bone_target34 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target34].name = sce.bone_target34 +sce.bone_target90.strip()
            bpy.context.scene.bone_target34 = sce.bone_target34+sce.bone_target90.strip()
        
        
        
        
        
        if sce.bone_target35 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target35].name = sce.bone_target35 +sce.bone_target90.strip()
            bpy.context.scene.bone_target35 = sce.bone_target35+sce.bone_target90.strip() 
        
        
        
        if sce.bone_target36 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target36].name = sce.bone_target36 +sce.bone_target90.strip()
            bpy.context.scene.bone_target36 = sce.bone_target36+sce.bone_target90.strip() 
        
        
        
        if sce.bone_target37 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target37].name = sce.bone_target37 +sce.bone_target90.strip()
            bpy.context.scene.bone_target37 = sce.bone_target37+sce.bone_target90.strip()
        
        
        
        if sce.bone_target38 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target38].name = sce.bone_target38 +sce.bone_target90.strip()
            bpy.context.scene.bone_target38 = sce.bone_target38+sce.bone_target90.strip()
        
       
        if sce.bone_target39 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target39].name = sce.bone_target39 +sce.bone_target90.strip()
            bpy.context.scene.bone_target39 = sce.bone_target39+sce.bone_target90.strip()
       
       

        if sce.bone_target40 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target40].name = sce.bone_target40 +sce.bone_target90.strip()
            bpy.context.scene.bone_target40 = sce.bone_target40+sce.bone_target90.strip()
       
       
       
        if sce.bone_targetHip !="" :
        
            #bpy.context.object.data.bones[sce.bone_targetHip].name = sce.bone_targetHip+sce.bone_target90.strip()
            bpy.context.scene.bone_targetHip = sce.bone_targetHip+sce.bone_target90.strip()  
        
        
        
        
        
        
        ###########Fingers
        
        if sce.bone_target60 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target60].name = sce.bone_target60 +sce.bone_target90.strip()
            bpy.context.scene.bone_target60 = sce.bone_target60+sce.bone_target90.strip()
        
        
       
        
        if sce.bone_target61 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target61].name = sce.bone_target61 +sce.bone_target90.strip()
            bpy.context.scene.bone_target61 = sce.bone_target61+sce.bone_target90.strip()
        
        
        
        
        if sce.bone_target62 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target62].name = sce.bone_target62 +sce.bone_target90.strip()
            bpy.context.scene.bone_target62 = sce.bone_target62+sce.bone_target90.strip()  
        
        
        
        if sce.bone_target63 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target63].name = sce.bone_target63 +sce.bone_target90.strip()
            bpy.context.scene.bone_target63 = sce.bone_target63+sce.bone_target90.strip() 
        
        
        if sce.bone_target64 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target64].name = sce.bone_target64 +sce.bone_target90.strip()
            bpy.context.scene.bone_target64 = sce.bone_target64+sce.bone_target90.strip() 
        
          
        if sce.bone_target65 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target65].name = sce.bone_target65 +sce.bone_target90.strip()
            bpy.context.scene.bone_target65 = sce.bone_target65+sce.bone_target90.strip()
        
        
        if sce.bone_target66 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target66].name = sce.bone_target66 +sce.bone_target90.strip()
            bpy.context.scene.bone_target66 = sce.bone_target66+sce.bone_target90.strip()  
        
        
        if sce.bone_target67 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target67].name = sce.bone_target67 +sce.bone_target90.strip()
            bpy.context.scene.bone_target67 = sce.bone_target67+sce.bone_target90.strip()
        
        
        if sce.bone_target68 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target68].name = sce.bone_target68 +sce.bone_target90.strip()
            bpy.context.scene.bone_target68 = sce.bone_target68+sce.bone_target90.strip()
        
        
        if sce.bone_target69 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target69].name = sce.bone_target69 +sce.bone_target90.strip()
            bpy.context.scene.bone_target69 = sce.bone_target69+sce.bone_target90.strip()
        
        
        
        if sce.bone_target70 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target70].name = sce.bone_target70 +sce.bone_target90.strip()
            bpy.context.scene.bone_target70 = sce.bone_target70+sce.bone_target90.strip()
        
        
        if sce.bone_target71 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target71].name = sce.bone_target71 +sce.bone_target90.strip()
            bpy.context.scene.bone_target71 = sce.bone_target71+sce.bone_target90.strip()
        
        
        if sce.bone_target72 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target72].name = sce.bone_target72 +sce.bone_target90.strip()
            bpy.context.scene.bone_target72 = sce.bone_target72+sce.bone_target90.strip()
        
        
        if sce.bone_target73 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target73].name = sce.bone_target73 +sce.bone_target90.strip()
            bpy.context.scene.bone_target73 = sce.bone_target73+sce.bone_target90.strip()
        
       
       
       
        if sce.bone_target74 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target74].name = sce.bone_target74 +sce.bone_target90.strip()
            bpy.context.scene.bone_target74 = sce.bone_target74+sce.bone_target90.strip()
        
        if sce.bone_target75 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target75].name = sce.bone_target75 +sce.bone_target90.strip()
            bpy.context.scene.bone_target75 = sce.bone_target75+sce.bone_target90.strip()
        
        
        if sce.bone_target76 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target76].name = sce.bone_target76 +sce.bone_target90.strip()
            bpy.context.scene.bone_target76 = sce.bone_target76+sce.bone_target90.strip()
        
        
        if sce.bone_target77 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target77].name = sce.bone_target77 +sce.bone_target90.strip()
            bpy.context.scene.bone_target77 = sce.bone_target77+sce.bone_target90.strip()
        
        
        
        if sce.bone_target78 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target78].name = sce.bone_target78 +sce.bone_target90.strip()
            bpy.context.scene.bone_target78 = sce.bone_target78+sce.bone_target90.strip()
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        ########### finger rrrrrrrrrr
        
        if sce.bone_target41 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target41].name = sce.bone_target41 +sce.bone_target90.strip()
            bpy.context.scene.bone_target41 = sce.bone_target41+sce.bone_target90.strip()
        
        
        if sce.bone_target42 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target42].name = sce.bone_target42 +sce.bone_target90.strip()
            bpy.context.scene.bone_target42 = sce.bone_target42+sce.bone_target90.strip()
        
        
        
        if sce.bone_target43 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target43].name = sce.bone_target43 +sce.bone_target90.strip()
            bpy.context.scene.bone_target43 = sce.bone_target43+sce.bone_target90.strip()
        
        
        if sce.bone_target44 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target44].name = sce.bone_target44 +sce.bone_target90.strip()
            bpy.context.scene.bone_target44 = sce.bone_target44+sce.bone_target90.strip()
        
        
        
        if sce.bone_target45 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target45].name = sce.bone_target45 +sce.bone_target90.strip()
            bpy.context.scene.bone_target45 = sce.bone_target45+sce.bone_target90.strip()
        
        
        if sce.bone_target46 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target46].name = sce.bone_target46 +sce.bone_target90.strip()
            bpy.context.scene.bone_target46 = sce.bone_target46+sce.bone_target90.strip()
        
        
        
        if sce.bone_target47 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target47].name = sce.bone_target47 +sce.bone_target90.strip()
            bpy.context.scene.bone_target47 = sce.bone_target47+sce.bone_target90.strip()  
        
        
        
        if sce.bone_target48 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target48].name = sce.bone_target48 +sce.bone_target90.strip()
            bpy.context.scene.bone_target48 = sce.bone_target48+sce.bone_target90.strip()
        
        
        
        if sce.bone_target49 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target49].name = sce.bone_target49 +sce.bone_target90.strip()
            bpy.context.scene.bone_target49 = sce.bone_target49+sce.bone_target90.strip()
        
        
        
        if sce.bone_target50 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target50].name = sce.bone_target50 +sce.bone_target90.strip()
            bpy.context.scene.bone_target50 = sce.bone_target50+sce.bone_target90.strip()
        
        
        if sce.bone_target51 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target51].name = sce.bone_target51 +sce.bone_target90.strip()
            bpy.context.scene.bone_target51 = sce.bone_target51+sce.bone_target90.strip()
        
        
        if sce.bone_target52 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target52].name = sce.bone_target52 +sce.bone_target90.strip()
            bpy.context.scene.bone_target52 = sce.bone_target52+sce.bone_target90.strip()
        
        
        
        if sce.bone_target53 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target53].name = sce.bone_target53 +sce.bone_target90.strip()
            bpy.context.scene.bone_target53 = sce.bone_target53+sce.bone_target90.strip()
        
        
        if sce.bone_target54 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target54].name = sce.bone_target54 +sce.bone_target90.strip()
            bpy.context.scene.bone_target54 = sce.bone_target54+sce.bone_target90.strip()
        
        
        if sce.bone_target55 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target55].name = sce.bone_target55 +sce.bone_target90.strip()
            bpy.context.scene.bone_target55 = sce.bone_target55+sce.bone_target90.strip()
        
        
        
        if sce.bone_target56 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target56].name = sce.bone_target56 +sce.bone_target90.strip()
            bpy.context.scene.bone_target56 = sce.bone_target56+sce.bone_target90.strip()
        
        
        if sce.bone_target57 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target57].name = sce.bone_target57 +sce.bone_target90.strip()
            bpy.context.scene.bone_target57 = sce.bone_target57+sce.bone_target90.strip()
        
        
        if sce.bone_target58 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target58].name = sce.bone_target58 +sce.bone_target90.strip()
            bpy.context.scene.bone_target58 = sce.bone_target58+sce.bone_target90.strip()
        
        
        if sce.bone_target59 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target59 = sce.bone_target59+sce.bone_target90.strip()
        
        



        if sce.bone_target2 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target2 = sce.bone_target2+sce.bone_target90.strip()


        if sce.bone_target5 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target5 = sce.bone_target5+sce.bone_target90.strip()


        if sce.bone_target10 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target10 = sce.bone_target10+sce.bone_target90.strip()


        if sce.bone_target13 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target13 = sce.bone_target13+sce.bone_target90.strip()


       
       
        if sce.bone_target19 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target19 = sce.bone_target19+sce.bone_target90.strip()
        


        if sce.bone_target22 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target22 = sce.bone_target22+sce.bone_target90.strip()
       
       
       
       
        if sce.bone_target27 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target27 = sce.bone_target27+sce.bone_target90.strip()


        if sce.bone_target30 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target30 = sce.bone_target30+sce.bone_target90.strip()

        if sce.bone_target79 !="" :
            
            #bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +sce.bone_target90.strip()
            bpy.context.scene.bone_target79 = sce.bone_target79+sce.bone_target90.strip()

        if sce.bone_target79 !="":

            bpy.context.object.data.bones[sce.bone_target79].name ="root"
            bpy.context.scene.bone_target79 ="root"



        
        bpy.ops.object.select_all(action='DESELECT')
                
        objectToSelect = bpy.data.objects[sce.Armature_Target] 
        objectToSelect.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data

        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("CenterBrow") 
        if  bonein is not None:
            
            print("gg")
            bpy.context.object.data.bones["CenterBrow"].name = "qqcenterbrowqq"


        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("Nose") 
        if  bonein is not None:
            
            print("gg")
            bpy.context.object.data.bones["Nose"].name = "qnoseq"
        
        
        

        bpy.ops.object.mode_set(mode='EDIT')

        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')
        
        
        
        
        
        
        
 
        
        
        return {'FINISHED'}
  



class namingfixnoid_op(bpy.types.Operator):
    bl_label = "  "
    bl_idname = "namingfixnoid.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene
        
        
       
    
       

 
        
        if sce.bone_target1 !="" :
            
            bpy.context.object.data.bones[sce.bone_target1].name = sce.bone_target1 +"MBRF"
            bpy.context.scene.bone_target1 = sce.bone_target1+"MBRF"

 
        if sce.bone_target3 !="" :
            
            bpy.context.object.data.bones[sce.bone_target3].name = sce.bone_target3 +"MBRF"
            bpy.context.scene.bone_target3 = sce.bone_target3+"MBRF"
      

        if sce.bone_target4 !="" :
            
            bpy.context.object.data.bones[sce.bone_target4].name = sce.bone_target4 +"MBRF"
            bpy.context.scene.bone_target4 = sce.bone_target4+"MBRF"
 
 
        if sce.bone_target6 !="" :
            
            bpy.context.object.data.bones[sce.bone_target6].name = sce.bone_target6 +"MBRF"
            bpy.context.scene.bone_target6 = sce.bone_target6+"MBRF"
      
      
      
        if sce.bone_target7 !="" :
            
            bpy.context.object.data.bones[sce.bone_target7].name = sce.bone_target7 +"MBRF"
            bpy.context.scene.bone_target7 = sce.bone_target7+"MBRF"
      
      
      
        if sce.bone_target8 !="" :
            
            bpy.context.object.data.bones[sce.bone_target8].name = sce.bone_target8 +"MBRF"
            bpy.context.scene.bone_target8 = sce.bone_target8+"MBRF"
      
      

        if sce.bone_target9 !="" :
            
            bpy.context.object.data.bones[sce.bone_target9].name = sce.bone_target9 +"MBRF"
            bpy.context.scene.bone_target9 = sce.bone_target9+"MBRF" 
        
        
        
        
        if sce.bone_target11 !="" :
            
            bpy.context.object.data.bones[sce.bone_target11].name = sce.bone_target11 +"MBRF"
            bpy.context.scene.bone_target11 = sce.bone_target11+"MBRF" 
        
        
        
        
        if sce.bone_target12 !="" :
        
            bpy.context.object.data.bones[sce.bone_target12].name = sce.bone_target12 +"MBRF"
            bpy.context.scene.bone_target12 = sce.bone_target12+"MBRF"
        
        
        
        
        if sce.bone_target14 !="" :
            
            bpy.context.object.data.bones[sce.bone_target14].name = sce.bone_target14 +"MBRF"
            bpy.context.scene.bone_target14 = sce.bone_target14+"MBRF"
            
        
        
        
        
        if sce.bone_target15 !="" :
            
            bpy.context.object.data.bones[sce.bone_target15].name = sce.bone_target15 +"MBRF"
            bpy.context.scene.bone_target15 = sce.bone_target15+"MBRF" 
        
        
        if sce.bone_target16 !="" :
            
            bpy.context.object.data.bones[sce.bone_target16].name = sce.bone_target16 +"MBRF"
            bpy.context.scene.bone_target16 = sce.bone_target16+"MBRF" 
        
        
        if sce.bone_target17 !="" :
            
            bpy.context.object.data.bones[sce.bone_target17].name = sce.bone_target17 +"MBRF"
            bpy.context.scene.bone_target17 = sce.bone_target17+"MBRF"    
        
        
        if sce.bone_target18 !="" :
            
            bpy.context.object.data.bones[sce.bone_target18].name = sce.bone_target18 +"MBRF"
            bpy.context.scene.bone_target18 = sce.bone_target18+"MBRF"
        
        
        if sce.bone_target20 !="" :
            
            bpy.context.object.data.bones[sce.bone_target20].name = sce.bone_target20 +"MBRF"
            bpy.context.scene.bone_target20 = sce.bone_target20+"MBRF"
        
        
        
        if sce.bone_target21 !="" :
            
            bpy.context.object.data.bones[sce.bone_target21].name = sce.bone_target21 +"MBRF"
            bpy.context.scene.bone_target21 = sce.bone_target21+"MBRF"
        
        
        
        if sce.bone_target23 !="" :
            
            bpy.context.object.data.bones[sce.bone_target23].name = sce.bone_target23 +"MBRF"
            bpy.context.scene.bone_target23 = sce.bone_target23+"MBRF"
        
        
        
        if sce.bone_target24 !="" :
            
            bpy.context.object.data.bones[sce.bone_target24].name = sce.bone_target24 +"MBRF"
            bpy.context.scene.bone_target24 = sce.bone_target24+"MBRF" 
        
        
        
        
        if sce.bone_target25 !="" :
            
            bpy.context.object.data.bones[sce.bone_target25].name = sce.bone_target25 +"MBRF"
            bpy.context.scene.bone_target25 = sce.bone_target25+"MBRF"
        
        
        
        if sce.bone_target26 !="" :
            
            bpy.context.object.data.bones[sce.bone_target26].name = sce.bone_target26 +"MBRF"
            bpy.context.scene.bone_target26 = sce.bone_target26+"MBRF"
        
        
        if sce.bone_target28 !="" :
            
            bpy.context.object.data.bones[sce.bone_target28].name = sce.bone_target28 +"MBRF"
            bpy.context.scene.bone_target28 = sce.bone_target28+"MBRF"
        
        
        
        if sce.bone_target29 !="" :
            
            bpy.context.object.data.bones[sce.bone_target29].name = sce.bone_target29 +"MBRF"
            bpy.context.scene.bone_target29 = sce.bone_target29+"MBRF" 
        
        
        
        
        if sce.bone_target31 !="" :
            
            bpy.context.object.data.bones[sce.bone_target31].name = sce.bone_target31 +"MBRF"
            bpy.context.scene.bone_target31 = sce.bone_target31+"MBRF"
        
        
        
        
        
        if sce.bone_target32 !="" :
            
            bpy.context.object.data.bones[sce.bone_target32].name = sce.bone_target32 +"MBRF"
            bpy.context.scene.bone_target32 = sce.bone_target32+"MBRF"
        
        
        
        
        
        
        if sce.bone_target33 !="" :
            
            bpy.context.object.data.bones[sce.bone_target33].name = sce.bone_target33 +"MBRF"
            bpy.context.scene.bone_target33 = sce.bone_target33+"MBRF"
        
        
        
        if sce.bone_target34 !="" :
            
            bpy.context.object.data.bones[sce.bone_target34].name = sce.bone_target34 +"MBRF"
            bpy.context.scene.bone_target34 = sce.bone_target34+"MBRF"
        
        
        
        
        
        if sce.bone_target35 !="" :
            
            bpy.context.object.data.bones[sce.bone_target35].name = sce.bone_target35 +"MBRF"
            bpy.context.scene.bone_target35 = sce.bone_target35+"MBRF" 
        
        
        
        if sce.bone_target36 !="" :
            
            bpy.context.object.data.bones[sce.bone_target36].name = sce.bone_target36 +"MBRF"
            bpy.context.scene.bone_target36 = sce.bone_target36+"MBRF" 
        
        
        
        if sce.bone_target37 !="" :
            
            bpy.context.object.data.bones[sce.bone_target37].name = sce.bone_target37 +"MBRF"
            bpy.context.scene.bone_target37 = sce.bone_target37+"MBRF"
        
        
        
        if sce.bone_target38 !="" :
            
            bpy.context.object.data.bones[sce.bone_target38].name = sce.bone_target38 +"MBRF"
            bpy.context.scene.bone_target38 = sce.bone_target38+"MBRF"
        
       
        if sce.bone_target39 !="" :
            
            bpy.context.object.data.bones[sce.bone_target39].name = sce.bone_target39 +"MBRF"
            bpy.context.scene.bone_target39 = sce.bone_target39+"MBRF"
       
       

        if sce.bone_target40 !="" :
            
            bpy.context.object.data.bones[sce.bone_target40].name = sce.bone_target40 +"MBRF"
            bpy.context.scene.bone_target40 = sce.bone_target40+"MBRF"
       
       
       
        if sce.bone_targetHip !="" :
        
            bpy.context.object.data.bones[sce.bone_targetHip].name = sce.bone_targetHip+"MBRF"
            bpy.context.scene.bone_targetHip = sce.bone_targetHip+"MBRF"  
        
        
        
        
        
        
        ########Fingers
        
        if sce.bone_target60 !="" :
            
            bpy.context.object.data.bones[sce.bone_target60].name = sce.bone_target60 +"MBRF"
            bpy.context.scene.bone_target60 = sce.bone_target60+"MBRF"
        
        
       
        
        if sce.bone_target61 !="" :
            
            bpy.context.object.data.bones[sce.bone_target61].name = sce.bone_target61 +"MBRF"
            bpy.context.scene.bone_target61 = sce.bone_target61+"MBRF"
        
        
        
        
        if sce.bone_target62 !="" :
            
            bpy.context.object.data.bones[sce.bone_target62].name = sce.bone_target62 +"MBRF"
            bpy.context.scene.bone_target62 = sce.bone_target62+"MBRF"  
        
        
        
        if sce.bone_target63 !="" :
            
            bpy.context.object.data.bones[sce.bone_target63].name = sce.bone_target63 +"MBRF"
            bpy.context.scene.bone_target63 = sce.bone_target63+"MBRF" 
        
        
        if sce.bone_target64 !="" :
            
            bpy.context.object.data.bones[sce.bone_target64].name = sce.bone_target64 +"MBRF"
            bpy.context.scene.bone_target64 = sce.bone_target64+"MBRF" 
        
          
        if sce.bone_target65 !="" :
            
            bpy.context.object.data.bones[sce.bone_target65].name = sce.bone_target65 +"MBRF"
            bpy.context.scene.bone_target65 = sce.bone_target65+"MBRF"
        
        
        if sce.bone_target66 !="" :
            
            bpy.context.object.data.bones[sce.bone_target66].name = sce.bone_target66 +"MBRF"
            bpy.context.scene.bone_target66 = sce.bone_target66+"MBRF"  
        
        
        if sce.bone_target67 !="" :
            
            bpy.context.object.data.bones[sce.bone_target67].name = sce.bone_target67 +"MBRF"
            bpy.context.scene.bone_target67 = sce.bone_target67+"MBRF"
        
        
        if sce.bone_target68 !="" :
            
            bpy.context.object.data.bones[sce.bone_target68].name = sce.bone_target68 +"MBRF"
            bpy.context.scene.bone_target68 = sce.bone_target68+"MBRF"
        
        
        if sce.bone_target69 !="" :
            
            bpy.context.object.data.bones[sce.bone_target69].name = sce.bone_target69 +"MBRF"
            bpy.context.scene.bone_target69 = sce.bone_target69+"MBRF"
        
        
        
        if sce.bone_target70 !="" :
            
            bpy.context.object.data.bones[sce.bone_target70].name = sce.bone_target70 +"MBRF"
            bpy.context.scene.bone_target70 = sce.bone_target70+"MBRF"
        
        
        if sce.bone_target71 !="" :
            
            bpy.context.object.data.bones[sce.bone_target71].name = sce.bone_target71 +"MBRF"
            bpy.context.scene.bone_target71 = sce.bone_target71+"MBRF"
        
        
        if sce.bone_target72 !="" :
            
            bpy.context.object.data.bones[sce.bone_target72].name = sce.bone_target72 +"MBRF"
            bpy.context.scene.bone_target72 = sce.bone_target72+"MBRF"
        
        
        if sce.bone_target73 !="" :
            
            bpy.context.object.data.bones[sce.bone_target73].name = sce.bone_target73 +"MBRF"
            bpy.context.scene.bone_target73 = sce.bone_target73+"MBRF"
        
       
       
       
        if sce.bone_target74 !="" :
            
            bpy.context.object.data.bones[sce.bone_target74].name = sce.bone_target74 +"MBRF"
            bpy.context.scene.bone_target74 = sce.bone_target74+"MBRF"
        
        if sce.bone_target75 !="" :
            
            bpy.context.object.data.bones[sce.bone_target75].name = sce.bone_target75 +"MBRF"
            bpy.context.scene.bone_target75 = sce.bone_target75+"MBRF"
        
        
        if sce.bone_target76 !="" :
            
            bpy.context.object.data.bones[sce.bone_target76].name = sce.bone_target76 +"MBRF"
            bpy.context.scene.bone_target76 = sce.bone_target76+"MBRF"
        
        
        if sce.bone_target77 !="" :
            
            bpy.context.object.data.bones[sce.bone_target77].name = sce.bone_target77 +"MBRF"
            bpy.context.scene.bone_target77 = sce.bone_target77+"MBRF"
        
        
        
        if sce.bone_target78 !="" :
            
            bpy.context.object.data.bones[sce.bone_target78].name = sce.bone_target78 +"MBRF"
            bpy.context.scene.bone_target78 = sce.bone_target78+"MBRF"
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        ########## finger rrrrrrrrrr
        
        if sce.bone_target41 !="" :
            
            bpy.context.object.data.bones[sce.bone_target41].name = sce.bone_target41 +"MBRF"
            bpy.context.scene.bone_target41 = sce.bone_target41+"MBRF"
        
        
        if sce.bone_target42 !="" :
            
            bpy.context.object.data.bones[sce.bone_target42].name = sce.bone_target42 +"MBRF"
            bpy.context.scene.bone_target42 = sce.bone_target42+"MBRF"
        
        
        
        if sce.bone_target43 !="" :
            
            bpy.context.object.data.bones[sce.bone_target43].name = sce.bone_target43 +"MBRF"
            bpy.context.scene.bone_target43 = sce.bone_target43+"MBRF"
        
        
        if sce.bone_target44 !="" :
            
            bpy.context.object.data.bones[sce.bone_target44].name = sce.bone_target44 +"MBRF"
            bpy.context.scene.bone_target44 = sce.bone_target44+"MBRF"
        
        
        
        if sce.bone_target45 !="" :
            
            bpy.context.object.data.bones[sce.bone_target45].name = sce.bone_target45 +"MBRF"
            bpy.context.scene.bone_target45 = sce.bone_target45+"MBRF"
        
        
        if sce.bone_target46 !="" :
            
            bpy.context.object.data.bones[sce.bone_target46].name = sce.bone_target46 +"MBRF"
            bpy.context.scene.bone_target46 = sce.bone_target46+"MBRF"
        
        
        
        if sce.bone_target47 !="" :
            
            bpy.context.object.data.bones[sce.bone_target47].name = sce.bone_target47 +"MBRF"
            bpy.context.scene.bone_target47 = sce.bone_target47+"MBRF"  
        
        
        
        if sce.bone_target48 !="" :
            
            bpy.context.object.data.bones[sce.bone_target48].name = sce.bone_target48 +"MBRF"
            bpy.context.scene.bone_target48 = sce.bone_target48+"MBRF"
        
        
        
        if sce.bone_target49 !="" :
            
            bpy.context.object.data.bones[sce.bone_target49].name = sce.bone_target49 +"MBRF"
            bpy.context.scene.bone_target49 = sce.bone_target49+"MBRF"
        
        
        
        if sce.bone_target50 !="" :
            
            bpy.context.object.data.bones[sce.bone_target50].name = sce.bone_target50 +"MBRF"
            bpy.context.scene.bone_target50 = sce.bone_target50+"MBRF"
        
        
        if sce.bone_target51 !="" :
            
            bpy.context.object.data.bones[sce.bone_target51].name = sce.bone_target51 +"MBRF"
            bpy.context.scene.bone_target51 = sce.bone_target51+"MBRF"
        
        
        if sce.bone_target52 !="" :
            
            bpy.context.object.data.bones[sce.bone_target52].name = sce.bone_target52 +"MBRF"
            bpy.context.scene.bone_target52 = sce.bone_target52+"MBRF"
        
        
        
        if sce.bone_target53 !="" :
            
            bpy.context.object.data.bones[sce.bone_target53].name = sce.bone_target53 +"MBRF"
            bpy.context.scene.bone_target53 = sce.bone_target53+"MBRF"
        
        
        if sce.bone_target54 !="" :
            
            bpy.context.object.data.bones[sce.bone_target54].name = sce.bone_target54 +"MBRF"
            bpy.context.scene.bone_target54 = sce.bone_target54+"MBRF"
        
        
        if sce.bone_target55 !="" :
            
            bpy.context.object.data.bones[sce.bone_target55].name = sce.bone_target55 +"MBRF"
            bpy.context.scene.bone_target55 = sce.bone_target55+"MBRF"
        
        
        
        if sce.bone_target56 !="" :
            
            bpy.context.object.data.bones[sce.bone_target56].name = sce.bone_target56 +"MBRF"
            bpy.context.scene.bone_target56 = sce.bone_target56+"MBRF"
        
        
        if sce.bone_target57 !="" :
            
            bpy.context.object.data.bones[sce.bone_target57].name = sce.bone_target57 +"MBRF"
            bpy.context.scene.bone_target57 = sce.bone_target57+"MBRF"
        
        
        if sce.bone_target58 !="" :
            
            bpy.context.object.data.bones[sce.bone_target58].name = sce.bone_target58 +"MBRF"
            bpy.context.scene.bone_target58 = sce.bone_target58+"MBRF"
        
        
        if sce.bone_target59 !="" :
            
            bpy.context.object.data.bones[sce.bone_target59].name = sce.bone_target59 +"MBRF"
            bpy.context.scene.bone_target59 = sce.bone_target59+"MBRF"
        
        


        

        if sce.bone_target2 !="" :
            
            bpy.context.object.data.bones[sce.bone_target2].name = sce.bone_target2 +"MBRF"
            bpy.context.scene.bone_target2 = sce.bone_target2+"MBRF"


        if sce.bone_target5 !="" :
            
            bpy.context.object.data.bones[sce.bone_target5].name = sce.bone_target5 +"MBRF"
            bpy.context.scene.bone_target5 = sce.bone_target5+"MBRF"


        if sce.bone_target10 !="" :
            
            bpy.context.object.data.bones[sce.bone_target10].name = sce.bone_target10 +"MBRF"
            bpy.context.scene.bone_target10 = sce.bone_target10+"MBRF"


        if sce.bone_target13 !="" :
            
            bpy.context.object.data.bones[sce.bone_target13].name = sce.bone_target13 +"MBRF"
            bpy.context.scene.bone_target13 = sce.bone_target13+"MBRF"


       
       
        if sce.bone_target19 !="" :
            
            bpy.context.object.data.bones[sce.bone_target19].name = sce.bone_target19 +"MBRF"
            bpy.context.scene.bone_target19 = sce.bone_target19+"MBRF"
        


        if sce.bone_target22 !="" :
            
            bpy.context.object.data.bones[sce.bone_target22].name = sce.bone_target22 +"MBRF"
            bpy.context.scene.bone_target22 = sce.bone_target22+"MBRF"
       
       
       
       
        if sce.bone_target27 !="" :
            
            bpy.context.object.data.bones[sce.bone_target27].name = sce.bone_target27 +"MBRF"
            bpy.context.scene.bone_target27 = sce.bone_target27+"MBRF"

        if sce.bone_target30 !="" :
            
            bpy.context.object.data.bones[sce.bone_target30].name = sce.bone_target30 +"MBRF"
            bpy.context.scene.bone_target30 = sce.bone_target30+"MBRF"












        
        bpy.ops.object.select_all(action='DESELECT')
                
        objectToSelect = bpy.data.objects[sce.Armature_Target] 
        objectToSelect.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data

        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("CenterBrow") 
        if  bonein is not None:
            
            print("gg")
            bpy.context.object.data.bones["CenterBrow"].name = "qqcenterbrowqq"


        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("Nose") 
        if  bonein is not None:
            
            print("gg")
            bpy.context.object.data.bones["Nose"].name = "qnoseq"
        
        
        

        bpy.ops.object.mode_set(mode='EDIT')

        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')
        
        
        
        
        
        
        
 
        
        
        return {'FINISHED'}
  






class setnameue_op(bpy.types.Operator):
    bl_label = "  "
    bl_idname = "setnameues.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene


         
     

        # Replace 'YourArmature' with the actual name of your armature
        armature_name = sce.Armature_Target

        # Replace 'bone1', 'bone2', 'bone3' with the actual names of your bones
        target_bones = ['pelvis']

        # Get the armature object
        armature_obj = bpy.data.objects.get(armature_name)

        # Check if the armature object exists
        if armature_obj:
            # Get the armature data
            armature_data = armature_obj.data
            
            # Iterate through the target bones
            for bone_name in target_bones:
                # Check if the bone exists in the armature
                if bone_name in armature_data.bones:
                    # Get the bone
                    bone = armature_data.bones[bone_name]
                    
                    # Modify the bone name by adding "_RF"
                    new_bone_name = bone_name + "_RF"
                    
                    # Rename the bone
                    bone.name = new_bone_name
                    
                    print(f"Renamed '{bone_name}' to '{new_bone_name}' in armature '{armature_name}'.")
                else:
                    print(f"Bone '{bone_name}' not found in armature '{armature_name}'.")
        else:
            print(f"Armature '{armature_name}' not found.")

       
    
       

 
         
        
        
        
        
        
 
        
        
        return {'FINISHED'}
  






















 

 


 
