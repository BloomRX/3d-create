import bpy
import json
import os
import bmesh 
import math




def makeuerigshouder():

    bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
    bpy.context.active_object.name = 'RF_Pose_shoul_AR'

    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["RF_Pose_shoul_AR"]
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    
    for obj in bpy.context.selected_objects:
        obj.name = "RF_Pose_shoul"
        obj.data.name = "RF_Pose_shoul"


    
    
    #///////////Naming
    bpy.ops.object.select_all(action='DESELECT')
        
    objectToSelect = bpy.data.objects["RF_Pose_shoul"] 
    objectToSelect.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect
    ob = bpy.data.objects["RF_Pose_shoul"] 
    armature = ob.data

            
    bpy.context.object.data.bones["Bone"].name = "temp"

    bpy.ops.object.mode_set(mode='EDIT')

    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')      
   
    bpy.ops.object.select_all(action='DESELECT')

    #////clavicle_l
    objectToSelect = bpy.data.objects["RF_Pose_shoul"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("clavicle_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')





    objectToSelect2 = bpy.data.objects["RF_Pose_shoul"] 
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_Pose_shoul"] 
    armature = ob.data

    bpy.ops.object.mode_set(mode='EDIT')
    
    
    



    objectToSelect.data.edit_bones['clavicle_l'].head[0] = 1.4279
    objectToSelect.data.edit_bones['clavicle_l'].head[1] = 1.7398
    objectToSelect.data.edit_bones['clavicle_l'].head[2] = 146.301
    objectToSelect.data.edit_bones['clavicle_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['clavicle_l'].tail[0] = 19.0099
    objectToSelect.data.edit_bones['clavicle_l'].tail[1] = 2.5572
    objectToSelect.data.edit_bones['clavicle_l'].tail[2] = 143.584
    objectToSelect.data.edit_bones['clavicle_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['clavicle_l'].roll = -2.99169
    objectToSelect.data.edit_bones['clavicle_l'].length = 17.8095
    objectToSelect.data.edit_bones['clavicle_l'].envelope_distance = 0.25



    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')



    #RRRRRRRRRRRRRRR


    #////clavicle_r
    objectToSelect = bpy.data.objects["RF_Pose_shoul"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("clavicle_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')




    objectToSelect2 = bpy.data.objects["RF_Pose_shoul"] 
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_Pose_shoul"] 
    armature = ob.data

    bpy.ops.object.mode_set(mode='EDIT')
    
    
    

    objectToSelect.data.edit_bones['clavicle_r'].head[0] = -1.4279
    objectToSelect.data.edit_bones['clavicle_r'].head[1] = 1.7399
    objectToSelect.data.edit_bones['clavicle_r'].head[2] =  146.301
    objectToSelect.data.edit_bones['clavicle_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['clavicle_r'].tail[0] = -19.0099
    objectToSelect.data.edit_bones['clavicle_r'].tail[1] = 2.5573
    objectToSelect.data.edit_bones['clavicle_r'].tail[2] = 143.583
    objectToSelect.data.edit_bones['clavicle_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['clavicle_r'].roll = 2.99169
    objectToSelect.data.edit_bones['clavicle_r'].length = 17.8096
    objectToSelect.data.edit_bones['clavicle_r'].envelope_distance = 0.25



    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')


def makeuerigfootfix():

    bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
    bpy.context.active_object.name = 'RF_Rig_AR'

    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["RF_Rig_AR"]
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    
    for obj in bpy.context.selected_objects:
        obj.name = "RF_Rig"
        obj.data.name = "RF_Rig"
    
    
    #///////////Naming
    bpy.ops.object.select_all(action='DESELECT')
        
    objectToSelect = bpy.data.objects["RF_Rig"] 
    objectToSelect.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect
    ob = bpy.data.objects["RF_Rig"] 
    armature = ob.data

            
    bpy.context.object.data.bones["Bone"].name = "temp"

    bpy.ops.object.mode_set(mode='EDIT')

    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')
   
    bpy.ops.object.select_all(action='DESELECT')
 



    #////foot_l
    objectToSelect = bpy.data.objects["RF_Rig"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("foot_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')





    objectToSelect2 = bpy.data.objects["RF_Rig"] 
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_Rig"] 
    armature = ob.data

    bpy.ops.object.mode_set(mode='EDIT')
    
    
    


    objectToSelect.data.edit_bones['foot_l'].head[0] = 14.0877
    objectToSelect.data.edit_bones['foot_l'].head[1] = 0.9943
    objectToSelect.data.edit_bones['foot_l'].head[2] =  8.2376
    objectToSelect.data.edit_bones['foot_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['foot_l'].tail[0] = 11.6034
    objectToSelect.data.edit_bones['foot_l'].tail[1] = 17.582
    objectToSelect.data.edit_bones['foot_l'].tail[2] = 8.7672
    objectToSelect.data.edit_bones['foot_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['foot_l'].roll = -1.56847
    objectToSelect.data.edit_bones['foot_l'].length = 16.7811
    objectToSelect.data.edit_bones['foot_l'].envelope_distance = 0.25



    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')





    #////ball_l
    objectToSelect = bpy.data.objects["RF_Rig"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ball_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')





    objectToSelect2 = bpy.data.objects["RF_Rig"] 
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_Rig"] 
    armature = ob.data

    bpy.ops.object.mode_set(mode='EDIT')
    
    
    


    objectToSelect.data.edit_bones['ball_l'].head[0] = 15.7779
    objectToSelect.data.edit_bones['ball_l'].head[1] = -13.9288
    objectToSelect.data.edit_bones['ball_l'].head[2] =  0.7508
    objectToSelect.data.edit_bones['ball_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ball_l'].tail[0] = 15.8559
    objectToSelect.data.edit_bones['ball_l'].tail[1] = -14.4526
    objectToSelect.data.edit_bones['ball_l'].tail[2] = 17.5236
    objectToSelect.data.edit_bones['ball_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ball_l'].roll = -1.41742
    objectToSelect.data.edit_bones['ball_l'].length = 16.7812
    objectToSelect.data.edit_bones['ball_l'].envelope_distance = 0.25



    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')



    ####RRRRRRRRRRRRRRR




    #////foot_r
    objectToSelect = bpy.data.objects["RF_Rig"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("foot_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')





    objectToSelect2 = bpy.data.objects["RF_Rig"] 
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_Rig"] 
    armature = ob.data

    bpy.ops.object.mode_set(mode='EDIT')
    
    
    


    objectToSelect.data.edit_bones['foot_r'].head[0] = -14.0876
    objectToSelect.data.edit_bones['foot_r'].head[1] = 0.9848
    objectToSelect.data.edit_bones['foot_r'].head[2] = 8.2382
    objectToSelect.data.edit_bones['foot_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['foot_r'].tail[0] = -16.5718
    objectToSelect.data.edit_bones['foot_r'].tail[1] = -15.603
    objectToSelect.data.edit_bones['foot_r'].tail[2] = 7.7087
    objectToSelect.data.edit_bones['foot_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['foot_r'].roll = 1.15308
    objectToSelect.data.edit_bones['foot_r'].length = 16.7811
    objectToSelect.data.edit_bones['foot_r'].envelope_distance = 0.25



    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')




    #////ball_r
    objectToSelect = bpy.data.objects["RF_Rig"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ball_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')





    objectToSelect2 = bpy.data.objects["RF_Rig"] 
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_Rig"] 
    armature = ob.data

    bpy.ops.object.mode_set(mode='EDIT')
    
    
    


    objectToSelect.data.edit_bones['ball_r'].head[0] = -15.7777
    objectToSelect.data.edit_bones['ball_r'].head[1] = -13.9382
    objectToSelect.data.edit_bones['ball_r'].head[2] = 0.7514
    objectToSelect.data.edit_bones['ball_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ball_r'].tail[0] = -15.6997
    objectToSelect.data.edit_bones['ball_r'].tail[1] = -13.4145
    objectToSelect.data.edit_bones['ball_r'].tail[2] = -16.0214
    objectToSelect.data.edit_bones['ball_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ball_r'].roll = -1.42672
    objectToSelect.data.edit_bones['ball_r'].length = 16.7812
    objectToSelect.data.edit_bones['ball_r'].envelope_distance = 0.25



    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')



    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["RF_Rig"]
    objectToSelect2.select_set(True)

    ob = bpy.data.objects['RF_Rig']

    bpy.ops.object.mode_set(mode='POSE')

    pbone = ob.pose.bones["foot_l"]
    # Set rotation mode to Euler XYZ, easier to understand
    # than default quaternions
    pbone.rotation_mode = 'XYZ'
    # select axis in ['X','Y','Z']  <--bone local
    axis = 'X'
    angle = 180
    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
    bpy.ops.object.mode_set(mode='OBJECT')


    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["RF_Rig"]
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_Rig"] 
    armature = ob.data
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='SELECT')
    
    bpy.ops.object.posemode_toggle()

    bpy.ops.pose.armature_apply(selected=False)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')



    objectToSelect = bpy.data.objects["RF_Rig"] 
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect
    
    ob = bpy.data.objects["RF_Rig"]
    armature = ob.data
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    myBone = armature.edit_bones['ball_l']
    myBone2 = armature.edit_bones['foot_l']
    myBone.select = True
    myBone2.select = True
    armature.edit_bones.active = myBone2
    bpy.ops.armature.parent_set(type='OFFSET')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')


    objectToSelect = bpy.data.objects["RF_Rig"] 
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect
    
    ob = bpy.data.objects["RF_Rig"]
    armature = ob.data
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    myBone = armature.edit_bones['ball_r']
    myBone2 = armature.edit_bones['foot_r']
    myBone.select = True
    myBone2.select = True
    armature.edit_bones.active = myBone2
    bpy.ops.armature.parent_set(type='OFFSET')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')


class Getue_Shoulderfix(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Fix Shoulder"
    bl_idname = "mb.sholdfic"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        if mytool.my_bool29 !=False and mytool.my_string40 ==False :

        
            makeuerigshouder()

            
        
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["RF_Pose_shoul"]   
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]  
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            
            objectToSelect = bpy.data.objects["RF_Pose_shoul"]   
            objectToSelect2 = bpy.data.objects[sce.Armature_Target] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["RF_Pose_shoul"]  
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones["clavicle_l"] 
            b.select=True
            ob.data.bones.active=b
            ob2 = bpy.data.objects[sce.Armature_Target]  
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target17]  
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["RF_Pose_shoul"]  
            objectToSelect2 = bpy.data.objects[sce.Armature_Target] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect 
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 


            
            
            objectToSelect = bpy.data.objects["RF_Pose_shoul"] 
            objectToSelect2 = bpy.data.objects[sce.Armature_Target] 
            objectToSelect.select_set(True)    
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects["RF_Pose_shoul"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='POSE')
            b=ob.data.bones["clavicle_r"] 
            b.select=True
            ob.data.bones.active=b
            ob2 = bpy.data.objects[sce.Armature_Target] 
            armature = ob2.data
            b=ob2.data.bones[sce.bone_target25] 
            b.select=True
            ob2.data.bones.active=b
            bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT') 



            #///Apply  pose

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_Pose_shoul"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            #Mirror 
            bpy.context.object.data.use_mirror_x = False
            
            ob = bpy.data.objects["RF_Pose_shoul"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='SELECT')
            
            bpy.ops.object.posemode_toggle()

            bpy.ops.pose.armature_apply(selected=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')





            armatureFrom = bpy.data.objects["RF_Pose_shoul"]
            armatureTo = bpy.data.objects["RF_Pose_shoul"]

            for boneTo in armatureTo.pose.bones:
                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                if boneFrom == None:
                    continue

                for con in boneTo.constraints:
                    boneTo.constraints.remove(con)

            

            bpy.ops.object.select_all(action='DESELECT')
                
            objectToSelect = bpy.data.objects[sce.Armature_Target] 
            objectToSelect.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect
            ob = bpy.data.objects[sce.Armature_Target] 
            armature = ob.data
            
            
            
            
            objectToSelect2 = bpy.data.objects["RF_Pose_shoul"] 
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            ob = bpy.data.objects["RF_Pose_shoul"] 
            armature = ob.data
            
            bpy.ops.object.mode_set(mode='EDIT')
            
            
        

            #////DEF-shoulder.L
            if sce.bone_target17 !="" and  sce.bone_target25 !="":
    
                objectToSelect.data.edit_bones[sce.bone_target17].tail[2] = objectToSelect2.data.edit_bones['clavicle_l'].tail[2]

                objectToSelect.data.edit_bones[sce.bone_target25].tail[2] = objectToSelect2.data.edit_bones['clavicle_r'].tail[2]


                objectToSelect.data.edit_bones[sce.bone_target18].head[2] = objectToSelect2.data.edit_bones['clavicle_l'].tail[2]

                objectToSelect.data.edit_bones[sce.bone_target26].head[2] = objectToSelect2.data.edit_bones['clavicle_r'].tail[2]


        

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')







            objectToSelect2 = bpy.data.objects["RF_Pose_shoul"] 
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            ob = bpy.data.objects["RF_Pose_shoul"] 
            armature = ob.data
            
            bpy.ops.object.mode_set(mode='EDIT')
            
            
        

            #////DEF-shoulder.L
            if sce.bone_target17 !="" and  sce.bone_target25 !="":
    
            

                objectToSelect.data.edit_bones[sce.bone_target17].head[0] = 1.4279

                objectToSelect.data.edit_bones[sce.bone_target25].head[0] = -1.4279


        

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')

            bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            bpy.context.active_object.name = 'AU5Clavicle_PosMatching_On'











            objects = bpy.context.scene.objects.keys()
            if  'RF_Pose_shoul' in objects:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["RF_Pose_shoul"]
                objectToSelect2.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.delete(use_global=False)
                bpy.ops.object.select_all(action='DESELECT')





        

        
        return {'FINISHED'}
    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)

 

