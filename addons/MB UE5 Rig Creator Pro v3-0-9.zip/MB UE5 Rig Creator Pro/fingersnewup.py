

import bpy

import math

  
 
class fingersnew_OT_op(bpy.types.Operator):
    bl_label = "fn"
    bl_idname = "fingersnew.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene



        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :

            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.R")
            if  bonein is not None and bonein2 is  not None:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects["Fingers_Direction"]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones["thumb_Dir.L"] 
                b.select=True
                ob.data.bones.active=b
                bpy.context.object.pose.use_mirror_x = False
                bpy.context.active_pose_bone.scale[1] = -1
                bpy.ops.object.mode_set(mode='OBJECT')

                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects["Fingers_Direction"] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()
                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')

            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("index_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("index_Dir.R")
            if  bonein is not None and bonein2 is not None:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects["Fingers_Direction"]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones["index_Dir.L"] 
                b.select=True
                ob.data.bones.active=b
                bpy.context.object.pose.use_mirror_x = False
                bpy.context.active_pose_bone.scale[1] = -1
                bpy.ops.object.mode_set(mode='OBJECT')

                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects["Fingers_Direction"] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()
          
                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')

            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("middle_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("middle_Dir.R")
            if  bonein is not None and bonein2 is not None:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects["Fingers_Direction"]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones["middle_Dir.L"] 
                b.select=True
                ob.data.bones.active=b
                bpy.context.object.pose.use_mirror_x = False
                bpy.context.active_pose_bone.scale[1] = -1
                bpy.ops.object.mode_set(mode='OBJECT')

                
                
                
                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects["Fingers_Direction"] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()
              

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')

          
          
          
          
            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("ring_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("ring_Dir.R")
            if  bonein is not None and bonein2 is not None:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects["Fingers_Direction"]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones["ring_Dir.L"] 
                b.select=True
                ob.data.bones.active=b
                bpy.context.object.pose.use_mirror_x = False
                bpy.context.active_pose_bone.scale[1] = -1
                bpy.ops.object.mode_set(mode='OBJECT')

                
                
                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects["Fingers_Direction"] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                bpy.ops.object.posemode_toggle()
              


                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')

            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("pinky_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("pinky_Dir.R")
            if  bonein is not None and bonein2 is not None:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects["Fingers_Direction"]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones["pinky_Dir.L"] 
                b.select=True
                ob.data.bones.active=b
                bpy.context.object.pose.use_mirror_x = False
                bpy.context.active_pose_bone.scale[1] = -1
                bpy.ops.object.mode_set(mode='OBJECT')

                
                
                
                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects["Fingers_Direction"] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()
                
                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')
            


            # Handsssss
            
            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("hand_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("hand_Dir.R")
            if  bonein is not None and bonein2 is not None:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects["Fingers_Direction"]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones["hand_Dir.L"] 
                b.select=True
                ob.data.bones.active=b
                bpy.context.object.pose.use_mirror_x = False
                bpy.context.active_pose_bone.scale[1] = -1
                bpy.ops.object.mode_set(mode='OBJECT')
                
                 
                

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects["Fingers_Direction"] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')
                
                ob = bpy.data.objects["Fingers_Direction"]
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                myBone = armature.edit_bones["hand_Dir.L"]    
                #myBone.select_head = True 
                myBone.select_tail = True   
                bpy.ops.view3d.snap_cursor_to_selected()
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')
                
                
                #Addbone
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Fingers_Direction"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
            
                
                ebs = objectToSelect.data.edit_bones
                eb = ebs.new("Fixhand_Dir.L")
                eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                eb.tail = (0, 1, 2)    # upon returning to object mode
                eb.length = 5

                #////Snip to cursor
                eb.select_head = True    
                eb.select_tail = True
                bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')   
                
                
                
                
                
                
                
                
                
                
                
                
                
                
                



            objects = bpy.context.scene.objects.keys()
            if  'Fingers_Direction' in objects :
                
                bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("hand_Dir.L")
                bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("hand_Dir.R")
                if  bonein is not None and bonein2 is not None:


                    # armature1 = bpy.data.objects[sce.Armature_Target]
                    # armature2 = bpy.data.objects['Fingers_Direction']
                    
                    # bones_to_select = ['hand_l']
                    
            
            

                    # for numbone in range (0,1): 
                            
                            
                    #     selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                        
                            
                    #     neckconstraint = selected_bone.constraints
                    #     neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    #     neckCopyRot.target = armature2  
                    #     neckCopyRot.subtarget = "hand_Dir.L"
                        
                    
                    
                    
                    
                    #DAMPED_TRACK
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    armature2 = bpy.data.objects['Fingers_Direction']
                    
                    bones_to_select = ['hand_l']
                    
            
            

                    for numbone in range (0,1): 
                            
                            
                        selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                        
                            
                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature2  
                        neckCopyRot.subtarget = "Fixhand_Dir.L"
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    armature2 = bpy.data.objects['Fingers_Direction']
                    
                    bones_to_select = ['hand_r']
                    
            
            

                    for numbone in range (0,1): 
                            
                            
                        selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                        
                            
                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature2  
                        neckCopyRot.subtarget = "hand_Dir.R"
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                         
                
                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)
                
                
                
                
            
            
            
            








        
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        armature1 = bpy.data.objects[sce.Armature_Target]
        
        bones_to_select = ['index_metacarpal_l','middle_metacarpal_l','ring_metacarpal_l',
        'pinky_metacarpal_l','index_01_l','index_02_l'
        ,'index_03_l','middle_01_l','middle_02_l','middle_03_l','ring_01_l','ring_02_l','ring_03_l','pinky_01_l','pinky_02_l','pinky_03_l']

        for numbone in range (0,16): 
                
            selected_bone = armature1.pose.bones[bones_to_select[numbone]]

            
                
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature1  
            neckCopyRot.subtarget = "hand_l"
       




        bones_to_select = ['index_metacarpal_r','middle_metacarpal_r','ring_metacarpal_r',
        'pinky_metacarpal_r','index_01_r','index_02_r'
        ,'index_03_r','middle_01_r','middle_02_r','middle_03_r','ring_01_r','ring_02_r','ring_03_r','pinky_01_r','pinky_02_r','pinky_03_r']

        for numbone in range (0,16): 
                
            selected_bone = armature1.pose.bones[bones_to_select[numbone]]

            
                
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature1  
            neckCopyRot.subtarget = "hand_r" 




        bpy.ops.screen.frame_jump(end=False)
        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)



        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :
        
            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("pinky_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("pinky_Dir.R")
            if  bonein is not None and bonein2 is not None:


                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['pinky_01_l','pinky_02_l','pinky_02_l','pinky_metacarpal_l']
        
        

                for numbone in range (0,4): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
            
                    neckCopyRot.subtarget = "pinky_Dir.L"


                
                bpy.ops.screen.frame_jump(end=False)
                #Apply
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)



         


        #pinky_01_l 
        armature1 = bpy.data.objects[sce.Armature_Target]
        selected_bone = armature1.pose.bones["pinky_01_l"]
        selected_bone2 = armature1.pose.bones["pinky_02_l"]
        selected_bone3 = armature1.pose.bones["pinky_metacarpal_l"]
        selected_bone4 = armature1.pose.bones["pinky_03_l"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'


        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_02_l"
        
        
        
        
        
        

        
        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :
        
            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("ring_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("ring_Dir.R")
            if  bonein is not None and bonein2 is not None:


                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['ring_01_l','ring_02_l','ring_03_l','ring_metacarpal_l']
        
        

                for numbone in range (0,4): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
            
                    neckCopyRot.subtarget = "ring_Dir.L"

    




                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)


        

         
        #ring_01_l 
        selected_bone = armature1.pose.bones["ring_01_l"]
        selected_bone2 = armature1.pose.bones["ring_02_l"]
        selected_bone3 = armature1.pose.bones["ring_metacarpal_l"]
        selected_bone4 = armature1.pose.bones["ring_03_l"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
        
        
        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_02_l"

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("middle_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("middle_Dir.R")
            if  bonein is not None and bonein2 is not None:


                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['middle_01_l','middle_02_l','middle_03_l','middle_metacarpal_l']
        
        

                for numbone in range (0,4): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
            
                    neckCopyRot.subtarget = "middle_Dir.L"



                
                
                
                bpy.ops.screen.frame_jump(end=False)
                #Apply
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)


 



        #middle_01_l 
        selected_bone = armature1.pose.bones["middle_01_l"]
        selected_bone2 = armature1.pose.bones["middle_02_l"]
        selected_bone3 = armature1.pose.bones["middle_metacarpal_l"]
        selected_bone4 = armature1.pose.bones["middle_03_l"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_02_l"
        
        
        
        
        
        

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("index_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("index_Dir.R")
            if  bonein is not None and bonein2 is not None:

                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['index_01_l','index_02_l','index_03_l','index_metacarpal_l']
        
        

                for numbone in range (0,4): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
            
                    neckCopyRot.subtarget = "index_Dir.L"
    



                bpy.ops.screen.frame_jump(end=False)
                #Apply
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)


        

        #index_01_l 
        selected_bone = armature1.pose.bones["index_01_l"]
        selected_bone2 = armature1.pose.bones["index_02_l"]
        selected_bone3 = armature1.pose.bones["index_metacarpal_l"]
        selected_bone4 = armature1.pose.bones["index_03_l"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_02_l"
        
        
        
        
        
        
        
        





        # RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("pinky_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("pinky_Dir.R")
            if  bonein is not None and bonein2 is not None:

                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['pinky_01_r','pinky_02_r','pinky_03_r','pinky_metacarpal_r']
        
        

                for numbone in range (0,4): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
            
                    neckCopyRot.subtarget = "pinky_Dir.R"

        


                bpy.ops.screen.frame_jump(end=False)
                #Apply
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)










        
        #pinky_01_r
        armature1 = bpy.data.objects[sce.Armature_Target]
        selected_bone = armature1.pose.bones["pinky_01_r"]
        selected_bone2 = armature1.pose.bones["pinky_02_r"]
        selected_bone3 = armature1.pose.bones["pinky_metacarpal_r"]
        selected_bone4 = armature1.pose.bones["pinky_03_r"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_02_r"
        
        
        
        
        
        

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :
        
            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("ring_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("ring_Dir.R")
            if  bonein is not None and bonein2 is not None:

                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['ring_01_r','ring_02_r','ring_03_r','ring_metacarpal_r']
        
        

                for numbone in range (0,4): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
            
                    neckCopyRot.subtarget = "ring_Dir.R"




                bpy.ops.screen.frame_jump(end=False)
                #Apply
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)







         
        #ring_01_r
        selected_bone = armature1.pose.bones["ring_01_r"]
        selected_bone2 = armature1.pose.bones["ring_02_r"]
        selected_bone3 = armature1.pose.bones["ring_metacarpal_r"]
        selected_bone4 = armature1.pose.bones["ring_03_r"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
        
        
        



        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_02_r"

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("middle_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("middle_Dir.R")
            if  bonein is not None and bonein2 is not None:

                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['middle_01_r','middle_02_r','middle_03_r','middle_metacarpal_r']
        
        

                for numbone in range (0,4): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
            
                    neckCopyRot.subtarget = "middle_Dir.R"





                bpy.ops.screen.frame_jump(end=False)
                #Apply
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)










        #middle_01_r
        selected_bone = armature1.pose.bones["middle_01_r"]
        selected_bone2 = armature1.pose.bones["middle_02_r"]
        selected_bone3 = armature1.pose.bones["middle_metacarpal_r"]
        selected_bone4 = armature1.pose.bones["middle_03_r"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_02_r"
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :



            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("index_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("index_Dir.R")
            if  bonein is not None and bonein2 is not None:

                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['index_01_r','index_02_r','index_03_r','index_metacarpal_r']
        
        

                for numbone in range (0,4): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
            
                    neckCopyRot.subtarget = "index_Dir.R"




                bpy.ops.screen.frame_jump(end=False)
                #Apply
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.armature_apply(selected=False)
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)











        

        #index_01_r
        selected_bone = armature1.pose.bones["index_01_r"]
        selected_bone2 = armature1.pose.bones["index_02_r"]
        selected_bone3 = armature1.pose.bones["index_metacarpal_r"]
        selected_bone4 = armature1.pose.bones["index_03_r"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_02_r"
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        




        ############### thumb_01_r RRRRRRRRRRR ##########


        bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.L")
        bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.R")

      
        if  bonein is None and bonein2 is None :


            bpy.ops.object.select_all(action='DESELECT')
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones["thumb_01_r"]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("thumb_Fix_r")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            
            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            armature1 = bpy.data.objects[sce.Armature_Target]
            selected_bone = armature1.pose.bones["thumb_Fix_r"]
        


            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
            neckCopyRot.target = armature1
            neckCopyRot.subtarget = "thumb_03_r"
            neckCopyRot.lock_axis = 'LOCK_Y'
            neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'


            armature1 = bpy.data.objects[sce.Armature_Target]
            
            bones_to_select = ['thumb_01_r','thumb_02_r','thumb_03_r']
            
            

            for numbone in range (0,3): 
                    
                selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                
                    
                neckconstraint = selected_bone.constraints
                neckCopyRot = neckconstraint.new('COPY_ROTATION')
                neckCopyRot.target = armature1  
                neckCopyRot.subtarget = "thumb_Fix_r"
        
        
        
        
        
        
        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :
            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.R")
            if  bonein is not None and bonein2 is not None:

             

                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['thumb_01_r','thumb_02_r','thumb_03_r']
                
                

                for numbone in range (0,3): 
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
                    neckCopyRot.subtarget = "thumb_Dir.R"

  

 









        bpy.ops.screen.frame_jump(end=False)
        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)



        #index_01_l 
        selected_bone = armature1.pose.bones["thumb_01_r"]
        selected_bone1 = armature1.pose.bones["thumb_02_r"]
        selected_bone2 = armature1.pose.bones["thumb_02_r"]
        selected_bone3 = armature1.pose.bones["thumb_03_r"]



        neckconstraint = selected_bone1.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_r"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
 

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_r"
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        



        bpy.ops.screen.frame_jump(end=False)
        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)


        






        ##############################################


         ############### thumb_01_l LLLLLLLLLLL ##########

        bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.L")
        bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.R")

      
        if  bonein is None and bonein2 is None :


                bpy.ops.object.select_all(action='DESELECT')
                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                myBone = armature.edit_bones["thumb_01_l"]    
                myBone.select_head = True 
                #myBone.select_tail = True   
                bpy.ops.view3d.snap_cursor_to_selected()
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
                
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                bpy.ops.object.mode_set(mode='EDIT')
            
                
                ebs = objectToSelect.data.edit_bones
                eb = ebs.new("thumb_Fix_l")
                eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                eb.tail = (0, 1, 2)    # upon returning to object mode
                
                #////Snip to cursor
                eb.select_head = True    
                eb.select_tail = True
                bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')


                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)

                ob = bpy.data.objects[sce.Armature_Target]

                bpy.ops.object.mode_set(mode='POSE')

                pbone = ob.pose.bones["thumb_Fix_l"]
                # Set rotation mode to Euler XYZ, easier to understand
                # than default quaternions
                pbone.rotation_mode = 'XYZ'
                # select axis in ['X','Y','Z']  <--bone local
                axis = 'X'
                angle = 180
                pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                bpy.ops.object.mode_set(mode='OBJECT')




                armature1 = bpy.data.objects[sce.Armature_Target]
                selected_bone = armature1.pose.bones["thumb_Fix_l"]
            


                neckconstraint = selected_bone.constraints
                neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                neckCopyRot.target = armature1
                neckCopyRot.subtarget = "thumb_03_l"
                neckCopyRot.lock_axis = 'LOCK_Y'
                neckCopyRot.track_axis = 'TRACK_X'


                armature1 = bpy.data.objects[sce.Armature_Target]
                
                bones_to_select = ['thumb_01_l','thumb_02_l','thumb_03_l']
        
        

                for numbone in range (0,3): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1  
         
                    neckCopyRot.subtarget = "thumb_Fix_l"
        
        
        
        
        
        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :
            bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.L")
            bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.R")
            if  bonein is not None and bonein2 is not None:


                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects['Fingers_Direction']
                
                bones_to_select = ['thumb_01_l','thumb_02_l','thumb_03_l']
        
        

                for numbone in range (0,3): 
                        
                        
                    selected_bone = armature1.pose.bones[bones_to_select[numbone]]

                    
                        
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2  
         
                    neckCopyRot.subtarget = "thumb_Dir.L"

  







        bpy.ops.screen.frame_jump(end=False)
        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)



        
        
        
        
        #thumb_01_l 
        selected_bone = armature1.pose.bones["thumb_01_l"]
        selected_bone1 = armature1.pose.bones["thumb_02_l"]
        selected_bone2 = armature1.pose.bones["thumb_02_l"]
        selected_bone3 = armature1.pose.bones["thumb_03_l"]


        neckconstraint = selected_bone1.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

       



        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_l"
        
        
        
        



        bpy.ops.screen.frame_jump(end=False)
        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)



        
        
        



        
        
        return {'FINISHED'}
  


 
class fingersdirec_OT_op(bpy.types.Operator):
    bl_label = "Fingers Direction"
    bl_idname = "fingerdirec.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.ops.object.posemode_toggle()
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
            

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' not in objects :

            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            bpy.context.active_object.name = 'RF_thumb_AR'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_thumb_AR"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            
            for obj in bpy.context.selected_objects:
                obj.name = "Fingers_Direction"
                obj.data.name = "Fingers_Direction"


        


        bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.L")
        bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("thumb_Dir.R")
        if  bonein is None and bonein2 is  None:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect


        
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target66]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("thumb_Dir.L")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["thumb_Dir.L"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = -90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')





            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

    
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target47]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("thumb_Dir.R")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5
            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["thumb_Dir.R"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = 90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')


            #Apply
            # bpy.ops.object.select_all(action='DESELECT')
            # objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            # objectToSelect2.select_set(True)
            # bpy.context.view_layer.objects.active = objectToSelect2
            # ob = bpy.data.objects["Fingers_Direction"] 
            # armature = ob.data
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='SELECT')
            
            # bpy.ops.object.posemode_toggle()

            # bpy.ops.pose.armature_apply(selected=False)
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='DESELECT')
            # bpy.ops.object.mode_set(mode='OBJECT')



            ##Rest in pose mode
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.posemode_toggle()
            bpy.ops.pose.select_all(action='SELECT')
            bpy.ops.pose.rot_clear()
            bpy.ops.pose.loc_clear()
            bpy.ops.object.mode_set(mode='OBJECT')



            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.context.object.lock_location[0] = True
            bpy.context.object.lock_location[1] = True
            bpy.context.object.lock_location[2] = True
            bpy.context.object.lock_rotation[0] = True
            bpy.context.object.lock_rotation[1] = True
            bpy.context.object.lock_rotation[2] = True
            bpy.context.object.lock_scale[0] = True
            bpy.context.object.lock_scale[1] = True
            bpy.context.object.lock_scale[2] = True
            bpy.context.object.pose.use_mirror_x = True
            bpy.context.object.show_in_front = True
            bpy.context.object.data.show_axes = True
            bpy.context.object.data.axes_position = 1
            bpy.ops.object.posemode_toggle()



            




 




       

        

        
        
        return {'FINISHED'}
  


 
class indexDir_op(bpy.types.Operator):
    bl_label = " index "
    bl_idname = "indexfinger.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.ops.object.posemode_toggle()
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')



        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' not in objects :

            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            bpy.context.active_object.name = 'RF_thumb_AR'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_thumb_AR"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            
            for obj in bpy.context.selected_objects:
                obj.name = "Fingers_Direction"
                obj.data.name = "Fingers_Direction"

        
        

        
        
        bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("index_Dir.L")
        bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("index_Dir.R")
        if  bonein is None and bonein2 is  None:
 
 
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

        
        
         
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target69]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("index_Dir.L")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["index_Dir.L"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = -90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')





            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

    
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target50]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("index_Dir.R")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5
            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["index_Dir.R"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = 90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')


            #Apply
            # bpy.ops.object.select_all(action='DESELECT')
            # objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            # objectToSelect2.select_set(True)
            # bpy.context.view_layer.objects.active = objectToSelect2
            # ob = bpy.data.objects["Fingers_Direction"] 
            # armature = ob.data
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='SELECT')
            
            # bpy.ops.object.posemode_toggle()

            # bpy.ops.pose.armature_apply(selected=False)
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='DESELECT')
            # bpy.ops.object.mode_set(mode='OBJECT')


            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.context.object.lock_location[0] = True
            bpy.context.object.lock_location[1] = True
            bpy.context.object.lock_location[2] = True
            bpy.context.object.lock_rotation[0] = True
            bpy.context.object.lock_rotation[1] = True
            bpy.context.object.lock_rotation[2] = True
            bpy.context.object.lock_scale[0] = True
            bpy.context.object.lock_scale[1] = True
            bpy.context.object.lock_scale[2] = True
            bpy.context.object.pose.use_mirror_x = True
            bpy.context.object.show_in_front = True
            bpy.context.object.data.show_axes = True
            bpy.context.object.data.axes_position = 1
            bpy.ops.object.posemode_toggle()


 

 
       

        

        
        
        return {'FINISHED'}
  


 
class middleDir_op(bpy.types.Operator):
    bl_label = " middle "
    bl_idname = "middlefinger.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.ops.object.posemode_toggle()
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')



        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' not in objects :

            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            bpy.context.active_object.name = 'RF_thumb_AR'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_thumb_AR"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            
            for obj in bpy.context.selected_objects:
                obj.name = "Fingers_Direction"
                obj.data.name = "Fingers_Direction"

        
        

        
        
        bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("middle_Dir.L")
        bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("middle_Dir.R")
        if  bonein is None and bonein2 is  None:
 
 
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

        
        
         
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target72]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("middle_Dir.L")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["middle_Dir.L"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = -90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')





            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

    
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target53]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("middle_Dir.R")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5
            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["middle_Dir.R"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = 90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')


            #Apply
            # bpy.ops.object.select_all(action='DESELECT')
            # objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            # objectToSelect2.select_set(True)
            # bpy.context.view_layer.objects.active = objectToSelect2
            # ob = bpy.data.objects["Fingers_Direction"] 
            # armature = ob.data
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='SELECT')
            
            # bpy.ops.object.posemode_toggle()

            # bpy.ops.pose.armature_apply(selected=False)
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='DESELECT')
            # bpy.ops.object.mode_set(mode='OBJECT')


            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.context.object.lock_location[0] = True
            bpy.context.object.lock_location[1] = True
            bpy.context.object.lock_location[2] = True
            bpy.context.object.lock_rotation[0] = True
            bpy.context.object.lock_rotation[1] = True
            bpy.context.object.lock_rotation[2] = True
            bpy.context.object.lock_scale[0] = True
            bpy.context.object.lock_scale[1] = True
            bpy.context.object.lock_scale[2] = True
            bpy.context.object.pose.use_mirror_x = True
            bpy.context.object.show_in_front = True
            bpy.context.object.data.show_axes = True
            bpy.context.object.data.axes_position = 1
            bpy.ops.object.posemode_toggle()


 

 
       

        

        
        
        return {'FINISHED'}
  



 
class ringDir_op(bpy.types.Operator):
    bl_label = " ring "
    bl_idname = "ringfinger.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.ops.object.posemode_toggle()
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')



        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' not in objects :

            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            bpy.context.active_object.name = 'RF_thumb_AR'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_thumb_AR"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            
            for obj in bpy.context.selected_objects:
                obj.name = "Fingers_Direction"
                obj.data.name = "Fingers_Direction"

        
        

        
        
        bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("ring_Dir.L")
        bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("ring_Dir.R")
        if  bonein is None and bonein2 is  None:
 
 
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

        
        
         
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target75]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("ring_Dir.L")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["ring_Dir.L"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = -90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')





            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

    
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target56]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("ring_Dir.R")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5
            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["ring_Dir.R"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = 90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')


            #Apply
            # bpy.ops.object.select_all(action='DESELECT')
            # objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            # objectToSelect2.select_set(True)
            # bpy.context.view_layer.objects.active = objectToSelect2
            # ob = bpy.data.objects["Fingers_Direction"] 
            # armature = ob.data
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='SELECT')
            
            # bpy.ops.object.posemode_toggle()

            # bpy.ops.pose.armature_apply(selected=False)
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='DESELECT')
            # bpy.ops.object.mode_set(mode='OBJECT')


            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.context.object.lock_location[0] = True
            bpy.context.object.lock_location[1] = True
            bpy.context.object.lock_location[2] = True
            bpy.context.object.lock_rotation[0] = True
            bpy.context.object.lock_rotation[1] = True
            bpy.context.object.lock_rotation[2] = True
            bpy.context.object.lock_scale[0] = True
            bpy.context.object.lock_scale[1] = True
            bpy.context.object.lock_scale[2] = True
            bpy.context.object.pose.use_mirror_x = True
            bpy.context.object.show_in_front = True
            bpy.context.object.data.show_axes = True
            bpy.context.object.data.axes_position = 1
            bpy.ops.object.posemode_toggle()


 

 
       

        

        
        
        return {'FINISHED'}
  




 
class pinkyDir_op(bpy.types.Operator):
    bl_label = " pinky "
    bl_idname = "pinkyfinger.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.ops.object.posemode_toggle()
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')



        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' not in objects :

            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            bpy.context.active_object.name = 'RF_thumb_AR'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_thumb_AR"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            
            for obj in bpy.context.selected_objects:
                obj.name = "Fingers_Direction"
                obj.data.name = "Fingers_Direction"

        
        

        
        
        bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("pinky_Dir.L")
        bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("pinky_Dir.R")
        if  bonein is None and bonein2 is  None:
 
 
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

        
        
         
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target78]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("pinky_Dir.L")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["pinky_Dir.L"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = -90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')





            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

    
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target59]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("pinky_Dir.R")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5
            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["pinky_Dir.R"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = 90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')


            #Apply
            # bpy.ops.object.select_all(action='DESELECT')
            # objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            # objectToSelect2.select_set(True)
            # bpy.context.view_layer.objects.active = objectToSelect2
            # ob = bpy.data.objects["Fingers_Direction"] 
            # armature = ob.data
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='SELECT')
            
            # bpy.ops.object.posemode_toggle()

            # bpy.ops.pose.armature_apply(selected=False)
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='DESELECT')
            # bpy.ops.object.mode_set(mode='OBJECT')

            ##Rest in pose mode
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.posemode_toggle()
            bpy.ops.pose.select_all(action='SELECT')
            bpy.ops.pose.rot_clear()
            bpy.ops.pose.loc_clear()
            bpy.ops.object.mode_set(mode='OBJECT')


            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.context.object.lock_location[0] = True
            bpy.context.object.lock_location[1] = True
            bpy.context.object.lock_location[2] = True
            bpy.context.object.lock_rotation[0] = True
            bpy.context.object.lock_rotation[1] = True
            bpy.context.object.lock_rotation[2] = True
            bpy.context.object.lock_scale[0] = True
            bpy.context.object.lock_scale[1] = True
            bpy.context.object.lock_scale[2] = True
            bpy.context.object.pose.use_mirror_x = True
            bpy.context.object.show_in_front = True
            bpy.context.object.data.show_axes = True
            bpy.context.object.data.axes_position = 1
            bpy.ops.object.posemode_toggle()


 

 
       

        

        
        
        return {'FINISHED'}
  





 
class hand_op(bpy.types.Operator):
    bl_label = " hand "
    bl_idname = "handdire.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' in objects :


            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.ops.object.posemode_toggle()
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')



        objects = bpy.context.scene.objects.keys()
        if  'Fingers_Direction' not in objects :

            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
            bpy.context.active_object.name = 'RF_thumb_AR'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_thumb_AR"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            
            for obj in bpy.context.selected_objects:
                obj.name = "Fingers_Direction"
                obj.data.name = "Fingers_Direction"

        
        

        
        
        bonein =bpy.data.objects["Fingers_Direction"].data.bones.get("hand_Dir.L")
        bonein2 =bpy.data.objects["Fingers_Direction"].data.bones.get("hand_Dir.R")
        if  bonein is None and bonein2 is  None:
 
 
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

        
        
         
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target24]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')


            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("hand_Dir.L")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5

            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["hand_Dir.L"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = -90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')





            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

    
            ob = bpy.data.objects[sce.Armature_Target]
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            myBone = armature.edit_bones[sce.bone_target32]    
            myBone.select_head = True 
            #myBone.select_tail = True   
            bpy.ops.view3d.snap_cursor_to_selected()
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')




            #////Snip to
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
        
            
            ebs = objectToSelect.data.edit_bones
            eb = ebs.new("hand_Dir.R")
            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
            eb.tail = (0, 1, 2)    # upon returning to object mode
            eb.length = 5
            #////Snip to cursor
            eb.select_head = True    
            eb.select_tail = True
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')   


            #set rot
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            objectToSelect2.select_set(True)

            ob = bpy.data.objects["Fingers_Direction"]

            bpy.ops.object.mode_set(mode='POSE')

            pbone = ob.pose.bones["hand_Dir.R"]
            # Set rotation mode to Euler XYZ, easier to understand
            # than default quaternions
            pbone.rotation_mode = 'XYZ'
            # select axis in ['X','Y','Z']  <--bone local
            axis = 'Y'
            angle = 90
            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
            bpy.ops.object.mode_set(mode='OBJECT')


            #Apply
            # bpy.ops.object.select_all(action='DESELECT')
            # objectToSelect2 = bpy.data.objects["Fingers_Direction"]
            # objectToSelect2.select_set(True)
            # bpy.context.view_layer.objects.active = objectToSelect2
            # ob = bpy.data.objects["Fingers_Direction"] 
            # armature = ob.data
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='SELECT')
            
            # bpy.ops.object.posemode_toggle()

            # bpy.ops.pose.armature_apply(selected=False)
            # bpy.ops.object.mode_set(mode='EDIT')
            # bpy.ops.armature.select_all(action='DESELECT')
            # bpy.ops.object.mode_set(mode='OBJECT')

            ##Rest in pose mode
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.posemode_toggle()
            bpy.ops.pose.select_all(action='SELECT')
            bpy.ops.pose.rot_clear()
            bpy.ops.pose.loc_clear()
            bpy.ops.object.mode_set(mode='OBJECT')


            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Fingers_Direction"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.context.object.lock_location[0] = True
            bpy.context.object.lock_location[1] = True
            bpy.context.object.lock_location[2] = True
            bpy.context.object.lock_rotation[0] = True
            bpy.context.object.lock_rotation[1] = True
            bpy.context.object.lock_rotation[2] = True
            bpy.context.object.lock_scale[0] = True
            bpy.context.object.lock_scale[1] = True
            bpy.context.object.lock_scale[2] = True
            bpy.context.object.pose.use_mirror_x = True
            bpy.context.object.show_in_front = True
            bpy.context.object.data.show_axes = True
            bpy.context.object.data.axes_position = 1
            bpy.ops.object.posemode_toggle()


 

 
       

        

        
        
        return {'FINISHED'}
  




 

 






