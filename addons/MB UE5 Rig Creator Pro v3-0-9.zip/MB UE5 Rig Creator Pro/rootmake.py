  
import bpy
import math

 

def makeuerig():
    
    

    bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
    bpy.context.active_object.name = 'RF_Rig_AR'

    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["RF_Rig_AR"]
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    
    for obj in bpy.context.selected_objects:
        obj.name = "RF_Rig"
        obj.data.name = "RF_Rig"
    
    
    #///////////Naming
    bpy.ops.object.select_all(action='DESELECT')
        
    objectToSelect = bpy.data.objects["RF_Rig"] 
    objectToSelect.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect
    ob = bpy.data.objects["RF_Rig"] 
    armature = ob.data

            
    bpy.context.object.data.bones["Bone"].name = "temp"

    bpy.ops.object.mode_set(mode='EDIT')

    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')
   
    bpy.ops.object.select_all(action='DESELECT')
 

    
    objectToSelect = bpy.data.objects["RF_Rig"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    
    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("center_of_mass")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['center_of_mass'].head[0] = 0
    objectToSelect.data.edit_bones['center_of_mass'].head[1] = 0
    objectToSelect.data.edit_bones['center_of_mass'].head[2] = 0
    objectToSelect.data.edit_bones['center_of_mass'].head_radius = 0.1



    objectToSelect.data.edit_bones['center_of_mass'].tail[0] = 0
    objectToSelect.data.edit_bones['center_of_mass'].tail[1] = 1
    objectToSelect.data.edit_bones['center_of_mass'].tail[2] = 0
    objectToSelect.data.edit_bones['center_of_mass'].tail_radius = 0.05
    objectToSelect.data.edit_bones['center_of_mass'].roll = 0
    objectToSelect.data.edit_bones['center_of_mass'].length = 1
    objectToSelect.data.edit_bones['center_of_mass'].envelope_distance = 0.25



    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')

  


class rootmak_op(bpy.types.Operator):
    bl_label = "Add root bone for animation "
    bl_idname = "rootma.op"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        
        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' not in objects:
            
            self.report({"WARNING"}, "Set Character Scale !")
        
        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' in objects:

        

            if sce.Armature_Target =="" or sce.bone_targetHip =="" :
                
                self.report({"WARNING"}, " Hips/pelvis required ")


            if mytool.my_bool33 ==False :
                
                self.report({"WARNING"}, "Enable Animation Processing ")
        
        
        
            if sce.Armature_Target !="" and sce.bone_targetHip !="" and mytool.my_bool33 !=False : 
                
                

                mytool.my_int_famee = bpy.context.scene.frame_end 

                scene = bpy.context.scene
                scene.frame_set(1)

                if sce.bone_targetHip =="root":

                    bpy.context.object.data.bones[sce.bone_targetHip].name = sce.bone_targetHip +"MBRF"
                    bpy.context.scene.bone_targetHip = sce.bone_targetHip+"MBRF"






                #show all hiden bones 
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]  
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                bpy.ops.armature.reveal()
                bpy.ops.object.mode_set(mode='OBJECT') 

                
                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target] 
                objectToSelect.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect
                bpy.ops.object.transform_apply(location=True, rotation=False, scale=False)


    



                bpy.ops.object.select_all(action='DESELECT')   
                objectToSelect = bpy.data.objects[sce.Armature_Target] 
                objectToSelect.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data

                

            
                if sce.bone_target79 =="" :
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("root") 
                    if  bonein is not None:
                    
                        bpy.context.object.data.bones["root"].name = "root_OldRF"

                bpy.ops.object.mode_set(mode='EDIT')

                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')





                bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                bpy.context.active_object.name = 'RF_root_AR'

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["RF_root_AR"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                
                for obj in bpy.context.selected_objects:
                    obj.name = "Ar_root"
                    obj.data.name = "Ar_root"

            
    


                #////Snip to
                bpy.ops.view3d.snap_cursor_to_center()
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Ar_root"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
            
                
                ebs = objectToSelect.data.edit_bones
                eb = ebs.new("root")
                eb.tail = (0, 0, 100)
                eb.length = 100    # upon returning to object mode
                
                
                eb.select_head = True    
                eb.select_tail = True
                bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')   


                

                
                bpy.ops.object.select_all(action='DESELECT')  
                objectToSelect2 = bpy.data.objects["Ar_root"]
                objectToSelect2.select_set(True)    
            


            
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 

                bpy.ops.object.join()



            
            
            
            
            
            
                ########################################## #new add bone to fix bone 

                if mytool.my_boolflipedHips !=False : 
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones[sce.bone_targetHip]    
                    myBone.select_head = True 
                    #myBone.select_tail = True   
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')
            
                    

                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                
                    
                    ebs = objectToSelect.data.edit_bones
                    eb = ebs.new("hips_FixAnim")
                    eb.head = (0, 0, 0) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 0, 10)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    
                    bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                    bpy.context.active_object.name = 'hips_FixFrootAR'

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["hips_FixFrootAR"]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    
                    for obj in bpy.context.selected_objects:
                        obj.name = "hips_FixFroot"
                        obj.data.name = "hips_FixFroot"
                

                    #////Snip to
                    bpy.ops.view3d.snap_cursor_to_center()
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["hips_FixFroot"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                
                    
                    ebs = objectToSelect.data.edit_bones
                    eb = ebs.new("hips_Fix")
                    eb.tail = (0, 0, 100)
                    eb.length = 100    # upon returning to object mode
                    
                    
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')   






                    armature1 = bpy.data.objects[sce.Armature_Target]
                    armature2 = bpy.data.objects['hips_FixFroot']


                    selected_bone = armature1.pose.bones["hips_FixAnim"]

                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2
                    neckCopyRot.subtarget = "hips_Fix"


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')   
                    
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.ops.pose.select_all(action='DESELECT')
                    b=ob.data.bones["hips_FixAnim"] 
                    b.select=True
                    ob.data.bones.active=b
                    bpy.ops.pose.armature_apply(selected=True)
                    bpy.ops.constraint.delete(constraint="Copy Rotation", owner='BONE')
                    bpy.ops.object.mode_set(mode='OBJECT')

                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    arm = bpy.data.objects[sce.Armature_Target]
                    arm.data.edit_bones["hips_FixAnim"].parent = arm.data.edit_bones[sce.bone_targetHip]
                    bpy.ops.object.mode_set(mode='OBJECT')



                    #ADD  hipsPLAIN_AXES
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')   
                    
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.ops.pose.select_all(action='SELECT')
                    bpy.ops.pose.rot_clear()
                    bpy.ops.pose.loc_clear()

                    bpy.ops.pose.select_all(action='DESELECT')
                    b=ob.data.bones["hips_FixAnim"] 
                    b.select=True
                    ob.data.bones.active=b
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='OBJECT')

                    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                    bpy.context.active_object.name = 'hipsPLAIN_AXES'

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["hipsPLAIN_AXES"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 

                    bpy.ops.object.constraint_add(type='COPY_LOCATION')
                    bpy.context.object.constraints["Copy Location"].use_x = False
                    bpy.context.object.constraints["Copy Location"].use_y = False
                    bpy.context.object.constraints["Copy Location"].target = bpy.data.objects[sce.Armature_Target]
                    bpy.context.object.constraints["Copy Location"].subtarget = "hips_FixAnim"
                    bpy.context.object.constraints["Copy Location"].use_offset = True


                    bpy.ops.view3d.snap_cursor_to_center()


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["hipsPLAIN_AXES"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 

                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.constraint_add(type='LIMIT_LOCATION')
                    bpy.context.object.constraints["Limit Location"].use_min_z = True


                    bpy.ops.object.constraint_add(type='COPY_LOCATION')
                    bpy.context.object.constraints["Copy Location.001"].use_z = False
                    bpy.context.object.constraints["Copy Location.001"].target = bpy.data.objects[sce.Armature_Target]
                    bpy.context.object.constraints["Copy Location.001"].subtarget = "hips_FixAnim"



                    bpy.ops.object.constraint_add(type='COPY_LOCATION')
                    bpy.context.object.constraints["Copy Location.001"].use_z = False
                    bpy.context.object.constraints["Copy Location.001"].target = bpy.data.objects[sce.Armature_Target]
                    bpy.context.object.constraints["Copy Location.001"].subtarget = "hips_FixAnim"


                    bpy.ops.object.constraint_add(type='COPY_ROTATION')
                    bpy.context.object.constraints["Copy Rotation"].target = bpy.data.objects[sce.Armature_Target]
                    bpy.context.object.constraints["Copy Rotation"].subtarget = "hips_FixAnim"

                    ################## END ############################################









                if mytool.my_boolflipedHips ==False : 

                    #ADD  hipsPLAIN_AXES
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')   
                    
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.ops.pose.select_all(action='SELECT')
                    bpy.ops.pose.rot_clear()
                    bpy.ops.pose.loc_clear()

                    bpy.ops.pose.select_all(action='DESELECT')
                    b=ob.data.bones[sce.bone_targetHip] 
                    b.select=True
                    ob.data.bones.active=b
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='OBJECT')

                    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                    bpy.context.active_object.name = 'hipsPLAIN_AXES'

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["hipsPLAIN_AXES"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 

                    bpy.ops.object.constraint_add(type='COPY_LOCATION')
                    bpy.context.object.constraints["Copy Location"].use_x = False
                    bpy.context.object.constraints["Copy Location"].use_y = False
                    bpy.context.object.constraints["Copy Location"].target = bpy.data.objects[sce.Armature_Target]
                    bpy.context.object.constraints["Copy Location"].subtarget = sce.bone_targetHip
                    bpy.context.object.constraints["Copy Location"].use_offset = True


                    bpy.ops.view3d.snap_cursor_to_center()


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["hipsPLAIN_AXES"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 

                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.constraint_add(type='LIMIT_LOCATION')
                    bpy.context.object.constraints["Limit Location"].use_min_z = True


                    bpy.ops.object.constraint_add(type='COPY_LOCATION')
                    bpy.context.object.constraints["Copy Location.001"].use_z = False
                    bpy.context.object.constraints["Copy Location.001"].target = bpy.data.objects[sce.Armature_Target]
                    bpy.context.object.constraints["Copy Location.001"].subtarget = sce.bone_targetHip



                    bpy.ops.object.constraint_add(type='COPY_LOCATION')
                    bpy.context.object.constraints["Copy Location.001"].use_z = False
                    bpy.context.object.constraints["Copy Location.001"].target = bpy.data.objects[sce.Armature_Target]
                    bpy.context.object.constraints["Copy Location.001"].subtarget = sce.bone_targetHip


                    bpy.ops.object.constraint_add(type='COPY_ROTATION')
                    bpy.context.object.constraints["Copy Rotation"].target = bpy.data.objects[sce.Armature_Target]
                    bpy.context.object.constraints["Copy Rotation"].subtarget = sce.bone_targetHip

            
    

    

                #zzz  
                

                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects["hipsPLAIN_AXES"]
                
            

                selected_bone = armature1.pose.bones["root"]
            
                
                neckconstraint = selected_bone.constraints
                neckCopyRot = neckconstraint.new('COPY_LOCATION')
                neckCopyRot.target = armature2
                neckCopyRot.subtarget = "hipsPLAIN_AXES"



                
                #COPY_ROTATION
                armature1 = bpy.data.objects[sce.Armature_Target]
                armature2 = bpy.data.objects["hipsPLAIN_AXES"]
                
            

                selected_bone = armature1.pose.bones["root"]
            
                
                neckconstraint = selected_bone.constraints
                neckCopyRot = neckconstraint.new('COPY_ROTATION')
                neckCopyRot.target = armature2
                neckCopyRot.subtarget = "hipsPLAIN_AXES"



                if mytool.my_boolTOUnrealroot !=False :
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones["root"]
                    myBone.select = True
                    armature.edit_bones.active = myBone
                    bpy.context.active_bone.name = "FirstRoot"
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    makeuerig()

                    

                    
                    bpy.ops.view3d.snap_cursor_to_center()
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                
                    
                    ebs = objectToSelect.data.edit_bones
                    eb = ebs.new("root")
                    eb.head = (0, 0, 0) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 0, -100)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')

                    
                    
                    
                    #NEW Fix
                    
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    armature2 = bpy.data.objects['RF_Rig']


                    selected_bone = armature1.pose.bones["root"]

                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature2
                    neckCopyRot.subtarget = "center_of_mass"


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')   
                    
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.ops.pose.select_all(action='DESELECT')
                    b=ob.data.bones["root"] 
                    b.select=True
                    ob.data.bones.active=b
                    bpy.ops.pose.armature_apply(selected=True)
                    bpy.ops.constraint.delete(constraint="Copy Rotation", owner='BONE')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    ### Set size bone root
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    
                    bpy.ops.object.mode_set(mode='EDIT')
                    

                    objectToSelect.data.edit_bones['root'].length = 1

                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')
                





                    #############EndFix








    
    
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    arm = bpy.data.objects[sce.Armature_Target]
                    arm.data.edit_bones["root"].parent = arm.data.edit_bones['FirstRoot']
                    bpy.ops.object.mode_set(mode='OBJECT')









                    
    
                
                

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                bpy.ops.object.duplicate()
                bpy.context.active_object.name = 'bone_root_t'

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["bone_root_t"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                for obj in bpy.context.selected_objects:
                    obj.name = "bone_root"
                    obj.data.name = "bone_root"

            


    

                
                
                if mytool.my_bool33 !=False :
                
                
                    objectToSelect = bpy.data.objects["bone_root"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect


                    ob = bpy.data.objects["bone_root"]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    myBone = armature.edit_bones[sce.bone_targetHip]
                    myBone.select = True
                    armature.edit_bones.active = myBone
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.ops.nla.bake(frame_start=mytool.my_int_feames, frame_end=mytool.my_int_famee, step=1, only_selected=True, visual_keying=True, clear_constraints=True, clear_parents=True, use_current_action=True, clean_curves=False, bake_types={'POSE'})
                    bpy.ops.object.mode_set(mode='OBJECT')


    



                #/////////////delete Bone
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
            
                
                
                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')

                ob = bpy.context.object
                assert ob.type == 'ARMATURE'
                arma = ob.data
                bpy.ops.object.mode_set(mode='EDIT') # ensure edit mode
                bpy.ops.armature.select_all(action='DESELECT')
            
                
                bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("FirstRoot")
            
                if  bonein is not None :

                    bone = arma.edit_bones['FirstRoot']
                    arma.edit_bones.remove(bone)


                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')




    
    
    

            
            
                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.posemode_toggle()
                bpy.ops.pose.select_all(action='SELECT')
                bpy.ops.pose.rot_clear()
                bpy.ops.pose.loc_clear()
                bpy.ops.object.mode_set(mode='OBJECT')




                






                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)

                    

                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                arm = bpy.data.objects[sce.Armature_Target]
                arm.data.edit_bones[sce.bone_targetHip].parent = arm.data.edit_bones['root']
                bpy.ops.object.mode_set(mode='OBJECT')


                

                armatureFrom = bpy.data.objects["bone_root"]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)
                    #copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
                    copy_con = boneTo.constraints.new('COPY_ROTATION')
                    copy_con.target = armatureFrom
                    copy_con.subtarget = boneFrom.name
                    copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                    copy_con2.target = armatureFrom
                    copy_con2.subtarget = boneFrom.name

                


                
                

                # LIMIT_LOCATION Root
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 
    
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='SELECT')
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones["root"] 
                b.select=True
                ob.data.bones.active=b
                bpy.ops.pose.constraint_add(type='LIMIT_LOCATION')
                bpy.context.object.pose.bones["root"].constraints["Limit Location"].use_min_z = True
                bpy.ops.object.mode_set(mode='OBJECT')


    


    
                
                if mytool.my_boolXroot ==False :
                
                    bpy.context.object.pose.bones["root"].constraints["Copy Location"].use_x = False
            
            
                if mytool.my_boolYroot ==False :
                    
                    bpy.context.object.pose.bones["root"].constraints["Copy Location"].use_y = False
                

                if mytool.my_boolZroot ==False :
                    bpy.context.object.pose.bones["root"].constraints["Copy Location"].use_z = False





                #Copy Rotation


                



                if mytool.my_boolXRroot ==False :

                    bpy.context.object.pose.bones["root"].constraints["Copy Rotation"].use_x = False
            
                if mytool.my_boolYRroot ==False :
                    
                    bpy.context.object.pose.bones["root"].constraints["Copy Rotation"].use_y = False

                if mytool.my_boolZRroot ==False :
                    
                    bpy.context.object.pose.bones["root"].constraints["Copy Rotation"].use_z = False




    


    
                
            
            
                if mytool.my_bool33 !=False :


                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect


                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    myBone = armature.edit_bones[sce.bone_targetHip]
                    myBone.select = True
                    armature.edit_bones.active = myBone
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.ops.nla.bake(frame_start=mytool.my_int_feames, frame_end=mytool.my_int_famee, step=1, only_selected=True, visual_keying=True, clear_constraints=True, clear_parents=True, use_current_action=True, clean_curves=False, bake_types={'POSE'})
                    bpy.ops.object.mode_set(mode='OBJECT')

    
                
                objects = bpy.context.scene.objects.keys()
                if  'bone_root' in objects:

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["bone_root"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False)
                    bpy.ops.object.select_all(action='DESELECT')
            
                

                objects = bpy.context.scene.objects.keys()
                if  'FLOOR_LockRoot' in objects:

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["FLOOR_LockRoot"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False)
                    bpy.ops.object.select_all(action='DESELECT')




                objects = bpy.context.scene.objects.keys()
                if  'hipsPLAIN_AXES' in objects:

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["hipsPLAIN_AXES"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False)
                    bpy.ops.object.select_all(action='DESELECT')



                objects = bpy.context.scene.objects.keys()
                if  'hipsZZZ_AXES' in objects:

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["hipsZZZ_AXES"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False)
                    bpy.ops.object.select_all(action='DESELECT')







                if mytool.my_boolApplyScale !=False :

                    #Apply Scale 
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.duplicate()
                    bpy.context.active_object.name = 'Apply_ScaleAR'

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["Apply_ScaleAR"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    for obj in bpy.context.selected_objects:
                        obj.name = "Apply_ScaleAnim"
                        obj.data.name = "Apply_ScaleAnim"



                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

                    



                    armatureFrom = bpy.data.objects["Apply_ScaleAnim"]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)
                        copy_con = boneTo.constraints.new('COPY_ROTATION')
                        copy_con.target = armatureFrom
                        copy_con.subtarget = boneFrom.name
                        copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                        copy_con2.target = armatureFrom
                        copy_con2.subtarget = boneFrom.name

        



                if mytool.my_boolApplyScale !=False :


                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect


                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    myBone = armature.edit_bones[sce.bone_targetHip]
                    myBone.select = True
                    armature.edit_bones.active = myBone
                    bpy.ops.object.mode_set(mode='POSE')
                    bpy.ops.nla.bake(frame_start=mytool.my_int_feames, frame_end=mytool.my_int_famee, step=1, only_selected=True, visual_keying=True, clear_constraints=True, clear_parents=True, use_current_action=True, clean_curves=False, bake_types={'POSE'})
                    bpy.ops.object.mode_set(mode='OBJECT')

            


                objects = bpy.context.scene.objects.keys()
                if  'Apply_ScaleAnim' in objects:

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["Apply_ScaleAnim"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False)
                    bpy.ops.object.select_all(action='DESELECT')




                objects = bpy.context.scene.objects.keys()
                if  'hips_FixFroot' in objects:

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["hips_FixFroot"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False)
                    bpy.ops.object.select_all(action='DESELECT')
                
                

                objects = bpy.context.scene.objects.keys()
                if  'RF_Rig' in objects:

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["RF_Rig"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False)
                    bpy.ops.object.select_all(action='DESELECT')   


            
            
            
            
                #/////////////delete Bone
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
            
                
                
                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')

                ob = bpy.context.object
                assert ob.type == 'ARMATURE'
                arma = ob.data
                bpy.ops.object.mode_set(mode='EDIT') # ensure edit mode
                bpy.ops.armature.select_all(action='DESELECT')
            
                
                bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("hips_FixAnim")
            
                if  bonein is not None :

                    bone = arma.edit_bones['hips_FixAnim']
                    arma.edit_bones.remove(bone)


                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')
            
            


               
                   
                bpy.context.scene.bone_target79 ="root"

        
        
        return {'FINISHED'}
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
