import bpy

import math

x = True

 
class lefthand_new_op(bpy.types.Operator):
    bl_label = "LFingers"
    bl_idname = "leftfinger.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene


        if mytool.my_bool33 ==False :
                     
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            
            
            for action in bpy.data.actions:
                bpy.data.actions.remove(action)


            ##Rest in pose mode
        
            bpy.ops.object.posemode_toggle()
            bpy.ops.pose.select_all(action='SELECT')
            bpy.ops.pose.rot_clear()
            bpy.ops.pose.loc_clear()
            bpy.ops.object.mode_set(mode='OBJECT')


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'fingers_RFAR'



        ##Rest
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["fingers_RFAR"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        if mytool.my_bool33 !=False :

            context = bpy.context
            object = context.object

            #should put checks in to see if you have object animation_data etc

            action = object.animation_data.action  # this is the action that is shown in action editor.

            # the action can be unlinked using.

            object.animation_data.action = None


 
        
        
        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["fingers_RFAR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.view3d.snap_cursor_to_center()








        #pinky1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'pinky1_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target76
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #pinky2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'pinky2_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky2_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target77
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #pinky3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'pinky3_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky3_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target78
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################







        #ring1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'ring1_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring1_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target73
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #ring2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'ring2_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring2_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target74
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #ring3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'ring3_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring3_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target75
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################










        #mid1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'mid1_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid1_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target70
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #mid2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'mid2_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid2_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target71
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #mid3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'mid3_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid3_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target72
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################










        #index1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'index1_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index1_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target67
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #index2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'index2_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index2_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target68
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #index3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'index3_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index3_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target69
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################







        #thumb1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'thumb1_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb1_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target64
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #thumb2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'thumb2_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb2_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target65
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #thumb3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'thumb3_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb3_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target66
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################





        #Hand
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'hand_AXES_L'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["hand_AXES_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target24
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################













 
        bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'RF_fingers_AR'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_fingers_AR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        
        for obj in bpy.context.selected_objects:
            obj.name = "pinky1_ar_L"
            obj.data.name = "pinky1_ar_L"







        ##1111111
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("finger_X_L")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   


        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_L"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_X_L"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Z'
        angle = -90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')



        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_L"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_X_L"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Y'
        angle = 90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')







        ##222222222222
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("finger_-X_L")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   


        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_L"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_-X_L"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Z'
        angle = 90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')




         


        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_L"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_-X_L"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Y'
        angle = 90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')





        ##33333333
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("finger_Y_L")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   

        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_L"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_Y_L"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'X'
        angle = 180
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')




        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_L"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_Y_L"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Y'
        angle = -90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')




        ##33333333
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("finger_-Y_L")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   

        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_L"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_-Y_L"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'X'
        angle = 0
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')













        # /////////////delete Bones RF
        bpy.ops.object.select_all(action='DESELECT')
        ob = bpy.data.objects["pinky1_ar_L"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')

        ob = bpy.context.object
        assert ob.type == 'ARMATURE'
        arma = ob.data
        bpy.ops.object.mode_set(mode='EDIT') # ensure edit mode
        bpy.ops.armature.select_all(action='DESELECT')
    
    
        
        bone = arma.edit_bones['Bone']
        arma.edit_bones.remove(bone)
        
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        ob = bpy.data.objects["pinky1_ar_L"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='POSE')
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.select_all(action='DESELECT')
        b=ob.data.bones["finger_Y_L"] 
        b.select=True
        ob.data.bones.active=b
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects["pinky1_ar_L"] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



            
        objectToSelect = bpy.data.objects["pinky1_ar_L"] 
        objectToSelect.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect
        
        
        ob = bpy.data.objects["pinky1_ar_L"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        arm = bpy.data.objects["pinky1_ar_L"]
        
        arm.data.edit_bones['finger_X_L'].parent = arm.data.edit_bones["finger_Y_L"]
        arm.data.edit_bones['finger_-X_L'].parent = arm.data.edit_bones["finger_Y_L"]
        arm.data.edit_bones['finger_-Y_L'].parent = arm.data.edit_bones["finger_Y_L"]
        


        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'pinky2_ar_L'

        
        
        
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'pinky3_ar_L'





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'ring1_ar_L'


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'ring2_ar_L'


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'ring3_ar_L'






        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'mid1_ar_L'



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'mid2_ar_L'


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'mid3_ar_L'





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'index1_ar_L'



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'index2_ar_L'



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'index3_ar_L'





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'thumb1_ar_L'




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'thumb2_ar_L'





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'thumb3_ar_L'



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'hand_ar_L'




         




        
        #Add to emtys
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["pinky1_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky2_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["pinky2_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky3_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["pinky3_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        #ring


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["ring1_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring2_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["ring2_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring3_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["ring3_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        #mid


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["mid1_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid2_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["mid2_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid3_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["mid3_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')







        #index


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["index1_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index2_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["index2_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index3_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["index3_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')








        #thumb


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb1_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["thumb1_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb2_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["thumb2_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb3_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["thumb3_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')






        #hand


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["hand_ar_L"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["hand_AXES_L"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')









          




        
        
        return {'FINISHED'}
  
 
class lefthand_rot_op(bpy.types.Operator):
    bl_label = "RFingers"
    bl_idname = "leftfingerrot.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene


        
        
       
       
       
        

        if mytool.my_boolStand_xn !=False :

            #pinky  
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky1_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky2_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky3_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"




        
            #ring 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring1_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring2_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring3_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"






            #mid1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid1_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid2_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid3_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"







            #index1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index1_ar_L']
                        
            selected_bone = armature1.pose.bones['index_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index2_ar_L']
                        
            selected_bone = armature1.pose.bones['index_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index3_ar_L']
                        
            selected_bone = armature1.pose.bones['index_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"



            



        if mytool.my_boolStand_zt !=False :

            #thumb1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb1_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb2_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb3_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"


        

        #OP2222222222222222222222222222222 ##########################################################


        if mytool.my_boolStand_z !=False :

            #pinky  
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky1_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky2_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky3_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"




        
            #ring 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring1_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring2_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring3_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"






            #mid1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid1_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid2_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid3_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"







            #index1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index1_ar_L']
                        
            selected_bone = armature1.pose.bones['index_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index2_ar_L']
                        
            selected_bone = armature1.pose.bones['index_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index3_ar_L']
                        
            selected_bone = armature1.pose.bones['index_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"



            



        if mytool.my_boolStand_xt !=False :

            #thumb1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb1_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb2_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb3_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"



        #OPPPPPPPPPPPPPP 33333333333333333333333333333333333333333333333

        
        
        
        
        if mytool.my_boolStand_zn !=False :

            #pinky  
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky1_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky2_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky3_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"




        
            #ring 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring1_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring2_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring3_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"






            #mid1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid1_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid2_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid3_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"







            #index1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index1_ar_L']
                        
            selected_bone = armature1.pose.bones['index_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index2_ar_L']
                        
            selected_bone = armature1.pose.bones['index_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index3_ar_L']
                        
            selected_bone = armature1.pose.bones['index_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"



             


        if mytool.my_boolStand_xnt !=False :

            #thumb1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb1_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb2_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb3_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"
       
       
       
        
        
        #opppppppp444444444444444444444444444444444444

       
       
       
        if mytool.my_boolStand_x !=False :

            #pinky  
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky1_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky2_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky3_ar_L']
                        
            selected_bone = armature1.pose.bones['pinky_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"




        
            #ring 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring1_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring2_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring3_ar_L']
                        
            selected_bone = armature1.pose.bones['ring_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"






            #mid1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid1_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid2_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid3_ar_L']
                        
            selected_bone = armature1.pose.bones['middle_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"







            #index1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index1_ar_L']
                        
            selected_bone = armature1.pose.bones['index_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index2_ar_L']
                        
            selected_bone = armature1.pose.bones['index_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index3_ar_L']
                        
            selected_bone = armature1.pose.bones['index_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"



             



        if mytool.my_boolStand_znt !=False :

            #thumb1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb1_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_01_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb2_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_02_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb3_ar_L']
                        
            selected_bone = armature1.pose.bones['thumb_03_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"
        
        
        
        
        #HAnd_oppppppppppppppppppppppppppppppppppppppppppppppppppppp
        #HAnd_oppppppppppppppppppppppppppppppppppppppppppppppppppppp
        #HAnd_oppppppppppppppppppppppppppppppppppppppppppppppppppppp
        #HAnd_oppppppppppppppppppppppppppppppppppppppppppppppppppppp
        #hand_LLLLLLLLLLLLL#####################################
        

        #OPPPPP1
        if mytool.my_bool_hand_zn !=False :


            #hand_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['hand_ar_L']
                        
            selected_bone = armature1.pose.bones['hand_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_L"



        #OPPPPP2
        if mytool.my_bool_hand_z !=False :


            #hand_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['hand_ar_L']
                        
            selected_bone = armature1.pose.bones['hand_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_L"




        #OPPPPP3
        if mytool.my_bool_hand_x !=False :


            #hand_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['hand_ar_L']
                        
            selected_bone = armature1.pose.bones['hand_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_L"


        
        
        #OPPPPP4
        if mytool.my_bool_hand_xn !=False :


            #hand_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['hand_ar_L']
                        
            selected_bone = armature1.pose.bones['hand_l']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_L"






       
       
       
       
        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)
       
       
       
       
       




       
        
        
        
        
        
        
        
        
        
        
        #add cons  #add cons  #add cons
        #add cons  #add cons  #add cons
        #add cons  #add cons  #add cons











        #pinky_01_l 
        armature1 = bpy.data.objects[sce.Armature_Target]
        selected_bone = armature1.pose.bones["pinky_01_l"]
        selected_bone2 = armature1.pose.bones["pinky_02_l"]
        selected_bone7 = armature1.pose.bones["pinky_metacarpal_l"]
        selected_bone4 = armature1.pose.bones["pinky_03_l"]
        
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_02_l"


         


        neckconstraint = selected_bone7.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "hand_l"


    
        
        
        neckconstraint = selected_bone7.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



        #ring_01_l

        #pinky_01_l 
        armature1 = bpy.data.objects[sce.Armature_Target]
        selected_bone = armature1.pose.bones["ring_01_l"]
        selected_bone2 = armature1.pose.bones["ring_02_l"]
        selected_bone7 = armature1.pose.bones["ring_metacarpal_l"]
        selected_bone4 = armature1.pose.bones["ring_03_l"]
        
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_02_l"


         


        neckconstraint = selected_bone7.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "hand_l"


    
        
        
        neckconstraint = selected_bone7.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
        
        
        





        #middle_01_l 
        selected_bone = armature1.pose.bones["middle_01_l"]
        selected_bone2 = armature1.pose.bones["middle_02_l"]
        selected_bone3 = armature1.pose.bones["middle_metacarpal_l"]
        selected_bone4 = armature1.pose.bones["middle_03_l"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_02_l"
 


        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "hand_l"

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



 





        #index_01_l 
        selected_bone = armature1.pose.bones["index_01_l"]
        selected_bone2 = armature1.pose.bones["index_02_l"]
        selected_bone3 = armature1.pose.bones["index_metacarpal_l"]
        selected_bone4 = armature1.pose.bones["index_03_l"]
        selected_bone5 = armature1.pose.bones["hand_l"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_02_l"

         



        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "hand_l"


        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'


        neckconstraint = selected_bone5.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'


        #thumb_01_l 
        selected_bone = armature1.pose.bones["thumb_01_l"]
        selected_bone1 = armature1.pose.bones["thumb_02_l"]
        selected_bone2 = armature1.pose.bones["thumb_02_l"]
        selected_bone3 = armature1.pose.bones["thumb_03_l"]


        neckconstraint = selected_bone1.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_01_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_03_l"
        neckCopyRot.track_axis = 'TRACK_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

       



        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_l"



        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)









             

        
        
        return {'FINISHED'}
  








#Right

class rigthand_new_op(bpy.types.Operator):
    bl_label = "RFingers"
    bl_idname = "rightfinger.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        # bpy.ops.object.select_all(action='DESELECT')
        # objectToSelect = bpy.data.objects[sce.Armature_Target]
        # objectToSelect.select_set(True)    
        # bpy.context.view_layer.objects.active = objectToSelect

        # bpy.ops.object.duplicate()
        # bpy.context.active_object.name = 'fingers_RFAR'



        #pinky1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'pinky1_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target57
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #pinky2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'pinky2_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky2_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target58
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #pinky3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'pinky3_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky3_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target59
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################







        #ring1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'ring1_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring1_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target54
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #ring2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'ring2_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring2_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target55
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #ring3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'ring3_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring3_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target56
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################










        #mid1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'mid1_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid1_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target51
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #mid2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'mid2_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid2_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target52
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #mid3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'mid3_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid3_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target53
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################










        #index1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'index1_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index1_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target48
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #index2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'index2_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index2_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target49
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #index3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'index3_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index3_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target50
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################







        #thumb1
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'thumb1_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb1_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target45
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################


        #thumb2
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'thumb2_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb2_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target46
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################




        #thumb3
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'thumb3_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb3_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target47
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################





        #Hand
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'hand_AXES_R'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["hand_AXES_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["fingers_RFAR"]
        bpy.context.object.constraints["Copy Transforms"].subtarget = sce.bone_target32
        bpy.ops.object.select_all(action='DESELECT')

        ################## END ############################################













 
        bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'RF_fingers_AR'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_fingers_AR"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        
        for obj in bpy.context.selected_objects:
            obj.name = "pinky1_ar_R"
            obj.data.name = "pinky1_ar_R"







        ##1111111
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("finger_X_R")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   


        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_R"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_X_R"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Z'
        angle = -90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')



        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_R"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_X_R"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Y'
        angle = 90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')







        ##222222222222
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("finger_-X_R")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   


        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_R"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_-X_R"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Z'
        angle = 90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')




         


        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_R"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_-X_R"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Y'
        angle = 90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')





        ##33333333
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("finger_Y_R")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   

        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_R"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_Y_R"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'X'
        angle = 180
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')




        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_R"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_Y_R"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'Y'
        angle = -90
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')




        ##33333333
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
    
        
        ebs = objectToSelect.data.edit_bones
        eb = ebs.new("finger_-Y_R")
        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
        eb.tail = (0, 1, 2)    # upon returning to object mode
        eb.length = 5

        #////Snip to cursor
        eb.select_head = True    
        eb.select_tail = True
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   

        #NEW NEW NEW
        #set rot
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)

        ob = bpy.data.objects["pinky1_ar_R"]

        bpy.ops.object.mode_set(mode='POSE')

        pbone = ob.pose.bones["finger_-Y_R"]
        # Set rotation mode to Euler XYZ, easier to understand
        # than default quaternions
        pbone.rotation_mode = 'XYZ'
        # select axis in ['X','Y','Z']  <--bone local
        axis = 'X'
        angle = 0
        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
        bpy.ops.object.mode_set(mode='OBJECT')













        # /////////////delete Bones RF
        bpy.ops.object.select_all(action='DESELECT')
        ob = bpy.data.objects["pinky1_ar_R"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')

        ob = bpy.context.object
        assert ob.type == 'ARMATURE'
        arma = ob.data
        bpy.ops.object.mode_set(mode='EDIT') # ensure edit mode
        bpy.ops.armature.select_all(action='DESELECT')
    
    
        
        bone = arma.edit_bones['Bone']
        arma.edit_bones.remove(bone)
        
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        ob = bpy.data.objects["pinky1_ar_R"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='POSE')
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.select_all(action='DESELECT')
        b=ob.data.bones["finger_Y_R"] 
        b.select=True
        ob.data.bones.active=b
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects["pinky1_ar_R"] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



            
        objectToSelect = bpy.data.objects["pinky1_ar_R"] 
        objectToSelect.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect
        
        
        ob = bpy.data.objects["pinky1_ar_R"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        arm = bpy.data.objects["pinky1_ar_R"]
        
        arm.data.edit_bones['finger_X_R'].parent = arm.data.edit_bones["finger_Y_R"]
        arm.data.edit_bones['finger_-X_R'].parent = arm.data.edit_bones["finger_Y_R"]
        arm.data.edit_bones['finger_-Y_R'].parent = arm.data.edit_bones["finger_Y_R"]
        


        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'pinky2_ar_R'

        
        
        
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'pinky3_ar_R'





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'ring1_ar_R'


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'ring2_ar_R'


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'ring3_ar_R'






        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'mid1_ar_R'



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'mid2_ar_R'


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'mid3_ar_R'





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'index1_ar_R'



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'index2_ar_R'



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'index3_ar_R'





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'thumb1_ar_R'




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'thumb2_ar_R'





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'thumb3_ar_R'



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        bpy.context.object.data.use_mirror_x = False
        bpy.ops.object.duplicate()
        bpy.context.active_object.name = 'hand_ar_R'




         




        
        #Add to emtys
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["pinky1_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky2_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["pinky2_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["pinky3_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["pinky3_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        #ring


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["ring1_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring2_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["ring2_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["ring3_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["ring3_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        #mid


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["mid1_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid2_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["mid2_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["mid3_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["mid3_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')







        #index


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["index1_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index2_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["index2_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["index3_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["index3_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')








        #thumb


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb1_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["thumb1_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb2_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["thumb2_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["thumb3_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["thumb3_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')






        #hand


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["hand_ar_R"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        bpy.ops.object.constraint_add(type='COPY_TRANSFORMS')
        bpy.context.object.constraints["Copy Transforms"].target = bpy.data.objects["hand_AXES_R"]
        bpy.ops.constraint.apply(constraint="Copy Transforms", owner='OBJECT')


        




             

        
        
        return {'FINISHED'}
  


class rigthand_rot_op(bpy.types.Operator):
    bl_label = "RFingers"
    bl_idname = "rigtfingerrot.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene


        
        
       
       
       
        

        if mytool.my_boolStandR_x !=False :

            #pinky  
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky1_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky2_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky3_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"




        
            #ring 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring1_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring2_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring3_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"






            #mid1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid1_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid2_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid3_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"







            #index1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index1_ar_R']
                        
            selected_bone = armature1.pose.bones['index_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index2_ar_R']
                        
            selected_bone = armature1.pose.bones['index_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index3_ar_R']
                        
            selected_bone = armature1.pose.bones['index_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"



            



        if mytool.my_boolStandR_zt !=False :

            #thumb1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb1_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb2_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb3_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"


        

        #OP2222222222222222222222222222222 ##########################################################


        if mytool.my_boolStandR_z !=False :

            #pinky  
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky1_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky2_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky3_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"




        
            #ring 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring1_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring2_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring3_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"






            #mid1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid1_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid2_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid3_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"







            #index1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index1_ar_R']
                        
            selected_bone = armature1.pose.bones['index_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index2_ar_R']
                        
            selected_bone = armature1.pose.bones['index_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index3_ar_R']
                        
            selected_bone = armature1.pose.bones['index_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"



            



        if mytool.my_boolStandR_xt !=False :

            #thumb1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb1_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb2_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb3_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"



        #OPPPPPPPPPPPPPP 33333333333333333333333333333333333333333333333

        
        
        
        
        if mytool.my_boolStandR_zn !=False :

            #pinky  
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky1_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky2_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky3_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"




        
            #ring 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring1_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring2_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring3_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"






            #mid1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid1_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid2_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid3_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"







            #index1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index1_ar_R']
                        
            selected_bone = armature1.pose.bones['index_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index2_ar_R']
                        
            selected_bone = armature1.pose.bones['index_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index3_ar_R']
                        
            selected_bone = armature1.pose.bones['index_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"



             


        if mytool.my_boolStandR_xnt !=False :

            #thumb1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb1_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb2_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb3_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"
       
       
       
        
        
        #opppppppp444444444444444444444444444444444444

       
       
       
        if mytool.my_boolStandR_xn !=False :

            #pinky  
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky1_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky2_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['pinky3_ar_R']
                        
            selected_bone = armature1.pose.bones['pinky_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"




        
            #ring 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring1_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring2_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['ring3_ar_R']
                        
            selected_bone = armature1.pose.bones['ring_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"






            #mid1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid1_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid2_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['mid3_ar_R']
                        
            selected_bone = armature1.pose.bones['middle_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"







            #index1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index1_ar_R']
                        
            selected_bone = armature1.pose.bones['index_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index2_ar_R']
                        
            selected_bone = armature1.pose.bones['index_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['index3_ar_R']
                        
            selected_bone = armature1.pose.bones['index_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"



             



        if mytool.my_boolStandR_znt !=False :

            #thumb1_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb1_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_01_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"




            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb2_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_02_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"



            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['thumb3_ar_R']
                        
            selected_bone = armature1.pose.bones['thumb_03_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"
        
        
        
        
        #HAnd_oppppppppppppppppppppppppppppppppppppppppppppppppppppp
        #HAnd_oppppppppppppppppppppppppppppppppppppppppppppppppppppp
        #HAnd_oppppppppppppppppppppppppppppppppppppppppppppppppppppp
        #HAnd_oppppppppppppppppppppppppppppppppppppppppppppppppppppp
        #hand_LLLLLLLLLLLLL#####################################
        

        #OPPPPP1
        if mytool.my_bool_handR_zn !=False :


            #hand_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['hand_ar_R']
                        
            selected_bone = armature1.pose.bones['hand_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_Y_R"



        #OPPPPP2
        if mytool.my_bool_handR_z !=False :


            #hand_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['hand_ar_R']
                        
            selected_bone = armature1.pose.bones['hand_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-Y_R"




        #OPPPPP3
        if mytool.my_bool_handR_x !=False :


            #hand_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['hand_ar_R']
                        
            selected_bone = armature1.pose.bones['hand_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_X_R"


        
        
        #OPPPPP4
        if mytool.my_bool_handR_xn !=False :


            #hand_ar_L 
            armature1 = bpy.data.objects[sce.Armature_Target]
            armature2 = bpy.data.objects['hand_ar_R']
                        
            selected_bone = armature1.pose.bones['hand_r']
                    
            neckconstraint = selected_bone.constraints
            neckCopyRot = neckconstraint.new('COPY_ROTATION')
            neckCopyRot.target = armature2  
            neckCopyRot.subtarget = "finger_-X_R"






       
       
       
       
        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)
       
       
       
       
       




       
        
        
        
        
        
        
        
        
        
        
        #add cons  #add cons  #add cons
        #add cons  #add cons  #add cons
        #add cons  #add cons  #add cons


 









































        #pinky_01_l 
        armature1 = bpy.data.objects[sce.Armature_Target]
        selected_bone = armature1.pose.bones["pinky_01_r"]
        selected_bone2 = armature1.pose.bones["pinky_02_r"]
        selected_bone3 = armature1.pose.bones["pinky_metacarpal_r"]
        selected_bone4 = armature1.pose.bones["pinky_03_r"]
        
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'


        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_02_r"


        
        #new

        # neckconstraint = selected_bone3.constraints
        # neckCopyRot = neckconstraint.new('DAMPED_TRACK')
        # neckCopyRot.target = armature1
        # neckCopyRot.subtarget = "pinky_01_r"
        # neckCopyRot.track_axis = 'TRACK_X'


        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "hand_r"

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "pinky_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
        
        
        



        #ring_01_l 
        selected_bone = armature1.pose.bones["ring_01_r"]
        selected_bone2 = armature1.pose.bones["ring_02_r"]
        selected_bone3 = armature1.pose.bones["ring_metacarpal_r"]
        selected_bone4 = armature1.pose.bones["ring_03_r"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        # neckconstraint = selected_bone3.constraints
        # neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        # neckCopyRot.target = armature1
        # neckCopyRot.subtarget = "ring_01_r"
        # neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        # neckCopyRot.lock_axis = 'LOCK_Y'
        
        
        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_02_r"

         

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "hand_r"


        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "ring_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



   



        #middle_01_l 
        selected_bone = armature1.pose.bones["middle_01_r"]
        selected_bone2 = armature1.pose.bones["middle_02_r"]
        selected_bone3 = armature1.pose.bones["middle_metacarpal_r"]
        selected_bone4 = armature1.pose.bones["middle_03_r"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_02_r"

        #new

        # neckconstraint = selected_bone3.constraints
        # neckCopyRot = neckconstraint.new('DAMPED_TRACK')
        # neckCopyRot.target = armature1
        # neckCopyRot.subtarget = "middle_01_r"
        # neckCopyRot.track_axis = 'TRACK_X'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "hand_r"

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



 





        #index_01_l 
        selected_bone = armature1.pose.bones["index_01_r"]
        selected_bone2 = armature1.pose.bones["index_02_r"]
        selected_bone3 = armature1.pose.bones["index_metacarpal_r"]
        selected_bone4 = armature1.pose.bones["index_03_r"]
        selected_bone5 = armature1.pose.bones["hand_r"]
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'




        neckconstraint = selected_bone4.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_02_r"

        #new

        # neckconstraint = selected_bone3.constraints
        # neckCopyRot = neckconstraint.new('DAMPED_TRACK')
        # neckCopyRot.target = armature1
        # neckCopyRot.subtarget = "index_01_r"
        # neckCopyRot.track_axis = 'TRACK_X'



        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "hand_r"


        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "index_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

        
        
        neckconstraint = selected_bone5.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "middle_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'


        





        #thumb_01_l 
        selected_bone = armature1.pose.bones["thumb_01_r"]
        selected_bone1 = armature1.pose.bones["thumb_02_r"]
        selected_bone2 = armature1.pose.bones["thumb_02_r"]
        selected_bone3 = armature1.pose.bones["thumb_03_r"]


        neckconstraint = selected_bone1.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_01_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'
        


        neckconstraint = selected_bone.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'



        neckconstraint = selected_bone2.constraints
        neckCopyRot = neckconstraint.new('LOCKED_TRACK')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_03_r"
        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
        neckCopyRot.lock_axis = 'LOCK_Y'

       



        neckconstraint = selected_bone3.constraints
        neckCopyRot = neckconstraint.new('COPY_ROTATION')
        neckCopyRot.target = armature1
        neckCopyRot.subtarget = "thumb_02_r"



        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects[sce.Armature_Target] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)









             

        
        
        return {'FINISHED'}
  


class showaxx_op(bpy.types.Operator):
    bl_label = "RFingers"
    bl_idname = "showax.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene
        
        
        global x
       
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        

        
        
        if  x == True:
            x = False
            bpy.context.object.data.show_axes = True
        
        elif x == False:
            
            x = True
            bpy.context.object.data.show_axes = False
        
        
       
            







             

        
        
        return {'FINISHED'}
  