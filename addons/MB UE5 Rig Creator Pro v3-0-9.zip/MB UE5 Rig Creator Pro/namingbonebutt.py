import bpy




class Button_SetBoneName01(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename01"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target1 = i.name
            
        return {'FINISHED'}
    


class Button_SetBoneName02(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename02"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target3 = i.name
            
        return {'FINISHED'}
    


class Button_SetBoneName03(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename03"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target4 = i.name
            
        return {'FINISHED'}
    


class Button_SetBoneName04(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename04"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target6 = i.name
            
        return {'FINISHED'}
    


class Button_SetBoneName05(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename05"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target7 = i.name
            
        return {'FINISHED'}
    

class Button_SetBoneName06butt(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename06butt"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target8 = i.name
            
        return {'FINISHED'}
    



class Button_SetBoneName07(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename07"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target9 = i.name
            
        return {'FINISHED'}
    



class Button_SetBoneName08butt(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename08butt"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target11 = i.name
            
        return {'FINISHED'}
    



class Button_SetBoneName09(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename09"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target12 = i.name
            
        return {'FINISHED'}
    





class Button_SetBoneName010(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename010"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target14 = i.name
            
        return {'FINISHED'}
    




class Button_SetBoneName011(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename011"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target15 = i.name
            
        return {'FINISHED'}
    




class Button_SetBoneName012(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename012"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target16 = i.name
            
        return {'FINISHED'}
    


class Button_SetBoneName013(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename013"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target17 = i.name
            
        return {'FINISHED'}
    




class Button_SetBoneName014(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename014"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target18 = i.name
            
        return {'FINISHED'}
    





class Button_SetBoneName015(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename015"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target20 = i.name
            
        return {'FINISHED'}
    



class Button_SetBoneName016(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename016"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target21 = i.name
            
        return {'FINISHED'}
    




class Button_SetBoneName017(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename017"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target23 = i.name
            
        return {'FINISHED'}
    







class Button_SetBoneName018(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename018"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target24 = i.name
            
        return {'FINISHED'}
    






class Button_SetBoneName019(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename019"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target33 = i.name
            
        return {'FINISHED'}
    




class Button_SetBoneName020(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename020"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target34 = i.name
            
        return {'FINISHED'}
    


class Button_SetBoneName021(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename021"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target35 = i.name
            
        return {'FINISHED'}
    




class Button_SetBoneName022(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename022"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target36 = i.name
            
        return {'FINISHED'}
    





class Button_SetBoneName023(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename023"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target37 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName024(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename024"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target38 = i.name
            
        return {'FINISHED'}
  





class Button_SetBoneName025(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename025"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target39 = i.name
            
        return {'FINISHED'}
  







class Button_SetBoneName026(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename026"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target40 = i.name
            
        return {'FINISHED'}
  






class Button_SetBoneName027(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename027"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_targetHip = i.name
            
        return {'FINISHED'}
  





#Fingers LL



class Button_SetBoneName028(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename028"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target60 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName029(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename029"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target61 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName030(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename030"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target62 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName031(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename031"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target63 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName032(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename032"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target64 = i.name
            
        return {'FINISHED'}
  





class Button_SetBoneName033(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename033"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target65 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName034(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename034"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target66 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName035(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename035"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target67 = i.name
            
        return {'FINISHED'}
  


 

class Button_SetBoneName036(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename036"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target68 = i.name
            
        return {'FINISHED'}
  


class Button_SetBoneName037(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename037"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target69 = i.name
            
        return {'FINISHED'}
  





class Button_SetBoneName038(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename038"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target70 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName039(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename039"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target71 = i.name
            
        return {'FINISHED'}
  





class Button_SetBoneName040(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename040"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target72 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName041(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename041"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target73 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName042(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename042"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target74 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName043(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename043"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target75 = i.name
            
        return {'FINISHED'}
  






class Button_SetBoneName044(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename044"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target76 = i.name
            
        return {'FINISHED'}
  






class Button_SetBoneName045(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename045"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target77 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName046(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename046"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target78 = i.name
            
        return {'FINISHED'}
  




#Fingers rrrrrrrrrrr



class Button_SetBoneName047(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename047"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target41 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName048(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename048"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target42 = i.name
            
        return {'FINISHED'}
  


class Button_SetBoneName049(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename049"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target43 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName050(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename050"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target44 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName051(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename051"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target45 = i.name
            
        return {'FINISHED'}
  






class Button_SetBoneName052(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename052"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target46 = i.name
            
        return {'FINISHED'}
  





class Button_SetBoneName053(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename053"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target47 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName054(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename054"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target48 = i.name
            
        return {'FINISHED'}
  





class Button_SetBoneName055(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename055"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target49 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName056(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename056"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target50 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName057(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename057"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target51 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName058(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename058"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target52 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName059(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename059"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target53 = i.name
            
        return {'FINISHED'}
  





class Button_SetBoneName060(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename060"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target54 = i.name
            
        return {'FINISHED'}
  





class Button_SetBoneName061(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename061"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target55 = i.name
            
        return {'FINISHED'}
  

class Button_SetBoneName062(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename062"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target56 = i.name
            
        return {'FINISHED'}
  



class Button_SetBoneName063(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename063"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target57 = i.name
            
        return {'FINISHED'}
  




class Button_SetBoneName064(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename064"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target58 = i.name
            
        return {'FINISHED'}
  






class Button_SetBoneName065(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename065"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target59 = i.name
            
        return {'FINISHED'}
  









#########




class Button_SetBoneName066(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename066"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target25 = i.name
            
        return {'FINISHED'}
  

 
 

class Button_SetBoneName067(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename067"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target26 = i.name
            
        return {'FINISHED'}
  

 
 


class Button_SetBoneName068(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename068"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target28 = i.name
            
        return {'FINISHED'}
  

 
 


class Button_SetBoneName069(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename069"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target29 = i.name
            
        return {'FINISHED'}
  

 



class Button_SetBoneName070(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename070"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target31 = i.name
            
        return {'FINISHED'}
  

 


class Button_SetBoneName071(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename071"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target32 = i.name
            
        return {'FINISHED'}
  



#New
 
class Button_SetBoneName072(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename072"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target2 = i.name
            
        return {'FINISHED'}
  

  
class Button_SetBoneName073(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename073"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target5 = i.name
            
        return {'FINISHED'}
  

  
class Button_SetBoneName074(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename074"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target10 = i.name
            
        return {'FINISHED'}
  

  
class Button_SetBoneName075(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename075"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target13 = i.name
            
        return {'FINISHED'}
  



  
class Button_SetBoneName076(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename076"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target19 = i.name
            
        return {'FINISHED'}
  


  
class Button_SetBoneName077(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename077"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target22 = i.name
            
        return {'FINISHED'}
  


  
class Button_SetBoneName078(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename078"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target27 = i.name
            
        return {'FINISHED'}
  


  
class Button_SetBoneName079(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "Show Bone Map"
    bl_idname = "mb.setbonename079"
    bl_options = {'REGISTER', 'UNDO'} 

    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.selected_pose_bones
 
        for i in bpy.context.selected_pose_bones:
            print(i.name)
            sce.bone_target30 = i.name
            
        return {'FINISHED'}
  



































































    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
  
  
  
  
  
  
  
  
  
  
  
  
  
    
    
    