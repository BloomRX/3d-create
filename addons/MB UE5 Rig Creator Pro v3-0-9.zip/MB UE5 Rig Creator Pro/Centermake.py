import bpy





class center_OT_op(bpy.types.Operator):
    bl_label = "Apply"
    bl_idname = "center.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False 
        scene = bpy.context.scene
        scene.frame_set(1)

        #Delete Anim on object mode

        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        context = bpy.context
        ob = context.object
        ad = ob.animation_data

        if ad:
            action = ad.action
            if action:
                remove_types = ["location", "scale", "rotation"]
                # select all that have datapath above
                fcurves = [fc for fc in action.fcurves
                        for type in remove_types
                        if fc.data_path.startswith(type)
                        ]
                # remove fcurves
                while(fcurves):
                    fc = fcurves.pop()
                    action.fcurves.remove(fc)


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')   
        
        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        ob = bpy.data.objects[sce.Armature_Target]
        armature = ob.data
        bpy.ops.object.mode_set(mode='POSE')
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.select_all(action='DESELECT')
        b=ob.data.bones[sce.bone_targetHip] 
        b.select=True
        ob.data.bones.active=b
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.mode_set(mode='OBJECT')


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')


        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
        bpy.context.active_object.name = 'For_CenterAnim'

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 

        bpy.ops.object.constraint_add(type='COPY_LOCATION')
        bpy.context.object.constraints["Copy Location"].target = bpy.data.objects["For_CenterAnim"]
        bpy.context.object.constraints["Copy Location"].use_z = False
        bpy.ops.constraint.apply(constraint="Copy Location", owner='OBJECT')

       
         


        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        ob = bpy.data.objects[sce.Armature_Target]
        armature = ob.data
        bpy.ops.object.mode_set(mode='POSE')
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.pose.select_all(action='DESELECT')
        b=ob.data.bones[sce.bone_targetHip] 
        b.select=True
        ob.data.bones.active=b
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.mode_set(mode='OBJECT')

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect 
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')


       
       
       
        bjectToSelect = bpy.data.objects[sce.Armature_Target]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        ob = bpy.data.objects[sce.Armature_Target]
        armature = ob.data
        bpy.ops.object.mode_set(mode='POSE')
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.pose.select_all(action='DESELECT')
        b=ob.data.bones[sce.bone_targetHip] 
        b.select=True
        ob.data.bones.active=b
        bpy.ops.pose.constraint_add(type='COPY_LOCATION')
        bpy.context.object.pose.bones[sce.bone_targetHip].constraints["Copy Location"].target = bpy.data.objects["For_CenterAnim"]
        bpy.context.object.pose.bones[sce.bone_targetHip].constraints["Copy Location"].use_z = False
        bpy.ops.constraint.apply(constraint="Copy Location", owner='BONE')
        bpy.ops.object.mode_set(mode='OBJECT')



        objects = bpy.context.scene.objects.keys()
        if  'For_CenterAnim' in objects:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["For_CenterAnim"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')

        


        



         



       


        
        
        return {'FINISHED'}
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)

