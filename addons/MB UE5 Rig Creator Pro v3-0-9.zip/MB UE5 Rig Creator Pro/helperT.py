


import bpy
import json
import os
import bmesh 
import math




 
class helper_OT_op(bpy.types.Operator):
    bl_label = "Apply"
    bl_idname = "helpert.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        if  sce.Armature_Target !="":

            if mytool.my_bool33 !=False :

                mytool.my_int_famee = bpy.context.scene.frame_end    
                
                #Rig RF For Anime 
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                bpy.ops.object.duplicate()
                bpy.context.active_object.name = 'RF_For_Animation_t'

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["RF_For_Animation_t"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect



                for obj in bpy.context.selected_objects:
                    obj.name = "RF_For_AnimHelper"
                    obj.data.name = "RF_For_AnimHelper"


            

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["RF_For_AnimHelper"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["RF_For_AnimHelper"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects["RF_For_AnimHelper"] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.loc_clear()
                bpy.ops.pose.rot_clear()

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')









            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            
            if mytool.my_bool33 !=False :

            
                context = bpy.context
                object = context.object

                #should put checks in to see if you have object animation_data etc

                action = object.animation_data.action  # this is the action that is shown in action editor.

                # the action can be unlinked using.

                object.animation_data.action = None

    

            
            #bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        


            # Clear existing selections
        bpy.ops.object.select_all(action='DESELECT')

        # List to store selected mesh objects
        selected_objects = []

        # Iterate through all objects in the scene
        for obj in bpy.context.scene.objects:
            # Check if the object is a mesh
            if obj.type == 'MESH':
                # Check if the object has a parent that is an armature
                if obj.parent and obj.parent.type == 'ARMATURE':
                    obj.select_set(True)
                    selected_objects.append(obj)
                # Check if the object has an Armature modifier
                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                    obj.select_set(True)
                    selected_objects.append(obj)

        # Check if there are selected objects to join
        if selected_objects:
            # Set the active object to the first selected object
            bpy.context.view_layer.objects.active = selected_objects[0]

            # Join all selected objects into the active object
            bpy.ops.object.join()
             



            rig = bpy.data.objects[sce.Armature_Target]
            for obj in bpy.data.objects:
                if (obj.type == 'MESH' and
                    rig in [m.object for m in obj.modifiers if m.type == 'ARMATURE']
                    ):
                    #bpy.ops.object.parent_clear(type='CLEAR')
                    obj.select_set(obj.type == "MESH") 
                    pass        

            for obj in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = obj
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE':
                    
                        modifier.name ='root'
            
            bpy.ops.object.select_all(action='DESELECT')
            
            
            
            
            
            
            
            
            




        # Clear existing selections
        bpy.ops.object.select_all(action='DESELECT')

        # List to store selected mesh objects
        selected_objects = []

        # Iterate through all objects in the scene
        for obj in bpy.context.scene.objects:
            # Check if the object is a mesh
            if obj.type == 'MESH':
                # Check if the object has a parent that is an armature
                if obj.parent and obj.parent.type == 'ARMATURE':
                    obj.select_set(True)
                    selected_objects.append(obj)
                # Check if the object has an Armature modifier
                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                    obj.select_set(True)
                    selected_objects.append(obj)

        # Check if there are selected objects to join
        if selected_objects:
            # Set the active object to the first selected object
            bpy.context.view_layer.objects.active = selected_objects[0]

            # Join all selected objects into the active object
           
            # Update the view
            bpy.context.view_layer.update()


        bpy.ops.object.modifier_apply_as_shapekey(keep_modifier=True, modifier="root")


         
        
        # target_obj = bpy.context.active_object

        # # Check if the active object is not None and is a mesh
        # if target_obj and target_obj.type == 'MESH':

        #     # Check if the shape key named 'root' exists
        #     if target_obj.data.shape_keys and 'root' in target_obj.data.shape_keys.key_blocks:
        #         shape_key_data = target_obj.data.shape_keys.key_blocks['root'].data

        #         # Create a BMesh for the target object
        #         bm = bmesh.new()
        #         bm.from_mesh(target_obj.data)

        #         # Apply the shape key vertices to the BMesh
        #         for i, v in enumerate(bm.verts):
        #             v.co = shape_key_data[i].co

        #         # Update the mesh with the applied shape key
        #         bm.to_mesh(target_obj.data)
        #         bm.free()

        #         # Update the target object
        #         target_obj.data.update()

        #         # If you are in Edit Mode, you might also want to update the mesh in the 3D view
        #         bpy.context.view_layer.update()

        obj = bpy.context.active_object

        # Ensure the object has shape keys
        if obj.data.shape_keys:
            # Select the first shape key
            obj.active_shape_key_index = 0
        else:
            print("No shape keys found in the selected object.")
        
        
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.blend_from_shape()
        bpy.ops.mesh.blend_from_shape(shape='root')
        bpy.ops.mesh.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')     





        target_obj = bpy.context.active_object

        # Check if the active object is not None and is a mesh
        if target_obj and target_obj.type == 'MESH':

            # Check if the shape key named 'root' exists
            if target_obj.data.shape_keys and 'root' in target_obj.data.shape_keys.key_blocks:
 

                # Set the name of the shape key you want to delete
                shape_key_name = "root"

                # Get the active object
                obj = bpy.context.active_object

                # Check if the object has shape keys
                if obj and obj.data.shape_keys:
                    # Check if the shape key exists
                    if shape_key_name in obj.data.shape_keys.key_blocks:
                        # Select the object and go to Object mode (optional)
                        bpy.context.view_layer.objects.active = obj
                        bpy.ops.object.mode_set(mode='OBJECT')

                        # Set the active shape key to the one you want to delete
                        obj.active_shape_key_index = obj.data.shape_keys.key_blocks.find(shape_key_name)

                        # Delete the active shape key
                        bpy.ops.object.shape_key_remove(all=False)

                        print(f"Shape key '{shape_key_name}' deleted.")
                    else:
                        print(f"Shape key '{shape_key_name}' not found.")
                else:
                    print("No active object or no shape keys.")            

                
        
                    



            #///Apply  pose

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            #Mirror 
            bpy.context.object.data.use_mirror_x = False
            
            ob = bpy.data.objects[sce.Armature_Target] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='SELECT')
            
            bpy.ops.object.posemode_toggle()

            bpy.ops.pose.armature_apply(selected=False)
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')



 
          
          
            if mytool.my_bool33 !=False :
            
            
            
                armatureFrom = bpy.data.objects['RF_For_AnimHelper']
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)

                    copy_con = boneTo.constraints.new('COPY_ROTATION')
                    copy_con.target = armatureFrom
                    copy_con.subtarget = boneFrom.name
                    
                    copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                    copy_con2.target = armatureFrom
                    copy_con2.subtarget = boneFrom.name

                    copy_con3 = boneTo.constraints.new('COPY_SCALE')
                    copy_con3.target = armatureFrom
                    copy_con3.subtarget = boneFrom.name
                    copy_con3.target_space = 'LOCAL'
                    copy_con3.owner_space = 'LOCAL'
            
            



                # #bake
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect


                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                #myBone = armature.edit_bones[sce.bone_target1]
                #myBone.select = True
                #armature.edit_bones.active = myBone
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.nla.bake(frame_start=mytool.my_int_feames, frame_end=mytool.my_int_famee, step=1, only_selected=True, visual_keying=True, clear_constraints=True, clear_parents=True, use_current_action=True, clean_curves=False, bake_types={'POSE'})
                bpy.ops.object.mode_set(mode='OBJECT')
            


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)



            objects = bpy.context.scene.objects.keys()
            if  'RF_For_AnimHelper' in objects:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["RF_For_AnimHelper"]
                objectToSelect2.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.delete(use_global=False)
                bpy.ops.object.select_all(action='DESELECT')


 
        
        
        
           



 




        
        
        return {'FINISHED'}
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)


 
class apply_scaleonly_op(bpy.types.Operator):
    bl_label = "Apply"
    bl_idname = "apolyscale.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene
        

        
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        scene = bpy.context.scene
        scene.frame_set(1)

        if  sce.Armature_Target !="":

            if mytool.my_bool33 !=False :

                mytool.my_int_famee = bpy.context.scene.frame_end    
                
                #Rig RF For Anime 
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                bpy.ops.object.duplicate()
                bpy.context.active_object.name = 'RF_For_Animation_t'

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["RF_For_Animation_t"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect



                for obj in bpy.context.selected_objects:
                    obj.name = "RF_For_AnimHelper"
                    obj.data.name = "RF_For_AnimHelper"


            

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["RF_For_AnimHelper"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["RF_For_AnimHelper"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects["RF_For_AnimHelper"] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.loc_clear()
                bpy.ops.pose.rot_clear()

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')









            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            
            if mytool.my_bool33 !=False :

            
                context = bpy.context
                object = context.object

                #should put checks in to see if you have object animation_data etc

                action = object.animation_data.action  # this is the action that is shown in action editor.

                # the action can be unlinked using.

                object.animation_data.action = None

    
 


            #set name for  ARMATURE
        
            bpy.ops.object.select_all(action='DESELECT')

            rig = bpy.data.objects[sce.Armature_Target]
            for obj in bpy.data.objects:
                if (obj.type == 'MESH' and
                    rig in [m.object for m in obj.modifiers if m.type == 'ARMATURE']
                    ):
                    #bpy.ops.object.parent_clear(type='CLEAR')
                    obj.select_set(obj.type == "MESH") 
                    pass        

            for obj in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = obj
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE':
                    
                        modifier.name ='rig'


        
            
                
        
                   


             





            armatureFrom = bpy.data.objects[sce.Armature_Target]
            armatureTo = bpy.data.objects[sce.Armature_Target]

            for boneTo in armatureTo.pose.bones:
                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                if boneFrom == None:
                    continue

                for con in boneTo.constraints:
                    boneTo.constraints.remove(con)



        
 
            

             
        
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)     
          
          
           
          
          
          
          
            if mytool.my_bool33 !=False :
            
            
            
                armatureFrom = bpy.data.objects['RF_For_AnimHelper']
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)

                    copy_con = boneTo.constraints.new('COPY_ROTATION')
                    copy_con.target = armatureFrom
                    copy_con.subtarget = boneFrom.name
                    
                    copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                    copy_con2.target = armatureFrom
                    copy_con2.subtarget = boneFrom.name

                    copy_con3 = boneTo.constraints.new('COPY_SCALE')
                    copy_con3.target = armatureFrom
                    copy_con3.subtarget = boneFrom.name
                    copy_con3.target_space = 'LOCAL'
                    copy_con3.owner_space = 'LOCAL'
            
            



                # #bake
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect


                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                #myBone = armature.edit_bones[sce.bone_target1]
                #myBone.select = True
                #armature.edit_bones.active = myBone
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.nla.bake(frame_start=mytool.my_int_feames, frame_end=mytool.my_int_famee, step=1, only_selected=True, visual_keying=True, clear_constraints=True, clear_parents=True, use_current_action=True, clean_curves=False, bake_types={'POSE'})
                bpy.ops.object.mode_set(mode='OBJECT')
            


                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)



            objects = bpy.context.scene.objects.keys()
            if  'RF_For_AnimHelper' in objects:

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["RF_For_AnimHelper"]
                objectToSelect2.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.delete(use_global=False)
                bpy.ops.object.select_all(action='DESELECT')



            bpy.ops.object.select_all(action='DESELECT')
            rig = bpy.data.objects[sce.Armature_Target]
            for obj in bpy.data.objects:
                if (obj.type == 'MESH' and
                    rig in [m.object for m in obj.modifiers if m.type == 'ARMATURE']
                    ):
                    #bpy.ops.object.parent_clear(type='CLEAR')
                    obj.select_set(obj.type == "MESH") 
                    pass     
        
        
        
            for obj in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = obj
                
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)




            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects[sce.Armature_Target]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect




        
        
        return {'FINISHED'}
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)


 
class removeac_OT_op(bpy.types.Operator):
    bl_label = "Apply"
    bl_idname = "removeac.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        # bpy.ops.object.select_all(action='DESELECT')
        # objectToSelect = bpy.data.objects["root"]
        # objectToSelect.select_set(True)    
        # bpy.context.view_layer.objects.active = objectToSelect


        # for action in bpy.data.actions:
        #     action.use_fake_user = False

        #     # remove only unused action and does not have use_fake_user
        #     if action.users == 0 and not action.use_fake_user:
        #         bpy.data.actions.remove(action)

      

 

        #Delete unused Anim #Delete unused Anim #Delete unused Anim #Delete unused Anim

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["root"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        
        # Get the active object
        obj = bpy.context.object

        # Get the action data of the object
        action_data = obj.animation_data

        # Get the action of the object
        action = action_data.action

        # Print the name of the action
        print(action.name)
                
        bpy.data.actions[action.name].use_fake_user = True
        bpy.data.actions[action.name].name = "Animation"



        # Get all actions
        actions = bpy.data.actions

        # Set use_fake_user to False for all actions
        for action in actions:
            action.use_fake_user = False



        
        bpy.data.actions["Animation"].use_fake_user = True
         


    

        for action in bpy.data.actions:
            if not action.use_fake_user:
                bpy.data.actions.remove(action)







       





        
        
        return {'FINISHED'}
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)

