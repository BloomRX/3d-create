import bpy






class deletttmup_op(bpy.types.Operator):
    bl_label = "delettem"
    bl_idname = "delettem.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["hand_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["hand_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["hand_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["hand_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["index1_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["index2_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2






        objectToSelect2 = bpy.data.objects["index3_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2





        objectToSelect2 = bpy.data.objects["index1_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["index1_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["index1_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["index2_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["index2_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["index2_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2




        objectToSelect2 = bpy.data.objects["index2_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["index3_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["index3_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["index3_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["index3_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["mid1_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["mid1_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["mid1_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["mid1_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["mid2_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["mid2_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["mid2_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2



        objectToSelect2 = bpy.data.objects["mid2_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["mid3_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        

        objectToSelect2 = bpy.data.objects["mid3_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["mid3_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["mid3_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky1_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky1_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky1_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky1_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky2_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky2_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky2_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky2_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky3_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky3_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky3_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["pinky3_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["ring1_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["ring1_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["ring1_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring1_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring2_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring2_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring2_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring2_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring3_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring3_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring3_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["ring3_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["thumb1_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["thumb1_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["thumb1_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["thumb1_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["thumb2_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["thumb2_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["thumb2_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["thumb2_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["thumb3_ar_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        objectToSelect2 = bpy.data.objects["thumb3_ar_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["thumb3_AXES_L"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        objectToSelect2 = bpy.data.objects["thumb3_AXES_R"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.delete(use_global=False)

        
        
      
       

       
 
     

       
            







             

        
        
        return {'FINISHED'}
  