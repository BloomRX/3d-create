

import bpy



class Auto_SetScalerf(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "auto"
    bl_idname = "mb.autoscaler"
    bl_options = {'REGISTER', 'UNDO'}  
    
    #center : bpy.props.BoolProperty(name= "Spine01 Center scale ", default= False)
   
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        #c = self.center
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False







        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' not in  objects:

            if sce.bone_targetHip =="" :

                self.report({"WARNING"}, "required set Hips/Pelvis Bone")


            if sce.bone_targetHip !="" and sce.Armature_Target !="" :

        
                bpy.ops.object.select_all(action='DESELECT')  
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='SELECT')
                bpy.ops.pose.rot_clear()
                bpy.ops.pose.loc_clear()
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones[sce.bone_targetHip] 
                ob.data.bones.active=b
                bpy.ops.view3d.snap_cursor_to_selected()
                bpy.ops.object.mode_set(mode='OBJECT')


                # Create a new armature object
                armature = bpy.data.armatures.new("Scalebound")
                armature_obj = bpy.data.objects.new("Scalebound", armature)

                # Link the armature object to the scene
                scene = bpy.context.scene
                scene.collection.objects.link(armature_obj)

                # Make the armature the active object
                bpy.context.view_layer.objects.active = armature_obj
                armature_obj.select_set(True)

                # Switch to Edit mode to add bones
                bpy.ops.object.mode_set(mode='EDIT')

                # Create a new bone
                bone = armature.edit_bones.new("Bone1")
                bone.head = (0, 0, 0)
                bone.tail = (0, 0, 1)

                


                # Switch to Edit mode
                bpy.ops.object.mode_set(mode='EDIT')

                # Get a reference to "Bone1"
                bone = armature_obj.data.edit_bones["Bone1"]

                # Set the tail of the bone to the 3D cursor location
                bone.tail = bpy.context.scene.cursor.location
                bone.tail[0] += 0.00001
                bone.tail[1] += 0.00001
                #new
                bone.tail[2] += 0.00001



                # Switch back to Object mode
                bpy.ops.object.mode_set(mode='OBJECT')



         

 




        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' not in  objects:

            if sce.bone_targetHip =="" :

                self.report({"WARNING"}, "required set Hips/Pelvis Bone")


            if sce.bone_targetHip !="" and sce.Armature_Target !="" :

                scene = bpy.context.scene
                scene.frame_set(1)

                

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2



                bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')

                

                collections = bpy.context.object.data.collections

                for layer in range(len(collections)):
                    collections[layer].is_visible = True
                

                # ############
                # armature = bpy.context.active_object
                # armature.scale = (1, 1, 1)
                # ###############


                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2

                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)

                 








                #Delete Anim on object mode

                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.posemode_toggle()
                bpy.ops.pose.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')
 

                context = bpy.context
                ob = context.object
                ad = ob.animation_data

                if ad:
                    action = ad.action
                    if action:
                        remove_types = ["location", "scale", "rotation"]
                        # select all that have datapath above
                        fcurves = [fc for fc in action.fcurves
                                for type in remove_types
                                if fc.data_path.startswith(type)
                                ]
                        # remove fcurves
                        while(fcurves):
                            fc = fcurves.pop()
                            action.fcurves.remove(fc)


                
                

                ##Unlock all bones
                ##Rest in pose mode and Unlock all bones
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.posemode_toggle()
                bpy.ops.pose.select_all(action='SELECT')
                for b in bpy.context.active_object.pose.bones:
                    b.lock_location[0] = False # x
                    b.lock_location[1] = False # y
                    b.lock_location[2] = False # z
                    
                    b.lock_rotation[0] = False # x
                    b.lock_rotation[1] = False # y
                    b.lock_rotation[2] = False # z
                    
                    
                    b.lock_scale[0] = False # x
                    b.lock_scale[1] = False # y
                    b.lock_scale[2] = False # z
                bpy.ops.pose.rot_clear()
                bpy.ops.pose.loc_clear()
                bpy.ops.object.mode_set(mode='OBJECT')


                
                



                











            
                bpy.ops.view3d.snap_cursor_to_center()
                bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'
                bpy.context.scene.unit_settings.system = 'METRIC'
                bpy.context.scene.unit_settings.scale_length = 0.01
                bpy.context.space_data.clip_end = 100000
                bpy.context.space_data.clip_start = 0.1
                 

                bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, -2.3795, 98.6932), scale=(1, 1, 1))

                bpy.context.active_object.name = 'UE5_Character_Scale_RF'
                bpy.context.object.display_type = 'WIRE'
                bpy.context.object.show_in_front = True

                bpy.context.object.lock_location[0] = True
                bpy.context.object.lock_location[1] = True
                bpy.context.object.lock_location[2] = True
                bpy.context.object.lock_rotation[0] = True
                bpy.context.object.lock_rotation[1] = True
                bpy.context.object.lock_rotation[2] = True


                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 

                bpy.context.object.lock_location[0] = False
                bpy.context.object.lock_location[1] = False
                bpy.context.object.lock_location[2] = False
                bpy.context.object.lock_rotation[0] = False
                bpy.context.object.lock_rotation[1] = False
                bpy.context.object.lock_rotation[2] = False
                bpy.context.object.lock_scale[0] = False
                bpy.context.object.lock_scale[1] = False
                bpy.context.object.lock_scale[2] = False


                


 
                
                # objectToSelect = bpy.data.objects[sce.Armature_Target]
                # objectToSelect.select_set(True)    
                # bpy.context.view_layer.objects.active = objectToSelect
                # ob = bpy.data.objects[sce.Armature_Target]
                # armature = ob.data
                # bpy.ops.object.mode_set(mode='POSE')
                # bpy.ops.pose.select_all(action='SELECT')
                # bpy.ops.pose.rot_clear()
                # bpy.ops.pose.loc_clear()
                # bpy.ops.pose.select_all(action='DESELECT')
                # b=ob.data.bones[sce.bone_target15] 
                # b.select=True
                # c=ob.data.bones[sce.bone_target7] 
                # c.select=True
                # ob.data.bones.active=b
                # bpy.ops.view3d.snap_cursor_to_selected()
                # bpy.ops.object.mode_set(mode='OBJECT')

                bpy.ops.view3d.snap_cursor_to_center()


                 


                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 
                bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
                bpy.ops.object.location_clear(clear_delta=False)




                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.posemode_toggle()
                bpy.ops.pose.select_all(action='SELECT')
                bpy.ops.pose.rot_clear()
                bpy.ops.pose.loc_clear()
                bpy.ops.object.mode_set(mode='OBJECT')


                



  

                ##Rest in pose mode
            
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.loc_clear()
                bpy.ops.pose.rot_clear()
                bpy.ops.object.mode_set(mode='OBJECT')

                # for area in bpy.context.screen.areas:
                #         if area.type == 'VIEW_3D':
                #             override = bpy.context.copy()
                #             override['area'] = area
                #             bpy.ops.view3d.view_axis(override, type='FRONT')
                #             break

                
                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["UE5_Character_Scale_RF"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect


             

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 
 
               
                bpy.ops.object.select_all(action='DESELECT')
           
           
           
           
                # ####ِAuto size
                # bpy.context.scene.unit_settings.scale_length = 0.01
                # bpy.ops.mesh.primitive_cube_add(size=5, location=(0, 0, 90))  
                # bpy.ops.transform.resize(value=(50, 50, 36))
                # bpy.context.active_object.name = 'UE5_Char_AutoScale'
                # bpy.context.object.display_type = 'WIRE'


                #new

                bpy.ops.mesh.primitive_cube_add(size=5, location=(0, 0, 50))  
                bpy.ops.transform.resize(value=(50, 50, 19.7))
                bpy.context.active_object.name = 'UE5_Char_AutoScale'
                bpy.context.object.display_type = 'WIRE'









                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["UE5_Char_AutoScale"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)


                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 



    

                # Define the names of the child and parent objects
                child_object_name = sce.Armature_Target
                parent_object_name = "Scalebound"

                # Check if the specified objects exist in the scene
                if child_object_name in bpy.data.objects and parent_object_name in bpy.data.objects:
                    # Get references to the child and parent objects
                    child_object = bpy.data.objects[child_object_name]
                    parent_object = bpy.data.objects[parent_object_name]

                    # Set the parent of the child object to the parent object using 'OBJECT' type
                    bpy.ops.object.select_all(action='DESELECT')  # Deselect all objects
                    child_object.select_set(True)
                    parent_object.select_set(True)
                    bpy.context.view_layer.objects.active = parent_object  # Set the parent object as the active object
                    bpy.ops.object.parent_set(type='OBJECT', keep_transform=False)

                    # Print a message to confirm the parenting operation
                    print(f"Set '{parent_object_name}' as the parent of '{child_object_name}'")
                else:
                    print("One or both of the specified objects do not exist in the scene.")



            
    





                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["Scalebound"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect


            

                # Get references to the cube and armature objects
                cube = bpy.data.objects['UE5_Char_AutoScale']  # Replace 'Cube' with the name of your cube
                armature = bpy.context.active_object


                # Get the dimensions of the cube
                cube_dimensions = cube.dimensions

                # Calculate the scaling factors for each axis
                scale_factors = (
                    cube_dimensions.x / armature.dimensions.x,
                    cube_dimensions.y / armature.dimensions.y,
                    cube_dimensions.z / armature.dimensions.z
                )

                # Find the minimum scale factor (to avoid stretching)
                min_scale = min(scale_factors)

                # Apply the uniform scale factor to the armature
                armature.scale = (min_scale, min_scale, min_scale)

                # Set the location of the armature to match the cube
                armature.location = cube.location



                

                




















                bpy.ops.view3d.view_all(center=False)


                # objects = bpy.context.scene.objects.keys()
                # if  'UE5_Char_AutoScale' in objects:

                
                    
                #     bpy.ops.object.select_all(action='DESELECT')
                #     objectToSelect2 = bpy.data.objects["UE5_Char_AutoScale"]
                #     objectToSelect2.select_set(True)    
                #     bpy.context.view_layer.objects.active = objectToSelect2
                #     bpy.ops.object.delete(use_global=False) 



                # objects = bpy.context.scene.objects.keys()
                # if  'UE5_Character_Scale_RF' in objects:

                
                    
                #     bpy.ops.object.select_all(action='DESELECT')
                #     objectToSelect2 = bpy.data.objects["UE5_Character_Scale_RF"]
                #     objectToSelect2.select_set(True)    
                #     bpy.context.view_layer.objects.active = objectToSelect2
                #     bpy.ops.object.delete(use_global=False)  

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 

                bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')

    
    


                objects = bpy.context.scene.objects.keys()
                if  'Scalebound' in objects:

                
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["Scalebound"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False) 





                objects = bpy.context.scene.objects.keys()
                if  'UE5_Char_AutoScale' in objects:

                
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["UE5_Char_AutoScale"]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.delete(use_global=False) 














        return {'FINISHED'}


    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self) 
    




class Offist_SetScalerf(bpy.types.Operator):
    """Open the Dialog box"""
    bl_label = "use only scale to Align character feet with the ground"
    bl_idname = "mb.charautoffs"
    bl_options = {'REGISTER', 'UNDO'}  
    
    #center : bpy.props.BoolProperty(name= "Spine01 Center scale ", default= False)
   
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        #c = self.center
        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False



        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' not in  objects:

            bpy.ops.mb.autoscaler()




        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' in objects:

        
            
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["UE5_Character_Scale_RF"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)  




        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' not in  objects:

            if sce.bone_targetHip =="" :

                self.report({"WARNING"}, "required set Hips/Pelvis Bone")


            if sce.bone_targetHip !="" and sce.Armature_Target !="" :

                scene = bpy.context.scene
                scene.frame_set(1)

                

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2


                collections = bpy.context.object.data.collections

                for layer in range(len(collections)):
                    collections[layer].is_visible = True

                 
                


                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2

                armatureFrom = bpy.data.objects[sce.Armature_Target]
                armatureTo = bpy.data.objects[sce.Armature_Target]

                for boneTo in armatureTo.pose.bones:
                    boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                    if boneFrom == None:
                        continue

                    for con in boneTo.constraints:
                        boneTo.constraints.remove(con)

                 








                #Delete Anim on object mode

                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.posemode_toggle()
                bpy.ops.pose.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='OBJECT')
 

                context = bpy.context
                ob = context.object
                ad = ob.animation_data

                if ad:
                    action = ad.action
                    if action:
                        remove_types = ["location", "scale", "rotation"]
                        # select all that have datapath above
                        fcurves = [fc for fc in action.fcurves
                                for type in remove_types
                                if fc.data_path.startswith(type)
                                ]
                        # remove fcurves
                        while(fcurves):
                            fc = fcurves.pop()
                            action.fcurves.remove(fc)


                
                

                ##Unlock all bones
                ##Rest in pose mode and Unlock all bones
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.posemode_toggle()
                bpy.ops.pose.select_all(action='SELECT')
                for b in bpy.context.active_object.pose.bones:
                    b.lock_location[0] = False # x
                    b.lock_location[1] = False # y
                    b.lock_location[2] = False # z
                    
                    b.lock_rotation[0] = False # x
                    b.lock_rotation[1] = False # y
                    b.lock_rotation[2] = False # z
                    
                    
                    b.lock_scale[0] = False # x
                    b.lock_scale[1] = False # y
                    b.lock_scale[2] = False # z
                bpy.ops.pose.rot_clear()
                bpy.ops.pose.loc_clear()
                bpy.ops.object.mode_set(mode='OBJECT')


                
                



                











            
                bpy.ops.view3d.snap_cursor_to_center()
                bpy.context.scene.tool_settings.transform_pivot_point = 'ACTIVE_ELEMENT'
                bpy.context.scene.unit_settings.system = 'METRIC'
                bpy.context.scene.unit_settings.scale_length = 0.01
                bpy.context.space_data.clip_end = 100000
                bpy.context.space_data.clip_start = 0.1
                 

                bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, -2.3795, 98.6932), scale=(1, 1, 1))

                bpy.context.active_object.name = 'UE5_Character_Scale_RF'
                bpy.context.object.display_type = 'WIRE'
                bpy.context.object.show_in_front = True

                bpy.context.object.lock_location[0] = True
                bpy.context.object.lock_location[1] = True
                bpy.context.object.lock_location[2] = True
                bpy.context.object.lock_rotation[0] = True
                bpy.context.object.lock_rotation[1] = True
                bpy.context.object.lock_rotation[2] = True


                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 

                bpy.context.object.lock_location[0] = False
                bpy.context.object.lock_location[1] = False
                bpy.context.object.lock_location[2] = False
                bpy.context.object.lock_rotation[0] = False
                bpy.context.object.lock_rotation[1] = False
                bpy.context.object.lock_rotation[2] = False
                bpy.context.object.lock_scale[0] = False
                bpy.context.object.lock_scale[1] = False
                bpy.context.object.lock_scale[2] = False


                


 
                
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects[sce.Armature_Target]
                armature = ob.data
                bpy.ops.object.mode_set(mode='POSE')
                bpy.ops.pose.select_all(action='SELECT')
                bpy.ops.pose.rot_clear()
                bpy.ops.pose.loc_clear()
                bpy.ops.pose.select_all(action='DESELECT')
                b=ob.data.bones[sce.bone_targetHip] 
                b.select=True
                ob.data.bones.active=b
                bpy.ops.view3d.snap_cursor_to_selected()
                bpy.ops.object.mode_set(mode='OBJECT')


                 





                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 
                bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
                bpy.ops.object.location_clear(clear_delta=False)



                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["UE5_Character_Scale_RF"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 

                #bpy.ops.view3d.snap_cursor_to_selected()




                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 

                bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)


                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                bpy.ops.object.posemode_toggle()
                bpy.ops.pose.select_all(action='SELECT')
                bpy.ops.pose.rot_clear()
                bpy.ops.pose.loc_clear()
                bpy.ops.object.mode_set(mode='OBJECT')


                bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                bpy.context.active_object.name = 'use only scale to Align character feet with the ground'
                bpy.context.object.show_name = True



  

                ##Rest in pose mode
            
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect

                ##Rest in pose mode
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2
                ob = bpy.data.objects[sce.Armature_Target] 
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='SELECT')
                
                bpy.ops.object.posemode_toggle()

                bpy.ops.pose.loc_clear()
                bpy.ops.pose.rot_clear()
                bpy.ops.object.mode_set(mode='OBJECT')

                
                
                
                
                #bpy.ops.view3d.view_axis(type='FRONT')

                
                
                
                
                
                
                
                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects["UE5_Character_Scale_RF"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect


                
                objectToSelect = bpy.data.objects["use only scale to Align character feet with the ground"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                
                
                bpy.ops.view3d.view_selected(use_all_regions=False)   

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect = bpy.data.objects[sce.Armature_Target]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect 
 
               

            # ####ِAuto size
            # bpy.context.scene.unit_settings.scale_length = 0.01
            # bpy.ops.mesh.primitive_cube_add(size=5, location=(0, 0, 90))  
            # bpy.ops.transform.resize(value=(50, 50, 36))
            # bpy.context.space_data.clip_end = 100000
            # bpy.context.space_data.clip_start = 0.1
            # bpy.context.active_object.name = 'UE5_Char_AutoScale'
            # bpy.context.object.display_type = 'WIRE'

            # bpy.ops.object.select_all(action='DESELECT')
            # objectToSelect = bpy.data.objects["UE5_Char_AutoScale"]
            # objectToSelect.select_set(True)    
            # bpy.context.view_layer.objects.active = objectToSelect
            # bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)


          


            # # Get the target object
            # bpy.ops.object.select_all(action='DESELECT')
            # target_obj = bpy.data.objects[sce.Armature_Target]

            # # Get the object to scale
            # obj_to_scale = bpy.data.objects["UE5_Char_AutoScale"]

            # # Calculate the size of the target object's bounding box
            # target_size = target_obj.dimensions

            # # Calculate the scale factor needed to fit the object inside the target's bounding box
            # scale_factor = [target_size[i]/obj_to_scale.dimensions[i] for i in range(3)]

            # # Scale the object
            # obj_to_scale.scale = scale_factor
            # obj_to_scale.select_set(state=True)


            # bpy.context.object.scale[0] = bpy.context.object.scale[2] 
            # bpy.context.object.scale[1] = bpy.context.object.scale[2]  
















        return {'FINISHED'}


    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self) 
    











































