
import bpy

def rigrfuev():
    

    bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
    bpy.context.active_object.name = 'rig_spine_rf'

    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["rig_spine_rf"]
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    
    for obj in bpy.context.selected_objects:
        obj.name = "RF_UEV_spine_spine"
        obj.data.name = "RF_UEV_spine_spine"
    
    
    #///////////Naming
    bpy.ops.object.select_all(action='DESELECT')
        
    objectToSelect = bpy.data.objects["RF_UEV_spine_spine"] 
    objectToSelect.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect
    ob = bpy.data.objects["RF_UEV_spine_spine"] 
    armature = ob.data

            
    bpy.context.object.data.bones["Bone"].name = "temp"

    bpy.ops.object.mode_set(mode='EDIT')

    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')
   
    bpy.ops.object.select_all(action='DESELECT')
 

    #////clavicle_l
    objectToSelect = bpy.data.objects["RF_UEV_spine_spine"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("clavicle_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')





    objectToSelect2 = bpy.data.objects["RF_UEV_spine_spine"] 
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_UEV_spine_spine"] 
    armature = ob.data

    bpy.ops.object.mode_set(mode='EDIT')
    
    
    



    objectToSelect.data.edit_bones['clavicle_l'].head[0] = 1.4279
    objectToSelect.data.edit_bones['clavicle_l'].head[1] = 1.7398
    objectToSelect.data.edit_bones['clavicle_l'].head[2] = 146.301
    objectToSelect.data.edit_bones['clavicle_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['clavicle_l'].tail[0] = 0.6107
    objectToSelect.data.edit_bones['clavicle_l'].tail[1] = 19.5305
    objectToSelect.data.edit_bones['clavicle_l'].tail[2] = 146.365
    objectToSelect.data.edit_bones['clavicle_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['clavicle_l'].roll = 0.153272
    objectToSelect.data.edit_bones['clavicle_l'].length = 17.8096
    objectToSelect.data.edit_bones['clavicle_l'].envelope_distance = 0.25



    
    #RRRRRRRRRRRRRRRRRRRRRR

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("clavicle_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['clavicle_r'].head[0] = -1.4279
    objectToSelect.data.edit_bones['clavicle_r'].head[1] = 1.7399
    objectToSelect.data.edit_bones['clavicle_r'].head[2] =  146.301
    objectToSelect.data.edit_bones['clavicle_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['clavicle_r'].tail[0] = -2.2451
    objectToSelect.data.edit_bones['clavicle_r'].tail[1] = -16.0509
    objectToSelect.data.edit_bones['clavicle_r'].tail[2] = 146.237
    objectToSelect.data.edit_bones['clavicle_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['clavicle_r'].roll = 3.13819
    objectToSelect.data.edit_bones['clavicle_r'].length = 17.8097
    objectToSelect.data.edit_bones['clavicle_r'].envelope_distance = 0.25

 
 

 
    #//////Spine


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pelvis")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['pelvis'].head[0] = -0
    objectToSelect.data.edit_bones['pelvis'].head[1] = -2.2809
    objectToSelect.data.edit_bones['pelvis'].head[2] =  95.8968
    objectToSelect.data.edit_bones['pelvis'].head_radius = 0.1



    objectToSelect.data.edit_bones['pelvis'].tail[0] = -0
    objectToSelect.data.edit_bones['pelvis'].tail[1] = 5.7597
    objectToSelect.data.edit_bones['pelvis'].tail[2] =  95.3862
    objectToSelect.data.edit_bones['pelvis'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pelvis'].roll = -1.5708
    objectToSelect.data.edit_bones['pelvis'].length =  8.0568
    objectToSelect.data.edit_bones['pelvis'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_01")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['spine_01'].head[0] = 0
    objectToSelect.data.edit_bones['spine_01'].head[1] = -2.0479
    objectToSelect.data.edit_bones['spine_01'].head[2] = 99.5664
    objectToSelect.data.edit_bones['spine_01'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_01'].tail[0] = 0
    objectToSelect.data.edit_bones['spine_01'].tail[1] = 4.6263
    objectToSelect.data.edit_bones['spine_01'].tail[2] =  100.843
    objectToSelect.data.edit_bones['spine_01'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_01'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_01'].length =  6.7952
    objectToSelect.data.edit_bones['spine_01'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_02")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['spine_02'].head[0] = 0
    objectToSelect.data.edit_bones['spine_02'].head[1] = -3.324
    objectToSelect.data.edit_bones['spine_02'].head[2] = 106.241
    objectToSelect.data.edit_bones['spine_02'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_02'].tail[0] = 0
    objectToSelect.data.edit_bones['spine_02'].tail[1] = 3.8546
    objectToSelect.data.edit_bones['spine_02'].tail[2] =  107.168
    objectToSelect.data.edit_bones['spine_02'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_02'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_02'].length =  7.2382
    objectToSelect.data.edit_bones['spine_02'].envelope_distance = 0.25


 




     
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_03")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
     

    objectToSelect.data.edit_bones['spine_03'].head[0] = 0
    objectToSelect.data.edit_bones['spine_03'].head[1] = -4.2512
    objectToSelect.data.edit_bones['spine_03'].head[2] = 113.419
    objectToSelect.data.edit_bones['spine_03'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_03'].tail[0] = 0
    objectToSelect.data.edit_bones['spine_03'].tail[1] = 4.2561
    objectToSelect.data.edit_bones['spine_03'].tail[2] =  112.886
    objectToSelect.data.edit_bones['spine_03'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_03'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_03'].length =  8.524
    objectToSelect.data.edit_bones['spine_03'].envelope_distance = 0.25


 

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_04")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  
    


    objectToSelect.data.edit_bones['spine_04'].head[0] = -0
    objectToSelect.data.edit_bones['spine_04'].head[1] = -3.718
    objectToSelect.data.edit_bones['spine_04'].head[2] = 121.926
    objectToSelect.data.edit_bones['spine_04'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_04'].tail[0] = -0.0002
    objectToSelect.data.edit_bones['spine_04'].tail[1] = 15.4578
    objectToSelect.data.edit_bones['spine_04'].tail[2] =  118.734
    objectToSelect.data.edit_bones['spine_04'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_04'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_04'].length = 19.4397
    objectToSelect.data.edit_bones['spine_04'].envelope_distance = 0.25

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_05")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['spine_05'].head[0] = -0
    objectToSelect.data.edit_bones['spine_05'].head[1] = -0.5251
    objectToSelect.data.edit_bones['spine_05'].head[2] = 141.102
    objectToSelect.data.edit_bones['spine_05'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_05'].tail[0] = 0
    objectToSelect.data.edit_bones['spine_05'].tail[1] = 7.2133
    objectToSelect.data.edit_bones['spine_05'].tail[2] =  139.719
    objectToSelect.data.edit_bones['spine_05'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_05'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_05'].length = 7.861
    objectToSelect.data.edit_bones['spine_05'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("neck_01")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 
    
    


    objectToSelect.data.edit_bones['neck_01'].head[0] = -0
    objectToSelect.data.edit_bones['neck_01'].head[1] = 1.5667
    objectToSelect.data.edit_bones['neck_01'].head[2] = 152.804
    objectToSelect.data.edit_bones['neck_01'].head_radius = 0.1



    objectToSelect.data.edit_bones['neck_01'].tail[0] = 0
    objectToSelect.data.edit_bones['neck_01'].tail[1] = 6.5296
    objectToSelect.data.edit_bones['neck_01'].tail[2] =  154.023
    objectToSelect.data.edit_bones['neck_01'].tail_radius = 0.05
    objectToSelect.data.edit_bones['neck_01'].roll = -1.5708
    objectToSelect.data.edit_bones['neck_01'].length = 5.1104
    objectToSelect.data.edit_bones['neck_01'].envelope_distance = 0.25



    
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("neck_02")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['neck_02'].head[0] = -0
    objectToSelect.data.edit_bones['neck_02'].head[1] = 0.3483
    objectToSelect.data.edit_bones['neck_02'].head[2] = 157.767
    objectToSelect.data.edit_bones['neck_02'].head_radius = 0.1



    objectToSelect.data.edit_bones['neck_02'].tail[0] = 0
    objectToSelect.data.edit_bones['neck_02'].tail[1] = 5.156
    objectToSelect.data.edit_bones['neck_02'].tail[2] = 158.779
    objectToSelect.data.edit_bones['neck_02'].tail_radius = 0.05
    objectToSelect.data.edit_bones['neck_02'].roll = -1.5708
    objectToSelect.data.edit_bones['neck_02'].length = 4.9131
    objectToSelect.data.edit_bones['neck_02'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("head")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



     

    objectToSelect.data.edit_bones['head'].head[0] = -0
    objectToSelect.data.edit_bones['head'].head[1] = -0.6631
    objectToSelect.data.edit_bones['head'].head[2] = 162.575
    objectToSelect.data.edit_bones['head'].head_radius = 0.1



    objectToSelect.data.edit_bones['head'].tail[0] = -0
    objectToSelect.data.edit_bones['head'].tail[1] = 4.2499
    objectToSelect.data.edit_bones['head'].tail[2] = 162.575
    objectToSelect.data.edit_bones['head'].tail_radius = 0.05
    objectToSelect.data.edit_bones['head'].roll = -1.5708
    objectToSelect.data.edit_bones['head'].length = 4.913
    objectToSelect.data.edit_bones['head'].envelope_distance = 0.25



     
     

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ball_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



     


    objectToSelect.data.edit_bones['ball_l'].head[0] = 15.7779
    objectToSelect.data.edit_bones['ball_l'].head[1] = -13.9288
    objectToSelect.data.edit_bones['ball_l'].head[2] =  0.7508
    objectToSelect.data.edit_bones['ball_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ball_l'].tail[0] = 15.8559
    objectToSelect.data.edit_bones['ball_l'].tail[1] = -14.4526
    objectToSelect.data.edit_bones['ball_l'].tail[2] = 17.5236
    objectToSelect.data.edit_bones['ball_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ball_l'].roll = -1.41742
    objectToSelect.data.edit_bones['ball_l'].length = 16.7812
    objectToSelect.data.edit_bones['ball_l'].envelope_distance = 0.25


 
    
 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ball_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['ball_r'].head[0] = -15.7777
    objectToSelect.data.edit_bones['ball_r'].head[1] = -13.9382
    objectToSelect.data.edit_bones['ball_r'].head[2] = 0.7514
    objectToSelect.data.edit_bones['ball_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ball_r'].tail[0] = -15.6997
    objectToSelect.data.edit_bones['ball_r'].tail[1] = -13.4145
    objectToSelect.data.edit_bones['ball_r'].tail[2] = -16.0214
    objectToSelect.data.edit_bones['ball_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ball_r'].roll = -1.42672
    objectToSelect.data.edit_bones['ball_r'].length = 16.7812
    objectToSelect.data.edit_bones['ball_r'].envelope_distance = 0.25

    #New Foot

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("foot_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



    objectToSelect.data.edit_bones['foot_l'].head[0] = 14.0877
    objectToSelect.data.edit_bones['foot_l'].head[1] = 0.9943
    objectToSelect.data.edit_bones['foot_l'].head[2] =  8.2376
    objectToSelect.data.edit_bones['foot_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['foot_l'].tail[0] = 11.6034
    objectToSelect.data.edit_bones['foot_l'].tail[1] = 17.582
    objectToSelect.data.edit_bones['foot_l'].tail[2] = 8.7672
    objectToSelect.data.edit_bones['foot_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['foot_l'].roll = -1.56847
    objectToSelect.data.edit_bones['foot_l'].length = 16.7811
    objectToSelect.data.edit_bones['foot_l'].envelope_distance = 0.25


    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("foot_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


    


    objectToSelect.data.edit_bones['foot_r'].head[0] = -14.0876
    objectToSelect.data.edit_bones['foot_r'].head[1] = 0.9848
    objectToSelect.data.edit_bones['foot_r'].head[2] = 8.2382
    objectToSelect.data.edit_bones['foot_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['foot_r'].tail[0] = -16.5718
    objectToSelect.data.edit_bones['foot_r'].tail[1] = -15.603
    objectToSelect.data.edit_bones['foot_r'].tail[2] = 7.7087
    objectToSelect.data.edit_bones['foot_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['foot_r'].roll = 1.15308
    objectToSelect.data.edit_bones['foot_r'].length = 16.7811
    objectToSelect.data.edit_bones['foot_r'].envelope_distance = 0.25
 
    


    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')


 




class spine_curuev_op(bpy.types.Operator):
    bl_label = "LFingers"
    bl_idname = "spine.my_opuev"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene



        rigrfuev()




        bpy.ops.object.select_all(action='DESELECT')
        source_armature_name = "root"
        source_bone_name = "pelvis"
        target_bone_names = ["pelvis"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name




      
        source_armature_name = "root"
        source_bone_name = "spine_01"
        target_bone_names = ["spine_01"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name

        



        source_armature_name = "root"
        source_bone_name = "spine_02"
        target_bone_names = ["spine_02"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name





        source_armature_name = "root"
        source_bone_name = "spine_03"
        target_bone_names = ["spine_03"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name

        


        source_armature_name = "root"
        source_bone_name = "spine_04"
        target_bone_names = ["spine_04"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name







        source_armature_name = "root"
        source_bone_name = "spine_05"
        target_bone_names = ["spine_05"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name



        source_armature_name = "root"
        source_bone_name = "neck_01"
        target_bone_names = ["neck_01"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name



        source_armature_name = "root"
        source_bone_name = "neck_02"
        target_bone_names = ["neck_02"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name





        source_armature_name = "root"
        source_bone_name = "head"
        target_bone_names = ["head"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name




        source_armature_name = "root"
        source_bone_name = "clavicle_l"
        target_bone_names = ["clavicle_l"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name



        source_armature_name = "root"
        source_bone_name = "clavicle_r"
        target_bone_names = ["clavicle_r"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name





        source_armature_name = "root"
        source_bone_name = "ball_l"
        target_bone_names = ["ball_l"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name


        source_armature_name = "root"
        source_bone_name = "ball_r"
        target_bone_names = ["ball_r"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name




        
        #new Foot

        

        source_armature_name = "root"
        source_bone_name = "foot_l"
        target_bone_names = ["foot_l"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name


        source_armature_name = "root"
        source_bone_name = "foot_r"
        target_bone_names = ["foot_r"]

        # Get the armatures and bones
        source_armature = bpy.data.objects.get(source_armature_name)
        target_armature = bpy.data.objects.get("RF_UEV_spine_spine")

        # Check if the armatures exist
        if source_armature and target_armature:
            source_bone = source_armature.pose.bones.get(source_bone_name)
            
            for target_bone_name in target_bone_names:
                target_bone = target_armature.pose.bones.get(target_bone_name)
                
                # Check if the target bone exists
                if target_bone:
    
                    # Add Copy Rotation constraint
                    copy_rotation_constraint = target_bone.constraints.new(type='COPY_LOCATION')
                    copy_rotation_constraint.target = source_armature
                    copy_rotation_constraint.subtarget = source_bone_name


















        
        
        
        #Apply
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["RF_UEV_spine_spine"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        ob = bpy.data.objects["RF_UEV_spine_spine"] 
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='SELECT')
        
        bpy.ops.object.posemode_toggle()

        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect2 = bpy.data.objects["RF_UEV_spine_spine"] 
        objectToSelect.select_set(True)    
        objectToSelect2.select_set(True)








        armature_obj = bpy.data.objects['root']
        armature_obj2 = bpy.data.objects['RF_UEV_spine_spine']

        bpy.ops.object.mode_set(mode='EDIT')

        
        # Get the bones in the first armature
        bone = armature_obj.data.edit_bones.get("spine_01")
        bone2 = armature_obj.data.edit_bones.get("spine_02")
        bone3 = armature_obj.data.edit_bones.get("spine_03")
        bone4 = armature_obj.data.edit_bones.get("spine_04")
        bone5 = armature_obj.data.edit_bones.get("spine_05")
        bone6 = armature_obj.data.edit_bones.get("neck_01")
        bone7 = armature_obj.data.edit_bones.get("neck_02")
        bone8 = armature_obj.data.edit_bones.get("head")
        bone9 = armature_obj.data.edit_bones.get("clavicle_r")
        bone10 = armature_obj.data.edit_bones.get("clavicle_l")
        bone11 = armature_obj.data.edit_bones.get("ball_r")
        bone12 = armature_obj.data.edit_bones.get("ball_l")

        bone13 = armature_obj.data.edit_bones.get("foot_r")
        bone14 = armature_obj.data.edit_bones.get("foot_l")
        #bone13 = armature_obj.data.edit_bones.get("pelvis")

        # Get the reference bone
        ref_bone = armature_obj2.data.edit_bones.get("spine_01")
        ref_bone2 = armature_obj2.data.edit_bones.get("spine_02")
        ref_bone3 = armature_obj2.data.edit_bones.get("spine_03")
        ref_bone4 = armature_obj2.data.edit_bones.get("spine_04")
        ref_bone5 = armature_obj2.data.edit_bones.get("spine_05")
        ref_bone6 = armature_obj2.data.edit_bones.get("neck_01")
        ref_bone7 = armature_obj2.data.edit_bones.get("neck_02")
        ref_bone8 = armature_obj2.data.edit_bones.get("head")
        ref_bone9 = armature_obj2.data.edit_bones.get("clavicle_r")
        ref_bone10 = armature_obj2.data.edit_bones.get("clavicle_l")
        ref_bone11 = armature_obj2.data.edit_bones.get("ball_r")
        ref_bone12 = armature_obj2.data.edit_bones.get("ball_l")

        ref_bone13 = armature_obj2.data.edit_bones.get("foot_r")
        ref_bone14 = armature_obj2.data.edit_bones.get("foot_l")
        
        
        
        #ref_bone13 = armature_obj2.data.edit_bones.get("pelvis")
        # Set the bone's values similar to the reference bone

        bone.head = ref_bone.head
        bone.tail = ref_bone.tail
        bone.roll = ref_bone.roll



        bone2.head = ref_bone2.head
        bone2.tail = ref_bone2.tail
        bone2.roll = ref_bone2.roll


        bone3.head = ref_bone3.head
        bone3.tail = ref_bone3.tail
        bone3.roll = ref_bone3.roll


        bone4.head = ref_bone4.head
        bone4.tail = ref_bone4.tail
        bone4.roll = ref_bone4.roll


        bone5.head = ref_bone5.head
        bone5.tail = ref_bone5.tail
        bone5.roll = ref_bone5.roll


        bone6.head = ref_bone6.head
        bone6.tail = ref_bone6.tail
        bone6.roll = ref_bone6.roll


        bone7.head = ref_bone7.head
        bone7.tail = ref_bone7.tail
        bone7.roll = ref_bone7.roll



        bone8.head = ref_bone8.head
        bone8.tail = ref_bone8.tail
        bone8.roll = ref_bone8.roll

        if mytool.auto_calv !=False  and bpy.context.scene.my_tool.my_string50 ==0 and bpy.context.scene.my_tool.my_string51 ==0 and bpy.context.scene.my_tool.my_string52 ==0 and bpy.context.scene.my_tool.my_string53 ==0:

            bone9.head = ref_bone9.head
            bone9.tail = ref_bone9.tail
            bone9.roll = ref_bone9.roll



            bone10.head = ref_bone10.head
            bone10.tail = ref_bone10.tail
            bone10.roll = ref_bone10.roll



        bone11.head = ref_bone11.head
        bone11.tail = ref_bone11.tail
        bone11.roll = ref_bone11.roll

        bone12.head = ref_bone12.head
        bone12.tail = ref_bone12.tail
        bone12.roll = ref_bone12.roll

        if mytool.auto_foot !=False :

            bone13.head = ref_bone13.head
            bone13.tail = ref_bone13.tail
            bone13.roll = ref_bone13.roll

            bone14.head = ref_bone14.head
            bone14.tail = ref_bone14.tail
            bone14.roll = ref_bone14.roll

         


        
        bpy.ops.object.mode_set(mode='OBJECT')

        objects = bpy.context.scene.objects.keys()
        if  'RF_UEV_spine_spine' in objects:

           
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_UEV_spine_spine"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False) 
        
        
         

        









        return {'FINISHED'}
  














