import bpy
import json
import os
import bmesh 
import math



from . MagicBoneTop_Panel import makeuerigauto
from . MagicBoneTop_Panel import makeuerig

from . MagicBoneTop_Panel import makeuerigclav

from . MagicBoneTop_Panel import hiderigs
from . MagicBoneTop_Panel import unhiderigs

from . MagicBoneTop_Panel import makeuerigfootfix
 
from . ShoulderFix import Getue_Shoulderfix
from . ShoulderFix import makeuerigshouder

from . ApplyScalear import autoscale_OT_op
from . ApplyScalear import autoscaleroot_OT_op



 
class CreatRig_OT_my_op(bpy.types.Operator):
    bl_label = "Create UE5 Rig "
    bl_idname = "createrig.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    #center : bpy.props.BoolProperty(name= "Keep Rig Rf For Anim", default= False)
    #center2 : bpy.props.BoolProperty(name= "Unlink Animation", default= False)
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene
        

        context.window_manager.progress = 0.0
        bpy.context.window_manager.progress_begin(0.0, 100.0)
        

        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        

        bpy.ops.screen.frame_jump(end=False)

        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' not in objects and mytool.auto_scale ==False :
            
            self.report({"WARNING"}, "Set Character Scale !")
        
        objects = bpy.context.scene.objects.keys()
        if  'UE5_Character_Scale_RF' in objects or mytool.auto_scale ==True:
            
            bpy.context.window_manager.progress_update(5.0)    
            
            
            objects = bpy.context.scene.objects.keys()
            if  'RF_Pose' in objects:
                
                self.report({"WARNING"}, "Apply Pose !")
                
            objects = bpy.context.scene.objects.keys()
            if  'RF_Pose' not in objects:

                if mytool.my_enumar != 'OP1':

                    mytool.auto_fillcraterig =True

                    if mytool.auto_fill !=False:

                        bpy.ops.rigslis.myop_operator()

                        if sce.bone_targetHip =="":    
                            bpy.ops.rigslis.myop_operator()
                    
            
                if sce.Armature_Target !="" and sce.bone_target1 !="" and sce.bone_target4 !="" and sce.bone_target7 !="" and sce.bone_target9 !="" and sce.bone_target12 !=""  and sce.bone_target15 !="" and sce.bone_target25 !="" and sce.bone_target26 !=""  and sce.bone_target29 !="" and sce.bone_target32 !="" and sce.bone_target17 !="" and sce.bone_target18 !="" and sce.bone_target21 !="" and sce.bone_target24 !="" and sce.bone_target33 !="" and sce.bone_target36 !="" and sce.bone_targetHip !="":
                    
                    
                     

                    # Iterate through all objects in the scene
                    for obj in bpy.context.scene.objects:
                        # Check if the object is a mesh
                        if obj.type == 'MESH':
                            # Iterate through all modifiers of the object
                            for modifier in obj.modifiers:
                                # Check if the modifier is a Subdivision Surface modifier
                                if modifier.type == 'SUBSURF':
                                    # Remove the Subdivision Surface modifier from the object
                                    obj.modifiers.remove(modifier)




                    if mytool.add_rootanim ==True:
                        bpy.ops.rootma.op()
                    
                    

                    if mytool.auto_scale ==True :

                        bpy.ops.mb.autoscaler()

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2           

                    # Get the active armature object
                    armature_obj = bpy.context.active_object

                    # Check if the active object is an armature
                    if armature_obj and armature_obj.type == 'ARMATURE':
                        # Iterate through all pose bones
                        for bone in armature_obj.pose.bones:
                            # Set custom_shape to None for each bone
                            bone.custom_shape = None
                    else:
                        print("The active object is not an armature.")
  

                        


                    #new daz 
                    if mytool.my_enumar == 'OP13' or mytool.my_enumar == 'OP12' :

                        bpy.ops.fixlocdaz.myop_operator() 


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect2

                    
                   # /////////////delete Bones RF
                    bpy.ops.object.select_all(action='DESELECT')
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')

                    ob = bpy.context.object
                    assert ob.type == 'ARMATURE'
                    arma = ob.data
                    bpy.ops.object.mode_set(mode='EDIT') # ensure edit mode
                    bpy.ops.armature.select_all(action='DESELECT')
                
        

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ik_hand_l")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['ik_hand_l']
                        arma.edit_bones.remove(bone)


                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ik_hand_r")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['ik_hand_r']
                        arma.edit_bones.remove(bone)


                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ik_hand_gun")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['ik_hand_gun']
                        arma.edit_bones.remove(bone)


                    

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ik_foot_l")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['ik_foot_l']
                        arma.edit_bones.remove(bone)
                    
                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ik_foot_r")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['ik_foot_r']
                        arma.edit_bones.remove(bone)
                    
                    

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ik_hand_root")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['ik_hand_root']
                        arma.edit_bones.remove(bone)
                    

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ik_foot_root")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['ik_foot_root']
                        arma.edit_bones.remove(bone)
                    
                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("center_of_mass")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['center_of_mass']
                        arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("interaction")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['interaction']
                        arma.edit_bones.remove(bone)

                   




                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')
                        
                   
                   
                   
                   
                    if mytool.my_string54 !=False :
                    
                        bpy.ops.fixtwisto.myop_operator()
                    



                    if mytool.my_bool33 ==False :
                     
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        
                        
                        for action in bpy.data.actions:
                            bpy.data.actions.remove(action)


                        ##Rest in pose mode
                    
                        bpy.ops.object.posemode_toggle()
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.rot_clear()
                        bpy.ops.pose.loc_clear()
                        bpy.ops.object.mode_set(mode='OBJECT')

                    if sce.bone_target66 !="" :
                        bpy.ops.leftfinger.myop_operator() 
                        bpy.ops.rightfinger.myop_operator()
                    
                    #spine
                    bpy.ops.spinewsl.myop_operator()
                    
                    
                    if mytool.my_enumar == 'OP4' or mytool.my_boolT_Pose !=False and sce.bone_target64 !=""  and mytool.my_string39 ==False:

                        objects = bpy.context.scene.objects.keys()
                        if  'Fingers_Direction' not in objects:
                        
                        
                            if sce.Armature_Target !="" and sce.bone_target64 !="" and sce.bone_target45 !="" :
                            
                                bpy.ops.fingerdirec.myop_operator()

                                
                                objectToSelect = bpy.data.objects["Fingers_Direction"]
                                objectToSelect.select_set(True)    
                                bpy.context.view_layer.objects.active = objectToSelect 
                                bpy.ops.object.mode_set(mode='EDIT')
                                bpy.ops.armature.select_all(action='DESELECT')
                                bpy.ops.object.mode_set(mode='OBJECT')   
                                
                                objectToSelect = bpy.data.objects["Fingers_Direction"]
                                objectToSelect.select_set(True)    
                                bpy.context.view_layer.objects.active = objectToSelect
                                ob = bpy.data.objects["Fingers_Direction"]
                                armature = ob.data
                                bpy.ops.object.mode_set(mode='POSE')
                                bpy.ops.pose.select_all(action='SELECT')
                                bpy.ops.pose.select_all(action='DESELECT')
                                b=ob.data.bones["thumb_Dir.L"] 
                                b.select=True
                                ob.data.bones.active=b
                                bpy.context.active_pose_bone.rotation_mode = 'QUATERNION'
                                bpy.context.active_pose_bone.rotation_quaternion[0] = 0.795635
                                bpy.context.active_pose_bone.rotation_quaternion[1] = 0.526614
                                bpy.context.active_pose_bone.rotation_quaternion[2] = -0.277527
                                bpy.context.active_pose_bone.rotation_quaternion[3] = -0.112343




                                bpy.ops.pose.select_all(action='DESELECT')
                                bpy.ops.object.mode_set(mode='OBJECT')



                                objectToSelect = bpy.data.objects["Fingers_Direction"]
                                objectToSelect.select_set(True)    
                                bpy.context.view_layer.objects.active = objectToSelect 
                                bpy.ops.object.mode_set(mode='EDIT')
                                bpy.ops.armature.select_all(action='DESELECT')
                                bpy.ops.object.mode_set(mode='OBJECT')   
                                
                                objectToSelect = bpy.data.objects["Fingers_Direction"]
                                objectToSelect.select_set(True)    
                                bpy.context.view_layer.objects.active = objectToSelect
                                ob = bpy.data.objects["Fingers_Direction"]
                                armature = ob.data
                                bpy.ops.object.mode_set(mode='POSE')
                                bpy.ops.pose.select_all(action='SELECT')
                                bpy.ops.pose.select_all(action='DESELECT')
                                b=ob.data.bones["thumb_Dir.R"] 
                                b.select=True
                                ob.data.bones.active=b
                                bpy.context.active_pose_bone.rotation_mode = 'QUATERNION'
                                bpy.context.active_pose_bone.rotation_quaternion[0] = 0.795635
                                bpy.context.active_pose_bone.rotation_quaternion[1] = 0.526614
                                bpy.context.active_pose_bone.rotation_quaternion[2] = 0.277527
                                bpy.context.active_pose_bone.rotation_quaternion[3] = 0.112343


                                bpy.ops.pose.select_all(action='DESELECT')
                                bpy.ops.object.mode_set(mode='OBJECT')

                    
                                
                                bpy.ops.view3d.snap_cursor_to_center()
                    
                    
                    





                    if mytool.my_enumar == 'OP6'or mytool.my_enumar == 'OP5' or mytool.my_boolA_Pose !=False and sce.bone_target64 !="" and mytool.my_string39 ==False :

                        objects = bpy.context.scene.objects.keys()
                        if  'Fingers_Direction' not in objects:
                        
                        
                            if sce.Armature_Target !="" and sce.bone_target64 !="" and sce.bone_target45 !="" :
                            
                                bpy.ops.fingerdirec.myop_operator()

                               
                                objectToSelect = bpy.data.objects["Fingers_Direction"]
                                objectToSelect.select_set(True)    
                                bpy.context.view_layer.objects.active = objectToSelect 
                                bpy.ops.object.mode_set(mode='EDIT')
                                bpy.ops.armature.select_all(action='DESELECT')
                                bpy.ops.object.mode_set(mode='OBJECT')   
                                
                                objectToSelect = bpy.data.objects["Fingers_Direction"]
                                objectToSelect.select_set(True)    
                                bpy.context.view_layer.objects.active = objectToSelect
                                ob = bpy.data.objects["Fingers_Direction"]
                                armature = ob.data
                                bpy.ops.object.mode_set(mode='POSE')
                                bpy.ops.pose.select_all(action='SELECT')
                                bpy.ops.pose.select_all(action='DESELECT')
                                b=ob.data.bones["thumb_Dir.L"] 
                                b.select=True
                                ob.data.bones.active=b
                                bpy.context.active_pose_bone.rotation_mode = 'QUATERNION'
                                bpy.context.active_pose_bone.rotation_quaternion[0] = 0.75723
                                bpy.context.active_pose_bone.rotation_quaternion[1] = 0.284722
                                bpy.context.active_pose_bone.rotation_quaternion[2] = -0.482574
                                bpy.context.active_pose_bone.rotation_quaternion[3] = -0.335647




                                bpy.ops.pose.select_all(action='DESELECT')
                                bpy.ops.object.mode_set(mode='OBJECT')



                                objectToSelect = bpy.data.objects["Fingers_Direction"]
                                objectToSelect.select_set(True)    
                                bpy.context.view_layer.objects.active = objectToSelect 
                                bpy.ops.object.mode_set(mode='EDIT')
                                bpy.ops.armature.select_all(action='DESELECT')
                                bpy.ops.object.mode_set(mode='OBJECT')   
                                
                                objectToSelect = bpy.data.objects["Fingers_Direction"]
                                objectToSelect.select_set(True)    
                                bpy.context.view_layer.objects.active = objectToSelect
                                ob = bpy.data.objects["Fingers_Direction"]
                                armature = ob.data
                                bpy.ops.object.mode_set(mode='POSE')
                                bpy.ops.pose.select_all(action='SELECT')
                                bpy.ops.pose.select_all(action='DESELECT')
                                b=ob.data.bones["thumb_Dir.R"] 
                                b.select=True
                                ob.data.bones.active=b
                                bpy.context.active_pose_bone.rotation_mode = 'QUATERNION'
                                bpy.context.active_pose_bone.rotation_quaternion[0] = 0.75723
                                bpy.context.active_pose_bone.rotation_quaternion[1] = 0.284722
                                bpy.context.active_pose_bone.rotation_quaternion[2] = 0.482574
                                bpy.context.active_pose_bone.rotation_quaternion[3] = 0.335647




                                bpy.ops.pose.select_all(action='DESELECT')
                                bpy.ops.object.mode_set(mode='OBJECT')



                    if mytool.my_enumar == 'OP7':
                        print("UE4")
                               








                    
                    
                    
                    objects = bpy.context.scene.objects.keys()
                    if  'Fingers_Direction' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.context.object.hide_viewport = False
                        bpy.context.object.hide_render = False
                        bpy.context.object.hide_set(False)
                        bpy.context.object.hide_select = False 
                    
                    bpy.context.window_manager.progress_update(6.0)    
                    
                    
                    objects = bpy.context.scene.objects.keys()
                    if  'RF_To_Ues_PosMatching' not in objects:
                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.namingfixname.op()

                        if sce.bone_target90 =="":
                            
                            bpy.ops.namingfixnoid.op()
                    
                    
                     

                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.context.object.hide_viewport = False
                    bpy.context.object.hide_render = False
                    bpy.context.object.hide_set(False)
                    bpy.context.object.hide_select = False


                    
                    #show all hiden bones 
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]  
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect 
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    bpy.ops.armature.reveal()
                    bpy.ops.object.mode_set(mode='OBJECT') 






                    objects = bpy.context.scene.objects.keys()
                    if  'Rig_AnimRF_root' in objects :

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["Rig_AnimRF_root"]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.context.object.hide_viewport = False
                        bpy.context.object.hide_render = False
                        bpy.context.object.hide_set(False)
                        bpy.context.object.hide_select = False





                    objects = bpy.context.scene.objects.keys()
                    if  'Rig_AnimRF_root' not in objects and sce.bone_target79 !="" :
                    
                        #rig root anim
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.duplicate()
                        bpy.context.active_object.name = 'Rig_AnimRF_rootT'

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["Rig_AnimRF_rootT"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        for obj in bpy.context.selected_objects:
                            obj.name = "Rig_AnimRF_root"
                            obj.data.name = "Rig_AnimRF_root"


                        #########
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["Rig_AnimRF_root"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect 
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')   
                        
                        objectToSelect = bpy.data.objects["Rig_AnimRF_root"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects["Rig_AnimRF_root"]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.rot_clear()
                        bpy.ops.pose.loc_clear()
                        bpy.ops.pose.scale_clear()
                    
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones[sce.bone_target79] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.ops.view3d.snap_cursor_to_selected()
                        bpy.ops.object.mode_set(mode='OBJECT')


                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["Rig_AnimRF_root"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect 
                        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
                        bpy.ops.object.location_clear(clear_delta=False)








                    objects = bpy.context.scene.objects.keys()
                    if  'Rig_AnimRF_root' in objects and sce.bone_target79 !="" :

                        

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect 
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')   
                        
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.rot_clear()
                        bpy.ops.pose.loc_clear()
                        #bpy.ops.pose.scale_clear()
                    
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones[sce.bone_target79] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.ops.anim.keyframe_clear_v3d()
                        bpy.ops.object.mode_set(mode='OBJECT')




                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect 
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')   
                        
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.rot_clear()
                        bpy.ops.pose.loc_clear()
                        #bpy.ops.pose.scale_clear()
                    
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones[sce.bone_target79] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.ops.view3d.snap_cursor_to_selected()
                        bpy.ops.object.mode_set(mode='OBJECT')


                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect 
                        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
                        bpy.ops.object.location_clear(clear_delta=False)





                    bpy.context.window_manager.progress_update(7.0)

      


                    objects = bpy.context.scene.objects.keys()
                    if  'Rig_AnimRF_Fix' in objects: 



                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["Rig_AnimRF_Fix"]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.context.object.hide_viewport = False
                        bpy.context.object.hide_render = False
                        bpy.context.object.hide_set(False)
                        bpy.context.object.hide_select = False
                    
                    objects = bpy.context.scene.objects.keys()
                    if  'Rig_AutoMatchingRF' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["Rig_AutoMatchingRF"]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.context.object.hide_viewport = False
                        bpy.context.object.hide_render = False
                        bpy.context.object.hide_set(False)
                        bpy.context.object.hide_select = False
                    
                    
                    
                    #Set Armature to OBJECT mode 
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.mode_set(mode='OBJECT')



                    if mytool.my_bool35 !=False :
                    
                        #SET bones TO offset pri  
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2


                        from bpy import context

                        obj = context.object

                        bpy.ops.object.mode_set(mode='EDIT')

                        for bone in obj.data.edit_bones:
                            bone.use_connect = False
                        

                        bpy.ops.object.mode_set(mode='OBJECT')









                    

                    objects = bpy.context.scene.objects.keys()
                    if  'Rig_AnimRF_Fix' not in objects and mytool.my_bool33 !=False: 
                    
                        #rig Fix Anime
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.duplicate()
                        bpy.context.active_object.name = 'Rig_AnimRF_Fixt'

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["Rig_AnimRF_Fixt"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        for obj in bpy.context.selected_objects:
                            obj.name = "Rig_AnimRF_Fix"
                            obj.data.name = "Rig_AnimRF_Fix"




                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

                    objects = bpy.context.scene.objects.keys()
                    if  'RF_For_Animation' not in objects and mytool.my_bool33 !=False : 

                        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                        
                        print("ff")

                    if mytool.my_bool33 ==False : 
                        ##Rest
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target] 
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        bpy.ops.object.location_clear(clear_delta=False)
                        
                        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)


                        
                        
                    objects = bpy.context.scene.objects.keys()
                    if  'RF_For_Animation' not in objects and mytool.my_bool33 !=False :
                    
                    
                    
                    
                        #make rig for Anim //////////////////////////////////////////////////////

                    
                        #Apply  transforms_to_deltas For Anime  
                        ##Rest
                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target] 
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        bpy.ops.object.location_clear(clear_delta=False)
                        


                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        
                        

                            

                        
                        #Rig RF For Anime 
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.duplicate()
                        bpy.context.active_object.name = 'RF_For_Animation_t'

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["RF_For_Animation_t"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect



                        for obj in bpy.context.selected_objects:
                            obj.name = "RF_For_Animation"
                            obj.data.name = "RF_For_Animation"
                        

                        ##Rest
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["RF_For_Animation"] 
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        bpy.ops.object.location_clear(clear_delta=False)

                        context = bpy.context
                        object = context.object

                        #should put checks in to see if you have object animation_data etc

                        action = object.animation_data.action  # this is the action that is shown in action editor.

                        # the action can be unlinked using.

                        object.animation_data.action = None



                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["RF_For_Animation"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        ##Rest in pose mode
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["RF_For_Animation"]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects["RF_For_Animation"] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.loc_clear()
                        bpy.ops.pose.rot_clear()

                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')

                        
                        context = bpy.context
                        object = context.object

                        #should put checks in to see if you have object animation_data etc

                        action = object.animation_data.action  # this is the action that is shown in action editor.

                        # the action can be unlinked using.

                        object.animation_data.action = None

                        #//////////////////////////////////////////


                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.duplicate()
                        bpy.context.active_object.name = 'RF_Anime_T'

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["RF_Anime_T"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        
                        
                        for obj in bpy.context.selected_objects:
                            obj.name = "RF_Anime_"
                            obj.data.name = "RF_Anime_"







                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.duplicate()
                        bpy.context.active_object.name = 'Rig_AnimRF_t'

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["Rig_AnimRF_t"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        for obj in bpy.context.selected_objects:
                            obj.name = "Rig_AnimRF"
                            obj.data.name = "Rig_AnimRF"


                        
                        
                        

                        armatureFrom = bpy.data.objects['Rig_AnimRF_Fix']
                        armatureTo = bpy.data.objects['Rig_AnimRF']

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)

                            copy_con = boneTo.constraints.new('COPY_ROTATION')
                            copy_con.target = armatureFrom
                            copy_con.subtarget = boneFrom.name
                            
                            copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                            copy_con2.target = armatureFrom
                            copy_con2.subtarget = boneFrom.name
                            
                            
                            copy_con3 = boneTo.constraints.new('COPY_SCALE')
                            copy_con3.target = armatureFrom
                            copy_con3.subtarget = boneFrom.name
                            copy_con3.target_space = 'LOCAL'
                            copy_con3.owner_space = 'LOCAL' 




                        armatureFrom = bpy.data.objects['Rig_AnimRF_Fix']
                        armatureTo = bpy.data.objects['RF_Anime_']

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)

                            copy_con = boneTo.constraints.new('COPY_ROTATION')
                            copy_con.target = armatureFrom
                            copy_con.subtarget = boneFrom.name
                            
                            copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                            copy_con2.target = armatureFrom
                            copy_con2.subtarget = boneFrom.name
                            
                            
                            copy_con3 = boneTo.constraints.new('COPY_SCALE')
                            copy_con3.target = armatureFrom
                            copy_con3.subtarget = boneFrom.name
                            copy_con3.target_space = 'LOCAL'
                            copy_con3.owner_space = 'LOCAL'
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        #////////////////////////////////////////////////////////////////


                    




                    ##Rest
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    bpy.ops.object.location_clear(clear_delta=False)

                    if mytool.my_bool33 !=False :

                        context = bpy.context
                        object = context.object

                        #should put checks in to see if you have object animation_data etc

                        action = object.animation_data.action  # this is the action that is shown in action editor.

                        # the action can be unlinked using.

                        object.animation_data.action = None



                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    ##Rest in pose mode
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.loc_clear()
                    bpy.ops.pose.rot_clear()

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')

                    if mytool.my_bool33 !=False :
                        
                        context = bpy.context
                        object = context.object

                        #should put checks in to see if you have object animation_data etc

                        action = object.animation_data.action  # this is the action that is shown in action editor.

                        # the action can be unlinked using.

                        object.animation_data.action = None

                    #//////////////////////////////////////////





                    objects = bpy.context.scene.objects.keys()
                    if  'AU5Clavicle_PosMatching_On' not in objects:

                        bpy.ops.mb.sholdfic()
                    
                    objects = bpy.context.scene.objects.keys()
                    if  'AU5FootRoto_PosMatching_On' not in objects:
                        bpy.ops.mb.footfixmroto()
                    



                    objects = bpy.context.scene.objects.keys()
                    if  'AU5Foot_PosMatching_On' not in objects: 
                        bpy.ops.mb.footuezz()  
                    
                    
                
                    bpy.context.window_manager.progress_update(8.0)
                
                
                
                    makeuerig()
                
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    bpy.context.object.data.use_mirror_x = False

                    bpy.ops.object.duplicate()

                    bpy.context.active_object.name = 'Your_Rig_PoseTemp'


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["Your_Rig_PoseTemp"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    
                    
                    for obj in bpy.context.selected_objects:
                        obj.name = "Your_Rig_Pose"
                        obj.data.name = "Your_Rig_Pose"



                    

                ######///New Clear Parent
                if sce.Armature_Target !="" and sce.bone_target1 !="" and sce.bone_target4 !="" and sce.bone_target7 !="" and sce.bone_target9 !="" and sce.bone_target12 !=""  and sce.bone_target15 !="" and sce.bone_target25 !="" and sce.bone_target26 !=""  and sce.bone_target29 !="" and sce.bone_target32 !="" and sce.bone_target17 !="" and sce.bone_target18 !="" and sce.bone_target21 !="" and sce.bone_target24 !="" and sce.bone_target33 !="" and sce.bone_target36 !="" and sce.bone_targetHip !="":
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')

                    
                    
                    
                    bpy.ops.armature.select_all(action='DESELECT')



                    # left Leg

                    if sce.bone_target1 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target1) 
                        if  bonein is not None:
                            myBone4 = armature.edit_bones[sce.bone_target1]
                            myBone4.select = True


                    
                    
                    if sce.bone_target2 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target2) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target2]
                            myBone4.select = True


                    
                    if sce.bone_target3 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target3) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target3]
                            myBone4.select = True


                
                
                    if sce.bone_target4 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target4) 
                        if  bonein is not None:
                
                
                            myBone4 = armature.edit_bones[sce.bone_target4]
                            myBone4.select = True


                    
                    
                    if sce.bone_target5 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target5) 
                        if  bonein is not None: 
                    
                            myBone4 = armature.edit_bones[sce.bone_target5]
                            myBone4.select = True


                    
                    
                    if sce.bone_target6 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target6) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target6]
                            myBone4.select = True


                    
                    if sce.bone_target7 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target7) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target7]
                            myBone4.select = True


                
                
                    if sce.bone_target8 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target8) 
                        if  bonein is not None:
                
                
                            myBone4 = armature.edit_bones[sce.bone_target8]
                            myBone4.select = True





                    #Right Leg
                    
                    if sce.bone_target9 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target9) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target9]
                            myBone4.select = True


                    
                    
                    if sce.bone_target10 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target10) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target10]
                            myBone4.select = True


                
                    if sce.bone_target11 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target11) 
                        if  bonein is not None:
                
                
                            myBone4 = armature.edit_bones[sce.bone_target11]
                            myBone4.select = True


                    
                    if sce.bone_target12 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target12) 
                        if  bonein is not None:
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target12]
                            myBone4.select = True


                    if sce.bone_target13 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target13) 
                        if  bonein is not None:



                            myBone4 = armature.edit_bones[sce.bone_target13]
                            myBone4.select = True


                    
                    if sce.bone_target14 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target14) 
                        if  bonein is not None:
                    
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target14]
                            myBone4.select = True



                    if sce.bone_target15 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target15) 
                        if  bonein is not None:
                    
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target15]
                            myBone4.select = True




                    if sce.bone_target16 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target16) 
                        if  bonein is not None:
                    
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target16]
                            myBone4.select = True




                    #Left Arm

                    if sce.bone_target17 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target17) 
                        if  bonein is not None:

                            myBone = armature.edit_bones[sce.bone_target17]
                            myBone.select = True
                    
                    



                    if sce.bone_target18 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target18) 
                        if  bonein is not None:




                            myBone2 = armature.edit_bones[sce.bone_target18]
                            myBone2.select = True
                
                    
                    
                    if sce.bone_target19 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target19) 
                        if  bonein is not None:
                    
                    
                            myBone3 = armature.edit_bones[sce.bone_target19]
                            myBone3.select = True

                    
                    
                    
                    if sce.bone_target20 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target20) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target20]
                            myBone4.select = True

                    
                    
                    if sce.bone_target21 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target21) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target21]
                            myBone4.select = True
                    
                    
                    
                    if sce.bone_target22 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target22) 
                        if  bonein is not None: 
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target22]
                            myBone4.select = True

                
                
                    if sce.bone_target23 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target23) 
                        if  bonein is not None:
                
                
                            myBone4 = armature.edit_bones[sce.bone_target23]
                            myBone4.select = True

                    
                    if sce.bone_target24 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target24) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target24]
                            myBone4.select = True






                    #Rigt Arm
                    if sce.bone_target25 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target25) 
                        if  bonein is not None: 
                    
                            myBone = armature.edit_bones[sce.bone_target25]
                            myBone.select = True


                    if sce.bone_target26 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target26) 
                        if  bonein is not None:
                    
                            myBone2 = armature.edit_bones[sce.bone_target26]
                            myBone2.select = True



                    if sce.bone_target27 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target27) 
                        if  bonein is not None:


                            myBone3 = armature.edit_bones[sce.bone_target27]
                            myBone3.select = True



                    if sce.bone_target28 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target28) 
                        if  bonein is not None:




                            myBone4 = armature.edit_bones[sce.bone_target28]
                            myBone4.select = True



                    if sce.bone_target29 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target29) 
                        if  bonein is not None:



                            myBone4 = armature.edit_bones[sce.bone_target29]
                            myBone4.select = True




                    if sce.bone_target30 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target30) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target30]
                            myBone4.select = True

                    
                    
                    if sce.bone_target31 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target31) 
                        if  bonein is not None: 
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target31]
                            myBone4.select = True

                    
                    if sce.bone_target32 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target32) 
                        if  bonein is not None:
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target32]
                            myBone4.select = True



                    
                    
                    
                    
                    ###Spine


                    
                    if sce.bone_target33 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target33) 
                        if  bonein is not None:


                            myBone3 = armature.edit_bones[sce.bone_target33]
                            myBone3.select = True
                        
                
                    if sce.bone_target34 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target34) 
                        if  bonein is not None:
                
                
                
                            myBone4 = armature.edit_bones[sce.bone_target34]
                            myBone4.select = True

                    
                    
                    if sce.bone_target35 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target35) 
                        if  bonein is not None:    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target35]
                            myBone4.select = True

                    
                    
                    if sce.bone_target36 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target36) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target36]
                            myBone4.select = True

                
                
                
                
                    if sce.bone_target37 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target37) 
                        if  bonein is not None:
                
                
                            myBone4 = armature.edit_bones[sce.bone_target37]
                            myBone4.select = True

                    
                    if sce.bone_target38 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target38) 
                        if  bonein is not None:  
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target38]
                            myBone4.select = True

                
                    if sce.bone_target39 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target39) 
                        if  bonein is not None:
                
                            myBone4 = armature.edit_bones[sce.bone_target39]
                            myBone4.select = True

                    if sce.bone_target40 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target40) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target40]
                            myBone4.select = True


                    if sce.bone_targetHip !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_targetHip) 
                        if  bonein is not None:  
                    
                        
                            myBone4 = armature.edit_bones[sce.bone_targetHip]
                            myBone4.select = True


                        
                    

                        #Right Fingers
                    
                    if sce.bone_target41 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target41) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target41] #DEF-palm.01.R
                            myBone4.select = True

                
                
                
                
                
                    if sce.bone_target42 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target42) 
                        if  bonein is not None:
                
                
                            myBone4 = armature.edit_bones[sce.bone_target42] #DEF-palm.02.R
                            myBone4.select = True

                
                    if sce.bone_target43 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target43) 
                        if  bonein is not None:
                
                            myBone4 = armature.edit_bones[sce.bone_target43] #DEF-palm.03.R
                            myBone4.select = True

                
                
                    if sce.bone_target44 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target44) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target44] #DEF-palm.04.R
                            myBone4.select = True


                
                    if sce.bone_target45 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target45) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target45]  
                            myBone4.select = True
                    
                    
                    
                    if sce.bone_target46 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target46) 
                        if  bonein is not None:
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target46]  
                            myBone4.select = True
                    
                    
                    if sce.bone_target47 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target47) 
                        if  bonein is not None:
                        
                            
                        
                            myBone4 = armature.edit_bones[sce.bone_target47]
                            myBone4.select = True

                

                
                    if sce.bone_target48 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target48) 
                        if  bonein is not None:


                    
                            myBone4 = armature.edit_bones[sce.bone_target48]
                            myBone4.select = True

                    
                    
                    
                    
                    
                    if sce.bone_target49 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target49) 
                        if  bonein is not None: 
                        
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target49]
                            myBone4.select = True
                
                    
                    
                    
                    if sce.bone_target50 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target50) 
                        if  bonein is not None: 
                        
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target50]
                            myBone4.select = True


                    
                    
                    if sce.bone_target51 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target51) 
                        if  bonein is not None: 
                        
                        
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target51]
                            myBone4.select = True

                
                
                
                    if sce.bone_target52 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target52) 
                        if  bonein is not None:
                    
                    
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target52]
                            myBone4.select = True

                    
                    
                    
                    
                    if sce.bone_target53 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target53) 
                        if  bonein is not None: 
                        

                        
                            myBone4 = armature.edit_bones[sce.bone_target53]
                            myBone4.select = True


                    
                    
                    
                    
                    
                    if sce.bone_target54 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target54) 
                        if  bonein is not None:      
                        
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target54]
                            myBone4.select = True

                        
                    
                    
                    if sce.bone_target55 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target55) 
                        if  bonein is not None:
                        
                        
                        
                        
                        
                            
                            myBone4 = armature.edit_bones[sce.bone_target55]
                            myBone4.select = True



                    if sce.bone_target56 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target56) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target56]
                            myBone4.select = True


                    
                    if sce.bone_target57 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target57) 
                        if  bonein is not None:
                        
                        
                            
                            myBone4 = armature.edit_bones[sce.bone_target57]
                            myBone4.select = True

                    
                    
                    if sce.bone_target58 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target58) 
                        if  bonein is not None:
                        
                        
                        
                            
                            myBone4 = armature.edit_bones[sce.bone_target58]
                            myBone4.select = True

                
                
                
                
                    if sce.bone_target59 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target59) 
                        if  bonein is not None:
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target59]
                            myBone4.select = True



                    
                    #Left Fingers
                
                    if sce.bone_target60 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target60) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target60] #'DEF-palm.01.L'
                            myBone4.select = True
                    
                    
                    if sce.bone_target61 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target61) 
                        if  bonein is not None: 

                            myBone4 = armature.edit_bones[sce.bone_target61] #'DEF-palm.01.L'
                            myBone4.select = True
                    
                
                
                

                
                    if sce.bone_target62 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target62) 
                        if  bonein is not None:
                    
                    
                        
                            myBone4 = armature.edit_bones[sce.bone_target62] #'DEF-palm.01.L' 
                            myBone4.select = True
                        
                    
                    
                    
                    if sce.bone_target63 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target63) 
                        if  bonein is not None: 
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target63] #'DEF-palm.01.L'
                            myBone4.select = True


                
                
                    if sce.bone_target64 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target64) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target64]
                            myBone4.select = True
                    
                
                
                
                
                    if sce.bone_target65 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target65) 
                        if  bonein is not None: 
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target65]
                            myBone4.select = True
                
                
                
                    if sce.bone_target66 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target66) 
                        if  bonein is not None:
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target66]
                            myBone4.select = True

                    
                    
                    
                    if sce.bone_target67 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target67) 
                        if  bonein is not None: 
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target67]
                            myBone4.select = True

                    
                    
                    
                    if sce.bone_target68 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target68) 
                        if  bonein is not None:     
                        
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target68]
                            myBone4.select = True
                
                    
                    
                    
                    
                    if sce.bone_target69 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target69) 
                        if  bonein is not None:  
                        
                            myBone4 = armature.edit_bones[sce.bone_target69]
                            myBone4.select = True


                    
                    if sce.bone_target70 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target70) 
                        if  bonein is not None:
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target70]
                            myBone4.select = True

                
                
                
                    if sce.bone_target71 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target71) 
                        if  bonein is not None: 
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target71]
                            myBone4.select = True

                    
                    
                    if sce.bone_target72 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target72) 
                        if  bonein is not None:
                        
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target72]
                            myBone4.select = True


                
                
                    if sce.bone_target73 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target73) 
                        if  bonein is not None: 
                    
                    
                    
                            myBone4 = armature.edit_bones[sce.bone_target73]
                            myBone4.select = True

                    
                    
                    
                    if sce.bone_target74 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target74) 
                        if  bonein is not None:
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target74]
                            myBone4.select = True

                    
                    
                    if sce.bone_target75 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target75) 
                        if  bonein is not None:
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target75]
                            myBone4.select = True


                
                    if sce.bone_target76 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target76) 
                        if  bonein is not None:
                    
                            myBone4 = armature.edit_bones[sce.bone_target76]
                            myBone4.select = True

                    
                    
                    
                    if sce.bone_target77 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target77) 
                        if  bonein is not None:
                        
                    
                            myBone4 = armature.edit_bones[sce.bone_target77]
                            myBone4.select = True

                    
                    if sce.bone_target78 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target78) 
                        if  bonein is not None: 
                        
                        
                            myBone4 = armature.edit_bones[sce.bone_target78]
                            myBone4.select = True



                    

                    bpy.ops.armature.parent_clear(type='CLEAR')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')



        


        
                    ######################## IK ##########################

                    #///  Add bone for Ik ik_hand_l


                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones[sce.bone_target24]    
                    myBone.select_head = True 
                    #myBone.select_tail = True   
                    bpy.ops.view3d.snap_cursor_to_selected()
                   
                    bpy.ops.armature.select_all(action='DESELECT')
                    


                #////Snip to
                    
                    
                
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("ik_hand_l")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    
                    bpy.ops.armature.select_all(action='DESELECT')
                   





                    #///  Add bone for Ik ik_hand_r

 
                    myBone = armature.edit_bones[sce.bone_target32]    
                    myBone.select_head = True 
                    
                    bpy.ops.view3d.snap_cursor_to_selected()
                 
                    bpy.ops.armature.select_all(action='DESELECT')
                 


                #////Snip to
                  
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("ik_hand_r")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    
                    bpy.ops.armature.select_all(action='DESELECT')
                   


    


                    #///  Add bone for Ik ik_hand_gun
 
                    myBone = armature.edit_bones[sce.bone_target32]    
                    myBone.select_head = True 
                    
                    bpy.ops.view3d.snap_cursor_to_selected()
                  
                    bpy.ops.armature.select_all(action='DESELECT')
                   


                #////Snip to
                     
                
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("ik_hand_gun")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
 
                    bpy.ops.armature.select_all(action='DESELECT')
                   



    

                    #///  Add bone for Ik ik_hand_root


                    #root bone
                    
                    bpy.ops.view3d.snap_cursor_to_center()


                #////Snip to
                    
                  
                
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("ik_hand_root")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                   
                    bpy.ops.armature.select_all(action='DESELECT')
                  





                    #///  Add bone for Ik ik_foot_r

 
                    myBone = armature.edit_bones[sce.bone_target15]    
                    myBone.select_head = True 
                    #myBone.select_tail = True   
                    bpy.ops.view3d.snap_cursor_to_selected()
                   
                    bpy.ops.armature.select_all(action='DESELECT')
                   


                #////Snip to
                    
                  
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("ik_foot_r")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                     
                    bpy.ops.armature.select_all(action='DESELECT')
                   




                    #///  Add bone for Ik ik_foot_l


                 
                    myBone = armature.edit_bones[sce.bone_target7]    
                    myBone.select_head = True 
                    
                    bpy.ops.view3d.snap_cursor_to_selected()
                  
                    bpy.ops.armature.select_all(action='DESELECT')
                   


                #////Snip to
                    
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("ik_foot_l")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                  
                    bpy.ops.armature.select_all(action='DESELECT')
                




                    #///  Add bone for Ik ik_foot_root


                    #  root bone 
                
                    bpy.ops.view3d.snap_cursor_to_center()


                #////Snip to
                    
                
                
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("ik_foot_root")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                 
                    bpy.ops.armature.select_all(action='DESELECT')
                 






                    #///  Add bone for Ik center_of_mass

                    #root bone

                    bpy.ops.view3d.snap_cursor_to_center()



                #////Snip to
               
                
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("center_of_mass")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                 
                    bpy.ops.armature.select_all(action='DESELECT')
                   






                    #///  Add bone for Ik interaction


                    
                    #root bone
                    
                    bpy.ops.view3d.snap_cursor_to_center()



                #////Snip to
                    
                
                
                    
                    ebs = ob.data.edit_bones
                    eb = ebs.new("interaction")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')




                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    #///////////Naming #///////////Naming
                    
                    
                    
                    
                    
                    
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data

                
                
                
                    if sce.bone_target17 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target17) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target17].name = "clavicle_l"
                    
                    if sce.bone_target18 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target18) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target18].name = "upperarm_l"
                        
                    if sce.bone_target19 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target19) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target19].name = "upperarm_twist_01_l"
                
                    if sce.bone_target20 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target20) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target20].name = "upperarm_twist_02_l"
                        
                        
                    if sce.bone_target21 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target21) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target21].name = "lowerarm_l"
                    
                    
                    if sce.bone_target22 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target22) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target22].name = "lowerarm_twist_02_l"
                    
                    if sce.bone_target23 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target23) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target23].name = "lowerarm_twist_01_l"
                    
                    
                    if sce.bone_target24 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target24) 
                        if  bonein is not None:
                            
                            bpy.context.object.data.bones[sce.bone_target24].name = "hand_l"
                    
                    if sce.bone_target1 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target1) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target1].name = "thigh_l"
                    
                    if sce.bone_target2 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target2) 
                        if  bonein is not None: 
                        
                            bpy.context.object.data.bones[sce.bone_target2].name = "thigh_twist_01_l"
                
                    if sce.bone_target3 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target3) 
                        if  bonein is not None:
                            
                            bpy.context.object.data.bones[sce.bone_target3].name = "thigh_twist_02_l"
                
                    if sce.bone_target4 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target4) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target4].name = "calf_l"
                

                    if sce.bone_target5 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target5) 
                        if  bonein is not None: 
                        
                            bpy.context.object.data.bones[sce.bone_target5].name = "calf_twist_02_l"
                    
                    
                    if sce.bone_target6 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target6) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target6].name = "calf_twist_01_l"
                
                    if sce.bone_target7 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target7) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target7].name = "foot_l"

                    if sce.bone_target8 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target8) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target8].name = "ball_l"
                    
                    
                    
                    
                    
                
                
                
                
                
                
                    if sce.bone_target25 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target25) 
                        if  bonein is not None:
                    
                            bpy.context.object.data.bones[sce.bone_target25].name = "clavicle_r"
                
                    if sce.bone_target26 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target26) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target26].name = "upperarm_r"
                    
                    
                    
                    if sce.bone_target27 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target27) 
                        if  bonein is not None: 
                        
                            bpy.context.object.data.bones[sce.bone_target27].name = "upperarm_twist_01_r"
                    
                    
                    
                    if sce.bone_target28 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target28) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target28].name = "upperarm_twist_02_r"
                    
                    
                    if sce.bone_target29 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target29) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target29].name = "lowerarm_r"
                    
                    
                    if sce.bone_target30 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target30) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target30].name = "lowerarm_twist_02_r"
                
                    
                    if sce.bone_target31 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target31) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target31].name = "lowerarm_twist_01_r"
                
                
                    if sce.bone_target32 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target32) 
                        if  bonein is not None:
                    
                    
                            bpy.context.object.data.bones[sce.bone_target32].name = "hand_r"
                
                    

                    if sce.bone_target9 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target9) 
                        if  bonein is not None:


                            bpy.context.object.data.bones[sce.bone_target9].name = "thigh_r"
                        
                
                
                    if sce.bone_target10 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target10) 
                        if  bonein is not None:
                    
                            bpy.context.object.data.bones[sce.bone_target10].name = "thigh_twist_01_r"
                    
                    if sce.bone_target11 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target11) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target11].name = "thigh_twist_02_r"
                
                    if sce.bone_target12 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target12) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target12].name = "calf_r"
                
                    
                    if sce.bone_target13 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target13) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target13].name = "calf_twist_02_r"
                
                    if sce.bone_target14 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target14) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target14].name = "calf_twist_01_r"
                
                    if sce.bone_target15 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target15) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target15].name = "foot_r"
                
                    if sce.bone_target16 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target16) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target16].name = "ball_r"


                    




                    #Fingers_R

                    if sce.bone_target41 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target41) 
                        if  bonein is not None:
                            bpy.context.object.data.bones[sce.bone_target41].name = "pinky_metacarpal_r"
                    
                    if sce.bone_target42 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target42) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target42].name = "ring_metacarpal_r"
                        
                    if sce.bone_target43 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target43) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target43].name = "middle_metacarpal_r"
                    
                    if sce.bone_target44 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target44) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target44].name = "index_metacarpal_r"
                        
                    


                    if sce.bone_target45 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target45) 
                        if  bonein is not None:


                            bpy.context.object.data.bones[sce.bone_target45].name = "thumb_01_r"
                            bpy.context.object.data.bones[sce.bone_target46].name = "thumb_02_r"
                            bpy.context.object.data.bones[sce.bone_target47].name = "thumb_03_r"


                            bpy.context.object.data.bones[sce.bone_target48].name = "index_01_r"
                            bpy.context.object.data.bones[sce.bone_target49].name = "index_02_r"
                            bpy.context.object.data.bones[sce.bone_target50].name = "index_03_r"



                            bpy.context.object.data.bones[sce.bone_target51].name = "middle_01_r"
                            bpy.context.object.data.bones[sce.bone_target52].name = "middle_02_r"
                            bpy.context.object.data.bones[sce.bone_target53].name = "middle_03_r"



                            bpy.context.object.data.bones[sce.bone_target54].name = "ring_01_r"
                            bpy.context.object.data.bones[sce.bone_target55].name = "ring_02_r"
                            bpy.context.object.data.bones[sce.bone_target56].name = "ring_03_r"


                            bpy.context.object.data.bones[sce.bone_target57].name = "pinky_01_r"
                            bpy.context.object.data.bones[sce.bone_target58].name = "pinky_02_r"
                            bpy.context.object.data.bones[sce.bone_target59].name = "pinky_03_r"





                    #Fingers_l


                    if sce.bone_target60 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target60) 
                        if  bonein is not None:
                            bpy.context.object.data.bones[sce.bone_target60].name = "pinky_metacarpal_l"
                        
                    
                    
                    if sce.bone_target61 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target61) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target61].name = "ring_metacarpal_l"
                
                
                    if sce.bone_target62 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target62) 
                        if  bonein is not None:
                    
                    
                            bpy.context.object.data.bones[sce.bone_target62].name = "middle_metacarpal_l"
                    
                    
                    
                    if sce.bone_target63 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target63) 
                        if  bonein is not None:    
                        
                            bpy.context.object.data.bones[sce.bone_target63].name = "index_metacarpal_l"
                    
                    
                    

                    if sce.bone_target64 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target64) 
                        if  bonein is not None:

                            bpy.context.object.data.bones[sce.bone_target64].name = "thumb_01_l"
                            bpy.context.object.data.bones[sce.bone_target65].name = "thumb_02_l"
                            bpy.context.object.data.bones[sce.bone_target66].name = "thumb_03_l"


                            bpy.context.object.data.bones[sce.bone_target67].name = "index_01_l"
                            bpy.context.object.data.bones[sce.bone_target68].name = "index_02_l"
                            bpy.context.object.data.bones[sce.bone_target69].name = "index_03_l"



                            bpy.context.object.data.bones[sce.bone_target70].name = "middle_01_l"
                            bpy.context.object.data.bones[sce.bone_target71].name = "middle_02_l"
                            bpy.context.object.data.bones[sce.bone_target72].name = "middle_03_l"



                            bpy.context.object.data.bones[sce.bone_target73].name = "ring_01_l"
                            bpy.context.object.data.bones[sce.bone_target74].name = "ring_02_l"
                            bpy.context.object.data.bones[sce.bone_target75].name = "ring_03_l"


                            bpy.context.object.data.bones[sce.bone_target76].name = "pinky_01_l"
                            bpy.context.object.data.bones[sce.bone_target77].name = "pinky_02_l"
                            bpy.context.object.data.bones[sce.bone_target78].name = "pinky_03_l"
                




                    
                    #Spine
                    if sce.bone_target33 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target33) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target33].name = "head"
                    
                    if sce.bone_target34 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target34) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target34].name = "neck_02"
                
                    if sce.bone_target35 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target35) 
                        if  bonein is not None:
                    
                            bpy.context.object.data.bones[sce.bone_target35].name = "neck_01"
                
                
                
                    if sce.bone_target36 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target36) 
                        if  bonein is not None:

                    
                            bpy.context.object.data.bones[sce.bone_target36].name = "spine_05"
                    
                    
                    if sce.bone_target37 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target37) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target37].name = "spine_04"
                
                
                    if sce.bone_target38 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target38) 
                        if  bonein is not None:

                    
                            bpy.context.object.data.bones[sce.bone_target38].name = "spine_03"
                    
                    
                    if sce.bone_target39 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target39) 
                        if  bonein is not None:
                        
                            bpy.context.object.data.bones[sce.bone_target39].name = "spine_02"
                        
                    
                    
                    if sce.bone_target40 !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_target40) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_target40].name = "spine_01"
                        
                    
                
                    if sce.bone_targetHip !="" :
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get(sce.bone_targetHip) 
                        if  bonein is not None:
                        
                        
                            bpy.context.object.data.bones[sce.bone_targetHip].name = "pelvis"
                    

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("CenterBrow") 
                    if  bonein is not None:
                        
                        print("gg")
                        bpy.context.object.data.bones["CenterBrow"].name = "qqcenterbrowqq"


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("Nose") 
                    if  bonein is not None:
                        
                        print("gg")
                        bpy.context.object.data.bones["Nose"].name = "qnoseq"
                
                
                

                    bpy.ops.object.mode_set(mode='EDIT')

                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    #Add bone Root ANim ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss RRRRRRRRRRRRRRRRR
        
                    # 
                    



                    
                    
                    
                    
                    
                    
                    #Add bones ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss RRRRRRRRRRRRRRRRR
        
                    # Two Select   FOR ADD  Bone by upperarm_twist_02_l
                    if sce.bone_target25 !="" and sce.bone_target26 !="" and sce.bone_target27 =="" and sce.bone_target28 !="" and sce.bone_target29 !="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_r")
                        if bonein5 is not None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["upperarm_twist_02_r"]
                            myBone2 = armature.edit_bones["upperarm_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("upperarm_twist_01_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')










                    # Two Select   FOR ADD  Bone upperarm_twist_01_l
                    if sce.bone_target25 !="" and sce.bone_target26 !="" and sce.bone_target27 =="" and sce.bone_target28 =="" and sce.bone_target29 !="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_r")
                        bonein6 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_01_r")
                        if bonein5 is None and bonein6 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["upperarm_r"]
                            myBone2 = armature.edit_bones["lowerarm_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_01_r


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("upperarm_twist_02_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            
                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["upperarm_twist_02_r"]
                            myBone2 = armature.edit_bones["upperarm_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("upperarm_twist_01_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')







                    # Two Select   FOR ADD  Bone lowerarm_twist_01_l
                    if sce.bone_target29 !="" and sce.bone_target30 =="" and sce.bone_target31 !="" and sce.bone_target32 !="":
                        bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_02_r")
                        if bonein1 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["lowerarm_r"]
                            myBone2 = armature.edit_bones["lowerarm_twist_01_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("lowerarm_twist_02_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                    







                    #op 2 if we have upperarm_r and lowerarm_r only   

                    # Two Select   FOR ADD  Bone upperarm_twist_02_l
                    if sce.bone_target29 !="" and sce.bone_target30 =="" and sce.bone_target31 ==""  and sce.bone_target32 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_01_r")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_02_r")
                        if bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["lowerarm_r"]
                            myBone2 = armature.edit_bones["hand_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_01_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("lowerarm_twist_02_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["lowerarm_twist_02_r"]
                            myBone2 = armature.edit_bones["hand_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_01_r   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("lowerarm_twist_01_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')
















                    #Add bones ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss LLLLLLLLLLLLLLLLLLL
        
                    # Two Select   FOR ADD  Bone by upperarm_twist_02_l
                    if sce.bone_target17 !="" and sce.bone_target18 !="" and sce.bone_target19 =="" and sce.bone_target20 !="" and sce.bone_target21 !="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_l")
                        if bonein5 is not None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["upperarm_twist_02_l"]
                            myBone2 = armature.edit_bones["upperarm_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("upperarm_twist_01_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')










                    # Two Select   FOR ADD  Bone upperarm_twist_01_l
                    if sce.bone_target17 !="" and sce.bone_target18 !="" and sce.bone_target19 =="" and sce.bone_target20 =="" and sce.bone_target21 !="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_l")
                        bonein6 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_01_l")
                        if bonein5 is None and bonein6 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["upperarm_l"]
                            myBone2 = armature.edit_bones["lowerarm_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_01_r


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("upperarm_twist_02_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            
                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["upperarm_twist_02_l"]
                            myBone2 = armature.edit_bones["upperarm_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("upperarm_twist_01_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')































                    #Add bones sssssssssssssssssssssssssssssssssssssssssssssssssssssssss 22222222222222




                    # Two Select   FOR ADD  Bone lowerarm_twist_01_l
                    if sce.bone_target21 !="" and sce.bone_target22 =="" and sce.bone_target23 !="" and sce.bone_target24 !="":
                        bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_02_l")
                        if bonein1 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["lowerarm_twist_01_l"]
                            myBone2 = armature.edit_bones["lowerarm_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("lowerarm_twist_02_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                    
                    bpy.context.window_manager.progress_update(10.0)






                    #op 2 if we have upperarm_l and lowerarm_l only   

                    # Two Select   FOR ADD  Bone upperarm_twist_02_l
                    if sce.bone_target21 !="" and sce.bone_target22 =="" and sce.bone_target23 ==""  and sce.bone_target24 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_01_l")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_02_l")
                        if bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["lowerarm_l"]
                            myBone2 = armature.edit_bones["hand_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_01_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("lowerarm_twist_02_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["lowerarm_twist_02_l"]
                            myBone2 = armature.edit_bones["hand_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_01_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("lowerarm_twist_01_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                    



                    




                    #Add bones Spine   Spine   Spine   Spine ///////////////////////////////////////





                    # Two Select   FOR ADD  Bone neck_02
                    if sce.bone_target33 !="" and sce.bone_target35 !="" and sce.bone_target34 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("neck_02")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["head"]
                            myBone2 = armature.edit_bones["neck_01"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone neck_02 


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("neck_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')










                    # Two Select   FOR ADD  Bone neck_01
                    if sce.bone_target33 !="" and sce.bone_target35 =="" and sce.bone_target34 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("neck_02")
                        bonein6 =bpy.data.objects[sce.Armature_Target].data.bones.get("neck_01")
                        if bonein5 is None and bonein6 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["head"]
                            myBone2 = armature.edit_bones["spine_05"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone neck_01 


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("neck_01")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            #make bone 2


                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["neck_01"]
                            myBone2 = armature.edit_bones["head"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #ADD  Bone neck_02 

                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("neck_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')











                    # op 2 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 =="" and sce.bone_target38 ==""  and sce.bone_target39 =="" and sce.bone_target40 =="" and sce.bone_targetHip !="" :
                        bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_04")
                        bonein2 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_03")
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_02")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_01")
                        
                        if bonein1 is None and bonein2 is None and bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_05"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_04   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_04")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_04"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_03   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_03")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                            #make bone 3

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_03"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #make bone 4

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_02"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_01   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_01")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')

                    



                    # op 3 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 !="" and sce.bone_target38 ==""  and sce.bone_target39 =="" and sce.bone_target40 =="" and sce.bone_targetHip !="" :
                        bonein2 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_03")
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_02")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_01")
                        
                        if bonein2 is None and bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_04"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_03  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_03")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 3

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_03"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_02"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_01   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_01")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')
                            
                            
                            

                            
                    
                    #NEW /////////////////////
                    
                    
                    
                    
                    
                    
                    
                    
                    # op 4 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 !="" and sce.bone_target38 ==""  and sce.bone_target39 =="" and sce.bone_target40 !="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_03")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_02")
                        
                        if  bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_04"]
                            myBone2 = armature.edit_bones["spine_01"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_03  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_03")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 3

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_03"]
                            myBone2 = armature.edit_bones["spine_03"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_01   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')            
                            
                            
                    
                    
                    #NEW ///////////////////// 2222
                    
                    
                    
                    
                    
                    
                    
                    
                    # op 4 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 !="" and sce.bone_target38 ==""  and sce.bone_target39 !="" and sce.bone_target40 =="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_03")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_01")
                        
                        if  bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_04"]
                            myBone2 = armature.edit_bones["spine_02"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_03  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_03")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 3

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_02"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_01   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_01")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')    
                    
                    
                    
                    
                    
                    
                    
                    
                    #NEW ///////////////////// 33333
                    
                    
                    
                    
                    
                    
                    
                    
                    # op 4 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 !="" and sce.bone_target38 !=""  and sce.bone_target39 =="" and sce.bone_target40 =="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_02")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_01")
                        
                        if  bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_03"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_03  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 3

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_02"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_01   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_01")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')   
                    
                    
                    
                    
                    
                    
                    #NEW ///////////////////// 44444
                    
                    # op 4 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 =="" and sce.bone_target38 !=""  and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_04")
                        if  bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_05"]
                            myBone2 = armature.edit_bones["spine_03"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_04  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_04")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')

    
    
    
    
                    #NEW ///////////////////// 5555
                    
                    # op 4 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target39 !="" and sce.bone_target40==""  and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_01")
                        if  bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_02"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_1  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_01")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')
    
    
    
    
                    #NEW ///////////////////// 6666
                    
                    
                    
                    
                    
                    
                    
                    
                    # op 4 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 =="" and sce.bone_target38 !=""  and sce.bone_target39 =="" and sce.bone_target40 =="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_02")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_01")
                        
                        if  bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_03"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_03  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 3

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_02"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_01   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_01")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')   
    
    
    
    

                #NEW ///////////////////// 7777


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 =="" and sce.bone_target38 ==""  and sce.bone_target39 !="" and sce.bone_target40 =="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_03")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_04")
                        
                        if  bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_05"]
                            myBone2 = armature.edit_bones["spine_02"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                            bpy.context.window_manager.progress_update(11.0)
                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_04")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT') 



                            #make bone 2


                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_04"]
                            myBone2 = armature.edit_bones["spine_02"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_03")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')     
                    
                    
                    
        
                    
                    
                    
                    
                    #NEW ///////////////////// 888


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 =="" and sce.bone_target38 !=""  and sce.bone_target39 =="" and sce.bone_target40 !="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_02")
                        
                        
                        if  bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_03"]
                            myBone2 = armature.edit_bones["spine_01"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT') 


    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
    
    
    
    
    
    
    
    
    
    
    
                            
                            
                            






                    # op 4 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 !="" and sce.bone_target38 !=""  and sce.bone_target39 =="" and sce.bone_target40 !="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_02")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_01")
                        
                        if  bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_03"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                        


                    # op 5 spine spine  chest and pelvis only


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 !="" and sce.bone_target38 !=""  and sce.bone_target39 !="" and sce.bone_target40 =="" and sce.bone_targetHip !="" :
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_01")
                        
                        if  bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_02"]
                            myBone2 = armature.edit_bones["pelvis"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_01")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            
                            






                    # op 6 spine spine   


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 =="" and sce.bone_target38 !=""  and sce.bone_target39 !="" and sce.bone_target40 !="" and sce.bone_targetHip !="" :
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_04")
                        
                        if  bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_05"]
                            myBone2 = armature.edit_bones["spine_03"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_04")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')               










                    # op 7 spine spine   


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 =="" and sce.bone_target38 ==""  and sce.bone_target39 !="" and sce.bone_target40 !="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_03")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_04")
                        
                        if  bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_05"]
                            myBone2 = armature.edit_bones["spine_02"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_04")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT') 



                            #make bone 2


                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_04"]
                            myBone2 = armature.edit_bones["spine_02"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_03")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT') 













                    # op 8 spine spine   


                    # Two Select   FOR ADD  Bone spine 
                    if sce.bone_target36 !="" and sce.bone_target37 =="" and sce.bone_target38 ==""  and sce.bone_target39 =="" and sce.bone_target40 !="" and sce.bone_targetHip !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_02")
                        bonein2 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_03")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("spine_04")
                        
                        if  bonein3 is None and bonein2 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_05"]
                            myBone2 = armature.edit_bones["spine_01"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_04")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT') 



                            #make bone 2


                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_04"]
                            myBone2 = armature.edit_bones["spine_01"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_03")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT') 






                            #make bone 3


                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["spine_03"]
                            myBone2 = armature.edit_bones["spine_01"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone spine_02  


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("spine_02")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')







                    # Right  Leg

                    #Add bones ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss RRRRRRRRRRRRRRRRR





                    # Two Select   FOR ADD  Bone upperarm_twist_02_r
                    if sce.bone_target9!="" and sce.bone_target10 =="" and sce.bone_target12 !="" and sce.bone_target11 !="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_01_r")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["thigh_r"]
                            myBone2 = armature.edit_bones["thigh_twist_02_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("thigh_twist_01_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                    







                    #op 2 if 

                    # Two Select   
                    if sce.bone_target9 !="" and sce.bone_target10 =="" and sce.bone_target11 ==""  and sce.bone_target12 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_01_r")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_02_r")
                        if bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["thigh_r"]
                            myBone2 = armature.edit_bones["calf_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone thigh_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("thigh_twist_02_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["thigh_twist_02_r"]
                            myBone2 = armature.edit_bones["thigh_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("thigh_twist_01_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                    # Right  Leg 2222

                    #Add bones ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss RRRRRRRRRRRRRRRRR





                    # Two Select   FOR ADD  Bone calf_twist_02_l
                    if sce.bone_target12!="" and sce.bone_target14 !="" and sce.bone_target15 !="" and sce.bone_target13 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_02_r")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["calf_r"]
                            myBone2 = armature.edit_bones["calf_twist_01_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("calf_twist_02_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                    







                    #ooooop 2 if 

                    # Two Select   
                    if sce.bone_target12 !="" and sce.bone_target13 =="" and sce.bone_target14 ==""  and sce.bone_target15 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_01_r")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_02_r")
                        if bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["calf_r"]
                            myBone2 = armature.edit_bones["foot_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("calf_twist_02_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["calf_twist_02_r"]
                            myBone2 = armature.edit_bones["foot_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            bpy.context.window_manager.progress_update(15.0)


                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("calf_twist_01_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                    



                # Right  Leg

                    #Add bones ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss LLLLLLLLLLLLLLLLLLL





                    # Two Select   FOR ADD  Bone upperarm_twist_02_r
                    if sce.bone_target1!="" and sce.bone_target2 =="" and sce.bone_target3 !="" and sce.bone_target4 !="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_01_l")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["thigh_l"]
                            myBone2 = armature.edit_bones["thigh_twist_02_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("thigh_twist_01_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                    







                    #op 2 if 

                    # Two Select   
                    if sce.bone_target1!="" and sce.bone_target2 =="" and sce.bone_target3 =="" and sce.bone_target4 !="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_01_l")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_02_l")
                        if bonein5 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["thigh_l"]
                            myBone2 = armature.edit_bones["calf_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone thigh_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("thigh_twist_02_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["thigh_twist_02_l"]
                            myBone2 = armature.edit_bones["thigh_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone upperarm_twist_02_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("thigh_twist_01_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                    # Left  Leg 2222

                    #Add bones ssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssssss LLLLLLLLLLLLLL





                    # Two Select   FOR ADD  Bone calf_twist_02_l
                    if sce.bone_target4!="" and sce.bone_target6 !="" and sce.bone_target7 !="" and sce.bone_target5 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_02_l")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["calf_l"]
                            myBone2 = armature.edit_bones["calf_twist_01_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_02_2   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("calf_twist_02_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                    

                    #op 2 if 

                    # Two Select   
                    if sce.bone_target4 !="" and sce.bone_target5 =="" and sce.bone_target6 ==""  and sce.bone_target7 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_01_l")
                        bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_02_l")
                        if bonein3 is None and bonein4 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["calf_l"]
                            myBone2 = armature.edit_bones["foot_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("calf_twist_02_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #make bone 2

                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["calf_twist_02_l"]
                            myBone2 = armature.edit_bones["foot_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone thigh_twist_01_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("calf_twist_01_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')






                    ##NEWWWWWWWWWWWWWWWWWWWWWWW



                    if sce.bone_target19 !="" and sce.bone_target20 =="" and sce.bone_target21 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_l")
                        if bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["upperarm_twist_01_l"]
                            myBone2 = armature.edit_bones["lowerarm_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("upperarm_twist_02_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                             

                    if sce.bone_target22 !="" and sce.bone_target23 =="" and sce.bone_target24 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_01_l")
                        if bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["lowerarm_twist_02_l"]
                            myBone2 = armature.edit_bones["hand_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("lowerarm_twist_01_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                    if sce.bone_target27 !="" and sce.bone_target28 =="" and sce.bone_target29 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_r")
                        if bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["upperarm_twist_01_r"]
                            myBone2 = armature.edit_bones["lowerarm_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("upperarm_twist_02_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                    if sce.bone_target30 !="" and sce.bone_target31 =="" and sce.bone_target32 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_01_r")
                        if bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["lowerarm_twist_02_r"]
                            myBone2 = armature.edit_bones["hand_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("lowerarm_twist_01_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')







                    if sce.bone_target2 !="" and sce.bone_target3 =="" and sce.bone_target4 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_02_l")
                        if bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["thigh_twist_01_l"]
                            myBone2 = armature.edit_bones["calf_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("thigh_twist_02_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                    if sce.bone_target5 !="" and sce.bone_target6 =="" and sce.bone_target7 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_01_l")
                        if bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["calf_twist_02_l"]
                            myBone2 = armature.edit_bones["foot_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("calf_twist_01_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')






                    if sce.bone_target10 !="" and sce.bone_target11 =="" and sce.bone_target12 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_02_r")
                        if bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["thigh_twist_01_r"]
                            myBone2 = armature.edit_bones["calf_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("thigh_twist_02_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                    if sce.bone_target13 !="" and sce.bone_target14 =="" and sce.bone_target15 !="" :
                        bonein3 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_01_r")
                        if bonein3 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["calf_twist_02_r"]
                            myBone2 = armature.edit_bones["foot_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone calf_twist_01_l


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("calf_twist_01_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



















                    #LLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLLL
                    #////// //////////////////////////////////////////////////////////////////////////////
                    #/////////////////////////////////////////////////////////////////////////////////////
                    #For Fingers 4 up /////////////////////////////////////////////////////////////////////
                    #/////////////////////////////////////////////////////////////////////////////////////
                    #/////////////////////////////////////////////////////////////////////////////////////
                    #For Fingers 4 up /////////////////////////////////////////////////////////////////////

                    if sce.bone_target76 !="" and sce.bone_target60 =="" :
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_metacarpal_l")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["pinky_01_l"]
                            myBone2 = armature.edit_bones["hand_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone pinky_metacarpal_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("pinky_metacarpal_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                    if sce.bone_target73 !="" and sce.bone_target61 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_metacarpal_l")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["ring_01_l"]
                            myBone2 = armature.edit_bones["hand_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone ring_metacarpal_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("ring_metacarpal_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')







                    if sce.bone_target70 !="" and sce.bone_target62 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_metacarpal_l")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["middle_01_l"]
                            myBone2 = armature.edit_bones["hand_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone middle_metacarpal_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("middle_metacarpal_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')







                    if sce.bone_target48 !="" and sce.bone_target63 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("index_metacarpal_l")
                        if bonein5 is None : 



                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["index_01_l"]
                            myBone2 = armature.edit_bones["hand_l"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            bpy.context.window_manager.progress_update(40.0)


                            #ADD  Bone index_metacarpal_l   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("index_metacarpal_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')











                    #RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                    #////// //////////////////////////////////////////////////////////////////////////////
                    #/////////////////////////////////////////////////////////////////////////////////////
                    #For Fingers 4 up /////////////////////////////////////////////////////////////////////
                    #/////////////////////////////////////////////////////////////////////////////////////
                    #/////////////////////////////////////////////////////////////////////////////////////
                    #For Fingers 4 up /////////////////////////////////////////////////////////////////////

                    if sce.bone_target57 !="" and sce.bone_target41 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_metacarpal_r")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["pinky_01_r"]
                            myBone2 = armature.edit_bones["hand_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone pinky_metacarpal_r   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("pinky_metacarpal_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                    if sce.bone_target54 !="" and sce.bone_target42 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_metacarpal_r")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["ring_01_r"]
                            myBone2 = armature.edit_bones["hand_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone ring_metacarpal_r   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("ring_metacarpal_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')







                    if sce.bone_target51 !="" and sce.bone_target43 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_metacarpal_r")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["middle_01_r"]
                            myBone2 = armature.edit_bones["hand_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone middle_metacarpal_r   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("middle_metacarpal_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')







                    if sce.bone_target48 !="" and sce.bone_target44 =="":
                        bonein5 =bpy.data.objects[sce.Armature_Target].data.bones.get("index_metacarpal_r")
                        if bonein5 is None :      
                    
                    
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["index_01_r"]
                            myBone2 = armature.edit_bones["hand_r"]
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #ADD  Bone index_metacarpal_r   


                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("index_metacarpal_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                    


                    
                            

                    ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                    ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                    ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                    ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                    ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                    ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################

                    
                    ####### Make bone RF 

                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones["upperarm_l"]
                    myBone2 = armature.edit_bones["lowerarm_l"]
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    #ADD  Bone Bone RF for cor rot 


                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.mode_set(mode='EDIT')
                
                    
                    ebs = objectToSelect.data.edit_bones
                    eb = ebs.new("arm_rfbone_l")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')

                    
                    
                    
                    #set rot
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)

                    ob = bpy.data.objects[sce.Armature_Target]

                    bpy.ops.object.mode_set(mode='POSE')

                    pbone = ob.pose.bones["arm_rfbone_l"]
                    # Set rotation mode to Euler XYZ, easier to understand
                    # than default quaternions
                    pbone.rotation_mode = 'XYZ'
                    # select axis in ['X','Y','Z']  <--bone local
                    axis = 'X'
                    angle = -90
                    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                    bpy.ops.object.mode_set(mode='OBJECT')



                    bpy.ops.screen.frame_jump(end=False)
        
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["upperarm_l"]
                    selected_bone2 = armature1.pose.bones["lowerarm_l"]
                    selected_bone3 = armature1.pose.bones["hand_l"]
                
            
                    #copy Rot
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "arm_rfbone_l"

                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "arm_rfbone_l"

                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "arm_rfbone_l"

                    
                    #set rot
                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_01_l")
                    if bonein4 is not None:

                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone4 = armature1.pose.bones["upperarm_twist_01_l"]

                        neckconstraint = selected_bone4.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "arm_rfbone_l"
                        
                        
            
                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_l")
                    if bonein4 is not None :

                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone5 = armature1.pose.bones["upperarm_twist_02_l"]

                        neckconstraint = selected_bone5.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "arm_rfbone_l"

    
                    
        

                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_01_l")
                    if bonein4 is not None :

                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone6 = armature1.pose.bones["lowerarm_twist_01_l"]

                        neckconstraint = selected_bone6.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "arm_rfbone_l"

        

                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_02_l")
                    if bonein4 is not None :

                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone7 = armature1.pose.bones["lowerarm_twist_02_l"]

                        neckconstraint = selected_bone7.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "arm_rfbone_l"

                
                    

                
                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)



                    #Add  DAMPED_TRACK
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["upperarm_twist_01_l"]
                    
                    
                
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'


                    
                    
                    
                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)




                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone2 = armature1.pose.bones["upperarm_l"]
                    selected_bone3 = armature1.pose.bones["upperarm_twist_02_l"]
                    selected_bone4 = armature1.pose.bones["lowerarm_l"]
                    selected_bone5 = armature1.pose.bones["lowerarm_twist_02_l"]
                    selected_bone6 = armature1.pose.bones["lowerarm_twist_01_l"]
                    selected_bone7 = armature1.pose.bones["hand_l"]


            
                
            
                    #copy Rot
    
                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"

                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"

                    neckconstraint = selected_bone4.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"

                    neckconstraint = selected_bone5.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"

                    neckconstraint = selected_bone6.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"

                    neckconstraint = selected_bone7.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"



                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)





                    #Add  DAMPED_TRACK
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["upperarm_twist_01_l"]
                    selected_bone2 = armature1.pose.bones["upperarm_twist_02_l"]
                    selected_bone3 = armature1.pose.bones["lowerarm_l"]
                    selected_bone4 = armature1.pose.bones["lowerarm_twist_02_l"]
                    selected_bone5 = armature1.pose.bones["lowerarm_twist_01_l"]
                    selected_bone6 = armature1.pose.bones["hand_r"]
            

                


                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'

                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'

                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_02_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'

                    neckconstraint = selected_bone4.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'

                    neckconstraint = selected_bone5.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_02_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'

                    neckconstraint = selected_bone6.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_01_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'
                    


                    
                    #copy Rot
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["hand_l"]
                


            
                
            
                    
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_01_l"
    
    
    
                    
                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)





                    #     ## Fix Right ARM

                    #Add  LOCKED_TRACK
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["upperarm_l"]
                    selected_bone2 = armature1.pose.bones["upperarm_l"]
                    selected_bone3 = armature1.pose.bones["upperarm_l"]
                    selected_bone4 = armature1.pose.bones["lowerarm_l"]
                    selected_bone5 = armature1.pose.bones["lowerarm_l"]
                    selected_bone6 = armature1.pose.bones["lowerarm_l"]

                    
                
            


                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'   


                    
                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X' 

                    
                    
                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_l"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_X' 

                    neckconstraint = selected_bone4.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_02_l"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X' 


                    neckconstraint = selected_bone5.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_02_l"
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X' 

                    neckconstraint = selected_bone6.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_02_l"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_X' 

                        

                    
                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)




                #     ############ End Fix ###########





    
                        

                    
                    #set rot
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)

                    ob = bpy.data.objects[sce.Armature_Target]

                    bpy.ops.object.mode_set(mode='POSE')

                    pbone = ob.pose.bones["hand_l"]
                    # Set rotation mode to Euler XYZ, easier to understand
                    # than default quaternions
                    pbone.rotation_mode = 'XYZ'
                    # select axis in ['X','Y','Z']  <--bone local
                    axis = 'X'
                    angle = -90
                    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                    bpy.ops.object.mode_set(mode='OBJECT')




                    




                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR
                #     ############## RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR



                    
                    ####### Make bone RF 

                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones["upperarm_r"]
                    myBone2 = armature.edit_bones["lowerarm_r"]
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    #ADD  Bone Bone RF for cor rot 


                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.mode_set(mode='EDIT')
                
                    
                    ebs = objectToSelect.data.edit_bones
                    eb = ebs.new("arm_rfbone_r")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')

                    #set rot
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)

                    ob = bpy.data.objects[sce.Armature_Target]

                    bpy.ops.object.mode_set(mode='POSE')

                    pbone = ob.pose.bones["arm_rfbone_r"]
                    # Set rotation mode to Euler XYZ, easier to understand
                    # than default quaternions
                    pbone.rotation_mode = 'XYZ'
                    # select axis in ['X','Y','Z']  <--bone local
                    axis = 'X'
                    angle = 90
                    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                    bpy.ops.object.mode_set(mode='OBJECT')

                    
                    
                    
                    bpy.ops.screen.frame_jump(end=False)
        
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["upperarm_r"]
                    selected_bone2 = armature1.pose.bones["lowerarm_r"]
                    selected_bone3 = armature1.pose.bones["hand_r"]
                
                
                
            
                    #copy Rot
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "arm_rfbone_r"

                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "arm_rfbone_r"

                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "arm_rfbone_r"

                    
                    #set rot
                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_01_r")
                    if bonein4 is not None:
                        
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone4 = armature1.pose.bones["upperarm_twist_01_r"]

                        neckconstraint = selected_bone4.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "arm_rfbone_r"
                        
                        
            
                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_r")
                    if bonein4 is not None :

                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone5 = armature1.pose.bones["upperarm_twist_02_r"]

                        neckconstraint = selected_bone5.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "arm_rfbone_r"

    
                    
        

                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_01_r")
                    if bonein4 is not None :
                        
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone6 = armature1.pose.bones["lowerarm_twist_01_r"]

                        neckconstraint = selected_bone6.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "arm_rfbone_r"

        

                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_02_r")
                    if bonein4 is not None :
                        
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone7 = armature1.pose.bones["lowerarm_twist_01_r"]

                        neckconstraint = selected_bone7.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "arm_rfbone_r"



                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)



                
                
                
                    #Add  LOCKED_TRACK
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["upperarm_twist_01_r"]
                
            


                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_r"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_X'

            
    
                    
                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)



                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone2 = armature1.pose.bones["upperarm_r"]
                    selected_bone3 = armature1.pose.bones["upperarm_twist_02_r"]
                    selected_bone4 = armature1.pose.bones["lowerarm_r"]
                    selected_bone5 = armature1.pose.bones["lowerarm_twist_02_r"]
                    selected_bone6 = armature1.pose.bones["lowerarm_twist_01_r"]
                    selected_bone7 = armature1.pose.bones["hand_r"]


            
                
            
                    #copy Rot
    
                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"

                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"

                    neckconstraint = selected_bone4.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"

                    neckconstraint = selected_bone5.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"

                    neckconstraint = selected_bone6.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"

                    neckconstraint = selected_bone7.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"



                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)


                    bpy.context.window_manager.progress_update(60.0)



                    #Add  DAMPED_TRACK
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["upperarm_twist_01_r"]
                    selected_bone2 = armature1.pose.bones["upperarm_twist_02_r"]
                    selected_bone3 = armature1.pose.bones["lowerarm_r"]
                    selected_bone4 = armature1.pose.bones["lowerarm_twist_02_r"]
                    selected_bone5 = armature1.pose.bones["lowerarm_twist_01_r"]
                    selected_bone6 = armature1.pose.bones["hand_r"]
            

                


                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_r"
                    neckCopyRot.track_axis = 'TRACK_X'

                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"
                    neckCopyRot.track_axis = 'TRACK_X'

                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_02_r"
                    neckCopyRot.track_axis = 'TRACK_X'

                    neckconstraint = selected_bone4.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_r"
                    neckCopyRot.track_axis = 'TRACK_X'

                    neckconstraint = selected_bone5.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_02_r"
                    neckCopyRot.track_axis = 'TRACK_X'

                    neckconstraint = selected_bone6.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_01_r"
                    neckCopyRot.track_axis = 'TRACK_X'
                    


                    
                    #copy Rot
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["hand_r"]
                


            
                
            
                    
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_01_r"
    
    
    
                    
                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)

                    
                    
                    
                    
                #     ## Fix Right ARM

                    #Add  LOCKED_TRACK
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["upperarm_r"]
                    selected_bone2 = armature1.pose.bones["upperarm_r"]
                    selected_bone3 = armature1.pose.bones["upperarm_r"]
                    selected_bone4 = armature1.pose.bones["lowerarm_r"]
                    selected_bone5 = armature1.pose.bones["lowerarm_r"]
                    selected_bone6 = armature1.pose.bones["lowerarm_r"]

                    
                
            


                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_X'


                    
                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"
                    neckCopyRot.track_axis = 'TRACK_X'

                    
                    
                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "upperarm_twist_01_r"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'

                    neckconstraint = selected_bone4.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_02_r"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_X'


                    neckconstraint = selected_bone5.constraints
                    neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_02_r"
                    neckCopyRot.track_axis = 'TRACK_X'

                    neckconstraint = selected_bone6.constraints
                    neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "lowerarm_twist_02_r"
                    neckCopyRot.lock_axis = 'LOCK_Y'
                    neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'

                        

                    
                    bpy.ops.screen.frame_jump(end=False)
                    #Apply
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)




                #     ############ End Fix ###########
                    

                    
            
                    
                    
                    #set rot
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)

                    ob = bpy.data.objects[sce.Armature_Target]

                    bpy.ops.object.mode_set(mode='POSE')

                    pbone = ob.pose.bones["hand_r"]
                    # Set rotation mode to Euler XYZ, easier to understand
                    # than default quaternions
                    pbone.rotation_mode = 'XYZ'
                    # select axis in ['X','Y','Z']  <--bone local
                    axis = 'X'
                    angle = -90
                    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                    bpy.ops.object.mode_set(mode='OBJECT')



                    ################# END ARM RRRRRRRRRR ###########################
                    ################# END ARM RRRRRRRRRR ###########################
                    ################# END ARM RRRRRRRRRR ###########################

                
                    
                    
                    
                #     ##################### Legs
                #     ##################### Legs
                #     ##################### Legs
                #     ##################### Legs
                #     ##################### Legs
                #     ##################### Legs
                #     ##################### Legs
                #     ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                #     ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                #     ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                #     ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                #     ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################
                #     ########################## LLLLLLLLLLLLLLLLLLLLLLL Bones Rot 90 #####################

                    
                    ####### Make bone RF 

                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones["thigh_l"]
                    myBone2 = armature.edit_bones["calf_l"]
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    #ADD  Bone Bone RF for cor rot 


                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.mode_set(mode='EDIT')
                
                    
                    ebs = objectToSelect.data.edit_bones
                    eb = ebs.new("leg_rfbone_l")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')

                    #set rot
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)

                    ob = bpy.data.objects[sce.Armature_Target]

                    bpy.ops.object.mode_set(mode='POSE')

                    pbone = ob.pose.bones["leg_rfbone_l"]
                    # Set rotation mode to Euler XYZ, easier to understand
                    # than default quaternions
                    pbone.rotation_mode = 'XYZ'
                    # select axis in ['X','Y','Z']  <--bone local
                    axis = 'X'
                    angle = -90
                    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                    bpy.ops.object.mode_set(mode='OBJECT')



                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)

                    ob = bpy.data.objects[sce.Armature_Target]

                    bpy.ops.object.mode_set(mode='POSE')

                    pbone = ob.pose.bones["leg_rfbone_l"]
                    # Set rotation mode to Euler XYZ, easier to understand
                    # than default quaternions
                    pbone.rotation_mode = 'XYZ'
                    # select axis in ['X','Y','Z']  <--bone local
                    axis = 'Y'
                    angle = -90
                    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                    bpy.ops.object.mode_set(mode='OBJECT')


                
                
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["thigh_l"]
                    selected_bone2 = armature1.pose.bones["calf_l"]
                    selected_bone3 = armature1.pose.bones["foot_l"]

                    selected_bone4 = armature1.pose.bones["thigh_twist_01_l"]
                    selected_bone5 = armature1.pose.bones["thigh_twist_02_l"]

                    selected_bone6 = armature1.pose.bones["calf_twist_01_l"]
                    selected_bone7 = armature1.pose.bones["calf_twist_02_l"]
                


            
                
            
                    #copy Rot
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "leg_rfbone_l"

                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "leg_rfbone_l"

                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "leg_rfbone_l"


                

    


                    #set rot
                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_01_l")
                    if bonein4 is not None:

                        neckconstraint = selected_bone4.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "leg_rfbone_l"

                        
            
                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_02_l")
                    if bonein4 is not None :

                        neckconstraint = selected_bone5.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "leg_rfbone_l"



        

                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_01_l")
                    if bonein4 is not None :

                        neckconstraint = selected_bone6.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "leg_rfbone_l"


                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_02_l")
                    if bonein4 is not None :

                        neckconstraint = selected_bone7.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "leg_rfbone_l"



                        bpy.ops.screen.frame_jump(end=False)
                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)
                

                        
                        
                        
                        


                        #Add  DAMPED_TRACK
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone = armature1.pose.bones["thigh_l"]
                        selected_bone2 = armature1.pose.bones["thigh_twist_01_l"]
                        selected_bone3 = armature1.pose.bones["thigh_twist_02_l"]
                        selected_bone4 = armature1.pose.bones["calf_l"]
                        selected_bone5 = armature1.pose.bones["calf_twist_02_l"]
                        selected_bone6 = armature1.pose.bones["calf_twist_01_l"]
    
                        
                        
                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "thigh_twist_01_l"
                        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'


                        neckconstraint = selected_bone2.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "thigh_twist_02_l"
                        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'


                        neckconstraint = selected_bone3.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "calf_l"
                        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'


                        neckconstraint = selected_bone4.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "calf_twist_02_l"
                        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'


                        neckconstraint = selected_bone5.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "calf_twist_01_l"
                        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'


                        neckconstraint = selected_bone6.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "foot_l"
                        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'

                        





                        bpy.ops.screen.frame_jump(end=False)
                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)




                        #copy Rot foot 
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone = armature1.pose.bones["foot_l"]

                        
                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "calf_twist_01_l"



                        bpy.ops.screen.frame_jump(end=False)
                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)

            
            
                #         #### Add bone for FOOT to Fix ///////////////////
            






                        bpy.ops.object.select_all(action='DESELECT')
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        myBone = armature.edit_bones["foot_l"]    
                        myBone.select_head = True 
                        #myBone.select_tail = True   
                        bpy.ops.view3d.snap_cursor_to_selected()
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                    #////Snip to
                        
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.mode_set(mode='EDIT')
                    
                        
                        ebs = objectToSelect.data.edit_bones
                        eb = ebs.new("DEF-fix-foot.L")
                        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                        eb.tail = (0, 1, 2)    # upon returning to object mode
                        
                        #////Snip to cursor
                        eb.select_head = True    
                        eb.select_tail = True
                        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')




                        #MoveBone
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)

                        ob = bpy.data.objects[sce.Armature_Target]

                        bpy.ops.object.mode_set(mode='POSE')
                        
                        name = "DEF-fix-foot.L"
                        pb = ob.pose.bones.get(name)
                        pb.location = (0, -20, 0)
                        bpy.ops.object.mode_set(mode='OBJECT')

                        
                        
                        #Add  DAMPED_TRACK
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone = armature1.pose.bones["foot_l"]
                    
                        
                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "DEF-fix-foot.L"
                        neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'



                        bpy.ops.screen.frame_jump(end=False)
                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)


    

                #         #////////////////////////Foot End //////////////////



                        if sce.bone_target8 !="":


                            #////////////////////////add Bone to toe  //////////////////


                            bpy.ops.object.select_all(action='DESELECT')
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["ball_l"]    
                            myBone.select_head = True 
                            #myBone.select_tail = True   
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                        #////Snip to
                            
                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("ball_BoneFix_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #set rot
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)

                            ob = bpy.data.objects[sce.Armature_Target]

                            bpy.ops.object.mode_set(mode='POSE')

                            pbone = ob.pose.bones["ball_BoneFix_l"]
                            # Set rotation mode to Euler XYZ, easier to understand
                            # than default quaternions
                            pbone.rotation_mode = 'XYZ'
                            # select axis in ['X','Y','Z']  <--bone local
                            axis = 'X'
                            angle = 0
                            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                            bpy.ops.object.mode_set(mode='OBJECT')



                            #copy Rot
                            armature1 = bpy.data.objects[sce.Armature_Target]
                            selected_bone = armature1.pose.bones["ball_l"]
                            
                    
                        
                    
                            
                            neckconstraint = selected_bone.constraints
                            neckCopyRot = neckconstraint.new('COPY_ROTATION')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "ball_BoneFix_l"

                            
                            
                            


                            #Add  DAMPED_TRACK
                            armature1 = bpy.data.objects[sce.Armature_Target]
                            selected_bone = armature1.pose.bones["ball_l"]
                        
                    



                            neckconstraint = selected_bone.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "foot_l"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'



                            bpy.ops.screen.frame_jump(end=False)
                            #Apply
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)


    





                        ############## Fix Axes Sholder LLLLLLLLLLLLLLLLLLLLL ##############################
                        ############## Fix Axes Sholder LLLLLLLLLLLLLLLLLLLLL ##############################
                        ############## Fix Axes Sholder LLLLLLLLLLLLLLLLLLLLL ##############################
                        ############## Fix Axes Sholder LLLLLLLLLLLLLLLLLLLLL ##############################
                        ############## Fix Axes Sholder LLLLLLLLLLLLLLLLLLLLL ##############################
                        ############## Fix Axes Sholder LLLLLLLLLLLLLLLLLLLLL ##############################
                        ############## Fix Axes Sholder LLLLLLLLLLLLLLLLLLLLL ##############################



                        if mytool.my_string40 ==False :


                            bpy.ops.object.select_all(action='DESELECT')
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["clavicle_l"]    
                            #myBone.select_head = True 
                            myBone.select_tail = True   
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                        #////Snip to
                            
                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("Fix_clavicle_l")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #set Length
                            bpy.ops.object.select_all(action='DESELECT') 
                        
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            
                            bpy.ops.object.mode_set(mode='EDIT')
                            objectToSelect2.data.edit_bones['Fix_clavicle_l'].length = objectToSelect2.data.edit_bones['clavicle_l'].length
                            
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            #set Roll   
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones['Fix_clavicle_l'] 
                            myBone2 = armature.edit_bones['clavicle_l'] 
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone
                            bpy.ops.armature.calculate_roll(type='ACTIVE')
                            bpy.ops.object.mode_set(mode='POSE')
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            #set rot
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)

                            ob = bpy.data.objects[sce.Armature_Target]

                            bpy.ops.object.mode_set(mode='POSE')

                            pbone = ob.pose.bones["clavicle_l"]
                            # Set rotation mode to Euler XYZ, easier to understand
                            # than default quaternions
                            pbone.rotation_mode = 'XYZ'
                            # select axis in ['X','Y','Z']  <--bone local
                            axis = 'X'
                            angle = -90
                            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                            bpy.ops.object.mode_set(mode='OBJECT')

                            bpy.ops.screen.frame_jump(end=False)
                            #Apply
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)




                            #Add  DAMPED_TRACK
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones['upperarm_l']    
                            myBone2 = armature.edit_bones['clavicle_l'] 
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
            

                            bpy.ops.pose.constraint_add_with_targets(type='DAMPED_TRACK')
                            bpy.context.object.pose.bones["clavicle_l"].constraints["Damped Track"].track_axis = 'TRACK_X'


                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            bpy.ops.screen.frame_jump(end=False)
                            #Apply
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)






                            ############## Fix Axes Sholder RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR ##############################
                            ############## Fix Axes Sholder RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR ##############################
                            ############## Fix Axes Sholder RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR ##############################
                            ############## Fix Axes Sholder RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR ##############################
                            ############## Fix Axes Sholder RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR ##############################
                            ############## Fix Axes Sholder RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR ##############################
                            ############## Fix Axes Sholder RRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRRR ##############################


                        
                            



                            bpy.ops.object.select_all(action='DESELECT')
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["clavicle_r"]    
                            #myBone.select_head = True 
                            myBone.select_tail = True   
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                        #////Snip to
                            
                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("Fix_clavicle_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #set Length
                            bpy.ops.object.select_all(action='DESELECT') 
                        
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            
                            bpy.ops.object.mode_set(mode='EDIT')
                            objectToSelect2.data.edit_bones['Fix_clavicle_r'].length = objectToSelect2.data.edit_bones['clavicle_r'].length
                            
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            #set Roll   
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones['Fix_clavicle_r'] 
                            myBone2 = armature.edit_bones['clavicle_r'] 
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone
                            bpy.ops.armature.calculate_roll(type='ACTIVE')
                            bpy.ops.object.mode_set(mode='POSE')
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            #set rot
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)

                            ob = bpy.data.objects[sce.Armature_Target]

                            bpy.ops.object.mode_set(mode='POSE')

                            pbone = ob.pose.bones["clavicle_r"]
                            # Set rotation mode to Euler XYZ, easier to understand
                            # than default quaternions
                            pbone.rotation_mode = 'XYZ'
                            # select axis in ['X','Y','Z']  <--bone local
                            axis = 'X'
                            angle = 90
                            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #Apply
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)





                            #Add  Locked Track
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones['upperarm_r']
                            myBone2 = armature.edit_bones['clavicle_r']
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.constraint_add_with_targets(type='LOCKED_TRACK')
                            bpy.context.object.pose.bones["clavicle_r"].constraints["Locked Track"].lock_axis = 'LOCK_Y'
                            bpy.context.object.pose.bones["clavicle_r"].constraints["Locked Track"].track_axis = 'TRACK_X'


                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')





                            #Add  DAMPED_TRACK
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones['upperarm_r']    
                            myBone2 = armature.edit_bones['clavicle_r'] 
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()
            

                            bpy.ops.pose.constraint_add_with_targets(type='DAMPED_TRACK')
                            bpy.context.object.pose.bones["clavicle_r"].constraints["Damped Track"].track_axis = 'TRACK_X'


                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                            #Add  Locked Track
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect = bpy.data.objects[sce.Armature_Target] 
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect
                            
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones['upperarm_r']
                            myBone2 = armature.edit_bones['clavicle_r']
                            myBone.select = True
                            myBone2.select = True
                            armature.edit_bones.active = myBone2
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.constraint_add_with_targets(type='LOCKED_TRACK')
                            bpy.context.object.pose.bones["clavicle_r"].constraints["Locked Track.001"].lock_axis = 'LOCK_Y'
                            bpy.context.object.pose.bones["clavicle_r"].constraints["Locked Track.001"].track_axis = 'TRACK_NEGATIVE_X'



                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')




                            #Apply
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)







                        











                #     ##########################RRRRRRRRRRRRRRRRRRRRRRRRRR Bones Rot 90 #####################
                #     ##########################RRRRRRRRRRRRRRRRRRRRRRRRRR Bones Rot 90 #####################
                #     ##########################RRRRRRRRRRRRRRRRRRRRRRRRRR Bones Rot 90 #####################
                #     ##########################RRRRRRRRRRRRRRRRRRRRRRRRRR Bones Rot 90 #####################
                #     ##########################RRRRRRRRRRRRRRRRRRRRRRRRRR Bones Rot 90 #####################
                #     ##########################RRRRRRRRRRRRRRRRRRRRRRRRRR Bones Rot 90 #####################
                #     ##########################RRRRRRRRRRRRRRRRRRRRRRRRRR Bones Rot 90 #####################
                #     ##########################RRRRRRRRRRRRRRRRRRRRRRRRRR Bones Rot 90 #####################
            

                    
                    ####### Make bone RF 

                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones["thigh_r"]
                    myBone2 = armature.edit_bones["calf_r"]
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.view3d.snap_cursor_to_selected()
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    #ADD  Bone Bone RF for cor rot 


                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.mode_set(mode='EDIT')
                
                    
                    ebs = objectToSelect.data.edit_bones
                    eb = ebs.new("leg_rfbone_r")
                    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                    eb.tail = (0, 1, 2)    # upon returning to object mode
                    
                    #////Snip to cursor
                    eb.select_head = True    
                    eb.select_tail = True
                    bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')

                
                    #set rot
                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)

                    ob = bpy.data.objects[sce.Armature_Target]

                    bpy.ops.object.mode_set(mode='POSE')

                    pbone = ob.pose.bones["leg_rfbone_r"]
                    # Set rotation mode to Euler XYZ, easier to understand
                    # than default quaternions
                    pbone.rotation_mode = 'XYZ'
                    # select axis in ['X','Y','Z']  <--bone local
                    axis = 'X'
                    angle = 90
                    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                    bpy.ops.object.mode_set(mode='OBJECT')



                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)

                    ob = bpy.data.objects[sce.Armature_Target]

                    bpy.ops.object.mode_set(mode='POSE')

                    pbone = ob.pose.bones["leg_rfbone_r"]
                    # Set rotation mode to Euler XYZ, easier to understand
                    # than default quaternions
                    pbone.rotation_mode = 'XYZ'
                    # select axis in ['X','Y','Z']  <--bone local
                    axis = 'Y'
                    angle = -90
                    pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                    bpy.ops.object.mode_set(mode='OBJECT')


                
                
                    armature1 = bpy.data.objects[sce.Armature_Target]
                    selected_bone = armature1.pose.bones["thigh_r"]
                    selected_bone2 = armature1.pose.bones["calf_r"]
                    selected_bone3 = armature1.pose.bones["foot_r"]

                    selected_bone4 = armature1.pose.bones["thigh_twist_01_r"]
                    selected_bone5 = armature1.pose.bones["thigh_twist_02_r"]

                    selected_bone6 = armature1.pose.bones["calf_twist_01_r"]
                    selected_bone7 = armature1.pose.bones["calf_twist_02_r"]
                


            
                
            
                    #copy Rot
                    neckconstraint = selected_bone.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "leg_rfbone_r"

                    neckconstraint = selected_bone2.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "leg_rfbone_r"

                    neckconstraint = selected_bone3.constraints
                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                    neckCopyRot.target = armature1
                    neckCopyRot.subtarget = "leg_rfbone_r"


                

    


                    #set rot
                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_01_r")
                    if bonein4 is not None:

                        neckconstraint = selected_bone4.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "leg_rfbone_r"

                        
            
                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_02_r")
                    if bonein4 is not None :

                        neckconstraint = selected_bone5.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "leg_rfbone_r"



        

                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_01_r")
                    if bonein4 is not None :

                        neckconstraint = selected_bone6.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "leg_rfbone_r"


                    bonein4 =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_02_r")
                    if bonein4 is not None :

                        neckconstraint = selected_bone7.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "leg_rfbone_r"



                        bpy.ops.screen.frame_jump(end=False)
                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)





                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)



                        



                        #Add  DAMPED_TRACK
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone = armature1.pose.bones["thigh_r"]
                        selected_bone2 = armature1.pose.bones["thigh_twist_01_r"]
                        selected_bone3 = armature1.pose.bones["thigh_twist_02_r"]
                        selected_bone4 = armature1.pose.bones["calf_r"]
                        selected_bone5 = armature1.pose.bones["calf_twist_02_r"]
                        selected_bone6 = armature1.pose.bones["calf_twist_01_r"]
    
                        
                        
                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "thigh_twist_01_r"
                        neckCopyRot.track_axis = 'TRACK_X'


                        neckconstraint = selected_bone2.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "thigh_twist_02_r"
                        neckCopyRot.track_axis = 'TRACK_X'


                        neckconstraint = selected_bone3.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "calf_r"
                        neckCopyRot.track_axis = 'TRACK_X'


                        neckconstraint = selected_bone4.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "calf_twist_02_r"
                        neckCopyRot.track_axis = 'TRACK_X'


                        neckconstraint = selected_bone5.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "calf_twist_01_r"
                        neckCopyRot.track_axis = 'TRACK_X'


                        neckconstraint = selected_bone6.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "foot_r"
                        neckCopyRot.track_axis = 'TRACK_X'



                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)




                        #copy Rot foot 
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone = armature1.pose.bones["foot_r"]

                        
                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "calf_twist_01_r"



                        bpy.ops.screen.frame_jump(end=False)
                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)






                #         #### Add bone for FOOT to Fix RRRRRRRRRRRR///////////////////
            


                        bpy.ops.object.select_all(action='DESELECT')
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        myBone = armature.edit_bones["foot_r"]    
                        myBone.select_head = True 
                        #myBone.select_tail = True   
                        bpy.ops.view3d.snap_cursor_to_selected()
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                    #////Snip to
                        
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.mode_set(mode='EDIT')
                    
                        
                        ebs = objectToSelect.data.edit_bones
                        eb = ebs.new("DEF-fix-foot.R")
                        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                        eb.tail = (0, 1, 2)    # upon returning to object mode
                        
                        #////Snip to cursor
                        eb.select_head = True    
                        eb.select_tail = True
                        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')




                        #MoveBone
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)

                        ob = bpy.data.objects[sce.Armature_Target]

                        bpy.ops.object.mode_set(mode='POSE')
                        
                        name = "DEF-fix-foot.R"
                        pb = ob.pose.bones.get(name)
                        pb.location = (0, -20, 0)
                        bpy.ops.object.mode_set(mode='OBJECT')

                        
                        
                        #Add  DAMPED_TRACK
                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone = armature1.pose.bones["foot_r"]
                    
                        
                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('DAMPED_TRACK')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "DEF-fix-foot.R"
                        neckCopyRot.track_axis = 'TRACK_X'



                        bpy.ops.screen.frame_jump(end=False)
                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)


    

                #         #////////////////////////Foot End //////////////////

                        if sce.bone_target16 !="":

                            #////////////////////////add Bone to toe  //////////////////


                            bpy.ops.object.select_all(action='DESELECT')
                            ob = bpy.data.objects[sce.Armature_Target]
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            myBone = armature.edit_bones["ball_r"]    
                            myBone.select_head = True 
                            #myBone.select_tail = True   
                            bpy.ops.view3d.snap_cursor_to_selected()
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                        #////Snip to
                            
                            objectToSelect = bpy.data.objects[sce.Armature_Target]
                            objectToSelect.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect

                            bpy.ops.object.mode_set(mode='EDIT')
                        
                            
                            ebs = objectToSelect.data.edit_bones
                            eb = ebs.new("ball_BoneFix_r")
                            eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                            eb.tail = (0, 1, 2)    # upon returning to object mode
                            
                            #////Snip to cursor
                            eb.select_head = True    
                            eb.select_tail = True
                            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                            #set rot
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)

                            ob = bpy.data.objects[sce.Armature_Target]

                            bpy.ops.object.mode_set(mode='POSE')

                            pbone = ob.pose.bones["ball_BoneFix_r"]
                            # Set rotation mode to Euler XYZ, easier to understand
                            # than default quaternions
                            pbone.rotation_mode = 'XYZ'
                            # select axis in ['X','Y','Z']  <--bone local
                            axis = 'X'
                            angle = 180
                            pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                            bpy.ops.object.mode_set(mode='OBJECT')



                            #copy Rot
                            armature1 = bpy.data.objects[sce.Armature_Target]
                            selected_bone = armature1.pose.bones["ball_r"]
                            
                    
                        
                    
                            
                            neckconstraint = selected_bone.constraints
                            neckCopyRot = neckconstraint.new('COPY_ROTATION')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "ball_BoneFix_r"

                            
                            
                            


                            #Add  DAMPED_TRACK
                            armature1 = bpy.data.objects[sce.Armature_Target]
                            selected_bone = armature1.pose.bones["ball_r"]
                        
                    



                            neckconstraint = selected_bone.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "foot_r"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'



                            bpy.ops.screen.frame_jump(end=False)
                            #Apply
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)
        
    


                #         ################ END Toe #######################






                #         #////////////////////////add Bone to Spine Roto cor  //////////////////


                        










                        bpy.ops.object.select_all(action='DESELECT')
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        myBone = armature.edit_bones["pelvis"]    
                        myBone.select_head = True 
                        #myBone.select_tail = True   
                        bpy.ops.view3d.snap_cursor_to_selected()
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                    #////Snip to
                        
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.mode_set(mode='EDIT')
                    
                        
                        ebs = objectToSelect.data.edit_bones
                        eb = ebs.new("spine_BoneFix_r")
                        eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
                        eb.tail = (0, 1, 2)    # upon returning to object mode
                        
                        #////Snip to cursor
                        eb.select_head = True    
                        eb.select_tail = True
                        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                        #set rot
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)

                        ob = bpy.data.objects[sce.Armature_Target]

                        bpy.ops.object.mode_set(mode='POSE')

                        pbone = ob.pose.bones["spine_BoneFix_r"]
                        # Set rotation mode to Euler XYZ, easier to understand
                        # than default quaternions
                        pbone.rotation_mode = 'XYZ'
                        # select axis in ['X','Y','Z']  <--bone local
                        axis = 'X'
                        angle = -90
                        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                        bpy.ops.object.mode_set(mode='OBJECT')



                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)

                        ob = bpy.data.objects[sce.Armature_Target]

                        bpy.ops.object.mode_set(mode='POSE')

                        pbone = ob.pose.bones["spine_BoneFix_r"]
                        # Set rotation mode to Euler XYZ, easier to understand
                        # than default quaternions
                        pbone.rotation_mode = 'XYZ'
                        # select axis in ['X','Y','Z']  <--bone local
                        axis = 'Y'
                        angle = -90
                        pbone.rotation_euler.rotate_axis(axis, math.radians(angle))
                        bpy.ops.object.mode_set(mode='OBJECT')


                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')



                        armature1 = bpy.data.objects[sce.Armature_Target]
                        selected_bone = armature1.pose.bones["pelvis"]
                        selected_bone2 = armature1.pose.bones["spine_01"]
                        selected_bone3 = armature1.pose.bones["spine_02"]
                        selected_bone4 = armature1.pose.bones["spine_03"]
                        selected_bone5 = armature1.pose.bones["spine_04"]
                        selected_bone6 = armature1.pose.bones["spine_05"]
                        selected_bone7 = armature1.pose.bones["neck_01"]
                        selected_bone8 = armature1.pose.bones["neck_02"]
                        selected_bone9 = armature1.pose.bones["head"]
                    
                        


                        neckconstraint = selected_bone.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"


                        neckconstraint = selected_bone2.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"


                        neckconstraint = selected_bone3.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"


                        neckconstraint = selected_bone4.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"


                        neckconstraint = selected_bone5.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"


                        neckconstraint = selected_bone6.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"

                        neckconstraint = selected_bone7.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"

                        neckconstraint = selected_bone8.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"

                        neckconstraint = selected_bone9.constraints
                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                        neckCopyRot.target = armature1
                        neckCopyRot.subtarget = "spine_BoneFix_r"
                        
    

                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')



                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)



                       
                       
                    

                        bpy.context.window_manager.progress_update(65.0)            
                       
                       
                       
                        # if mytool.my_boolspine !=False :

                        


                        


                        if mytool.my_string38 !=False :

                            #spinerot
                            bpy.ops.spinerotoo.myop_operator()


                                
                            #LOCKED_TRACK &&
                            armature1 = bpy.data.objects[sce.Armature_Target]
                            selected_bone = armature1.pose.bones["pelvis"]
                            selected_bone2 = armature1.pose.bones["pelvis"]
                
                            

                            neckconstraint = selected_bone.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "spine_05"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'




                            neckconstraint = selected_bone2.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "spine_05"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'




                            #Apply
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)

                        

                        
                        
                            
                            #LOCKED_TRACK &&
                            armature1 = bpy.data.objects[sce.Armature_Target]
                            selected_bone = armature1.pose.bones["spine_01"]
                            selected_bone2 = armature1.pose.bones["spine_02"]
                            selected_bone3 = armature1.pose.bones["spine_03"]
                            selected_bone4 = armature1.pose.bones["spine_04"]
                            selected_bone5 = armature1.pose.bones["spine_05"]
                            selected_bone6 = armature1.pose.bones["neck_01"]
                            selected_bone7 = armature1.pose.bones["neck_02"]

                            selected_bone8 = armature1.pose.bones["head"]
                
                
                    


                            neckconstraint = selected_bone.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "spine_05"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'


                            neckconstraint = selected_bone2.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "spine_05"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'



                            neckconstraint = selected_bone3.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "spine_05"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'


                            neckconstraint = selected_bone4.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "spine_05"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'



                            neckconstraint = selected_bone5.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "neck_01"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'


                            neckconstraint = selected_bone6.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "neck_02"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'


                            neckconstraint = selected_bone7.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "head"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_X'


                            neckconstraint = selected_bone8.constraints
                            neckCopyRot = neckconstraint.new('LOCKED_TRACK')
                            neckCopyRot.target = armature1
                            neckCopyRot.subtarget = "neck_02"
                            neckCopyRot.lock_axis = 'LOCK_Y'
                            neckCopyRot.track_axis = 'TRACK_NEGATIVE_X'





    



        

        
                            #Apply
                            
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')



                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)



                             
                        
                            

                        ######### Agsment

                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect 
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')   
                        
                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["head"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string41 *-1




                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["neck_02"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string42 *-1


                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["neck_01"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string43 *-1



                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["spine_05"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string44 *-1








                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["spine_04"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string45 *-1




                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["spine_03"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string46 *-1




                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["spine_02"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string47 *-1



                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["spine_01"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string48 *-1





                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["pelvis"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string49


                        bpy.ops.object.mode_set(mode='OBJECT')


                        


                       
                       
                       
                       
                       
                        if mytool.my_string40 !=False :

                            makeuerigclav()

                            armature1 = bpy.data.objects[sce.Armature_Target]
                            armature2 = bpy.data.objects['RF_clav_A']
                                        
                            selected_bone = armature1.pose.bones["clavicle_l"]
                                    
                            neckconstraint = selected_bone.constraints
                            neckCopyRot = neckconstraint.new('COPY_ROTATION')
                            neckCopyRot.target = armature2  
                            neckCopyRot.subtarget = "clavicle_l"


                            armature1 = bpy.data.objects[sce.Armature_Target]
                            armature2 = bpy.data.objects['RF_clav_A']
                                        
                            selected_bone2 = armature1.pose.bones["clavicle_r"]
                                    
                            neckconstraint = selected_bone2.constraints
                            neckCopyRot = neckconstraint.new('COPY_ROTATION')
                            neckCopyRot.target = armature2  
                            neckCopyRot.subtarget = "clavicle_r"
                            


                        #Apply
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')



                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)








                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["clavicle_l"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[1]=bpy.context.scene.my_tool.my_string50 




                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["clavicle_r"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[1]=bpy.context.scene.my_tool.my_string51 






                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["clavicle_l"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string52 *-1





                        objectToSelect = bpy.data.objects[sce.Armature_Target]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        ob = bpy.data.objects[sce.Armature_Target]
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='POSE')
                        bpy.ops.pose.select_all(action='SELECT')
                        bpy.ops.pose.select_all(action='DESELECT')
                        b=ob.data.bones["clavicle_r"] 
                        b.select=True
                        ob.data.bones.active=b
                        bpy.context.active_pose_bone.rotation_mode = 'XYZ'
                        bpy.context.active_pose_bone.rotation_euler[2]=bpy.context.scene.my_tool.my_string53 *-1
                        
    
                        bpy.ops.object.mode_set(mode='OBJECT')



















                        
                        
                        
                        
                        objects = bpy.context.scene.objects.keys()
                        if  'Fingers_Direction' not in objects :

                            bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                            bpy.context.active_object.name = 'RF_thumb_AR'

                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["RF_thumb_AR"]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            
                            for obj in bpy.context.selected_objects:
                                obj.name = "Fingers_Direction"
                                obj.data.name = "Fingers_Direction"  
                        
                        
                        
                        
                        
                        
                        

                        ########### Fingers ###########################
                        bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("index_01_l")
                        bonein2 =bpy.data.objects[sce.Armature_Target].data.bones.get("index_01_r")
                        if  bonein is not None and bonein2 is  not None:
                        
                            if mytool.my_string39 ==False: 
                            
                                bpy.ops.fingersnew.myop_operator() 
                            
                            if mytool.my_string39 !=False:
                            
                                bpy.ops.leftfingerrot.myop_operator() 
                                bpy.ops.rigtfingerrot.myop_operator() 


                        
                        
                        
                        
                        
                        
                        
                        ##############New Rig Pose Copy
                        armatureFrom = bpy.data.objects["Your_Rig_Pose"]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)

                            copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
                            copy_con.target = armatureFrom
                            copy_con.subtarget = boneFrom.name


        










                #         ######################### NEW  RF_Rig ##########################################################################################################################
                #         ######################### NEW  RF_Rig ##########################################################################################################################
                #         ######################### NEW  RF_Rig ##########################################################################################################################
                #         ######################### NEW  RF_Rig ##########################################################################################################################
                #         ######################### NEW  RF_Rig ##########################################################################################################################
                #         ######################### NEW  RF_Rig ##########################################################################################################################
                #         ######################### NEW  RF_Rig ##########################################################################################################################
                #         ######################### NEW  RF_Rig ##########################################################################################################################

                        objects = bpy.context.scene.objects.keys()
                        if  'RF_To_Ues_PosMatching' in objects:
                        
                        
                        
                        #///COPY ROT1 1 
                            if sce.bone_target17 !="" and mytool.my_bool !=False :

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']

                                    selected_bone = armature1.pose.bones["clavicle_l"]

                                    neckconstraint = selected_bone.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "clavicle_l"
                                


                            #///COPY ROT 2
                            if sce.bone_target18 !="" and mytool.my_bool3 !=False :

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']
    
                                    selected_bone2 = armature1.pose.bones["upperarm_l"]

                                    neckconstraint = selected_bone2.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "upperarm_l"
                            
                
        
                    

                            #///COPY ROT 3
                            if sce.bone_target21 !="" and mytool.my_bool5 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone3 = armature1.pose.bones["lowerarm_l"]

                                    neckconstraint = selected_bone3.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "lowerarm_l"
                            

                    

                            #///COPY ROT 4
                            if sce.bone_target24 !="" and mytool.my_bool7 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone4 = armature1.pose.bones["hand_l"]

                                    neckconstraint = selected_bone4.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "hand_l"
                        




                            #///COPY ROT 5
                            if sce.bone_target1 !="" and mytool.my_bool18 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone5 = armature1.pose.bones["thigh_l"]

                                    neckconstraint = selected_bone5.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "thigh_l"

                                
                            

                    


                            #///COPY ROT 6
                            if sce.bone_target4 !="" and mytool.my_bool20 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone6 = armature1.pose.bones["calf_l"]

                                    neckconstraint = selected_bone6.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "calf_l"
                            

            

    

                            if sce.bone_target25 !="" and mytool.my_bool2 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone7 = armature1.pose.bones["clavicle_r"]

                                    neckconstraint = selected_bone7.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "clavicle_r"
                        
            
    
                            if sce.bone_target26 !="" and mytool.my_bool4 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone8 = armature1.pose.bones["upperarm_r"]

                                    neckconstraint = selected_bone8.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "upperarm_r"
                            



                    

                            #///COPY ROT 3

                            if sce.bone_target29 !="" and mytool.my_bool6 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone9 = armature1.pose.bones["lowerarm_r"]

                                    neckconstraint = selected_bone9.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "lowerarm_r"
                            
    
        

                    

                            #///COPY ROT 4

                            if sce.bone_target32 !="" and mytool.my_bool8 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone10 = armature1.pose.bones["hand_r"]

                                    neckconstraint = selected_bone10.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "hand_r"
                            

            




                            #///COPY ROT 5

                            if sce.bone_target9 !="" and mytool.my_bool19 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone11 = armature1.pose.bones["thigh_r"]

                                    neckconstraint = selected_bone11.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "thigh_r"
                            


                            #///COPY ROT 6

                            if sce.bone_target12 !="" and mytool.my_bool21 !=False:


                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone12 = armature1.pose.bones["calf_r"]

                                    neckconstraint = selected_bone12.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "calf_r"
                            

            


                        
                        
                        
                        
                            ##Spine
                        #///COPY ROT1 1

                            if sce.bone_target33 !="" and mytool.my_bool9 !=False :

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone13 = armature1.pose.bones["head"]

                                    neckconstraint = selected_bone13.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "head"
                        


                            #///COPY ROT1 2

                            if sce.bone_target34 !="" and mytool.my_bool11 !=False :

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone14 = armature1.pose.bones["neck_02"]

                                    neckconstraint = selected_bone14.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "neck_02"
                            

            


                            #///COPY ROT1 3

                            if sce.bone_target35 !=""and mytool.my_bool10 !=False :

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone15 = armature1.pose.bones["neck_01"]

                                    neckconstraint = selected_bone15.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "neck_01"
            

                            
                            #///COPY ROT1 4

                            if sce.bone_target36 !="" and mytool.my_bool12 !=False:


                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone16 = armature1.pose.bones["spine_05"]

                                    neckconstraint = selected_bone16.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "spine_05"

                                
            


                            #///COPY ROT1 5
                            if sce.bone_target37 !="" and mytool.my_bool13 !=False :

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone17 = armature1.pose.bones["spine_04"]

                                    neckconstraint = selected_bone17.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "spine_04"
                            
            




                            #///COPY ROT1 6

                            if sce.bone_target38 !="" and mytool.my_bool14 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone18 = armature1.pose.bones["spine_03"]

                                    neckconstraint = selected_bone18.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "spine_03"
                            

            



                            #///COPY ROT1 7

                            if sce.bone_target39 !="" and mytool.my_bool15 !=False :

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone19 = armature1.pose.bones["spine_02"]

                                    neckconstraint = selected_bone19.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "spine_02"
                            

            



                            #///COPY ROT1 8

                            if sce.bone_target40 !="" and mytool.my_bool16 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone20 = armature1.pose.bones["spine_01"]

                                    neckconstraint = selected_bone20.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "spine_01"
                        
            



                            #///COPY ROT1 9

                            if sce.bone_targetHip !="" and mytool.my_bool17 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone21 = armature1.pose.bones["pelvis"]

                                    neckconstraint = selected_bone21.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "pelvis"
                
                            

                                #add Foots ////////////////////////////////////////////////////////////

                            if sce.bone_target7 !="" and mytool.my_bool22 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone22 = armature1.pose.bones["foot_l"]

                                    neckconstraint = selected_bone22.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "foot_l"
            


                            if sce.bone_target8 !="" and mytool.my_bool24 !=False:

                                    if sce.bone_target8 !="":
                                    
                                        armature1 = bpy.data.objects[sce.Armature_Target]
                                        armature2 = bpy.data.objects['RF_Rig']


                                        selected_bone23 = armature1.pose.bones["ball_l"]

                                        neckconstraint = selected_bone23.constraints
                                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                        neckCopyRot.target = armature2
                                        neckCopyRot.subtarget = "ball_l"
                        
                                


                            if sce.bone_target15 !="" and mytool.my_bool23 !=False:

                                    armature1 = bpy.data.objects[sce.Armature_Target]
                                    armature2 = bpy.data.objects['RF_Rig']


                                    selected_bone24 = armature1.pose.bones["foot_r"]

                                    neckconstraint = selected_bone24.constraints
                                    neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                    neckCopyRot.target = armature2
                                    neckCopyRot.subtarget = "foot_r"
            


                            if sce.bone_target16 !="" and mytool.my_bool25 !=False:

                                    
                                    if sce.bone_target16 !="":
                                    
                                        armature1 = bpy.data.objects[sce.Armature_Target]
                                        armature2 = bpy.data.objects['RF_Rig']


                                        selected_bone25 = armature1.pose.bones["ball_r"]

                                        neckconstraint = selected_bone25.constraints
                                        neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                        neckCopyRot.target = armature2
                                        neckCopyRot.subtarget = "ball_r"
            



                                #new /////////////////////////////////////

                        #add Foots ////////////////////////////////////////////////////////////

                        if mytool.my_bool26 !=False or mytool.my_bool27 !=False:

                            armature1 = bpy.data.objects[sce.Armature_Target]
                            armature2 = bpy.data.objects['RF_Rig']


                            selected_bone26 = armature1.pose.bones["foot_l"]

                            neckconstraint = selected_bone26.constraints
                            neckCopyRot = neckconstraint.new('COPY_ROTATION')
                            neckCopyRot.target = armature2
                            neckCopyRot.subtarget = "foot_l"
                    
            


                        if mytool.my_bool26 !=False or mytool.my_bool27 !=False:

                            
                            if sce.bone_target8 !="":
                                armature1 = bpy.data.objects[sce.Armature_Target]
                                armature2 = bpy.data.objects['RF_Rig']

                                
                                selected_bone27 = armature1.pose.bones["ball_l"]

                                neckconstraint = selected_bone27.constraints
                                neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                neckCopyRot.target = armature2
                                neckCopyRot.subtarget = "ball_l"
            


                        if  mytool.my_bool26 !=False or mytool.my_bool27 !=False:

                            armature1 = bpy.data.objects[sce.Armature_Target]
                            armature2 = bpy.data.objects['RF_Rig']


                            selected_bone28 = armature1.pose.bones["foot_r"]

                            neckconstraint = selected_bone28.constraints
                            neckCopyRot = neckconstraint.new('COPY_ROTATION')
                            neckCopyRot.target = armature2
                            neckCopyRot.subtarget = "foot_r"
                    
                        



                        if mytool.my_bool26 !=False or mytool.my_bool27 !=False:

                            if sce.bone_target16 !="":
                            
                                armature1 = bpy.data.objects[sce.Armature_Target]
                                armature2 = bpy.data.objects['RF_Rig']


                                selected_bone29 = armature1.pose.bones["ball_r"]

                                neckconstraint = selected_bone29.constraints
                                neckCopyRot = neckconstraint.new('COPY_ROTATION')
                                neckCopyRot.target = armature2
                                neckCopyRot.subtarget = "ball_r"
                    
            


                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                            objectToSelect2.select_set(True)
                            bpy.context.view_layer.objects.active = objectToSelect2
                            ob = bpy.data.objects[sce.Armature_Target] 
                            armature = ob.data
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='SELECT')
                            
                            bpy.ops.object.posemode_toggle()

                            bpy.ops.pose.armature_apply(selected=False)
                            bpy.ops.object.mode_set(mode='EDIT')
                            bpy.ops.armature.select_all(action='DESELECT')
                            bpy.ops.object.mode_set(mode='OBJECT')


                        
                        
                        
                            armatureFrom = bpy.data.objects[sce.Armature_Target]
                            armatureTo = bpy.data.objects[sce.Armature_Target]

                            for boneTo in armatureTo.pose.bones:
                                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                                if boneFrom == None:
                                    continue

                                for con in boneTo.constraints:
                                    boneTo.constraints.remove(con)


                        
                        ##############New Rig Pose Copy
                        armatureFrom = bpy.data.objects["Your_Rig_Pose"]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)

                            copy_con = boneTo.constraints.new('COPY_TRANSFORMS')
                            copy_con.target = armatureFrom
                            copy_con.subtarget = boneFrom.name        
                            
                        
                        
                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects[sce.Armature_Target] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.armature_apply(selected=False)
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')


                    
                    
                    
                        armatureFrom = bpy.data.objects[sce.Armature_Target]
                        armatureTo = bpy.data.objects[sce.Armature_Target]

                        for boneTo in armatureTo.pose.bones:
                            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                            if boneFrom == None:
                                continue

                            for con in boneTo.constraints:
                                boneTo.constraints.remove(con)


                        
    
                        


                    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    
                    
                    
                    
                    objectToSelect2 = bpy.data.objects["RF_Rig"] 
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects["RF_Rig"] 
                    armature = ob.data
                    
                    bpy.ops.object.mode_set(mode='EDIT')
                    
                    


                    #/////IK #/////IK#/////IK



                    #////ik_hand_r
                    objectToSelect.data.edit_bones['ik_hand_r'].head_radius = objectToSelect2.data.edit_bones['ik_hand_r'].head_radius
                    objectToSelect.data.edit_bones['ik_hand_r'].tail[0] = objectToSelect2.data.edit_bones['ik_hand_r'].tail[0]
                    objectToSelect.data.edit_bones['ik_hand_r'].tail[1] = objectToSelect2.data.edit_bones['ik_hand_r'].tail[1]
                    objectToSelect.data.edit_bones['ik_hand_r'].tail[2] = objectToSelect2.data.edit_bones['ik_hand_r'].tail[2]
                    objectToSelect.data.edit_bones['ik_hand_r'].tail_radius = objectToSelect2.data.edit_bones['ik_hand_r'].tail_radius
                    objectToSelect.data.edit_bones['ik_hand_r'].roll = objectToSelect2.data.edit_bones['ik_hand_r'].roll
                    objectToSelect.data.edit_bones['ik_hand_r'].length = objectToSelect2.data.edit_bones['ik_hand_r'].length
                    objectToSelect.data.edit_bones['ik_hand_r'].envelope_distance = objectToSelect2.data.edit_bones['ik_hand_r'].envelope_distance





                    #////ik_hand_l
                    objectToSelect.data.edit_bones['ik_hand_l'].head_radius = objectToSelect2.data.edit_bones['ik_hand_l'].head_radius
                    objectToSelect.data.edit_bones['ik_hand_l'].tail[0] = objectToSelect2.data.edit_bones['ik_hand_l'].tail[0]
                    objectToSelect.data.edit_bones['ik_hand_l'].tail[1] = objectToSelect2.data.edit_bones['ik_hand_l'].tail[1]
                    objectToSelect.data.edit_bones['ik_hand_l'].tail[2] = objectToSelect2.data.edit_bones['ik_hand_l'].tail[2]
                    objectToSelect.data.edit_bones['ik_hand_l'].tail_radius = objectToSelect2.data.edit_bones['ik_hand_l'].tail_radius
                    objectToSelect.data.edit_bones['ik_hand_l'].roll = objectToSelect2.data.edit_bones['ik_hand_l'].roll
                    objectToSelect.data.edit_bones['ik_hand_l'].length = objectToSelect2.data.edit_bones['ik_hand_l'].length
                    objectToSelect.data.edit_bones['ik_hand_l'].envelope_distance = objectToSelect2.data.edit_bones['ik_hand_l'].envelope_distance




                    #////ik_hand_gun
                    objectToSelect.data.edit_bones['ik_hand_gun'].head_radius = objectToSelect2.data.edit_bones['ik_hand_gun'].head_radius
                    objectToSelect.data.edit_bones['ik_hand_gun'].tail[0] = objectToSelect2.data.edit_bones['ik_hand_gun'].tail[0]
                    objectToSelect.data.edit_bones['ik_hand_gun'].tail[1] = objectToSelect2.data.edit_bones['ik_hand_gun'].tail[1]
                    objectToSelect.data.edit_bones['ik_hand_gun'].tail[2] = objectToSelect2.data.edit_bones['ik_hand_gun'].tail[2]
                    objectToSelect.data.edit_bones['ik_hand_gun'].tail_radius = objectToSelect2.data.edit_bones['ik_hand_gun'].tail_radius
                    objectToSelect.data.edit_bones['ik_hand_gun'].roll = objectToSelect2.data.edit_bones['ik_hand_gun'].roll
                    objectToSelect.data.edit_bones['ik_hand_gun'].length = objectToSelect2.data.edit_bones['ik_hand_gun'].length
                    objectToSelect.data.edit_bones['ik_hand_gun'].envelope_distance = objectToSelect2.data.edit_bones['ik_hand_gun'].envelope_distance





                    #////ik_hand_root
                    objectToSelect.data.edit_bones['ik_hand_root'].head_radius = objectToSelect2.data.edit_bones['ik_hand_root'].head_radius
                    objectToSelect.data.edit_bones['ik_hand_root'].tail[0] = objectToSelect2.data.edit_bones['ik_hand_root'].tail[0]
                    objectToSelect.data.edit_bones['ik_hand_root'].tail[1] = objectToSelect2.data.edit_bones['ik_hand_root'].tail[1]
                    objectToSelect.data.edit_bones['ik_hand_root'].tail[2] = objectToSelect2.data.edit_bones['ik_hand_root'].tail[2]
                    objectToSelect.data.edit_bones['ik_hand_root'].tail_radius = objectToSelect2.data.edit_bones['ik_hand_root'].tail_radius
                    objectToSelect.data.edit_bones['ik_hand_root'].roll = objectToSelect2.data.edit_bones['ik_hand_root'].roll
                    objectToSelect.data.edit_bones['ik_hand_root'].length = objectToSelect2.data.edit_bones['ik_hand_root'].length
                    objectToSelect.data.edit_bones['ik_hand_root'].envelope_distance = objectToSelect2.data.edit_bones['ik_hand_root'].envelope_distance




                    #////ik_foot_l
                    objectToSelect.data.edit_bones['ik_foot_l'].head_radius = objectToSelect2.data.edit_bones['ik_foot_l'].head_radius
                    objectToSelect.data.edit_bones['ik_foot_l'].tail[0] = objectToSelect2.data.edit_bones['ik_foot_l'].tail[0]
                    objectToSelect.data.edit_bones['ik_foot_l'].tail[1] = objectToSelect2.data.edit_bones['ik_foot_l'].tail[1]
                    objectToSelect.data.edit_bones['ik_foot_l'].tail[2] = objectToSelect2.data.edit_bones['ik_foot_l'].tail[2]
                    objectToSelect.data.edit_bones['ik_foot_l'].tail_radius = objectToSelect2.data.edit_bones['ik_foot_l'].tail_radius
                    objectToSelect.data.edit_bones['ik_foot_l'].roll = objectToSelect2.data.edit_bones['ik_foot_l'].roll
                    objectToSelect.data.edit_bones['ik_foot_l'].length = objectToSelect2.data.edit_bones['ik_foot_l'].length
                    objectToSelect.data.edit_bones['ik_foot_l'].envelope_distance = objectToSelect2.data.edit_bones['ik_foot_l'].envelope_distance





                    #////ik_foot_l
                    objectToSelect.data.edit_bones['ik_foot_r'].head_radius = objectToSelect2.data.edit_bones['ik_foot_r'].head_radius
                    objectToSelect.data.edit_bones['ik_foot_r'].tail[0] = objectToSelect2.data.edit_bones['ik_foot_r'].tail[0]
                    objectToSelect.data.edit_bones['ik_foot_r'].tail[1] = objectToSelect2.data.edit_bones['ik_foot_r'].tail[1]
                    objectToSelect.data.edit_bones['ik_foot_r'].tail[2] = objectToSelect2.data.edit_bones['ik_foot_r'].tail[2]
                    objectToSelect.data.edit_bones['ik_foot_r'].tail_radius = objectToSelect2.data.edit_bones['ik_foot_r'].tail_radius
                    objectToSelect.data.edit_bones['ik_foot_r'].roll = objectToSelect2.data.edit_bones['ik_foot_r'].roll
                    objectToSelect.data.edit_bones['ik_foot_r'].length = objectToSelect2.data.edit_bones['ik_foot_r'].length
                    objectToSelect.data.edit_bones['ik_foot_r'].envelope_distance = objectToSelect2.data.edit_bones['ik_foot_r'].envelope_distance



                    #////ik_foot_l
                    objectToSelect.data.edit_bones['ik_foot_root'].head_radius = objectToSelect2.data.edit_bones['ik_foot_root'].head_radius
                    objectToSelect.data.edit_bones['ik_foot_root'].tail[0] = objectToSelect2.data.edit_bones['ik_foot_root'].tail[0]
                    objectToSelect.data.edit_bones['ik_foot_root'].tail[1] = objectToSelect2.data.edit_bones['ik_foot_root'].tail[1]
                    objectToSelect.data.edit_bones['ik_foot_root'].tail[2] = objectToSelect2.data.edit_bones['ik_foot_root'].tail[2]
                    objectToSelect.data.edit_bones['ik_foot_root'].tail_radius = objectToSelect2.data.edit_bones['ik_foot_root'].tail_radius
                    objectToSelect.data.edit_bones['ik_foot_root'].roll = objectToSelect2.data.edit_bones['ik_foot_root'].roll
                    objectToSelect.data.edit_bones['ik_foot_root'].length = objectToSelect2.data.edit_bones['ik_foot_root'].length
                    objectToSelect.data.edit_bones['ik_foot_root'].envelope_distance = objectToSelect2.data.edit_bones['ik_foot_root'].envelope_distance




                    #////ik_foot_l
                    objectToSelect.data.edit_bones['center_of_mass'].head_radius = objectToSelect2.data.edit_bones['center_of_mass'].head_radius
                    objectToSelect.data.edit_bones['center_of_mass'].tail[0] = objectToSelect2.data.edit_bones['center_of_mass'].tail[0]
                    objectToSelect.data.edit_bones['center_of_mass'].tail[1] = objectToSelect2.data.edit_bones['center_of_mass'].tail[1]
                    objectToSelect.data.edit_bones['center_of_mass'].tail[2] = objectToSelect2.data.edit_bones['center_of_mass'].tail[2]
                    objectToSelect.data.edit_bones['center_of_mass'].tail_radius = objectToSelect2.data.edit_bones['center_of_mass'].tail_radius
                    objectToSelect.data.edit_bones['center_of_mass'].roll = objectToSelect2.data.edit_bones['center_of_mass'].roll
                    objectToSelect.data.edit_bones['center_of_mass'].length = objectToSelect2.data.edit_bones['center_of_mass'].length
                    objectToSelect.data.edit_bones['center_of_mass'].envelope_distance = objectToSelect2.data.edit_bones['center_of_mass'].envelope_distance



                    #////ik_foot_l
                    objectToSelect.data.edit_bones['interaction'].head_radius = objectToSelect2.data.edit_bones['interaction'].head_radius
                    objectToSelect.data.edit_bones['interaction'].tail[0] = objectToSelect2.data.edit_bones['interaction'].tail[0]
                    objectToSelect.data.edit_bones['interaction'].tail[1] = objectToSelect2.data.edit_bones['interaction'].tail[1]
                    objectToSelect.data.edit_bones['interaction'].tail[2] = objectToSelect2.data.edit_bones['interaction'].tail[2]
                    objectToSelect.data.edit_bones['interaction'].tail_radius = objectToSelect2.data.edit_bones['interaction'].tail_radius
                    objectToSelect.data.edit_bones['interaction'].roll = objectToSelect2.data.edit_bones['interaction'].roll
                    objectToSelect.data.edit_bones['interaction'].length = objectToSelect2.data.edit_bones['interaction'].length
                    objectToSelect.data.edit_bones['interaction'].envelope_distance = objectToSelect2.data.edit_bones['interaction'].envelope_distance



                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





    

                    ############# ik foot  rot to foot  and hands to hands


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones['foot_l']
                    myBone2 = armature.edit_bones['ik_foot_l']
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.pose.constraint_add_with_targets(type='COPY_ROTATION')
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones['foot_r']
                    myBone2 = armature.edit_bones['ik_foot_r']
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.pose.constraint_add_with_targets(type='COPY_ROTATION')
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones['hand_r']
                    myBone2 = armature.edit_bones['ik_hand_gun']
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.pose.constraint_add_with_targets(type='COPY_ROTATION')
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')

                    



                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones['hand_r']
                    myBone2 = armature.edit_bones['ik_hand_r']
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.pose.constraint_add_with_targets(type='COPY_ROTATION')
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')




                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones['hand_l']
                    myBone2 = armature.edit_bones['ik_hand_l']
                    myBone.select = True
                    myBone2.select = True
                    armature.edit_bones.active = myBone2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.pose.constraint_add_with_targets(type='COPY_ROTATION')
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects[sce.Armature_Target] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')


                    armatureFrom = bpy.data.objects[sce.Armature_Target]
                    armatureTo = bpy.data.objects[sce.Armature_Target]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)


                    





                        








                

                    # ########     Setup ///////////////////////////////////////////////////////////////  Setup ///////////////////// Setup ///////////////////// Setup//////////

                





        
                    
                    
                    #//////////////////////////////////////////////


                    objects = bpy.context.scene.objects.keys()
                    if  'RF_To_Ues_PosMatching' in objects:
                        
                        bpy.ops.headrotof.myop_operator()
    


                    bpy.ops.object.select_all(action='DESELECT')
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    arm = bpy.data.objects[sce.Armature_Target]


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ball_l")
                    if  bonein is not None:
                        arm.data.edit_bones['ball_l'].parent = arm.data.edit_bones['foot_l']

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ball_l")
                    if  bonein is not None:
                        arm.data.edit_bones['foot_l'].parent = arm.data.edit_bones['calf_l']

                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_01_l")
                    if  bonein is not None:
                        arm.data.edit_bones['calf_twist_01_l'].parent = arm.data.edit_bones['calf_l']

                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_02_l")
                    if  bonein is not None:
                        arm.data.edit_bones['calf_twist_02_l'].parent = arm.data.edit_bones['calf_l']
                    

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_l")
                    if  bonein is not None:
                        arm.data.edit_bones['calf_l'].parent = arm.data.edit_bones['thigh_l']

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_02_l")
                    if  bonein is not None:
                        arm.data.edit_bones['thigh_twist_02_l'].parent = arm.data.edit_bones['thigh_l']
                        
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_01_l")
                    if  bonein is not None:
                        arm.data.edit_bones['thigh_twist_01_l'].parent = arm.data.edit_bones['thigh_l']
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_l")
                    if  bonein is not None:
                        arm.data.edit_bones['thigh_l'].parent = arm.data.edit_bones['pelvis']
                        
        
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("hand_l")
                    if  bonein is not None:
                
                        arm.data.edit_bones['hand_l'].parent = arm.data.edit_bones['lowerarm_l']
                

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_01_l")
                    if  bonein is not None:
                        
                        arm.data.edit_bones['lowerarm_twist_01_l'].parent = arm.data.edit_bones['lowerarm_l']

        

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_02_l")
                    if  bonein is not None:
                        arm.data.edit_bones['lowerarm_twist_02_l'].parent = arm.data.edit_bones['lowerarm_l']




                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_l")
                    if  bonein is not None:
                        arm.data.edit_bones['lowerarm_l'].parent = arm.data.edit_bones['upperarm_l']

        

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_l")
                    if  bonein is not None:
                        arm.data.edit_bones['upperarm_twist_02_l'].parent = arm.data.edit_bones['upperarm_l']

                

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_01_l")
                    if  bonein is not None:
                        arm.data.edit_bones['upperarm_twist_01_l'].parent = arm.data.edit_bones['upperarm_l']
                        
                        


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_l")
                    if  bonein is not None:
                        arm.data.edit_bones['upperarm_l'].parent = arm.data.edit_bones['clavicle_l']

                        

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("clavicle_l")
                    if  bonein is not None:
                        
                        arm.data.edit_bones['clavicle_l'].parent = arm.data.edit_bones['spine_05']




                        

                    
                    #RRRRRR

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ball_r")
                    if  bonein is not None:
                        arm.data.edit_bones['ball_r'].parent = arm.data.edit_bones['foot_r']

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("foot_r")
                    if  bonein is not None:
                        arm.data.edit_bones['foot_r'].parent = arm.data.edit_bones['calf_r']

                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_01_r")
                    if  bonein is not None:
                        arm.data.edit_bones['calf_twist_01_r'].parent = arm.data.edit_bones['calf_r']

                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_twist_02_r")
                    if  bonein is not None:
                        arm.data.edit_bones['calf_twist_02_r'].parent = arm.data.edit_bones['calf_r']
                    

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("calf_r")
                    if  bonein is not None:
                        arm.data.edit_bones['calf_r'].parent = arm.data.edit_bones['thigh_r']

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_02_r")
                    if  bonein is not None:
                        arm.data.edit_bones['thigh_twist_02_r'].parent = arm.data.edit_bones['thigh_r']
                        
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_twist_01_r")
                    if  bonein is not None:
                        arm.data.edit_bones['thigh_twist_01_r'].parent = arm.data.edit_bones['thigh_r']
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thigh_r")
                    if  bonein is not None:
                        arm.data.edit_bones['thigh_r'].parent = arm.data.edit_bones['pelvis']
                        
        
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("hand_r")
                    if  bonein is not None:
                
                        arm.data.edit_bones['hand_r'].parent = arm.data.edit_bones['lowerarm_r']
                

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_01_r")
                    if  bonein is not None:
                        
                        arm.data.edit_bones['lowerarm_twist_01_r'].parent = arm.data.edit_bones['lowerarm_r']

        

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_twist_02_r")
                    if  bonein is not None:
                        arm.data.edit_bones['lowerarm_twist_02_r'].parent = arm.data.edit_bones['lowerarm_r']




                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("lowerarm_r")
                    if  bonein is not None:
                        arm.data.edit_bones['lowerarm_r'].parent = arm.data.edit_bones['upperarm_r']

        

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_02_r")
                    if  bonein is not None:
                        arm.data.edit_bones['upperarm_twist_02_r'].parent = arm.data.edit_bones['upperarm_r']

                

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_twist_01_r")
                    if  bonein is not None:
                        arm.data.edit_bones['upperarm_twist_01_r'].parent = arm.data.edit_bones['upperarm_r']
                        
                        


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("upperarm_r")
                    if  bonein is not None:
                        arm.data.edit_bones['upperarm_r'].parent = arm.data.edit_bones['clavicle_r']

                        

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("clavicle_r")
                    if  bonein is not None:
                        
                        arm.data.edit_bones['clavicle_r'].parent = arm.data.edit_bones['spine_05']


                    #///Spine//////////
                    arm.data.edit_bones['head'].parent = arm.data.edit_bones['neck_02']
                    arm.data.edit_bones['neck_02'].parent = arm.data.edit_bones['neck_01']
                    arm.data.edit_bones['neck_01'].parent = arm.data.edit_bones['spine_05']
                    arm.data.edit_bones['spine_05'].parent = arm.data.edit_bones['spine_04']
                    arm.data.edit_bones['spine_04'].parent = arm.data.edit_bones['spine_03']
                    arm.data.edit_bones['spine_03'].parent = arm.data.edit_bones['spine_02']
                    arm.data.edit_bones['spine_02'].parent = arm.data.edit_bones['spine_01']
                    arm.data.edit_bones['spine_01'].parent = arm.data.edit_bones['pelvis']
                

                    ###Fingers_l
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("index_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['index_metacarpal_l'].parent = arm.data.edit_bones['hand_l']

                    

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['middle_metacarpal_l'].parent = arm.data.edit_bones['hand_l']

                    

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['ring_metacarpal_l'].parent = arm.data.edit_bones['hand_l']
                    
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['pinky_metacarpal_l'].parent = arm.data.edit_bones['hand_l']


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thumb_03_l")
                    if  bonein is not None:

                        arm.data.edit_bones['thumb_03_l'].parent = arm.data.edit_bones['thumb_02_l']
                        arm.data.edit_bones['thumb_02_l'].parent = arm.data.edit_bones['thumb_01_l']
                        arm.data.edit_bones['thumb_01_l'].parent = arm.data.edit_bones['hand_l']



                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("index_03_l")
                    if  bonein is not None:

                        arm.data.edit_bones['index_03_l'].parent = arm.data.edit_bones['index_02_l']
                        arm.data.edit_bones['index_02_l'].parent = arm.data.edit_bones['index_01_l']
                        

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("index_metacarpal_l")
                    if  bonein is not None:  
                        
                        arm.data.edit_bones['index_01_l'].parent = arm.data.edit_bones['index_metacarpal_l']      

                        
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_03_l")
                    if  bonein is not None:

                        arm.data.edit_bones['middle_03_l'].parent = arm.data.edit_bones['middle_02_l']
                        arm.data.edit_bones['middle_02_l'].parent = arm.data.edit_bones['middle_01_l']
                        
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['middle_01_l'].parent = arm.data.edit_bones['middle_metacarpal_l']


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_03_l")
                    if  bonein is not None:

                        arm.data.edit_bones['ring_03_l'].parent = arm.data.edit_bones['ring_02_l']
                        arm.data.edit_bones['ring_02_l'].parent = arm.data.edit_bones['ring_01_l']


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_metacarpal_l")
                    if  bonein is not None:
                        
                        arm.data.edit_bones['ring_01_l'].parent = arm.data.edit_bones['ring_metacarpal_l']
    
                
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_03_l")
                    if  bonein is not None:
                        arm.data.edit_bones['pinky_03_l'].parent = arm.data.edit_bones['pinky_02_l']
                        arm.data.edit_bones['pinky_02_l'].parent = arm.data.edit_bones['pinky_01_l']


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['pinky_01_l'].parent = arm.data.edit_bones['pinky_metacarpal_l']

    


                ###Fingers_r

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("index_metacarpal_r")
                    if  bonein is not None:
                        arm.data.edit_bones['index_metacarpal_r'].parent = arm.data.edit_bones['hand_r']

                    

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['middle_metacarpal_r'].parent = arm.data.edit_bones['hand_r']

                    

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['ring_metacarpal_r'].parent = arm.data.edit_bones['hand_r']
                    
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['pinky_metacarpal_r'].parent = arm.data.edit_bones['hand_r']


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thumb_03_l")
                    if  bonein is not None:

                        arm.data.edit_bones['thumb_03_r'].parent = arm.data.edit_bones['thumb_02_r']
                        arm.data.edit_bones['thumb_02_r'].parent = arm.data.edit_bones['thumb_01_r']
                        arm.data.edit_bones['thumb_01_r'].parent = arm.data.edit_bones['hand_r']



                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("index_03_l")
                    if  bonein is not None:

                        arm.data.edit_bones['index_03_r'].parent = arm.data.edit_bones['index_02_r']
                        arm.data.edit_bones['index_02_r'].parent = arm.data.edit_bones['index_01_r']
                        

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("index_metacarpal_r")
                    if  bonein is not None:  
                        
                        arm.data.edit_bones['index_01_r'].parent = arm.data.edit_bones['index_metacarpal_r']      

                        
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_03_l")
                    if  bonein is not None:

                        arm.data.edit_bones['middle_03_r'].parent = arm.data.edit_bones['middle_02_r']
                        arm.data.edit_bones['middle_02_r'].parent = arm.data.edit_bones['middle_01_r']
                        
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['middle_01_r'].parent = arm.data.edit_bones['middle_metacarpal_r']


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_03_l")
                    if  bonein is not None:

                        arm.data.edit_bones['ring_03_r'].parent = arm.data.edit_bones['ring_02_r']
                        arm.data.edit_bones['ring_02_r'].parent = arm.data.edit_bones['ring_01_r']


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_metacarpal_l")
                    if  bonein is not None:
                        
                        arm.data.edit_bones['ring_01_r'].parent = arm.data.edit_bones['ring_metacarpal_r']
    
                
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_03_l")
                    if  bonein is not None:
                        arm.data.edit_bones['pinky_03_r'].parent = arm.data.edit_bones['pinky_02_r']
                        arm.data.edit_bones['pinky_02_r'].parent = arm.data.edit_bones['pinky_01_r']


                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_metacarpal_l")
                    if  bonein is not None:
                        arm.data.edit_bones['pinky_01_r'].parent = arm.data.edit_bones['pinky_metacarpal_r']
        


                    #////IK
                    
                    arm.data.edit_bones['ik_hand_l'].parent = arm.data.edit_bones['ik_hand_gun']
                    arm.data.edit_bones['ik_hand_r'].parent = arm.data.edit_bones['ik_hand_gun']
                    arm.data.edit_bones['ik_hand_gun'].parent = arm.data.edit_bones['ik_hand_root']
                    arm.data.edit_bones['ik_foot_l'].parent = arm.data.edit_bones['ik_foot_root']
                    arm.data.edit_bones['ik_foot_r'].parent = arm.data.edit_bones['ik_foot_root']


                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')
    

                

                    # /////////////delete Bones RF
                    bpy.ops.object.select_all(action='DESELECT')
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')

                    ob = bpy.context.object
                    assert ob.type == 'ARMATURE'
                    arma = ob.data
                    bpy.ops.object.mode_set(mode='EDIT') # ensure edit mode
                    bpy.ops.armature.select_all(action='DESELECT')
                
                    bpy.context.window_manager.progress_update(70.0)
                    
                    bone = arma.edit_bones['DEF-fix-foot.L']
                    arma.edit_bones.remove(bone)
                
                    bone = arma.edit_bones['DEF-fix-foot.R']
                    arma.edit_bones.remove(bone)

                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("Fix_clavicle_l")
                    if  bonein is not None:
                        
                   
                   
                        bone = arma.edit_bones['Fix_clavicle_l']
                        arma.edit_bones.remove(bone)

                        bone = arma.edit_bones['Fix_clavicle_r']
                        arma.edit_bones.remove(bone)

                    bone = arma.edit_bones['arm_rfbone_l']
                    arma.edit_bones.remove(bone)

                    bone = arma.edit_bones['arm_rfbone_r']
                    arma.edit_bones.remove(bone)
                    
                    bonein =bpy.data.objects[sce.Armature_Target].data.bones.get("thumb_Fix_r")
                    bonein2 =bpy.data.objects[sce.Armature_Target].data.bones.get("thumb_Fix_l")
                    if  bonein is not None and bonein2 is not None:

                        bone = arma.edit_bones['thumb_Fix_r']
                        arma.edit_bones.remove(bone)

                        bone = arma.edit_bones['thumb_Fix_l']
                        arma.edit_bones.remove(bone)

                    

                    
                    bonein9 =bpy.data.objects[sce.Armature_Target].data.bones.get("ball_BoneFix_l")
                    if  bonein9 is not None:

                        bone = arma.edit_bones['ball_BoneFix_l']
                        arma.edit_bones.remove(bone)
                    
                    bonein8 =bpy.data.objects[sce.Armature_Target].data.bones.get("ball_BoneFix_r")
                    if  bonein8 is not None:

                        bone = arma.edit_bones['ball_BoneFix_r']
                        arma.edit_bones.remove(bone)
                

                    


                    bone = arma.edit_bones['leg_rfbone_l']
                    arma.edit_bones.remove(bone)

                    bone = arma.edit_bones['leg_rfbone_r']
                    arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_01_rfbone_l")
                    if bonein1 is not None : 
                        bone = arma.edit_bones['middle_01_rfbone_l']
                        arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("middle_01_rfbone_r")
                    if bonein1 is not None : 
                        bone = arma.edit_bones['middle_01_rfbone_r']
                        arma.edit_bones.remove(bone)
                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("index_01_rfbone_r")
                    if bonein1 is not None :

                        bone = arma.edit_bones['index_01_rfbone_r']
                        arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("index_01_rfbone_l")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['index_01_rfbone_l']
                        arma.edit_bones.remove(bone)
                    
                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_01_rfbone_l")
                    if bonein1 is not None :

                        bone = arma.edit_bones['pinky_01_rfbone_l']
                        arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("pinky_01_rfbone_r")
                    if bonein1 is not None :
                
                
                        bone = arma.edit_bones['pinky_01_rfbone_r']
                        arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_01_rfbone_l")
                    if bonein1 is not None :

                        bone = arma.edit_bones['ring_01_rfbone_l']
                        arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("ring_01_rfbone_r")
                    if bonein1 is not None :

                        bone = arma.edit_bones['ring_01_rfbone_r']
                        arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("thumb_01_rfbone_l")
                    if bonein1 is not None :
                


                        bone = arma.edit_bones['thumb_01_rfbone_l']
                        arma.edit_bones.remove(bone)

                    bonein1 =bpy.data.objects[sce.Armature_Target].data.bones.get("thumb_01_rfbone_r")
                    if bonein1 is not None :
                    
                        bone = arma.edit_bones['thumb_01_rfbone_r']
                        arma.edit_bones.remove(bone)


                    bone = arma.edit_bones['spine_BoneFix_r']
                    arma.edit_bones.remove(bone)


                



                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')
                            
                
                
                
                
                
                
                
                    bpy.ops.object.select_all(action='DESELECT')





                    objects = bpy.context.scene.objects.keys()
                    if  'Your_Rig_Pose' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["Your_Rig_Pose"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT') 



                     


                    objects = bpy.context.scene.objects.keys()
                    if  'RF_To_Ues_PosMatching' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["RF_To_Ues_PosMatching"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')




                    objects = bpy.context.scene.objects.keys()
                    if  'AU5Clavicle_PosMatching_On' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["AU5Clavicle_PosMatching_On"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')        


                    objects = bpy.context.scene.objects.keys()
                    if  'AU5Foot_PosMatching_On' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["AU5Foot_PosMatching_On"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT') 



                    objects = bpy.context.scene.objects.keys()
                    if  'AU5FootRoto_PosMatching_On' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["AU5FootRoto_PosMatching_On"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT') 



                    objects = bpy.context.scene.objects.keys()
                    if  'Rig_AutoMatchingRF' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["Rig_AutoMatchingRF"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')




                    objects = bpy.context.scene.objects.keys()
                    if  'ARSP_RFAR' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["ARSP_RFAR"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')



                    objects = bpy.context.scene.objects.keys()
                    if  'RF_fixSpines_AR' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["RF_fixSpines_AR"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')



                    objects = bpy.context.scene.objects.keys()
                    if  'spinefix_ar' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["spinefix_ar"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')



                    objects = bpy.context.scene.objects.keys()
                    if  'ARSP_RFAR2' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["ARSP_RFAR2"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')

                    objects = bpy.context.scene.objects.keys()
                    if  'fingers_RFAR' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["fingers_RFAR"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')


                    objects = bpy.context.scene.objects.keys()
                    if  'RF_clav_A' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["RF_clav_A"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)
                        bpy.ops.object.select_all(action='DESELECT')









                    ##Unlock all bones
                    ##Rest in pose mode and Unlock all bones
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.posemode_toggle()
                    bpy.ops.pose.select_all(action='SELECT')
                    for b in bpy.context.active_object.pose.bones:
                        b.lock_location[0] = False # x
                        b.lock_location[1] = False # y
                        b.lock_location[2] = False # z
                        
                        b.lock_rotation[0] = False # x
                        b.lock_rotation[1] = False # y
                        b.lock_rotation[2] = False # z
                        
                        
                        b.lock_scale[0] = False # x
                        b.lock_scale[1] = False # y
                        b.lock_scale[2] = False # z
                    bpy.ops.pose.rot_clear()
                    bpy.ops.pose.loc_clear()
                    bpy.ops.object.mode_set(mode='OBJECT')





                    #Naming
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects[sce.Armature_Target] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect



                    for obj in bpy.context.selected_objects:
                        obj.name = "root"
                        obj.data.name = "root" 

                

                    bpy.ops.view3d.snap_cursor_to_center()
            
                     
                    objectToSelect = bpy.data.objects["root"] 
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    armature = bpy.context.active_object.data

                    # Iterate through all bones in the armature unhide all bones
                    for bone in armature.bones:
                        bone.hide = False

                    
                    


                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')
                    
                    
                    

                    if mytool.Parent_toheadb !=False : 
                    
                    
                        # Get the active armature object
                        armature_obj = bpy.context.active_object

                        # Check if the active object is an armature
                        if armature_obj and armature_obj.type == 'ARMATURE':
                            # Get the pose bone named "Bone1"
                            parent_bone_name = "head"
                            parent_bone = armature_obj.pose.bones.get(parent_bone_name)
                            
                            if parent_bone:
                                # Select all child bones of Bone1 and their descendants
                                selected_bones = set()
                                stack = [parent_bone]

                                while stack:
                                    current_bone = stack.pop()
                                    selected_bones.add(current_bone.bone)

                                    # Add child bones to the stack
                                    stack.extend(child for child in armature_obj.pose.bones
                                                if child.bone.parent == current_bone.bone)

                                # Select the bones
                                for bone in selected_bones:
                                    bone.select = True
                        





                        # Switch to Edit Mode
                        bpy.ops.object.mode_set(mode='EDIT')
                        
                        # Get the active armature object
                        armature_obj = bpy.context.active_object

                        # Check if the active object is an armature
                        if armature_obj and armature_obj.type == 'ARMATURE':
                            # Get the selected bones
                            selected_bones = [bone for bone in armature_obj.data.edit_bones if bone.select]

                            # Get the bone named "Bone1"
                            parent_bone_name = "head"
                            parent_bone = armature_obj.data.edit_bones.get(parent_bone_name)

                            if parent_bone:
                                # Parent each selected bone to "Bone1"
                                for bone in selected_bones:
                                    bone.parent = parent_bone
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')



                    



                     
                    
                    if mytool.auto_spineuevc !=False :
                        bpy.ops.spine.my_opuev()
                    
                    
                     
                    
                    if mytool.my_bool33 !=False :

                        
                        bpy.ops.animrigin.myop_operator()

                    if mytool.auto_uepos !=False :

                    
                        bpy.ops.posem.pu_operator()
                        
                        if mytool.my_bool33 !=False :
                            bpy.ops.animwopse.myop_operator()
                    
                    
                    if mytool.ueposea_anpose !=False and mytool.auto_uepos ==False :

                    
                        bpy.ops.animposeo.m_operator()
                    
                    hiderigs()



                    
            

                    
                    
        
    





                    

                    
                    
                    #bpy.ops.autoscaleroot.myop_operator()

                    #bpy.ops.autoscale.myop_operator()
                    if mytool.my_bool33 ==False :
                        
                        if mytool.my_string54 !=False :

                            bpy.ops.fixtwistoback.myop_operator()
                            print("ff")
                        
                        objects = bpy.context.scene.objects.keys()
                        if  'RF_Rig' in objects:

                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["RF_Rig"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.context.object.hide_viewport = False
                            bpy.context.object.hide_render = False
                            bpy.context.object.hide_set(False)
                            bpy.context.object.hide_select = False
                            
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["RF_Rig"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.ops.object.delete(use_global=False) 
                        
                        objects = bpy.context.scene.objects.keys()
                        if  'Rig_AnimRF_Fix' in objects:

                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["Rig_AnimRF_Fix"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.context.object.hide_viewport = False
                            bpy.context.object.hide_render = False
                            bpy.context.object.hide_set(False)
                            bpy.context.object.hide_select = False
                            
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["Rig_AnimRF_Fix"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.ops.object.delete(use_global=False)  
                    
                        objects = bpy.context.scene.objects.keys()
                        if  'Rig_AnimRF' in objects:

                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["Rig_AnimRF"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.context.object.hide_viewport = False
                            bpy.context.object.hide_render = False
                            bpy.context.object.hide_set(False)
                            bpy.context.object.hide_select = False
                            
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["Rig_AnimRF"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.ops.object.delete(use_global=False) 
                    
                    
                        objects = bpy.context.scene.objects.keys()
                        if  'RF_For_Animation' in objects:
                            
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["RF_For_Animation"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.context.object.hide_viewport = False
                            bpy.context.object.hide_render = False
                            bpy.context.object.hide_set(False)
                            bpy.context.object.hide_select = False
                            
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["RF_For_Animation"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.ops.object.delete(use_global=False)
                    
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        objects = bpy.context.scene.objects.keys()
                        if  'RF_Anime_' in objects:

                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["RF_Anime_"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.context.object.hide_viewport = False
                            bpy.context.object.hide_render = False
                            bpy.context.object.hide_set(False)
                            bpy.context.object.hide_select = False
                            
                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["RF_Anime_"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            bpy.ops.object.delete(use_global=False)
                    
                    
                    objects = bpy.context.scene.objects.keys()
                    if  'Fingers_Direction' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.context.object.hide_viewport = False
                        bpy.context.object.hide_render = False
                        bpy.context.object.hide_set(False)
                        bpy.context.object.hide_select = False
                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["Fingers_Direction"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)



                    objects = bpy.context.scene.objects.keys()
                    if  'use only scale to Align character feet with the ground' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["use only scale to Align character feet with the ground"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.context.object.hide_viewport = False
                        bpy.context.object.hide_render = False
                        bpy.context.object.hide_set(False)
                        bpy.context.object.hide_select = False
                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["use only scale to Align character feet with the ground"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)

                    
                    
                    
                    objects = bpy.context.scene.objects.keys()
                    if  'UE5_Character_Scale_RF' in objects:

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["UE5_Character_Scale_RF"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.context.object.hide_viewport = False
                        bpy.context.object.hide_render = False
                        bpy.context.object.hide_set(False)
                        bpy.context.object.hide_select = False
                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["UE5_Character_Scale_RF"]
                        objectToSelect2.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False) 


                    if sce.bone_target66 !="" :
                        bpy.ops.delettem.myop_operator() 
                         



                    
        
                    if mytool.my_enumar == 'OP13' :

                        bpy.ops.dazappl.myop_operator() 
        
                     
                    
                    
                    
                    if mytool.my_enumar == 'OP14' or mytool.my_enumar == 'OP6'or mytool.my_enumar == 'OP13'or mytool.my_enumar == 'OP18' or mytool.my_enumar == 'OP20':  

    
                        
                        # Clear existing selections
                        bpy.ops.object.select_all(action='DESELECT')

                        # List to store selected mesh objects
                        selected_objects = []

                        # Iterate through all objects in the scene
                        for obj in bpy.context.scene.objects:
                            # Check if the object is a mesh
                            if obj.type == 'MESH':
                                # Check if the object has a parent that is an armature
                                if obj.parent and obj.parent.type == 'ARMATURE':
                                    obj.select_set(True)
                                    selected_objects.append(obj)
                                # Check if the object has an Armature modifier
                                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                                    obj.select_set(True)
                                    selected_objects.append(obj)

                        # Check if there are selected objects to join
                        if selected_objects:
                            # Set the active object to the first selected object
                            bpy.context.view_layer.objects.active = selected_objects[0]

                            # Iterate over each selected object
                            for obj in selected_objects:
                                # Get the vertex groups
                                vg1 = obj.vertex_groups.get("r_metatarsal")
                                vg2 = obj.vertex_groups.get("foot_r")

                                if not vg1 or not vg2:
                                    print(f"One or both vertex groups do not exist in object {obj.name}.")
                                    continue
                                
                                # Iterate through each vertex in the object
                                for v in obj.data.vertices:
                                    for g in v.groups:
                                        if g.group == vg1.index:
                                            # Get current weight in vg2 (if exists)
                                            current_weight = 0
                                            for g2 in v.groups:
                                                if g2.group == vg2.index:
                                                    current_weight = g2.weight
                                                    break
                                            # Add the weight from vg1 to vg2
                                            new_weight = current_weight + g.weight
                                            vg2.add([v.index], new_weight, 'REPLACE')

                            print("Vertices from 'bone1' added to 'bone2' for all selected objects.")
                        
                        
                        
                        # Clear existing selections
                        bpy.ops.object.select_all(action='DESELECT')

                        # List to store selected mesh objects
                        selected_objects = []

                        # Iterate through all objects in the scene
                        for obj in bpy.context.scene.objects:
                            # Check if the object is a mesh
                            if obj.type == 'MESH':
                                # Check if the object has a parent that is an armature
                                if obj.parent and obj.parent.type == 'ARMATURE':
                                    obj.select_set(True)
                                    selected_objects.append(obj)
                                # Check if the object has an Armature modifier
                                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                                    obj.select_set(True)
                                    selected_objects.append(obj)

                        # Check if there are selected objects to join
                        if selected_objects:
                            # Set the active object to the first selected object
                            bpy.context.view_layer.objects.active = selected_objects[0]

                            # Iterate over each selected object
                            for obj in selected_objects:
                                # Get the vertex groups
                                vg1 = obj.vertex_groups.get("l_metatarsal")
                                vg2 = obj.vertex_groups.get("foot_l")

                                if not vg1 or not vg2:
                                    print(f"One or both vertex groups do not exist in object {obj.name}.")
                                    continue
                                
                                # Iterate through each vertex in the object
                                for v in obj.data.vertices:
                                    for g in v.groups:
                                        if g.group == vg1.index:
                                            # Get current weight in vg2 (if exists)
                                            current_weight = 0
                                            for g2 in v.groups:
                                                if g2.group == vg2.index:
                                                    current_weight = g2.weight
                                                    break
                                            # Add the weight from vg1 to vg2
                                            new_weight = current_weight + g.weight
                                            vg2.add([v.index], new_weight, 'REPLACE')

                            print("Vertices from 'bone1' added to 'bone2' for all selected objects.")


                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["root"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            # Define the list of bone names to delete
                           
                            bones_to_delete = ["l_metatarsal", "r_metatarsal"]

                            # Ensure we are in Object Mode
                            if bpy.context.object.mode != 'OBJECT':
                                bpy.ops.object.mode_set(mode='OBJECT')

                            # Get the active object (assumed to be the armature)
                            armature = bpy.context.object

                            # Enter Edit Mode to modify the bones
                            bpy.ops.object.mode_set(mode='EDIT')

                            # Delete the bones
                            for bone_name in bones_to_delete:
                                if bone_name in armature.data.edit_bones:
                                    bone = armature.data.edit_bones[bone_name]
                                    armature.data.edit_bones.remove(bone)

                            # Return to Object Mode
                            bpy.ops.object.mode_set(mode='OBJECT')

                            print("Deleted bones:", bones_to_delete)


                    #G8
                    if mytool.my_enumar == 'OP15' or mytool.my_enumar == 'OP5'or mytool.my_enumar == 'OP12'or mytool.my_enumar == 'OP19'or mytool.my_enumar == 'OP21':  

    
                        
                        # Clear existing selections
                        bpy.ops.object.select_all(action='DESELECT')

                        # List to store selected mesh objects
                        selected_objects = []

                        # Iterate through all objects in the scene
                        for obj in bpy.context.scene.objects:
                            # Check if the object is a mesh
                            if obj.type == 'MESH':
                                # Check if the object has a parent that is an armature
                                if obj.parent and obj.parent.type == 'ARMATURE':
                                    obj.select_set(True)
                                    selected_objects.append(obj)
                                # Check if the object has an Armature modifier
                                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                                    obj.select_set(True)
                                    selected_objects.append(obj)

                        # Check if there are selected objects to join
                        if selected_objects:
                            # Set the active object to the first selected object
                            bpy.context.view_layer.objects.active = selected_objects[0]

                            # Iterate over each selected object
                            for obj in selected_objects:
                                # Get the vertex groups
                                vg1 = obj.vertex_groups.get("rMetatarsals")
                                vg2 = obj.vertex_groups.get("foot_r")

                                if not vg1 or not vg2:
                                    print(f"One or both vertex groups do not exist in object {obj.name}.")
                                    continue
                                
                                # Iterate through each vertex in the object
                                for v in obj.data.vertices:
                                    for g in v.groups:
                                        if g.group == vg1.index:
                                            # Get current weight in vg2 (if exists)
                                            current_weight = 0
                                            for g2 in v.groups:
                                                if g2.group == vg2.index:
                                                    current_weight = g2.weight
                                                    break
                                            # Add the weight from vg1 to vg2
                                            new_weight = current_weight + g.weight
                                            vg2.add([v.index], new_weight, 'REPLACE')

                            print("Vertices from 'bone1' added to 'bone2' for all selected objects.")
                        
                        
                        
                        # Clear existing selections
                        bpy.ops.object.select_all(action='DESELECT')

                        # List to store selected mesh objects
                        selected_objects = []

                        # Iterate through all objects in the scene
                        for obj in bpy.context.scene.objects:
                            # Check if the object is a mesh
                            if obj.type == 'MESH':
                                # Check if the object has a parent that is an armature
                                if obj.parent and obj.parent.type == 'ARMATURE':
                                    obj.select_set(True)
                                    selected_objects.append(obj)
                                # Check if the object has an Armature modifier
                                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                                    obj.select_set(True)
                                    selected_objects.append(obj)

                        # Check if there are selected objects to join
                        if selected_objects:
                            # Set the active object to the first selected object
                            bpy.context.view_layer.objects.active = selected_objects[0]

                            # Iterate over each selected object
                            for obj in selected_objects:
                                # Get the vertex groups
                                vg1 = obj.vertex_groups.get("lMetatarsals")
                                vg2 = obj.vertex_groups.get("foot_l")

                                if not vg1 or not vg2:
                                    print(f"One or both vertex groups do not exist in object {obj.name}.")
                                    continue
                                
                                # Iterate through each vertex in the object
                                for v in obj.data.vertices:
                                    for g in v.groups:
                                        if g.group == vg1.index:
                                            # Get current weight in vg2 (if exists)
                                            current_weight = 0
                                            for g2 in v.groups:
                                                if g2.group == vg2.index:
                                                    current_weight = g2.weight
                                                    break
                                            # Add the weight from vg1 to vg2
                                            new_weight = current_weight + g.weight
                                            vg2.add([v.index], new_weight, 'REPLACE')

                            print("Vertices from 'bone1' added to 'bone2' for all selected objects.")


                            bpy.ops.object.select_all(action='DESELECT')
                            objectToSelect2 = bpy.data.objects["root"]
                            objectToSelect2.select_set(True)    
                            bpy.context.view_layer.objects.active = objectToSelect2
                            # Define the list of bone names to delete
                           
                            bones_to_delete = ["lMetatarsals", "rMetatarsals"]

                            # Ensure we are in Object Mode
                            if bpy.context.object.mode != 'OBJECT':
                                bpy.ops.object.mode_set(mode='OBJECT')

                            # Get the active object (assumed to be the armature)
                            armature = bpy.context.object

                            # Enter Edit Mode to modify the bones
                            bpy.ops.object.mode_set(mode='EDIT')

                            # Delete the bones
                            for bone_name in bones_to_delete:
                                if bone_name in armature.data.edit_bones:
                                    bone = armature.data.edit_bones[bone_name]
                                    armature.data.edit_bones.remove(bone)

                            # Return to Object Mode
                            bpy.ops.object.mode_set(mode='OBJECT')

                            print("Deleted bones:", bones_to_delete)





        objects = bpy.context.scene.objects.keys()
        if  'RF_To_Ues_PosMatching' in objects:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_To_Ues_PosMatching"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')


        mytool.auto_fillcraterig =False

        bpy.context.window_manager.progress_update(100.0)

        bpy.context.window_manager.progress_update(0.0)





        
        
        return {'FINISHED'}

    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)      


