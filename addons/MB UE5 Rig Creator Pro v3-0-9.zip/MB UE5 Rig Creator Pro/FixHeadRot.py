import bpy





class fixhedrot_roto_in(bpy.types.Operator):
    bl_label = "Get Animation "
    bl_idname = "headrotof.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene


         

        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.object.mode_set(mode='OBJECT')



        
        
        
        
        armatureFrom = bpy.data.objects['RF_Rig']
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)

            copy_con = boneTo.constraints.new('COPY_ROTATION')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name




    
    
    
    #///COPY ROT1 1 
        if sce.bone_target17 !="" and mytool.my_bool ==False :

            bpy.context.object.pose.bones["clavicle_l"].constraints["Copy Rotation"].influence = 0

        
            


        #///COPY ROT 2
        if sce.bone_target18 !="" and mytool.my_bool3 ==False :

            bpy.context.object.pose.bones["upperarm_l"].constraints["Copy Rotation"].influence = 0
        
            


        #///COPY ROT 3
        if sce.bone_target21 !="" and mytool.my_bool5 ==False:
            bpy.context.object.pose.bones["lowerarm_l"].constraints["Copy Rotation"].influence = 0





        #///COPY ROT 4
        if sce.bone_target24 !="" and mytool.my_bool7 ==False:

            bpy.context.object.pose.bones["hand_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ik_hand_l"].constraints["Copy Rotation"].influence = 0
        
            




        #///COPY ROT 5
        if sce.bone_target1 !="" and mytool.my_bool18 ==False:
        
            bpy.context.object.pose.bones["thigh_l"].constraints["Copy Rotation"].influence = 0


        #///COPY ROT 6
        if sce.bone_target4 !="" and mytool.my_bool20 ==False:
        
            bpy.context.object.pose.bones["calf_l"].constraints["Copy Rotation"].influence = 0
        


        ##RRRRRRRRR

        #///COPY ROT1 1


        if sce.bone_target25 !="" and mytool.my_bool2 ==False:
    
            bpy.context.object.pose.bones["clavicle_r"].constraints["Copy Rotation"].influence = 0


        #///COPY ROT 2


        if sce.bone_target26 !="" and mytool.my_bool4 ==False:
        
            bpy.context.object.pose.bones["upperarm_r"].constraints["Copy Rotation"].influence = 0




        #///COPY ROT 3

        if sce.bone_target29 !="" and mytool.my_bool6 ==False:
            
            bpy.context.object.pose.bones["lowerarm_r"].constraints["Copy Rotation"].influence = 0




        #///COPY ROT 4

        if sce.bone_target32 !="" and mytool.my_bool8 ==False:
            
            bpy.context.object.pose.bones["hand_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ik_hand_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ik_hand_gun"].constraints["Copy Rotation"].influence = 0





        #///COPY ROT 5

        if sce.bone_target9 !="" and mytool.my_bool19 ==False:
        
            bpy.context.object.pose.bones["thigh_r"].constraints["Copy Rotation"].influence = 0
            




        #///COPY ROT 6

        if sce.bone_target12 !="" and mytool.my_bool21 ==False:
            
            bpy.context.object.pose.bones["calf_r"].constraints["Copy Rotation"].influence = 0

            


    
    
    
    
    
    
    
    
        ##Spine
    #///COPY ROT1 1

        if sce.bone_target33 !="" and mytool.my_bool9 ==False :
    
                bpy.context.object.pose.bones["head"].constraints["Copy Rotation"].influence = 0




        #///COPY ROT1 2

        if sce.bone_target34 !="" and mytool.my_bool11 ==False :

            bpy.context.object.pose.bones["neck_02"].constraints["Copy Rotation"].influence = 0
        



        #///COPY ROT1 3

        if sce.bone_target35 !=""and mytool.my_bool10 ==False :

            bpy.context.object.pose.bones["neck_01"].constraints["Copy Rotation"].influence = 0
        

        

        
        #///COPY ROT1 4

        if sce.bone_target36 !="" and mytool.my_bool12 ==False:

            bpy.context.object.pose.bones["spine_05"].constraints["Copy Rotation"].influence = 0
        
            




        #///COPY ROT1 5
        if sce.bone_target37 !="" and mytool.my_bool13 ==False :
        
            bpy.context.object.pose.bones["spine_04"].constraints["Copy Rotation"].influence = 0



        #///COPY ROT1 6

        if sce.bone_target38 !="" and mytool.my_bool14 ==False:
            
            bpy.context.object.pose.bones["spine_03"].constraints["Copy Rotation"].influence = 0
        

            



        #///COPY ROT1 7

        if sce.bone_target39 !="" and mytool.my_bool15 ==False :
        
            bpy.context.object.pose.bones["spine_02"].constraints["Copy Rotation"].influence = 0
            





        #///COPY ROT1 8

        if sce.bone_target40 !="" and mytool.my_bool16 ==False:

            bpy.context.object.pose.bones["spine_01"].constraints["Copy Rotation"].influence = 0
    
            




        #///COPY ROT1 9

        if sce.bone_targetHip !="" and mytool.my_bool17 ==False:

            bpy.context.object.pose.bones["pelvis"].constraints["Copy Rotation"].influence = 0
        
            
        
        

            #add Foots ////////////////////////////////////////////////////////////

        if sce.bone_target7 !="" and mytool.my_bool22 ==False:


            bpy.context.object.pose.bones["foot_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ik_foot_l"].constraints["Copy Rotation"].influence = 0

    
            





        if sce.bone_target8 !="" and mytool.my_bool24 ==False:

            bpy.context.object.pose.bones["ball_l"].constraints["Copy Rotation"].influence = 0
    
        




        if sce.bone_target15 !="" and mytool.my_bool23 ==False:

            bpy.context.object.pose.bones["foot_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ik_foot_r"].constraints["Copy Rotation"].influence = 0
    
            



        if sce.bone_target16 !="" and mytool.my_bool25 ==False:

            bpy.context.object.pose.bones["ball_r"].constraints["Copy Rotation"].influence = 0
    
            

       #New
       
        if sce.bone_target3 !="" and mytool.my_bool37 ==False:

            bpy.context.object.pose.bones["thigh_twist_02_l"].constraints["Copy Rotation"].influence = 0


        if sce.bone_target6 !="" and mytool.my_bool39 ==False:

            bpy.context.object.pose.bones["calf_twist_01_l"].constraints["Copy Rotation"].influence = 0


        
        
        
        
        if sce.bone_target11 !="" and mytool.my_bool42 ==False:

            bpy.context.object.pose.bones["thigh_twist_02_r"].constraints["Copy Rotation"].influence = 0


        if sce.bone_target14 !="" and mytool.my_bool40 ==False:

            bpy.context.object.pose.bones["calf_twist_01_r"].constraints["Copy Rotation"].influence = 0



        if sce.bone_target20 !="" and mytool.my_bool41 ==False:

            bpy.context.object.pose.bones["upperarm_twist_02_l"].constraints["Copy Rotation"].influence = 0


        if sce.bone_target23 !="" and mytool.my_bool43 ==False:

            bpy.context.object.pose.bones["lowerarm_twist_01_l"].constraints["Copy Rotation"].influence = 0

    




        if sce.bone_target28 !="" and mytool.my_bool41 ==False:

            bpy.context.object.pose.bones["upperarm_twist_02_r"].constraints["Copy Rotation"].influence = 0


        if sce.bone_target31 !="" and mytool.my_bool44 ==False:

            bpy.context.object.pose.bones["lowerarm_twist_01_r"].constraints["Copy Rotation"].influence = 0
    
   
   
        if sce.bone_target67 !="" and mytool.my_boolfingers ==False:
            bpy.context.object.pose.bones["thumb_01_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["thumb_02_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["thumb_03_l"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["index_01_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["index_02_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["index_03_l"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["middle_01_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["middle_02_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["middle_03_l"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["ring_01_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ring_02_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ring_03_l"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["pinky_01_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["pinky_02_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["pinky_03_l"].constraints["Copy Rotation"].influence = 0
   
       

            bpy.context.object.pose.bones["pinky_metacarpal_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ring_metacarpal_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["middle_metacarpal_l"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["index_metacarpal_l"].constraints["Copy Rotation"].influence = 0
   

         
            bpy.context.object.pose.bones["thumb_01_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["thumb_02_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["thumb_03_r"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["index_01_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["index_02_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["index_03_r"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["middle_01_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["middle_02_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["middle_03_r"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["ring_01_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ring_02_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ring_03_r"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["pinky_01_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["pinky_02_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["pinky_03_r"].constraints["Copy Rotation"].influence = 0

            bpy.context.object.pose.bones["pinky_metacarpal_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["ring_metacarpal_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["middle_metacarpal_r"].constraints["Copy Rotation"].influence = 0
            bpy.context.object.pose.bones["index_metacarpal_r"].constraints["Copy Rotation"].influence = 0
   
   
   
   
    #add Foots ////////////////////////////////////////////////////////////


        






        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.pose.armature_apply(selected=False)
        bpy.ops.object.mode_set(mode='OBJECT')


    
    
    
        armatureFrom = bpy.data.objects[sce.Armature_Target]
        armatureTo = bpy.data.objects[sce.Armature_Target]

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)

        

        
        
        return {'FINISHED'}

    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)



