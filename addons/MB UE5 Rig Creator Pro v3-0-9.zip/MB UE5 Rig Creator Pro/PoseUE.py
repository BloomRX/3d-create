import bpy
import bmesh


def makeuerig():

    bpy.ops.object.armature_add(enter_editmode=False, align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
    bpy.context.active_object.name = 'RF_Rig_AR'

    bpy.ops.object.select_all(action='DESELECT')
    objectToSelect2 = bpy.data.objects["RF_Rig_AR"]
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    
    for obj in bpy.context.selected_objects:
        obj.name = "RF_PosRig"
        obj.data.name = "RF_PosRig"
    
    
    #///////////Naming
    bpy.ops.object.select_all(action='DESELECT')
        
    objectToSelect = bpy.data.objects["RF_PosRig"] 
    objectToSelect.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect
    ob = bpy.data.objects["RF_PosRig"] 
    armature = ob.data

            
    bpy.context.object.data.bones["Bone"].name = "temp"

    bpy.ops.object.mode_set(mode='EDIT')

    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')
   
    bpy.ops.object.select_all(action='DESELECT')
 

    #////clavicle_l
    objectToSelect = bpy.data.objects["RF_PosRig"]
    objectToSelect.select_set(True)    
    bpy.context.view_layer.objects.active = objectToSelect

    bpy.ops.object.mode_set(mode='EDIT')
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("clavicle_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')





    objectToSelect2 = bpy.data.objects["RF_PosRig"] 
    objectToSelect2.select_set(True)
    bpy.context.view_layer.objects.active = objectToSelect2
    ob = bpy.data.objects["RF_PosRig"] 
    armature = ob.data

    bpy.ops.object.mode_set(mode='EDIT')
    
    
    



    objectToSelect.data.edit_bones['clavicle_l'].head[0] = 1.4279
    objectToSelect.data.edit_bones['clavicle_l'].head[1] = 1.7398
    objectToSelect.data.edit_bones['clavicle_l'].head[2] = 146.301
    objectToSelect.data.edit_bones['clavicle_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['clavicle_l'].tail[0] = 0.6107
    objectToSelect.data.edit_bones['clavicle_l'].tail[1] = 19.5305
    objectToSelect.data.edit_bones['clavicle_l'].tail[2] = 146.365
    objectToSelect.data.edit_bones['clavicle_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['clavicle_l'].roll = 0.153272
    objectToSelect.data.edit_bones['clavicle_l'].length = 17.8096
    objectToSelect.data.edit_bones['clavicle_l'].envelope_distance = 0.25



    
    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("upperarm_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



    
    


    objectToSelect.data.edit_bones['upperarm_l'].head[0] = 19.0099
    objectToSelect.data.edit_bones['upperarm_l'].head[1] = 2.5572
    objectToSelect.data.edit_bones['upperarm_l'].head[2] = 143.584
    objectToSelect.data.edit_bones['upperarm_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['upperarm_l'].tail[0] = 18.4065
    objectToSelect.data.edit_bones['upperarm_l'].tail[1] = 21.0369
    objectToSelect.data.edit_bones['upperarm_l'].tail[2] = 142.629
    objectToSelect.data.edit_bones['upperarm_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['upperarm_l'].roll = 0.957395
    objectToSelect.data.edit_bones['upperarm_l'].length = 18.5142
    objectToSelect.data.edit_bones['upperarm_l'].envelope_distance = 0.25

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("upperarm_twist_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['upperarm_twist_01_l'].head[0] = 24.3423
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].head[1] = 2.3405
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].head[2] = 136.02
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['upperarm_twist_01_l'].tail[0] = 23.7997
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].tail[1] = 20.8174
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].tail[2] = 134.978
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].roll = 0.919652
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].length = 18.5142
    objectToSelect.data.edit_bones['upperarm_twist_01_l'].envelope_distance = 0.25


  
 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("upperarm_twist_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['upperarm_twist_02_l'].head[0] = 29.6746
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].head[1] = 2.1237
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].head[2] = 128.456
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['upperarm_twist_02_l'].tail[0] = 29.0712
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].tail[1] = 20.6034
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].tail[2] = 127.501
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].roll = 0.957395
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].length = 18.5142
    objectToSelect.data.edit_bones['upperarm_twist_02_l'].envelope_distance = 0.25

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("lowerarm_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['lowerarm_l'].head[0] = 35.007
    objectToSelect.data.edit_bones['lowerarm_l'].head[1] = 1.907
    objectToSelect.data.edit_bones['lowerarm_l'].head[2] = 120.892
    objectToSelect.data.edit_bones['lowerarm_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['lowerarm_l'].tail[0] = 41.1295
    objectToSelect.data.edit_bones['lowerarm_l'].tail[1] = 15.7361
    objectToSelect.data.edit_bones['lowerarm_l'].tail[2] = 110.826
    objectToSelect.data.edit_bones['lowerarm_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['lowerarm_l'].roll = 0.937355
    objectToSelect.data.edit_bones['lowerarm_l'].length = 18.1674
    objectToSelect.data.edit_bones['lowerarm_l'].envelope_distance = 0.25

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("lowerarm_twist_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].head[0] = 39.2609
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].head[1] = -3.9616
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].head[2] = 115.417
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].tail[0] = 45.4103
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].tail[1] = 10.2928
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].tail[2] = 105.98
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].roll = 0.900541
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].length = 18.1676
    objectToSelect.data.edit_bones['lowerarm_twist_02_l'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("lowerarm_twist_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 


    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].head[0] = 43.5147
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].head[1] = -9.8303
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].head[2] = 109.942
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].tail[0] = 49.6642
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].tail[1] = 4.4242
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].tail[2] = 100.505
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].roll = 0.900541
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].length = 18.1677
    objectToSelect.data.edit_bones['lowerarm_twist_01_l'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("hand_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 


    objectToSelect.data.edit_bones['hand_l'].head[0] = 47.7686
    objectToSelect.data.edit_bones['hand_l'].head[1] = -15.6989
    objectToSelect.data.edit_bones['hand_l'].head[2] = 104.467
    objectToSelect.data.edit_bones['hand_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['hand_l'].tail[0] = 45.3304
    objectToSelect.data.edit_bones['hand_l'].tail[1] = -14.723
    objectToSelect.data.edit_bones['hand_l'].tail[2] = 101.752
    objectToSelect.data.edit_bones['hand_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['hand_l'].roll = 1.43187
    objectToSelect.data.edit_bones['hand_l'].length = 3.7774
    objectToSelect.data.edit_bones['hand_l'].envelope_distance = 0.25

 

    #FINGERS


   

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pinky_metacarpal_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['pinky_metacarpal_l'].head[0] = 50.9451
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].head[1] = -16.0742
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].head[2] = 101.904
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['pinky_metacarpal_l'].tail[0] = 46.6689
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].tail[1] = -16.4425
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].tail[2] = 99.4111
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].roll = 1.32455
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].length = 4.9635
    objectToSelect.data.edit_bones['pinky_metacarpal_l'].envelope_distance = 0.25


 
    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ring_metacarpal_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['ring_metacarpal_l'].head[0] = 50.3309
    objectToSelect.data.edit_bones['ring_metacarpal_l'].head[1] = -17.1326
    objectToSelect.data.edit_bones['ring_metacarpal_l'].head[2] = 102.405
    objectToSelect.data.edit_bones['ring_metacarpal_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ring_metacarpal_l'].tail[0] = 46.2048
    objectToSelect.data.edit_bones['ring_metacarpal_l'].tail[1] = -16.9154
    objectToSelect.data.edit_bones['ring_metacarpal_l'].tail[2] = 98.5573
    objectToSelect.data.edit_bones['ring_metacarpal_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ring_metacarpal_l'].roll = 1.30417
    objectToSelect.data.edit_bones['ring_metacarpal_l'].length = 5.6459
    objectToSelect.data.edit_bones['ring_metacarpal_l'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("middle_metacarpal_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['middle_metacarpal_l'].head[0] = 49.6886
    objectToSelect.data.edit_bones['middle_metacarpal_l'].head[1] = -18.1298
    objectToSelect.data.edit_bones['middle_metacarpal_l'].head[2] = 102.917
    objectToSelect.data.edit_bones['middle_metacarpal_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['middle_metacarpal_l'].tail[0] = 45.6016
    objectToSelect.data.edit_bones['middle_metacarpal_l'].tail[1] = -17.0494
    objectToSelect.data.edit_bones['middle_metacarpal_l'].tail[2] = 98.5216
    objectToSelect.data.edit_bones['middle_metacarpal_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['middle_metacarpal_l'].roll = 1.44461
    objectToSelect.data.edit_bones['middle_metacarpal_l'].length = 6.0984
    objectToSelect.data.edit_bones['middle_metacarpal_l'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("index_metacarpal_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['index_metacarpal_l'].head[0] = 48.1391
    objectToSelect.data.edit_bones['index_metacarpal_l'].head[1] = -19.7001
    objectToSelect.data.edit_bones['index_metacarpal_l'].head[2] = 103.231
    objectToSelect.data.edit_bones['index_metacarpal_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['index_metacarpal_l'].tail[0] = 44.6015
    objectToSelect.data.edit_bones['index_metacarpal_l'].tail[1] = -18.0013
    objectToSelect.data.edit_bones['index_metacarpal_l'].tail[2] = 98.849
    objectToSelect.data.edit_bones['index_metacarpal_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['index_metacarpal_l'].roll = 1.52123
    objectToSelect.data.edit_bones['index_metacarpal_l'].length = 5.8824
    objectToSelect.data.edit_bones['index_metacarpal_l'].envelope_distance = 0.25


 


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thumb_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['thumb_01_l'].head[0] = 46.2267
    objectToSelect.data.edit_bones['thumb_01_l'].head[1] = -18.4958
    objectToSelect.data.edit_bones['thumb_01_l'].head[2] = 102.958
    objectToSelect.data.edit_bones['thumb_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['thumb_01_l'].tail[0] = 47.7942
    objectToSelect.data.edit_bones['thumb_01_l'].tail[1] = -16.8726
    objectToSelect.data.edit_bones['thumb_01_l'].tail[2] = 99.2068
    objectToSelect.data.edit_bones['thumb_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thumb_01_l'].roll = 1.5851
    objectToSelect.data.edit_bones['thumb_01_l'].length = 4.3776
    objectToSelect.data.edit_bones['thumb_01_l'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thumb_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['thumb_02_l'].head[0] = 45.1901
    objectToSelect.data.edit_bones['thumb_02_l'].head[1] = -22.2247
    objectToSelect.data.edit_bones['thumb_02_l'].head[2] = 100.912
    objectToSelect.data.edit_bones['thumb_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['thumb_02_l'].tail[0] = 46.6633
    objectToSelect.data.edit_bones['thumb_02_l'].tail[1] = -20.2062
    objectToSelect.data.edit_bones['thumb_02_l'].tail[2] = 99.1012
    objectToSelect.data.edit_bones['thumb_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thumb_02_l'].roll = 1.42894
    objectToSelect.data.edit_bones['thumb_02_l'].length = 3.086
    objectToSelect.data.edit_bones['thumb_02_l'].envelope_distance = 0.25

 
 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thumb_03_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['thumb_03_l'].head[0] = 45.0489
    objectToSelect.data.edit_bones['thumb_03_l'].head[1] = -24.2255
    objectToSelect.data.edit_bones['thumb_03_l'].head[2] = 98.5667
    objectToSelect.data.edit_bones['thumb_03_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['thumb_03_l'].tail[0] = 46.5242
    objectToSelect.data.edit_bones['thumb_03_l'].tail[1] = -21.8903
    objectToSelect.data.edit_bones['thumb_03_l'].tail[2] = 97.1907
    objectToSelect.data.edit_bones['thumb_03_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thumb_03_l'].roll = 1.3891
    objectToSelect.data.edit_bones['thumb_03_l'].length = 3.0859
    objectToSelect.data.edit_bones['thumb_03_l'].envelope_distance = 0.25

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("index_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['index_01_l'].head[0] = 50.5319
    objectToSelect.data.edit_bones['index_01_l'].head[1] = -23.7315
    objectToSelect.data.edit_bones['index_01_l'].head[2] = 99.678
    objectToSelect.data.edit_bones['index_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['index_01_l'].tail[0] = 47.6599
    objectToSelect.data.edit_bones['index_01_l'].tail[1] = -21.4939
    objectToSelect.data.edit_bones['index_01_l'].tail[2] = 97.8365
    objectToSelect.data.edit_bones['index_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['index_01_l'].roll = 1.70432
    objectToSelect.data.edit_bones['index_01_l'].length = 4.08
    objectToSelect.data.edit_bones['index_01_l'].envelope_distance = 0.25


  
    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("index_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['index_02_l'].head[0] = 50.9922
    objectToSelect.data.edit_bones['index_02_l'].head[1] = -25.9389
    objectToSelect.data.edit_bones['index_02_l'].head[2] = 96.2777
    objectToSelect.data.edit_bones['index_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['index_02_l'].tail[0] = 49.1517
    objectToSelect.data.edit_bones['index_02_l'].tail[1] = -24.2027
    objectToSelect.data.edit_bones['index_02_l'].tail[2] = 95.7017
    objectToSelect.data.edit_bones['index_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['index_02_l'].roll = 1.80717
    objectToSelect.data.edit_bones['index_02_l'].length = 2.5949
    objectToSelect.data.edit_bones['index_02_l'].envelope_distance = 0.25

  

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("index_03_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 


    objectToSelect.data.edit_bones['index_03_l'].head[0] = 50.8057
    objectToSelect.data.edit_bones['index_03_l'].head[1] = -26.93
    objectToSelect.data.edit_bones['index_03_l'].head[2] = 93.8867
    objectToSelect.data.edit_bones['index_03_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['index_03_l'].tail[0] = 49.0493
    objectToSelect.data.edit_bones['index_03_l'].tail[1] = -25.0202
    objectToSelect.data.edit_bones['index_03_l'].tail[2] = 93.8425
    objectToSelect.data.edit_bones['index_03_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['index_03_l'].roll = 1.88885
    objectToSelect.data.edit_bones['index_03_l'].length = 2.595
    objectToSelect.data.edit_bones['index_03_l'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("middle_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 
    


    objectToSelect.data.edit_bones['middle_01_l'].head[0] = 52.6456
    objectToSelect.data.edit_bones['middle_01_l'].head[1] = -21.9758
    objectToSelect.data.edit_bones['middle_01_l'].head[2] = 99.2218
    objectToSelect.data.edit_bones['middle_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['middle_01_l'].tail[0] = 48.3818
    objectToSelect.data.edit_bones['middle_01_l'].tail[1] = -19.4887
    objectToSelect.data.edit_bones['middle_01_l'].tail[2] = 97.6876
    objectToSelect.data.edit_bones['middle_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['middle_01_l'].roll = 1.75721
    objectToSelect.data.edit_bones['middle_01_l'].length = 5.1691
    objectToSelect.data.edit_bones['middle_01_l'].envelope_distance = 0.25

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("middle_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['middle_02_l'].head[0] = 52.9672
    objectToSelect.data.edit_bones['middle_02_l'].head[1] = -24.2736
    objectToSelect.data.edit_bones['middle_02_l'].head[2] = 94.6028
    objectToSelect.data.edit_bones['middle_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['middle_02_l'].tail[0] = 51.0045
    objectToSelect.data.edit_bones['middle_02_l'].tail[1] = -22.7706
    objectToSelect.data.edit_bones['middle_02_l'].tail[2] = 94.7001
    objectToSelect.data.edit_bones['middle_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['middle_02_l'].roll = 1.93398
    objectToSelect.data.edit_bones['middle_02_l'].length = 2.474
    objectToSelect.data.edit_bones['middle_02_l'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("middle_03_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['middle_03_l'].head[0] = 52.3875
    objectToSelect.data.edit_bones['middle_03_l'].head[1] = -24.8799
    objectToSelect.data.edit_bones['middle_03_l'].head[2] = 92.2753
    objectToSelect.data.edit_bones['middle_03_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['middle_03_l'].tail[0] = 50.5553
    objectToSelect.data.edit_bones['middle_03_l'].tail[1] = -23.2944
    objectToSelect.data.edit_bones['middle_03_l'].tail[2] = 92.7753
    objectToSelect.data.edit_bones['middle_03_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['middle_03_l'].roll = 2.01509
    objectToSelect.data.edit_bones['middle_03_l'].length = 2.474
    objectToSelect.data.edit_bones['middle_03_l'].envelope_distance = 0.25



     

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ring_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 
    


    objectToSelect.data.edit_bones['ring_01_l'].head[0] = 53.6885
    objectToSelect.data.edit_bones['ring_01_l'].head[1] = -19.7768
    objectToSelect.data.edit_bones['ring_01_l'].head[2] = 98.7157
    objectToSelect.data.edit_bones['ring_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ring_01_l'].tail[0] = 49.2946
    objectToSelect.data.edit_bones['ring_01_l'].tail[1] = -17.991
    objectToSelect.data.edit_bones['ring_01_l'].tail[2] = 97.2072
    objectToSelect.data.edit_bones['ring_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ring_01_l'].roll = 1.66432
    objectToSelect.data.edit_bones['ring_01_l'].length = 4.977
    objectToSelect.data.edit_bones['ring_01_l'].envelope_distance = 0.25


 
    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ring_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['ring_02_l'].head[0] = 54.4661
    objectToSelect.data.edit_bones['ring_02_l'].head[1] = -21.689
    objectToSelect.data.edit_bones['ring_02_l'].head[2] = 94.1869
    objectToSelect.data.edit_bones['ring_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ring_02_l'].tail[0] = 52.46
    objectToSelect.data.edit_bones['ring_02_l'].tail[1] = -20.6376
    objectToSelect.data.edit_bones['ring_02_l'].tail[2] = 94.2074
    objectToSelect.data.edit_bones['ring_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ring_02_l'].roll = 1.86335
    objectToSelect.data.edit_bones['ring_02_l'].length = 2.265
    objectToSelect.data.edit_bones['ring_02_l'].envelope_distance = 0.25

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ring_03_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['ring_03_l'].head[0] = 54.151
    objectToSelect.data.edit_bones['ring_03_l'].head[1] = -22.2479
    objectToSelect.data.edit_bones['ring_03_l'].head[2] = 92.0147
    objectToSelect.data.edit_bones['ring_03_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ring_03_l'].tail[0] = 52.2207
    objectToSelect.data.edit_bones['ring_03_l'].tail[1] = -21.1209
    objectToSelect.data.edit_bones['ring_03_l'].tail[2] = 92.3811
    objectToSelect.data.edit_bones['ring_03_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ring_03_l'].roll = 1.95521
    objectToSelect.data.edit_bones['ring_03_l'].length = 2.265
    objectToSelect.data.edit_bones['ring_03_l'].envelope_distance = 0.25



 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pinky_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['pinky_01_l'].head[0] = 53.5398
    objectToSelect.data.edit_bones['pinky_01_l'].head[1] = -17.628
    objectToSelect.data.edit_bones['pinky_01_l'].head[2] = 97.9685
    objectToSelect.data.edit_bones['pinky_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['pinky_01_l'].tail[0] = 49.9896
    objectToSelect.data.edit_bones['pinky_01_l'].tail[1] = -16.9674
    objectToSelect.data.edit_bones['pinky_01_l'].tail[2] = 96.7353
    objectToSelect.data.edit_bones['pinky_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pinky_01_l'].roll = 1.5428
    objectToSelect.data.edit_bones['pinky_01_l'].length = 3.8159
    objectToSelect.data.edit_bones['pinky_01_l'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pinky_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['pinky_02_l'].head[0] = 54.5455
    objectToSelect.data.edit_bones['pinky_02_l'].head[1] = -18.7614
    objectToSelect.data.edit_bones['pinky_02_l'].head[2] =  94.4662
    objectToSelect.data.edit_bones['pinky_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['pinky_02_l'].tail[0] = 52.5818
    objectToSelect.data.edit_bones['pinky_02_l'].tail[1] = -18.2124
    objectToSelect.data.edit_bones['pinky_02_l'].tail[2] = 94.5316
    objectToSelect.data.edit_bones['pinky_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pinky_02_l'].roll = 1.82806
    objectToSelect.data.edit_bones['pinky_02_l'].length = 2.04
    objectToSelect.data.edit_bones['pinky_02_l'].envelope_distance = 0.25


 

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pinky_03_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['pinky_03_l'].head[0] = 54.3574
    objectToSelect.data.edit_bones['pinky_03_l'].head[1] = -19.1977
    objectToSelect.data.edit_bones['pinky_03_l'].head[2] =  92.4823
    objectToSelect.data.edit_bones['pinky_03_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['pinky_03_l'].tail[0] = 52.4171
    objectToSelect.data.edit_bones['pinky_03_l'].tail[1] = -18.6133
    objectToSelect.data.edit_bones['pinky_03_l'].tail[2] = 92.7175
    objectToSelect.data.edit_bones['pinky_03_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pinky_03_l'].roll = 1.89112
    objectToSelect.data.edit_bones['pinky_03_l'].length = 2.04
    objectToSelect.data.edit_bones['pinky_03_l'].envelope_distance = 0.25


 
    #RRRRRRRRRRRRRRRRRRRRRR

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("clavicle_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['clavicle_r'].head[0] = -1.4279
    objectToSelect.data.edit_bones['clavicle_r'].head[1] = 1.7399
    objectToSelect.data.edit_bones['clavicle_r'].head[2] =  146.301
    objectToSelect.data.edit_bones['clavicle_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['clavicle_r'].tail[0] = -2.2451
    objectToSelect.data.edit_bones['clavicle_r'].tail[1] = -16.0509
    objectToSelect.data.edit_bones['clavicle_r'].tail[2] = 146.237
    objectToSelect.data.edit_bones['clavicle_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['clavicle_r'].roll = 3.13819
    objectToSelect.data.edit_bones['clavicle_r'].length = 17.8097
    objectToSelect.data.edit_bones['clavicle_r'].envelope_distance = 0.25

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("upperarm_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['upperarm_r'].head[0] = -19.0099
    objectToSelect.data.edit_bones['upperarm_r'].head[1] = 2.5573
    objectToSelect.data.edit_bones['upperarm_r'].head[2] =  143.583
    objectToSelect.data.edit_bones['upperarm_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['upperarm_r'].tail[0] = -19.6133
    objectToSelect.data.edit_bones['upperarm_r'].tail[1] = -15.9221
    objectToSelect.data.edit_bones['upperarm_r'].tail[2] = 144.538
    objectToSelect.data.edit_bones['upperarm_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['upperarm_r'].roll = -0.169686
    objectToSelect.data.edit_bones['upperarm_r'].length = 18.5139
    objectToSelect.data.edit_bones['upperarm_r'].envelope_distance = 0.25

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("upperarm_twist_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['upperarm_twist_01_r'].head[0] = -24.3423
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].head[1] = 2.3405
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].head[2] =  136.019
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['upperarm_twist_01_r'].tail[0] = -24.8849
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].tail[1] = -16.136
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].tail[2] = 137.06
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].roll = -0.041221
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].length = 18.5138
    objectToSelect.data.edit_bones['upperarm_twist_01_r'].envelope_distance = 0.25

 
    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("upperarm_twist_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['upperarm_twist_02_r'].head[0] = -29.6746
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].head[1] = 2.1238
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].head[2] =  128.456
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['upperarm_twist_02_r'].tail[0] = -30.278
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].tail[1] = -16.3555
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].tail[2] = 129.411
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].roll = -0.169686
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].length = 18.5138
    objectToSelect.data.edit_bones['upperarm_twist_02_r'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("lowerarm_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['lowerarm_r'].head[0] = -35.0067
    objectToSelect.data.edit_bones['lowerarm_r'].head[1] = 1.9071
    objectToSelect.data.edit_bones['lowerarm_r'].head[2] =  120.892
    objectToSelect.data.edit_bones['lowerarm_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['lowerarm_r'].tail[0] = -28.8842
    objectToSelect.data.edit_bones['lowerarm_r'].tail[1] = -11.922
    objectToSelect.data.edit_bones['lowerarm_r'].tail[2] = 130.958
    objectToSelect.data.edit_bones['lowerarm_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['lowerarm_r'].roll = 2.03025
    objectToSelect.data.edit_bones['lowerarm_r'].length = 18.1674
    objectToSelect.data.edit_bones['lowerarm_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("lowerarm_twist_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].head[0] = -39.2606
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].head[1] = -3.9616
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].head[2] =  115.417
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].tail[0] = -33.1111
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].tail[1] = -18.216
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].tail[2] = 124.853
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].roll = 2.05563
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].length = 18.1671
    objectToSelect.data.edit_bones['lowerarm_twist_02_r'].envelope_distance = 0.25


  
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("lowerarm_twist_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].head[0] = -43.5144
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].head[1] = -9.8302
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].head[2] =  109.942
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].tail[0] = -37.365
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].tail[1] = -24.0846
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].tail[2] = 119.378
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].roll = 2.05563
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].length = 18.167
    objectToSelect.data.edit_bones['lowerarm_twist_01_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("hand_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 
    


    objectToSelect.data.edit_bones['hand_r'].head[0] = -47.7683
    objectToSelect.data.edit_bones['hand_r'].head[1] = -15.6988
    objectToSelect.data.edit_bones['hand_r'].head[2] =  104.466
    objectToSelect.data.edit_bones['hand_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['hand_r'].tail[0] = -50.2066
    objectToSelect.data.edit_bones['hand_r'].tail[1] = -16.6747
    objectToSelect.data.edit_bones['hand_r'].tail[2] = 107.181
    objectToSelect.data.edit_bones['hand_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['hand_r'].roll = -0.0316926
    objectToSelect.data.edit_bones['hand_r'].length = 3.7774
    objectToSelect.data.edit_bones['hand_r'].envelope_distance = 0.25

 


    #Fingers



 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pinky_metacarpal_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



   
    
    


    objectToSelect.data.edit_bones['pinky_metacarpal_r'].head[0] = -50.9451
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].head[1] = -16.0742
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].head[2] =  101.904
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['pinky_metacarpal_r'].tail[0] = -55.2211
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].tail[1] = -15.7059
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].tail[2] = 104.397
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].roll = -0.76132
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].length = 4.9634
    objectToSelect.data.edit_bones['pinky_metacarpal_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ring_metacarpal_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['ring_metacarpal_r'].head[0] = -50.3309
    objectToSelect.data.edit_bones['ring_metacarpal_r'].head[1] = -17.1326
    objectToSelect.data.edit_bones['ring_metacarpal_r'].head[2] =  102.405
    objectToSelect.data.edit_bones['ring_metacarpal_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ring_metacarpal_r'].tail[0] = -54.4571
    objectToSelect.data.edit_bones['ring_metacarpal_r'].tail[1] = -17.3498
    objectToSelect.data.edit_bones['ring_metacarpal_r'].tail[2] = 106.253
    objectToSelect.data.edit_bones['ring_metacarpal_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ring_metacarpal_r'].roll = -0.336499
    objectToSelect.data.edit_bones['ring_metacarpal_r'].length = 5.6462
    objectToSelect.data.edit_bones['ring_metacarpal_r'].envelope_distance = 0.25


 
 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("middle_metacarpal_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  
    


    objectToSelect.data.edit_bones['middle_metacarpal_r'].head[0] = -49.6886
    objectToSelect.data.edit_bones['middle_metacarpal_r'].head[1] = -18.1298
    objectToSelect.data.edit_bones['middle_metacarpal_r'].head[2] =  102.917
    objectToSelect.data.edit_bones['middle_metacarpal_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['middle_metacarpal_r'].tail[0] = -53.7756
    objectToSelect.data.edit_bones['middle_metacarpal_r'].tail[1] = -19.2103
    objectToSelect.data.edit_bones['middle_metacarpal_r'].tail[2] = 107.312
    objectToSelect.data.edit_bones['middle_metacarpal_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['middle_metacarpal_r'].roll = -0.0535294
    objectToSelect.data.edit_bones['middle_metacarpal_r'].length = 6.0981
    objectToSelect.data.edit_bones['middle_metacarpal_r'].envelope_distance = 0.25

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("index_metacarpal_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  

    objectToSelect.data.edit_bones['index_metacarpal_r'].head[0] = -48.1391
    objectToSelect.data.edit_bones['index_metacarpal_r'].head[1] = -19.7001
    objectToSelect.data.edit_bones['index_metacarpal_r'].head[2] =  103.231
    objectToSelect.data.edit_bones['index_metacarpal_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['index_metacarpal_r'].tail[0] = -51.6767
    objectToSelect.data.edit_bones['index_metacarpal_r'].tail[1] = -21.3989
    objectToSelect.data.edit_bones['index_metacarpal_r'].tail[2] = 107.613
    objectToSelect.data.edit_bones['index_metacarpal_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['index_metacarpal_r'].roll = 0.162834
    objectToSelect.data.edit_bones['index_metacarpal_r'].length = 5.8824
    objectToSelect.data.edit_bones['index_metacarpal_r'].envelope_distance = 0.25


  

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thumb_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 


    objectToSelect.data.edit_bones['thumb_01_r'].head[0] = -46.2267
    objectToSelect.data.edit_bones['thumb_01_r'].head[1] = -18.4958
    objectToSelect.data.edit_bones['thumb_01_r'].head[2] =  102.958
    objectToSelect.data.edit_bones['thumb_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['thumb_01_r'].tail[0] = -44.6592
    objectToSelect.data.edit_bones['thumb_01_r'].tail[1] = -20.119
    objectToSelect.data.edit_bones['thumb_01_r'].tail[2] = 106.709
    objectToSelect.data.edit_bones['thumb_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thumb_01_r'].roll = 2.37665
    objectToSelect.data.edit_bones['thumb_01_r'].length = 4.3774
    objectToSelect.data.edit_bones['thumb_01_r'].envelope_distance = 0.25

 


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thumb_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['thumb_02_r'].head[0] = -45.1901
    objectToSelect.data.edit_bones['thumb_02_r'].head[1] = -22.2247
    objectToSelect.data.edit_bones['thumb_02_r'].head[2] =  100.912
    objectToSelect.data.edit_bones['thumb_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['thumb_02_r'].tail[0] = -43.7169
    objectToSelect.data.edit_bones['thumb_02_r'].tail[1] = -24.2432
    objectToSelect.data.edit_bones['thumb_02_r'].tail[2] = 102.723
    objectToSelect.data.edit_bones['thumb_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thumb_02_r'].roll = 2.79487
    objectToSelect.data.edit_bones['thumb_02_r'].length =  3.0862
    objectToSelect.data.edit_bones['thumb_02_r'].envelope_distance = 0.25

 

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thumb_03_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['thumb_03_r'].head[0] = -45.0489
    objectToSelect.data.edit_bones['thumb_03_r'].head[1] = -24.2255
    objectToSelect.data.edit_bones['thumb_03_r'].head[2] =  98.5668
    objectToSelect.data.edit_bones['thumb_03_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['thumb_03_r'].tail[0] = -43.5736
    objectToSelect.data.edit_bones['thumb_03_r'].tail[1] = -26.5607
    objectToSelect.data.edit_bones['thumb_03_r'].tail[2] = 99.9428
    objectToSelect.data.edit_bones['thumb_03_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thumb_03_r'].roll = 3.02951
    objectToSelect.data.edit_bones['thumb_03_r'].length =  3.0859
    objectToSelect.data.edit_bones['thumb_03_r'].envelope_distance = 0.25


 
 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("index_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['index_01_r'].head[0] = -50.5319
    objectToSelect.data.edit_bones['index_01_r'].head[1] = -23.7315
    objectToSelect.data.edit_bones['index_01_r'].head[2] =  99.678
    objectToSelect.data.edit_bones['index_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['index_01_r'].tail[0] = -53.4039
    objectToSelect.data.edit_bones['index_01_r'].tail[1] = -25.9691
    objectToSelect.data.edit_bones['index_01_r'].tail[2] = 101.519
    objectToSelect.data.edit_bones['index_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['index_01_r'].roll = -0.296982
    objectToSelect.data.edit_bones['index_01_r'].length =  4.0798
    objectToSelect.data.edit_bones['index_01_r'].envelope_distance = 0.25


  

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("index_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['index_02_r'].head[0] = -50.9922
    objectToSelect.data.edit_bones['index_02_r'].head[1] = -25.9389
    objectToSelect.data.edit_bones['index_02_r'].head[2] =  96.2778
    objectToSelect.data.edit_bones['index_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['index_02_r'].tail[0] = -52.8328
    objectToSelect.data.edit_bones['index_02_r'].tail[1] = -27.6752
    objectToSelect.data.edit_bones['index_02_r'].tail[2] = 96.8539
    objectToSelect.data.edit_bones['index_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['index_02_r'].roll = -0.727794
    objectToSelect.data.edit_bones['index_02_r'].length =  2.5951
    objectToSelect.data.edit_bones['index_02_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("index_03_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 
    
    
    


    objectToSelect.data.edit_bones['index_03_r'].head[0] = -50.8057
    objectToSelect.data.edit_bones['index_03_r'].head[1] = -26.93
    objectToSelect.data.edit_bones['index_03_r'].head[2] =  93.8867
    objectToSelect.data.edit_bones['index_03_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['index_03_r'].tail[0] = -52.5622
    objectToSelect.data.edit_bones['index_03_r'].tail[1] = -28.8398
    objectToSelect.data.edit_bones['index_03_r'].tail[2] = 93.9309
    objectToSelect.data.edit_bones['index_03_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['index_03_r'].roll = -1.20245
    objectToSelect.data.edit_bones['index_03_r'].length = 2.5951
    objectToSelect.data.edit_bones['index_03_r'].envelope_distance = 0.25


  


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("middle_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['middle_01_r'].head[0] = -52.6456
    objectToSelect.data.edit_bones['middle_01_r'].head[1] = -21.9758
    objectToSelect.data.edit_bones['middle_01_r'].head[2] =  99.2218
    objectToSelect.data.edit_bones['middle_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['middle_01_r'].tail[0] = -56.9093
    objectToSelect.data.edit_bones['middle_01_r'].tail[1] = -24.4629
    objectToSelect.data.edit_bones['middle_01_r'].tail[2] = 100.756
    objectToSelect.data.edit_bones['middle_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['middle_01_r'].roll = -0.693576
    objectToSelect.data.edit_bones['middle_01_r'].length = 5.169
    objectToSelect.data.edit_bones['middle_01_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("middle_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['middle_02_r'].head[0] = -52.9672
    objectToSelect.data.edit_bones['middle_02_r'].head[1] = -24.2736
    objectToSelect.data.edit_bones['middle_02_r'].head[2] =  94.6028
    objectToSelect.data.edit_bones['middle_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['middle_02_r'].tail[0] = -54.9299
    objectToSelect.data.edit_bones['middle_02_r'].tail[1] = -25.7767
    objectToSelect.data.edit_bones['middle_02_r'].tail[2] = 94.5054
    objectToSelect.data.edit_bones['middle_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['middle_02_r'].roll = -1.30675
    objectToSelect.data.edit_bones['middle_02_r'].length = 2.4741
    objectToSelect.data.edit_bones['middle_02_r'].envelope_distance = 0.25


  

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("middle_03_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    
    


    objectToSelect.data.edit_bones['middle_03_r'].head[0] = -52.3875
    objectToSelect.data.edit_bones['middle_03_r'].head[1] = -24.8799
    objectToSelect.data.edit_bones['middle_03_r'].head[2] =  92.2753
    objectToSelect.data.edit_bones['middle_03_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['middle_03_r'].tail[0] = -54.2197
    objectToSelect.data.edit_bones['middle_03_r'].tail[1] = -26.4654
    objectToSelect.data.edit_bones['middle_03_r'].tail[2] = 91.7752
    objectToSelect.data.edit_bones['middle_03_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['middle_03_r'].roll = -1.65936
    objectToSelect.data.edit_bones['middle_03_r'].length = 2.474
    objectToSelect.data.edit_bones['middle_03_r'].envelope_distance = 0.25


 
 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ring_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['ring_01_r'].head[0] = -53.6885
    objectToSelect.data.edit_bones['ring_01_r'].head[1] = -19.7768
    objectToSelect.data.edit_bones['ring_01_r'].head[2] =  98.7157
    objectToSelect.data.edit_bones['ring_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ring_01_r'].tail[0] = -58.0824
    objectToSelect.data.edit_bones['ring_01_r'].tail[1] = -21.5626
    objectToSelect.data.edit_bones['ring_01_r'].tail[2] = 100.224
    objectToSelect.data.edit_bones['ring_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ring_01_r'].roll = -0.815866
    objectToSelect.data.edit_bones['ring_01_r'].length = 4.977
    objectToSelect.data.edit_bones['ring_01_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ring_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['ring_02_r'].head[0] = -54.4661
    objectToSelect.data.edit_bones['ring_02_r'].head[1] = -21.689
    objectToSelect.data.edit_bones['ring_02_r'].head[2] =  94.1869
    objectToSelect.data.edit_bones['ring_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ring_02_r'].tail[0] = -56.4722
    objectToSelect.data.edit_bones['ring_02_r'].tail[1] = -22.7404
    objectToSelect.data.edit_bones['ring_02_r'].tail[2] =  94.1663
    objectToSelect.data.edit_bones['ring_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ring_02_r'].roll = -1.29872
    objectToSelect.data.edit_bones['ring_02_r'].length = 2.265
    objectToSelect.data.edit_bones['ring_02_r'].envelope_distance = 0.25

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ring_03_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['ring_03_r'].head[0] = -54.151
    objectToSelect.data.edit_bones['ring_03_r'].head[1] = -22.2479
    objectToSelect.data.edit_bones['ring_03_r'].head[2] =  92.0147
    objectToSelect.data.edit_bones['ring_03_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ring_03_r'].tail[0] = -56.0812
    objectToSelect.data.edit_bones['ring_03_r'].tail[1] = -23.3749
    objectToSelect.data.edit_bones['ring_03_r'].tail[2] =  91.6483
    objectToSelect.data.edit_bones['ring_03_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ring_03_r'].roll = -1.56154
    objectToSelect.data.edit_bones['ring_03_r'].length = 2.265
    objectToSelect.data.edit_bones['ring_03_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pinky_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['pinky_01_r'].head[0] = -53.5398
    objectToSelect.data.edit_bones['pinky_01_r'].head[1] = -17.628
    objectToSelect.data.edit_bones['pinky_01_r'].head[2] = 97.9685
    objectToSelect.data.edit_bones['pinky_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['pinky_01_r'].tail[0] = -57.0901
    objectToSelect.data.edit_bones['pinky_01_r'].tail[1] = -18.2886
    objectToSelect.data.edit_bones['pinky_01_r'].tail[2] =  99.2017
    objectToSelect.data.edit_bones['pinky_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pinky_01_r'].roll = -0.930154
    objectToSelect.data.edit_bones['pinky_01_r'].length = 3.816
    objectToSelect.data.edit_bones['pinky_01_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pinky_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['pinky_02_r'].head[0] = -54.5455
    objectToSelect.data.edit_bones['pinky_02_r'].head[1] = -18.7614
    objectToSelect.data.edit_bones['pinky_02_r'].head[2] = 94.4662
    objectToSelect.data.edit_bones['pinky_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['pinky_02_r'].tail[0] = -56.5092
    objectToSelect.data.edit_bones['pinky_02_r'].tail[1] = -19.3104
    objectToSelect.data.edit_bones['pinky_02_r'].tail[2] =  94.4008
    objectToSelect.data.edit_bones['pinky_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pinky_02_r'].roll = -1.38015
    objectToSelect.data.edit_bones['pinky_02_r'].length =  2.04
    objectToSelect.data.edit_bones['pinky_02_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pinky_03_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['pinky_03_r'].head[0] = -54.3574
    objectToSelect.data.edit_bones['pinky_03_r'].head[1] = -19.1977
    objectToSelect.data.edit_bones['pinky_03_r'].head[2] =  92.4823
    objectToSelect.data.edit_bones['pinky_03_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['pinky_03_r'].tail[0] = -56.2977
    objectToSelect.data.edit_bones['pinky_03_r'].tail[1] = -19.7821
    objectToSelect.data.edit_bones['pinky_03_r'].tail[2] =  92.247
    objectToSelect.data.edit_bones['pinky_03_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pinky_03_r'].roll = -1.49177
    objectToSelect.data.edit_bones['pinky_03_r'].length =  2.04
    objectToSelect.data.edit_bones['pinky_03_r'].envelope_distance = 0.25


 
    #//////Spine


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("pelvis")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['pelvis'].head[0] = -0
    objectToSelect.data.edit_bones['pelvis'].head[1] = -2.2809
    objectToSelect.data.edit_bones['pelvis'].head[2] =  95.8968
    objectToSelect.data.edit_bones['pelvis'].head_radius = 0.1



    objectToSelect.data.edit_bones['pelvis'].tail[0] = -0
    objectToSelect.data.edit_bones['pelvis'].tail[1] = 5.7597
    objectToSelect.data.edit_bones['pelvis'].tail[2] =  95.3862
    objectToSelect.data.edit_bones['pelvis'].tail_radius = 0.05
    objectToSelect.data.edit_bones['pelvis'].roll = -1.5708
    objectToSelect.data.edit_bones['pelvis'].length =  8.0568
    objectToSelect.data.edit_bones['pelvis'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_01")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  


    objectToSelect.data.edit_bones['spine_01'].head[0] = 0
    objectToSelect.data.edit_bones['spine_01'].head[1] = -2.0479
    objectToSelect.data.edit_bones['spine_01'].head[2] = 99.5664
    objectToSelect.data.edit_bones['spine_01'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_01'].tail[0] = 0
    objectToSelect.data.edit_bones['spine_01'].tail[1] = 4.6263
    objectToSelect.data.edit_bones['spine_01'].tail[2] =  100.843
    objectToSelect.data.edit_bones['spine_01'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_01'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_01'].length =  6.7952
    objectToSelect.data.edit_bones['spine_01'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_02")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['spine_02'].head[0] = 0
    objectToSelect.data.edit_bones['spine_02'].head[1] = -3.324
    objectToSelect.data.edit_bones['spine_02'].head[2] = 106.241
    objectToSelect.data.edit_bones['spine_02'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_02'].tail[0] = 0
    objectToSelect.data.edit_bones['spine_02'].tail[1] = 3.8546
    objectToSelect.data.edit_bones['spine_02'].tail[2] =  107.168
    objectToSelect.data.edit_bones['spine_02'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_02'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_02'].length =  7.2382
    objectToSelect.data.edit_bones['spine_02'].envelope_distance = 0.25


 




     
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_03")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
     

    objectToSelect.data.edit_bones['spine_03'].head[0] = 0
    objectToSelect.data.edit_bones['spine_03'].head[1] = -4.2512
    objectToSelect.data.edit_bones['spine_03'].head[2] = 113.419
    objectToSelect.data.edit_bones['spine_03'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_03'].tail[0] = 0
    objectToSelect.data.edit_bones['spine_03'].tail[1] = 4.2561
    objectToSelect.data.edit_bones['spine_03'].tail[2] =  112.886
    objectToSelect.data.edit_bones['spine_03'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_03'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_03'].length =  8.524
    objectToSelect.data.edit_bones['spine_03'].envelope_distance = 0.25


 

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_04")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


  
    


    objectToSelect.data.edit_bones['spine_04'].head[0] = -0
    objectToSelect.data.edit_bones['spine_04'].head[1] = -3.718
    objectToSelect.data.edit_bones['spine_04'].head[2] = 121.926
    objectToSelect.data.edit_bones['spine_04'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_04'].tail[0] = -0.0002
    objectToSelect.data.edit_bones['spine_04'].tail[1] = 15.4578
    objectToSelect.data.edit_bones['spine_04'].tail[2] =  118.734
    objectToSelect.data.edit_bones['spine_04'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_04'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_04'].length = 19.4397
    objectToSelect.data.edit_bones['spine_04'].envelope_distance = 0.25

 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("spine_05")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['spine_05'].head[0] = -0
    objectToSelect.data.edit_bones['spine_05'].head[1] = -0.5251
    objectToSelect.data.edit_bones['spine_05'].head[2] = 141.102
    objectToSelect.data.edit_bones['spine_05'].head_radius = 0.1



    objectToSelect.data.edit_bones['spine_05'].tail[0] = 0
    objectToSelect.data.edit_bones['spine_05'].tail[1] = 7.2133
    objectToSelect.data.edit_bones['spine_05'].tail[2] =  139.719
    objectToSelect.data.edit_bones['spine_05'].tail_radius = 0.05
    objectToSelect.data.edit_bones['spine_05'].roll = -1.5708
    objectToSelect.data.edit_bones['spine_05'].length = 7.861
    objectToSelect.data.edit_bones['spine_05'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("neck_01")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 
    
    


    objectToSelect.data.edit_bones['neck_01'].head[0] = -0
    objectToSelect.data.edit_bones['neck_01'].head[1] = 1.5667
    objectToSelect.data.edit_bones['neck_01'].head[2] = 152.804
    objectToSelect.data.edit_bones['neck_01'].head_radius = 0.1



    objectToSelect.data.edit_bones['neck_01'].tail[0] = 0
    objectToSelect.data.edit_bones['neck_01'].tail[1] = 6.5296
    objectToSelect.data.edit_bones['neck_01'].tail[2] =  154.023
    objectToSelect.data.edit_bones['neck_01'].tail_radius = 0.05
    objectToSelect.data.edit_bones['neck_01'].roll = -1.5708
    objectToSelect.data.edit_bones['neck_01'].length = 5.1104
    objectToSelect.data.edit_bones['neck_01'].envelope_distance = 0.25



    
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("neck_02")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['neck_02'].head[0] = -0
    objectToSelect.data.edit_bones['neck_02'].head[1] = 0.3483
    objectToSelect.data.edit_bones['neck_02'].head[2] = 157.767
    objectToSelect.data.edit_bones['neck_02'].head_radius = 0.1



    objectToSelect.data.edit_bones['neck_02'].tail[0] = 0
    objectToSelect.data.edit_bones['neck_02'].tail[1] = 5.156
    objectToSelect.data.edit_bones['neck_02'].tail[2] = 158.779
    objectToSelect.data.edit_bones['neck_02'].tail_radius = 0.05
    objectToSelect.data.edit_bones['neck_02'].roll = -1.5708
    objectToSelect.data.edit_bones['neck_02'].length = 4.9131
    objectToSelect.data.edit_bones['neck_02'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("head")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



     

    objectToSelect.data.edit_bones['head'].head[0] = -0
    objectToSelect.data.edit_bones['head'].head[1] = -0.6631
    objectToSelect.data.edit_bones['head'].head[2] = 162.575
    objectToSelect.data.edit_bones['head'].head_radius = 0.1



    objectToSelect.data.edit_bones['head'].tail[0] = -0
    objectToSelect.data.edit_bones['head'].tail[1] = 4.2499
    objectToSelect.data.edit_bones['head'].tail[2] = 162.575
    objectToSelect.data.edit_bones['head'].tail_radius = 0.05
    objectToSelect.data.edit_bones['head'].roll = -1.5708
    objectToSelect.data.edit_bones['head'].length = 4.913
    objectToSelect.data.edit_bones['head'].envelope_distance = 0.25



     

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thigh_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



    
    


    objectToSelect.data.edit_bones['thigh_l'].head[0] = 9.9692
    objectToSelect.data.edit_bones['thigh_l'].head[1] = -2.5406
    objectToSelect.data.edit_bones['thigh_l'].head[2] =  93.5428
    objectToSelect.data.edit_bones['thigh_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['thigh_l'].tail[0] = 5.7503
    objectToSelect.data.edit_bones['thigh_l'].tail[1] = 26.0427
    objectToSelect.data.edit_bones['thigh_l'].tail[2] = 93.276
    objectToSelect.data.edit_bones['thigh_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thigh_l'].roll = -1.62525
    objectToSelect.data.edit_bones['thigh_l'].length = 28.8942
    objectToSelect.data.edit_bones['thigh_l'].envelope_distance = 0.25



     
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thigh_twist_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



     
    


    objectToSelect.data.edit_bones['thigh_twist_01_l'].head[0] = 10.7569
    objectToSelect.data.edit_bones['thigh_twist_01_l'].head[1] = -2.559
    objectToSelect.data.edit_bones['thigh_twist_01_l'].head[2] =  79.1172
    objectToSelect.data.edit_bones['thigh_twist_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['thigh_twist_01_l'].tail[0] = 6.5031
    objectToSelect.data.edit_bones['thigh_twist_01_l'].tail[1] = 26.0177
    objectToSelect.data.edit_bones['thigh_twist_01_l'].tail[2] = 79.5087
    objectToSelect.data.edit_bones['thigh_twist_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thigh_twist_01_l'].roll = -1.61907
    objectToSelect.data.edit_bones['thigh_twist_01_l'].length = 28.8942
    objectToSelect.data.edit_bones['thigh_twist_01_l'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thigh_twist_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['thigh_twist_02_l'].head[0] = 11.5446
    objectToSelect.data.edit_bones['thigh_twist_02_l'].head[1] = -2.5773
    objectToSelect.data.edit_bones['thigh_twist_02_l'].head[2] =  64.6916
    objectToSelect.data.edit_bones['thigh_twist_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['thigh_twist_02_l'].tail[0] = 7.2909
    objectToSelect.data.edit_bones['thigh_twist_02_l'].tail[1] = 25.9994
    objectToSelect.data.edit_bones['thigh_twist_02_l'].tail[2] = 65.0831
    objectToSelect.data.edit_bones['thigh_twist_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thigh_twist_02_l'].roll = -1.61907
    objectToSelect.data.edit_bones['thigh_twist_02_l'].length = 28.8942
    objectToSelect.data.edit_bones['thigh_twist_02_l'].envelope_distance = 0.25



     

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("calf_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['calf_l'].head[0] = 12.3323
    objectToSelect.data.edit_bones['calf_l'].head[1] = -2.5957
    objectToSelect.data.edit_bones['calf_l'].head[2] =  50.266
    objectToSelect.data.edit_bones['calf_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['calf_l'].tail[0] = 8.1046
    objectToSelect.data.edit_bones['calf_l'].tail[1] = 25.1437
    objectToSelect.data.edit_bones['calf_l'].tail[2] = 52.4588
    objectToSelect.data.edit_bones['calf_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['calf_l'].roll = -1.61883
    objectToSelect.data.edit_bones['calf_l'].length = 28.1453
    objectToSelect.data.edit_bones['calf_l'].envelope_distance = 0.25



     
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("calf_twist_02_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['calf_twist_02_l'].head[0] = 12.9174
    objectToSelect.data.edit_bones['calf_twist_02_l'].head[1] = -1.3991
    objectToSelect.data.edit_bones['calf_twist_02_l'].head[2] =  36.2565
    objectToSelect.data.edit_bones['calf_twist_02_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['calf_twist_02_l'].tail[0] = 8.7509
    objectToSelect.data.edit_bones['calf_twist_02_l'].tail[1] = 26.4219
    objectToSelect.data.edit_bones['calf_twist_02_l'].tail[2] = 37.1447
    objectToSelect.data.edit_bones['calf_twist_02_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['calf_twist_02_l'].roll = -1.61774
    objectToSelect.data.edit_bones['calf_twist_02_l'].length = 28.1453
    objectToSelect.data.edit_bones['calf_twist_02_l'].envelope_distance = 0.25



     

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("calf_twist_01_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['calf_twist_01_l'].head[0] = 13.5771
    objectToSelect.data.edit_bones['calf_twist_01_l'].head[1] = -0.1914
    objectToSelect.data.edit_bones['calf_twist_01_l'].head[2] =  22.2511
    objectToSelect.data.edit_bones['calf_twist_01_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['calf_twist_01_l'].tail[0] = 9.4105
    objectToSelect.data.edit_bones['calf_twist_01_l'].tail[1] = 27.6296
    objectToSelect.data.edit_bones['calf_twist_01_l'].tail[2] = 23.1393
    objectToSelect.data.edit_bones['calf_twist_01_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['calf_twist_01_l'].roll = -1.61774
    objectToSelect.data.edit_bones['calf_twist_01_l'].length = 28.1453
    objectToSelect.data.edit_bones['calf_twist_01_l'].envelope_distance = 0.25



     

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("foot_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 
    


    objectToSelect.data.edit_bones['foot_l'].head[0] = 14.0877
    objectToSelect.data.edit_bones['foot_l'].head[1] = 0.9943
    objectToSelect.data.edit_bones['foot_l'].head[2] =  8.2376
    objectToSelect.data.edit_bones['foot_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['foot_l'].tail[0] = 11.6034
    objectToSelect.data.edit_bones['foot_l'].tail[1] = 17.582
    objectToSelect.data.edit_bones['foot_l'].tail[2] = 8.7672
    objectToSelect.data.edit_bones['foot_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['foot_l'].roll = -1.56847
    objectToSelect.data.edit_bones['foot_l'].length = 16.7811
    objectToSelect.data.edit_bones['foot_l'].envelope_distance = 0.25



     

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ball_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



     


    objectToSelect.data.edit_bones['ball_l'].head[0] = 15.7779
    objectToSelect.data.edit_bones['ball_l'].head[1] = -13.9288
    objectToSelect.data.edit_bones['ball_l'].head[2] =  0.7508
    objectToSelect.data.edit_bones['ball_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ball_l'].tail[0] = 15.8559
    objectToSelect.data.edit_bones['ball_l'].tail[1] = -14.4526
    objectToSelect.data.edit_bones['ball_l'].tail[2] = 17.5236
    objectToSelect.data.edit_bones['ball_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ball_l'].roll = -1.41742
    objectToSelect.data.edit_bones['ball_l'].length = 16.7812
    objectToSelect.data.edit_bones['ball_l'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thigh_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['thigh_r'].head[0] = -9.9691
    objectToSelect.data.edit_bones['thigh_r'].head[1] = -2.55
    objectToSelect.data.edit_bones['thigh_r'].head[2] =  93.5434
    objectToSelect.data.edit_bones['thigh_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['thigh_r'].tail[0] = -14.188
    objectToSelect.data.edit_bones['thigh_r'].tail[1] = -31.1333
    objectToSelect.data.edit_bones['thigh_r'].tail[2] = 93.8101
    objectToSelect.data.edit_bones['thigh_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thigh_r'].roll = 1.64264
    objectToSelect.data.edit_bones['thigh_r'].length = 28.8942
    objectToSelect.data.edit_bones['thigh_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thigh_twist_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['thigh_twist_01_r'].head[0] = -10.7568
    objectToSelect.data.edit_bones['thigh_twist_01_r'].head[1] = -2.5684
    objectToSelect.data.edit_bones['thigh_twist_01_r'].head[2] =  79.1178
    objectToSelect.data.edit_bones['thigh_twist_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['thigh_twist_01_r'].tail[0] = -15.0106
    objectToSelect.data.edit_bones['thigh_twist_01_r'].tail[1] = -31.1451
    objectToSelect.data.edit_bones['thigh_twist_01_r'].tail[2] = 78.7263
    objectToSelect.data.edit_bones['thigh_twist_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thigh_twist_01_r'].roll = 1.33896
    objectToSelect.data.edit_bones['thigh_twist_01_r'].length = 28.8942
    objectToSelect.data.edit_bones['thigh_twist_01_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("thigh_twist_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    
    


    objectToSelect.data.edit_bones['thigh_twist_02_r'].head[0] = -11.5445
    objectToSelect.data.edit_bones['thigh_twist_02_r'].head[1] = -2.5868
    objectToSelect.data.edit_bones['thigh_twist_02_r'].head[2] = 64.6922
    objectToSelect.data.edit_bones['thigh_twist_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['thigh_twist_02_r'].tail[0] = -15.7983
    objectToSelect.data.edit_bones['thigh_twist_02_r'].tail[1] = -31.1634
    objectToSelect.data.edit_bones['thigh_twist_02_r'].tail[2] = 64.3007
    objectToSelect.data.edit_bones['thigh_twist_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['thigh_twist_02_r'].roll = 1.33896
    objectToSelect.data.edit_bones['thigh_twist_02_r'].length = 28.8941
    objectToSelect.data.edit_bones['thigh_twist_02_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("calf_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['calf_r'].head[0] = -12.3322
    objectToSelect.data.edit_bones['calf_r'].head[1] = -2.6051
    objectToSelect.data.edit_bones['calf_r'].head[2] = 50.2666
    objectToSelect.data.edit_bones['calf_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['calf_r'].tail[0] = -16.56
    objectToSelect.data.edit_bones['calf_r'].tail[1] = -30.3446
    objectToSelect.data.edit_bones['calf_r'].tail[2] = 48.0737
    objectToSelect.data.edit_bones['calf_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['calf_r'].roll = 0.565808
    objectToSelect.data.edit_bones['calf_r'].length = 28.1454
    objectToSelect.data.edit_bones['calf_r'].envelope_distance = 0.25



    
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("calf_twist_02_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 
    


    objectToSelect.data.edit_bones['calf_twist_02_r'].head[0] = -12.9546
    objectToSelect.data.edit_bones['calf_twist_02_r'].head[1] = -1.403
    objectToSelect.data.edit_bones['calf_twist_02_r'].head[2] = 36.2592
    objectToSelect.data.edit_bones['calf_twist_02_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['calf_twist_02_r'].tail[0] = -17.1212
    objectToSelect.data.edit_bones['calf_twist_02_r'].tail[1] = -29.224
    objectToSelect.data.edit_bones['calf_twist_02_r'].tail[2] = 35.371
    objectToSelect.data.edit_bones['calf_twist_02_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['calf_twist_02_r'].roll = 1.10381
    objectToSelect.data.edit_bones['calf_twist_02_r'].length = 28.1453
    objectToSelect.data.edit_bones['calf_twist_02_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("calf_twist_01_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



      
    


    objectToSelect.data.edit_bones['calf_twist_01_r'].head[0] = -13.577
    objectToSelect.data.edit_bones['calf_twist_01_r'].head[1] = -0.2008
    objectToSelect.data.edit_bones['calf_twist_01_r'].head[2] = 22.2517
    objectToSelect.data.edit_bones['calf_twist_01_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['calf_twist_01_r'].tail[0] = -17.7435
    objectToSelect.data.edit_bones['calf_twist_01_r'].tail[1] = -28.0218
    objectToSelect.data.edit_bones['calf_twist_01_r'].tail[2] = 21.3636
    objectToSelect.data.edit_bones['calf_twist_01_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['calf_twist_01_r'].roll = 1.10381
    objectToSelect.data.edit_bones['calf_twist_01_r'].length = 28.1453
    objectToSelect.data.edit_bones['calf_twist_01_r'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("foot_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['foot_r'].head[0] = -14.0876
    objectToSelect.data.edit_bones['foot_r'].head[1] = 0.9848
    objectToSelect.data.edit_bones['foot_r'].head[2] = 8.2382
    objectToSelect.data.edit_bones['foot_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['foot_r'].tail[0] = -16.5718
    objectToSelect.data.edit_bones['foot_r'].tail[1] = -15.603
    objectToSelect.data.edit_bones['foot_r'].tail[2] = 7.7087
    objectToSelect.data.edit_bones['foot_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['foot_r'].roll = 1.15308
    objectToSelect.data.edit_bones['foot_r'].length = 16.7811
    objectToSelect.data.edit_bones['foot_r'].envelope_distance = 0.25

 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ball_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['ball_r'].head[0] = -15.7777
    objectToSelect.data.edit_bones['ball_r'].head[1] = -13.9382
    objectToSelect.data.edit_bones['ball_r'].head[2] = 0.7514
    objectToSelect.data.edit_bones['ball_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ball_r'].tail[0] = -15.6997
    objectToSelect.data.edit_bones['ball_r'].tail[1] = -13.4145
    objectToSelect.data.edit_bones['ball_r'].tail[2] = -16.0214
    objectToSelect.data.edit_bones['ball_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ball_r'].roll = -1.42672
    objectToSelect.data.edit_bones['ball_r'].length = 16.7812
    objectToSelect.data.edit_bones['ball_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ik_hand_root")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['ik_hand_root'].head[0] = 0
    objectToSelect.data.edit_bones['ik_hand_root'].head[1] = 0
    objectToSelect.data.edit_bones['ik_hand_root'].head[2] = 0
    objectToSelect.data.edit_bones['ik_hand_root'].head_radius = 0.1



    objectToSelect.data.edit_bones['ik_hand_root'].tail[0] = 0
    objectToSelect.data.edit_bones['ik_hand_root'].tail[1] = 115.937
    objectToSelect.data.edit_bones['ik_hand_root'].tail[2] = 0
    objectToSelect.data.edit_bones['ik_hand_root'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ik_hand_root'].roll = 0
    objectToSelect.data.edit_bones['ik_hand_root'].length = 115.937
    objectToSelect.data.edit_bones['ik_hand_root'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ik_foot_root")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



     

    objectToSelect.data.edit_bones['ik_foot_root'].head[0] = 0
    objectToSelect.data.edit_bones['ik_foot_root'].head[1] = 0
    objectToSelect.data.edit_bones['ik_foot_root'].head[2] = 0
    objectToSelect.data.edit_bones['ik_foot_root'].head_radius = 0.1



    objectToSelect.data.edit_bones['ik_foot_root'].tail[0] = 0
    objectToSelect.data.edit_bones['ik_foot_root'].tail[1] = 16.3494
    objectToSelect.data.edit_bones['ik_foot_root'].tail[2] = 0
    objectToSelect.data.edit_bones['ik_foot_root'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ik_foot_root'].roll = 0
    objectToSelect.data.edit_bones['ik_foot_root'].length = 16.3494
    objectToSelect.data.edit_bones['ik_foot_root'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("center_of_mass")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['center_of_mass'].head[0] = 0
    objectToSelect.data.edit_bones['center_of_mass'].head[1] = 0
    objectToSelect.data.edit_bones['center_of_mass'].head[2] = 0
    objectToSelect.data.edit_bones['center_of_mass'].head_radius = 0.1



    objectToSelect.data.edit_bones['center_of_mass'].tail[0] = 0
    objectToSelect.data.edit_bones['center_of_mass'].tail[1] = 1
    objectToSelect.data.edit_bones['center_of_mass'].tail[2] = 0
    objectToSelect.data.edit_bones['center_of_mass'].tail_radius = 0.05
    objectToSelect.data.edit_bones['center_of_mass'].roll = 0
    objectToSelect.data.edit_bones['center_of_mass'].length = 1
    objectToSelect.data.edit_bones['center_of_mass'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("interaction")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode



    
    


    objectToSelect.data.edit_bones['interaction'].head[0] = 0
    objectToSelect.data.edit_bones['interaction'].head[1] = 0
    objectToSelect.data.edit_bones['interaction'].head[2] = 0
    objectToSelect.data.edit_bones['interaction'].head_radius = 0.1



    objectToSelect.data.edit_bones['interaction'].tail[0] = 0
    objectToSelect.data.edit_bones['interaction'].tail[1] = 1
    objectToSelect.data.edit_bones['interaction'].tail[2] = 0
    objectToSelect.data.edit_bones['interaction'].tail_radius = 0.05
    objectToSelect.data.edit_bones['interaction'].roll = 0
    objectToSelect.data.edit_bones['interaction'].length = 1
    objectToSelect.data.edit_bones['interaction'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ik_foot_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['ik_foot_r'].head[0] = -14.0876
    objectToSelect.data.edit_bones['ik_foot_r'].head[1] = 0.9848
    objectToSelect.data.edit_bones['ik_foot_r'].head[2] = 8.2382
    objectToSelect.data.edit_bones['ik_foot_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ik_foot_r'].tail[0] = -16.5079
    objectToSelect.data.edit_bones['ik_foot_r'].tail[1] = -15.1762
    objectToSelect.data.edit_bones['ik_foot_r'].tail[2] = 7.7223
    objectToSelect.data.edit_bones['ik_foot_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ik_foot_r'].roll = 1.15308
    objectToSelect.data.edit_bones['ik_foot_r'].length = 16.3494
    objectToSelect.data.edit_bones['ik_foot_r'].envelope_distance = 0.25



     

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ik_foot_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['ik_foot_l'].head[0] = 14.0877
    objectToSelect.data.edit_bones['ik_foot_l'].head[1] = 0.9943
    objectToSelect.data.edit_bones['ik_foot_l'].head[2] = 8.2376
    objectToSelect.data.edit_bones['ik_foot_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ik_foot_l'].tail[0] = 11.6673
    objectToSelect.data.edit_bones['ik_foot_l'].tail[1] = 17.1553
    objectToSelect.data.edit_bones['ik_foot_l'].tail[2] = 8.7536
    objectToSelect.data.edit_bones['ik_foot_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ik_foot_l'].roll = -1.56847
    objectToSelect.data.edit_bones['ik_foot_l'].length = 16.3494
    objectToSelect.data.edit_bones['ik_foot_l'].envelope_distance = 0.25


 

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ik_hand_l")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 


    objectToSelect.data.edit_bones['ik_hand_l'].head[0] = 47.7686
    objectToSelect.data.edit_bones['ik_hand_l'].head[1] = -15.6989
    objectToSelect.data.edit_bones['ik_hand_l'].head[2] = 104.467
    objectToSelect.data.edit_bones['ik_hand_l'].head_radius = 0.1



    objectToSelect.data.edit_bones['ik_hand_l'].tail[0] = 16.9336
    objectToSelect.data.edit_bones['ik_hand_l'].tail[1] = -3.3575
    objectToSelect.data.edit_bones['ik_hand_l'].tail[2] = 70.134
    objectToSelect.data.edit_bones['ik_hand_l'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ik_hand_l'].roll = 1.43187
    objectToSelect.data.edit_bones['ik_hand_l'].length = 47.7688
    objectToSelect.data.edit_bones['ik_hand_l'].envelope_distance = 0.25



    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ik_hand_r")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode


 
    


    objectToSelect.data.edit_bones['ik_hand_r'].head[0] = -47.7683
    objectToSelect.data.edit_bones['ik_hand_r'].head[1] = -15.6988
    objectToSelect.data.edit_bones['ik_hand_r'].head[2] = 104.466
    objectToSelect.data.edit_bones['ik_hand_r'].head_radius = 0.1



    objectToSelect.data.edit_bones['ik_hand_r'].tail[0] = -78.6033
    objectToSelect.data.edit_bones['ik_hand_r'].tail[1] = -28.0401
    objectToSelect.data.edit_bones['ik_hand_r'].tail[2] = 138.799
    objectToSelect.data.edit_bones['ik_hand_r'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ik_hand_r'].roll = -0.0316931
    objectToSelect.data.edit_bones['ik_hand_r'].length = 47.7688
    objectToSelect.data.edit_bones['ik_hand_r'].envelope_distance = 0.25


 
    

    ebs = objectToSelect.data.edit_bones
    eb = ebs.new("ik_hand_gun")
    eb.head = (0, 1, 1) # if the head and tail are the same, the bone is deleted
    eb.tail = (0, 1, 2)    # upon returning to object mode

 

    objectToSelect.data.edit_bones['ik_hand_gun'].head[0] = -47.7683
    objectToSelect.data.edit_bones['ik_hand_gun'].head[1] = -15.6988
    objectToSelect.data.edit_bones['ik_hand_gun'].head[2] = 104.466
    objectToSelect.data.edit_bones['ik_hand_gun'].head_radius = 0.1



    objectToSelect.data.edit_bones['ik_hand_gun'].tail[0] = -78.6033
    objectToSelect.data.edit_bones['ik_hand_gun'].tail[1] = -28.0401
    objectToSelect.data.edit_bones['ik_hand_gun'].tail[2] = 138.799
    objectToSelect.data.edit_bones['ik_hand_gun'].tail_radius = 0.05
    objectToSelect.data.edit_bones['ik_hand_gun'].roll = -0.0316931
    objectToSelect.data.edit_bones['ik_hand_gun'].length = 47.7688
    objectToSelect.data.edit_bones['ik_hand_gun'].envelope_distance = 0.25



    bpy.ops.armature.select_all(action='DESELECT')
    bpy.ops.object.mode_set(mode='OBJECT')


class posemake_op(bpy.types.Operator):
    bl_label = "poseu"
    bl_idname = "posem.pu_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.context.scene.tool_settings.use_keyframe_insert_auto = False
        
        scene = bpy.context.scene
        scene.frame_set(1)


        
                
                
                
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["root"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2

        bpy.ops.object.move_to_collection(collection_index=0)
        
         
        


        
        ##Rest in pose mode
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["root"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.select_all(action='SELECT')
        bpy.ops.pose.rot_clear()
        bpy.ops.pose.loc_clear()
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.view3d.snap_cursor_to_center()
                
                

                
                
                
                
            
                

                 


                        
                
        if mytool.my_bool33 !=False :
    
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["root"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.duplicate()
            bpy.context.active_object.name = 'Rig_AnimRF_Fixt'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Rig_AnimRF_Fixt"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            for obj in bpy.context.selected_objects:
                obj.name = "Rig_AnimRF_Fix"
                obj.data.name = "Rig_AnimRF_Fix"


            
        

        if mytool.my_bool33 !=False :
            
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["root"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.duplicate()
            bpy.context.active_object.name = 'RF_Anime_T'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["RF_Anime_T"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            
            
            for obj in bpy.context.selected_objects:
                obj.name = "RF_Anime_"
                obj.data.name = "RF_Anime_"


        
        
             

        if mytool.my_bool33 !=False :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["root"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            bpy.ops.object.duplicate()
            bpy.context.active_object.name = 'Rig_AnimRF_t'

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["Rig_AnimRF_t"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            for obj in bpy.context.selected_objects:
                obj.name = "Rig_AnimRF"
                obj.data.name = "Rig_AnimRF"

 


        #////////////////////////////////////////////////////////////////


        #Fix ///////////////////////////////

        if mytool.my_bool33 !=False :
            
            armatureFrom = bpy.data.objects['Rig_AnimRF_Fix']
            armatureTo = bpy.data.objects['Rig_AnimRF']

            for boneTo in armatureTo.pose.bones:
                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                if boneFrom == None:
                    continue

                for con in boneTo.constraints:
                    boneTo.constraints.remove(con)

                copy_con = boneTo.constraints.new('COPY_ROTATION')
                copy_con.target = armatureFrom
                copy_con.subtarget = boneFrom.name
                
                copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                copy_con2.target = armatureFrom
                copy_con2.subtarget = boneFrom.name




            armatureFrom = bpy.data.objects['Rig_AnimRF_Fix']
            armatureTo = bpy.data.objects['RF_Anime_']

            for boneTo in armatureTo.pose.bones:
                boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                if boneFrom == None:
                    continue

                for con in boneTo.constraints:
                    boneTo.constraints.remove(con)

                copy_con = boneTo.constraints.new('COPY_ROTATION')
                copy_con.target = armatureFrom
                copy_con.subtarget = boneFrom.name
                
                copy_con2 = boneTo.constraints.new('COPY_LOCATION')
                copy_con2.target = armatureFrom
                copy_con2.subtarget = boneFrom.name


        




            ##Rest
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["root"] 
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect
            bpy.ops.object.location_clear(clear_delta=False)

            if mytool.my_bool33 !=False :

                context = bpy.context
                object = context.object

                #should put checks in to see if you have object animation_data etc

                action = object.animation_data.action  # this is the action that is shown in action editor.

                # the action can be unlinked using.

                object.animation_data.action = None



            
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect = bpy.data.objects["root"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect

            ##Rest in pose mode
            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["root"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2
            ob = bpy.data.objects["root"] 
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='SELECT')
            
            bpy.ops.object.posemode_toggle()

            bpy.ops.pose.loc_clear()
            bpy.ops.pose.rot_clear()

            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')

            if mytool.my_bool33 !=False :

            
                context = bpy.context
                object = context.object

                #should put checks in to see if you have object animation_data etc

                action = object.animation_data.action  # this is the action that is shown in action editor.

                # the action can be unlinked using.

                object.animation_data.action = None

                #//////////////////////////////////////////








 
            


        makeuerig()
    

        

        
        
        
        #layer show
        

         
    
    
    
    
        #***********************************************************************************************
        #***********************************************************************************************

        #UV namimg

        bpy.ops.object.select_all(action='DESELECT')

        # List to store selected mesh objects
        selected_objects = []

        # Iterate through all objects in the scene
        for obj in bpy.context.scene.objects:
            # Check if the object is a mesh
            if obj.type == 'MESH':
                # Check if the object has a parent that is an armature
                if obj.parent and obj.parent.type == 'ARMATURE':
                    obj.select_set(True)
                    selected_objects.append(obj)
                # Check if the object has an Armature modifier
                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                    obj.select_set(True)
                    selected_objects.append(obj)

        # Rename UV maps to "vvv" for all selected objects
        for obj in selected_objects:
            # Set the object as active
            bpy.context.view_layer.objects.active = obj
            # Ensure we are in object mode
            bpy.ops.object.mode_set(mode='OBJECT')
            # Iterate over all UV maps
            for uv_map in obj.data.uv_layers:
                uv_map.name = "UVMap"

        # Optional: print the names of the objects and their UV maps to verify
        for obj in selected_objects:
            print(f"Object: {obj.name}")
            for uv_map in obj.data.uv_layers:
                print(f"  UV Map: {uv_map.name}")


        # UV
            
        

      
        # Clear existing selections
        bpy.ops.object.select_all(action='DESELECT')

        # List to store selected mesh objects
        selected_objects = []

        # Iterate through all objects in the scene
        for obj in bpy.context.scene.objects:
            # Check if the object is a mesh
            if obj.type == 'MESH':
                # Check if the object has a parent that is an armature
                if obj.parent and obj.parent.type == 'ARMATURE':
                    obj.select_set(True)
                    selected_objects.append(obj)
                # Check if the object has an Armature modifier
                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                    obj.select_set(True)
                    selected_objects.append(obj)

        # Check if there are selected objects to join
        if selected_objects:
            # Set the active object to the first selected object
            bpy.context.view_layer.objects.active = selected_objects[0]

            # Join all selected objects into the active object
            bpy.ops.object.join()

            rig = bpy.data.objects["root"]
            for obj in bpy.data.objects:
                if (obj.type == 'MESH' and
                    rig in [m.object for m in obj.modifiers if m.type == 'ARMATURE']
                    )and obj.visible_get():
                    #bpy.ops.object.parent_clear(type='CLEAR')
                    obj.select_set(obj.type == "MESH") 
                    pass        

            for obj in bpy.context.selected_objects:
                bpy.context.view_layer.objects.active = obj
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE':
                    
                        modifier.name ='root'
            
            bpy.ops.object.select_all(action='DESELECT')
            
            
            
            
            
            
            
            
            
            
            
        objectToSelect = bpy.data.objects["root"]
        objectToSelect.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect
        
        
        
        
        armatureFrom = bpy.data.objects['RF_PosRig']
        armatureTo = bpy.data.objects['root']

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)

            copy_con = boneTo.constraints.new('COPY_ROTATION')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name



        ################################################################ new 2024

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        # List of bone names from which to remove the constraint
        bone_names = ["index_metacarpal_l", "middle_metacarpal_l", "ring_metacarpal_l", "pinky_metacarpal_l",
        "index_metacarpal_r","middle_metacarpal_r","ring_metacarpal_r","pinky_metacarpal_r"]

        # Constraint type or name you want to remove
        constraint_type_to_remove = "COPY_ROTATION"  # Change this to the type of constraint you want to remove

        # Make sure you are in object mode and have the armature object selected
        armature = bpy.context.object

        if armature and armature.type == 'ARMATURE':
            # Enter pose mode to access bone constraints
            bpy.ops.object.mode_set(mode='POSE')

            for bone_name in bone_names:
                if bone_name in armature.pose.bones:
                    bone = armature.pose.bones[bone_name]
                    constraints_to_remove = [constraint for constraint in bone.constraints if constraint.type == constraint_type_to_remove]

                    for constraint in constraints_to_remove:
                        bone.constraints.remove(constraint)

            # Switch back to object mode
            bpy.ops.object.mode_set(mode='OBJECT')
        else:
            print("Please select an armature object.")










        # Clear existing selections
        bpy.ops.object.select_all(action='DESELECT')

        # List to store selected mesh objects
        selected_objects = []

        # Iterate through all objects in the scene
        for obj in bpy.context.scene.objects:
            # Check if the object is a mesh
            if obj.type == 'MESH':
                # Check if the object has a parent that is an armature
                if obj.parent and obj.parent.type == 'ARMATURE':
                    obj.select_set(True)
                    selected_objects.append(obj)
                # Check if the object has an Armature modifier
                elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                    obj.select_set(True)
                    selected_objects.append(obj)

        # Check if there are selected objects to join
        if selected_objects:
            # Set the active object to the first selected object
            bpy.context.view_layer.objects.active = selected_objects[0]

            # Join all selected objects into the active object
           
            # Update the view
            bpy.context.view_layer.update()


        bpy.ops.object.modifier_apply_as_shapekey(keep_modifier=True, modifier="root")
    
        obj = bpy.context.active_object


        # Check if the object is a mesh
        if obj.type == 'MESH':

            # Ensure the object has shape keys
            if obj.data.shape_keys:
                # Select the first shape key
                obj.active_shape_key_index = 0
            else:
                print("No shape keys found in the selected object.")
            
            
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.blend_from_shape()
            bpy.ops.mesh.blend_from_shape(shape='root')
            bpy.ops.mesh.select_all(action='DESELECT')
            bpy.ops.object.mode_set(mode='OBJECT')  
                    










        target_obj = bpy.context.active_object

        # Check if the active object is not None and is a mesh
        if target_obj and target_obj.type == 'MESH':

            # Check if the shape key named 'root' exists
            if target_obj.data.shape_keys and 'root' in target_obj.data.shape_keys.key_blocks:
 

                # Set the name of the shape key you want to delete
                shape_key_name = "root"

                # Get the active object
                obj = bpy.context.active_object

                # Check if the object has shape keys
                if obj and obj.data.shape_keys:
                    # Check if the shape key exists
                    if shape_key_name in obj.data.shape_keys.key_blocks:
                        # Select the object and go to Object mode (optional)
                        bpy.context.view_layer.objects.active = obj
                        bpy.ops.object.mode_set(mode='OBJECT')

                        # Set the active shape key to the one you want to delete
                        obj.active_shape_key_index = obj.data.shape_keys.key_blocks.find(shape_key_name)

                        # Delete the active shape key
                        bpy.ops.object.shape_key_remove(all=False)

                        print(f"Shape key '{shape_key_name}' deleted.")
                    else:
                        print(f"Shape key '{shape_key_name}' not found.")
                else:
                    print("No active object or no shape keys.")



        
















        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['hand_r']
        myBone2 = armature.edit_bones['ik_hand_gun']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['hand_r']
        myBone2 = armature.edit_bones['ik_hand_r']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['hand_l']
        myBone2 = armature.edit_bones['ik_hand_l']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['foot_r']
        myBone2 = armature.edit_bones['ik_foot_r']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['foot_l']
        myBone2 = armature.edit_bones['ik_foot_l']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')
                
                
        #***********************************************************************************************
        #***********************************************************************************************         

                
                
        





        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.duplicate()

        bpy.context.active_object.name = 'rig_forunrealVTemp'


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["rig_forunrealVTemp"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        
        
        for obj in bpy.context.selected_objects:
            obj.name = "rig_forunrealV"
            obj.data.name = "rig_forunrealV"
            
                        
        
        


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        bpy.ops.object.duplicate()

        bpy.context.active_object.name = 'Your_Rig_PoseTemp'

        
        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["Your_Rig_PoseTemp"]
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect

        
        
        for obj in bpy.context.selected_objects:
            obj.name = "Your_Rig_Pose"
            obj.data.name = "Your_Rig_Pose"          






           




 
     




        # apply pose ################################################################################
        # apply pose ################################################################################
        # apply pose ################################################################################
            
        objects = bpy.context.scene.objects.keys()
        if  'RF_PosRig' not in objects:
         
            self.report({"WARNING"}, "Ues UE5 Matching Pose First !")
        
        objects = bpy.context.scene.objects.keys()
        if  'RF_PosRig' in objects:
        
            if  "root" !="":
                    
                     

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["root"]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.context.object.hide_viewport = False
                    bpy.context.object.hide_render = False
                    bpy.context.object.hide_set(False)
                    bpy.context.object.hide_select = False 
                    
                    
                    
                    #Set Armature to OBJECT mode
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["root"]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    bpy.ops.object.mode_set(mode='OBJECT')
                    
                    
                        


                     

                    #///Apply  pose

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["root"]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    #Mirror 
                    bpy.context.object.data.use_mirror_x = False
                    
                    ob = bpy.data.objects["root"] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    armatureFrom = bpy.data.objects["root"]
                    armatureTo = bpy.data.objects["root"]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)









                    #///Apply  pose 2

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["Your_Rig_Pose"]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects["Your_Rig_Pose"] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    armatureFrom = bpy.data.objects["Your_Rig_Pose"]
                    armatureTo = bpy.data.objects["Your_Rig_Pose"]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)






                #///Apply  pose 3

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["rig_forunrealV"]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2
                    ob = bpy.data.objects["rig_forunrealV"] 
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='SELECT')
                    
                    bpy.ops.object.posemode_toggle()

                    bpy.ops.pose.armature_apply(selected=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    bpy.ops.object.mode_set(mode='OBJECT')





                    armatureFrom = bpy.data.objects["rig_forunrealV"]
                    armatureTo = bpy.data.objects["rig_forunrealV"]

                    for boneTo in armatureTo.pose.bones:
                        boneFrom = armatureFrom.pose.bones.get(boneTo.name)
                        if boneFrom == None:
                            continue

                        for con in boneTo.constraints:
                            boneTo.constraints.remove(con)







            
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["rig_forunrealV"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    

                    bpy.ops.object.delete(use_global=False)



                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["root"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.duplicate()

                    bpy.context.active_object.name = 'rig_forunrealVTemp'

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["rig_forunrealVTemp"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    
                    
                    for obj in bpy.context.selected_objects:
                        obj.name = "rig_forunrealV"
                        obj.data.name = "rig_forunrealV"
                        
                                    
                    
                    




                    #make  Your_Rig_Pose rig for pose
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["Your_Rig_Pose"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    

                    bpy.ops.object.delete(use_global=False)



                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["root"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    bpy.ops.object.duplicate()
                    bpy.context.active_object.name = 'Your_Rig_PoseTemp'

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["Your_Rig_PoseTemp"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect

                    
                    
                    for obj in bpy.context.selected_objects:
                        obj.name = "Your_Rig_Pose"
                        obj.data.name = "Your_Rig_Pose"





                    
                    objects = bpy.context.scene.objects.keys()
                    if  'RF_PosRig' in objects:
                    
                    




                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["RF_PosRig"]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        bpy.ops.object.delete(use_global=False)



 

 
 







                    #make  Your_Rig_Pose rig for pose
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["Your_Rig_Pose"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    

                    bpy.ops.object.delete(use_global=False)




    
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect = bpy.data.objects["rig_forunrealV"]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    

                    bpy.ops.object.delete(use_global=False)

                    
                    



                 



                    
                    
                    
                    
                    bpy.ops.view3d.snap_cursor_to_center()



                    bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0), scale=(1, 1, 1))
                    bpy.context.active_object.name = 'RF_To_Ues_PosMatching'


                   


                    if mytool.my_bool33 !=False or  mytool.my_bool34 !=False: 
                
                    
                    
                        
                        #make rig for Anim //////////////////////////////////////////////////////
                        #Apply  transforms_to_deltas For Anime  
                        ##Rest
                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["root"] 
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        bpy.ops.object.location_clear(clear_delta=False)
                        


                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["root"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        
                        

                            

                        
                        #Rig RF For Anime 
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["root"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        bpy.ops.object.duplicate()
                        bpy.context.active_object.name = 'RF_For_Animation_t'

                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["RF_For_Animation_t"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect



                        for obj in bpy.context.selected_objects:
                            obj.name = "RF_For_Animation"
                            obj.data.name = "RF_For_Animation"
                        

                        ##Rest
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["RF_For_Animation"] 
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect
                        bpy.ops.object.location_clear(clear_delta=False)

                        if mytool.my_bool33 !=False :

                            context = bpy.context
                            object = context.object

                            #should put checks in to see if you have object animation_data etc

                            action = object.animation_data.action  # this is the action that is shown in action editor.

                            # the action can be unlinked using.

                            object.animation_data.action = None



                        
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect = bpy.data.objects["RF_For_Animation"]
                        objectToSelect.select_set(True)    
                        bpy.context.view_layer.objects.active = objectToSelect

                        ##Rest in pose mode
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects["RF_For_Animation"]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2
                        ob = bpy.data.objects["RF_For_Animation"] 
                        armature = ob.data
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='SELECT')
                        
                        bpy.ops.object.posemode_toggle()

                        bpy.ops.pose.loc_clear()
                        bpy.ops.pose.rot_clear()

                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.armature.select_all(action='DESELECT')
                        bpy.ops.object.mode_set(mode='OBJECT')

                        if mytool.my_bool33 !=False :

                        
                            context = bpy.context
                            object = context.object

                            #should put checks in to see if you have object animation_data etc

                            action = object.animation_data.action  # this is the action that is shown in action editor.

                            # the action can be unlinked using.

                            object.animation_data.action = None

                            #//////////////////////////////////////////


                         

                         



 




        
        return {'FINISHED'}
    
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)
    




class animpose_only_op(bpy.types.Operator):
    bl_label = "Apply"
    bl_idname = "animposeo.m_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

       


        # Get the object named "root"
        objectToSelect = bpy.data.objects.get("root")

        # Check if the object exists
        if objectToSelect:
            # Select the object
            objectToSelect.select_set(True)

            # Set the active object
            bpy.context.view_layer.objects.active = objectToSelect

            # Clear object location
            bpy.ops.object.location_clear(clear_delta=False)

            # Check if the object has animation data
            if objectToSelect.animation_data:
                # Get the action from animation data
                action = objectToSelect.animation_data.action

                # Check if the object has an action
                if action:
                    # Unlink the action
                    objectToSelect.animation_data.action = None
                    print(f"Action unlinked for object: {objectToSelect.name}")
                else:
                    print(f"No action found for object: {objectToSelect.name}")
            else:
                print(f"No animation data found for object: {objectToSelect.name}")
        else:
            print("Object 'root' not found.")








        makeuerig()

        armatureFrom = bpy.data.objects['RF_PosRig']
        armatureTo = bpy.data.objects['root']

        for boneTo in armatureTo.pose.bones:
            boneFrom = armatureFrom.pose.bones.get(boneTo.name)
            if boneFrom == None:
                continue

            for con in boneTo.constraints:
                boneTo.constraints.remove(con)

            copy_con = boneTo.constraints.new('COPY_ROTATION')
            copy_con.target = armatureFrom
            copy_con.subtarget = boneFrom.name

        ################################################################ new 2024

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        # List of bone names from which to remove the constraint
        bone_names = ["index_metacarpal_l", "middle_metacarpal_l", "ring_metacarpal_l", "pinky_metacarpal_l",
        "index_metacarpal_r","middle_metacarpal_r","ring_metacarpal_r","pinky_metacarpal_r"]

        # Constraint type or name you want to remove
        constraint_type_to_remove = "COPY_ROTATION"  # Change this to the type of constraint you want to remove

        # Make sure you are in object mode and have the armature object selected
        armature = bpy.context.object

        if armature and armature.type == 'ARMATURE':
            # Enter pose mode to access bone constraints
            bpy.ops.object.mode_set(mode='POSE')

            for bone_name in bone_names:
                if bone_name in armature.pose.bones:
                    bone = armature.pose.bones[bone_name]
                    constraints_to_remove = [constraint for constraint in bone.constraints if constraint.type == constraint_type_to_remove]

                    for constraint in constraints_to_remove:
                        bone.constraints.remove(constraint)

            # Switch back to object mode
            bpy.ops.object.mode_set(mode='OBJECT')
        else:
            print("Please select an armature object.")


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['hand_r']
        myBone2 = armature.edit_bones['ik_hand_gun']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['hand_r']
        myBone2 = armature.edit_bones['ik_hand_r']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['hand_l']
        myBone2 = armature.edit_bones['ik_hand_l']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['foot_r']
        myBone2 = armature.edit_bones['ik_foot_r']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')




        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect = bpy.data.objects["root"] 
        objectToSelect.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect
        
        ob = bpy.data.objects["root"]
        armature = ob.data
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        myBone = armature.edit_bones['foot_l']
        myBone2 = armature.edit_bones['ik_foot_l']
        myBone.select = True
        myBone2.select = True
        armature.edit_bones.active = myBone2
        bpy.ops.object.posemode_toggle()
        bpy.ops.pose.constraint_add_with_targets(type='COPY_LOCATION')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.armature.select_all(action='DESELECT')
        bpy.ops.object.mode_set(mode='OBJECT')


        













        if mytool.ueposea_anpose !=False :
            objectToSelect = bpy.data.objects["root"]
            objectToSelect.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect


            ob = bpy.data.objects['root']
            armature = ob.data
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.armature.select_all(action='SELECT')
            myBone = armature.edit_bones["pelvis"]
            myBone.select = True
            armature.edit_bones.active = myBone
            bpy.ops.object.mode_set(mode='POSE')
            bpy.ops.nla.bake(frame_start=1, frame_end=2, step=1, only_selected=True, visual_keying=True, clear_constraints=True, clear_parents=True, use_current_action=True, clean_curves=True, bake_types={'POSE'})
            bpy.ops.object.mode_set(mode='OBJECT')


        objects = bpy.context.scene.objects.keys()
        if  'RF_PosRig' in objects :

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["RF_PosRig"]
            objectToSelect2.select_set(True)    
            bpy.context.view_layer.objects.active = objectToSelect2
            bpy.ops.object.delete(use_global=False)
            bpy.ops.object.select_all(action='DESELECT')
         


        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["root"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        
        # Get the active object
        obj = bpy.context.object

        # Get the action data of the object
        action_data = obj.animation_data

        # Get the action of the object
        action = action_data.action

        # Print the name of the action
        print(action.name)
                
        bpy.data.actions[action.name].use_fake_user = True
        bpy.data.actions[action.name].name = "UE5_Pose_For_IKRetar"



        



        
        bpy.data.actions["UE5_Pose_For_IKRetar"].use_fake_user = True
         


    

        for action in bpy.data.actions:
            if not action.use_fake_user:
                bpy.data.actions.remove(action)
             




        if mytool.my_bool33 !=False : 

            # Select the object named "root"
            object_to_select = bpy.data.objects["root"]
            object_to_select.select_set(True)
            bpy.context.view_layer.objects.active = object_to_select

            # Get the active object
            obj = bpy.context.object

            # Set the desired action name
            desired_action_name = "Animation"

            # Check if the desired action exists in the actions
            if desired_action_name in bpy.data.actions:
                # Set the action of the object to the desired action
                obj.animation_data.action = bpy.data.actions[desired_action_name]
                print(f"Object's action set to: {desired_action_name}")
            else:
                print(f"Action named {desired_action_name} not found.")









       


        
        
        return {'FINISHED'}
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)



class expoer_fbx_op(bpy.types.Operator):
    bl_label = "Apply"
    bl_idname = "exportfbxf.m_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.ops.screen.frame_jump(end=False)

        objects = bpy.context.scene.objects.keys()
        if  'root' in objects:





            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects["root"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2



            # Clear existing selections
            bpy.ops.object.select_all(action='DESELECT')

            # List to store selected mesh objects
            selected_objects = []

            # Iterate through all objects in the scene
            for obj in bpy.context.scene.objects:
                # Check if the object is a mesh
                if obj.type == 'MESH':
                    # Check if the object has a parent that is an armature
                    if obj.parent and obj.parent.type == 'ARMATURE':
                        obj.select_set(True)
                        selected_objects.append(obj)
                    # Check if the object has an Armature modifier
                    elif any(mod.type == 'ARMATURE' for mod in obj.modifiers):
                        obj.select_set(True)
                        selected_objects.append(obj)

            # Check if there are selected objects to join
            if selected_objects:
                # Set the active object to the first selected object
                bpy.context.view_layer.objects.active = selected_objects[0]

                # Join all selected objects into the active object

            objectToSelect2 = bpy.data.objects["root"]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2



            use_selection = True
            use_armature_deform_only = True
            add_leaf_bones = False


            object_types = {'ARMATURE', 'MESH'}
            mesh_smooth_type = 'EDGE'

            # Invoke the FBX export operation
            bpy.ops.export_scene.fbx(
                'INVOKE_DEFAULT',
                use_selection=use_selection,
                use_armature_deform_only=use_armature_deform_only,
                add_leaf_bones=add_leaf_bones,
                mesh_smooth_type=mesh_smooth_type,
                object_types=object_types
            )

       
 
       


        
        
        return {'FINISHED'}
    
         

 











































