import bpy



 
class autoscale_OT_op(bpy.types.Operator):
    bl_label = "Apply Scale"
    bl_idname = "autoscale.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene


        if bpy.context.object.scale[0] > 1:

            bpy.ops.object.select_all(action='DESELECT')
            objectToSelect2 = bpy.data.objects[sce.Armature_Target]
            objectToSelect2.select_set(True)
            bpy.context.view_layer.objects.active = objectToSelect2


            #check if character has animation 
            obj = bpy.context.active_object
            # Collect places where animation/driver data possibly present.
            keyable_list = [getattr(obj.data, 'shape_keys', None)]
            for ms in obj.material_slots:
                if not ms:
                    continue
                keyable_list.append(ms.material)
                for ts in ms.material.texture_slots:
                    if not ts:
                        continue
                    keyable_list.append(ts.texture)
            for ps in obj.particle_systems:
                keyable_list.append(ps.settings)
            keyable_list.append(obj)
            keyable_list.append(obj.data)

            # Print data paths of available animation/driver f-curves.
            for keyable in keyable_list:
                if not keyable or not keyable.animation_data:
                    continue
                action = keyable.animation_data.action
                for fc in keyable.animation_data.drivers:
                    print(fc.data_path)
                if action:
                    print("ok")


                #check if character has animation 


                    if mytool.my_bool35 !=False :
                        #SET bones TO offset   
                        bpy.ops.object.select_all(action='DESELECT')
                        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                        objectToSelect2.select_set(True)
                        bpy.context.view_layer.objects.active = objectToSelect2


                        from bpy import context

                        obj = context.object

                        bpy.ops.object.mode_set(mode='EDIT')

                        for bone in obj.data.edit_bones:
                            bone.use_connect = False
                        

                        bpy.ops.object.mode_set(mode='OBJECT')

            

            

                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects[sce.Armature_Target]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2

                    objectToSelect = bpy.data.objects[sce.Armature_Target]
                    objectToSelect.select_set(True)    
                    bpy.context.view_layer.objects.active = objectToSelect
                    ob = bpy.data.objects[sce.Armature_Target]
                    armature = ob.data
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.armature.select_all(action='DESELECT')
                    myBone = armature.edit_bones[sce.bone_targetHip]
                    myBone.select = True
                    armature.edit_bones.active = myBone
                    bpy.ops.object.mode_set(mode='OBJECT')


                    #########################################


                    context = bpy.context

                    ob = context.object
                    action = ob.animation_data.action

                    to_bake = ("location",)

                    fcs = (fc for fc in action.fcurves 
                        if any(fc.data_path.endswith(p) for p in to_bake))

                    for fc in fcs:
                        
                        for c in fcs:

                            keyframes = c.keyframe_points

                            for fc in keyframes:
                        
                                

                                fc.co.y *= bpy.context.object.scale[0]
            

                
                    #bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        
        
        return {'FINISHED'}
  
class autoscaleroot_OT_op(bpy.types.Operator):
    bl_label = "Apply Scale"
    bl_idname = "autoscaleroot.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene

        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["root"]
        objectToSelect2.select_set(True)
        bpy.context.view_layer.objects.active = objectToSelect2


        #check if character has animation 
        obj = bpy.context.active_object
        # Collect places where animation/driver data possibly present.
        keyable_list = [getattr(obj.data, 'shape_keys', None)]
        for ms in obj.material_slots:
            if not ms:
                continue
            keyable_list.append(ms.material)
            for ts in ms.material.texture_slots:
                if not ts:
                    continue
                keyable_list.append(ts.texture)
        for ps in obj.particle_systems:
            keyable_list.append(ps.settings)
        keyable_list.append(obj)
        keyable_list.append(obj.data)

        # Print data paths of available animation/driver f-curves.
        for keyable in keyable_list:
            if not keyable or not keyable.animation_data:
                continue
            action = keyable.animation_data.action
            for fc in keyable.animation_data.drivers:
                print(fc.data_path)
            if action:
                print("ok")


            #check if character has animation 


                if mytool.my_bool35 !=False :
                    #SET bones TO offset   
                    bpy.ops.object.select_all(action='DESELECT')
                    objectToSelect2 = bpy.data.objects["root"]
                    objectToSelect2.select_set(True)
                    bpy.context.view_layer.objects.active = objectToSelect2


                    from bpy import context

                    obj = context.object

                    bpy.ops.object.mode_set(mode='EDIT')

                    for bone in obj.data.edit_bones:
                        bone.use_connect = False
                    

                    bpy.ops.object.mode_set(mode='OBJECT')

        

        

                bpy.ops.object.select_all(action='DESELECT')
                objectToSelect2 = bpy.data.objects["root"]
                objectToSelect2.select_set(True)
                bpy.context.view_layer.objects.active = objectToSelect2

                objectToSelect = bpy.data.objects["root"]
                objectToSelect.select_set(True)    
                bpy.context.view_layer.objects.active = objectToSelect
                ob = bpy.data.objects["root"]
                armature = ob.data
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.armature.select_all(action='DESELECT')
                myBone = armature.edit_bones["pelvis"]
                myBone.select = True
                armature.edit_bones.active = myBone
                bpy.ops.object.mode_set(mode='OBJECT')


                #########################################


                context = bpy.context

                ob = context.object
                action = ob.animation_data.action

                to_bake = ("location",)

                fcs = (fc for fc in action.fcurves 
                    if any(fc.data_path.endswith(p) for p in to_bake))

                for fc in fcs:
                    
                    for c in fcs:

                        keyframes = c.keyframe_points

                        for fc in keyframes:
                    
                            

                            fc.co.y *= bpy.context.object.scale[0]
        

            
                #bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
       
       
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        
        
        return {'FINISHED'}
  






