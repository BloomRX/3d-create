


import bpy

import math











class daz_OT_op(bpy.types.Operator):
    bl_label = "Apply"
    bl_idname = "dazappl.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects["root"]
        objectToSelect2.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect2

        


        # Iterate through all objects in the scene
        for obj in bpy.context.scene.objects:
            # Check if the object has an Armature modifier
            if obj.type == 'MESH':
                for modifier in obj.modifiers:
                    if modifier.type == 'ARMATURE':
                        # Rename the Armature modifier to "gg"
                        modifier.name = "Genesis9"





        # Set the name of the rig object
        rig_name = "root"

        # Get a reference to the rig object
        rig_object = bpy.data.objects.get(rig_name)

        if rig_object is not None:
            # Iterate through all objects in the scene
            for obj in bpy.context.scene.objects:
                # Check if the object is an empty and has children (meshes)
                if obj.type == 'EMPTY' and obj.children:
                    # Iterate through the children (meshes) of the empty
                    for child in obj.children:
                        # Unparent the mesh from the empty
                        child.parent = None
                        # Parent the mesh to the rig
                        child.parent = rig_object












        # Get the active armature (rig)
        rig = bpy.context.active_object

        # Create a list to store the names of selected mesh objects
        selected_meshes = []

        # Check if the active object is an armature
        if rig and rig.type == 'ARMATURE':
            # Iterate through all objects in the scene
            for obj in bpy.context.scene.objects:
                # Check if the object is a mesh, has the rig as its parent, and has an Armature modifier
                if (
                    obj.type == 'MESH'
                    and obj.modifiers.get("Genesis9") is not None
                ):
                    selected_meshes.append(obj)

            # Deselect all objects
            bpy.ops.object.select_all(action='DESELECT')

            # Select the found mesh objects and clear location
            for obj in selected_meshes:
                obj.select_set(True)
                bpy.context.view_layer.objects.active = obj  # Set the active object
                bpy.ops.object.location_clear(clear_delta=False)
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)















        # bpy.ops.object.select_all(action='DESELECT')
        # objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        # objectToSelect2.select_set(True)    
        # bpy.context.view_layer.objects.active = objectToSelect2



        
        # # Set the name of the rig object
        # rig_name = sce.Armature_Target

        # # Get a reference to the rig object
        # rig_object = bpy.data.objects.get(rig_name)

        # if rig_object is not None:
        #     # Iterate through all objects in the scene
        #     for obj in bpy.context.scene.objects:
        #         # Check if the object is an empty and has children (meshes)
        #         if obj.type == 'EMPTY' and obj.children:
        #             # Iterate through the children (meshes) of the empty
        #             for child in obj.children:
        #                 # Unparent the mesh from the empty
        #                 child.parent = None
        #                 # Parent the mesh to the rig
        #                 child.parent = rig_object






 


        # # Iterate through all objects in the scene
        # for obj in bpy.context.scene.objects:
        #     # Check if the object has an Armature modifier
        #     if obj.type == 'MESH':
        #         for modifier in obj.modifiers:
        #             if modifier.type == 'ARMATURE':
        #                 # Rename the Armature modifier to "gg"
        #                 modifier.name = "Genesis9"




        # # Get the active armature (rig)
        # rig = bpy.context.active_object

        # # Create a list to store the names of selected mesh objects
        # selected_meshes = []

        # # Check if the active object is an armature
        # if rig and rig.type == 'ARMATURE':
        #     # Iterate through all objects in the scene
        #     for obj in bpy.context.scene.objects:
        #         # Check if the object is a mesh, has the rig as its parent, and has an Armature modifier
        #         if (
        #             obj.type == 'MESH'
        #             and obj.modifiers.get("Genesis9") is not None
        #         ):
        #             selected_meshes.append(obj)

        #     # Deselect all objects
        #     bpy.ops.object.select_all(action='DESELECT')

        #     # Select the found mesh objects and clear location
        #     for obj in selected_meshes:
        #         obj.select_set(True)
        #         bpy.context.view_layer.objects.active = obj  # Set the active object
        #         bpy.ops.object.location_clear(clear_delta=False)
        #         bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)





        
        
        return {'FINISHED'}
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)






class fixloc_OT_op(bpy.types.Operator):
    bl_label = "Apply"
    bl_idname = "fixlocdaz.myop_operator"
    bl_options = {'REGISTER', 'UNDO'} 
    
    
    def execute(self, context):
        scene = context.scene
        mytool = scene.my_tool
        sce = context.scene



        bpy.ops.object.select_all(action='DESELECT')
        objectToSelect2 = bpy.data.objects[sce.Armature_Target]
        objectToSelect2.select_set(True)    
        bpy.context.view_layer.objects.active = objectToSelect2

        


        # Replace 'RigObjectName' with the name of your rig object
        rig_object_name = sce.Armature_Target

        # Function to recursively select objects
        def select_objects_with_parent(obj):
            # Check if the object is a mesh and has the specified rig object as its ultimate parent
            if obj.type == 'MESH' and is_ultimate_parent(obj, rig_object_name):
                obj.select_set(True)
            
            # Recursively check children
            for child in obj.children:
                select_objects_with_parent(child)

        # Function to check if an object's ultimate parent is the rig object
        def is_ultimate_parent(obj, rig_name):
            parent = obj.parent
            while parent:
                if parent.name == rig_name:
                    return True
                parent = parent.parent
            return False

        # Get the rig object
        rig_object = bpy.data.objects.get(rig_object_name)

        if rig_object:
            # Clear the current selection
            bpy.ops.object.select_all(action='DESELECT')
            
            # Call the recursive function starting from the rig object
            select_objects_with_parent(rig_object)
            
            # Iterate through selected objects
            for obj in bpy.context.selected_objects:
                bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)





        # Name of the rig object to which the selected mesh objects will be parented
        rig_object_name = sce.Armature_Target

        # Check if the rig object exists in the scene
        if rig_object_name in bpy.data.objects:
            # Get the rig object
            rig_object = bpy.data.objects[rig_object_name]

            # Get a list of all currently selected objects
            selected_objects = bpy.context.selected_objects

            # Iterate through the selected objects
            for selected_object in selected_objects:
                # Check if the selected object is a mesh object
                if selected_object.type == 'MESH':
                    # Set the rig object as the active object
                    bpy.context.view_layer.objects.active = rig_object

                    # Parent the selected mesh object to the rig object
                    bpy.ops.object.parent_set(type='OBJECT')
                else:
                    print(f"Object '{selected_object.name}' is not a mesh and will not be parented to the rig.")
        else:
            print(f"Rig object named '{rig_object_name}' not found in the scene.")






        
        
        return {'FINISHED'}
    def invoke(self, context, event):
        
        return context.window_manager.invoke_props_dialog(self)

