bl_info = {
    "name": "Professional Hair Suite",
    "author": "CGIAGE (Baddor)",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Pro Hair Suite",
    "description": "Complete suite of professional hair tools for Blender",
    "category": "3D View",
    "doc_url": "https://baddor.gumroad.com/",
}

import bpy
from . import hair_direction_tools
from . import hair_cards_converter

class VIEW3D_PT_pro_hair_suite(bpy.types.Panel):
    bl_label = "Pro Hair Suite"
    bl_idname = "VIEW3D_PT_pro_hair_suite"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Pro Hair Suite"

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Professional Hair Tools", icon='OUTLINER_OB_CURVES')
        box.operator("wm.url_open", text="Get More Tools", icon='URL').url = "https://baddor.gumroad.com/"

def register():
    bpy.utils.register_class(VIEW3D_PT_pro_hair_suite)
    hair_direction_tools.register()
    hair_cards_converter.register()

def unregister():
    bpy.utils.unregister_class(VIEW3D_PT_pro_hair_suite)
    hair_direction_tools.unregister()
    hair_cards_converter.unregister()

if __name__ == "__main__":
    register()
