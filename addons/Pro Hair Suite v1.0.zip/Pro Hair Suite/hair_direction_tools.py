bl_info = {
    "name": "Hair Direction Tools",
    "author": "CGIAGE",
    "version": (1, 0),
    "blender": (4, 0, 0),
    "category": "Object",
}

import bpy
from mathutils import Vector

# ─── Scene Properties ─────────────────────────────────────────────────────
def init_props():
    bpy.types.Scene.hair_direction = bpy.props.FloatVectorProperty(
        name="Direction",
        description="Target direction for hair tips",
        default=(0.0, 0.0, -1.0),  # Default down
        subtype='DIRECTION'
    )

def clear_props():
    if hasattr(bpy.types.Scene, "hair_direction"):
        del bpy.types.Scene.hair_direction

# ─── Helpers ───────────────────────────────────────────────────────────────
def _get_local_pt(pt):
    # old CurvePoint or new HairPoint
    if hasattr(pt, "co"):
        v = pt.co
        return v.xyz if hasattr(v, "xyz") else v
    if hasattr(pt, "position"):
        return pt.position
    return None

def _get_point_position(pt):
    """Get position from either CurvePoint or regular point"""
    return getattr(pt, "position", None) or getattr(pt, "co", None)

def _reverse_bezier(spline):
    pts    = spline.bezier_points
    coords = [p.co.copy()           for p in pts][::-1]
    hl     = [p.handle_left.copy()  for p in pts][::-1]
    hr     = [p.handle_right.copy() for p in pts][::-1]
    for i, p in enumerate(pts):
        p.co           = coords[i]
        p.handle_left  = hl[i]
        p.handle_right = hr[i]

def _reverse_poly(spline):
    pts    = spline.points
    coords = [p.co.copy() for p in pts][::-1]
    for i, p in enumerate(pts):
        p.co = coords[i]

def _reverse_hair_strand(data, s, e):
    pts = data.points
    # Use position instead of co for Blender 4.5
    positions = [pts[i].position.copy() for i in range(s, e)][::-1]
    tilts = [getattr(pts[i], "tilt", 0.0) for i in range(s, e)][::-1]
    
    for j, idx in enumerate(range(s, e)):
        pts[idx].position = positions[j]
        # Only set tilt if it exists
        if hasattr(pts[idx], "tilt"):
            pts[idx].tilt = tilts[j]

# ─── Core Flip Logic ───────────────────────────────────────────────────────
def flip_strands(ctx):
    objs_seen = strands_seen = flipped = 0
    target_dir = Vector(ctx.scene.hair_direction).normalized()
    
    print("\n=== Hair Direction Debug ===")
    print(f"Target direction: {target_dir}")
    
    for obj in ctx.selected_objects:
        print(f"\nChecking object: {obj.name} (Type: {obj.type})")
        
        if obj.type != 'CURVES':
            continue
        
        data = obj.data
        if not hasattr(data, "points"):
            continue
            
        # Get curve data and offsets - fixed conversion
        points = data.points
        offsets = [x.value for x in data.curve_offset_data]  # Access .value property directly
        
        if not points or not offsets:
            continue
            
        print(f"Found {len(points)} points")
        print(f"Found {len(offsets)} offset values")
        
        objs_seen += 1
        mw = obj.matrix_world
        
        # Process each strand using offsets
        for i in range(len(offsets) - 1):
            start = offsets[i]
            end = offsets[i + 1]
            length = end - start
            
            if length < 2:
                continue
                
            strands_seen += 1
            
            # Get root and tip points using new helper
            root_pos = _get_point_position(points[start])
            tip_pos = _get_point_position(points[end - 1])
            
            if not root_pos or not tip_pos:
                continue
                
            # Transform to world space and get direction
            root_world = mw @ root_pos
            tip_world = mw @ tip_pos
            strand_dir = (tip_world - root_world).normalized()
            
            dot = strand_dir.dot(target_dir)
            print(f"Strand {i}: length={length}, dot={dot:.2f}")
            
            if dot < 0:
                print(f"Flipping strand {i}")
                _reverse_hair_strand(data, start, end)
                flipped += 1
    
    print(f"\nFinal results: Objects={objs_seen}, Strands={strands_seen}, Flipped={flipped}")
    return objs_seen, strands_seen, flipped

# ─── UI Panel & Operators ─────────────────────────────────────────────────
class HAIRDIR_PT_panel(bpy.types.Panel):
    bl_label = "Hair Direction Tools"
    bl_idname = "VIEW3D_PT_hairdir"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Pro Hair Suite"
    bl_parent_id = "VIEW3D_PT_pro_hair_suite"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.prop(context.scene, "hair_direction")
        box.operator("hairdir.align", text="Align Hair", icon='CURVE_PATH')

class HAIRDIR_OT_align(bpy.types.Operator):
    bl_idname = "hairdir.align"
    bl_label = "Align Hair Direction"
    
    def execute(self, context):
        o, s, f = flip_strands(context)
        self.report({'INFO'}, f"Objects: {o}, Strands: {s}, Flipped: {f}")
        return {'FINISHED'}

# ─── Registration ─────────────────────────────────────────────────────────
classes = (
    HAIRDIR_PT_panel,
    HAIRDIR_OT_align,
)

def register():
    init_props()
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    clear_props()
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    print("This file is part of Pro Hair Suite addon")