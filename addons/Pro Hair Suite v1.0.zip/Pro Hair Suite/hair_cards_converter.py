bl_info = {
    "name": "Hair Cards Converter",
    "author": "CGIAGE",
    "version": (1, 0),
    "blender": (4, 1, 0),
    "category": "Mesh",
}

import bpy
import bmesh
import math
from bpy.props import FloatProperty, IntProperty

class OBJECT_OT_haircards_to_lines(bpy.types.Operator):
    """Convert hair cards to curves through vertex-lines based on UV clustering"""
    bl_idname = "object.haircards_to_lines"
    bl_label = "Convert Hair Cards to Curves"
    bl_options = {'REGISTER', 'UNDO'}

    eps: FloatProperty(
        name="UV Tolerance",
        description="Max UV gap to consider loops in the same run",
        default=1e-4, min=0.0, precision=6
    )
    min_loops: IntProperty(
        name="Min Loops",
        description="Minimum loops per run to keep",
        default=2, min=1
    )

    def convert_to_curves(self, context):
        """Convert the resulting lines to curves and clean up"""
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Convert to curves
        bpy.ops.object.convert(target='CURVE')
        bpy.ops.object.convert(target='CURVES')

        # Clean up attributes
        for obj in context.selected_objects:
            if obj.type == 'CURVES':
                curve_data = obj.data
                attr_names = [attr.name for attr in curve_data.attributes]
                
                for name in attr_names:
                    attr = curve_data.attributes.get(name)
                    if attr:
                        try:
                            curve_data.attributes.remove(attr)
                        except RuntimeError:
                            continue

    def execute(self, context):
        # Store initial state
        orig_mode = context.mode
        orig_obj = context.active_object
        sel_objs = [o for o in context.selected_objects if o.type == 'MESH']

        if not sel_objs:
            self.report({'ERROR'}, "Select at least one mesh")
            return {'CANCELLED'}

        # Process each object
        processed_count = 0
        for obj in sel_objs:
            context.view_layer.objects.active = obj

            # switch to Edit Mesh
            if context.mode != 'EDIT_MESH':
                bpy.ops.object.mode_set(mode='EDIT')
            mesh     = obj.data
            bm       = bmesh.from_edit_mesh(mesh)
            uv_layer = bm.loops.layers.uv.active
            if uv_layer is None:
                self.report({'WARNING'}, f"{obj.name}: no UV map, skipped")
                bpy.ops.object.mode_set(mode='OBJECT')
                continue

            # reset tags & selections
            for v in bm.verts:
                v.tag = False
            bpy.ops.mesh.select_all(action='DESELECT')
            for f in bm.faces:
                for l in f.loops:
                    l[uv_layer].select = False
            bmesh.update_edit_mesh(mesh, destructive=True)

            # face→component flood fill
            face_comp = {}
            comp_id   = 0
            for f in bm.faces:
                if f.index in face_comp:
                    continue
                stack = [f]
                while stack:
                    cur = stack.pop()
                    if cur.index in face_comp:
                        continue
                    face_comp[cur.index] = comp_id
                    for e in cur.edges:
                        for nf in e.link_faces:
                            if nf.index not in face_comp:
                                stack.append(nf)
                comp_id += 1

            to_dup = []
            for cid in range(comp_id):
                comp_loops = []
                for f in bm.faces:
                    if face_comp[f.index] != cid:
                        continue
                    for l in f.loops:
                        u, v = l[uv_layer].uv
                        comp_loops.append((l,
                                           u - math.floor(u),
                                           v - math.floor(v),
                                           l.vert))

                def cluster(key_idx):
                    data = sorted(comp_loops, key=lambda t: t[key_idx])
                    runs, curr = [], [data[0]]
                    for a, b in zip(data, data[1:]):
                        if abs(b[key_idx] - a[key_idx]) > self.eps:
                            if len(curr) >= self.min_loops:
                                runs.append(curr)
                            curr = [b]
                        else:
                            curr.append(b)
                    if len(curr) >= self.min_loops:
                        runs.append(curr)
                    return runs

                rows = cluster(2)
                cols = cluster(1)
                if not rows and not cols:
                    continue

                max_r = max((len(r) for r in rows), default=0)
                max_c = max((len(c) for c in cols), default=0)
                if max_c > max_r:
                    chosen = cols
                elif max_r > max_c:
                    chosen = rows
                else:
                    chosen = rows + cols

                # sort chosen runs by average U or V
                if chosen and chosen[0] in cols:
                    chosen.sort(key=lambda run: sum(p[1] for p in run)/len(run))
                else:
                    chosen.sort(key=lambda run: sum(p[2] for p in run)/len(run))

                to_dup.extend(chosen)

            if not to_dup:
                self.report({'WARNING'}, f"{obj.name}: no runs found")
                bpy.ops.object.mode_set(mode='OBJECT')
                continue

            # duplicate each run and tag new verts
            orig_verts = set(bm.verts)
            for run in to_dup:
                bpy.ops.mesh.select_all(action='DESELECT')
                for f in bm.faces:
                    for l in f.loops:
                        l[uv_layer].select = False

                verts = set()
                for l, *_ in run:
                    l[uv_layer].select = True
                    l.vert.select_set(True)
                    verts.add(l.vert)

                for e in bm.edges:
                    if e.verts[0] in verts and e.verts[1] in verts:
                        e.select_set(True)

                bmesh.update_edit_mesh(mesh, destructive=True)
                bpy.ops.mesh.duplicate()
                bmesh.update_edit_mesh(mesh, destructive=True)

                for v in bm.verts:
                    if v.select and v not in orig_verts:
                        v.tag = True

            # remove all un-tagged verts (the originals)
            bpy.ops.mesh.select_all(action='DESELECT')
            for v in bm.verts:
                if not v.tag:
                    v.select_set(True)
            bmesh.update_edit_mesh(mesh, destructive=True)
            bpy.ops.mesh.delete(type='VERT')
            bmesh.update_edit_mesh(mesh, destructive=True)

            # cleanup and back to Object mode
            for v in bm.verts:
                v.tag = False
            bmesh.update_edit_mesh(mesh, destructive=True)
            bpy.ops.object.mode_set(mode='OBJECT')

        # Convert the resulting lines to curves
        self.convert_to_curves(context)

        # restore original active & mode
        context.view_layer.objects.active = orig_obj
        bpy.ops.object.mode_set(mode=orig_mode)

        self.report({'INFO'}, "Hair cards successfully converted to curves")
        return {'FINISHED'}


class VIEW3D_PT_cardstolines(bpy.types.Panel):
    """Sidebar panel for Cards to Curves conversion"""
    bl_label = "Hair Cards Converter"
    bl_idname = "VIEW3D_PT_cardstolines"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Pro Hair Suite"
    bl_parent_id = "VIEW3D_PT_pro_hair_suite"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        row = box.row()
        op = row.operator(OBJECT_OT_haircards_to_lines.bl_idname, text="Convert to Curves", icon='STRANDS')


classes = (
    OBJECT_OT_haircards_to_lines,
    VIEW3D_PT_cardstolines,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

if __name__ == "__main__":
    print("This file is part of Pro Hair Suite addon")