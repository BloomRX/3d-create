# SPDX-FileCopyrightText: 2026 Tim Christmann and Cloth NeXt contributors
# SPDX-License-Identifier: GPL-3.0-or-later

"""PPF Param payload with the real Phase-3B material mapping.

Exact reproduction of the subset of ``kinds/param.rs`` /
``encoder/params.py`` (pinned commit ``7193f158``) the vertical slice
needs:

``{"scene": {...}, "group": [(shell_params, [name], [uuid]),
                             (static_params, [name], [uuid])],
  "pin_config": {}}``

All keys are the upstream kebab-case spellings; the consumer forwards each
present key to the solver's parameter table (unknown keys are a hard error
there, absent keys fall back to the solver defaults), so only audited keys
are emitted.

Material values come from the immutable, validated
:class:`~cloth_next.materials.ShellMaterialSettings` /
:class:`~cloth_next.materials.StaticMaterialSettings` captured on Blender's
main thread. The full artist-name -> wire-key table lives in
``docs/PPF_PARAMETER_MAPPING.md``. Two invariants matter most:

- ``stretch_resistance`` is the DIRECT density-normalized ``young-mod``
  wire value. It is NEVER divided by density here (the upstream presets
  are calibrated in this convention; dividing again would silently soften
  every fabric by its density factor).
- Material floats are rounded through IEEE-754 float32 before the CBOR
  float64 encode, mirroring the upstream encoder's ``np.float32(...)``
  wrapping, so Cloth NeXt payload values match the official client's
  bit-for-bit.

Scene keys include ``dt`` (1e-3 s solver default), axis-swapped ``gravity``
and ``wind``, optional ``air-density``, ``air-friction`` and
``isotropic-air-friction``,
``frames`` (Blender N -> solver N-1), ``fps``, ``friction-mode`` "min"
(solver default combination mode; both surfaces need high friction for a
grippy contact), and ``disable-contact`` from the cloth's Enable Contact
toggle. Native Blender Force animation is sampled into PPF's ``dyn_param``
tracks using the same audited scene keys.
"""

from __future__ import annotations

import math
import struct
from dataclasses import dataclass, field

from ...materials import WIRE_MODEL_NAMES, ShellMaterialSettings, StaticMaterialSettings
from ...materials.validation import validate_shell_values, validate_static_values
from ...materials.deformables import (RodMaterialSettings,
                                      SoftBodyMaterialSettings,
                                      RigidBodyMaterialSettings)
from ...materials.friction import artist_friction_to_ppf
from ...pinning import StaticPinConfig
from ...solver_quality import DEFAULT_SOLVER_QUALITY, SolverQualitySettings
from ..coordinates import blender_vector_to_ppf
from . import envelope

FIXED_TIME_STEP = DEFAULT_SOLVER_QUALITY.time_step  # compatibility export

FRICTION_MODE = "min"  # fixed this phase; surfaced read-only in Advanced PPF
_DYNAMIC_VECTOR_KEYS = {"gravity", "wind"}
_DYNAMIC_SCALAR_KEYS = {
    "air-density", "air-friction", "isotropic-air-friction"}


class ParamEncodeError(ValueError):
    pass


def _dynamic_value_size(key: str) -> int | None:
    if (key in _DYNAMIC_VECTOR_KEYS or key.startswith("velocity:")
            or key.startswith("angular_velocity_world:")):
        return 3
    if key in _DYNAMIC_SCALAR_KEYS:
        return 1
    return None


def float32_wire(value: float) -> float:
    """Round to the exact float32 the solver's parameter table stores.

    The upstream encoder wraps every material scalar in ``np.float32``;
    reproducing that here keeps payloads and hashes comparable with the
    official client and makes the precision loss explicit and tested.
    """
    return float(struct.unpack(">f", struct.pack(">f", float(value)))[0])


def shell_wire_params(shell: ShellMaterialSettings) -> dict[str, object]:
    """The exact SHELL group parameter dict for the pinned solver.

    ``young-mod`` receives ``stretch_resistance`` unchanged — no density
    division (see the module docstring).
    """
    validate_shell_values(shell)
    # Shell shrink is intentionally disabled until upstream PPF can combine
    # changing rest lengths with its strain limiter.  Keep the legacy setting
    # readable so old .blend files and presets remain compatible.
    shrink_factor = 1.0
    strain_limit = (shell.maximum_stretch_percent / 100.0
                    if shell.stretch_limit_enabled else 0.0)
    return {
        "model": WIRE_MODEL_NAMES[shell.model],
        "density": float32_wire(shell.surface_weight),
        "young-mod": float32_wire(shell.stretch_resistance),
        "poiss-rat": float32_wire(shell.sideways_response),
        "bend": float32_wire(shell.bend_resistance),
        "plasticity": float32_wire(
            shell.stretch_plasticity_rate
            if shell.stretch_plasticity_enabled else 0.0),
        "plasticity-threshold": float32_wire(
            shell.stretch_plasticity_threshold_percent / 100.0),
        "bend-plasticity": float32_wire(
            shell.bend_plasticity_rate
            if shell.bend_plasticity_enabled else 0.0),
        "bend-plasticity-threshold": float32_wire(math.radians(
            shell.bend_plasticity_threshold_degrees)),
        "bend-rest-from-geometry": float32_wire(
            1.0 if shell.bend_rest_from_geometry else 0.0),
        "deformation-damping": float32_wire(shell.shape_damping),
        "bending-damping": float32_wire(shell.fold_damping),
        "friction": float32_wire(artist_friction_to_ppf(
            shell.surface_grip)),
        "contact-gap": float32_wire(shell.collision_gap),
        "contact-offset": float32_wire(shell.surface_offset),
        "strain-limit": float32_wire(strain_limit),
        "shrink-x": float32_wire(shrink_factor),
        "shrink-y": float32_wire(shrink_factor),
        "pressure": float32_wire(shell.inflate_pressure
                                 if shell.enable_inflate else 0.0),
        "stitch-stiffness": float32_wire(shell.sewing_stiffness),
    }


def static_wire_params(static: StaticMaterialSettings) -> dict[str, object]:
    """The exact STATIC group parameter dict (the only keys upstream
    emits for STATIC groups)."""
    validate_static_values(static)
    return {
        "friction": float32_wire(artist_friction_to_ppf(
            static.surface_grip)),
        "contact-gap": float32_wire(static.collision_gap),
        "contact-offset": float32_wire(static.surface_offset),
    }


def rod_wire_params(rod: RodMaterialSettings) -> dict[str, object]:
    return {
        "model": "arap", "density": float32_wire(rod.linear_density),
        "young-mod": float32_wire(rod.stretch_resistance),
        "friction": float32_wire(artist_friction_to_ppf(rod.surface_grip)),
        "deformation-damping": float32_wire(rod.shape_damping),
        "bending-damping": float32_wire(rod.bend_damping),
        "contact-gap": float32_wire(rod.collision_gap),
        "contact-offset": float32_wire(rod.surface_offset),
        "bend": float32_wire(rod.bend_resistance),
        "strain-limit": float32_wire(rod.stretch_limit),
        "length-factor": float32_wire(rod.length_factor),
        "bend-plasticity": float32_wire(rod.bend_plasticity_rate),
        "bend-plasticity-threshold": float32_wire(math.radians(
            rod.bend_plasticity_threshold_degrees)),
        "bend-rest-from-geometry": float32_wire(
            1.0 if rod.bend_rest_from_geometry else 0.0),
    }


def soft_body_wire_params(soft: SoftBodyMaterialSettings, uuid: str) -> dict[str, object]:
    tet = {} if soft.tetrahedralizer == "ftetwild" else {uuid: {"backend": "tetgen"}}
    return {
        "model": "arap", "density": float32_wire(soft.volume_density),
        "young-mod": float32_wire(soft.stretch_resistance),
        "poiss-rat": float32_wire(soft.poisson_ratio),
        "shrink": float32_wire(soft.volume_scale),
        "friction": float32_wire(artist_friction_to_ppf(soft.surface_grip)),
        "deformation-damping": float32_wire(soft.shape_damping),
        "contact-gap": float32_wire(soft.collision_gap),
        "contact-offset": float32_wire(soft.surface_offset),
        "ftetwild": tet,
        "plasticity": float32_wire(soft.stretch_plasticity_rate),
        "plasticity-threshold": float32_wire(
            soft.stretch_plasticity_threshold_percent / 100.0),
    }


def rigid_body_wire_params(rigid: RigidBodyMaterialSettings) -> dict[str, object]:
    """PDRD uses an exact rigid transform; only mass and contact are editable."""
    return {
        "model": "pdrd",
        "density": float32_wire(rigid.volume_density),
        "friction": float32_wire(artist_friction_to_ppf(rigid.surface_grip)),
        "contact-gap": float32_wire(rigid.collision_gap),
        "contact-offset": float32_wire(rigid.surface_offset),
    }


@dataclass(frozen=True, slots=True)
class SimulationSettings:
    """Immutable scene-level inputs for the vertical slice."""

    frame_count: int  # Blender frames 1..frame_count
    fps: float
    gravity_blender: tuple[float, float, float]
    quality: SolverQualitySettings = field(default_factory=SolverQualitySettings)
    time_scale: float = 1.0
    wind_blender: tuple[float, float, float] = (0.0, 0.0, 0.0)
    air_density: float | None = None
    air_friction: float | None = None
    vertex_air_damp: float | None = None
    dynamic_parameters: tuple[
        tuple[str, tuple[tuple[float, tuple[float, ...], bool], ...]], ...
    ] = ()
    auto_save_interval: int = 0
    keep_saved_states: int = 0
    save_state_on_finish: bool = False

    def __post_init__(self) -> None:
        if self.frame_count < 2:
            raise ParamEncodeError("frame_count must be at least 2")
        if not math.isfinite(self.fps) or self.fps <= 0:
            raise ParamEncodeError("fps must be at least 1")
        if not math.isfinite(self.time_scale) or self.time_scale <= 0:
            raise ParamEncodeError("time scale must be finite and positive")
        if self.auto_save_interval < 0:
            raise ParamEncodeError("auto-save interval must be non-negative")
        if self.keep_saved_states < 0:
            raise ParamEncodeError("keep saved states must be non-negative")
        if len(self.gravity_blender) != 3 or any(
                not math.isfinite(c) for c in self.gravity_blender):
            raise ParamEncodeError("gravity must be a finite 3-vector")
        if len(self.wind_blender) != 3 or any(
                not math.isfinite(c) for c in self.wind_blender):
            raise ParamEncodeError("wind must be a finite 3-vector")
        for name, value in (("air density", self.air_density),
                            ("air friction", self.air_friction),
                            ("vertex air damping", self.vertex_air_damp)):
            if value is not None and (not math.isfinite(value) or value < 0.0):
                raise ParamEncodeError(f"{name} must be finite and non-negative")
        seen = set()
        for key, entries in self.dynamic_parameters:
            expected = _dynamic_value_size(key)
            if expected is None:
                raise ParamEncodeError(f"unsupported dynamic parameter {key!r}")
            if key in seen:
                raise ParamEncodeError(f"duplicate dynamic parameter {key!r}")
            seen.add(key)
            if len(entries) < 1 or (not key.startswith((
                    "velocity:", "angular_velocity_world:"))
                    and len(entries) < 2):
                raise ParamEncodeError(
                    f"dynamic parameter {key!r} needs at least two samples")
            previous = -1.0
            for time_seconds, value, _hold in entries:
                if (not math.isfinite(time_seconds) or time_seconds < 0.0
                        or time_seconds <= previous):
                    raise ParamEncodeError(
                        f"dynamic parameter {key!r} times must increase")
                if (len(value) != expected
                        or any(not math.isfinite(component) for component in value)
                        or (expected == 1
                            and any(component < 0.0 for component in value))):
                    raise ParamEncodeError(
                        f"dynamic parameter {key!r} has an invalid value")
                previous = time_seconds


def _scene_wire_params(settings: SimulationSettings,
                       contact_enabled: bool, *,
                       schema_version: int = 1,
                       protocol_version: str = "0.13") -> dict:
    scene = {
        "dt": float32_wire(settings.quality.time_step),
        "min-newton-steps": int(settings.quality.min_newton_steps),
        "cg-max-iter": int(settings.quality.cg_max_iter),
        "cg-tol": float32_wire(settings.quality.cg_tol),
        "target-toi": float32_wire(settings.quality.target_toi),
        "line-search-max-t": float32_wire(
            settings.quality.line_search_max_t),
        "constraint-ghat": float32_wire(
            settings.quality.constraint_ghat),
        "constraint-tol": float32_wire(settings.quality.constraint_tol),
        "max-newton-steps": int(settings.quality.max_newton_steps),
        "max-dx": float32_wire(settings.quality.max_dx),
        "eiganalysis-eps": float32_wire(settings.quality.eigenanalysis_eps),
        "friction-eps": float32_wire(settings.quality.friction_eps),
        "csrmat-max-nnz": int(settings.quality.csrmat_max_nnz),
        "barrier": settings.quality.contact_barrier,
        "gravity": list(blender_vector_to_ppf(settings.gravity_blender)),
        "wind": [0.0 if value == 0.0 else value
                 for value in blender_vector_to_ppf(settings.wind_blender)],
        # Blender frames 1..N map to solver frames 0..N-1 (upstream contract).
        "frames": int(settings.frame_count) - 1,
        # Protocol 0.13 uses the Time-Scaled solver rate. The
        # collider schedule and physical integration must share it.
        "fps": (float(settings.fps * settings.time_scale)
                if schema_version == 2 else int(settings.fps)),
        "friction-mode": FRICTION_MODE,
        "disable-contact": not bool(contact_enabled),
    }
    if protocol_version == "0.13":
        scene["ccd-reduction"] = float32_wire(
            settings.quality.ccd_reduction)
        scene["ccd-max-iter"] = int(settings.quality.ccd_max_iter)
    elif protocol_version != "0.18":
        raise ParamEncodeError(
            f"unsupported PPF protocol {protocol_version!r}")
    if settings.auto_save_interval:
        scene["auto-save"] = int(settings.auto_save_interval)
    if settings.keep_saved_states:
        scene["keep-states"] = int(settings.keep_saved_states)
    if settings.save_state_on_finish:
        scene["save-state-on-finish"] = True
    for key, value in (("air-density", settings.air_density),
                       ("air-friction", settings.air_friction),
                       ("isotropic-air-friction", settings.vertex_air_damp)):
        if value is not None:
            scene[key] = float32_wire(value)
    return scene


def _attach_dynamic_params(payload: dict, settings: SimulationSettings) -> dict:
    if not settings.dynamic_parameters:
        return payload
    dynamic = {}
    for key, entries in settings.dynamic_parameters:
        encoded = []
        for time_seconds, value, hold in entries:
            wire_value = (list(blender_vector_to_ppf(value))
                          if _dynamic_value_size(key) == 3
                          else [float32_wire(value[0])])
            encoded.append((float(time_seconds), wire_value, bool(hold)))
        dynamic[key] = encoded
    payload["dyn_param"] = dynamic
    return payload


def _pin_wire_config(static_pin: StaticPinConfig, index: int, offset: int) -> dict:
    """Encode one hard-fix or soft-pull Pin config entry."""
    strength = float(static_pin.pull_strength)
    if static_pin.pull_weights is not None:
        strength = float(static_pin.pull_weights[offset])
    if not math.isfinite(strength) or strength < 0.0:
        raise ParamEncodeError(
            "pin pull strength must be finite and non-negative")
    config = {"pin_group_id": static_pin.pin_group_id, "operations": []}
    if strength > 0.0:
        config["pull_strength"] = float(strength)
    if static_pin.times:
        config["embedded_move_index"] = 0
        config["pin_anim"] = {
            index: {"time": list(static_pin.times),
                    "position": [list(frame[offset])
                                 for frame in static_pin.positions]}}
    return config


def build_param_payload(settings: SimulationSettings,
                        cloth_name: str, cloth_uuid: str,
                        collider_name: str, collider_uuid: str, *,
                        shell: ShellMaterialSettings,
                        static: StaticMaterialSettings,
                        contact_enabled: bool = True,
                        static_pin: StaticPinConfig | None = None,
                        schema_version: int = 1,
                        protocol_version: str = "0.13") -> dict:
    for label, value in (("cloth name", cloth_name), ("cloth uuid", cloth_uuid),
                         ("collider name", collider_name),
                         ("collider uuid", collider_uuid)):
        if not value.strip():
            raise ParamEncodeError(f"{label} must not be empty")
    scene = _scene_wire_params(
        settings, contact_enabled, schema_version=schema_version,
        protocol_version=protocol_version)
    group = [
        (shell_wire_params(shell), [cloth_name], [cloth_uuid]),
        (static_wire_params(static), [collider_name], [collider_uuid]),
    ]
    pin_config = {}
    if static_pin is not None:
        pin_config[cloth_uuid] = {}
        for offset,index in enumerate(static_pin.indices):
            pin_config[cloth_uuid][index] = _pin_wire_config(
                static_pin, index, offset)
    payload = {"scene": scene, "group": group, "pin_config": pin_config}
    if schema_version == 2:
        payload["time_scale"] = float(settings.time_scale)
    return _attach_dynamic_params(payload, settings)


def build_multi_collider_param_payload(
        settings: SimulationSettings, cloth_name: str, cloth_uuid: str,
        colliders, *, shell: ShellMaterialSettings,
        contact_enabled: bool = True,
        static_pin: StaticPinConfig | None = None,
        schema_version: int = 1,
        protocol_version: str = "0.13") -> dict:
    """PPF Param payload with one material group per STATIC collider."""
    entries = tuple(colliders)
    if not entries:
        return build_multi_deformable_param_payload(
            settings, ((cloth_name, cloth_uuid, "SHELL", shell,
                        static_pin),), (), contact_enabled=contact_enabled,
            schema_version=schema_version, protocol_version=protocol_version)
    first_name, first_uuid, first_static = entries[0]
    payload = build_param_payload(
        settings, cloth_name, cloth_uuid, first_name, first_uuid,
        shell=shell, static=first_static, contact_enabled=contact_enabled,
        static_pin=static_pin, schema_version=schema_version,
        protocol_version=protocol_version)
    payload["group"] = [payload["group"][0]] + [
        (static_wire_params(static), [name], [uuid])
        for name, uuid, static in entries]
    return payload


def encode_multi_collider_param(
        settings: SimulationSettings, cloth_name: str, cloth_uuid: str,
        colliders, *, shell: ShellMaterialSettings,
        contact_enabled: bool = True,
        static_pin: StaticPinConfig | None = None,
        schema_version: int = 1,
        protocol_version: str = "0.13") -> tuple[bytes, str]:
    payload = build_multi_collider_param_payload(
        settings, cloth_name, cloth_uuid, colliders, shell=shell,
        contact_enabled=contact_enabled, static_pin=static_pin,
        schema_version=schema_version, protocol_version=protocol_version)
    blob = envelope.dumps_envelope(
        envelope.KIND_PARAM, payload, schema_version=schema_version)
    return blob, envelope.payload_sha256(blob)


def build_deformable_param_payload(
        settings: SimulationSettings, deformable_name: str,
        deformable_uuid: str, colliders, *, group_type: str,
        material: ShellMaterialSettings | RodMaterialSettings |
        SoftBodyMaterialSettings | RigidBodyMaterialSettings,
        contact_enabled: bool = True,
        static_pin: StaticPinConfig | None = None,
        schema_version: int = 1,
        protocol_version: str = "0.13") -> dict:
    return build_multi_deformable_param_payload(
        settings,
        ((deformable_name, deformable_uuid, group_type, material,
          static_pin),),
        colliders, contact_enabled=contact_enabled,
        schema_version=schema_version, protocol_version=protocol_version)


def build_multi_deformable_param_payload(
        settings: SimulationSettings, deformables, colliders, *,
        contact_enabled: bool = True,
        schema_version: int = 1,
        protocol_version: str = "0.13") -> dict:
    """PPF parameters for multiple dynamic objects and shared colliders.

    Each deformable tuple is ``(name, uuid, group_type, material, pin)``.
    Separate groups deliberately preserve per-object material settings.
    """
    dynamic_entries = tuple(deformables)
    if not dynamic_entries:
        raise ParamEncodeError("at least one deformable is required")
    entries = tuple(colliders)
    dynamic_groups = []
    pin_config = {}
    seen = set()
    for name, uuid, group_type, material, static_pin in dynamic_entries:
        if not name.strip() or not uuid.strip():
            raise ParamEncodeError("deformable name and uuid must not be empty")
        if uuid in seen:
            raise ParamEncodeError(f"duplicate deformable uuid {uuid!r}")
        seen.add(uuid)
        if group_type == "SHELL" and isinstance(material, ShellMaterialSettings):
            params = shell_wire_params(material)
        elif group_type == "ROD" and isinstance(material, RodMaterialSettings):
            params = rod_wire_params(material)
        elif group_type == "SOLID" and isinstance(material, SoftBodyMaterialSettings):
            params = soft_body_wire_params(material, uuid)
        elif group_type == "PDRD" and isinstance(material, RigidBodyMaterialSettings):
            params = rigid_body_wire_params(material)
        else:
            raise ParamEncodeError(
                f"material does not match deformable group {group_type!r}")
        dynamic_groups.append((params, [name], [uuid]))
        if static_pin is not None:
            object_pins = {}
            for offset, index in enumerate(static_pin.indices):
                object_pins[index] = _pin_wire_config(
                    static_pin, index, offset)
            pin_config[uuid] = object_pins
    payload = {"scene": _scene_wire_params(
                   settings, contact_enabled, schema_version=schema_version,
                   protocol_version=protocol_version),
               "group": [
        *dynamic_groups,
        *((static_wire_params(static), [name], [uuid])
          for name, uuid, static in entries),
    ], "pin_config": pin_config}
    if schema_version == 2:
        payload["time_scale"] = float(settings.time_scale)
    return _attach_dynamic_params(payload, settings)


def encode_deformable_param(
        settings: SimulationSettings, deformable_name: str,
        deformable_uuid: str, colliders, *, group_type: str,
        material: ShellMaterialSettings | RodMaterialSettings |
        SoftBodyMaterialSettings | RigidBodyMaterialSettings,
        contact_enabled: bool = True,
        static_pin: StaticPinConfig | None = None,
        schema_version: int = 1,
        protocol_version: str = "0.13") -> tuple[bytes, str]:
    payload = build_deformable_param_payload(
        settings, deformable_name, deformable_uuid, colliders,
        group_type=group_type, material=material,
        contact_enabled=contact_enabled, static_pin=static_pin,
        schema_version=schema_version, protocol_version=protocol_version)
    blob = envelope.dumps_envelope(
        envelope.KIND_PARAM, payload, schema_version=schema_version)
    return blob, envelope.payload_sha256(blob)


def encode_multi_deformable_param(
        settings: SimulationSettings, deformables, colliders, *,
        contact_enabled: bool = True,
        schema_version: int = 1,
        protocol_version: str = "0.13") -> tuple[bytes, str]:
    payload = build_multi_deformable_param_payload(
        settings, deformables, colliders, contact_enabled=contact_enabled,
        schema_version=schema_version, protocol_version=protocol_version)
    blob = envelope.dumps_envelope(
        envelope.KIND_PARAM, payload, schema_version=schema_version)
    return blob, envelope.payload_sha256(blob)


def encode_param(settings: SimulationSettings,
                 cloth_name: str, cloth_uuid: str,
                 collider_name: str, collider_uuid: str, *,
                 shell: ShellMaterialSettings,
                 static: StaticMaterialSettings,
                 contact_enabled: bool = True,
                 static_pin: StaticPinConfig | None = None,
                 schema_version: int = 1,
                 protocol_version: str = "0.13") -> tuple[bytes, str]:
    payload = build_param_payload(settings, cloth_name, cloth_uuid,
                                  collider_name, collider_uuid,
                                  shell=shell, static=static,
                                  contact_enabled=contact_enabled,
                                  static_pin=static_pin,
                                  schema_version=schema_version,
                                  protocol_version=protocol_version)
    blob = envelope.dumps_envelope(
        envelope.KIND_PARAM, payload, schema_version=schema_version)
    return blob, envelope.payload_sha256(blob)
