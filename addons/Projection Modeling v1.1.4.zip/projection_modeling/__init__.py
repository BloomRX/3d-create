# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "Projection modeling",
    "author" : "Vovrzull and Kitцynя", 
    "description" : "Addon for modeling using projections of 2D projections objects (mesh or curves)",
    "blender" : (3, 6, 0),
    "version" : (1, 1, 4),
    "location" : "N-panel",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
from bpy.props import EnumProperty
import bpy, math, cmath
from collections import namedtuple
import math
import mathutils
import os


addon_keymaps = {}
_icons = None
edit_function_ = {'sna_sum': 0, }
orientation_projection = {'sna_angle_rotate_orogin': 0.0, 'sna_object_matematic': None, 'sna_save_object_activ': None, }
projection_control = {'sna_real_object': False, 'sna_collection_scene_save': [], }
projection_modeling = {'sna_save_select_list': [], 'sna_active_object': None, 'sna_projection_object': None, }


def sna_new_collection_and_active_32E38_8196F(Collection_Name, Active_Scene_collection):
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection
    if property_exists("bpy.data.collections[Collection_Name]", globals(), locals()):
        if bpy.context.view_layer.layer_collection.children[Collection_Name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[Collection_Name]
    else:
        collection_04D18 = bpy.data.collections.new(name=Collection_Name, )
        bpy.context.collection.children.link(child=collection_04D18, )
        if bpy.context.view_layer.layer_collection.children[collection_04D18.name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[collection_04D18.name]
    if Active_Scene_collection:
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def sna_true_deselect__all_C6336_05C43():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_AD474(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_select__set_active_object_07AE7_BBB06(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


movetocollection_s3_vars_DD952 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_DD952(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


def sna_true_deselect__all_C6336_2BD50():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_active_scene_collection_2B61F_A4886():
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def sna_select__set_active_object_07AE7_5CB69(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_select__set_active_object_07AE7_027A8(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_select__set_active_object_07AE7_6D8B4(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_ursor_to_object001_0F7D9_3AF70(Object):
    bpy.data.scenes['Scene'].cursor.location = Object.location
    bpy.data.scenes['Scene'].cursor.rotation_euler = Object.rotation_euler


def sna_true_deselect__all_C6336_EC694():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_object_to_cursor001_31671_C5F03(Object):
    Object.location = bpy.data.scenes['Scene'].cursor.location
    Object.rotation_euler = bpy.data.scenes['Scene'].cursor.rotation_euler


def sna_true_deselect__all_C6336_A0868():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_85BF3(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_cursor_to_world_02FD0_0BF78():
    bpy.ops.view3d.snap_cursor_to_center()


def sna_update_sna_index_projection_activ_CE712(self, context):
    sna_updated_prop = self.sna_index_projection_activ
    projection_control['sna_real_object'] = False
    for i_91EA9 in range(len(bpy.context.scene.objects)):
        if (bpy.context.scene.objects[i_91EA9] == bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection):
            projection_control['sna_real_object'] = True
            break
    if projection_control['sna_real_object']:
        sna_select__set_active_object_07AE7_336E0(bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection)
    else:
        if len(bpy.context.scene.sna_collection__name_project) > sna_updated_prop:
            bpy.context.scene.sna_collection__name_project.remove(sna_updated_prop)


def sna_select__set_active_object_07AE7_336E0(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_true_deselect__all_C6336_7B3DF():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


movetocollection_s3_vars_24E65 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_24E65(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


class SNA_UL_display_collection_list_EA44E(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_EA44E, icon, active_data, active_propname, index_EA44E):
        row = layout
        layout.prop(item_EA44E, 'name_projection', text='', icon_value=0, emboss=False)
        layout.prop(item_EA44E.pointer__peojection.modifiers['Projection geonode vovrzull'], 'show_viewport', text='', icon_value=0, emboss=True)
        if property_exists("bpy.data.collections[item_EA44E.pointer__peojection.name + '.1']", globals(), locals()):
            op = layout.operator('sna.collection_hide_projection1_dc253', text='', icon_value=250, emboss=True, depress= not bpy.data.collections[item_EA44E.pointer__peojection.name + '.1'].hide_viewport)
            op.sna_name_projection = item_EA44E.pointer__peojection.name

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if sna_filter_88166(item):
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def sna_update_sna_active_index_projections_931CD(self, context):
    sna_updated_prop = self.sna_active_index_projections
    sna_select__set_active_object_07AE7_786EB(bpy.data.collections[(bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection) if property_exists("bpy.data.collections[bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection)]", globals(), locals()) else bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + '1')].objects[sna_updated_prop])


def sna_select__set_active_object_07AE7_786EB(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_true_deselect__all_C6336_D66FA():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_F86C4(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


movetocollection_s3_vars_E4705 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_E4705(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


def display_collection_id(uid, vars):
    id = f"coll_{uid}"
    for var in vars.keys():
        if var.startswith("i_"):
            id += f"_{var}_{vars[var]}"
    return id


class SNA_UL_display_collection_list001_745C6(bpy.types.UIList):

    def draw_item(self, context, layout, data, item_745C6, icon, active_data, active_propname, index_745C6):
        row = layout
        layout.label(text=item_745C6.name, icon_value=0)

    def filter_items(self, context, data, propname):
        flt_flags = []
        for item in getattr(data, propname):
            if not self.filter_name or self.filter_name.lower() in item.name.lower():
                if True:
                    flt_flags.append(self.bitflag_filter_item)
                else:
                    flt_flags.append(0)
            else:
                flt_flags.append(0)
        return flt_flags, []


def sna_select__set_active_object_07AE7_672A6(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_true_deselect__all_C6336_F1BC0():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_58CCF(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


movetocollection_s3_vars_C5BC7 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_C5BC7(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


movetocollection_s3_vars_F5842 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_F5842(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


def sna_select__set_active_object_07AE7_83649(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_true_deselect__all_C6336_79C20():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


movetocollection_s3_vars_71B95 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_71B95(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


def sna_true_deselect__all_C6336_FC948():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_select__set_active_object_07AE7_80BFE(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


movetocollection_s3_vars_050E5 = {'sna_objectstomove': [], }


def sna_fnmovetocollection_397D9_050E5(CollectionName):
    if (len(bpy.context.view_layer.objects.selected.values()) > 0):
        if property_exists("bpy.data.collections[CollectionName]", globals(), locals()):
            sna_fnlinkunlink_41AEA(CollectionName)
        else:
            collection_752A1 = bpy.data.collections.new(name=CollectionName, )
            bpy.context.scene.collection.children.link(child=collection_752A1, )
            sna_fnlinkunlink_41AEA(CollectionName)


def sna_fnlinkunlink_41AEA(CollectionName):
    movetocollection_s3_vars_050E5['sna_objectstomove'] = []
    for i_5B107 in range(len(bpy.context.view_layer.objects.selected)):
        movetocollection_s3_vars_050E5['sna_objectstomove'].append(bpy.context.view_layer.objects.selected[i_5B107])
    for i_18D5A in range(len(bpy.context.view_layer.objects.selected)):
        for i_BE9A3 in range(len(bpy.context.view_layer.objects.selected[i_18D5A].users_collection)):
            if (bpy.context.view_layer.objects.selected[i_18D5A].users_collection[i_BE9A3].name == CollectionName):
                movetocollection_s3_vars_050E5['sna_objectstomove'].remove(bpy.context.view_layer.objects.selected[i_18D5A])
    for i_EC7E0 in range(len(movetocollection_s3_vars_050E5['sna_objectstomove'])):
        for i_726C8 in range(len(movetocollection_s3_vars_050E5['sna_objectstomove'][i_EC7E0].users_collection)):
            movetocollection_s3_vars_050E5['sna_objectstomove'][i_EC7E0].users_collection[i_726C8].objects.unlink(object=movetocollection_s3_vars_050E5['sna_objectstomove'][i_EC7E0], )
    for i_9A186 in range(len(movetocollection_s3_vars_050E5['sna_objectstomove'])):
        bpy.data.collections[CollectionName].objects.link(object=movetocollection_s3_vars_050E5['sna_objectstomove'][i_9A186], )


def sna_new_collection_and_active_32E38_F15CE(Collection_Name, Active_Scene_collection):
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection
    if property_exists("bpy.data.collections[Collection_Name]", globals(), locals()):
        if bpy.context.view_layer.layer_collection.children[Collection_Name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[Collection_Name]
    else:
        collection_04D18 = bpy.data.collections.new(name=Collection_Name, )
        bpy.context.collection.children.link(child=collection_04D18, )
        if bpy.context.view_layer.layer_collection.children[collection_04D18.name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[collection_04D18.name]
    if Active_Scene_collection:
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def sna_true_deselect__all_C6336_71FC7():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_active_scene_collection_2B61F_FEE61():
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def sna_import_geonode_3E625_00041(Name_Geonode, Path):
    if property_exists("bpy.data.node_groups[Name_Geonode].name", globals(), locals()):
        pass
    else:
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=Path + r'\NodeTree', filename=Name_Geonode, link=False)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_A20E2 = None if not new_data else new_data[0]
    if property_exists("bpy.context.view_layer.objects.active.modifiers[Name_Geonode]", globals(), locals()):
        pass
    else:
        modifier_1FED0 = bpy.context.view_layer.objects.active.modifiers.new(name=Name_Geonode, type='NODES', )
        modifier_1FED0.node_group = bpy.data.node_groups[Name_Geonode]


def sna_true_deselect__all_C6336_59301():
    if (bpy.context.view_layer.objects.selected or bpy.context.view_layer.objects.active):
        exec('bpy.context.view_layer.objects.active = None')
        exec("bpy.ops.object.select_all(action='DESELECT')")


def sna_new_collection_and_active_32E38_2CC7A(Collection_Name, Active_Scene_collection):
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection
    if property_exists("bpy.data.collections[Collection_Name]", globals(), locals()):
        if bpy.context.view_layer.layer_collection.children[Collection_Name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[Collection_Name]
    else:
        collection_04D18 = bpy.data.collections.new(name=Collection_Name, )
        bpy.context.collection.children.link(child=collection_04D18, )
        if bpy.context.view_layer.layer_collection.children[collection_04D18.name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[collection_04D18.name]
    if Active_Scene_collection:
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def sna_select__set_active_object_07AE7_1688E(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_select__set_active_object_07AE7_1A90E(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_select__set_active_object_07AE7_5383C(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_select__set_active_object_07AE7_0B059(Object):
    bpy.ops.object.select_all('INVOKE_DEFAULT', action='DESELECT')
    bpy.context.view_layer.objects.active = Object
    Object.select_set(state=True, )
    return


def sna_active_scene_collection_2B61F_220E7():
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


from bpy.props import FloatProperty
from mathutils import Vector


def run_bevel(Radius_bevel, Bevel_mode):
        if bpy.ops.object.mode_set.poll():
            bpy.ops.object.mode_set(mode='EDIT')
        splines = bpy.context.object.data.splines
        bpy.ops.curve.spline_type_set(type='BEZIER')
        bpy.ops.curve.handle_type_set(type='VECTOR')
        s = []
        for spline in splines:
            n = 0
            ii = []
            for p in spline.bezier_points:
                if p.select_control_point:
                    ii.append(n)
                    n += 1
                else:
                    n += 1
            s.append(ii)
        sn = 0
        for spline in splines:
            ii = s[sn]
            bezier_points = spline.bezier_points
            n = len(bezier_points)
            if n > 2:
                jn = 0
                for j in ii:
                    j += jn
                    bpy.ops.curve.select_all(action='DESELECT')
                    if j != 0 and j != n - 1:
                        bezier_points[j].select_control_point = True
                        bezier_points[j + 1].select_control_point = True
                        bpy.ops.curve.subdivide()
                        selected4 = [bezier_points[j - 1], bezier_points[j],
                                     bezier_points[j + 1], bezier_points[j + 2]]
                        jn += 1
                        n += 1
                    elif j == 0:
                        bezier_points[j].select_control_point = True
                        bezier_points[j + 1].select_control_point = True
                        bpy.ops.curve.subdivide()
                        selected4 = [bezier_points[n], bezier_points[0],
                                     bezier_points[1], bezier_points[2]]
                        jn += 1
                        n += 1
                    elif j == n - 1:
                        bezier_points[j].select_control_point = True
                        bezier_points[j - 1].select_control_point = True
                        bpy.ops.curve.subdivide()
                        selected4 = [bezier_points[0], bezier_points[n],
                                     bezier_points[n - 1], bezier_points[n - 2]]
                    selected4[2].co = selected4[1].co
                    s1 = Vector(selected4[0].co) - Vector(selected4[1].co)
                    s2 = Vector(selected4[3].co) - Vector(selected4[2].co)
                    s1.normalize()
                    s11 = Vector(selected4[1].co) + s1 * Radius_bevel
                    selected4[1].co = s11
                    s2.normalize()
                    s22 = Vector(selected4[2].co) + s2 * Radius_bevel
                    selected4[2].co = s22
                    Fillet_Type = Bevel_mode
                    if Fillet_Type == 'Round':
                        if j != n - 1:
                            selected4[2].handle_right_type = 'VECTOR'
                            selected4[1].handle_left_type = 'VECTOR'
                            selected4[1].handle_right_type = 'ALIGNED'
                            selected4[2].handle_left_type = 'ALIGNED'
                        else:
                            selected4[1].handle_right_type = 'VECTOR'
                            selected4[2].handle_left_type = 'VECTOR'
                            selected4[2].handle_right_type = 'ALIGNED'
                            selected4[1].handle_left_type = 'ALIGNED'
                    if Fillet_Type == 'Chamfer':
                        selected4[2].handle_right_type = 'VECTOR'
                        selected4[1].handle_left_type = 'VECTOR'
                        selected4[1].handle_right_type = 'VECTOR'
                        selected4[2].handle_left_type = 'VECTOR'
            sn += 1


from mathutils import Vector, Matrix


def bezierSegmentPoints(begin, end):
    return [begin.co, begin.handle_right, end.handle_left, end.co]


def nearestPointOfLines(originA, dirA, originB, dirB, tolerance=0.0):
    normal = dirA.cross(dirB)
    normalA = dirA.cross(normal)
    normalB = dirB.cross(normal)
    divisorA = dirA@normalB
    divisorB = dirB@normalA
    if abs(divisorA) <= tolerance or abs(divisorB) <= tolerance:
        return (float('nan'), float('nan'), None, None)
    else:
        paramA = (originB-originA)@normalB/divisorA
        paramB = (originA-originB)@normalA/divisorB
        return (paramA, paramB, originA+dirA*paramA, originB+dirB*paramB)


def bezierSegments(splines, selection_only):
    segments = []
    for spline in splines:
        if spline.type != 'BEZIER':
            continue
        for index, current in enumerate(spline.bezier_points):
            next = spline.bezier_points[(index+1) % len(spline.bezier_points)]
            if next == spline.bezier_points[0] and not spline.use_cyclic_u:
                continue
            if not selection_only or (current.select_right_handle and next.select_left_handle):
                segments.append({
                    'spline': spline,
                    'beginIndex': index,
                    'endIndex': index+1 if index < len(spline.bezier_points)-1 else 0,
                    'beginPoint': current,
                    'endPoint': next,
                    'cuts': []
                })
    return segments


def bezierPointAt(points, t):
    s = 1-t
    return s*s*s*points[0] + 3*s*s*t*points[1] + 3*s*t*t*points[2] + t*t*t*points[3]


def bezierTangentAt(points, t):
    s = 1-t
    return s*s*(points[1]-points[0])+2*s*t*(points[2]-points[1])+t*t*(points[3]-points[2])
    # return s*s*points[0] + (s*s-2*s*t)*points[1] + (2*s*t-t*t)*points[2] + t*t*points[3]


def bezierSubivideAt(points, params):
    if len(params) == 0:
        return []
    newPoints = []
    newPoints.append(points[0]+(points[1]-points[0])*params[0])
    for index, param in enumerate(params):
        paramLeft = param
        if index > 0:
            paramLeft -= params[index-1]
        paramRight = -param
        if index == len(params)-1:
            paramRight += 1.0
        else:
            paramRight += params[index+1]
        point = bezierPointAt(points, param)
        tangent = bezierTangentAt(points, param)
        newPoints.append(point-tangent*paramLeft)
        newPoints.append(point)
        newPoints.append(point+tangent*paramRight)
    newPoints.append(points[3]-(points[3]-points[2])*(1.0-params[-1]))
    return newPoints


def subdivideBezierSegment(segment):
    # Blender only allows uniform subdivision. Use this method to subdivide at arbitrary params.
    # NOTE: segment['cuts'] must be sorted by param
    if len(segment['cuts']) == 0:
        return
    segment['beginPoint'] = segment['spline'].bezier_points[segment['beginIndex']]
    segment['endPoint'] = segment['spline'].bezier_points[segment['endIndex']]
    params = [cut['param'] for cut in segment['cuts']]
    newPoints = bezierSubivideAt(bezierSegmentPoints(segment['beginPoint'], segment['endPoint']), params)
    bpy.ops.curve.select_all(action='DESELECT')
    segment['beginPoint'] = segment['spline'].bezier_points[segment['beginIndex']]
    segment['beginPoint'].select_right_handle = True
    segment['beginPoint'].handle_left_type = 'FREE'
    segment['beginPoint'].handle_right_type = 'FREE'
    segment['endPoint'] = segment['spline'].bezier_points[segment['endIndex']]
    segment['endPoint'].select_left_handle = True
    segment['endPoint'].handle_left_type = 'FREE'
    segment['endPoint'].handle_right_type = 'FREE'
    bpy.ops.curve.subdivide(number_cuts=len(params))
    if segment['endIndex'] > 0:
        segment['endIndex'] += len(params)
    segment['beginPoint'] = segment['spline'].bezier_points[segment['beginIndex']]
    segment['endPoint'] = segment['spline'].bezier_points[segment['endIndex']]
    segment['beginPoint'].select_right_handle = False
    segment['beginPoint'].handle_right = newPoints[0]
    segment['endPoint'].select_left_handle = False
    segment['endPoint'].handle_left = newPoints[-1]
    for index, cut in enumerate(segment['cuts']):
        cut['index'] = segment['beginIndex']+1+index
        newPoint = segment['spline'].bezier_points[cut['index']]
        newPoint.handle_left_type = 'FREE'
        newPoint.handle_right_type = 'FREE'
        newPoint.select_left_handle = False
        newPoint.select_control_point = False
        newPoint.select_right_handle = False
        newPoint.handle_left = newPoints[index*3+1]
        newPoint.co = newPoints[index*3+2]
        newPoint.handle_right = newPoints[index*3+3]


def subdivideBezierSegmentsOfSameSpline(segments):
    # NOTE: segment['cuts'] must be sorted by param
    indexOffset = 0
    for segment in segments:
        segment['beginIndex'] += indexOffset
        if segment['endIndex'] > 0:
            segment['endIndex'] += indexOffset
        subdivideBezierSegment(segment)
        indexOffset += len(segment['cuts'])
    for segment in segments:
        segment['beginPoint'] = segment['spline'].bezier_points[segment['beginIndex']]
        segment['endPoint'] = segment['spline'].bezier_points[segment['endIndex']]


def subdivideBezierSegments(segments):
    # NOTE: segment['cuts'] must be sorted by param
    groups = {}
    for segment in segments:
        spline = segment['spline']
        if (spline in groups) == False:
            groups[spline] = []
        group = groups[spline]
        group.append(segment)
    for spline in groups:
        subdivideBezierSegmentsOfSameSpline(groups[spline])


def bezierProjectHandles(segments):
    insertions = []
    index_offset = 0
    for segment in segments:
        if len(insertions) > 0 and insertions[-1][0] != segment['spline']:
            index_offset = 0
        points = bezierSegmentPoints(segment['beginPoint'], segment['endPoint'])
        paramA, paramB, pointA, pointB = nearestPointOfLines(points[0], points[1]-points[0], points[3], points[2]-points[3])
        if pointA and pointB:
            segment['cuts'].append({'param': 0.5})
            insertions.append((segment['spline'], segment['beginIndex']+1+index_offset, (pointA+pointB)*0.5))
            index_offset += 1
    subdivideBezierSegments(segments)
    for insertion in insertions:
        bezier_point = insertion[0].bezier_points[insertion[1]]
        bezier_point.co = insertion[2]
        bezier_point.handle_left_type = 'VECTOR'
        bezier_point.handle_right_type = 'VECTOR'


def Run_Extended():
    segments = bezierSegments(bpy.context.object.data.splines, True)
    if len(segments) < 1:
        return {'CANCELLED'}
    bezierProjectHandles(segments)
    return {'FINISHED'}


class SNA_OT_Bevel_Curve_14Cd3(bpy.types.Operator):
    bl_idname = "sna.bevel_curve_14cd3"
    bl_label = "Bevel Curve"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_radius_bevel: bpy.props.FloatProperty(name='radius bevel', description='', default=0.6499999761581421, subtype='NONE', unit='NONE', step=3, precision=6)

    def sna_mode_enum_items(self, context):
        return [("No Items", "No Items", "No generate enum items node found to create items!", "ERROR", 0)]
    sna_mode: bpy.props.EnumProperty(name='Mode', description='', items=[('Chamfer', 'Chamfer', '', 0, 0), ('Round', 'Round', '', 0, 1)])

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        Radius_bevel = self.sna_radius_bevel
        Bevel_mode = self.sna_mode
        run_bevel(Radius_bevel, Bevel_mode)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Straight_993E5(bpy.types.Operator):
    bl_idname = "sna.straight_993e5"
    bl_label = "Straight"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        Run_Extended()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_CURVE_EDIT_888F5(bpy.types.Panel):
    bl_label = 'Curve Edit'
    bl_idname = 'SNA_PT_CURVE_EDIT_888F5'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Projection'
    bl_order = 4
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not 'EDIT_CURVE'==bpy.context.mode)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_6B02B = layout.row(heading='', align=True)
        row_6B02B.alert = False
        row_6B02B.enabled = True
        row_6B02B.active = True
        row_6B02B.use_property_split = False
        row_6B02B.use_property_decorate = False
        row_6B02B.scale_x = 1.0
        row_6B02B.scale_y = 1.0
        row_6B02B.alignment = 'Expand'.upper()
        row_6B02B.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_6B02B.operator('sna.bevel_curve_14cd3', text='Bevel Curve', icon_value=0, emboss=True, depress=False)
        op = row_6B02B.operator('sna.straight_993e5', text='Straight', icon_value=0, emboss=True, depress=False)
        layout.label(text='Convert Type', icon_value=0)
        col_2171E = layout.column(heading='', align=True)
        col_2171E.alert = False
        col_2171E.enabled = True
        col_2171E.active = True
        col_2171E.use_property_split = False
        col_2171E.use_property_decorate = False
        col_2171E.scale_x = 1.0
        col_2171E.scale_y = 1.0
        col_2171E.alignment = 'Expand'.upper()
        col_2171E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_CBF5E = col_2171E.row(heading='', align=True)
        row_CBF5E.alert = False
        row_CBF5E.enabled = True
        row_CBF5E.active = True
        row_CBF5E.use_property_split = False
        row_CBF5E.use_property_decorate = False
        row_CBF5E.scale_x = 1.0
        row_CBF5E.scale_y = 1.0
        row_CBF5E.alignment = 'Expand'.upper()
        row_CBF5E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_CBF5E.operator('curve.handle_type_set', text='Automatic', icon_value=0, emboss=True, depress=False)
        op.type = 'AUTOMATIC'
        op = row_CBF5E.operator('curve.handle_type_set', text='Vector', icon_value=0, emboss=True, depress=False)
        op.type = 'VECTOR'
        row_45377 = col_2171E.row(heading='', align=True)
        row_45377.alert = False
        row_45377.enabled = True
        row_45377.active = True
        row_45377.use_property_split = False
        row_45377.use_property_decorate = False
        row_45377.scale_x = 1.0
        row_45377.scale_y = 1.0
        row_45377.alignment = 'Expand'.upper()
        row_45377.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_45377.operator('curve.handle_type_set', text='Aligned', icon_value=0, emboss=True, depress=False)
        op.type = 'ALIGNED'
        op = row_45377.operator('curve.handle_type_set', text='free/align', icon_value=0, emboss=True, depress=False)
        op.type = 'TOGGLE_FREE_ALIGN'


def sna_add_to_outliner_ht_header_0D25B(self, context):
    if not (False):
        layout = self.layout
        op = layout.operator('outliner.expanded_toggle', text='', icon_value=5, emboss=False, depress=False)


def sna_new_collection_and_active_32E38(Collection_Name, Active_Scene_collection):
    bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection
    if property_exists("bpy.data.collections[Collection_Name]", globals(), locals()):
        if bpy.context.view_layer.layer_collection.children[Collection_Name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[Collection_Name]
    else:
        collection_04D18 = bpy.data.collections.new(name=Collection_Name, )
        bpy.context.collection.children.link(child=collection_04D18, )
        if bpy.context.view_layer.layer_collection.children[collection_04D18.name]:
            bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection.children[collection_04D18.name]
    if Active_Scene_collection:
        bpy.context.view_layer.active_layer_collection = bpy.context.view_layer.layer_collection


class SNA_OT_Extended_Collection_Ac163(bpy.types.Operator):
    bl_idname = "sna.extended_collection_ac163"
    bl_label = "Extended collection"
    bl_description = "Select the object as the active projection object and select the object for the third ray"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_new_collection_and_active_32E38_8196F('Projection Collection', False)
        sna_save_select_and_active1_BF03E()
        sna_true_deselect__all_C6336_05C43()
        for i_D80F5 in range(len(projection_modeling['sna_save_select_list'])):
            sna_select__set_active_object_07AE7_AD474(projection_modeling['sna_save_select_list'][i_D80F5])
            sna_curve_options_projection_B404C(projection_modeling['sna_save_select_list'][i_D80F5])
            collection_DDB5E = bpy.data.collections.new(name=projection_modeling['sna_active_object'].name + '.3', )
            bpy.context.collection.children.link(child=collection_DDB5E, )
            sna_fnmovetocollection_397D9_DD952(projection_modeling['sna_active_object'].name + '.3')
            sna_true_deselect__all_C6336_2BD50()
        sna_select__set_active_object_07AE7_BBB06(projection_modeling['sna_active_object'])
        bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_24'] = bpy.data.collections[projection_modeling['sna_active_object'].name + '.3']
        bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )
        sna_active_scene_collection_2B61F_A4886()
        bpy.ops.mesh.primitive_cube_add('INVOKE_DEFAULT', )
        bpy.data.objects.remove(object=bpy.context.view_layer.objects.active, do_unlink=True, do_id_user=True, do_ui_user=True, )
        sna_select__set_active_object_07AE7_5CB69(projection_modeling['sna_active_object'])
        for i_7BB5C in range(len([projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_6'], projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_9'], projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_24']])):
            if ([projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_6'], projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_9'], projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_24']][i_7BB5C] != None):
                sna_collection_mode_E5452([projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_6'], projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_9'], projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Input_24']][i_7BB5C], projection_modeling['sna_active_object'].modifiers['Projection geonode vovrzull']['Socket_0'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_AddonPreferences_C793C(bpy.types.AddonPreferences):
    bl_idname = 'projection_modeling'

    def draw(self, context):
        if not (False):
            layout = self.layout 
            col_609E5 = layout.column(heading='', align=False)
            col_609E5.alert = False
            col_609E5.enabled = True
            col_609E5.active = True
            col_609E5.use_property_split = False
            col_609E5.use_property_decorate = False
            col_609E5.scale_x = 1.0
            col_609E5.scale_y = 1.0
            col_609E5.alignment = 'Expand'.upper()
            col_609E5.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_609E5.label(text='Useful links', icon_value=0)
            row_2E552 = col_609E5.row(heading='', align=False)
            row_2E552.alert = False
            row_2E552.enabled = True
            row_2E552.active = True
            row_2E552.use_property_split = False
            row_2E552.use_property_decorate = False
            row_2E552.scale_x = 1.0
            row_2E552.scale_y = 1.0
            row_2E552.alignment = 'Expand'.upper()
            row_2E552.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_2E552.operator('sna.blender_market_link_c384f', text='Blender market', icon_value=0, emboss=True, depress=False)
            op = row_2E552.operator('sna.youtube_f99b6', text='Youtube', icon_value=0, emboss=True, depress=False)
            op = row_2E552.operator('sna.boosty_ff383', text='Boosty', icon_value=0, emboss=True, depress=False)


class SNA_OT_Blender_Market_Link_C384F(bpy.types.Operator):
    bl_idname = "sna.blender_market_link_c384f"
    bl_label = "Blender market link"
    bl_description = "Blender market link"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.url_open('INVOKE_DEFAULT', url='https://blendermarket.com/creators/vovrzul777')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Youtube_F99B6(bpy.types.Operator):
    bl_idname = "sna.youtube_f99b6"
    bl_label = "Youtube"
    bl_description = "Youtube link"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.url_open('INVOKE_DEFAULT', url='https://www.youtube.com/@Vovrzull')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Boosty_Ff383(bpy.types.Operator):
    bl_idname = "sna.boosty_ff383"
    bl_label = "Boosty"
    bl_description = "Boosty link"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.url_open('INVOKE_DEFAULT', url='https://boosty.to/vovrzull')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fix_orient_2d_curve_7056D(Name_collection, project_or_selected):
    bpy.ops.object.mode_set(mode='OBJECT')
    for i_E7AAD in range(len((projection_modeling['sna_save_select_list'] if project_or_selected else bpy.data.collections[Name_collection].objects))):
        sna_select__set_active_object_07AE7_027A8((projection_modeling['sna_save_select_list'] if project_or_selected else bpy.data.collections[Name_collection].objects)[i_E7AAD])
        bpy.ops.object.duplicate_move()
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(type='VERT')
        bpy.ops.mesh.select_all(action='SELECT')
        if (len(bpy.context.view_layer.objects.active.data.polygons) == 0):
            bpy.ops.mesh.fill()
            bpy.ops.mesh.dissolve_limited('INVOKE_DEFAULT', delimit={'NORMAL'})
        bpy.ops.transform.create_orientation(name='Vovrzull Projection')
        bpy.context.scene.transform_orientation_slots[0].type = 'Vovrzull Projection'
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.data.objects.remove(object=bpy.context.view_layer.objects.active, )
        bpy.context.scene.tool_settings.use_transform_data_origin = True
        sna_select__set_active_object_07AE7_6D8B4((projection_modeling['sna_save_select_list'] if project_or_selected else bpy.data.collections[Name_collection].objects)[i_E7AAD])
        bpy.ops.transform.transform(mode='ALIGN', orient_type='Vovrzull Projection')
        bpy.context.scene.tool_settings.use_transform_data_origin = False
        bpy.ops.transform.delete_orientation()
        bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
        sna_fix_origin_rotate3_5E78D((projection_modeling['sna_save_select_list'] if project_or_selected else bpy.data.collections[Name_collection].objects)[i_E7AAD])


class SNA_OT_Correct_Origin_Projections_C843B(bpy.types.Operator):
    bl_idname = "sna.correct_origin_projections_c843b"
    bl_label = "Correct origin projections"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_save_select_and_active1_BF03E()
        if (len(projection_modeling['sna_save_select_list']) == 0):
            projection_modeling['sna_save_select_list'].append(bpy.context.view_layer.objects.active)
        sna_fix_orient_2d_curve_7056D('', True)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_fix_origin_rotate3_5E78D(Object_Active):
    orientation_projection['sna_save_object_activ'] = Object_Active
    sna_ursor_to_object001_0F7D9_3AF70(bpy.context.view_layer.objects.active)
    sna_true_deselect__all_C6336_EC694()
    bpy.ops.mesh.primitive_vert_add()
    bpy.ops.object.mode_set(mode='OBJECT')
    sna_object_to_cursor001_31671_C5F03(bpy.context.view_layer.objects.active)
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    Xcontrol = 0.5
    Ycontrol = 0.0
    Zcontrol = 0.0
    Orient = 'LOCAL'
    import bmesh
    # Check if we're in Edit Mode
    if bpy.context.mode != 'EDIT_MESH':
        bpy.ops.object.mode_set(mode='EDIT')
    # Get the selected mesh object and its data
    obj = bpy.context.active_object
    mesh = obj.data
    # Create a BMesh to work with
    bm = bmesh.from_edit_mesh(mesh)
    # Extrude the selected faces (you can also use .verts to extrude vertices)
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value":(Xcontrol, Ycontrol, Zcontrol), "orient_type": Orient})
    # Update the BMesh
    bmesh.update_edit_mesh(mesh)
    # Deselect all faces or vertices
    #bm.select_flush(False)
    bpy.ops.mesh.select_all(action='INVERT')
    bpy.context.scene.transform_orientation_slots[0].type = 'GLOBAL'
    Xcontrol = 0.0
    Ycontrol = 0.0
    Zcontrol = -0.5
    Orient = 'GLOBAL'
    import bmesh
    # Check if we're in Edit Mode
    if bpy.context.mode != 'EDIT_MESH':
        bpy.ops.object.mode_set(mode='EDIT')
    # Get the selected mesh object and its data
    obj = bpy.context.active_object
    mesh = obj.data
    # Create a BMesh to work with
    bm = bmesh.from_edit_mesh(mesh)
    # Extrude the selected faces (you can also use .verts to extrude vertices)
    bpy.ops.mesh.extrude_region_move(TRANSFORM_OT_translate={"value":(Xcontrol, Ycontrol, Zcontrol), "orient_type": Orient})
    # Update the BMesh
    bmesh.update_edit_mesh(mesh)
    # Deselect all faces or vertices
    #bm.select_flush(False)
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.convert(target='CURVE')
    bpy.context.view_layer.objects.active.data.dimensions = '2D'
    bpy.ops.object.convert(target='MESH')
    p1 = bpy.context.view_layer.objects.active.data.vertices[0].co
    p2 = bpy.context.view_layer.objects.active.data.vertices[1].co
    p3 = bpy.context.view_layer.objects.active.data.vertices[2].co
    angle1 = None
    angle2 = None
    angle3 = None
    # Calculate the vectors representing the sides of the triangle
    v1 = (p2[0] - p1[0], p2[1] - p1[1], p2[2] - p1[2])
    v2 = (p3[0] - p2[0], p3[1] - p2[1], p3[2] - p2[2])
    v3 = (p1[0] - p3[0], p1[1] - p3[1], p1[2] - p3[2])
    # Calculate the lengths of the sides
    side1 = math.sqrt(v1[0]**2 + v1[1]**2 + v1[2]**2)
    side2 = math.sqrt(v2[0]**2 + v2[1]**2 + v2[2]**2)
    side3 = math.sqrt(v3[0]**2 + v3[1]**2 + v3[2]**2)
    # Calculate the angles using the Law of Cosines
    angle1 = math.degrees(math.acos((side2**2 + side3**2 - side1**2) / (2 * side2 * side3)))
    angle2 = math.degrees(math.acos((side3**2 + side1**2 - side2**2) / (2 * side3 * side1)))
    angle3 = math.degrees(math.acos((side1**2 + side2**2 - side3**2) / (2 * side1 * side2)))
    # Print the angles
    print("Angle 1: {:.2f} degrees".format(angle1))
    print("Angle 2: {:.2f} degrees".format(angle2))
    print("Angle 3: {:.2f} degrees".format(angle3))
    orientation_projection['sna_angle_rotate_orogin'] = 0.0
    orientation_projection['sna_angle_rotate_orogin'] = angle3
    orientation_projection['sna_object_matematic'] = None
    orientation_projection['sna_object_matematic'] = bpy.context.view_layer.objects.active
    bpy.context.scene.transform_orientation_slots[0].type = 'LOCAL'
    bpy.context.scene.tool_settings.use_transform_data_origin = True
    sna_true_deselect__all_C6336_A0868()
    sna_select__set_active_object_07AE7_85BF3(orientation_projection['sna_save_object_activ'])
    bpy.ops.transform.rotate(value=(float(math.radians(orientation_projection['sna_angle_rotate_orogin']) * -1.0) if (orientation_projection['sna_object_matematic'].data.vertices[2].co[1] > orientation_projection['sna_object_matematic'].data.vertices[0].co[1]) else math.radians(orientation_projection['sna_angle_rotate_orogin'])), orient_axis='Z', orient_type='LOCAL', constraint_axis=(False, False, True))
    print('')
    sna_cursor_to_world_02FD0_0BF78()
    bpy.data.objects.remove(object=orientation_projection['sna_object_matematic'], )
    bpy.context.scene.tool_settings.use_transform_data_origin = False


class SNA_OT_Rotate_Origin_180_14B9D(bpy.types.Operator):
    bl_idname = "sna.rotate_origin_180_14b9d"
    bl_label = "Rotate origin 180"
    bl_description = "Rotate origin 180"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.tool_settings.use_transform_data_origin = True
        bpy.ops.transform.rotate(value=math.radians(180.0), orient_axis='Y', orient_type='LOCAL', constraint_axis=(False, True, False))
        bpy.context.scene.tool_settings.use_transform_data_origin = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Collection_Hide_Projection1_Dc253(bpy.types.Operator):
    bl_idname = "sna.collection_hide_projection1_dc253"
    bl_label = "Collection Hide projection1"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_name_projection: bpy.props.StringProperty(name='Name projection', description='', default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_hide_collection_projections_38E61('.1', self.sna_name_projection)
        sna_hide_collection_projections_38E61('.2', self.sna_name_projection)
        sna_hide_collection_projections_38E61('.3', self.sna_name_projection)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Rebuild_The_List_Projections_6332F(bpy.types.Operator):
    bl_idname = "sna.rebuild_the_list_projections_6332f"
    bl_label = "Rebuild the list projections"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_collection__name_project.clear()
        for i_1DC63 in range(len(bpy.context.scene.objects)):
            if property_exists("bpy.context.scene.objects[i_1DC63].modifiers['Projection geonode vovrzull']", globals(), locals()):
                item_F64C3 = bpy.context.scene.sna_collection__name_project.add()
                item_F64C3.name_projection = bpy.context.scene.objects[i_1DC63].name
                item_F64C3.pointer__peojection = bpy.context.scene.objects[i_1DC63]
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_clean_collection_loft_E308B():
    projection_control['sna_collection_scene_save'] = []
    bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
    for i_027D8 in range(len(bpy.data.collections)):
        projection_control['sna_collection_scene_save'].append(bpy.data.collections[i_027D8])
    for i_762DF in range(len(projection_control['sna_collection_scene_save'])):
        if ((len(projection_control['sna_collection_scene_save'][i_762DF].objects) == 0) and (len(projection_control['sna_collection_scene_save'][i_762DF].children) == 0)):
            bpy.data.collections.remove(collection=projection_control['sna_collection_scene_save'][i_762DF], )


def sna_izvlesh_iz_collection_6CC1D():
    bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
    sna_true_deselect__all_C6336_7B3DF()
    for i_600A5 in range(len(bpy.data.collections)):
        if ('Projection object' == bpy.data.collections[i_600A5].name[:len('Projection object')]):
            if property_exists("bpy.data.objects[bpy.data.collections[i_600A5].name[:int(len(bpy.data.collections[i_600A5].name) - 2.0)]]", globals(), locals()):
                pass
            else:
                if (len(bpy.data.collections[i_600A5].objects) != 0):
                    for i_277D9 in range(len(bpy.data.collections[i_600A5].objects)):
                        bpy.data.collections[i_600A5].objects[i_277D9].select_set(state=True, )
                    sna_fnmovetocollection_397D9_24E65('Projection Collection')


class SNA_OT_Clean_Delete_Projection_07204(bpy.types.Operator):
    bl_idname = "sna.clean_delete_projection_07204"
    bl_label = "Clean delete projection"
    bl_description = "Removes projection collections from the outliner that do not have a projection object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_izvlesh_iz_collection_6CC1D()
        sna_clean_collection_loft_E308B()
        for i_D53C0 in range(len(bpy.context.scene.sna_collection__name_project)):
            projection_control['sna_real_object'] = False
            for i_0972B in range(len(bpy.context.scene.objects)):
                if (bpy.context.scene.objects[i_0972B] == bpy.context.scene.sna_collection__name_project[i_D53C0].pointer__peojection):
                    projection_control['sna_real_object'] = True
                    break
            if projection_control['sna_real_object']:
                pass
            else:
                if len(bpy.context.scene.sna_collection__name_project) > i_D53C0:
                    bpy.context.scene.sna_collection__name_project.remove(i_D53C0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_filter_88166(Input):
    return (property_exists("bpy.context.view_layer.objects", globals(), locals()) and Input.pointer__peojection.name in bpy.context.view_layer.objects)


def sna_hide_collection_projections_38E61(Input, Name_projection):
    if property_exists("bpy.data.collections[Name_projection + Input]", globals(), locals()):
        if bpy.data.collections[Name_projection + Input].hide_viewport:
            bpy.data.collections[Name_projection + Input].hide_viewport = False
        else:
            bpy.data.collections[Name_projection + Input].hide_viewport = True


class SNA_OT_Delete_Active_Projection_List_B9Afa(bpy.types.Operator):
    bl_idname = "sna.delete_active_projection_list_b9afa"
    bl_label = "Delete active projection list"
    bl_description = "deletes the active projection object in the projection objects sheet"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (property_exists("bpy.context.view_layer.objects", globals(), locals()) and bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name in bpy.context.view_layer.objects):
            bpy.data.objects.remove(object=bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection, do_unlink=True, do_id_user=True, do_ui_user=True, )
        if len(bpy.context.scene.sna_collection__name_project) > bpy.context.scene.sna_index_projection_activ:
            bpy.context.scene.sna_collection__name_project.remove(bpy.context.scene.sna_index_projection_activ)
        sna_izvlesh_iz_collection_6CC1D()
        sna_clean_collection_loft_E308B()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_PROJECTION_CONTROL__4E6C2(bpy.types.Panel):
    bl_label = 'Projection control '
    bl_idname = 'SNA_PT_PROJECTION_CONTROL__4E6C2'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Projection'
    bl_order = 1
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        row_361A0 = layout.row(heading='', align=False)
        row_361A0.alert = False
        row_361A0.enabled = True
        row_361A0.active = True
        row_361A0.use_property_split = False
        row_361A0.use_property_decorate = False
        row_361A0.scale_x = 1.0
        row_361A0.scale_y = 1.0
        row_361A0.alignment = 'Expand'.upper()
        row_361A0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_361A0.operator('sna.rebuild_the_list_projections_6332f', text='', icon_value=692, emboss=True, depress=False)
        op = row_361A0.operator('sna.clean_delete_projection_07204', text='', icon_value=93, emboss=True, depress=False)
        row_4D3D9 = row_361A0.row(heading='', align=True)
        row_4D3D9.alert = False
        row_4D3D9.enabled = True
        row_4D3D9.active = True
        row_4D3D9.use_property_split = False
        row_4D3D9.use_property_decorate = False
        row_4D3D9.scale_x = 1.0
        row_4D3D9.scale_y = 1.0
        row_4D3D9.alignment = 'Expand'.upper()
        row_4D3D9.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_4D3D9.operator('sna.correct_origin_projections_c843b', text='', icon_value=318, emboss=True, depress=False)
        op = row_4D3D9.operator('sna.rotate_origin_180_14b9d', text='180', icon_value=0, emboss=True, depress=False)
        op = row_361A0.operator('sna.delete_active_projection_list_b9afa', text='', icon_value=33, emboss=True, depress=False)
        coll_id = display_collection_id('EA44E', locals())
        layout.template_list('SNA_UL_display_collection_list_EA44E', coll_id, bpy.context.scene, 'sna_collection__name_project', bpy.context.scene, 'sna_index_projection_activ', rows=0)
        if (bpy.context.view_layer.objects.active != None):
            layout.label(text=bpy.context.view_layer.objects.active.name, icon_value=0)


class SNA_OT_Remove_From_Projections_Bda61(bpy.types.Operator):
    bl_idname = "sna.remove_from_projections_bda61"
    bl_label = "Remove from projections"
    bl_description = "Remove an object selected in the list from projections"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_true_deselect__all_C6336_D66FA()
        sna_select__set_active_object_07AE7_F86C4(bpy.data.collections[(bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection) if property_exists("bpy.data.collections[bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection)]", globals(), locals()) else bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + '1')].objects[bpy.context.scene.sna_active_index_projections])
        sna_fnmovetocollection_397D9_E4705('Projection Collection')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Objects_Beam_Swith_3Ba15(bpy.types.Operator):
    bl_idname = "sna.objects_beam_swith_3ba15"
    bl_label = "Objects beam swith"
    bl_description = "Switches the display of objects in the projection collections of the First, second, third projection rays"
    bl_options = {"REGISTER", "UNDO"}
    sna_index_collection: bpy.props.IntProperty(name='Index Collection', description='', default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.scene.sna_index_collection = self.sna_index_collection
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_OBJECTS_FOR_PROJECTION_A3469(bpy.types.Panel):
    bl_label = 'Objects for projection'
    bl_idname = 'SNA_PT_OBJECTS_FOR_PROJECTION_A3469'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Projection'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        if property_exists("bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ]", globals(), locals()):
            col_62F80 = layout.column(heading='', align=False)
            col_62F80.alert = False
            col_62F80.enabled = True
            col_62F80.active = True
            col_62F80.use_property_split = False
            col_62F80.use_property_decorate = False
            col_62F80.scale_x = 1.0
            col_62F80.scale_y = 1.0
            col_62F80.alignment = 'Expand'.upper()
            col_62F80.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_38508 = col_62F80.row(heading='', align=False)
            row_38508.alert = False
            row_38508.enabled = True
            row_38508.active = True
            row_38508.use_property_split = False
            row_38508.use_property_decorate = False
            row_38508.scale_x = 1.0
            row_38508.scale_y = 1.0
            row_38508.alignment = 'Expand'.upper()
            row_38508.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_93D44 = row_38508.row(heading='', align=True)
            row_93D44.alert = False
            row_93D44.enabled = True
            row_93D44.active = True
            row_93D44.use_property_split = False
            row_93D44.use_property_decorate = False
            row_93D44.scale_x = 1.0
            row_93D44.scale_y = 1.0
            row_93D44.alignment = 'Expand'.upper()
            row_93D44.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_93D44.operator('sna.add__objects_projection1_a4336', text='', icon_value=31, emboss=True, depress=False)
            op = row_93D44.operator('sna.remove_from_projections_bda61', text='', icon_value=32, emboss=True, depress=False)
            op = row_38508.operator('sna.objects_beam_swith_3ba15', text='1', icon_value=0, emboss=True, depress=((bpy.context.scene.sna_index_collection == 1) or ((bpy.context.scene.sna_index_collection == 3) and  not property_exists("bpy.data.collections[bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + '3']", globals(), locals()))))
            op.sna_index_collection = 1
            op = row_38508.operator('sna.objects_beam_swith_3ba15', text='2', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_index_collection == 2))
            op.sna_index_collection = 2
            if property_exists("bpy.data.collections[bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + '3']", globals(), locals()):
                op = row_38508.operator('sna.objects_beam_swith_3ba15', text='3', icon_value=0, emboss=True, depress=(bpy.context.scene.sna_index_collection == 3))
                op.sna_index_collection = 3
            coll_id = display_collection_id('745C6', locals())
            col_62F80.template_list('SNA_UL_display_collection_list001_745C6', coll_id, bpy.data.collections[(bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection) if property_exists("bpy.data.collections[bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection)]", globals(), locals()) else bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + '1')], 'objects', bpy.context.scene, 'sna_active_index_projections', rows=0)


class SNA_OT_Add__Objects_Projection1_A4336(bpy.types.Operator):
    bl_idname = "sna.add__objects_projection1_a4336"
    bl_label = "Add  objects projection1"
    bl_description = "Adds selected objects to the list of projections"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_save_select_and_active1_BF03E()
        result_0A688 = bpy.context.view_layer.objects.active.select_get()
        if result_0A688:
            projection_modeling['sna_save_select_list'].append(bpy.context.view_layer.objects.active)
        for i_32C95 in range(len(projection_modeling['sna_save_select_list'])):
            sna_select__set_active_object_07AE7_672A6(projection_modeling['sna_save_select_list'][i_32C95])
            sna_curve_options_projection_B404C(projection_modeling['sna_save_select_list'][i_32C95])
        sna_true_deselect__all_C6336_F1BC0()
        for i_39A62 in range(len(projection_modeling['sna_save_select_list'])):
            if (i_39A62 == 0):
                sna_select__set_active_object_07AE7_58CCF(projection_modeling['sna_save_select_list'][i_39A62])
            else:
                projection_modeling['sna_save_select_list'][i_39A62].select_set(state=True, )
        if property_exists("bpy.data.collections[bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection)]", globals(), locals()):
            sna_fnmovetocollection_397D9_C5BC7(bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection))
        else:
            bpy.context.scene.sna_index_collection = 1
            sna_fnmovetocollection_397D9_F5842(bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.name + '.' + str(bpy.context.scene.sna_index_collection))
        for i_218AB in range(len([bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_6'], bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_9'], bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_24']])):
            if ([bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_6'], bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_9'], bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_24']][i_218AB] != None):
                sna_collection_mode_E5452([bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_6'], bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_9'], bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Input_24']][i_218AB], bpy.context.scene.sna_collection__name_project[bpy.context.scene.sna_index_projection_activ].pointer__peojection.modifiers['Projection geonode vovrzull']['Socket_0'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_save_select_and_active1_BF03E():
    projection_modeling['sna_active_object'] = None
    projection_modeling['sna_save_select_list'] = []
    for i_3798C in range(len(bpy.context.view_layer.objects.selected)):
        if (bpy.context.view_layer.objects.selected[i_3798C] == bpy.context.view_layer.objects.active):
            projection_modeling['sna_active_object'] = bpy.context.view_layer.objects.selected[i_3798C]
        else:
            projection_modeling['sna_save_select_list'].append(bpy.context.view_layer.objects.selected[i_3798C])
    if (projection_modeling['sna_active_object'] == None):
        projection_modeling['sna_active_object'] = bpy.context.view_layer.objects.selected[0]


class SNA_OT_Dublicate_And_Aplly_Project_Bae9D(bpy.types.Operator):
    bl_idname = "sna.dublicate_and_aplly_project_bae9d"
    bl_label = "Dublicate and aplly project"
    bl_description = "Object duplication with apply geonodes, grid optimization"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.view_layer.objects.active != None):
            bpy.ops.object.duplicate_move()
            if property_exists("bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']", globals(), locals()):
                sna_aplly_projection_50025()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Apply_6Bcbb(bpy.types.Operator):
    bl_idname = "sna.apply_6bcbb"
    bl_label = "Apply"
    bl_description = "Apply geonodes, grid optimization"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if (bpy.context.view_layer.objects.active != None):
            sna_aplly_projection_50025()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_curve_update_projection_96497(Collections):
    for i_FB260 in range(len(Collections.objects)):
        sna_curve_options_projection_B404C(Collections.objects[i_FB260])


class SNA_OT_Update_Curve_Collection_6124C(bpy.types.Operator):
    bl_idname = "sna.update_curve_collection_6124c"
    bl_label = "Update Curve collection"
    bl_description = "Updates the settings of curves added to the collections so that they work as projections"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_curve_update_projection_96497(bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_6'])
        sna_curve_update_projection_96497(bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_9'])
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_aplly_projection_50025():
    if (property_exists("bpy.context.view_layer.objects.active.modifiers['Remesh Vovrzull']", globals(), locals()) or bpy.context.view_layer.objects.active.type == 'CURVE'):
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.origin_set('INVOKE_DEFAULT', type='ORIGIN_GEOMETRY', center='MEDIAN')
    else:
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.origin_set('INVOKE_DEFAULT', type='ORIGIN_GEOMETRY', center='MEDIAN')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.dissolve_limited('INVOKE_DEFAULT', angle_limit=0.0008730000117793679, delimit={'NORMAL'})
        bpy.ops.mesh.delete_loose(use_verts=True, use_edges=True)
        bpy.ops.object.mode_set(mode='OBJECT')


def sna_create_collection__5AFFD():
    for i_23280 in range(len(projection_modeling['sna_save_select_list'])):
        sna_select__set_active_object_07AE7_83649(projection_modeling['sna_save_select_list'][i_23280])
        sna_curve_options_projection_B404C(projection_modeling['sna_save_select_list'][i_23280])
        collection_5D5C9 = bpy.data.collections.new(name=projection_modeling['sna_projection_object'].name + '.2', )
        bpy.context.collection.children.link(child=collection_5D5C9, )
        sna_fnmovetocollection_397D9_71B95(projection_modeling['sna_projection_object'].name + '.2')
        sna_true_deselect__all_C6336_FC948()
    sna_true_deselect__all_C6336_79C20()
    sna_select__set_active_object_07AE7_80BFE(projection_modeling['sna_active_object'])
    sna_curve_options_projection_B404C(projection_modeling['sna_active_object'])
    collection_6CD22 = bpy.data.collections.new(name=projection_modeling['sna_projection_object'].name + '.1', )
    bpy.context.collection.children.link(child=collection_6CD22, )
    sna_fnmovetocollection_397D9_050E5(projection_modeling['sna_projection_object'].name + '.1')
    return


class SNA_PT_PROJECTION_MODELING_8A13B(bpy.types.Panel):
    bl_label = 'Projection modeling'
    bl_idname = 'SNA_PT_PROJECTION_MODELING_8A13B'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Projection'
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        split_48CB5 = layout.split(factor=0.8777778148651123, align=True)
        split_48CB5.alert = False
        split_48CB5.enabled = True
        split_48CB5.active = True
        split_48CB5.use_property_split = False
        split_48CB5.use_property_decorate = False
        split_48CB5.scale_x = 1.0
        split_48CB5.scale_y = 1.0
        split_48CB5.alignment = 'Expand'.upper()
        if not True: split_48CB5.operator_context = "EXEC_DEFAULT"
        op = split_48CB5.operator('sna.apply_6bcbb', text='Apply', icon_value=0, emboss=True, depress=False)
        op = split_48CB5.operator('sna.dublicate_and_aplly_project_bae9d', text='', icon_value=20, emboss=True, depress=False)
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']", globals(), locals()):
            col_9437E = layout.column(heading='', align=False)
            col_9437E.alert = False
            col_9437E.enabled = True
            col_9437E.active = True
            col_9437E.use_property_split = False
            col_9437E.use_property_decorate = False
            col_9437E.scale_x = 1.0
            col_9437E.scale_y = 1.0
            col_9437E.alignment = 'Expand'.upper()
            col_9437E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            split_A37BE = col_9437E.split(factor=0.8777778148651123, align=True)
            split_A37BE.alert = False
            split_A37BE.enabled = True
            split_A37BE.active = True
            split_A37BE.use_property_split = False
            split_A37BE.use_property_decorate = False
            split_A37BE.scale_x = 1.0
            split_A37BE.scale_y = 1.0
            split_A37BE.alignment = 'Expand'.upper()
            if not True: split_A37BE.operator_context = "EXEC_DEFAULT"
            op = split_A37BE.operator('sna.create_projection_5cf9e', text='Create Projection', icon_value=120, emboss=True, depress=False)
            op = split_A37BE.operator('sna.update_curve_collection_6124c', text='', icon_value=692, emboss=True, depress=False)
            col_9437E.separator(factor=-0.46999990940093994)
            split_848B6 = col_9437E.split(factor=0.5, align=True)
            split_848B6.alert = False
            split_848B6.enabled = True
            split_848B6.active = True
            split_848B6.use_property_split = False
            split_848B6.use_property_decorate = False
            split_848B6.scale_x = 1.0
            split_848B6.scale_y = 1.0
            split_848B6.alignment = 'Expand'.upper()
            if not True: split_848B6.operator_context = "EXEC_DEFAULT"
            op = split_848B6.operator('sna.mode_projection_d8aa3', text='2D Fill', icon_value=0, emboss=True, depress= not bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Socket_0'])
            op.sna_mode = False
            op = split_848B6.operator('sna.mode_projection_d8aa3', text='Pure Curve', icon_value=0, emboss=True, depress=bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Socket_0'])
            op.sna_mode = True
        else:
            op = layout.operator('sna.create_projection_5cf9e', text='Create Projection', icon_value=120, emboss=True, depress=False)
        if (bpy.context.view_layer.objects.active != None):
            col_9D1AC = layout.column(heading='', align=False)
            col_9D1AC.alert = False
            col_9D1AC.enabled = True
            col_9D1AC.active = True
            col_9D1AC.use_property_split = False
            col_9D1AC.use_property_decorate = False
            col_9D1AC.scale_x = 1.0
            col_9D1AC.scale_y = 1.0
            col_9D1AC.alignment = 'Expand'.upper()
            col_9D1AC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            if property_exists("bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']", globals(), locals()):
                col_4B643 = col_9D1AC.column(heading='', align=False)
                col_4B643.alert = False
                col_4B643.enabled = True
                col_4B643.active = True
                col_4B643.use_property_split = False
                col_4B643.use_property_decorate = False
                col_4B643.scale_x = 1.0
                col_4B643.scale_y = 1.0
                col_4B643.alignment = 'Expand'.upper()
                col_4B643.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                if (bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_24'] == None):
                    op = col_4B643.operator('sna.extended_collection_ac163', text='3 beam', icon_value=31, emboss=True, depress=False)
                row_59C26 = col_4B643.row(heading='', align=False)
                row_59C26.alert = False
                row_59C26.enabled = True
                row_59C26.active = True
                row_59C26.use_property_split = False
                row_59C26.use_property_decorate = False
                row_59C26.scale_x = 1.0
                row_59C26.scale_y = 1.0
                row_59C26.alignment = 'Expand'.upper()
                row_59C26.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_59C26.label(text='length 1', icon_value=0)
                row_59C26.label(text='length 2', icon_value=0)
                if (bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_24'] != None):
                    row_59C26.label(text='length 3', icon_value=0)
                row_C8D34 = col_4B643.row(heading='', align=False)
                row_C8D34.alert = False
                row_C8D34.enabled = True
                row_C8D34.active = True
                row_C8D34.use_property_split = False
                row_C8D34.use_property_decorate = False
                row_C8D34.scale_x = 1.0
                row_C8D34.scale_y = 1.0
                row_C8D34.alignment = 'Expand'.upper()
                row_C8D34.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                attr_77097 = '["' + str('Input_10' + '"]') 
                row_C8D34.prop(bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull'], attr_77097, text='', icon_value=0, emboss=True)
                attr_A58C5 = '["' + str('Input_17' + '"]') 
                row_C8D34.prop(bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull'], attr_A58C5, text='', icon_value=0, emboss=True)
                if (bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_24'] != None):
                    attr_1E5D8 = '["' + str('Input_25' + '"]') 
                    row_C8D34.prop(bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull'], attr_1E5D8, text='', icon_value=0, emboss=True)
                if (bpy.app.version < (4.0, 1.0, 0.0)):
                    attr_E7312 = '["' + str('Input_26' + '"]') 
                    col_4B643.prop(bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull'], attr_E7312, text='Shade Smooth', icon_value=0, emboss=True)
            if 'EDIT_CURVE'==bpy.context.mode:
                col_9D1AC.prop(bpy.context.view_layer.objects.active.data.splines.active, 'resolution_u', text='Resolution Active', icon_value=0, emboss=True)
            else:
                col_9D1AC.prop(bpy.context.view_layer.objects.active.data, 'resolution_u', text='Resolution All', icon_value=0, emboss=True)


class SNA_OT_Create_Projection_5Cf9E(bpy.types.Operator):
    bl_idname = "sna.create_projection_5cf9e"
    bl_label = "Create Projection"
    bl_description = "Creates a 3D model from the active and selected objects"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        sna_new_collection_and_active_32E38_F15CE('Projection Collection', False)
        sna_save_select_and_active1_BF03E()
        sna_true_deselect__all_C6336_71FC7()
        projection_modeling['sna_projection_object'] = None
        sna_active_scene_collection_2B61F_FEE61()
        bpy.ops.mesh.primitive_cube_add(scale=(0.10000000149011612, 0.10000000149011612, 0.10000000149011612))
        bpy.context.view_layer.objects.active.name = 'Projection object'
        if (bpy.app.version < (4.0, 1.0, 0.0)):
            bpy.context.view_layer.objects.active.data.use_auto_smooth = True
            bpy.context.view_layer.objects.active.data.auto_smooth_angle = math.radians(30.0)
        sna_import_geonode_3E625_00041('Projection geonode vovrzull', os.path.join(os.path.dirname(__file__), 'assets', 'Projection geonode vovrzull.blend'))
        projection_modeling['sna_projection_object'] = bpy.context.view_layer.objects.active
        sna_true_deselect__all_C6336_59301()
        sna_new_collection_and_active_32E38_2CC7A('Projection Collection', False)
        sna_create_collection__5AFFD()
        sna_select__set_active_object_07AE7_1688E(projection_modeling['sna_projection_object'])
        bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_6'] = bpy.data.collections[projection_modeling['sna_projection_object'].name + '.1']
        bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_9'] = bpy.data.collections[projection_modeling['sna_projection_object'].name + '.2']
        projection_modeling['sna_projection_object'].update_tag(refresh={'DATA'}, )
        bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull'].show_expanded = False
        item_FE2E9 = bpy.context.scene.sna_collection__name_project.add()
        item_FE2E9.name_projection = bpy.context.view_layer.objects.active.name
        item_FE2E9.pointer__peojection = projection_modeling['sna_projection_object']
        bpy.context.scene.sna_index_projection_activ = int(len(bpy.context.scene.sna_collection__name_project) - 1.0)
        sna_select__set_active_object_07AE7_1A90E(projection_modeling['sna_projection_object'])
        bpy.ops.object.duplicate_move()
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.data.objects.remove(object=bpy.context.view_layer.objects.active, do_unlink=True, do_id_user=True, do_ui_user=True, )
        sna_select__set_active_object_07AE7_5383C(projection_modeling['sna_projection_object'])
        bpy.ops.object.origin_set(type='ORIGIN_CURSOR', center='MEDIAN')
        bpy.ops.view3d.snap_cursor_to_center()
        sna_clean_collection_loft_E308B()
        sna_select__set_active_object_07AE7_0B059(projection_modeling['sna_projection_object'])
        sna_active_scene_collection_2B61F_220E7()
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_curve_options_projection_B404C(Objects):
    if (Objects.type == 'MESH'):
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.remove_doubles()
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.convert(target='CURVE')
        Objects.data.dimensions = '2D'
        Objects.data.fill_mode = 'BOTH'
        Objects.data.resolution_u = 4
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.dissolve_limited(delimit={'NORMAL'})
        bpy.ops.object.mode_set(mode='OBJECT')
    else:
        if (Objects.type == 'CURVE'):
            Objects.data.dimensions = '2D'
            Objects.data.fill_mode = 'BOTH'
            Objects.data.resolution_u = 4


class SNA_OT_Mode_Projection_D8Aa3(bpy.types.Operator):
    bl_idname = "sna.mode_projection_d8aa3"
    bl_label = "Mode Projection"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_mode: bpy.props.BoolProperty(name='Mode', description='', default=False)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Socket_0'] = self.sna_mode
        bpy.context.view_layer.objects.active.update_tag(refresh={'DATA'}, )
        projection_modeling['sna_active_object'] = bpy.context.view_layer.objects.active
        for i_8606C in range(len([bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_6'], bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_9'], bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_24']])):
            if ([bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_6'], bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_9'], bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_24']][i_8606C] != None):
                sna_collection_mode_E5452([bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_6'], bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_9'], bpy.context.view_layer.objects.active.modifiers['Projection geonode vovrzull']['Input_24']][i_8606C], self.sna_mode)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_collection_mode_E5452(Collection_Pointer, Mode):
    for i_B9ABF in range(len(Collection_Pointer.objects)):
        if (Collection_Pointer.objects[i_B9ABF].type == 'MESH'):
            pass
        else:
            Collection_Pointer.objects[i_B9ABF].data.dimensions = '2D'
            Collection_Pointer.objects[i_B9ABF].data.fill_mode = ('NONE' if Mode else 'BOTH')


class SNA_OT_Remesh_Vovrzull_60891(bpy.types.Operator):
    bl_idname = "sna.remesh_vovrzull_60891"
    bl_label = "Remesh vovrzull"
    bl_description = "Rebuilds the mesh on the active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Remesh Vovrzull']", globals(), locals()):
            bpy.context.view_layer.objects.active.modifiers.remove(modifier=bpy.context.view_layer.objects.active.modifiers['Remesh Vovrzull'], )
        else:
            modifier_006FA = bpy.context.view_layer.objects.active.modifiers.new(name='Remesh Vovrzull', type='REMESH', )
            modifier_006FA.mode = 'SHARP'
            modifier_006FA.octree_depth = 5
            modifier_006FA.scale = 0.968999981880188
            modifier_006FA.use_smooth_shade = True
            modifier_006FA.show_expanded = False
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Bevel_Control_Projection_98A23(bpy.types.Operator):
    bl_idname = "sna.bevel_control_projection_98a23"
    bl_label = "Bevel Control Projection"
    bl_description = "Adds a bevel to check the active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull']", globals(), locals()):
            if (bpy.context.view_layer.objects.active != None):
                sna_delete_modification_8D63C('Weld Vovrzull')
                sna_delete_modification_8D63C('Bevel vovrzull')
                sna_delete_modification_8D63C('WeightedNormal')
                if (bpy.app.version < (4.0, 1.0, 0.0)):
                    bpy.context.view_layer.objects.active.data.use_auto_smooth = True
                    bpy.context.view_layer.objects.active.data.auto_smooth_angle = math.radians(30.0)
        else:
            modifier_CCDD2 = bpy.context.view_layer.objects.active.modifiers.new(name='Weld Vovrzull', type='WELD', )
            modifier_CCDD2.show_expanded = False
            modifier_7BFB8 = bpy.context.view_layer.objects.active.modifiers.new(name='Bevel vovrzull', type='BEVEL', )
            modifier_7BFB8.affect = 'EDGES'
            modifier_7BFB8.offset_type = 'OFFSET'
            modifier_7BFB8.segments = 3
            modifier_7BFB8.width = 0.019999999552965164
            modifier_7BFB8.profile = 0.699999988079071
            modifier_7BFB8.miter_outer = 'MITER_ARC'
            modifier_7BFB8.use_clamp_overlap = False
            modifier_7BFB8.show_expanded = False
            if property_exists("bpy.context.view_layer.objects.active.modifiers['WeightedNormal']", globals(), locals()):
                pass
            else:
                modifier_019CF = bpy.context.view_layer.objects.active.modifiers.new(name='WeightedNormal', type='WEIGHTED_NORMAL', )
                modifier_019CF.weight = 50
                modifier_019CF.show_expanded = False
                if (bpy.app.version < (4.0, 1.0, 0.0)):
                    bpy.context.view_layer.objects.active.data.use_auto_smooth = True
                    bpy.context.view_layer.objects.active.data.auto_smooth_angle = math.radians(60.0)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_delete_modification_8D63C(Name_Modoficator):
    if property_exists("bpy.context.view_layer.objects.active.modifiers[Name_Modoficator]", globals(), locals()):
        bpy.context.view_layer.objects.active.modifiers.remove(modifier=bpy.context.view_layer.objects.active.modifiers[Name_Modoficator], )


class SNA_PT_MESH_OPTIMIZATION_FB692(bpy.types.Panel):
    bl_label = 'Mesh optimization'
    bl_idname = 'SNA_PT_MESH_OPTIMIZATION_FB692'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'Projection'
    bl_order = 3
    bl_options = {'DEFAULT_CLOSED'}
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        op = layout.operator('sna.remesh_vovrzull_60891', text='Remesh', icon_value=0, emboss=True, depress=property_exists("bpy.context.view_layer.objects.active.modifiers['Remesh Vovrzull']", globals(), locals()))
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Remesh Vovrzull']", globals(), locals()):
            col_334E8 = layout.column(heading='', align=False)
            col_334E8.alert = False
            col_334E8.enabled = True
            col_334E8.active = True
            col_334E8.use_property_split = False
            col_334E8.use_property_decorate = False
            col_334E8.scale_x = 1.0
            col_334E8.scale_y = 1.0
            col_334E8.alignment = 'Expand'.upper()
            col_334E8.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_334E8.prop(bpy.context.view_layer.objects.active.modifiers['Remesh Vovrzull'], 'octree_depth', text='Octree Depth', icon_value=0, emboss=True)
            col_334E8.prop(bpy.context.view_layer.objects.active.modifiers['Remesh Vovrzull'], 'scale', text='Scale', icon_value=0, emboss=True)
            split_43820 = col_334E8.split(factor=0.47777777910232544, align=False)
            split_43820.alert = False
            split_43820.enabled = True
            split_43820.active = True
            split_43820.use_property_split = False
            split_43820.use_property_decorate = False
            split_43820.scale_x = 1.0
            split_43820.scale_y = 1.0
            split_43820.alignment = 'Expand'.upper()
            if not True: split_43820.operator_context = "EXEC_DEFAULT"
            split_43820.label(text='Smooth Shading', icon_value=0)
            split_43820.prop(bpy.context.view_layer.objects.active.modifiers['Remesh Vovrzull'], 'use_smooth_shade', text='', icon_value=0, emboss=True)
        col_AE563 = layout.column(heading='', align=False)
        col_AE563.alert = False
        col_AE563.enabled = True
        col_AE563.active = True
        col_AE563.use_property_split = False
        col_AE563.use_property_decorate = False
        col_AE563.scale_x = 1.0
        col_AE563.scale_y = 1.0
        col_AE563.alignment = 'Expand'.upper()
        col_AE563.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        col_AE563.separator(factor=0.19000011682510376)
        op = col_AE563.operator('sna.bevel_control_projection_98a23', text='Bevel', icon_value=0, emboss=True, depress=property_exists("bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull']", globals(), locals()))
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull']", globals(), locals()):
            col_CED08 = col_AE563.column(heading='', align=False)
            col_CED08.alert = False
            col_CED08.enabled = True
            col_CED08.active = True
            col_CED08.use_property_split = False
            col_CED08.use_property_decorate = False
            col_CED08.scale_x = 1.0
            col_CED08.scale_y = 1.0
            col_CED08.alignment = 'Expand'.upper()
            col_CED08.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            col_CED08.prop(bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull'], 'width', text='Amount', icon_value=0, emboss=True)
            col_CED08.prop(bpy.context.view_layer.objects.active.modifiers['Bevel vovrzull'], 'segments', text='Segments', icon_value=0, emboss=True)
        if property_exists("bpy.context.view_layer.objects.active.modifiers['Weld Vovrzull']", globals(), locals()):
            col_AE563.prop(bpy.context.view_layer.objects.active.modifiers['Weld Vovrzull'], 'merge_threshold', text='Weld', icon_value=0, emboss=True)


class SNA_GROUP_sna_project_name_group(bpy.types.PropertyGroup):
    name_projection: bpy.props.StringProperty(name='Name Projection', description='', default='', subtype='NONE', maxlen=0)
    pointer__peojection: bpy.props.PointerProperty(name='Pointer  Peojection', description='', type=bpy.types.Object)


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_GROUP_sna_project_name_group)
    bpy.types.Scene.sna_index_projection_activ = bpy.props.IntProperty(name='Index Projection activ', description='', default=0, subtype='NONE', update=sna_update_sna_index_projection_activ_CE712)
    bpy.types.Scene.sna_collection__name_project = bpy.props.CollectionProperty(name='Collection  Name Project', description='', type=SNA_GROUP_sna_project_name_group)
    bpy.types.Scene.sna_active_index_projections = bpy.props.IntProperty(name='active index projections', description='', default=0, subtype='NONE', update=sna_update_sna_active_index_projections_931CD)
    bpy.types.Scene.sna_index_collection = bpy.props.IntProperty(name='Index collection', description='', default=1, subtype='NONE')
    bpy.types.Scene.sna_shade_smooth_41 = bpy.props.BoolProperty(name='Shade smooth 41', description='', default=False)
    bpy.utils.register_class(SNA_OT_Bevel_Curve_14Cd3)
    bpy.utils.register_class(SNA_OT_Straight_993E5)
    bpy.utils.register_class(SNA_PT_CURVE_EDIT_888F5)
    bpy.types.OUTLINER_HT_header.append(sna_add_to_outliner_ht_header_0D25B)
    bpy.utils.register_class(SNA_OT_Extended_Collection_Ac163)
    bpy.utils.register_class(SNA_AddonPreferences_C793C)
    bpy.utils.register_class(SNA_OT_Blender_Market_Link_C384F)
    bpy.utils.register_class(SNA_OT_Youtube_F99B6)
    bpy.utils.register_class(SNA_OT_Boosty_Ff383)
    bpy.utils.register_class(SNA_OT_Correct_Origin_Projections_C843B)
    bpy.utils.register_class(SNA_OT_Rotate_Origin_180_14B9D)
    bpy.utils.register_class(SNA_OT_Collection_Hide_Projection1_Dc253)
    bpy.utils.register_class(SNA_OT_Rebuild_The_List_Projections_6332F)
    bpy.utils.register_class(SNA_OT_Clean_Delete_Projection_07204)
    bpy.utils.register_class(SNA_OT_Delete_Active_Projection_List_B9Afa)
    bpy.utils.register_class(SNA_PT_PROJECTION_CONTROL__4E6C2)
    bpy.utils.register_class(SNA_UL_display_collection_list_EA44E)
    bpy.utils.register_class(SNA_OT_Remove_From_Projections_Bda61)
    bpy.utils.register_class(SNA_OT_Objects_Beam_Swith_3Ba15)
    bpy.utils.register_class(SNA_PT_OBJECTS_FOR_PROJECTION_A3469)
    bpy.utils.register_class(SNA_UL_display_collection_list001_745C6)
    bpy.utils.register_class(SNA_OT_Add__Objects_Projection1_A4336)
    bpy.utils.register_class(SNA_OT_Dublicate_And_Aplly_Project_Bae9D)
    bpy.utils.register_class(SNA_OT_Apply_6Bcbb)
    bpy.utils.register_class(SNA_OT_Update_Curve_Collection_6124C)
    bpy.utils.register_class(SNA_PT_PROJECTION_MODELING_8A13B)
    bpy.utils.register_class(SNA_OT_Create_Projection_5Cf9E)
    bpy.utils.register_class(SNA_OT_Mode_Projection_D8Aa3)
    bpy.utils.register_class(SNA_OT_Remesh_Vovrzull_60891)
    bpy.utils.register_class(SNA_OT_Bevel_Control_Projection_98A23)
    bpy.utils.register_class(SNA_PT_MESH_OPTIMIZATION_FB692)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    del bpy.types.Scene.sna_shade_smooth_41
    del bpy.types.Scene.sna_index_collection
    del bpy.types.Scene.sna_active_index_projections
    del bpy.types.Scene.sna_collection__name_project
    del bpy.types.Scene.sna_index_projection_activ
    bpy.utils.unregister_class(SNA_GROUP_sna_project_name_group)
    bpy.utils.unregister_class(SNA_OT_Bevel_Curve_14Cd3)
    bpy.utils.unregister_class(SNA_OT_Straight_993E5)
    bpy.utils.unregister_class(SNA_PT_CURVE_EDIT_888F5)
    bpy.types.OUTLINER_HT_header.remove(sna_add_to_outliner_ht_header_0D25B)
    bpy.utils.unregister_class(SNA_OT_Extended_Collection_Ac163)
    bpy.utils.unregister_class(SNA_AddonPreferences_C793C)
    bpy.utils.unregister_class(SNA_OT_Blender_Market_Link_C384F)
    bpy.utils.unregister_class(SNA_OT_Youtube_F99B6)
    bpy.utils.unregister_class(SNA_OT_Boosty_Ff383)
    bpy.utils.unregister_class(SNA_OT_Correct_Origin_Projections_C843B)
    bpy.utils.unregister_class(SNA_OT_Rotate_Origin_180_14B9D)
    bpy.utils.unregister_class(SNA_OT_Collection_Hide_Projection1_Dc253)
    bpy.utils.unregister_class(SNA_OT_Rebuild_The_List_Projections_6332F)
    bpy.utils.unregister_class(SNA_OT_Clean_Delete_Projection_07204)
    bpy.utils.unregister_class(SNA_OT_Delete_Active_Projection_List_B9Afa)
    bpy.utils.unregister_class(SNA_PT_PROJECTION_CONTROL__4E6C2)
    bpy.utils.unregister_class(SNA_UL_display_collection_list_EA44E)
    bpy.utils.unregister_class(SNA_OT_Remove_From_Projections_Bda61)
    bpy.utils.unregister_class(SNA_OT_Objects_Beam_Swith_3Ba15)
    bpy.utils.unregister_class(SNA_PT_OBJECTS_FOR_PROJECTION_A3469)
    bpy.utils.unregister_class(SNA_UL_display_collection_list001_745C6)
    bpy.utils.unregister_class(SNA_OT_Add__Objects_Projection1_A4336)
    bpy.utils.unregister_class(SNA_OT_Dublicate_And_Aplly_Project_Bae9D)
    bpy.utils.unregister_class(SNA_OT_Apply_6Bcbb)
    bpy.utils.unregister_class(SNA_OT_Update_Curve_Collection_6124C)
    bpy.utils.unregister_class(SNA_PT_PROJECTION_MODELING_8A13B)
    bpy.utils.unregister_class(SNA_OT_Create_Projection_5Cf9E)
    bpy.utils.unregister_class(SNA_OT_Mode_Projection_D8Aa3)
    bpy.utils.unregister_class(SNA_OT_Remesh_Vovrzull_60891)
    bpy.utils.unregister_class(SNA_OT_Bevel_Control_Projection_98A23)
    bpy.utils.unregister_class(SNA_PT_MESH_OPTIMIZATION_FB692)
