# RLX Auto Fit Addon v1.6.0 (Beta)
# Created by Robert White
# aka Created by Athayus Quan

# Realystic - https://realystic.com
# Copyright (c) 2021-2025

Co Developers 
& Alpha Team:

 - Leigh Avelino
 - Lyxia Watler

## Overview

RLX Auto Fit is a powerful Blender addon designed to automatically fit clothing items to one or multiple body targets. It offers advanced adaptive fitting with individual target body assignments and improved 3D shape preservation. Information on latest beta version. These features subject to change or be improved n via community feedback and as I improve at programming this and my other addons.

## Features v1.6.0 (New)
 = Preserve Fine Details

 = Optionally reduces over-shrinking or smoothing out small mesh elements. You can keep pockets, buckles, 
   or similar details intact by excluding them from heavy smoothing/shrinkwrap.
 = Displacement Map Support

 = Allows adding a Displacement modifier for extra surface detail.
 = Exposes strength and mid-level controls in the UI.
 = Advanced Normal Handling

 =  Adds an option to transfer tangents/split normals or to run Weighted Normal/Normal Edit after fitting.
 = Helps keep fitted meshes looking consistent and smooth.
 = Strap Mesh Fitting

 = Applies shrinkwrap to accessories (like belts, straps) against the clothing mesh itself (rather than the body).
 = Includes an offset option to keep the strap from clipping through the clothing.
 = Improved Vertex Group Workflow

 = Combines new or existing vertex groups to handle partial shrinkwrap.
 = More precise control over body-contact areas vs. detail areas.


## Features v1.5.9 (New)
 = Optional Use of a Collection for Array

 = Enables duplicating objects from a specific collection instead of the currently selected objects.
 = Keeps the same array layout functionality while letting you duplicate entire collections at once.
 = Add Items from a Collection to Fitting

 = Lets you bulk-add all mesh objects in a chosen collection to your fitting list.
 = Streamlines setup when dealing with multiple objects in a collection.


## Features 1.1.7

### 1. Multi-Target Fitting
- Assign multiple target bodies to a single clothing item
- Set individual weights for each target body
- Blend between multiple body shapes for complex fitting scenarios

### 2. Fitting Methods
#### Classic Method
- Uses Shrinkwrap modifier for basic fitting
- Suitable for simple clothing items or quick fits

#### Improved Method
- Utilizes Surface Deform and Adaptive Shrinkwrap modifiers
- Better preserves 3D shapes and details
- Ideal for complex clothing items or when higher quality is needed

### 3. Modifier Controls
- Shrinkwrap Offset: Adjust the distance between the clothing and the body
- Surface Deform Falloff: Control how far the deformation influence extends
- Adaptive Shrinkwrap Factor: Fine-tune the shrinkwrap behavior based on size differences
- Smooth Factor and Iterations: Refine the surface smoothness of fitted clothing
- Corrective Smooth Iterations: Further improve the final shape after fitting

### 4. Array Creation
- Quickly create arrays of selected objects
- Adjust array count directly from the addon panel

### 5. Object Operations
- Join Objects: Combine multiple selected objects into one
- Separate Objects: Split joined objects back into individual pieces
- Set Origin to Geometry: Quickly center the origin point of selected objects

### 6. Selection Tools
- Select Assigned Outfits: Easily select all clothing items that have been assigned to target bodies

### 7. Preset System
- Save current settings as named presets
- Load presets to quickly apply saved configurations
- Manage multiple fitting setups for different scenarios

### 8. User Interface
- Intuitive panel in the 3D Viewport sidebar
- Easy-to-use list for managing target objects and their assigned bodies
- Quick access to all major functions and settings

## How to Use

1. **Adding Objects**: Select the clothing items you want to fit and click "Add" in the addon panel.
2. **Assigning Target Bodies**: For each clothing item, click the dropdown arrow and add one or more target bodies.
3. **Choosing Fitting Method**: Select either "Classic" or "Improved" fitting method based on your needs.
4. **Adjusting Parameters**: Fine-tune the fitting parameters as needed.
5. **Applying Fit**: Click "Apply Fitting Modifiers" to add the necessary modifiers to your clothing items.
6. **Finalizing**: Use "Apply All Modifiers" to finalize the fit when satisfied with the results.

## Tips and Tricks

- Use the "Improved" method for complex clothing items or when you need to preserve intricate details.
- Experiment with different weight values when using multiple target bodies to achieve the desired blend.
- Save presets for commonly used configurations to speed up your workflow.
- The "Select Assigned Outfits" function is helpful for managing complex scenes with many clothing items.

## Troubleshooting

- If the fit is too tight or loose, adjust the Shrinkwrap Offset or Adaptive Shrinkwrap Factor.
- For unwanted deformations, try increasing the Surface Deform Falloff or adjusting the Smooth Factor.
- If the addon is running slowly, consider applying modifiers to objects you're no longer actively fitting.

## System Requirements

- Blender 3.6.19 LTS / 4.2.5 LTS / 4.3.2
- Compatible with Windows, macOS, and Linux

Please Note this addon is currently in beta and layout, functions and settings subject to change.

## Support

Real Life Support:
For additional help, bug reports, or feature requests, please visit our support page at 
https://realystic.com/blog/rlx-auto-fitter-addon
https://realystic.com/docs/ (WIP)
https://realystic.com/blog/
info@realystic.com
Programmed by: Robert White

If you need help reach out via contact below for various game or virtual platforms.

Second Life Support:
AQ Originals: https://aqn.me/
Avatar: Athayus Quan (Legacy Name)
discord: Athayus

https://realystic.com/page/rlx-licensing
---

Thank you for using RLX Auto Fit! We hope this addon enhances your 3D clothing creation workflow.

-------------------------------------------------------------------------
This addon is for release only on https://realystic.com/ 
-------------------------------------------------------------------------
And is not for release with 3rd parties without permission
If you find someone trying to sell this addon outside of
Realystic please contact us via info@realystic.com

Life Time updates and support only from Realystic.com, if you get this
file elsewhere and want full support and future updated releases 
please buy from Realystic, Robert White/ Athayus Quan only.
=========================================================================
Copyright (c) 2024-2025, Realystic.com, All Rights Reserved
=========================================================================
