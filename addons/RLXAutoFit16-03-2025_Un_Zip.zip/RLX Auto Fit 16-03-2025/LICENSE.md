# RLX Auto Fit Addon v1.6.0
# Created by Robert White
# Realystic - https://realystic.com
# Copyright (c) 2021-2025

## License Information

RLX Auto Fit is offered under three license tiers to accommodate different user needs. This licensing structure reflects over 3.5 years of dedicated development and significant intellectual property investment by Realystic.

### Relationship with Blender and GPL
While Blender is released under the GNU General Public License (GPL), RLX Auto Fit is released under this proprietary license. This is in line with Blender's policy that addons can be released under any license, as they are separate works that only use Blender's API.

### Updates and Support
Realystic may provide updates or upgrades to the SOFTWARE PRODUCT, subject to the terms of this Agreement unless other terms are provided with the updates or upgrades. I've simplified my license at the link below.

For complete license terms, please refer to the LICENSE.txt file included with the addon or visit https://realystic.com/page/rlx-licensing

## Disclaimer

RLX Auto Fit is provided "as is" without warranty of any kind. Realystic expressly disclaims any warranty for the SOFTWARE PRODUCT, including any express or implied warranty of merchantability, fitness for a particular purpose, or non-infringement.

Realystic shall not be liable for any damages arising out of the use of or inability to use the SOFTWARE PRODUCT, including but not limited to lost profits, business interruption, or lost information.

When using our tools, addons or any 3rd party programs with blender always make sure to backup your work as you work on content. 

By using RLX Auto Fit, you agree to abide by the terms of the license agreement. If you have any questions about the licensing, please contact Realystic at https://realystic.com.

© 2025 Realystic. All rights reserved. RLX Auto Fit is a product of over 3.5 years of development and represents significant intellectual property of Realystic.com & Robert White (Athayus).

-------------------------------------------------------------------------
This addon is for release only on https://realystic.com/ 
-------------------------------------------------------------------------
And is not for release with 3rd parties without permission
If you find someone trying to sell this addon outside of
Realystic please contact us via info@realystic.com

Life Time updates and support only from Realystic.com, if you get this
file elsewhere and want full support and future updated releases 
please buy from Realystic, Robert White/ Athayus Quan only.
=========================================================================
Copyright (c) 2024-2025, Realystic.com, All Rights Reserved
=========================================================================

