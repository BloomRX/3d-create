bl_info = {
    "name": "RLX Auto Fit",
    "author": "Realystic (Robert White)",
    "version": (1, 6, 0),
    "blender": (4, 3, 2), 
    "location": "View3D > Sidebar > RLX Tab",
    "description": "Automatically fit clothing items with advanced fitting for multiple objects, collections, and detail preservation.",
    "category": "Object",
    "wiki_url": "https://realystic.com/blog",
    "doc_url": "https://realystic.com/docs",
    "tracker_url": "https://realystic.com/page/rlx-licensing",
    "license": "Proprietary",
    "copyright": "2025",
}

import bpy
import os
import json
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    IntProperty,
    StringProperty,
    FloatProperty,
    FloatVectorProperty,
    EnumProperty,
    PointerProperty,
)
from bpy.types import (
    Operator,
    Panel,
    PropertyGroup,
    UIList,
)

# ------------------------------------------------------
# v1.6.0: NEW Advanced Options (with detail preservation)
# ------------------------------------------------------

def apply_strap_shrinkwrap(obj, context):
    """
    Applies a Shrinkwrap modifier targeting the clothing mesh,
    optionally offset by user-defined offset.
    """
    scene = context.scene
    target = scene.rlx_strap_target
    if not target or target.type != 'MESH':
        return  # No valid strap target

    strap_mod = obj.modifiers.new(name="RLX Strap Shrinkwrap", type='SHRINKWRAP')
    strap_mod.target = target
    strap_mod.wrap_method = 'NEAREST_SURFACEPOINT'
    strap_mod.wrap_mode = 'OUTSIDE'
    strap_mod.offset = scene.rlx_strap_offset
    strap_mod.show_on_cage = True

def preserve_details_with_vertex_groups(obj, context):
    """
    Reduce shrinkwrap effect on vertices belonging to the 'Detail' group by scaling
    their shrinkwrap weight to 20% of the usual value.
    """
    if not context.scene.rlx_preserve_fine_details:
        return

    detail_vg = obj.vertex_groups.get("Detail")
    if not detail_vg:
        return

    # We'll reduce the shrinkwrap weight wherever detail weight > 0.
    # For each RLX Shrinkwrap modifier, we do:
    #   1. Identify the assigned vertex group (vg).
    #   2. Create a new combined group that merges vg with "Detail" so that
    #      detail areas get only 0.2 * the original weight.
    #   3. Reassign the modifier to the new combined group.

    factor = 0.2  # 20% of the original weight in detail areas

    for mod in obj.modifiers:
        if mod.type == 'SHRINKWRAP' and mod.name.startswith("RLX Shrinkwrap"):
            existing_vg_name = mod.vertex_group
            if not existing_vg_name:
                continue  # No vertex group assigned to this Shrinkwrap mod

            if existing_vg_name not in obj.vertex_groups:
                continue

            existing_vg_index = obj.vertex_groups[existing_vg_name].index
            detail_vg_index = detail_vg.index

            combined_vg_name = existing_vg_name + "_combined_detail"
            # If there's an old combined group lying around, remove it
            if combined_vg_name in obj.vertex_groups:
                obj.vertex_groups.remove(obj.vertex_groups[combined_vg_name])

            combined_vg = obj.vertex_groups.new(name=combined_vg_name)

            # We'll compute final weights for each vertex:
            #   if detail_weight > 0 => final_weight = existing_weight * factor
            #   else => final_weight = existing_weight
            num_verts = len(obj.data.vertices)
            final_weights = [0.0] * num_verts

            for v in obj.data.vertices:
                e_w = 0.0
                d_w = 0.0
                for g in v.groups:
                    if g.group == existing_vg_index:
                        e_w = g.weight
                    elif g.group == detail_vg_index:
                        d_w = g.weight

                if d_w > 0.0:
                    final_weights[v.index] = e_w * factor
                else:
                    final_weights[v.index] = e_w

            # Now assign these final_weights to the combined group
            for i, w in enumerate(final_weights):
                if w > 0.0:
                    combined_vg.add([i], w, 'REPLACE')

            # Switch the modifier to the new group
            mod.vertex_group = combined_vg_name

def add_displacement_modifier(obj, context):
    """
    Optionally adds a Displacement modifier to the mesh.
    """
    if not context.scene.rlx_enable_displacement:
        return

    disp_mod = obj.modifiers.new(name="RLX Displacement", type='DISPLACE')
    disp_mod.strength = context.scene.rlx_displacement_strength
    disp_mod.mid_level = 0.0

def improve_normals(obj, context):
    """
    Demonstrates optional Weighted Normal usage.
    """
    if not context.scene.rlx_improve_normals:
        return

    wn_mod = obj.modifiers.new(name="RLX Weighted Normal", type='WEIGHTED_NORMAL')
    wn_mod.weight = 50
    wn_mod.keep_sharp = True
    wn_mod.mode = 'FACE_AREA'
    wn_mod.show_in_editmode = False
    wn_mod.show_on_cage = True

# ---------------------------
# Update functions (unchanged)
# ---------------------------
def update_modifier_settings(self, context):
    for item in context.scene.rlx_target_objects:
        obj = item.object
        if obj and obj.type == 'MESH':
            for mod in obj.modifiers:
                if mod.type == 'SHRINKWRAP' and mod.name.startswith("RLX Shrinkwrap"):
                    mod.offset = context.scene.rlx_shrinkwrap_offset
                elif mod.type == 'CORRECTIVE_SMOOTH' and mod.name.startswith("RLX Corrective Smooth"):
                    mod.iterations = context.scene.rlx_shrinkwrap_smooth_iterations
                    mod.use_only_smooth = context.scene.rlx_corrective_smooth_only_smooth
                    mod.smooth_type = context.scene.rlx_corrective_smooth_type
                    mod.show_viewport = context.scene.rlx_use_corrective_smooth

def update_array_count(self, context):
    for obj in context.selected_objects:
        if obj.type == 'MESH':
            array_mod = next((mod for mod in obj.modifiers if mod.type == 'ARRAY' and mod.name.startswith("RLX Array")), None)
            if array_mod:
                array_mod.count = context.scene.rlx_array_count

def update_array_spacing(self, context):
    for obj in context.selected_objects:
        if obj.type == 'MESH':
            array_mod = next((mod for mod in obj.modifiers if mod.type == 'ARRAY' and mod.name.startswith("RLX Array")), None)
            if array_mod:
                array_mod.relative_offset_displace[0] = context.scene.rlx_array_spacing

def update_array_direction(self, context):
    for obj in context.selected_objects:
        if obj.type == 'MESH':
            array_mod = next((mod for mod in obj.modifiers if mod.type == 'ARRAY' and mod.name.startswith("RLX Array")), None)
            if array_mod:
                direction = context.scene.rlx_array_direction
                if direction == 'X':
                    array_mod.relative_offset_displace = (context.scene.rlx_array_spacing, 0.0, 0.0)
                elif direction == 'Y':
                    array_mod.relative_offset_displace = (0.0, context.scene.rlx_array_spacing, 0.0)
                elif direction == 'Z':
                    array_mod.relative_offset_displace = (0.0, 0.0, context.scene.rlx_array_spacing)

# -----------------------------
# Preset Manager (unchanged)
# -----------------------------
class RLXPresetManager:
    @staticmethod
    def save_preset(name, data):
        presets_path = bpy.utils.user_resource('SCRIPTS', path="presets", create=True)
        file_path = os.path.join(presets_path, f"{name}.json")
        with open(file_path, 'w') as f:
            json.dump(data, f)

    @staticmethod
    def load_preset(name):
        presets_path = bpy.utils.user_resource('SCRIPTS', path="presets")
        file_path = os.path.join(presets_path, f"{name}.json")
        with open(file_path, 'r') as f:
            return json.load(f)

    @staticmethod
    def get_preset_list(self, context):
        presets_path = bpy.utils.user_resource('SCRIPTS', path="presets")
        if not os.path.exists(presets_path):
            return []
        return [(f[:-5], f[:-5], "") for f in os.listdir(presets_path) if f.endswith(".json")]

# -----------------------------
# Property Groups (unchanged)
# -----------------------------
class RLXTargetBody(PropertyGroup):
    body: PointerProperty(name="Target Body", type=bpy.types.Object)
    weight: FloatProperty(name="Weight", default=1.0, min=0.0, max=1.0, subtype='FACTOR')

class RLXTargetItem(PropertyGroup):
    object: PointerProperty(name="Object", type=bpy.types.Object)
    target_bodies: CollectionProperty(type=RLXTargetBody)
    original_mesh: PointerProperty(name="Original Mesh", type=bpy.types.Mesh)
    detailed_regions: BoolProperty(name="Has Detailed Regions", default=False)
    original_object_name: StringProperty(name="Original Object Name", default="")
    group_id: StringProperty(name="Group ID", default="")

# -----------------------------
# UI Lists (unchanged)
# -----------------------------
class RLX_UL_object_list(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        if item.object:
            row = layout.row(align=True)
            select_op = row.operator("rlx.select_object_in_viewport", text="", icon='RESTRICT_SELECT_OFF', emboss=False)
            select_op.object_name = item.object.name

            row.prop(item.object, "name", text="", emboss=False, icon='OBJECT_DATAMODE')

            if len(item.target_bodies) > 0:
                row.label(text=f"{len(item.target_bodies)} targets")
            else:
                row.label(text="No targets")

            if item.detailed_regions:
                row.label(text="", icon='MESH_GRID')

            op = row.operator("rlx.edit_target_bodies", text="", icon='DOWNARROW_HLT')
            op.object_index = index

# -----------------------------
# Panels
# -----------------------------
class RLX_PT_MainPanel(Panel):
    bl_label = "RLX Auto Fit v1.6.0"
    bl_idname = "RLX_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'RLX'

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        op_box = layout.box()
        op_box.prop(scene, "rlx_ui_show_operations", text="Operations", icon="TRIA_DOWN" if scene.rlx_ui_show_operations else "TRIA_RIGHT", emboss=False)
        if scene.rlx_ui_show_operations:
            op_col = op_box.column(align=True)

            row_use_collection = op_col.row(align=True)
            row_use_collection.prop(scene, "rlx_enable_collection_array", text="Use Collection for Array")
            row_use_collection.prop(scene, "rlx_array_collection", text="")

            array_row = op_col.row(align=True)
            array_row.operator("object.rlx_create_array", text="Create Array")
            array_row.prop(scene, "rlx_array_count", text="Count")
            array_row.prop(scene, "rlx_array_spacing", text="Spacing")

            preserve_group_row = op_col.row(align=True)
            preserve_group_row.prop(scene, "rlx_preserve_groups_in_array", text="Preserve Groups")

            direction_row = op_col.row(align=True)
            direction_row.prop(scene, "rlx_array_direction", text="Array Direction")

            join_separate_row = op_col.row(align=True)
            join_separate_row.operator("object.rlx_join_objects", text="Join Objects")
            join_separate_row.operator("object.rlx_separate_objects", text="Separate Objects")

            join_per_body_row = op_col.row(align=True)
            join_per_body_row.operator("object.rlx_join_objects_per_body", text="Join Objects Per Body")

        mod_box = layout.box()
        mod_box.prop(scene, "rlx_ui_show_fitting", text="Fitting Settings", icon="TRIA_DOWN" if scene.rlx_ui_show_fitting else "TRIA_RIGHT", emboss=False)
        if scene.rlx_ui_show_fitting:
            mod_col = mod_box.column(align=True)
            mod_row = mod_col.row()
            mod_row.template_list("RLX_UL_object_list", "", scene, "rlx_target_objects", scene, "rlx_target_objects_index", rows=3)
            mod_ops = mod_col.row(align=True)
            mod_ops.operator('rlx.add_object_to_list', text="Add")
            mod_ops.operator('rlx.remove_object_from_list', text="Remove")
            mod_ops.operator('rlx.clear_object_list', text="Clear")

            col_ops = mod_col.row(align=True)
            col_ops.prop(scene, "rlx_enable_collection_fitting", text="Collection Fitting")
            col_ops.operator("rlx.add_collection_to_fitting", text="Add Collection")

            mod_col.separator()
            mod_col.prop(scene, "rlx_shrinkwrap_offset")
            mod_col.prop(scene, "rlx_shrinkwrap_smooth_iterations")
            mod_col.prop(scene, "rlx_use_corrective_smooth", text="Enable Corrective Smooth")
            mod_col.prop(scene, "rlx_corrective_smooth_only_smooth", text="Only Smooth")
            mod_col.prop(scene, "rlx_corrective_smooth_type", text="Smooth Type")

            mod_col.separator()
            mod_col.operator("object.rlx_apply_fitting_modifiers", text="Add Fitting Modifiers")
            mod_col.operator("object.rlx_apply_modifiers_to_selected", text="Apply All Modifiers")

        sel_box = layout.box()
        sel_box.prop(scene, "rlx_ui_show_selection_tools", text="Selection Tools", icon="TRIA_DOWN" if scene.rlx_ui_show_selection_tools else "TRIA_RIGHT", emboss=False)
        if scene.rlx_ui_show_selection_tools:
            sel_col = sel_box.column(align=True)
            sel_col.operator("rlx.select_assigned_clothing", text="Select Assigned Outfits")
            sel_col.operator("object.rlx_set_origin_to_geometry", text="Set Origin to Geometry")

        adv_box = layout.box()
        adv_box.prop(scene, "rlx_ui_show_advanced_fitting", text="Advanced Options", icon="TRIA_DOWN" if scene.rlx_ui_show_advanced_fitting else "TRIA_RIGHT", emboss=False)
        if scene.rlx_ui_show_advanced_fitting:
            adv_col = adv_box.column(align=True)
            adv_col.prop(scene, "rlx_preserve_fine_details", text="Preserve Fine Details")
            adv_col.prop(scene, "rlx_enable_displacement", text="Enable Displacement")
            if scene.rlx_enable_displacement:
                adv_col.prop(scene, "rlx_displacement_strength", text="Displacement Strength")

            adv_col.prop(scene, "rlx_improve_normals", text="Improve Normals")

            adv_col.separator()
            adv_col.prop(scene, "rlx_enable_strap_mesh", text="Enable Strap Mesh Fitting")
            if scene.rlx_enable_strap_mesh:
                adv_col.prop(scene, "rlx_strap_target", text="Clothing Target")
                adv_col.prop(scene, "rlx_strap_offset", text="Strap Offset")
                adv_col.operator("rlx.apply_strap_fitting", text="Apply Strap Fitting")

class RLX_PT_PresetPanel(Panel):
    bl_label = "Presets"
    bl_idname = "RLX_PT_preset_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'RLX'
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row(align=True)
        row.prop(scene, "rlx_preset_name", text="")
        row.operator("rlx.save_preset", text="Save Preset")

        layout.prop(scene, "rlx_preset_list", text="")
        layout.operator("rlx.load_preset", text="Load Preset")

# -----------------------------
# Operators
# -----------------------------
class RLX_OT_SetOriginToGeometry(Operator):
    bl_idname = "object.rlx_set_origin_to_geometry"
    bl_label = "Set Origin to Geometry"
    bl_description = "Set the origin of the selected objects to their geometry center"

    def execute(self, context):
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                context.view_layer.objects.active = obj
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
        self.report({'INFO'}, "Origin set to geometry for selected objects.")
        return {'FINISHED'}

class RLX_OT_AddObjectToList(Operator):
    bl_idname = "rlx.add_object_to_list"
    bl_label = "Add Selected Objects to List"
    bl_description = "Add all selected mesh objects to the fitting list"

    def execute(self, context):
        added_count = 0
        for obj in context.selected_objects:
            if obj.type == 'MESH':
                if not any(item.object == obj for item in context.scene.rlx_target_objects):
                    item = context.scene.rlx_target_objects.add()
                    item.object = obj
                    item.original_object_name = obj.name
                    item.original_mesh = obj.data.copy()
                    item.group_id = obj.get("RLX_Group_ID", "")
                    added_count += 1
        if added_count > 0:
            self.report({'INFO'}, f"Added {added_count} objects to the list.")
        else:
            self.report({'WARNING'}, "No new objects were added to the list.")
        return {'FINISHED'}

class RLX_OT_RemoveObjectFromList(Operator):
    bl_idname = "rlx.remove_object_from_list"
    bl_label = "Remove Object from List"

    def execute(self, context):
        list = context.scene.rlx_target_objects
        index = context.scene.rlx_target_objects_index
        if index < 0 or index >= len(list):
            self.report({'WARNING'}, "No object selected to remove.")
            return {'CANCELLED'}

        item = list[index]
        if item.original_mesh:
            bpy.data.meshes.remove(item.original_mesh)
        list.remove(index)
        self.report({'INFO'}, "Removed selected object from the list.")
        return {'FINISHED'}

class RLX_OT_ClearObjectList(Operator):
    bl_idname = "rlx.clear_object_list"
    bl_label = "Clear Object List"
    bl_description = "Clear all objects from the list"

    def execute(self, context):
        list = context.scene.rlx_target_objects
        for item in list:
            if item.original_mesh:
                bpy.data.meshes.remove(item.original_mesh)
        list.clear()
        self.report({'INFO'}, "Cleared all objects from the list.")
        return {'FINISHED'}

class RLX_OT_EditTargetBodies(Operator):
    bl_idname = "rlx.edit_target_bodies"
    bl_label = "Edit Target Bodies"
    bl_description = "Edit target bodies for the selected object"

    object_index: IntProperty()
    apply_to_all: BoolProperty(name="Apply to All Selected", default=False)

    def execute(self, context):
        scene = context.scene
        item = scene.rlx_target_objects[self.object_index]

        if self.apply_to_all:
            selected_items = [it for it in scene.rlx_target_objects if it.object and it.object.select_get()]
            selected_items = [other_item for other_item in selected_items if other_item != item]

            target_bodies_data = [(tb.body, tb.weight) for tb in item.target_bodies]

            for other_item in selected_items:
                other_item.target_bodies.clear()
                for body, weight in target_bodies_data:
                    new_tb = other_item.target_bodies.add()
                    new_tb.body = body
                    new_tb.weight = weight

        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        item = scene.rlx_target_objects[self.object_index]

        layout.prop(self, "apply_to_all", text="Apply to All Selected Objects")

        for i, target_body in enumerate(item.target_bodies):
            box = layout.box()
            row = box.row()
            row.prop_search(target_body, "body", bpy.data, "objects", text=f"Target {i+1}")
            row.prop(target_body, "weight", text="Weight")
            remove_op = row.operator("rlx.remove_target_body", text="", icon='X')
            remove_op.object_index = self.object_index
            remove_op.target_index = i

        add_op = layout.operator("rlx.add_target_body", text="Add Target Body")
        add_op.object_index = self.object_index

class RLX_OT_AddTargetBody(Operator):
    bl_idname = "rlx.add_target_body"
    bl_label = "Add Target Body"
    bl_description = "Add a new target body to the selected object"

    object_index: IntProperty()

    def execute(self, context):
        scene = context.scene
        item = scene.rlx_target_objects[self.object_index]
        item.target_bodies.add()
        return {'FINISHED'}

class RLX_OT_RemoveTargetBody(Operator):
    bl_idname = "rlx.remove_target_body"
    bl_label = "Remove Target Body"
    bl_description = "Remove a target body from the selected object"

    object_index: IntProperty()
    target_index: IntProperty()

    def execute(self, context):
        scene = context.scene
        item = scene.rlx_target_objects[self.object_index]
        if self.target_index < 0 or self.target_index >= len(item.target_bodies):
            self.report({'WARNING'}, "Invalid target body index.")
            return {'CANCELLED'}
        item.target_bodies.remove(self.target_index)
        return {'FINISHED'}

class RLX_OT_SelectObjectInViewport(Operator):
    bl_idname = "rlx.select_object_in_viewport"
    bl_label = "Select Object in Viewport"
    bl_description = "Select this object in the 3D Viewport"

    object_name: StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        if obj:
            view_layer_objects = [o.name for o in context.view_layer.objects]
            if obj.name in view_layer_objects:
                for obj_in_view in context.view_layer.objects:
                    obj_in_view.select_set(False)
                obj.select_set(True)
                context.view_layer.objects.active = obj
            else:
                context.collection.objects.link(obj)
                obj.select_set(True)
                context.view_layer.objects.active = obj
        else:
            self.report({'ERROR'}, f"Object '{self.object_name}' not found.")
        return {'FINISHED'}

class RLX_OT_CreateArray(Operator):
    bl_idname = "object.rlx_create_array"
    bl_label = "Create Array"
    bl_description = "Create an array of the selected objects (or a chosen collection) with specified count and spacing"

    def execute(self, context):
        scene = context.scene
        spacing = scene.rlx_array_spacing
        preserve_groups = scene.rlx_preserve_groups_in_array
        direction = scene.rlx_array_direction
        array_count = scene.rlx_array_count
        array_spacing = spacing

        added_count = 0

        if scene.rlx_enable_collection_array and scene.rlx_array_collection:
            src_objects = [o for o in scene.rlx_array_collection.objects if o.type == 'MESH']
        else:
            src_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']

        for obj in src_objects:
            original_group_id = obj.get("RLX_Group_ID", "")
            for i in range(1, array_count):
                new_obj = obj.copy()
                new_obj.data = obj.data.copy()
                if direction == 'X':
                    new_obj.location.x += array_spacing * i
                elif direction == 'Y':
                    new_obj.location.y += array_spacing * i
                elif direction == 'Z':
                    new_obj.location.z += array_spacing * i
                context.collection.objects.link(new_obj)
                added_count += 1

                if preserve_groups and original_group_id:
                    new_obj["RLX_Group_ID"] = original_group_id
                else:
                    if "RLX_Group_ID" in new_obj:
                        del new_obj["RLX_Group_ID"]

        self.report({'INFO'}, f"Array created with {added_count} new objects.")
        return {'FINISHED'}

class RLX_OT_JoinObjects(Operator):
    bl_idname = "object.rlx_join_objects"
    bl_label = "Join Objects"
    bl_description = "Join selected objects into the active object"

    def execute(self, context):
        preserve_groups = False
        if not preserve_groups:
            if len(context.selected_objects) > 1:
                bpy.ops.object.join()
                self.report({'INFO'}, "Objects joined successfully.")
            else:
                self.report({'WARNING'}, "Please select multiple objects to join.")
        return {'FINISHED'}

class RLX_OT_SeparateObjects(Operator):
    bl_idname = "object.rlx_separate_objects"
    bl_label = "Separate Objects"
    bl_description = "Separate joined objects back into individual objects"

    def execute(self, context):
        selected_objects = context.selected_objects.copy()
        for obj in selected_objects:
            if obj.type == 'MESH':
                context.view_layer.objects.active = obj
                array_mods = [mod for mod in obj.modifiers if mod.type == 'ARRAY']
                for mod in array_mods:
                    bpy.ops.object.modifier_apply(modifier=mod.name)

                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.separate(type='LOOSE')
                bpy.ops.object.mode_set(mode='OBJECT')

                for new_obj in bpy.context.selected_objects:
                    if "RLX_Original_Object_Name" in new_obj:
                        original_name = new_obj["RLX_Original_Object_Name"]
                        new_obj.name = original_name
                        if "RLX_Group_ID" in new_obj:
                            new_obj["RLX_Group_ID"] = new_obj.get("RLX_Group_ID", "")
        self.report({'INFO'}, "Objects separated successfully.")
        return {'FINISHED'}

class RLX_OT_JoinObjectsPerBody(Operator):
    bl_idname = "object.rlx_join_objects_per_body"
    bl_label = "Join Objects Per Body"
    bl_description = "Join objects in each body collection into a single object"

    def execute(self, context):
        body_collections = [coll for coll in bpy.data.collections if coll.name.startswith("Body ")]
        for coll in body_collections:
            objects_to_join = [obj for obj in coll.objects if obj.type == 'MESH']
            if len(objects_to_join) > 1:
                bpy.ops.object.select_all(action='DESELECT')
                for obj in objects_to_join:
                    obj.select_set(True)
                context.view_layer.objects.active = objects_to_join[0]
                bpy.ops.object.join()
        self.report({'INFO'}, "Objects in each body collection have been joined.")
        return {'FINISHED'}

class RLX_OT_ApplyFittingModifiers(Operator):
    bl_idname = "object.rlx_apply_fitting_modifiers"
    bl_label = "Add Fitting Modifiers"
    bl_description = "Add fitting modifiers to the selected objects"

    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        target_items = [item for item in context.scene.rlx_target_objects if item.object in selected_objects]

        if not target_items:
            self.report({'WARNING'}, "No selected objects are in the fitting list.")
            return {'CANCELLED'}

        applied_count = 0
        skipped_items = []

        for item in target_items:
            obj = item.object
            if obj:
                if item.target_bodies:
                    for mod in obj.modifiers[:]:
                        if mod.name.startswith("RLX"):
                            obj.modifiers.remove(mod)

                    self.apply_classic_fit(context, obj, item)
                    applied_count += 1
                else:
                    skipped_items.append(obj.name)

                # v1.6.0 additions
                preserve_details_with_vertex_groups(obj, context)
                add_displacement_modifier(obj, context)
                improve_normals(obj, context)
            else:
                skipped_items.append("<Unknown object>")

        if applied_count > 0:
            self.report({'INFO'}, f"Fitting modifiers applied to {applied_count} objects.")
        if skipped_items:
            self.report({'WARNING'}, f"Skipped objects with no target bodies assigned: {', '.join(skipped_items)}")
        return {'FINISHED'}

    def apply_classic_fit(self, context, obj, target_item):
        if not target_item.original_mesh:
            target_item.original_mesh = obj.data.copy()

        for i, target_body in enumerate(target_item.target_bodies):
            if target_body.body:
                vg_name = f"RLX_Target_{i}"
                vg = obj.vertex_groups.new(name=vg_name)
                vg.add(range(len(obj.data.vertices)), target_body.weight, 'REPLACE')

                shrinkwrap_mod = obj.modifiers.new(name=f"RLX Shrinkwrap {target_body.body.name}", type='SHRINKWRAP')
                shrinkwrap_mod.target = target_body.body
                shrinkwrap_mod.wrap_method = 'NEAREST_SURFACEPOINT'
                shrinkwrap_mod.wrap_mode = 'OUTSIDE'
                shrinkwrap_mod.offset = context.scene.rlx_shrinkwrap_offset
                shrinkwrap_mod.vertex_group = vg_name
                shrinkwrap_mod.show_on_cage = True

        if context.scene.rlx_use_corrective_smooth:
            corrective_smooth_mod = obj.modifiers.new(name="RLX Corrective Smooth", type='CORRECTIVE_SMOOTH')
            corrective_smooth_mod.iterations = context.scene.rlx_shrinkwrap_smooth_iterations
            corrective_smooth_mod.use_only_smooth = context.scene.rlx_corrective_smooth_only_smooth
            corrective_smooth_mod.smooth_type = context.scene.rlx_corrective_smooth_type
            corrective_smooth_mod.show_viewport = True

class RLX_OT_PerformDataTransfer(Operator):
    bl_idname = "object.rlx_perform_data_transfer"
    bl_label = "Perform Data Transfer"
    bl_description = "Transfer normals from the original mesh to the fitted mesh"

    def execute(self, context):
        bpy.ops.object.rlx_apply_modifiers_to_selected()
        for item in context.scene.rlx_target_objects:
            obj = item.object
            if obj and obj.type == 'MESH':
                if item.original_mesh:
                    temp_mesh = item.original_mesh.copy()
                    temp_obj = bpy.data.objects.new(f"{obj.name}_original", temp_mesh)
                    context.collection.objects.link(temp_obj)
                    temp_obj.hide_viewport = True
                    temp_obj.hide_render = True

                    temp_obj.data.materials.clear()

                    data_transfer_mod = obj.modifiers.new(name="RLX Data Transfer", type='DATA_TRANSFER')
                    data_transfer_mod.object = temp_obj
                    data_transfer_mod.use_vert_data = False
                    data_transfer_mod.use_edge_data = False
                    data_transfer_mod.use_loop_data = True
                    data_transfer_mod.data_types_loops = {'CUSTOM_NORMAL'}
                    data_transfer_mod.use_poly_data = False
                    data_transfer_mod.use_max_distance = False
                    data_transfer_mod.loop_mapping = 'NEAREST_POLYNOR'
                    data_transfer_mod.mix_mode = 'REPLACE'
                    data_transfer_mod.mix_factor = 1.0

                    context.view_layer.objects.active = obj
                    if obj.mode != 'OBJECT':
                        bpy.ops.object.mode_set(mode='OBJECT')
                    data_transfer_mod.show_viewport = True
                    try:
                        bpy.ops.object.modifier_apply(modifier=data_transfer_mod.name)
                    except RuntimeError as e:
                        self.report({'WARNING'}, f"Could not apply Data Transfer on {obj.name}: {e}")

                    bpy.data.objects.remove(temp_obj, do_unlink=True)
                    bpy.data.meshes.remove(temp_mesh)
                else:
                    self.report({'WARNING'}, f"Original mesh data not found for object {obj.name}")
            else:
                self.report({'WARNING'}, f"Object {obj.name} is not a mesh or not found.")
        self.report({'INFO'}, "Data Transfer completed.")
        return {'FINISHED'}

class RLX_OT_ApplyModifiersToSelected(Operator):
    bl_idname = "object.rlx_apply_modifiers_to_selected"
    bl_label = "Apply All Modifiers"
    bl_description = "Apply all modifiers to the selected outfits"

    def execute(self, context):
        selected_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        target_items = [item for item in context.scene.rlx_target_objects if item.object in selected_objects]

        for item in target_items:
            obj = item.object
            if obj:
                context.view_layer.objects.active = obj
                if obj.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
                for mod in obj.modifiers[:]:
                    mod.show_viewport = True
                    try:
                        bpy.ops.object.modifier_apply(modifier=mod.name)
                    except RuntimeError as e:
                        self.report({'WARNING'}, f"Could not apply modifier {mod.name} on {obj.name}: {e}")
                if item.original_mesh:
                    bpy.data.meshes.remove(item.original_mesh)
                    item.original_mesh = None
        self.report({'INFO'}, "All modifiers applied to selected outfits.")
        return {'FINISHED'}

class RLX_OT_SelectAssignedClothing(Operator):
    bl_idname = "rlx.select_assigned_clothing"
    bl_label = "Select Assigned Outfits"

    def execute(self, context):
        for obj_in_view in context.view_layer.objects:
            obj_in_view.select_set(False)

        for item in context.scene.rlx_target_objects:
            if item.object and any(target.body for target in item.target_bodies):
                if item.object.name not in context.view_layer.objects:
                    context.collection.objects.link(item.object)
                item.object.select_set(True)
                context.view_layer.objects.active = item.object
        return {'FINISHED'}

class RLX_OT_SavePreset(Operator):
    bl_idname = "rlx.save_preset"
    bl_label = "Save Preset"

    def execute(self, context):
        preset_data = {
            "shrinkwrap_offset": context.scene.rlx_shrinkwrap_offset,
            "shrinkwrap_smooth_iterations": context.scene.rlx_shrinkwrap_smooth_iterations,
            "corrective_smooth_only_smooth": context.scene.rlx_corrective_smooth_only_smooth,
            "corrective_smooth_type": context.scene.rlx_corrective_smooth_type,
            "use_corrective_smooth": context.scene.rlx_use_corrective_smooth,
            "array_count": context.scene.rlx_array_count,
            "array_spacing": context.scene.rlx_array_spacing,
            "array_direction": context.scene.rlx_array_direction,
            "preserve_groups_in_array": context.scene.rlx_preserve_groups_in_array,
            "enable_collection_array": context.scene.rlx_enable_collection_array,
            "array_collection_name": context.scene.rlx_array_collection.name if context.scene.rlx_array_collection else "",
            "enable_collection_fitting": context.scene.rlx_enable_collection_fitting,
            "preserve_fine_details": context.scene.rlx_preserve_fine_details,
            "enable_displacement": context.scene.rlx_enable_displacement,
            "displacement_strength": context.scene.rlx_displacement_strength,
            "improve_normals": context.scene.rlx_improve_normals,
            "enable_strap_mesh": context.scene.rlx_enable_strap_mesh,
            "strap_target_name": context.scene.rlx_strap_target.name if context.scene.rlx_strap_target else "",
            "strap_offset": context.scene.rlx_strap_offset,
        }
        RLXPresetManager.save_preset(context.scene.rlx_preset_name, preset_data)
        self.report({'INFO'}, f"Preset '{context.scene.rlx_preset_name}' saved successfully.")
        return {'FINISHED'}

class RLX_OT_LoadPreset(Operator):
    bl_idname = "rlx.load_preset"
    bl_label = "Load Preset"

    def execute(self, context):
        preset_data = RLXPresetManager.load_preset(context.scene.rlx_preset_list)

        context.scene.rlx_shrinkwrap_offset = preset_data.get("shrinkwrap_offset", 0.005)
        context.scene.rlx_shrinkwrap_smooth_iterations = preset_data.get("shrinkwrap_smooth_iterations", 10)
        context.scene.rlx_corrective_smooth_only_smooth = preset_data.get("corrective_smooth_only_smooth", False)
        context.scene.rlx_corrective_smooth_type = preset_data.get("corrective_smooth_type", 'SIMPLE')
        context.scene.rlx_use_corrective_smooth = preset_data.get("use_corrective_smooth", True)
        context.scene.rlx_array_count = preset_data.get("array_count", 2)
        context.scene.rlx_array_spacing = preset_data.get("array_spacing", 1.0)
        context.scene.rlx_array_direction = preset_data.get("array_direction", 'X')
        context.scene.rlx_preserve_groups_in_array = preset_data.get("preserve_groups_in_array", False)

        context.scene.rlx_enable_collection_array = preset_data.get("enable_collection_array", False)
        col_name = preset_data.get("array_collection_name", "")
        context.scene.rlx_array_collection = bpy.data.collections.get(col_name) if col_name in bpy.data.collections else None
        context.scene.rlx_enable_collection_fitting = preset_data.get("enable_collection_fitting", False)

        context.scene.rlx_preserve_fine_details = preset_data.get("preserve_fine_details", False)
        context.scene.rlx_enable_displacement = preset_data.get("enable_displacement", False)
        context.scene.rlx_displacement_strength = preset_data.get("displacement_strength", 0.1)
        context.scene.rlx_improve_normals = preset_data.get("improve_normals", False)
        context.scene.rlx_enable_strap_mesh = preset_data.get("enable_strap_mesh", False)
        strap_target_name = preset_data.get("strap_target_name", "")
        context.scene.rlx_strap_target = bpy.data.objects.get(strap_target_name) if strap_target_name in bpy.data.objects else None
        context.scene.rlx_strap_offset = preset_data.get("strap_offset", 0.0)

        self.report({'INFO'}, f"Preset '{context.scene.rlx_preset_list}' loaded successfully.")
        return {'FINISHED'}

class RLX_OT_AddCollectionToFitting(Operator):
    bl_idname = "rlx.add_collection_to_fitting"
    bl_label = "Add Collection to Fitting"
    bl_description = "Add all mesh objects in the specified collection to the fitting list"

    def execute(self, context):
        scene = context.scene
        if not scene.rlx_enable_collection_fitting or not scene.rlx_array_collection:
            self.report({'WARNING'}, "Collection Fitting is not enabled or no collection is specified.")
            return {'CANCELLED'}

        collection = scene.rlx_array_collection
        added_count = 0
        for obj in collection.objects:
            if obj.type == 'MESH':
                if not any(item.object == obj for item in scene.rlx_target_objects):
                    item = scene.rlx_target_objects.add()
                    item.object = obj
                    item.original_object_name = obj.name
                    item.original_mesh = obj.data.copy()
                    item.group_id = obj.get("RLX_Group_ID", "")
                    added_count += 1
        self.report({'INFO'}, f"Added {added_count} objects from collection '{collection.name}' to the list.")
        return {'FINISHED'}

class RLX_OT_ApplyStrapFitting(Operator):
    bl_idname = "rlx.apply_strap_fitting"
    bl_label = "Apply Strap Fitting"
    bl_description = "Shrinkwrap selected accessory objects onto the chosen clothing mesh"

    def execute(self, context):
        scene = context.scene
        if not scene.rlx_enable_strap_mesh:
            self.report({'WARNING'}, "Strap Mesh Fitting is disabled.")
            return {'CANCELLED'}

        strap_objs = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not strap_objs:
            self.report({'WARNING'}, "No mesh objects selected for strap fitting.")
            return {'CANCELLED'}

        for obj in strap_objs:
            apply_strap_shrinkwrap(obj, context)

        self.report({'INFO'}, f"Strap fitting applied to {len(strap_objs)} objects.")
        return {'FINISHED'}

class RLX_OT_CustomSeparateByVertexGroups(Operator):
    bl_idname = "rlx.custom_separate_by_vertex_groups"
    bl_label = "Separate by Vertex Groups"
    bl_description = "Separate mesh into different objects based on vertex groups"

    def execute(self, context):
        obj = context.active_object
        if not obj or obj.type != 'MESH':
            self.report({'ERROR'}, "No active mesh object found.")
            return {'CANCELLED'}

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='DESELECT')

        vertex_groups = obj.vertex_groups
        if not vertex_groups:
            self.report({'ERROR'}, "No vertex groups found on the active object.")
            bpy.ops.object.mode_set(mode='OBJECT')
            return {'CANCELLED'}

        for vg in vertex_groups:
            bpy.ops.object.vertex_group_set_active(group=vg.name)
            bpy.ops.object.vertex_group_select()
            bpy.ops.mesh.separate(type='SELECTED')

        bpy.ops.object.mode_set(mode='OBJECT')
        self.report({'INFO'}, "Mesh separated by vertex groups.")
        return {'FINISHED'}

# -----------------------------
# Registration
# -----------------------------
classes = (
    RLXTargetBody,
    RLXTargetItem,
    RLX_UL_object_list,
    RLX_PT_MainPanel,
    RLX_PT_PresetPanel,
    RLX_OT_SetOriginToGeometry,
    RLX_OT_AddObjectToList,
    RLX_OT_RemoveObjectFromList,
    RLX_OT_ClearObjectList,
    RLX_OT_EditTargetBodies,
    RLX_OT_AddTargetBody,
    RLX_OT_RemoveTargetBody,
    RLX_OT_SelectObjectInViewport,
    RLX_OT_CreateArray,
    RLX_OT_JoinObjects,
    RLX_OT_SeparateObjects,
    RLX_OT_JoinObjectsPerBody,
    RLX_OT_ApplyFittingModifiers,
    RLX_OT_PerformDataTransfer,
    RLX_OT_ApplyModifiersToSelected,
    RLX_OT_SelectAssignedClothing,
    RLX_OT_SavePreset,
    RLX_OT_LoadPreset,
    RLX_OT_CustomSeparateByVertexGroups,
    RLX_OT_AddCollectionToFitting,
    RLX_OT_ApplyStrapFitting,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.rlx_target_objects = CollectionProperty(type=RLXTargetItem)
    bpy.types.Scene.rlx_target_objects_index = IntProperty()

    bpy.types.Scene.rlx_shrinkwrap_offset = FloatProperty(
        name="Shrinkwrap Offset",
        default=0.005,
        min=0.0,
        max=1.0,
        update=update_modifier_settings
    )
    bpy.types.Scene.rlx_shrinkwrap_smooth_iterations = IntProperty(
        name="Smooth Iterations",
        default=10,
        min=0,
        max=50,
        update=update_modifier_settings
    )
    bpy.types.Scene.rlx_corrective_smooth_only_smooth = BoolProperty(
        name="Only Smooth",
        default=False,
        description="When enabled, only smoothing is applied without correcting volume",
        update=update_modifier_settings
    )
    bpy.types.Scene.rlx_corrective_smooth_type = EnumProperty(
        name="Smooth Type",
        items=[
            ('SIMPLE', "Simple", ""),
            ('LENGTH_WEIGHTED', "Length Weighted", ""),
            ('ANGULAR', "Angular", ""),
            ('RELATIVE_EDGE', "Relative Edge", ""),
            ('SHARP_EDGE', "Sharp Edge", ""),
        ],
        default='SIMPLE',
        update=update_modifier_settings
    )
    bpy.types.Scene.rlx_use_corrective_smooth = BoolProperty(
        name="Enable Corrective Smooth",
        default=True,
        description="Toggle the Corrective Smooth modifier",
        update=update_modifier_settings
    )

    bpy.types.Scene.rlx_array_count = IntProperty(
        name="Array Count",
        default=2,
        min=1,
        max=100,
        update=update_array_count
    )
    bpy.types.Scene.rlx_array_spacing = FloatProperty(
        name="Array Spacing",
        default=1.0,
        min=0.0,
        max=10.0,
        update=update_array_spacing
    )
    bpy.types.Scene.rlx_array_direction = EnumProperty(
        name="Array Direction",
        items=[
            ('X', "X Axis", ""),
            ('Y', "Y Axis", ""),
            ('Z', "Z Axis", ""),
        ],
        default='X',
        update=update_array_direction
    )
    bpy.types.Scene.rlx_preserve_groups_in_array = BoolProperty(
        name="Preserve Groups",
        default=False,
        description="Preserve group assignments when creating arrays"
    )

    bpy.types.Scene.rlx_preset_name = StringProperty(name="Preset Name")
    bpy.types.Scene.rlx_preset_list = EnumProperty(
        items=RLXPresetManager.get_preset_list,
        name="Preset List"
    )

    bpy.types.Scene.rlx_ui_show_operations = BoolProperty(
        name="Show Operations",
        default=False
    )
    bpy.types.Scene.rlx_ui_show_fitting = BoolProperty(
        name="Show Fitting Settings",
        default=True
    )
    bpy.types.Scene.rlx_ui_show_selection_tools = BoolProperty(
        name="Show Selection Tools",
        default=False
    )

    # v1.5.9
    bpy.types.Scene.rlx_enable_collection_array = BoolProperty(
        name="Use Collection for Array",
        default=False,
        description="If enabled, arrays will be created from all meshes in the chosen collection"
    )
    bpy.types.Scene.rlx_array_collection = PointerProperty(
        name="Array Collection",
        type=bpy.types.Collection,
        description="Select the collection to array from (if enabled)"
    )
    bpy.types.Scene.rlx_enable_collection_fitting = BoolProperty(
        name="Collection Fitting",
        default=False,
        description="If enabled, you can add all objects from a collection to the fitting list"
    )

    # v1.6.0
    bpy.types.Scene.rlx_ui_show_advanced_fitting = BoolProperty(
        name="Show Advanced Fitting Options",
        default=False
    )
    bpy.types.Scene.rlx_preserve_fine_details = BoolProperty(
        name="Preserve Fine Details",
        default=False,
        description="Avoid over-smoothing or shrinkwrapping small mesh parts (buckles, pockets, etc.)"
    )
    bpy.types.Scene.rlx_enable_displacement = BoolProperty(
        name="Enable Displacement",
        default=False,
        description="Add a Displacement modifier for extra surface detail"
    )
    bpy.types.Scene.rlx_displacement_strength = FloatProperty(
        name="Displacement Strength",
        default=0.1,
        min=0.0,
        max=10.0,
        description="Controls intensity of the displacement"
    )
    bpy.types.Scene.rlx_improve_normals = BoolProperty(
        name="Improve Normals",
        default=False,
        description="Use Weighted Normals or Normal Edit to ensure final mesh shading is consistent"
    )
    bpy.types.Scene.rlx_enable_strap_mesh = BoolProperty(
        name="Enable Strap Mesh Fitting",
        default=False,
        description="Allows shrinkwrapping accessory meshes onto a clothing mesh"
    )
    bpy.types.Scene.rlx_strap_target = PointerProperty(
        name="Clothing Target",
        type=bpy.types.Object,
        description="Clothing mesh to wrap the strap or accessory onto"
    )
    bpy.types.Scene.rlx_strap_offset = FloatProperty(
        name="Strap Offset",
        default=0.0,
        min=0.0,
        max=1.0,
        description="Push strap away from clothing surface by this amount"
    )

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    del bpy.types.Scene.rlx_target_objects
    del bpy.types.Scene.rlx_target_objects_index
    del bpy.types.Scene.rlx_shrinkwrap_offset
    del bpy.types.Scene.rlx_shrinkwrap_smooth_iterations
    del bpy.types.Scene.rlx_corrective_smooth_only_smooth
    del bpy.types.Scene.rlx_corrective_smooth_type
    del bpy.types.Scene.rlx_use_corrective_smooth
    del bpy.types.Scene.rlx_array_count
    del bpy.types.Scene.rlx_array_spacing
    del bpy.types.Scene.rlx_array_direction
    del bpy.types.Scene.rlx_preserve_groups_in_array
    del bpy.types.Scene.rlx_preset_name
    del bpy.types.Scene.rlx_preset_list
    del bpy.types.Scene.rlx_ui_show_operations
    del bpy.types.Scene.rlx_ui_show_fitting
    del bpy.types.Scene.rlx_ui_show_selection_tools

    # v1.5.9
    del bpy.types.Scene.rlx_enable_collection_array
    del bpy.types.Scene.rlx_array_collection
    del bpy.types.Scene.rlx_enable_collection_fitting

    # v1.6.0
    del bpy.types.Scene.rlx_ui_show_advanced_fitting
    del bpy.types.Scene.rlx_preserve_fine_details
    del bpy.types.Scene.rlx_enable_displacement
    del bpy.types.Scene.rlx_displacement_strength
    del bpy.types.Scene.rlx_improve_normals
    del bpy.types.Scene.rlx_enable_strap_mesh
    del bpy.types.Scene.rlx_strap_target
    del bpy.types.Scene.rlx_strap_offset

if __name__ == "__main__":
    register()