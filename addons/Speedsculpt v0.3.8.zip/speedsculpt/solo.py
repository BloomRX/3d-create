# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
from bpy.types import Operator
from .functions import get_addon_preferences



class SPEEDSCULPT_OT_solo(Operator):
    bl_idname = "object.speedsculpt_solo"
    bl_label = "SOLO"
    bl_options = {"REGISTER"}
    bl_description = "\nMake non selected objects transparent.\n\n\nSHORTCUTS\n\n\nCLICK - Solo the selection\n\nSHIFT CLICK - Add Selection to Transparency\n\nCTRL CLICK - Remove Selection from Transparency\n\nALT CLICK - Invert Solo\n\nCTRL SHIFT CLICK - Exit"

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        prefs = get_addon_preferences()

        self.solo_color = prefs.sc_solo_color

        self.act_obj = context.object
        self.sel = [obj for obj in context.selected_objects]
        self.solo_object = [obj for obj in context.scene.objects if obj.get("is_solo")]
        self.solo_transparent_object = []

        self.has_solo = []
        self.dont_have_solo = []
        shading = context.space_data.shading


        for obj in context.visible_objects:
            if obj.display_type == 'BOUNDS':
                continue
            obj.display_type = 'TEXTURED'

        if len([obj for obj in context.selected_objects]) == 0:
            for obj in context.scene.objects:
                if obj.get("is_solo"):
                    del obj["is_solo"]
                if obj.type == 'EMPTY':
                    continue
                obj.color = (1, 1, 1, 1)

            shading.color_type = context.scene["solo_shading"]
            del context.scene["solo_shading"]
            context.space_data.shading.type = context.scene["solo_shading_type"]
            del context.scene["solo_shading_type"]

        else:
            if event.ctrl and event.shift:
                for obj in context.scene.objects:
                    if obj.get("is_solo"):
                        del obj["is_solo"]
                    if obj.type == 'EMPTY':
                        continue
                    obj.color = (1, 1, 1, 1)

                if context.scene.get("solo_shading"):
                    shading.color_type = context.scene["solo_shading"]
                    del context.scene["solo_shading"]
                if context.scene.get("solo_shading_type"):
                    shading.type = context.scene["solo_shading_type"]
                    del context.scene["solo_shading_type"]

            # ADD SELECTION
            elif event.shift:

                for obj in self.sel:
                    if not self.solo_object:
                        # Store shading type
                        context.scene["solo_shading"] = shading.color_type
                        context.scene["solo_shading_type"] = shading.type
                        shading.color_type = 'OBJECT'
                        shading.type = 'SOLID'

                        obj.color = prefs.sc_solo_color

                        for obj in context.visible_objects:
                            if obj.type == 'EMPTY':
                                continue
                            if not obj in self.sel:
                                obj["is_solo"] = True
                                obj.color = (1, 1, 1, 1)

                    else:
                        if obj.type == 'EMPTY':
                            continue
                        obj["is_solo"] = True
                        obj.color = (1, 1, 1, 1)


            # REMOVE SELECTION
            elif event.ctrl:
                for obj in self.sel:
                    if obj.type == 'EMPTY':
                        continue
                    if obj.get("is_solo"):
                        del obj["is_solo"]
                        obj.color = prefs.sc_solo_color

                    else:
                        self.act_obj["is_solo"] = True
                        obj.color = (1, 1, 1, 1)

            # Invert SOLO
            elif event.alt:
                if self.solo_object:
                    for obj in context.scene.objects:
                        if obj.type == 'EMPTY':
                            continue

                        if obj.get("is_solo"):
                            self.has_solo.append(obj)
                        elif not obj.get("is_solo"):
                            self.dont_have_solo.append(obj)

                    for obj in self.has_solo:
                        del obj["is_solo"]
                        obj.color = prefs.sc_solo_color

                    for obj in self.dont_have_solo:
                        obj["is_solo"] = True
                        obj.color = (1, 1, 1, 1)

            else:

                for obj in self.solo_object:
                    if obj.get("is_solo"):
                        del obj["is_solo"]

                        if context.scene.get("solo_shading"):
                            shading.color_type = context.scene["solo_shading"]
                            del context.scene["solo_shading"]
                        if context.scene.get("solo_shading_type"):
                            shading.type = context.scene["solo_shading_type"]
                            del context.scene["solo_shading_type"]

                for obj in context.visible_objects:
                    if obj.type == 'EMPTY':
                        continue
                    obj.color = prefs.sc_solo_color

                    # Store shading type
                    context.scene["solo_shading"] = shading.color_type
                    context.scene["solo_shading_type"] = context.space_data.shading.type

                for obj in self.sel:
                    if obj.type == 'EMPTY':
                        continue
                    obj.color = (1, 1, 1, 1)
                    obj["is_solo"] = True

                if shading.color_type == 'RANDOM':
                    shading.color_type = 'RANDOM'
                else:
                    shading.color_type = 'OBJECT'
                shading.type = 'SOLID'

        del (self.sel[:])
        del (self.has_solo[:])
        del (self.dont_have_solo[:])

        return {"FINISHED"}


CLASSES =  [SPEEDSCULPT_OT_solo
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass