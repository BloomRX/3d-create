# -*- coding:utf-8 -*-

# SPEEDSCULPT Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
import os
import bmesh
import sys
from .functions import *
from math import radians
from .icon.icons import load_icons
from bpy.types import Operator, Macro
from bpy.props import (StringProperty,
                       BoolProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty)
from types import SimpleNamespace
from mathutils import Matrix, Vector

##------------------------------------------------------
#
# Save Tmp
#
##------------------------------------------------------
def save_tmp():
    """ Save the current blend in the blender tmp file """
    tmp = os.path.join(bpy.app.tempdir, "speedsculpt_backup.blend")
    bpy.ops.wm.save_as_mainfile(copy=True, filepath=tmp, check_existing=False)

class SPEEDSCULPT_OT_cutter_primitives(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_cutter_primitives'
    bl_label = "CUTTER PRIMITIVES"
    bl_description = "Cut the Mesh or create a new one with Primitives"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    launch_cutter_primitives: EnumProperty(
        items=(('rectangle', " ", "Cut or create with a Rectangle", "MESH_PLANE", 0),
               ('vertex', " ", "Cut or create with a Shape", "HANDLE_VECTOR", 1),
               ('curve', " ", "Cut or create with a Curve", "MOD_CURVE", 2),
               ('sphere', " ", "Cut or create with a Sphere", "MESH_UVSPHERE", 3),
               ('cylinder', " ", "Cut or create with a Cylinder", "MESH_CYLINDER", 4),
               ('cube', " ", "Cut or create with a Cube", "MESH_CUBE", 5),
               ('circle', " ", "Cut or create with a Circle", "MESH_CIRCLE", 6)),
        default='rectangle') # type: ignore

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        if self.launch_cutter_primitives == 'rectangle':
            speedsculpt.cutter_primitives = 'rectangle'
        elif self.launch_cutter_primitives == 'vertex':
            speedsculpt.cutter_primitives = 'vertex'
        elif self.launch_cutter_primitives == 'curve':
            speedsculpt.cutter_primitives = 'curve'
        elif self.launch_cutter_primitives == 'sphere':
            speedsculpt.cutter_primitives = 'sphere'
        elif self.launch_cutter_primitives == 'cylinder':
            speedsculpt.cutter_primitives = 'cylinder'
        elif self.launch_cutter_primitives == 'cube':
            speedsculpt.cutter_primitives = 'cube'
        elif self.launch_cutter_primitives == 'circle':
            speedsculpt.cutter_primitives = 'circle'

        bpy.ops.object.speedsculpt_cutter('INVOKE_DEFAULT')

        return {'FINISHED'}

class SPEEDSCULPT_OT_add_assets_to_scene(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_add_assets_to_scene'
    bl_label = "ADD ASSETS"
    bl_description = "Add Assets from the Library to the scene"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()
        
        if speedsculpt.create_primitives == 'insert':
            bpy.ops.object.speedsculpt_add_assets_insert()
            return {'FINISHED'}

        if context.object is None:
            speedsculpt.primitives_parenting = False

        actObj = context.active_object

        if context.object is not None:
            bpy.ops.object.mode_set(mode='OBJECT')

        if context.object is None and not speedsculpt.ref_obj:
            speedsculpt.add_mirror = False

        # Nouvelle condition pour le mode INSERT
        # if speedsculpt.create_primitives == 'insert':
        #     # Récupérer le type de primitive sélectionné
        #     # Vous devrez adapter cette partie selon comment vous stockez le type de primitive
        #     primitive_type = "sphere"  # Valeur par défaut, à adapter selon vos besoins
        #     bpy.ops.object.speedsculpt_insert_primitive_modal('INVOKE_DEFAULT', primitive_type=primitive_type)
        #     return {'FINISHED'}

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT')
        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_cursor_to_selected()

        bpy.ops.object.speedsculpt_assets_add()
        new_obj = context.active_object
        
        # Récupérer tous les objets nouvellement ajoutés (sélectionnés)
        imported_objects = [obj for obj in context.selected_objects]

        # Pour origin/cursor/mouse, identifier et sélectionner uniquement le parent AVANT positionnement
        if speedsculpt.create_primitives in ['origin', 'cursor', 'mouse']:
            # Trouver l'objet parent principal (sans parent dans la hiérarchie)
            root_parent = None
            for obj in imported_objects:
                if obj.parent is None:
                    root_parent = obj
                    break
            
            if root_parent:
                # Désélectionner tous les objets
                bpy.ops.object.select_all(action='DESELECT')
                # Sélectionner uniquement l'objet parent principal
                root_parent.select_set(True)
                context.view_layer.objects.active = root_parent
                new_obj = root_parent  # Mettre à jour la référence

        

        if speedsculpt.create_primitives == 'cursor':
            if speedsculpt.copy_cursor_orientation:
                new_obj.rotation_euler = context.scene.cursor.rotation_euler.copy()
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        elif speedsculpt.create_primitives == 'selection':
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        elif speedsculpt.create_primitives == 'origin':
            context.scene.cursor.location[:] = (0, 0, 0)
            context.scene.cursor.rotation_euler[:] = (0, 0, 0)
            new_obj.location[:] = (0, 0, 0)

        if speedsculpt.add_mirror:
            if context.object is None:
                self.report({'INFO'}, "Select Mirror Object First", icon='ERROR')
            else:
                # Appliquer le mirror à tous les objets importés
                for obj in imported_objects:
                    if obj.type == 'MESH':  # Seulement sur les mesh
                        mod_mirror = obj.modifiers.new("Mirror", 'MIRROR')
                        mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
                        for prop, axis_index in mirror_axes.items():
                            if getattr(speedsculpt, prop):
                                mod_mirror.use_axis[axis_index] = True
                        if speedsculpt.ref_obj:
                            mod_mirror.mirror_object = speedsculpt.ref_obj
                        elif actObj:
                            mod_mirror.mirror_object = actObj

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                actObj.select_set(state=True)
                context.view_layer.objects.active = actObj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                actObj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj

        if speedsculpt.create_primitives == 'mouse':
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            bpy.ops.transform.translate('INVOKE_DEFAULT')

        return {'FINISHED'}

class SPEEDSCULPT_OT_add_assets_insert(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_add_assets_insert'
    bl_label = "ADD ASSETS INSERT"
    bl_description = "Add Assets from the Library to the scene with insert modal"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        # Lancer le modal en mode asset
        bpy.ops.object.speedsculpt_insert_primitive_modal('INVOKE_DEFAULT', primitive_type="asset")
        return {'FINISHED'}
    
def snap_faces(self, context):
    bpy.context.scene.tool_settings.use_snap = not bpy.context.scene.tool_settings.use_snap
    if bpy.app.version < (4, 2, 0):
        context.scene.tool_settings.snap_elements = {'FACE'}
    else:
        context.scene.tool_settings.snap_elements = {'FACE'}
    context.scene.tool_settings.use_snap_align_rotation = True
    bpy.context.scene.tool_settings.snap_target = 'MEDIAN'

def has_mirror_modifier(obj):
    # Check if the object exists and has modifiers
    if obj and obj.modifiers:
        # Check if any modifier is of type 'MIRROR'
        return any(mod.type == 'MIRROR' for mod in obj.modifiers)

    return False

def process_selected_objects(context):
    selected_objects = list(context.selected_objects)
    speedsculpt = context.scene.speedsculpt
    speedsculpt.curve_mirror_target = None

    current_mode = context.object.mode

    if current_mode != 'OBJECT':
        bpy.ops.object.mode_set(mode='OBJECT')

    for obj in selected_objects:
        if obj.data.users > 1:
            bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)

        if obj.get("speedsculpt_muscles"):
            del obj["speedsculpt_muscles"]

        if obj.type == 'ARMATURE':
            bpy.ops.object.convert_armature()

        if obj.type == 'CURVE' and obj.get("Speedsculpt_curve"):
            bpy.ops.object.mode_set(mode='OBJECT')
            for mod in obj.modifiers:
                if mod.type == "MIRROR":
                    print(mod.name)
                    speedsculpt.curve_mirror_target = mod.mirror_object

                    print(speedsculpt.curve_mirror_target)
                    print(mod.mirror_object)
                    bpy.ops.object.modifier_remove(modifier=mod.name)
                    bpy.ops.object.convert(target='MESH')

        elif obj.type == 'CURVE' or obj.type in {'FONT', 'META'}:
            if obj.mode!= 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.convert(target='MESH')
    
    #Restore Mode
    bpy.ops.object.mode_set(mode=current_mode, toggle=False)

def toggle_dynamic_topology_sculpt(context):
    for obj in context.selected_objects:
        # Switch to sculpt mode
        context.view_layer.objects.active = obj
        bpy.ops.object.mode_set(mode='SCULPT')

        # Toggle dynamic topology sculpting
        if obj.use_dynamic_topology_sculpting:
            bpy.ops.sculpt.dynamic_topology_toggle()

        # Switch back to object mode
        bpy.ops.object.mode_set(mode='OBJECT')

def contains_extracted_suffix():
    # Parcourir tous les objets sélectionnés
    for obj in bpy.context.selected_objects:
        if "_EXTRACTED" in obj.name:
            return True  # Trouvé un objet avec le suffixe "_EXTRACTED"

    return False  # Aucun objet avec le suffixe "_EXTRACTED" trouvé

def check_smooth_shading(obj):
    """
    Checks if the given Blender object uses smooth shading.

    Parameters:
    obj (bpy.types.Object): The Blender object to check.

    Returns:
    bool: True if the object uses smooth shading, False otherwise.
    """
    # Check if the object has a mesh data
    if obj and obj.type == 'MESH':
        return any(poly.use_smooth for poly in obj.data.polygons)
    return False

class SPEEDSCULPT_OT_remesh_selection(bpy.types.Operator):
    bl_idname = "object.speedsculpt_remesh_selection"
    bl_label = "REMESH SELECTION"
    bl_description = "\nRemesh the selection with the Remesh value and other settings as reference.\n\nDepending on the Value you are using, the complutation can take time."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        obj = context.active_object
        if obj and obj.library is None and obj.data and obj.data.users > 1:
            return context.window_manager.invoke_props_dialog(self)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        layout.label(text="This object's is not single user. Proceed with remesh?")

    def adjust_modifiers_values(self, obj, scale):
        """Adjust modifier values after applying scale"""
        max_scale = max(scale[0], scale[1], scale[2])
        avg_scale = (scale[0] + scale[1] + scale[2]) / 3

        for mod in obj.modifiers:
            if mod.type == 'SOLIDIFY':
                # Adjust thickness
                mod.thickness *= avg_scale
            elif mod.type == 'BEVEL':
                # Adjust based on offset_type
                if mod.offset_type in {'OFFSET', 'WIDTH', 'DEPTH', 'ABSOLUTE'}:
                    mod.width *= max_scale

    def execute(self, context):
        bpy.ops.ed.undo_push()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt

        selection = [obj for obj in bpy.context.selected_objects]
        for obj in selection:
            if obj.type == 'EMPTY':
                self.report({'ERROR'},"One or more Object is an Empty, Remesh Cancelled")
                return {'CANCELLED'}
                

        # Store original scale before applying
        original_scale = context.active_object.scale.copy()

        # AUTO SAVE
        if prefs.auto_save and sys.platform.startswith('win'):
            save_tmp()
            self.report({'INFO'},"Backup Scene Saved")

        act_obj = context.active_object
        mode = act_obj.mode

        act_obj_has_mirror = has_mirror_modifier(act_obj)

        if act_obj.modifiers:
            self.adjust_modifiers_values(act_obj, original_scale)

        # ----- CONVERT ARMATURE AND FONT
        process_selected_objects(context)

        #         print("TEST")

        act_obj = context.active_object
        context.view_layer.objects.active = act_obj
        act_obj.select_set(state = True)

        # --------- DISABLE DYNTOPO
        if context.object.type == 'MESH':
            toggle_dynamic_topology_sculpt(context)

        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        if obj.get("Speedsculpt_curve"):
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.speedsculpt_add_mirror()

        # APPLY MODIFIERS EXCEPT THE MIRROR
        if len(context.selected_objects)==1:
            for mod in act_obj.modifiers:
                if prefs.apply_mirror:
                    bpy.ops.object.convert(target='MESH')
                else:
                    if mod.type != 'MIRROR':
                        bpy.ops.object.modifier_apply(modifier=mod.name)

        if speedsculpt.cutter_create_boolean == 'create' and not act_obj_has_mirror:
                bpy.ops.object.convert(target='MESH')
        
        

        # BOOLEAN OPERATIONS
        if len(context.selected_objects)>=2:

            for obj in context.selected_objects:
                if obj == act_obj:
                    continue

                context.view_layer.objects.active = obj

                # remove mirror modifier if act_obj has a mirror
                if has_mirror_modifier(obj) and act_obj_has_mirror :
                    for mod in obj.modifiers:
                        bpy.ops.object.modifier_remove(modifier=mod.name)
                else:
                    for mod in obj.modifiers:
                        bpy.ops.object.modifier_apply(modifier=mod.name)

            context.view_layer.objects.active = act_obj

            if speedsculpt.boolean_operation == 'union':
                if not contains_extracted_suffix() and prefs.update_remesh:
                    bpy.ops.object.join()
                else:
                    bpy.ops.object.boolean_sculpt_union_difference()

            elif speedsculpt.boolean_operation == 'difference':
                bpy.ops.object.boolean_sculpt_union_difference()

            elif speedsculpt.boolean_operation == 'rebool':
                bpy.ops.object.boolean_sculpt_rebool()

        if prefs.fill_holes:
            fill_holes()

        # REMESH
        if prefs.update_remesh:
            for obj in context.selected_objects:
                bpy.ops.object.mode_set(mode='SCULPT')
                obj.data.remesh_voxel_size = prefs.remesh_mesh_value
                obj.data.remesh_voxel_adaptivity = prefs.remesh_mesh_voxel_adaptivity
                obj.data.use_remesh_fix_poles = prefs.remesh_mesh_fix_poles
                obj.data.use_remesh_preserve_volume = prefs.remesh_mesh_use_remesh_preserve_volume
                if bpy.app.version < (4, 1, 0):
                    obj.data.use_remesh_preserve_paint_mask = prefs.remesh_mesh_preserve_paint_mask
                    obj.data.use_remesh_preserve_sculpt_face_sets = prefs.remesh_mesh_preserve_sculpt_face_sets
                if bpy.app.version >= (4, 1, 0):
                    obj.data.use_remesh_preserve_attributes = prefs.remesh_mesh_preserve_attributes

            if contains_extracted_suffix():
                context.view_layer.objects.active = obj
            bpy.ops.object.voxel_remesh()

            if prefs.smooth_mesh:
                CheckSmoothMesh()

        if not contains_extracted_suffix():
            bpy.ops.object.mode_set(mode=mode)
        else:
            bpy.ops.object.mode_set(mode='OBJECT')

        # Select the first object
        if contains_extracted_suffix():
            selected_objects = [obj for obj in context.selected_objects]
            first_object = selected_objects[0]
            bpy.ops.object.select_all(action='DESELECT')

            context.view_layer.objects.active = first_object
            first_object.select_set(True)

        bpy.ops.object.mode_set(mode='OBJECT')
        if bpy.app.version < (4, 1, 0):
            context.object.data.use_auto_smooth = False
        if prefs.remesh_mesh_smooth_normals:
            bpy.ops.object.shade_smooth()
        else:
            bpy.ops.object.shade_flat()
        bpy.ops.object.mode_set(mode=mode)

        # REMOVE BSURFACE MATERIAL
        if bpy.data.materials.get('BSurfaceMesh'):
            bpy.data.materials.remove(bpy.data.materials['BSurfaceMesh'], do_unlink=True)

        return {'FINISHED'}

# ADD DYNTOPO
def CheckDyntopo():
    prefs = get_addon_preferences()
    sculpt = bpy.context.tool_settings.sculpt

    # Store current Mode
    mode = bpy.context.object.mode

    bpy.ops.view3d.snap_cursor_to_selected()
    saved_cursor_location = bpy.context.scene.cursor.location.copy()

    # Store initial detail and refine methods
    initial_detail_type_method = sculpt.detail_type_method
    initial_detail_refine_method = bpy.context.scene.tool_settings.sculpt.detail_refine_method

    if prefs.update_detail_flood_fill:
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.mode_set(mode='SCULPT')

        # Toggle Dyntopo if not active
        if not bpy.context.sculpt_object.use_dynamic_topology_sculpting:
            bpy.ops.sculpt.dynamic_topology_toggle()

        sculpt.detail_refine_method = 'SUBDIVIDE_COLLAPSE'
        sculpt.detail_type_method = 'CONSTANT'
        
        # bpy.context.scene.tool_settings.sculpt.constant_detail_resolution = 12

        bpy.ops.sculpt.detail_flood_fill()
        bpy.ops.sculpt.optimize()
    else:
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.mode_set(mode='SCULPT')

    # Restore initial settings
    sculpt.detail_type_method = initial_detail_type_method
    sculpt.detail_refine_method = initial_detail_refine_method

    # Apply shading based on version and preference
    bpy.ops.object.mode_set(mode='OBJECT')

    if prefs.remesh_mesh_smooth_normals:
        bpy.ops.object.shade_smooth()
    else:
        bpy.ops.object.shade_flat()

    # Restore Mode
    bpy.ops.object.mode_set(mode=mode)

    # Restore cursor and origin
    bpy.context.scene.cursor.location = saved_cursor_location
    bpy.ops.object.origin_set(type='ORIGIN_CURSOR')

# ADD AND APPLY SMOOTH MODIFIER
def CheckSmoothMesh():
    prefs = get_addon_preferences()
    if prefs.smooth_mesh:
        obj = bpy.context.object
        bpy.ops.object.mode_set(mode='OBJECT')
        mod_smooth = obj.modifiers.new("Smooth", 'SMOOTH')
        mod_smooth.factor = 1
        mod_smooth.iterations = prefs.smooth_mesh_value
        bpy.ops.object.modifier_apply(modifier=mod_smooth.name)

class SPEEDSCULPT_OT_smooth_mesh_only(bpy.types.Operator):
    bl_idname = "object.speedsculpt_smooth_mesh_only"
    bl_label = "DIRECT SMOOTH"
    bl_options = {"REGISTER", "UNDO"}
    bl_description = "\nDirect Smooth of the Mesh.\n\nIt will only add a Smooth to the Selection, no REMESH/DYNTOPO Update)"

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        prefs = get_addon_preferences()

        if context.object.mode == 'SCULPT':
            dynotop_mode = context.sculpt_object.use_dynamic_topology_sculpting
            if dynotop_mode:
                bpy.ops.sculpt.dynamic_topology_toggle()

        act_obj = context.active_object

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            obj.select_set(state=True)
            mod_smooth = obj.modifiers.new("Smooth", 'SMOOTH')
            mod_smooth.factor = 1
            mod_smooth.iterations = prefs.smooth_mesh_value
            bpy.ops.object.modifier_apply(modifier=mod_smooth.name)

        context.view_layer.objects.active = act_obj
        act_obj.select_set(state=True)

        if context.object.mode == 'SCULPT':
            if dynotop_mode:
                bpy.ops.sculpt.dynamic_topology_toggle()


        return {'FINISHED'}

selection = list()

def clean_and_convert(obj):
    if obj.modifiers:
        for mod in obj.modifiers:
            if mod.type == 'MIRROR':
                if not "Mirror_Skin" in obj.modifiers:
                    mod.use_mirror_merge = False
                    mod.use_clip = False

        bpy.ops.object.convert(target='MESH')

def separate_objects():
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.separate(type='LOOSE')
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.view_layer.objects.active = bpy.context.selected_objects[0]

def fill_holes():
    obj = bpy.context.object

    # Fill Holes
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='EDGE')
    bm = bmesh.from_edit_mesh(obj.data)
    sel_edges = [e for e in bm.edges if e.select]
    bpy.ops.mesh.select_non_manifold(extend=False, use_wire=False, use_boundary=True, use_multi_face=False,
                                     use_non_contiguous=False, use_verts=False)
    if len(sel_edges) > 0:
        for e in bm.edges:
            if e not in sel_edges: e.select = False
    bpy.ops.mesh.edge_face_add()
    bpy.ops.mesh.quads_convert_to_tris(quad_method='BEAUTY', ngon_method='BEAUTY')

    bpy.ops.mesh.select_more()
    bpy.ops.mesh.select_more()

    # mask from faces
    bpy.ops.mesh.hide(unselected=False)
    bpy.ops.object.mode_set(mode='SCULPT')
    bpy.ops.paint.mask_flood_fill(mode='VALUE', value=1)
    if bpy.app.version < (4, 2, 0):
        bpy.ops.paint.hide_show(action='SHOW', area='ALL')
    else:
        bpy.ops.paint.hide_show(action='SHOW')
    bpy.ops.paint.mask_flood_fill(mode='VALUE', value=0)

#------------------------------------------------------
# Update Dyntopo
#------------------------------------------------------
class SPEEDSCULPT_OT_update_dyntopo(bpy.types.Operator):
    bl_idname = "object.update_dyntopo"
    bl_label = "REMESH SELECTION - DYNTOPO"
    bl_description = "\nRemesh the selection with the Remesh value and other settings as reference.\n\nDepending on the Value you are using, the complutation can take time."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.ed.undo_push()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        act_obj = context.active_object
        add_remesh = prefs.add_remesh
        self.sculpt = False

        selection = [obj for obj in bpy.context.selected_objects]
        for obj in selection:
            if obj.type == 'EMPTY':
                self.report({'ERROR'},"One or more Object is an Empty, Remesh Cancelled")
                return {'CANCELLED'}

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()
                self.report({'INFO'},"Backup Scene Saved")

        context.preferences.edit.use_global_undo = True

        # ----- CONVERT ARMATURE AND FONT
        process_selected_objects(context)

        # APPLY MODIFIERS EXCEPT THE MIRROR
        for mod in act_obj.modifiers:
            if prefs.apply_mirror:
                bpy.ops.object.convert(target='MESH')
            else:
                if mod.type != 'MIRROR':
                    bpy.ops.object.modifier_apply(modifier=mod.name)

        if len(context.selected_objects) >= 2:
            if not contains_extracted_suffix():
                if speedsculpt.boolean_operation in {'union', 'difference'}:
                    bpy.ops.object.boolean_sculpt_union_difference()
                elif speedsculpt.boolean_operation == 'rebool':
                    bpy.ops.object.boolean_sculpt_rebool()

        # Convert Metaballs / Font / Curve
        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            obj.select_set(state = True)

            if obj.type == 'MESH':
                if obj.data.uv_layers:
                    bpy.ops.mesh.uv_texture_remove()

            if obj.data.users > 1:
                bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)

            if obj.type in { 'CURVE', 'FONT'}:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.convert(target='MESH')
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.remove_doubles()
                bpy.ops.object.mode_set(mode='OBJECT')

            if obj.type == 'META':
                bpy.ops.object.convert(target='MESH')

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            obj.select_set(state=True)

            if obj.get("speedsculpt_muscles"):
                del obj["speedsculpt_muscles"]

            # SCULPT
            if obj.mode == "SCULPT":
                self.sculpt = True
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.transform_apply(location=True, rotation=False, scale=True)
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
                bpy.ops.object.mode_set(mode='SCULPT')

            # OBJECT
            else:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
                bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

                if obj.modifiers:
                    if not "Mirror" in obj.modifiers:
                        clean_and_convert(obj)
                        separate_objects()
                        bpy.ops.object.boolean_sculpt_union_difference()

            # ACTIONS AFTER CONVERTION
            if prefs.fill_holes:
                fill_holes()
                bpy.ops.object.mode_set(mode='OBJECT')

            if add_remesh:
                bpy.ops.object.simple_remesh()
                clean_and_convert(obj)
                separate_objects()

            bpy.ops.object.mode_set(mode='OBJECT')

            CheckDyntopo()
            if not prefs.modal_smooth:
                CheckSmoothMesh()

        if self.sculpt:
            bpy.ops.object.mode_set(mode='SCULPT')

        context.scene.tool_settings.use_snap = False

        return {"FINISHED"}

def apply_modifiers(context):
    has_mirror = any(mod.type == 'MIRROR' for obj in context.selected_objects for mod in obj.modifiers)

    for obj in context.selected_objects:
        if has_mirror:
            for mod in obj.modifiers:
                bpy.ops.object.modifier_apply(modifier=mod.name)
        else:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.convert(target='MESH')

#------------------------------------------------------
# UNION / Difference
#------------------------------------------------------
class SPEEDSCULPT_OT_boolean_sculpt_union_difference(bpy.types.Operator):
    bl_idname = "object.boolean_sculpt_union_difference"
    bl_label = "Boolean Union Difference"
    bl_description = "Combine objects"
    bl_options = {"REGISTER", "UNDO"}

    def unlink_object_from_scene(self, context, o):
        for coll in o.users_collection:
            coll.objects.unlink(o)

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        # AUTO SAVE
        if prefs.auto_save and sys.platform.startswith('win'):
            save_tmp()

        # Check and Activate the Undo
        if not context.preferences.edit.use_global_undo:
            context.preferences.edit.use_global_undo = True

        self.operation_type = 'UNION' if speedsculpt.boolean_operation == 'union' else 'DIFFERENCE'

        # Making objects single-user
        for obj in context.selected_objects:
            if obj.data.users > 1:
                obj.make_single_user(object=True, obdata=True, material=False, animation=False)

        # Separate objects
        if speedsculpt.boolean_operation == 'union' and prefs.dyntopo_or_remesh == 'dyntopo':
            for obj in context.selected_objects:
                clean_and_convert(obj)
                separate_objects()

        # Union
        actObj = context.active_object
        for selObj in context.selected_objects:
            if selObj != actObj and selObj.type == "MESH":
                act_obj = context.active_object
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                # bpy.ops.object.transform_apply({"object": act_obj,
                #                                 "active_object": act_obj,
                #                                 "selected_editable_objects": [act_obj]},
                #                                location=False,
                #                                rotation=False,
                #                                scale=True)

                newMod = act_obj.modifiers.new("Boolean" + selObj.name, "BOOLEAN")
                newMod.operation = self.operation_type
                newMod.object = selObj
                apply_modifiers(context)

                bpy.ops.ed.undo_push()
                
                bpy.ops.object.select_all(action='DESELECT')
                selObj.select_set(state=True)
                bpy.ops.object.delete()
                act_obj.select_set(state=True)

        return {"FINISHED"}

# Boolean Rebool
class SPEEDSCULPT_OT_boolean_sculpt_rebool(bpy.types.Operator):
    bl_idname = "object.boolean_sculpt_rebool"
    bl_label = "Boolean Rebool"
    bl_description = "Slice the active object from your selection"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        prefs = get_addon_preferences()
        add_remesh = prefs.add_remesh

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()

        # Check and Activate the Undo
        if not context.preferences.edit.use_global_undo:
            context.preferences.edit.use_global_undo = True

        for obj in context.selected_objects:
            if obj.data.users > 1:
                bpy.ops.object.make_single_user(object=True, obdata=True, material=False, animation=False)


        final_list = []
        act_obj = context.active_object
        obj_bool_list = [obj for obj in context.selected_objects if obj != act_obj and obj.type == 'MESH']
        bpy.ops.object.select_all(action='DESELECT')

        final_list.append(act_obj)
        for obj in obj_bool_list:
            act_obj.select_set(state=True)

            boolean_mod = act_obj.modifiers.new("Boolean", 'BOOLEAN')
            boolean_mod.object = obj
            boolean_mod.operation = 'DIFFERENCE'

            bpy.ops.object.duplicate_move()
            tempobj = context.active_object
            final_list.append(tempobj)

            tempobj.modifiers["Boolean"].operation = 'INTERSECT'
            bpy.ops.object.modifier_apply(modifier='Boolean')
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')

            act_obj.select_set(state=True)
            context.view_layer.objects.active = act_obj
            bpy.ops.object.modifier_apply(modifier='Boolean')

            bpy.ops.ed.undo_push()
            act_obj.select_set(state=False)
            tempobj.select_set(state=False)
            obj.select_set(state=True)
            bpy.ops.object.delete(use_global=False)
            act_obj.select_set(state=True)

        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')
        bpy.ops.object.select_all(action='DESELECT')

        for obj in final_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            if add_remesh:
                bpy.ops.object.remesh()
                clean_and_convert(obj)
                separate_objects()
            if prefs.dyntopo_or_remesh == "dyntopo":
                if prefs.update_detail_flood_fill:
                    CheckDyntopo()
            else:
                if prefs.update_remesh:
                    bpy.ops.object.speedsculpt_remesh_selection()

            CheckSmoothMesh()
            obj.select_set(state=False)

        context.view_layer.objects.active = act_obj
        act_obj.select_set(state=True)

        if prefs.dyntopo_or_remesh == "dyntopo":
            if add_remesh:
                bpy.ops.object.remesh()
                clean_and_convert(act_obj)
                separate_objects()

        return {"FINISHED"}

_pick_remesh_state = None

def _speedsculpt_pick_remesh_timer():
    global _pick_remesh_state
    s = _pick_remesh_state
    if s is None:
        return None
    obj = bpy.data.objects.get(s.get("obj_name", ""), None)
    if obj is None or obj.type != "MESH":
        _pick_remesh_state = None
        return None

    def restore_mode_if_needed():
        mode_restore = s.get("mode_restore")
        if mode_restore and mode_restore != "SCULPT" and obj.mode == "SCULPT":
            bpy.context.view_layer.objects.active = obj
            bpy.ops.object.mode_set(mode=mode_restore)

    baseline = s["baseline"]
    if abs(obj.data.remesh_voxel_size - baseline) > 1e-9:
        prefs = get_addon_preferences()
        prefs.remesh_mesh_value = obj.data.remesh_voxel_size
        restore_mode_if_needed()
        _pick_remesh_state = None
        return None

    s["ticks"] = s.get("ticks", 0) + 1
    if s["ticks"] >= 240:
        restore_mode_if_needed()
        _pick_remesh_state = None
        return None
    return 0.05


class SPEEDSCULPT_OT_pick_remesh_size(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_pick_remesh_size'
    bl_label = "REMESH SIZE"
    bl_options = {'REGISTER'}
    bl_description = "\nPick the Remesh Value on an Object to use it when Remeshing your Mesh"

    @classmethod
    def poll(cls, context):
        obj = context.object
        if obj is None or obj.type != 'MESH' or not obj.visible_get(view_layer=context.view_layer):
            return False
        return all(abs(axis - obj.scale[0]) < 1e-5 for axis in obj.scale)

    @classmethod
    def description(cls, context, properties):
        scale_ok = (context.object is not None and all(abs(axis - 1.0) < 1e-5 for axis in context.object.scale))

        if scale_ok:
            return "Pick the Remesh Value on an Object to use it when Remeshing your Mesh\n\nIt works only for the active object"
        else:
            return "Object scale non uniform, please apply the scale to the object to 1 on all axes"

    def invoke(self, context, event):
        obj = context.object
        if obj is None or obj.type != 'MESH':
            return {'CANCELLED'}

        current_mode = obj.mode
        if current_mode != 'SCULPT':
            bpy.ops.object.mode_set(mode='SCULPT')

        if context.region is None:
            if current_mode != 'SCULPT':
                bpy.ops.object.mode_set(mode=current_mode)
            self.report({'WARNING'}, "Use from the 3D Viewport")
            return {'CANCELLED'}

        global _pick_remesh_state
        try:
            bpy.app.timers.unregister(_speedsculpt_pick_remesh_timer)
        except Exception:
            pass
        _pick_remesh_state = {
            "baseline": float(obj.data.remesh_voxel_size),
            "obj_name": obj.name,
            "mode_restore": current_mode,
            "ticks": 0,
        }
        bpy.ops.sculpt.sample_detail_size('INVOKE_DEFAULT', mode='VOXEL')
        bpy.app.timers.register(_speedsculpt_pick_remesh_timer, first_interval=0.05)
        return {'FINISHED'}

    def execute(self, context):
        if context.region is None:
            self.report({'WARNING'}, "Use from the 3D Viewport")
            return {'CANCELLED'}
        ev = SimpleNamespace(
            mouse_region_x=context.region.width // 2,
            mouse_region_y=context.region.height // 2,
        )
        return self.invoke(context, ev)

# SCALE
class SPEEDSCULPT_OT_scale_finalize(Operator):
    bl_idname = "speedsculpt.scale_finalize"
    bl_label = "scale Finalize"

    def execute(self, context):
        bpy.ops.transform.resize('INVOKE_DEFAULT', orient_type='LOCAL', orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)),
                                 orient_matrix_type='LOCAL', constraint_axis=(False, False, True),
                                 mirror=True, use_proportional_edit=False,
                                 proportional_edit_falloff='SMOOTH',
                                 proportional_size=1,
                                 use_proportional_connected=False,
                                 use_proportional_projected=False)

        return {'FINISHED'}

# BSURFACE
# End : Snap 3D Cursor and delete empty
class SPEEDSCULPT_OT_bsurface_finalize(Operator):
    bl_idname = "speedsculpt.bsurface_finalize"
    bl_label = "Bsurface Finalize"

    def execute(self, context):
        bpy.ops.wm.tool_set_by_id(name="builtin.select")
        if bpy.data.materials.get('BSurfaceMesh'):
            bpy.data.materials.remove(bpy.data.materials['BSurfaceMesh'], do_unlink=True)
        return {'FINISHED'}

class SPEEDSCULPT_OT_bsurface_start(Operator):
    bl_idname = "speedsculpt.bsurface_start"
    bl_label = "Bsurface Start"

    def execute(self, context):
        bpy.ops.mesh.surfsk_add_surface('INVOKE_DEFAULT')
        return {'FINISHED'}

class SPEEDSCULPT_OT_add_bsurface(Macro):
    bl_idname = "speedsculpt.add_bsurface"
    bl_label = "Speedsculpt Add Bsurface"

# VOXEL -----------------------------------------------------
class SPEEDSCULPT_OT_edit_voxel_size(bpy.types.Operator):
    bl_idname = "object.speedsculpt_edit_voxel_size"
    bl_label = "speedsculpt edit voxel size"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        prefs = get_addon_preferences()

        if context.object.mode == 'EDIT' :
            return {'FINISHED'}

        sculpt_mode = False
        if context.object.mode == 'SCULPT':
            sculpt_mode = True

        if tuple(context.object.scale) != (1, 1, 1):
            if sculpt_mode:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                bpy.ops.object.mode_set(mode='SCULPT')

        if context.object.type != 'MESH':
            bpy.ops.object.convert(target='MESH')
        
        if prefs.dyntopo_or_remesh == "remesh":
            bpy.ops.object.speedsculpt_voxel_size_edit('INVOKE_DEFAULT')

        elif prefs.dyntopo_or_remesh == "dyntopo":
            # Nettoyer d'abord en mode Object si nécessaire
            if context.object.mode != 'SCULPT':
                # Supprimer les UV maps en mode Object
                if context.object.data.uv_layers:
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.mesh.uv_texture_remove()
                    bpy.ops.object.mode_set(mode='OBJECT')
            
            bpy.ops.object.mode_set(mode='SCULPT')
            
            if not context.sculpt_object.use_dynamic_topology_sculpting:
                bpy.ops.sculpt.dynamic_topology_toggle()
            
            
            bpy.ops.object.mode_set(mode='SCULPT')
            
            # Forcer la mise à jour du contexte
            bpy.context.view_layer.update()
            
            # Lancer l'opérateur
            if context.sculpt_object and context.sculpt_object.use_dynamic_topology_sculpting:
                bpy.ops.object.speedsculpt_dyntopo_detail_size_edit('INVOKE_DEFAULT')

        return {'FINISHED'}
    
class SPEEDSCULPT_OT_voxel_size_edit(Macro):
    bl_idname = "object.speedsculpt_voxel_size_edit"
    bl_label = "Speedsculpt Voxel Size Edit"

class SPEEDSCULPT_OT_dyntopo_detail_size_edit(Macro):
    bl_idname = "object.speedsculpt_dyntopo_detail_size_edit"
    bl_label = "Speedsculpt Dyntopo Detail Size Edit"

class SPEEDSCULPT_OT_voxel_size_finalize(Operator):
    bl_idname = "object.speedsculpt_finalize"
    bl_label = "Voxel Size Finalize"

    def execute(self, context):
        context.area.tag_redraw()
        prefs = get_addon_preferences()
        sculpt_mode = False
        if context.object.mode == 'SCULPT':
            sculpt_mode = True

        if prefs.dyntopo_or_remesh == "remesh":
            prefs.remesh_mesh_value = context.object.data.remesh_voxel_size
            bpy.ops.object.speedsculpt_remesh_selection()

            bpy.ops.object.voxel_remesh()

            prefs.remesh_mesh_value = context.object.data.remesh_voxel_size

        elif prefs.dyntopo_or_remesh == "dyntopo":

            # bpy.ops.object.update_dyntopo()
            bpy.ops.sculpt.detail_flood_fill()

        if prefs.modal_smooth:
            if sculpt_mode:
                bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.speedsculpt_smooth_modal('INVOKE_DEFAULT')
        else:
            if prefs.smooth_mesh:
                CheckSmoothMesh()

        if sculpt_mode:
            bpy.ops.object.mode_set(mode='SCULPT')

        if prefs.dyntopo_or_remesh == "remesh":
            self.report({'INFO'}, "UPDATED REMESH")
        elif prefs.dyntopo_or_remesh == "dyntopo":
            self.report({'INFO'}, "UPDATED DYNTOPO")

        return {'FINISHED'}
    
class SPEEDSCULPT_OT_remesh_shortcut(Operator):
    bl_idname = "object.speedsculpt_remesh_shortcut"
    bl_label = "Remesh"

    def execute(self, context):

        prefs = get_addon_preferences()
        dyntopo_or_remesh = prefs.dyntopo_or_remesh

        if context.object.mode == 'EDIT':
            return {'FINISHED'}

        if context.object.type=='MESH':
            if context.object.mode == 'SCULPT':
                prefs.sculpt_mode = True
            else:
                prefs.sculpt_mode = False

            if dyntopo_or_remesh == "dyntopo":
                self.report({'INFO'}, "UPDATED DYNTOPO")
                bpy.ops.object.update_dyntopo()
            elif dyntopo_or_remesh == "remesh":
                self.report({'INFO'}, "UPDATED REMESH")
                bpy.ops.object.speedsculpt_remesh_selection()

            # if prefs.modal_smooth:
            if prefs.add_smooth_remesh_modal:
                bpy.ops.object.speedsculpt_smooth_modal('INVOKE_DEFAULT')


        return {'FINISHED'}
    
class SPEEDSCULPT_OT_increment_remesh_and_execute(bpy.types.Operator):
    bl_idname = "object.speedsculpt_increment_remesh_and_execute"
    bl_label = "INCREMENT DETAIL"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def description(cls, context, properties):
        prefs = get_addon_preferences()
        if prefs.dyntopo_or_remesh == "remesh":
            return "Increase or decrease remesh value by 10%\n\nSHIFT+CLICK: 20%\nCTRL+CLICK: 5%\n\nNote: Don't forget to sample the Dyntopo Detail Size"
        else:
            return "Increase or decrease dyntopo detail by 10%\n\nSHIFT+CLICK: 20%\nCTRL+CLICK: 5%\n\nNote: Don't forget to sample the Remesh Detail Size"

    direction: EnumProperty(
        items=[
            ('UP', "Up", "Increase value by 10%"),
            ('DOWN', "Down", "Decrease value by 10%")
        ],
        default='UP',
        name="Direction"
    ) # type: ignore

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        # Get addon preferences
        prefs = get_addon_preferences()
        sculpt = context.scene.tool_settings.sculpt
        
        if prefs.dyntopo_or_remesh == "remesh":

            if event.shift:
                percentage = 0.2  # 20% with Shift
            elif event.ctrl:
                percentage = 0.05  # 5% with Ctrl
            else:
                percentage = 0.1  # 10% with no modifier

            # Calculate multiplier based on direction
            if self.direction == 'UP':
                
                # UP = more detail = smaller value
                prefs.remesh_mesh_value *= (1.0 - percentage)  # -10%
                action = "decreased (more detail)"
            else:  # DOWN
                # DOWN = less detail = bigger value  
                prefs.remesh_mesh_value *= (1.0 + percentage)  # +10%
                action = "increased (less detail)"
            
            # Execute remesh selection
            bpy.ops.object.speedsculpt_remesh_selection()
            
            self.report({'INFO'}, f"Remesh value {action} to {prefs.remesh_mesh_value:.3f} and remesh executed")
            
        elif prefs.dyntopo_or_remesh == "dyntopo":

            if event.shift:
                percentage = 0.2  # 20% with Shift
            elif event.ctrl:
                percentage = 0.05  # 5% with Ctrl
            else:
                percentage = 0.1  # 10% with no modifier

            # Calculate multiplier based on direction
            if self.direction == 'UP':
                multiplier = (1.0 + percentage)  # +10%
                action = "increased"
            else:  # DOWN
                multiplier = (1.0 - percentage)  # -10%
                action = "decreased"
                
            # Check which detail method is being used and apply multiplier accordingly
            if sculpt.detail_type_method == 'RELATIVE':
                # Apply multiplier to detail_size
                sculpt.detail_size *= multiplier
                detail_value = sculpt.detail_size
                detail_type = "detail size"
                
            elif sculpt.detail_type_method in {'CONSTANT', 'MANUAL'}:
                # Apply multiplier to constant_detail_resolution
                sculpt.constant_detail_resolution *= multiplier
                detail_value = sculpt.constant_detail_resolution
                detail_type = "constant detail resolution"
                
            elif sculpt.detail_type_method == 'BRUSH':
                # Apply multiplier to detail_percent
                sculpt.detail_percent *= multiplier
                detail_value = sculpt.detail_percent
                detail_type = "detail percent"
            
            # If we're in sculpt mode and dyntopo is active, update it
            if context.object and context.object.mode == 'SCULPT':
                if context.sculpt_object and context.sculpt_object.use_dynamic_topology_sculpting:
                    # Update dyntopo with new detail settings
                    bpy.ops.sculpt.detail_flood_fill()
                else:
                    # Enable dyntopo if not active
                    bpy.ops.sculpt.dynamic_topology_toggle()
                    bpy.ops.sculpt.detail_flood_fill()
            else:
                # Switch to sculpt mode first
                bpy.ops.object.mode_set(mode='SCULPT')
                if not context.sculpt_object.use_dynamic_topology_sculpting:
                    bpy.ops.sculpt.dynamic_topology_toggle()
                bpy.ops.sculpt.detail_flood_fill()
            
            self.report({'INFO'}, f"Dyntopo {detail_type} {action} to {detail_value:.3f} and updated")
        
        return {"FINISHED"}

class SPEEDSCULPT_OT_increment_remesh_and_execute_shortcut(Operator):
    bl_idname = "object.speedsculpt_increment_remesh_and_execute_shortcut"
    bl_label = "INCREMENT REMESH AND EXECUTE"
    bl_description = "Increase or decrease remesh value or dyntopo detail by 10% and execute"
    bl_options = {"REGISTER", "UNDO"}

    direction: EnumProperty(
        items=[
            ('UP', "Up", "Increase value by 10%"),
            ('DOWN', "Down", "Decrease value by 10%")
        ],
        default='UP',
        name="Direction"
    ) # type: ignore

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        # Get addon preferences
        prefs = get_addon_preferences()
        sculpt = context.scene.tool_settings.sculpt
        
        if prefs.dyntopo_or_remesh == "remesh":

            # Calculate multiplier based on direction
            if self.direction == 'UP':
                # UP = more detail = smaller value
                prefs.remesh_mesh_value = 0.9  # -10%
                action = "decreased (more detail)"
            else:  # DOWN
                # DOWN = less detail = bigger value  
                prefs.remesh_mesh_value = 1.1  # +10%
                action = "increased (less detail)"
            
            # Execute remesh selection
            bpy.ops.object.speedsculpt_remesh_selection()
            
            self.report({'INFO'}, f"Remesh value {action} to {prefs.remesh_mesh_value:.3f} and remesh executed")
            
        elif prefs.dyntopo_or_remesh == "dyntopo":

            # Calculate multiplier based on direction
            if self.direction == 'UP':
                multiplier *= 1.1  # +10%
                action = "increased"
            else:  # DOWN
                multiplier *= 0.9  # -10%
                action = "decreased"
                
            # Check which detail method is being used and apply multiplier accordingly
            if sculpt.detail_type_method == 'RELATIVE':
                # Apply multiplier to detail_size
                sculpt.detail_size *= multiplier
                detail_value = sculpt.detail_size
                detail_type = "detail size"
                
            elif sculpt.detail_type_method in {'CONSTANT', 'MANUAL'}:
                # Apply multiplier to constant_detail_resolution
                sculpt.constant_detail_resolution *= multiplier
                detail_value = sculpt.constant_detail_resolution
                detail_type = "constant detail resolution"
                
            elif sculpt.detail_type_method == 'BRUSH':
                # Apply multiplier to detail_percent
                sculpt.detail_percent *= multiplier
                detail_value = sculpt.detail_percent
                detail_type = "detail percent"
            
            # If we're in sculpt mode and dyntopo is active, update it
            if context.object and context.object.mode == 'SCULPT':
                if context.sculpt_object and context.sculpt_object.use_dynamic_topology_sculpting:
                    # Update dyntopo with new detail settings
                    bpy.ops.sculpt.detail_flood_fill()
                else:
                    # Enable dyntopo if not active
                    bpy.ops.sculpt.dynamic_topology_toggle()
                    bpy.ops.sculpt.detail_flood_fill()
            else:
                # Switch to sculpt mode first
                bpy.ops.object.mode_set(mode='SCULPT')
                if not context.sculpt_object.use_dynamic_topology_sculpting:
                    bpy.ops.sculpt.dynamic_topology_toggle()
                bpy.ops.sculpt.detail_flood_fill()
            
            self.report({'INFO'}, f"Dyntopo {detail_type} {action} to {detail_value:.3f} and updated")
        
        return {"FINISHED"}

class SPEEDSCULPT_OT_scale_macro(Macro):
    bl_idname = "speedsculpt.scale_macro"
    bl_label = "Speedsculpt scale Macro"

class SPEEDSCULPT_OT_set_bsurface_info(Operator):
    bl_idname = 'object.speedsculpt_set_bsurface_info'
    bl_label = "Set Bsurface Info"
    bl_description = "Install or Activate Bsurface to use it with Speedsculpt"
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        return {'FINISHED'}

class SPEEDSCULPT_OT_set_looptools_info(Operator):
    bl_idname = 'object.speedsculpt_set_looptools_info'
    bl_label = "Set Looptools Info"
    bl_description = "Install or Activate Looptools to use it with Speedsculpt"
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        return {'FINISHED'}

class SPEEDSCULPT_OT_append_geomesh(Operator):
    bl_idname = "object.speedsculpt_append_geomesh"
    bl_label = "Create a Geomesh from the selected collection"

    geomesh_name: StringProperty(
        name="Geomesh Name",
        description="Name of the Geomesh object",
        default=""
    ) # type: ignore
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        speedsculpt = context.scene.speedsculpt
        
        layout.prop(speedsculpt, "collection_selection", text="Collection")
        
        # Check if name already exists
        name_exists = False
        test_name = self.geomesh_name
        if bpy.data.objects.get(test_name):
            name_exists = True
            
        row = layout.row()
        row.prop(self, "geomesh_name", text="Name")
        if name_exists:
            row = layout.row()
            row.label(text="Name already exists!", icon='ERROR')
    
    def execute(self, context):
        speedsculpt = context.scene.speedsculpt

        # Sauvegarde de l'état initial
        initial_active = context.active_object
        initial_selection = context.selected_objects.copy() if context.selected_objects else []
        initial_mode = None
        
        # Vérification améliorée avec visibilité
        if initial_active:
            # Vérifier si l'objet actif est visible
            is_visible = initial_active.visible_get(view_layer=context.view_layer)
            
            if is_visible and initial_selection:
                initial_mode = initial_active.mode
                
                # Passer en mode objet seulement si nécessaire
                if initial_mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
                
                # Désélectionner tous les objets
                bpy.ops.object.select_all(action='DESELECT')
            elif not is_visible:
                self.report({'WARNING'}, f"The Active Object '{initial_active.name}' is not visible")
                return {'CANCELLED'}
                    
        # APPEND -----------------------------------------
        # Get the directory of the current script file
        current_dir = os.path.dirname(os.path.realpath(__file__))
        # Define the base path
        base_path = os.path.join(current_dir, 'library')
        # Get the file path
        file_path = os.path.join(base_path, "geomesh.blend")
        
        # Vérifier que le fichier existe
        if not os.path.exists(file_path):
            self.report({'ERROR'}, f"No geomesh.blend found: {file_path}")
            return {'CANCELLED'}
        
        # Append the selected primitive
        try:
            with bpy.data.libraries.load(file_path) as (data_from, data_to):
                data_to.objects = [name for name in data_from.objects if name in data_from.objects]
        except Exception as e:
            self.report({'ERROR'}, f"Error on the append: {str(e)}")
            return {'CANCELLED'}

        # APPEND -----------------------------------------

        bpy.ops.object.select_all(action='DESELECT')

        # COLLECTION --------------------------------------
        # Get the master collection (scene collection)
        master_collection = context.scene.collection

        # Move object to master collection
        for obj in data_to.objects:
            # Unlink from current collections
            for collection in obj.users_collection:
                collection.objects.unlink(obj)
            
            # Link to master collection
            master_collection.objects.link(obj)
            context.view_layer.objects.active = obj
        # COLLECTION --------------------------------------

        act_obj = context.active_object
        
        if not act_obj:
            self.report({'ERROR'}, "No Object created")
            return {'CANCELLED'}

        act_obj.select_set(state=True)
        context.view_layer.objects.active = act_obj
        
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        # Configuration du modifier
        modifier = act_obj.modifiers.get("GeometryNodes_Geomesh")
        if modifier:
            geo_group = modifier.node_group
            if geo_group:
                collection_info = geo_group.nodes.get("Collection Info")
                
                if collection_info and speedsculpt.collection_selection:
                    collection_info.inputs[0].default_value = speedsculpt.collection_selection

                # Update the area of the modifiers
                bpy.context.view_layer.update()
                context.area.tag_redraw()

        # Set name with _Geomesh suffix
        geomesh_name = (self.geomesh_name if self.geomesh_name else 
                       speedsculpt.collection_selection.name if speedsculpt.collection_selection else "Geomesh")
        geomesh_name = geomesh_name.replace(" ", "_")
        
        if not geomesh_name.endswith("_Geomesh"):
            geomesh_name += "_Geomesh"
        
        act_obj.name = geomesh_name
        act_obj.data.name = act_obj.name
        act_obj.hide_select = True
        # Clear Location
        act_obj.location = (0, 0, 0)
        # Add custom property 'Geomesh'
        act_obj["Geomesh"] = True

        # Ajouter l'objet à la collection
        item = speedsculpt.geomesh_objects.add()
        item.name = act_obj.name
        item.value = act_obj.name
        
        # Mettre à jour l'index actif
        speedsculpt.geomesh_active_index = len(speedsculpt.geomesh_objects) - 1

        # Restaurer la sélection et le mode initial
        bpy.ops.object.select_all(action='DESELECT')
        
        if initial_active and initial_selection and initial_mode:
            # Vérifier que les objets existent encore et sont visibles
            valid_selection = []
            for obj in initial_selection:
                if obj.name in bpy.data.objects and obj.visible_get(view_layer=context.view_layer):
                    obj.select_set(state=True)
                    valid_selection.append(obj)
            
            # Restaurer l'objet actif si il est encore valide et visible
            if (initial_active.name in bpy.data.objects and 
                initial_active.visible_get(view_layer=context.view_layer)):
                context.view_layer.objects.active = initial_active
                
                # Restaurer le mode seulement si on a des objets sélectionnés valides
                if valid_selection and initial_mode != 'OBJECT':
                    try:
                        bpy.ops.object.mode_set(mode=initial_mode)
                    except:
                        self.report({'WARNING'}, f"Cannot restore the Previous Mode {initial_mode}")

        self.report({'INFO'}, f"Geomesh '{geomesh_name}' créé avec succès")
        return {'FINISHED'}
    
class SPEEDSCULPT_OT_toggle_geomesh_visibility(bpy.types.Operator):
    bl_idname = "object.speedsculpt_toggle_geomesh_visibility"
    bl_label = "Toggle Geomesh Visibility"
    bl_description = "Toggle visibility of Geomesh and its Geometry Nodes modifier\nThis will improve performance when Editing the Objects in the 3Dview"
    # bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si l'index est valide
        if 0 <= self.index < len(speedsculpt.geomesh_objects):
            # Récupère l'item
            item = speedsculpt.geomesh_objects[self.index]
            
            # Récupère l'objet Blender correspondant
            obj = bpy.data.objects.get(item.name)
            if obj:
                # Get le modificateur Geometry Nodes
                gn_mod = obj.modifiers.get("GeometryNodes_Geomesh")
                if gn_mod:
                    # Toggle visibility
                    obj.hide_viewport = not obj.hide_viewport
                    gn_mod.show_viewport = not gn_mod.show_viewport
                    
                    # Met à jour l'index actif
                    speedsculpt.geomesh_active_index = self.index

                    # Check if ISOLATE collection exists
                    isolate_collection = bpy.data.collections.get("ISOLATE")
                    if isolate_collection:
                        if obj.name not in isolate_collection.objects:
                            isolate_collection.objects.link(obj)
                    
                    # Force la mise à jour de l'interface
                    context.view_layer.update()
                    for area in context.screen.areas:
                        area.tag_redraw()
                    
                    return {'FINISHED'}
                else:
                    self.report({'WARNING'}, "Geometry Nodes modifier not found")
            else:
                self.report({'WARNING'}, "Object not found")
            
        return {'CANCELLED'}

class SPEEDSCULPT_OT_toggle_geomesh_visibility_shortcut(bpy.types.Operator):
    bl_idname = "object.speedsculpt_toggle_geomesh_visibility_shortcut"
    bl_label = "Toggle Geomesh Visibility"
    bl_description = "Toggle visibility of Geomesh object and its Geometry Nodes modifier"
    # bl_options = {'REGISTER', 'UNDO'}
    @classmethod
    def poll(cls, context):
        return context.scene.speedsculpt.geomesh_objects and len(context.scene.speedsculpt.geomesh_objects) > 0
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si on a des items dans la collection
        if len(speedsculpt.geomesh_objects) > 0:
            # Vérifie si l'index est valide
            if 0 <= speedsculpt.geomesh_active_index < len(speedsculpt.geomesh_objects):
                # Récupère l'item actif
                active_item = speedsculpt.geomesh_objects[speedsculpt.geomesh_active_index]
                
                # Récupère l'objet Blender correspondant
                active_geomesh = bpy.data.objects.get(active_item.name)
                if active_geomesh:
                    # Get son modifier
                    gn_mod = active_geomesh.modifiers.get("GeometryNodes_Geomesh")
                    if gn_mod:
                        # Toggle visibility
                        active_geomesh.hide_viewport = not active_geomesh.hide_viewport
                        gn_mod.show_viewport = not gn_mod.show_viewport
                        
                        # Force viewport update
                        context.view_layer.update()
                        for area in context.screen.areas:
                            if area.type == 'VIEW_3D':
                                area.tag_redraw()
                        
                        return {'FINISHED'}
            
        return {'CANCELLED'}

class SPEEDSCULPT_OT_delete_geomesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_delete_geomesh"
    bl_label = "Delete Geomesh"
    bl_description = "Delete the selected Geomesh"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Supprimer l'objet Blender
        obj = bpy.data.objects.get(self.object_name)
        if obj:
            bpy.data.objects.remove(obj, do_unlink=True)
        
        # Supprimer l'item de la collection
        speedsculpt.geomesh_objects.remove(self.index)
        
        # Ajuster l'index actif
        if len(speedsculpt.geomesh_objects) > 0:
            # Si on a supprimé le dernier item
            if self.index >= len(speedsculpt.geomesh_objects):
                speedsculpt.geomesh_active_index = len(speedsculpt.geomesh_objects) - 1
            else:
                # Garder le même index si possible
                speedsculpt.geomesh_active_index = self.index
        else:
            # Plus d'items, réinitialiser l'index
            speedsculpt.geomesh_active_index = 0
        
        # Forcer la mise à jour de l'interface
        for area in context.screen.areas:
            area.tag_redraw()
        
        return {'FINISHED'}

class SPEEDSCULPT_OT_lock_geomesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_lock_geomesh"
    bl_label = "Lock Geomesh"
    bl_description = "Lock/Unlock the Geomesh Selection"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore
    
    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si l'index est valide
        if 0 <= self.index < len(speedsculpt.geomesh_objects):
            # Récupère l'item
            item = speedsculpt.geomesh_objects[self.index]
            
            # Récupère l'objet Blender correspondant
            obj = bpy.data.objects.get(item.name)
            if obj:
                # Toggle hide_select
                obj.hide_select = not obj.hide_select
                
                # Met à jour l'index actif
                speedsculpt.geomesh_active_index = self.index
                
                # Force la mise à jour de l'interface
                context.view_layer.update()
                for area in context.screen.areas:
                    area.tag_redraw()
                
                return {'FINISHED'}
            
        return {'CANCELLED'}

class SPEEDSCULPT_OT_select_geomesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_select_geomesh"
    bl_label = "Select Geomesh"
    bl_description = "Select the selected Geomesh and make it active"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: bpy.props.StringProperty()# type: ignore
    index: bpy.props.IntProperty()# type: ignore

    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si l'index est valide
        if 0 <= self.index < len(speedsculpt.geomesh_objects):
            # Récupère l'item
            item = speedsculpt.geomesh_objects[self.index]
            
            # Désélectionne tous les objets
            bpy.ops.object.select_all(action='DESELECT')
            
            # Récupère et sélectionne l'objet
            obj = bpy.data.objects.get(item.name)
            if obj:
                obj.select_set(True)
                context.view_layer.objects.active = obj
                
                # Met à jour l'index actif dans la UI list
                speedsculpt.geomesh_active_index = self.index
                
                return {'FINISHED'}
            
        
        
        return {'CANCELLED'}

class SPEEDSCULPT_OT_rename_geomesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_rename_geomesh"
    bl_label = "Rename Geomesh"
    bl_description = "Rename the selected Geomesh"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore
    new_name: StringProperty(name="New Name") # type: ignore

    def invoke(self, context, event):
        # Get the object by name
        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            self.report({'WARNING'}, "Object not found")
            return {'CANCELLED'}
            
        # Get the base name without _Geomesh
        self.new_name = obj.name[:-8].replace(" ", "_") if obj.name.endswith("_Geomesh") else obj.name.replace(" ", "_")
        
        return context.window_manager.invoke_props_dialog(self, width=200)

    def draw(self, context):
        self.layout.prop(self, "new_name", text="")

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt

        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            self.report({'WARNING'}, "Object not found")
            return {'CANCELLED'}
        
        # Store current selection state
        was_selected = obj.select_get()
        active_obj = context.view_layer.objects.active

        # Rename object and mesh
        new_name = self.new_name + "_Geomesh"
        old_name = obj.name  # Store old name
        obj.name = new_name
        if obj.data:
            obj.data.name = new_name

        # Get all Geomesh objects and sort them
        geomesh_objects = sorted(
            [o for o in bpy.data.objects if o.get('Geomesh', False)],
            key=lambda x: x.name
        )
        
        # Find new index after sorting
        try:
            new_index = geomesh_objects.index(obj)
            speedsculpt.geomesh_active_index = new_index
            
            # Restore selection and active state
            obj.select_set(was_selected)
            if active_obj == obj:
                context.view_layer.objects.active = obj
        except ValueError:
            pass

        # Force UI updates
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        
        return {'FINISHED'}
  
class SPEEDSCULPT_OT_convert_geomesh_to_mesh(bpy.types.Operator):
    bl_idname = "object.speedsculpt_convert_geomesh_to_mesh"
    bl_label = "Convert Geomesh to Mesh"
    bl_description = "Convert Geomesh to regular mesh"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        
        # Vérifie si l'index est valide
        if 0 <= self.index < len(speedsculpt.geomesh_objects):
            # Récupère l'item
            item = speedsculpt.geomesh_objects[self.index]
            
            # Récupère l'objet Blender
            obj = bpy.data.objects.get(item.name)
            if not obj:
                self.report({'WARNING'}, "Object not found")
                return {'CANCELLED'}

            # Store current selection and mode
            has_object = context.object
            if has_object:
                active_object = context.active_object
                selection = context.selected_objects
                current_mode = active_object.mode

            # Deselect all objects
            bpy.ops.object.select_all(action='DESELECT')

            # Select and make active the target object
            obj.select_set(True)
            context.view_layer.objects.active = obj
            obj.hide_select = False
            obj.hide_viewport = False

            # Ensure we're in object mode
            if obj.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            
            for modifier in obj.modifiers:
                if not modifier.show_viewport:
                    obj.modifiers.remove(modifier)
                else:
                    try:
                        bpy.ops.object.modifier_apply(modifier=modifier.name)
                    except:
                        self.report({'WARNING'}, f"Could not apply modifier {modifier.name}")

            # Remove _Geomesh suffix from name
            if obj.name.endswith("_Geomesh"):
                obj.name = obj.name[:-8]
                if obj.data:
                    obj.data.name = obj.name

            # Select the converted object
            bpy.ops.object.select_all(action='DESELECT')
            obj.select_set(True)
            context.view_layer.objects.active = obj
            obj.show_in_front = False
            obj["Geomesh"] = False

            # Supprimer l'item de la collection
            speedsculpt.geomesh_objects.remove(self.index)
            
            # Ajuster l'index actif
            if len(speedsculpt.geomesh_objects) > 0:
                # Si on a supprimé le dernier item
                if self.index >= len(speedsculpt.geomesh_objects):
                    speedsculpt.geomesh_active_index = len(speedsculpt.geomesh_objects) - 1
                else:
                    # Garder le même index si possible
                    speedsculpt.geomesh_active_index = self.index
            else:
                # Plus d'items, réinitialiser l'index
                speedsculpt.geomesh_active_index = 0

            # Select the object
            bpy.ops.object.select_all(action='DESELECT')
            if has_object:
                for obj in selection:
                    obj.select_set(state=True)
                    context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode=current_mode)

            # Force UI updates
            for area in context.screen.areas:
                area.tag_redraw()

            return {'FINISHED'}
            
        return {'CANCELLED'}

class SPEEDSCULPT_OT_toggle_geomesh_mirror(bpy.types.Operator):
    bl_idname = "object.speedsculpt_toggle_geomesh_mirror"
    bl_label = "Toggle Geomesh Mirror"
    bl_description = "Toggle Geomesh Mirror modifier visibility"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore

    def execute(self, context):
        obj = bpy.data.objects.get(self.object_name)
        
        if obj:
            # Cherche un modifier Mirror existant
            mirror_mod = obj.modifiers.get("Mirror")
            
            if mirror_mod:
                # Si le modifier existe, on inverse sa visibilité
                mirror_mod.show_viewport = not mirror_mod.show_viewport
            else:
                # Si pas de modifier Mirror, on en crée un
                mirror_mod = obj.modifiers.new(name="Mirror", type='MIRROR')
                mirror_mod.use_bisect_axis[0] = True
                mirror_mod.show_viewport = True
                
                # Déplace le modifier à la fin de la pile
                for i in range(len(obj.modifiers)-1):
                    bpy.ops.object.modifier_move_down(modifier="Mirror")
            
            # Force le rafraîchissement de l'interface
            context.view_layer.update()
            for area in context.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
                    
        return {'FINISHED'}

########################################################################################################################
#    GRID SCALE
########################################################################################################################
class SPEEDSCULPT_OT_grid_scale(Operator):
    bl_idname = "object.speedsculpt_grid_scale"
    bl_label = "Grid Scale"

    grid_scale: FloatProperty(
        name="Grid Scale",
        description="Grid Scale",
        default=1.0
    ) # type: ignore
    
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        # Vérifier si la Grid Scale existe déjà
        for obj in bpy.data.objects:
            if obj.name.startswith("Grid_Scale"):
                return {'CANCELLED'}
                
        # Sauvegarder la sélection actuelle
        has_object = context.object
        if has_object:
            active_object = context.active_object
            selection = context.selected_objects
            current_mode = active_object.mode
            if active_object and selection:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.select_all(action='DESELECT')
        
        # APPEND -----------------------------------------
        current_dir = os.path.dirname(os.path.realpath(__file__))
        base_path = os.path.join(current_dir, 'library')
        file_path = os.path.join(base_path, "grid_scale.blend")
        
        with bpy.data.libraries.load(file_path) as (data_from, data_to):
            data_to.objects = [name for name in data_from.objects if name in data_from.objects]

        bpy.ops.object.select_all(action='DESELECT')

        # COLLECTION --------------------------------------
        master_collection = context.scene.collection
        grid_scale_collection = bpy.data.collections.get("GRID SCALE")
        if not grid_scale_collection:
            grid_scale_collection = bpy.data.collections.new("GRID SCALE")
            context.scene.collection.children.link(grid_scale_collection)
        
        # Move object to master collection
        for obj in data_to.objects:
            for collection in obj.users_collection:
                collection.objects.unlink(obj)
            grid_scale_collection.objects.link(obj)
            context.view_layer.objects.active = obj
            # S'assurer que l'objet est visible
            obj.hide_viewport = False

            # Appliquer l'échelle en fonction de l'unité active dans Blender
            unit_settings = context.scene.unit_settings
            scale_factor = 1.0
            
            # Détecter l'unité active et ajuster l'échelle en conséquence
            if unit_settings.system == 'METRIC':
                if unit_settings.length_unit == 'KILOMETERS':
                    scale_factor = 0.0001 
                elif unit_settings.length_unit == 'METERS':
                    scale_factor = 0.01  # Convertir de 100m à 1m
                elif unit_settings.length_unit == 'CENTIMETERS':
                    scale_factor = 1.0   # Pas de conversion nécessaire
                elif unit_settings.length_unit == 'MILLIMETERS':
                    scale_factor = 10.0  # Convertir de 100m à 1000mm
                
            # Appliquer l'échelle personnalisée multipliée par le facteur d'unité
            final_scale = self.grid_scale * scale_factor
            obj.scale = (final_scale, final_scale, final_scale)

        act_obj = context.active_object
        if act_obj:
            act_obj.select_set(state=True)
            context.view_layer.objects.active = act_obj
            bpy.ops.object.location_clear(clear_delta=False)
            act_obj.hide_select = True

        # Restaurer la sélection précédente
        bpy.ops.object.select_all(action='DESELECT')
        if has_object:
            for obj in selection:
                obj.select_set(state=True)
                context.view_layer.objects.active = active_object
            bpy.ops.object.mode_set(mode=current_mode)

        return {'FINISHED'}
    
class SPEEDSCULPT_OT_isolate_objects(Operator):
    bl_idname = "object.speedsculpt_isolate_objects"
    bl_label = "Isolate Objects"
    bl_description = "Link selected objects to ISOLATE collection and use local collections"
    bl_options = {'REGISTER', 'UNDO'}

    move_to_collection: BoolProperty(
        name="Move Objects to Collection",
        description="Move non-selected objects to Collection if they are not in any collection",
        default=False
    )# type: ignore

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        speedsculpt.active_collection = context.view_layer.active_layer_collection.collection.name

        # Vérifier s'il y a des objets sélectionnés
        if not context.selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        # Créer la collection ISOLATE si elle n'existe pas
        isolate_collection = bpy.data.collections.get("ISOLATE")
        if not isolate_collection:
            isolate_collection = bpy.data.collections.new("ISOLATE")
            context.scene.collection.children.link(isolate_collection)

        # Définir ISOLATE comme collection active
        for layer_coll in context.view_layer.layer_collection.children:
            if layer_coll.collection == isolate_collection:
                context.view_layer.active_layer_collection = layer_coll
                break

        # Vérifier les objets non sélectionnés qui ne sont pas dans une collection
        unselected_objects = [obj for obj in context.view_layer.objects if obj not in context.selected_objects]
        objects_without_collection = []
        
        for obj in unselected_objects:
            # Vérifier si l'objet est directement dans la collection de la scène (pas dans une sous-collection)
            if obj.name in context.scene.collection.objects and len(obj.users_collection) <= 1:
                objects_without_collection.append(obj)
        
        # Si des objets sans collection ont été trouvés
        if objects_without_collection:
            # Créer un message d'avertissement
            object_names = ", ".join([obj.name for obj in objects_without_collection[:5]])
            if len(objects_without_collection) > 5:
                object_names += f" and {len(objects_without_collection) - 5} others"
                
            warning_message = f"{len(objects_without_collection)} Non Selected objects that are not in a Collection: {object_names}"
            self.report({'WARNING'}, warning_message)
            
            # Si l'utilisateur a choisi de déplacer les objets et que Collection existe
            if self.move_to_collection:
                default_collection = bpy.data.collections.get("Collection")
                if default_collection:
                    for obj in objects_without_collection:
                        if obj.name not in default_collection.objects:
                            default_collection.objects.link(obj)
                            if obj.name in context.scene.collection.objects:
                                context.scene.collection.objects.unlink(obj)
                    self.report({'INFO'}, f"{len(objects_without_collection)} Objects moved to 'Collection'")
                else:
                    self.report({'WARNING'}, "'Collection' Doesn't exist, Can not move the Objects in it")

        # Lier les objets sélectionnés à la collection ISOLATE
        for obj in context.selected_objects:
            if obj.name not in isolate_collection.objects:
                isolate_collection.objects.link(obj)

        # Activer l'option local collections dans la vue 3D active
        context.space_data.use_local_collections = True

        # Réinitialiser la visibilité de toutes les collections dans la vue active
        # en les rendant toutes visibles d'abord
        for i, layer_coll in enumerate(context.view_layer.layer_collection.children):
            collection_index = i + 1
            if not layer_coll.visible_get():  # Si la collection est cachée dans la vue active
                bpy.ops.object.hide_collection(collection_index=collection_index, toggle=True)

        # Trouver l'index de la collection ISOLATE
        isolate_index = None
        for i, layer_coll in enumerate(context.view_layer.layer_collection.children):
            if layer_coll.name == "ISOLATE":
                isolate_index = i + 1
                break

        # Masquer toutes les collections sauf ISOLATE dans la vue active
        if isolate_index is not None:
            for i, layer_coll in enumerate(context.view_layer.layer_collection.children):
                collection_index = i + 1
                if collection_index != isolate_index:
                    if layer_coll.visible_get():  # Si la collection est visible dans la vue active
                        bpy.ops.object.hide_collection(collection_index=collection_index, toggle=True)

        return {'FINISHED'}
        
    def invoke(self, context, event):
        # Vérifier les objets non sélectionnés qui ne sont pas dans une collection
        unselected_objects = [obj for obj in context.view_layer.objects if obj not in context.selected_objects]
        objects_without_collection = []
        
        for obj in unselected_objects:
            if obj.name in context.scene.collection.objects and len(obj.users_collection) <= 1:
                objects_without_collection.append(obj)
        
        # Si des objets sans collection ont été trouvés, afficher un dialogue
        if objects_without_collection and bpy.data.collections.get("Collection"):
            return context.window_manager.invoke_props_dialog(self)
        else:
            return self.execute(context)
    
    def draw(self, context):
        layout = self.layout

        # Compter les objets sans collection
        unselected_objects = [obj for obj in context.view_layer.objects if obj not in context.selected_objects]
        objects_without_collection = []
        for obj in unselected_objects:
            if obj.name in context.scene.collection.objects and len(obj.users_collection) <= 1:
                objects_without_collection.append(obj)

        layout.label(text=f"{len(objects_without_collection)} Objects are not in a Collection", icon='WARNING_LARGE')
        layout.label(text="They will be visible in Isolation")
        layout.label(text="Move them in 'Collection' ?")
        layout.prop(self, "move_to_collection")

class SPEEDSCULPT_OT_unisolate_objects(Operator):
    bl_idname = "object.speedsculpt_unisolate_objects"
    bl_label = "Unisolate Objects"
    bl_description = "Disable local collections, unlink objects from ISOLATE collection and remove it"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        # Désactiver les collections locales
        context.space_data.use_local_collections = False

        saved_collection = bpy.data.collections.get(speedsculpt.active_collection)

        # Récupérer la collection ISOLATE
        isolate_collection = bpy.data.collections.get("ISOLATE")
        
        if isolate_collection:

            saved_collection = bpy.data.collections.get(speedsculpt.active_collection)

            # Réassigner les objets orphelins à la collection sauvegardée
            for obj in isolate_collection.objects[:]:
                if len(obj.users_collection) == 1:  # Seulement ISOLATE
                    if saved_collection:
                        saved_collection.objects.link(obj)
                isolate_collection.objects.unlink(obj)

            # Unlink tous les objets de la collection ISOLATE
            for obj in isolate_collection.objects[:]:  # Créer une copie de la liste pour éviter les problèmes de modification pendant l'itération
                isolate_collection.objects.unlink(obj)

            # Unlink la collection ISOLATE de la scène
            for scene in bpy.data.scenes:
                if isolate_collection.name in scene.collection.children:
                    scene.collection.children.unlink(isolate_collection)

            # Supprimer la collection ISOLATE
            bpy.data.collections.remove(isolate_collection)
        
        # Définir ISOLATE comme collection active
        for layer_coll in context.view_layer.layer_collection.children:
            if layer_coll.collection == saved_collection:
                context.view_layer.active_layer_collection = layer_coll
                break
        
        speedsculpt.active_collection = ""

        return {'FINISHED'}

# DUPLICATE WITH HIERARCHY
def get_hierarchy_depth(obj):
    depth = 0
    while obj.parent:
        obj = obj.parent
        depth += 1
    return depth

def duplicate_hierarchy_preserve_tree(objs, make_instances=False):
    original_to_copy = {}
    sorted_objs = sorted(objs, key=get_hierarchy_depth)

    for obj in sorted_objs:
        obj_copy = obj.copy()
        
        # Si make_instances est False, on copie les données, sinon on les partage
        if not make_instances:
            obj_copy.data = obj.data.copy() if obj.data else None
        # Si make_instances est True, obj_copy.data reste une référence aux données originales
        
        bpy.context.collection.objects.link(obj_copy)
        original_to_copy[obj] = obj_copy

    for orig in sorted_objs:
        copy = original_to_copy[orig]
        if orig.parent in original_to_copy:
            copy.parent = original_to_copy[orig.parent]
            copy.matrix_parent_inverse = orig.matrix_parent_inverse.copy()

    return list(original_to_copy.values())

class SPEEDSCULPT_OT_mirror_with_hierarchy(Operator):
    bl_idname = 'object.speedsculpt_mirror_with_hierarchy'
    bl_label = "Mirror With Hierarchy"
    bl_description = "Mirror the selection on the X axis with Hierarchy\n\nPerfect to Mirror limbs or parts of a character\nIt will keep the Hierarchy of the Selection"
    bl_options = {'REGISTER','UNDO'}

    
    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        initial_selection = context.selected_objects

        if not initial_selection:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        if speedsculpt.mirror_selection_add_suffixes:
            for obj in context.selected_objects:
                if "_L" in obj.name:
                    break
                
                obj.name = obj.name + '_L' 

        # Passer le paramètre make_instances à la fonction
        duplicated_objs = duplicate_hierarchy_preserve_tree(
            initial_selection, 
            make_instances=speedsculpt.mirror_selection_make_instances
        )

        # Empty
        bpy.ops.object.select_all(action='DESELECT')
        for obj in duplicated_objs:
            obj.select_set(True)
        context.view_layer.objects.active = duplicated_objs[0]
        bpy.ops.object.empty_add(type='PLAIN_AXES', align='WORLD', location=(0, 0, 0))
        empty = context.active_object

        # Parents racines
        root_objs = [obj for obj in duplicated_objs if not obj.parent or obj.parent not in duplicated_objs]
        for obj in root_objs:
            obj.select_set(True)
        empty.select_set(True)
        context.view_layer.objects.active = empty
        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)

        # Miroir X
        bpy.ops.object.select_all(action='DESELECT')
        empty.select_set(True)
        context.view_layer.objects.active = empty
        bpy.ops.transform.resize(value=(-1, 1, 1))
        bpy.ops.object.transform_apply(scale=True)

        # Déparente
        bpy.ops.object.select_all(action='DESELECT')
        for obj in root_objs:
            obj.select_set(True)
        context.view_layer.objects.active = root_objs[0]
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')

        # Supprime empty
        bpy.ops.object.select_all(action='DESELECT')
        empty.select_set(True)
        context.view_layer.objects.active = empty
        bpy.ops.object.delete()

        # Clean
        for obj in duplicated_objs:
            context.view_layer.objects.active = obj
            bpy.ops.object.transform_apply(location=False, rotation=True, scale=True)

            if obj.type == 'MESH':
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='SELECT')
                bpy.ops.mesh.normals_make_consistent(inside=False)
                bpy.ops.object.mode_set(mode='OBJECT')

            if speedsculpt.mirror_selection_add_suffixes:
                obj.name = obj.name.replace("_L", "_R").replace(".001", "")
            
            # Pour les instances, on ne renomme pas les données car elles sont partagées
            if obj.data and not speedsculpt.mirror_selection_make_instances:
                obj.data.name = obj.name

        return {'FINISHED'}
    
def identify_curves_modifier_type(modifier):
    """
    Identifie le type de modifier Curves en fonction de ses inputs
    """
    if modifier.type == 'NODES':
        try:
            # Récupérer tous les inputs disponibles dans l'ordre
            input_numbers = [int(prop.split("_")[1]) for prop in modifier.keys() if prop.startswith("Input_")]
            if not input_numbers:  # Si la liste est vide
                return None
                
            max_input = max(input_numbers)
            inputs = []
            for i in range(1, max_input + 1):
                if f"Input_{i}" in modifier:
                    inputs.append(i)
            
            # print(f"\nProcessing modifier: {modifier.name}")
            # print(f"Found inputs: {inputs}")
            
            # Définir les signatures d'inputs pour chaque type (dans l'ordre)
            signatures = {
                # UTILITY
                "profile": [2, 3, 4, 5, 6],
                
                # GENERATE
                "generate": [2, 12, 13, 14, 15, 16, 17, 18, 19, 20, 22, 27],
                "duplicate": [2, 3, 4, 5, 6, 7, 8],
                "interpolate": [2, 10, 12, 13, 14, 15, 16, 17, 18, 19, 24, 26, 28],
                
                # GUIDES
                "braid_hair_curves": [25, 4, 22, 3, 2, 5, 6, 7, 8, 9, 10, 11, 14, 13, 12, 15, 21, 16, 18],
                "clump_hair_curves": [6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 19],
                "create_guide_index_map": [3, 11, 12],
                "curl_hair_curves": [19, 4, 18, 3, 2, 5, 6, 7, 9, 10 ,11, 16, 15],
                
                # DEFORMATIONS
                "blend_hair_curves": [2, 4, 5, 6],
                "displace_hair_curves": [3, 8, 2, 9, 4, 6, 7],
                "frizz_hair_curves": [10, 3, 11, 2, 8, 6],
                "curves_noise": [10, 3, 14, 2, 11, 12, 13, 8, 6],
                "roll_hair_curves": [10, 13, 11, 2, 3, 9, 4, 5, 7, 6, 8, 12],
                "rotate_hair_curves": [5, 3, 2, 6, 8, 7],
                "shrinkwrap_hair_curves": [2, 5, 4, 8, 6, 7],
                "smooth_hair_curves": [10, 13, 3, 4, 2, 8],
                "straighten_hair_curves": [2, 9, 7],
                "trim_hair_curves": [9, 5, 6, 2, 7, 4, 3, 8],

                # UTILITIES
                "attach_hair_curves_to_surface": [4, 2, 6, 10, 8, 7, 12],
                "redistribute_curves_points": [2, 3],
                "restore_curve_segment_length": [4, 3, 2, 6],
            }

            # Vérifier si inputs n'est pas vide
            # if not inputs:
                # print("No inputs found")
                # return None

            # Comparer avec les signatures
            for mod_type, signature in signatures.items():
                # Vérifier si on a les mêmes inputs sans tenir compte de l'ordre
                if sorted(inputs) == sorted(signature):
                    # print(f"✓ Found match: {mod_type}")
                    return mod_type

        except Exception as e:
            print(f"Error checking inputs: {e}")
            
    # print("No match found")
    return None

class SPEEDSCULPT_OT_toggle_modifiers(Operator):
    bl_idname = "object.speedsculpt_toggle_modifiers"
    bl_label = "Toggle Modifiers"
    bl_description = "Toggle modifiers visibility for selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        selected_objects = context.selected_objects
        
        for obj in selected_objects:
            # Initialiser ou récupérer la liste des modifiers initialement cachés
            if "initial_hidden_modifiers" not in obj:
                # Premier appel : sauvegarder l'état initial des modifiers cachés
                initial_hidden = [mod.name for mod in obj.modifiers if not mod.show_viewport]
                obj["initial_hidden_modifiers"] = initial_hidden
            else:
                initial_hidden = list(obj.get("initial_hidden_modifiers", []))
            
            if obj.type == 'CURVES':
                for mod in obj.modifiers:
                    if mod.type == 'NODES':
                        modifier_type = identify_curves_modifier_type(mod)
                        if modifier_type in {'interpolate', 'duplicate', 'generate'}:
                            if mod.name not in initial_hidden:  # Ne pas toucher aux modifiers cachés initialement
                                mod.show_viewport = not mod.show_viewport
                
                # Nettoyer la liste si on réaffiche les modifiers
                if not any(mod.show_viewport for mod in obj.modifiers):
                    if "initial_hidden_modifiers" in obj:
                        del obj["initial_hidden_modifiers"]
            
            elif obj.type == 'MESH':
                # Vérifier s'il y a des modifiers visibles (non cachés initialement)
                visible_mods = [mod for mod in obj.modifiers 
                              if mod.show_viewport and mod.name not in initial_hidden]
                
                if visible_mods:
                    # Si des modifiers sont visibles, les cacher tous (sauf ceux cachés initialement)
                    for mod in obj.modifiers:
                        if mod.name not in initial_hidden:
                            mod.show_viewport = False
                else:
                    # Si tous sont cachés, réafficher tous (sauf ceux cachés initialement)
                    for mod in obj.modifiers:
                        if mod.name not in initial_hidden:
                            mod.show_viewport = True
                    # Nettoyer la liste après avoir réaffiché les modifiers
                    if "initial_hidden_modifiers" in obj:
                        del obj["initial_hidden_modifiers"]
                
                # Gérer les hair curves enfants
                for child in obj.children:
                    if child.type == 'CURVES':
                        if "initial_hidden_modifiers" not in child:
                            child_initial_hidden = [mod.name for mod in child.modifiers 
                                                  if not mod.show_viewport]
                            child["initial_hidden_modifiers"] = child_initial_hidden
                        else:
                            child_initial_hidden = list(child.get("initial_hidden_modifiers", []))
                        
                        for mod in child.modifiers:
                            if mod.type == 'NODES' and mod.name in {'Interpolate Hair Curves', 'Duplicate Hair Curves', 'Generate Hair Curves'}:
                                if mod.name not in child_initial_hidden:
                                    mod.show_viewport = not mod.show_viewport
                        
                        # Nettoyer la liste si on réaffiche les modifiers
                        if not any(mod.show_viewport for mod in child.modifiers):
                            if "initial_hidden_modifiers" in child:
                                del child["initial_hidden_modifiers"]

        return {'FINISHED'}

class SPEEDSCULPT_OT_flip_mesh(Operator):
    bl_idname = 'object.speedsculpt_flip_mesh'
    bl_label = "Flip the Mesh Symmetrically"
    bl_description = "Flip the Mesh Symmetrically"
    bl_options = {'REGISTER','UNDO'}

    flip_axis: EnumProperty(
            items=(("X", "X Axis",""),
                   ("Y","Y Axis",""),
                   ("Z","Z Axis","")),
                   default="X",
                   description="Flip the Mesh Symmetrically") # type: ignore

    @classmethod
    def description(self, context, properties):
        if properties.flip_axis == "X":
            return "Flip the Mesh Symmetrically on the X Axis"
        elif properties.flip_axis == "Y":
            return "Flip the Mesh Symmetrically on the Y Axis"
        elif properties.flip_axis == "Z":
            return "Flip the Mesh Symmetrically on the Z Axis"
                    
    # @classmethod
    # def poll(cls, context):
    #     return len(context.selected_objects) == 1 and context.object.mode == 'OBJECT'

    def execute(self, context):

        current_mode = context.active_object.mode

        bpy.ops.object.mode_set(mode='OBJECT')

        if self.flip_axis == 'X':
            axis = (-1,1,1)
        elif self.flip_axis == 'Y':
            axis = (1,-1,1)
        elif self.flip_axis == 'Z':
            axis = (1,1,-1)

        bpy.ops.transform.resize(value=axis, 
                                 orient_type='GLOBAL', 
                                 orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), 
                                 orient_matrix_type='GLOBAL', 
                                 constraint_axis=(True, False, False), 
                                 mirror=False, 
                                 use_proportional_edit=False, 
                                 proportional_edit_falloff='SMOOTH', 
                                 proportional_size=1, 
                                 use_proportional_connected=False, 
                                 use_proportional_projected=False, 
                                 snap=False, 
                                 snap_elements={'INCREMENT'}, 
                                 use_snap_project=False, 
                                 snap_target='CLOSEST', 
                                 use_snap_self=True, 
                                 use_snap_edit=True, 
                                 use_snap_nonedit=True, 
                                 use_snap_selectable=False)

        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='FACE')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        
        #Restore Mode
        bpy.ops.object.mode_set(mode=current_mode, toggle=False)

        return {'FINISHED'}

class SPEEDSCULPT_OT_draw_curve(Operator):
    bl_idname = "object.speedsculpt_draw_curve"
    bl_label = "Draw Curve"
    bl_description = "Draw a curve with Ronded cap"
    bl_options = {'REGISTER','UNDO'}


    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        active_collection = context.view_layer.active_layer_collection.collection
        cursor_location = context.scene.cursor.location.copy()
        cursor_rotation = context.scene.cursor.rotation_euler.copy()

        act_obj = context.active_object if context.object is not None and context.view_layer.objects.active is not None else None
                
        # Sauvegarder la sélection actuelle
        if context.selected_objects:
            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')
        
        # APPEND -----------------------------------------
        current_dir = os.path.dirname(os.path.realpath(__file__))
        base_path = os.path.join(current_dir, 'library')
        file_path = os.path.join(base_path, "draw_curve.blend")
        
        with bpy.data.libraries.load(file_path) as (data_from, data_to):
            data_to.objects = [name for name in data_from.objects if name in data_from.objects]


        # Lier les objets à la scène et les déplacer vers la collection active
        for obj in data_to.objects:
            # Lier l'objet à la scène s'il ne l'est pas déjà
            if obj.name not in context.scene.objects:
                context.scene.collection.objects.link(obj)
            
            # Retirer l'objet de toutes ses collections actuelles
            for collection in obj.users_collection:
                collection.objects.unlink(obj)
            
            # Ajouter l'objet à la collection active
            active_collection.objects.link(obj)
            context.view_layer.objects.active = obj

        new_obj = context.active_object
        new_obj["Speedsculpt_curve"] = True
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.wm.tool_set_by_id(name="builtin.draw")

        # CURSOR OR SURFACE
        context.scene.tool_settings.curve_paint_settings.depth_mode = speedsculpt.draw_curve_surface_cursor

        # Add Mirror
        if speedsculpt.add_mirror:
            bpy.ops.object.speedsculpt_add_mirror()
            
        # Parenting
        if speedsculpt.primitives_parenting and act_obj:
            if not context.active_object.parent:
                act_obj.select_set(state=True)
                context.view_layer.objects.active = act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                act_obj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj
        

        context.scene.cursor.location[:] = cursor_location
        context.scene.cursor.rotation_euler[:] = cursor_rotation
        
        return {'FINISHED'}

class SPEEDSCULPT_OT_brush_intensity_modal(bpy.types.Operator):
    bl_idname = "object.speedsculpt_brush_intensity_modal"
    bl_label = "Brush Intensity Modal"
    bl_description = "Click and drag to adjust brush strength and radius"
    bl_options = {'REGISTER', 'UNDO'}

    # Propriétés pour stocker les valeurs initiales
    initial_strength: FloatProperty() # type: ignore
    initial_radius: IntProperty() # type: ignore
    initial_mouse_x: IntProperty() # type: ignore
    initial_mouse_y: IntProperty() # type: ignore
    
    # Facteurs de sensibilité (réduits par deux)
    strength_sensitivity: FloatProperty(default=0.005, description="Sensitivity for strength adjustment") # type: ignore
    radius_sensitivity: FloatProperty(default=0.5, description="Sensitivity for radius adjustment") # type: ignore
    
    # Seuil pour déterminer quelle direction est dominante
    direction_threshold: FloatProperty(default=0.3, description="Threshold to determine dominant direction") # type: ignore

    @classmethod
    def poll(cls, context):
        # Vérifier qu'on est en mode sculpt et qu'un objet est actif
        return (context.mode == 'SCULPT' and 
                context.active_object and 
                context.active_object.type == 'MESH')

    def get_brush_settings(self, context):
        """Récupère les paramètres de la brosse active"""
        tool_settings = context.tool_settings.sculpt
        unified_settings = context.scene.tool_settings.unified_paint_settings
        
        # Vérifier si les paramètres unifiés sont utilisés
        if unified_settings.use_unified_size:
            size = unified_settings.size
        else:
            size = tool_settings.brush.size
            
        if unified_settings.use_unified_strength:
            strength = unified_settings.strength
        else:
            strength = tool_settings.brush.strength
            
        return strength, size

    def set_brush_settings(self, context, strength, size):
        """Définit les paramètres de la brosse active"""
        tool_settings = context.tool_settings.sculpt
        unified_settings = context.scene.tool_settings.unified_paint_settings
        
        # Vérifier si les paramètres unifiés sont utilisés
        if unified_settings.use_unified_size:
            unified_settings.size = int(size)  # Convertir en int
        else:
            tool_settings.brush.size = int(size)  # Convertir en int
            
        if unified_settings.use_unified_strength:
            unified_settings.strength = strength
        else:
            tool_settings.brush.strength = strength

    def invoke(self, context, event):
        # Sauvegarder les valeurs initiales
        self.initial_strength, self.initial_radius = self.get_brush_settings(context)
        self.initial_mouse_x = event.mouse_x
        self.initial_mouse_y = event.mouse_y
        
        # Démarrer le modal
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'MOUSEMOVE':
            # Calculer les déplacements
            delta_x = event.mouse_x - self.initial_mouse_x
            delta_y = event.mouse_y - self.initial_mouse_y
            
            # Calculer les valeurs absolues pour déterminer la direction dominante
            abs_delta_x = abs(delta_x)
            abs_delta_y = abs(delta_y)
            
            # Normaliser les déplacements pour la comparaison
            max_delta = max(abs_delta_x, abs_delta_y)
            if max_delta > 0:
                normalized_x = abs_delta_x / max_delta
                normalized_y = abs_delta_y / max_delta
                
                # Déterminer quelle direction est dominante
                if normalized_x > self.direction_threshold and normalized_x > normalized_y:
                    # Mouvement horizontal dominant - ajuster la force
                    strength_delta = delta_x * self.strength_sensitivity
                    new_strength = self.initial_strength + strength_delta
                    new_strength = max(0.0, min(1.0, new_strength))
                    
                    # Garder le rayon inchangé
                    new_radius = self.initial_radius
                    
                elif normalized_y > self.direction_threshold and normalized_y > normalized_x:
                    # Mouvement vertical dominant - ajuster le rayon (inversé)
                    radius_delta = delta_y * self.radius_sensitivity  # Plus d'inversion, vers le haut = augmentation
                    new_radius = self.initial_radius + radius_delta
                    new_radius = max(1, int(new_radius))  # Rayon minimum de 1, convertir en int
                    
                    # Garder la force inchangée
                    new_strength = self.initial_strength
                    
                else:
                    # Mouvement diagonal - ne rien faire
                    return {'RUNNING_MODAL'}
                
                # Appliquer les nouvelles valeurs
                self.set_brush_settings(context, new_strength, new_radius)
                
                # Forcer la mise à jour de l'interface
                context.area.tag_redraw()
            
        elif event.type == 'LEFTMOUSE' and event.value == 'RELEASE':
            # Terminer le modal quand on relâche le clic gauche
            return {'FINISHED'}
            
        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            # Annuler et restaurer les valeurs initiales
            self.set_brush_settings(context, self.initial_strength, self.initial_radius)
            return {'CANCELLED'}
        
        return {'RUNNING_MODAL'}

    def execute(self, context):
        return {'FINISHED'}

import os
from pathlib import Path

BRUSH_ASSET_PATHS = {
    "curve_sculpt": "brushes\\essentials_brushes-curve_sculpt.blend\\Brush\\",
    "mesh_paint": "brushes\\essentials_brushes-mesh_texture.blend\\Brush\\",
    "mesh_vertex_paint": "brushes\\essentials_brushes-mesh_vertex.blend\\Brush\\",
    "mesh_weight_paint": "brushes\\essentials_brushes-mesh_weight.blend\\Brush\\",
    "mesh_sculpt": "brushes\\essentials_brushes-mesh_sculpt.blend\\Brush\\",
    "gp_sculpt": "brushes\\essentials_brushes-gp_sculpt.blend\\Brush\\",
    "gp_vertex_paint": "brushes\\essentials_brushes-gp_vertex.blend\\Brush\\",
    "gp_weight_paint": "brushes\\essentials_brushes-gp_weight.blend\\Brush\\",
    "gp_draw": "brushes\\essentials_brushes-gp_draw.blend\\Brush\\"
}

mesh_sculpt_brushes_dic = {
    # Paint
    "mesh_sculpt_airbrush": {"asset_name": "Airbrush", "icon_name": "icon_mesh_paint_paint_airbrush"},
    "mesh_sculpt_blend_hard": {"asset_name": "Blend Hard", "icon_name": "icon_mesh_paint_paint_blend_hard"},
    "mesh_sculpt_blend_soft": {"asset_name": "Blend Soft", "icon_name": "icon_mesh_paint_paint_blend_soft"},
    "mesh_sculpt_blend_square": {"asset_name": "Blend Square", "icon_name": "icon_mesh_paint_paint_blend_square"},
    "mesh_sculpt_paint_blend": {"asset_name": "Paint Blend", "icon_name": "icon_mesh_paint_paint_wet"},
    "mesh_sculpt_paint_hard": {"asset_name": "Paint Hard", "icon_name": "icon_mesh_paint_paint"},
    "mesh_sculpt_paint_hard_pressure": {"asset_name": "Paint Hard Pressure", "icon_name": "icon_mesh_paint_paint_hard_pressure"},
    "mesh_sculpt_paint_soft": {"asset_name": "Paint Soft", "icon_name": "icon_mesh_paint_paint_soft"},
    "mesh_sculpt_paint_soft_pressure": {"asset_name": "Paint Soft Pressure", "icon_name": "icon_mesh_paint_paint_soft_pressure"},
    "mesh_sculpt_paint_square": {"asset_name": "Paint Square", "icon_name": "icon_mesh_paint_paint_roller"},
    "mesh_sculpt_sharpen": {"asset_name": "Sharpen", "icon_name": "icon_mesh_paint_sharpen"},
    "mesh_sculpt_smear": {"asset_name": "Smear", "icon_name": "icon_mesh_paint_smear"},
    #CLOTH
    "mesh_sculpt_bend_boundary_cloth": {"asset_name": "Bend Boundary Cloth", "icon_name": "icon_mesh_sculpt_cloth_boundary_bend"},
    "mesh_sculpt_bend_twist_cloth": {"asset_name": "Bend/Twist Cloth", "icon_name": "icon_mesh_sculpt_pose_cloth"},
    "mesh_sculpt_drag_cloth": {"asset_name": "Drag Cloth", "icon_name": "icon_mesh_sculpt_cloth_drag"},
    "mesh_sculpt_expand_contract_cloth": {"asset_name": "Expand/Contract Cloth", "icon_name": "icon_mesh_sculpt_cloth_expand_contract"},
    "mesh_sculpt_grab_cloth": {"asset_name": "Grab Cloth", "icon_name": "icon_mesh_sculpt_cloth_grab"},
    "mesh_sculpt_grab_planar_cloth": {"asset_name": "Grab Planar Cloth ", "icon_name": "icon_mesh_sculpt_cloth_grab_planar"},
    "mesh_sculpt_grab_random_cloth": {"asset_name": "Grab Random Cloth", "icon_name": "icon_mesh_sculpt_cloth_grab_random"},
    "mesh_sculpt_inflate_cloth": {"asset_name": "Inflate Cloth", "icon_name": "icon_mesh_sculpt_cloth_inflate"},
    "mesh_sculpt_pinch_folds_cloth": {"asset_name": "Pinch Folds Cloth", "icon_name": "icon_mesh_sculpt_cloth_pinch_folds"},
    "mesh_sculpt_pinch_point_cloth": {"asset_name": "Pinch Point Cloth", "icon_name": "icon_mesh_sculpt_cloth_pinch_point"},
    "mesh_sculpt_push_cloth": {"asset_name": "Push Cloth", "icon_name": "icon_mesh_sculpt_cloth_push"},
    "mesh_sculpt_stretch_move_cloth": {"asset_name": "Stretch/Move Cloth", "icon_name": "icon_mesh_sculpt_pose_stretch_cloth"},
    "mesh_sculpt_twist_boundary_cloth": {"asset_name": "Twist Boundary Cloth", "icon_name": "icon_mesh_sculpt_cloth_boundary_twist"},
    # SCULPT
    "mesh_sculpt_blob": {"asset_name": "Blob", "icon_name": "icon_mesh_sculpt_blob"},
    "mesh_sculpt_clay": {"asset_name": "Clay", "icon_name": "icon_mesh_sculpt_clay"},
    "mesh_sculpt_clay_strips": {"asset_name": "Clay Strips", "icon_name": "icon_mesh_sculpt_clay_strips"},
    "mesh_sculpt_clay_thumb": {"asset_name": "Clay Thumb", "icon_name": "icon_mesh_sculpt_clay_thumb"},
    "mesh_sculpt_crease_polish": {"asset_name": "Crease Polish", "icon_name": "icon_mesh_sculpt_crease"},
    "mesh_sculpt_crease_sharp": {"asset_name": "Crease Sharp", "icon_name": "icon_mesh_sculpt_crease_sharp"},
    "mesh_sculpt_draw": {"asset_name": "Draw", "icon_name": "icon_mesh_sculpt_draw"},
    "mesh_sculpt_draw_sharp": {"asset_name": "Draw Sharp", "icon_name": "icon_mesh_sculpt_draw_sharp"},
    "mesh_sculpt_inflate_deflate": {"asset_name": "Inflate/Deflate", "icon_name": "icon_mesh_sculpt_inflate"},
    "mesh_sculpt_layer": {"asset_name": "Layer", "icon_name": "icon_mesh_sculpt_layer"},
    "mesh_sculpt_fill_deepen": {"asset_name": "Fill/Deepen", "icon_name": "icon_mesh_sculpt_fill"},
    "mesh_sculpt_flatten_contrast": {"asset_name": "Flatten/Contrast", "icon_name": "icon_mesh_sculpt_flatten"},
    "mesh_sculpt_plateau": {"asset_name": "Plateau", "icon_name": "icon_mesh_sculpt_plateau"},
    "mesh_sculpt_scrape_multiplane": {"asset_name": "Scrape Multiplane", "icon_name": "icon_mesh_sculpt_multiplane_scrape"},
    "mesh_sculpt_scrape_fill": {"asset_name": "Scrape/Fill", "icon_name": "icon_mesh_sculpt_scrape"},
    "mesh_sculpt_smooth": {"asset_name": "Smooth", "icon_name": "icon_mesh_sculpt_smooth"},
    "mesh_sculpt_trim": {"asset_name": "Trim", "icon_name": "icon_mesh_sculpt_trim"},
    "mesh_sculpt_boundary": {"asset_name": "Boundary", "icon_name": "icon_mesh_sculpt_boundary"},
    "mesh_sculpt_elastic_grab": {"asset_name": "Elastic Grab", "icon_name": "icon_mesh_sculpt_elastic_grab"},
    "mesh_sculpt_elastic_snake_hook": {"asset_name": "Elastic Snake Hook", "icon_name": "icon_mesh_sculpt_elastic_snake_hook"},
    "mesh_sculpt_grab": {"asset_name": "Grab", "icon_name": "icon_mesh_sculpt_grab"},
    "mesh_sculpt_grab_2d": {"asset_name": "Grab 2D", "icon_name": "icon_mesh_sculpt_grab_2D"},
    "mesh_sculpt_grab_silhouette": {"asset_name": "Grab Silhouette", "icon_name": "icon_mesh_sculpt_grab_silhouette"},
    "mesh_sculpt_nudge": {"asset_name": "Nudge", "icon_name": "icon_mesh_sculpt_nudge"},
    "mesh_sculpt_pinch_magnify": {"asset_name": "Pinch/Magnify", "icon_name": "icon_mesh_sculpt_pinch"},
    "mesh_sculpt_pose": {"asset_name": "Pose", "icon_name": "icon_mesh_sculpt_pose"},
    "mesh_sculpt_pull": {"asset_name": "Pull", "icon_name": "icon_mesh_sculpt_pull"},
    "mesh_sculpt_relax_pinch": {"asset_name": "Relax Pinch", "icon_name": "icon_mesh_sculpt_relax_pinch"},
    "mesh_sculpt_relax_slide": {"asset_name": "Relax Slide", "icon_name": "icon_mesh_sculpt_slide_relax"},
    "mesh_sculpt_snake_hook": {"asset_name": "Snake Hook", "icon_name": "icon_mesh_sculpt_snake_hook"},
    "mesh_sculpt_thumb": {"asset_name": "Thumb", "icon_name": "icon_mesh_sculpt_thumb"},
    "mesh_sculpt_twist": {"asset_name": "Twist", "icon_name": "icon_mesh_sculpt_rotate"},
    "mesh_sculpt_density": {"asset_name": "Density", "icon_name": "icon_mesh_sculpt_simplify"},
    "mesh_sculpt_erase_multires_displacement": {"asset_name": "Erase Multires Displacement", "icon_name": "icon_mesh_sculpt_multires_eraser"},
    "mesh_sculpt_face_set_paint": {"asset_name": "Face Set Paint", "icon_name": "icon_mesh_sculpt_draw_face_set"},
    "mesh_sculpt_mask": {"asset_name": "Mask", "icon_name": "icon_mesh_sculpt_mask"},
    "mesh_sculpt_smear_multires_displacement": {"asset_name": "Smear Multires Displacement", "icon_name": "icon_mesh_sculpt_multires_smear"},
}

class OBJECT_OT_activate_brush(Operator):
    bl_idname = "object.activate_brush"
    bl_label = "Activate Brush"
    # bl_description = "Activate a specific brush from the asset library"
    
    brush_type: bpy.props.StringProperty() # type: ignore
    brush_name: bpy.props.StringProperty()# type: ignore

    @classmethod
    def description(cls, context, properties):
        # Retourne une description dynamique en fonction de la brosse
        return f"Activate the brush: {properties.brush_name}"

    def execute(self, context):
        if self.brush_type in BRUSH_ASSET_PATHS:
            asset_path = BRUSH_ASSET_PATHS[self.brush_type] + self.brush_name
            bpy.ops.brush.asset_activate(
                asset_library_type='ESSENTIALS',
                asset_library_identifier="",
                relative_asset_identifier=asset_path
            )
            # self.report({'INFO'}, f"Brush: {self.brush_name}"+" Active")
            return {'FINISHED'}
        else:
            self.report({'WARNING'}, "Brush type not found.")
            return {'CANCELLED'}

class BPM_OT_switch_smooth_brush(Operator):
    bl_idname = "sculpt.bpm_switch_smooth_brush"
    bl_label = "Switch to Smooth Brush"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Switch between active brush and smooth brush in sculpt mode"

    def execute(self, context):
        if context.mode != 'SCULPT':
            self.report({'WARNING'}, "Must be in sculpt mode")
            return {'CANCELLED'}
        
        sculpt_settings = context.tool_settings.sculpt
        current_brush = sculpt_settings.brush
        speedsculpt = context.scene.speedsculpt
        
        smooth_brush = bpy.data.brushes.get("Smooth")

        # Si la brosse Smooth n'est pas trouvée, essayer de l'activer via better_pie_menus
        if not smooth_brush:
            # Utiliser l'opérateur de better_pie_menus pour activer la brosse Smooth
            bpy.ops.object.activate_brush(
                brush_type="mesh_sculpt",
                brush_name="Smooth"
            )
            # Vérifier si la brosse est maintenant disponible
            smooth_brush = bpy.data.brushes.get("Smooth")
            if smooth_brush:
                self.report({'INFO'}, "Smooth brush activated from asset library.")
            else:
                self.report({'ERROR'}, "Smooth brush not found. Please ensure 'Smooth' brush exists in assets.")
                return {'CANCELLED'}

        if not speedsculpt.previous_brush_name:
            # Première utilisation - sauvegarder la brosse actuelle
            speedsculpt.previous_brush_name = current_brush.name
            speedsculpt.previous_brush_type = current_brush.sculpt_tool
            
            # Basculer vers la brosse smooth en utilisant l'opérateur de better_pie_menus
            bpy.ops.object.activate_brush(
                brush_type="mesh_sculpt",
                brush_name="Smooth"
            )
            self.report({'INFO'}, f"Switched to Smooth brush (saved: {speedsculpt.previous_brush_name})")
        else:
            # Deuxième utilisation - restaurer la brosse précédente
            previous_brush_name = speedsculpt.previous_brush_name
            previous_brush = bpy.data.brushes.get(previous_brush_name)
            
            if previous_brush:
                # Utiliser l'opérateur pour activer la brosse précédente
                # Chercher le type de brosse dans le dictionnaire
                brush_type = None
                for brush_key, brush_info in mesh_sculpt_brushes_dic.items():
                    if brush_info["asset_name"] == previous_brush_name:
                        brush_type = "mesh_sculpt"
                        break
                
                if brush_type:
                    bpy.ops.object.activate_brush(
                        brush_type=brush_type,
                        brush_name=previous_brush_name
                    )
                else:
                    # Si on ne trouve pas le type, essayer de l'assigner directement
                    try:
                        sculpt_settings.brush = previous_brush
                    except:
                        # Si ça ne marche pas, utiliser smooth
                        bpy.ops.object.activate_brush(
                            brush_type="mesh_sculpt",
                            brush_name="Smooth"
                        )
                
                # Nettoyer les propriétés sauvegardées
                speedsculpt.previous_brush_name = ""
                speedsculpt.previous_brush_type = ""
                self.report({'INFO'}, f"Restored to {previous_brush_name}")
            else:
                # Si la brosse précédente n'existe plus, nettoyer et utiliser smooth
                speedsculpt.previous_brush_name = ""
                speedsculpt.previous_brush_type = ""
                bpy.ops.object.activate_brush(
                    brush_type="mesh_sculpt",
                    brush_name="Smooth"
                )
                self.report({'INFO'}, "Previous brush not found, switched to Smooth")
        
        return {'FINISHED'}

# BACKUP SYSTEM
class SPEEDSCULPT_UL_backups_list(bpy.types.UIList):
    """UIList pour afficher les backups"""
    
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        icons = load_icons()
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row()
            row.scale_y = 1.2
            # Icône de backup
            icon = icons.get("icon_backup_mesh")
            row.label(text="", icon_value=icon.icon_id)
            
            # Nom du backup (sans timestamp)
            row.label(text=item.name)

            # Boutons d'action
            # Bouton pour appliquer le backup
            icon = icons.get("icon_valid")
            op = row.operator("object.speedsculpt_apply_backup_by_index", text="", icon_value=icon.icon_id, emboss=False)
            op.backup_index = index

            icon = icons.get("icon_mesh")
            op = row.operator("object.speedsculpt_create_mesh_from_backup", text="", icon_value=icon.icon_id, emboss=False)
            op.backup_index = index
            
            # Bouton pour supprimer le backup
            icon = icons.get("icon_trash")
            op = row.operator("object.speedsculpt_delete_backup_by_index", text="", icon_value=icon.icon_id, emboss=False)
            op.backup_index = index

class SPEEDSCULPT_OT_create_backup(Operator):
    bl_idname = "object.speedsculpt_create_backup"
    bl_label = "Backup to List"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Create a backup of the active object and add it to the list\n\n" \
        "The Backups are in the scene and not visible in the outliner\n\n" \
        "You can apply the backup to the active object by clicking on the Apply Backup button in the list\n" \
        "You can add back the backup to the scene by clicking on the Mesh icon\n" \
        "You can delete the backup by clicking on the Trash icon\n" \
        "You can clear all backups by clicking on the Trash icon next to Backup to List\n\n" \
        "You can clear all backups in the scene by clicking on the Trash icon below the list"

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        
        if not obj.data:
            self.report({'WARNING'}, "Object has no data to backup")
            return {'CANCELLED'}
        
        # Sauvegarder le mode actuel
        current_mode = obj.mode
        if current_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Créer une copie de l'objet
        obj_copy = obj.copy()
        obj_copy.data = obj.data.copy()
        
        # Générer un nom unique pour le backup avec compteur séquentiel
        import uuid
        
        # Obtenir les backups de cet objet spécifique
        backups = obj.unified_object_backup.backups  # CORRECTION ICI
        backup_number = len(backups) + 1
        
        # Trouver le prochain numéro disponible
        while True:
            backup_name = f"Backup_{backup_number:03d}"
            # Vérifier si ce nom existe déjà pour cet objet
            name_exists = any(item.name == backup_name for item in backups)
            if not name_exists:
                break
            backup_number += 1
        
        # Nommer l'objet copié avec le nom original + _backup_XXX
        backup_obj_name = f"{obj.name}_backup_{backup_number:03d}"
        obj_copy.name = backup_obj_name
        
        backup_id = str(uuid.uuid4())  # Identifiant unique
        
        # Créer l'item de backup
        backup_item = obj.unified_object_backup.backups.add()  # CORRECTION ICI
        backup_item.name = backup_name
        backup_item.timestamp = backup_name
        backup_item.object_data = obj_copy.data
        backup_item.object_name = obj.name
        backup_item.backup_id = backup_id
        
        # Supprimer l'objet copié mais garder ses données
        bpy.data.objects.remove(obj_copy, do_unlink=True)
        
        # S'assurer que les données sont en fake user pour ne pas être perdues
        if backup_item.object_data:
            backup_item.object_data.use_fake_user = True
            # Nommer aussi les données de mesh pour les retrouver dans l'outliner
            backup_item.object_data.name = backup_obj_name
        
        # Mettre à jour l'index pour sélectionner le nouveau backup
        obj.unified_object_backup.active_backup_index = len(obj.unified_object_backup.backups) - 1  # CORRECTION ICI
        
        # Restaurer le mode
        if current_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=current_mode)
        
        self.report({'INFO'}, f"Backup created: {backup_name}")
        return {'FINISHED'}

class SPEEDSCULPT_OT_apply_backup_by_index(Operator):
    bl_idname = "object.speedsculpt_apply_backup_by_index"
    bl_label = "Apply Backup"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply backup to active object"

    backup_index: IntProperty(default=0) # type: ignore

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        
        backups = obj.unified_object_backup.backups
        
        if self.backup_index < 0 or self.backup_index >= len(backups):
            self.report({'ERROR'}, "Invalid backup index")
            return {'CANCELLED'}
        
        backup_item = backups[self.backup_index]
        
        if not backup_item.object_data:
            self.report({'ERROR'}, "Backup data is missing")
            return {'CANCELLED'}
        
        # Sauvegarder le mode actuel
        current_mode = obj.mode
        if current_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        try:
            # Créer une copie des données de backup
            backup_mesh = backup_item.object_data.copy()
            
            # Remplacer les données de l'objet actif
            old_mesh = obj.data
            obj.data = backup_mesh
            
            # Supprimer l'ancien mesh s'il n'est plus utilisé
            if old_mesh.users == 0:
                bpy.data.meshes.remove(old_mesh, do_unlink=True)
            
            # Mettre à jour l'index actif du backup
            obj.unified_object_backup.active_backup_index = self.backup_index
            
            # Restaurer le mode
            if current_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=current_mode)
            
            self.report({'INFO'}, f"Backup applied: {backup_item.name}")
            return {'FINISHED'}
            
        except Exception as e:
            # Restaurer le mode en cas d'erreur
            if current_mode != 'OBJECT':
                bpy.ops.object.mode_set(mode=current_mode)
            
            self.report({'ERROR'}, f"Failed to apply backup: {str(e)}")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_delete_backup_by_index(Operator):
    bl_idname = "object.speedsculpt_delete_backup_by_index"
    bl_label = "Delete Backup"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Delete backup"

    backup_index: IntProperty(default=0) # type: ignore

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        
        backups = obj.unified_object_backup.backups  # CORRECTION ICI
        
        if self.backup_index < 0 or self.backup_index >= len(backups):
            self.report({'ERROR'}, "Invalid backup index")
            return {'CANCELLED'}
        
        backup_item = backups[self.backup_index]
        
        # Supprimer les données de mesh associées
        if backup_item.object_data:
            bpy.data.meshes.remove(backup_item.object_data, do_unlink=True)
        
        # Supprimer l'item de backup
        backups.remove(self.backup_index)
        
        # Ajuster l'index actif si nécessaire
        if len(backups) > 0:
            if obj.unified_object_backup.active_backup_index >= len(backups):
                obj.unified_object_backup.active_backup_index = len(backups) - 1
        else:
            obj.unified_object_backup.active_backup_index = 0
        
        self.report({'INFO'}, f"Backup deleted")
        return {'FINISHED'}

class SPEEDSCULPT_OT_clear_all_backups(Operator):
    bl_idname = "object.speedsculpt_clear_all_backups"
    bl_label = "Clear All Backups"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Delete all backups in the list"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        
        backups = obj.unified_object_backup.backups  # CORRECTION ICI
        
        # Supprimer toutes les données de mesh associées
        for backup_item in backups:
            if backup_item.object_data:
                bpy.data.meshes.remove(backup_item.object_data, do_unlink=True)
        
        # Vider la collection de backups
        backups.clear()
        
        # Réinitialiser l'index actif
        obj.unified_object_backup.active_backup_index = 0
        
        self.report({'INFO'}, "All backups cleared")
        return {'FINISHED'}

class SPEEDSCULPT_OT_clear_all_scene_backups(Operator):
    bl_idname = "object.speedsculpt_clear_all_scene_backups"
    bl_label = "Clear All Scene Backups"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Delete all backups from all objects in the scene"

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        total_backups_cleared = 0
        
        # Parcourir tous les objets de la scène
        for obj in scene.objects:
            if hasattr(obj, 'unified_object_backup'):
                backups = obj.unified_object_backup.backups
                
                # Supprimer toutes les données de mesh associées
                for backup_item in backups:
                    if backup_item.object_data:
                        bpy.data.meshes.remove(backup_item.object_data, do_unlink=True)
                        total_backups_cleared += 1
                
                # Vider la collection de backups
                backups.clear()
                
                # Réinitialiser l'index actif
                obj.unified_object_backup.active_backup_index = 0
        
        if total_backups_cleared > 0:
            self.report({'INFO'}, f"Cleared {total_backups_cleared} backups from all objects")
        else:
            self.report({'INFO'}, "No backups found in the scene")
        
        return {'FINISHED'}

class SPEEDSCULPT_OT_create_mesh_from_backup(Operator):
    bl_idname = "object.speedsculpt_create_mesh_from_backup"
    bl_label = "Create Mesh from Backup"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Create a new mesh object from the selected backup"

    backup_index: IntProperty(default=0) # type: ignore

    def execute(self, context):
        obj = context.active_object
        # current_mode = obj.mode

        if obj.mode !='OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        
        backups = obj.unified_object_backup.backups
        
        if self.backup_index < 0 or self.backup_index >= len(backups):
            self.report({'ERROR'}, "Invalid backup index")
            return {'CANCELLED'}
        
        backup_item = backups[self.backup_index]
        if not backup_item.object_data:
            self.report({'ERROR'}, "Backup data is missing")
            return {'CANCELLED'}
        
        try:
            # Créer une copie des données de backup
            backup_mesh = backup_item.object_data.copy()
            
            # Créer un nouvel objet avec ces données
            new_obj = bpy.data.objects.new(name=backup_item.name, object_data=backup_mesh)
            new_obj.name = backup_mesh.name
            
            # Copier la transformation de l'objet original
            new_obj.location = obj.location.copy()
            new_obj.rotation_euler = obj.rotation_euler.copy()
            new_obj.scale = obj.scale.copy()
            
            # Ajouter l'objet à la collection active
            context.collection.objects.link(new_obj)
            
            # Sélectionner le nouvel objet
            bpy.ops.object.select_all(action='DESELECT')
            new_obj.select_set(True)
            context.view_layer.objects.active = new_obj

            #Restore Mode
            # bpy.ops.object.mode_set(mode=current_mode, toggle=False)
            # Mettre à jour l'index actif du backup
            obj.unified_object_backup.active_backup_index = self.backup_index
            
            self.report({'INFO'}, f"Mesh created from backup: {backup_item.name}")
            return {'FINISHED'}
            
        except Exception as e:
            self.report({'ERROR'}, f"Failed to create mesh from backup: {str(e)}")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_backup_selection(Operator):
    bl_idname = "object.speedsculpt_backup_selection"
    bl_label = "Backup to Collection "
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Copy selected objects to BACKUPS collection"

    def execute(self, context):

        current_mode = context.active_object.mode

        if context.object != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')

        # Get selected objects
        selected_objects = [obj for obj in bpy.context.selected_objects]
        
        if not selected_objects:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}
        
        # Get or create BACKUP collection
        backup_collection = bpy.data.collections.get("BACKUPS")
        if not backup_collection:
            backup_collection = bpy.data.collections.new("BACKUPS")
            bpy.context.scene.collection.children.link(backup_collection)
            backup_collection.hide_viewport = True
        
        copied_count = 0
        # Copy selected objects to BACKUP collection
        for obj in selected_objects:
            # Create a copy of the object
            obj_copy = obj.copy()
            obj_copy.data = obj.data.copy()
            obj_copy.name = obj.name + "_backup"
            
            # Link the copy to BACKUP collection
            backup_collection.objects.link(obj_copy)
            copied_count += 1
        
        bpy.ops.object.select_all(action='DESELECT')
        for obj in selected_objects:
            obj.select_set(True)
            context.view_layer.objects.active = obj
            #Restore Mode
            bpy.ops.object.mode_set(mode=current_mode, toggle=False)
        
        self.report({'INFO'}, f"Copied {copied_count} object(s) to BACKUPS collection")
        return {'FINISHED'}
    
class SPEEDSCULPT_OT_array_curve(Operator):
    bl_idname = "object.speedsculpt_array_curve"
    bl_label = "Array Curve"
    bl_description = "Array selected objects with a curve"
    bl_options = {'REGISTER', 'UNDO'}

    def create_curve(self, context):
        # Crée une courbe Bézier au centre
        bpy.ops.curve.primitive_bezier_curve_add(radius=1, enter_editmode=False, location=(0, 0, 0))
        bpy.ops.object.mode_set(mode='EDIT')
        # On supprime le point pour obtenir une courbe vide
        bpy.ops.curve.delete(type='VERT')
        bpy.ops.object.mode_set(mode='OBJECT')
        # La courbe est visible devant tout
        bpy.context.object.show_in_front = True
        curve = bpy.context.active_object
        return curve

    def create_curve_modifier(self, obj):
        # Ajoute un modificateur de courbe à l'objet donné
        curve_modifier = obj.modifiers.new("Curve", 'CURVE')
        curve_modifier.deform_axis = 'POS_Z'
        curve_modifier.object = self.curve
        curve_modifier.show_on_cage = True
        curve_modifier.show_in_editmode = True
        return curve_modifier

    def create_array_modifier(self, obj):
        # Ajoute un modificateur d'Array à l'objet donné
        array_modifier = obj.modifiers.new("Array Curve", 'ARRAY')
        array_modifier.relative_offset_displace[0] = 0
        array_modifier.relative_offset_displace[2] = 0.4
        array_modifier.fit_type = 'FIT_CURVE'
        array_modifier.curve = self.curve
        array_modifier.show_on_cage = True
        array_modifier.show_in_editmode = True
        return array_modifier

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        cursor_location = context.scene.cursor.location.copy()
        cursor_rotation = context.scene.cursor.rotation_euler.copy()


        selected_objects = [obj for obj in bpy.context.selected_objects]

        # Vérifie si l'objet courbe est visible (si défini)
        if speedsculpt.array_curve_object and not speedsculpt.array_curve_object.visible_get(view_layer=context.view_layer):
            self.report({'WARNING'}, "Curve Object is not visible")
            return {'CANCELLED'}
        
        for obj in selected_objects:
            if not obj.visible_get(view_layer=context.view_layer):
                self.report({'WARNING'}, "Selected object is not visible")
                return {'CANCELLED'}


        if speedsculpt.array_curve_object :
            bpy.ops.object.select_all(action='DESELECT')
            speedsculpt.array_curve_object.select_set(state=True)
            context.view_layer.objects.active = speedsculpt.array_curve_object
            bpy.ops.object.duplicate_move()
            self.act_obj = context.active_object
        
        else:
            if selected_objects:
                bpy.ops.object.duplicate_move()
                self.act_obj = context.active_object

            else:
                bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=4, radius=1)
                self.act_obj = context.active_object
                if prefs.remesh_mesh_smooth_normals:
                    bpy.ops.object.shade_smooth()
                
        bpy.ops.object.location_clear(clear_delta=False)
        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        bpy.ops.view3d.snap_cursor_to_selected()
        bpy.ops.object.select_all(action='DESELECT')

        # Crée la courbe
        self.curve = self.create_curve(context)
        bpy.ops.object.select_all(action='DESELECT')

        # Sélectionne de nouveau l'objet source
        self.act_obj.select_set(state=True)
        context.view_layer.objects.active = self.act_obj

        # Applique les modificateurs
        self.create_array_modifier(self.act_obj)
        self.create_curve_modifier(self.act_obj)

        # Ajoute un miroir si demandé
        if getattr(speedsculpt, "add_mirror", False):
            bpy.ops.object.speedsculpt_add_mirror()
            bpy.ops.object.modifier_move_to_index(modifier="Mirror", index=2)

        # Avec le parenting si activé
        if getattr(speedsculpt, "primitives_parenting", False) and self.act_obj:
            if not context.active_object.parent:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                self.act_obj.select_set(state=False)
                self.curve.select_set(state=True)
                context.view_layer.objects.active = self.curve

        bpy.ops.object.select_all(action='DESELECT')

        # Sélectionne la courbe pour édition
        self.curve.select_set(state=True)
        context.view_layer.objects.active = self.curve
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.wm.tool_set_by_id(name="builtin.draw")

        # CURSOR OU SURFACE suivant le réglage utilisateur
        context.scene.tool_settings.curve_paint_settings.depth_mode = speedsculpt.array_curve_surface_cursor

        

        # Restaure la position du curseur 3D
        context.scene.cursor.location[:] = cursor_location
        context.scene.cursor.rotation_euler[:] = cursor_rotation

        return {'FINISHED'}

class SPEEDSCULPT_OT_remove_array_curve(Operator):
    bl_idname = "object.speedsculpt_remove_array_curve"
    bl_label = "Remove Array Curve"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Remove the Array Curve modifier from the selected object"

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        if not obj.modifiers.get("Array Curve"):
            self.report({'WARNING'}, "No Array Curve modifier found")
            return {'CANCELLED'}
        bpy.ops.object.modifier_remove(modifier="Array Curve")
        bpy.ops.object.modifier_remove(modifier="Curve")
        return {'FINISHED'}

class SPEEDSCULPT_OT_apply_array_curve(Operator):
    bl_idname = "object.speedsculpt_apply_array_curve"
    bl_label = "Apply Array Curve"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Apply the Array Curve modifier to the selected object"

    def execute(self, context):
        obj = context.active_object
        if not obj:
            self.report({'WARNING'}, "No active object")
            return {'CANCELLED'}
        bpy.ops.object.modifier_apply(modifier="Array Curve")
        bpy.ops.object.modifier_apply(modifier="Curve")
        return {'FINISHED'}

class SPEEDSCULPT_OT_toggle_array_curve_visibility(Operator):
    bl_idname = "object.speedsculpt_toggle_array_curve_visibility"
    bl_label = "Toggle Array Curve Visibility"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Toggle the visibility of the Array Curve modifier"


    def execute(self, context):
        obj = context.active_object
        if not obj.modifiers.get("Array Curve"):
            self.report({'WARNING'}, "No Array Curve modifier found")
            return {'CANCELLED'}
        if obj.modifiers.get("Array Curve").show_viewport:
            obj.modifiers.get("Array Curve").show_viewport = False
            obj.modifiers.get("Curve").show_viewport = False
        else:
            obj.modifiers.get("Array Curve").show_viewport = True  
            obj.modifiers.get("Curve").show_viewport = True
        return {'FINISHED'}

class SPEEDSCULPT_OT_connect_array_curve(bpy.types.Operator):
    bl_idname = "object.speedsculpt_connect_array_curve"
    bl_label = "Connect Object to Curve"
    bl_description = "Connect the active object to the selected curve and add Array and Curve modifiers"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Must have 2 objects selected, active must be mesh, another is curve
        sel = context.selected_objects
        if len(sel) != 2:
            self.report({'ERROR'}, "Select exactly two objects: a mesh (active) and a curve.")
            return {'CANCELLED'}
        obj = context.active_object
        bpy.ops.object.location_clear(clear_delta=False)

        
        # Find the curve object in selection
        curve_obj = None
        for o in sel:
            if o.type == 'CURVE' and o != obj:
                curve_obj = o
                break
        if not curve_obj:
            self.report({'ERROR'}, "Select a mesh and a curve (the curve must not be active).")
            return {'CANCELLED'}
        # Add Array modifier if not present
        if not obj.modifiers.get("Array Curve"):
            mod_array = obj.modifiers.new(name="Array Curve", type='ARRAY')
            mod_array.fit_type = 'FIT_CURVE'
            mod_array.curve = curve_obj
            mod_array.use_merge_vertices = True
            mod_array.use_relative_offset = True
            mod_array.relative_offset_displace[0] = 0.0
            mod_array.relative_offset_displace[1] = 0.0
            mod_array.relative_offset_displace[2] = 0.4
        # Add Curve modifier if not present
        if not obj.modifiers.get("Curve"):
            mod_curve = obj.modifiers.new(name="Curve", type='CURVE')
            mod_curve.object = curve_obj
            mod_curve.deform_axis = 'POS_Z'
        self.report({'INFO'}, "Array and Curve modifiers added/configured.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_toggle_flat_shading(bpy.types.Operator):
    """Toggle display Flat Shading and return to previous mode"""
    bl_idname = "object.speedsculpt_toggle_flat_shading"
    bl_label = "Toggle Flat Shading"
    bl_description = "Toggle the 3D viewport between current shading and flat shading, restoring previous state on next use"
    bl_options = {'REGISTER', 'UNDO'}

    # Static attribute to store previous shading settings per viewport
    # Key: area pointer as string, Value: dict of settings
    _prev_shading = {}

    @classmethod
    def poll(cls, context):
        # Operator available only in 3D viewports
        return context.area and context.area.type == 'VIEW_3D' and context.space_data

    def execute(self, context):
        prefs = get_addon_preferences()
        
        # Use the active area and space_data directly from context
        if not context.area or context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "No active 3D Viewport found")
            return {'CANCELLED'}
        
        if not context.space_data or context.space_data.type != 'VIEW_3D':
            self.report({'WARNING'}, "No VIEW_3D space found")
            return {'CANCELLED'}

        space = context.space_data
        shading = space.shading

        # Create a stable key for this viewport
        # Using area's as_pointer() which is stable for the lifetime of the area
        key = str(context.area.as_pointer())

        # Check if we are currently in flat shading mode
        # by checking ONLY the viewport state (not the stored key)
        is_flat = (shading.type == 'SOLID' and shading.light == 'FLAT')

        if not is_flat:
            # We are NOT in flat mode, so enable it
            # Store only the settings we're going to modify
            SPEEDSCULPT_OT_toggle_flat_shading._prev_shading[key] = {
                'type': shading.type,
                'light': shading.light,
                'color_type': shading.color_type,
                'single_color': tuple(shading.single_color),
                'background_type': shading.background_type,
                'background_color': tuple(shading.background_color),
                'show_cavity': shading.show_cavity,
                'show_shadows': shading.show_shadows,
                'show_xray': shading.show_xray,
                'use_dof': shading.use_dof,
                'show_backface_culling': shading.show_backface_culling,
                'show_object_outline': shading.show_object_outline,
                'show_overlays': space.overlay.show_overlays if hasattr(space, 'overlay') else None
            }
            
            # Apply flat shading
            shading.type = 'SOLID'
            shading.light = 'FLAT'
            
            # Disable visual effects in flat mode
            shading.show_cavity = False
            shading.show_shadows = False
            shading.show_xray = False
            shading.use_dof = False
            shading.show_backface_culling = False
            shading.show_object_outline = False
            
            # Apply color type from preferences
            shading.color_type = prefs.flat_shading_color_type
            
            # Apply custom color if requested
            if prefs.flat_shading_color_type == 'SINGLE':
                shading.single_color = prefs.flat_shading_custom_color
            
            # Toggle overlays if requested
            if prefs.flat_shading_toggle_overlays and hasattr(space, 'overlay'):
                space.overlay.show_overlays = False

            # Apply background color if requested
            if prefs.flat_shading_use_background_color:
                shading.background_type = 'VIEWPORT'
                shading.background_color = prefs.flat_shading_background_color
            
            self.report({'INFO'}, "Flat shading enabled")
        else:
            # We ARE in flat mode, so disable it
            # Check if we have stored settings for this viewport
            prev = SPEEDSCULPT_OT_toggle_flat_shading._prev_shading.get(key)
            if prev:
                # We have stored settings, restore them
                try:
                    shading.type = prev['type']
                    shading.light = prev['light']
                    shading.color_type = prev['color_type']
                    shading.single_color = prev['single_color']
                    shading.background_type = prev['background_type']
                    shading.background_color = prev['background_color']
                    shading.show_cavity = prev['show_cavity']
                    shading.show_shadows = prev['show_shadows']
                    shading.show_xray = prev['show_xray']
                    shading.use_dof = prev['use_dof']
                    shading.show_backface_culling = prev['show_backface_culling']
                    shading.show_object_outline = prev['show_object_outline']
                    if prev['show_overlays'] is not None and hasattr(space, 'overlay'):
                        space.overlay.show_overlays = prev['show_overlays']
                except Exception as e:
                    self.report({'WARNING'}, f"Could not restore some properties: {str(e)}")
                
                # Remove the stored state for this viewport after restoring
                del SPEEDSCULPT_OT_toggle_flat_shading._prev_shading[key]
                self.report({'INFO'}, "Previous shading restored")
            else:
                # No stored settings found (viewport was split or settings lost)
                # Apply safe default settings instead
                shading.type = 'SOLID'
                shading.light = 'MATCAP'
                shading.color_type = 'MATERIAL'
                shading.background_type = 'THEME'
                
                # Restore overlays if they were toggled
                if prefs.flat_shading_toggle_overlays and hasattr(space, 'overlay'):
                    space.overlay.show_overlays = True
                
                self.report({'INFO'}, "Restored to default shading (viewport was split or settings lost)")

        return {'FINISHED'}

# MULTI-OBJECT SCULPTING OPERATORS
class SPEEDSCULPT_OT_prepare_multi_sculpt(Operator):
    bl_idname = 'object.speedsculpt_prepare_multi_sculpt'
    bl_label = "Prepare Multi-Object Sculpt"
    bl_description = "Prepare selected objects for sculpting as a single combined mesh"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.selected_objects and all(obj.type == 'MESH' for obj in context.selected_objects)

    def execute(self, context):
        import uuid
        
        # Generate unique ID for this sculpt session
        sculpt_id = str(uuid.uuid4())
        
        selected_objects = list(context.selected_objects)
        active_obj = context.active_object
        
        # IMPORTANT: Apply all transforms on original objects first
        # This bakes location/rotation/scale into the mesh geometry
        for obj in selected_objects:
            obj.select_set(True)
        context.view_layer.objects.active = selected_objects[0]
        
        # Apply all transforms (location, rotation, scale)
        bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
        
        # Store original objects with custom property
        for i, obj in enumerate(selected_objects):
            obj["speedsculpt_multi_sculpt_id"] = sculpt_id
            obj["speedsculpt_multi_sculpt_index"] = i
        
        # Create temporary collection
        temp_collection_name = f"SPEEDSCULPT_TEMP_{sculpt_id[:8]}"
        if temp_collection_name not in bpy.data.collections:
            temp_collection = bpy.data.collections.new(temp_collection_name)
            context.scene.collection.children.link(temp_collection)
        else:
            temp_collection = bpy.data.collections[temp_collection_name]
        
        # Store collection name in scene
        context.scene["speedsculpt_temp_collection"] = temp_collection_name
        
        # Duplicate objects
        duplicated_objects = []
        for obj in selected_objects:
            obj_copy = obj.copy()
            obj_copy.data = obj.data.copy()
            obj_copy.name = obj.name + "_sculpt"
            
            # Link to temp collection
            temp_collection.objects.link(obj_copy)
            duplicated_objects.append(obj_copy)
            
            # Remove mirror modifiers from the copy
            modifiers_to_remove = [mod for mod in obj_copy.modifiers if mod.type == 'MIRROR']
            for mod in modifiers_to_remove:
                obj_copy.modifiers.remove(mod)
        
        # Hide original objects in viewport
        for obj in selected_objects:
            obj.hide_viewport = True
        
        # Deselect all and select duplicated objects
        bpy.ops.object.select_all(action='DESELECT')
        for obj in duplicated_objects:
            obj.select_set(True)
        
        # Set active object
        context.view_layer.objects.active = duplicated_objects[0]
        
        # Join all objects into one
        if len(duplicated_objects) > 1:
            bpy.ops.object.join()
        
        # Get the combined object
        combined_obj = context.active_object
        combined_obj.name = f"SCULPT_COMBINED_{sculpt_id[:8]}"
        combined_obj["speedsculpt_combined_id"] = sculpt_id
        
        # Now we can safely set origin to geometry center
        # Since transforms are applied, this won't move the geometry
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
        
        self.report({'INFO'}, f"Prepared {len(selected_objects)} objects for multi-sculpting")
        return {'FINISHED'}

class SPEEDSCULPT_OT_apply_multi_sculpt(Operator):
    bl_idname = 'object.speedsculpt_apply_multi_sculpt'
    bl_label = "Apply Multi-Object Sculpt"
    bl_description = "Apply sculpting modifications back to original objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.get("speedsculpt_combined_id")

    def execute(self, context):
        import mathutils
        
        combined_obj = context.active_object
        sculpt_id = combined_obj.get("speedsculpt_combined_id")
        
        if not sculpt_id:
            self.report({'ERROR'}, "Active object is not a multi-sculpt combined object")
            return {'CANCELLED'}
        
        # Find original objects - EXCLUDE the combined object itself!
        original_objects = [obj for obj in bpy.data.objects 
                        if obj.get("speedsculpt_multi_sculpt_id") == sculpt_id 
                        and not obj.get("speedsculpt_combined_id")]  # <-- IMPORTANT: exclude combined object
        
        if not original_objects:
            self.report({'ERROR'}, "Original objects not found")
            return {'CANCELLED'}
        
        # Sort by index to maintain order
        original_objects.sort(key=lambda obj: obj.get("speedsculpt_multi_sculpt_index", 0))
        
        # Make sure we're in object mode
        if context.mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        # Ensure combined object is selected and active
        bpy.ops.object.select_all(action='DESELECT')
        combined_obj.select_set(True)
        context.view_layer.objects.active = combined_obj
        
        # Separate by loose parts
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.separate(type='LOOSE')
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Get all separated objects (they should all be selected now)
        separated_objects = [obj for obj in context.selected_objects if obj.type == 'MESH']
        
        # Apply transforms on separated objects to bake their position
        # This ensures the geometry is at the right place in world space
        for sep_obj in separated_objects:
            sep_obj.select_set(True)
        if separated_objects:
            context.view_layer.objects.active = separated_objects[0]
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            
        print(f"Found {len(separated_objects)} separated objects")
        print(f"Need to match with {len(original_objects)} original objects")
        
        # Function to get object info for matching
        def get_object_info(obj):
            # Calculate bounding box center in world space
            bbox_center = sum((mathutils.Vector(b) for b in obj.bound_box), mathutils.Vector()) / 8
            bbox_center = obj.matrix_world @ bbox_center
            
            # Calculate approximate volume
            dimensions = obj.dimensions
            volume = dimensions.x * dimensions.y * dimensions.z
            
            return bbox_center, volume
        
        # Match objects - find best match for each original
        matched_pairs = []
        used_separated = set()
        
        for orig_obj in original_objects:
            orig_center, orig_volume = get_object_info(orig_obj)
            
            best_match = None
            best_score = float('inf')
            
            for sep_obj in separated_objects:
                if sep_obj in used_separated:
                    continue
                    
                sep_center, sep_volume = get_object_info(sep_obj)
                
                # Score based on distance and volume similarity
                distance = (orig_center - sep_center).length
                volume_diff = abs(orig_volume - sep_volume) / max(orig_volume, 0.001)
                score = distance + volume_diff * 10
                
                if score < best_score:
                    best_score = score
                    best_match = sep_obj
            
            if best_match:
                matched_pairs.append((orig_obj, best_match))
                used_separated.add(best_match)
                print(f"Matched {orig_obj.name} with {best_match.name} (score: {best_score:.3f})")
            else:
                print(f"WARNING: No match found for {orig_obj.name}")
        
        # Deselect all before applying
        bpy.ops.object.select_all(action='DESELECT')
        
        # Apply mesh data to original objects
        updated_count = 0
        objects_to_cleanup = []  # Store objects for cleanup to avoid "StructRNA removed" error
        
        for orig_obj, sep_obj in matched_pairs:
            # Store the old mesh data to delete it later
            old_mesh = orig_obj.data
            
            # Assign new mesh data from separated object
            orig_obj.data = sep_obj.data
            
            # Unhide original object
            orig_obj.hide_viewport = False
            
            # Select original
            orig_obj.select_set(True)
            
            # Store for later cleanup
            objects_to_cleanup.append((orig_obj, old_mesh))
            
            updated_count += 1
        
        # Set the first updated object as active
        if matched_pairs:
            context.view_layer.objects.active = matched_pairs[0][0]
        
        # Clean up old mesh data
        for orig_obj, old_mesh in objects_to_cleanup:
            if old_mesh.users == 0:
                bpy.data.meshes.remove(old_mesh)
        
        # Clean up separated objects (remove them from scene, their mesh data is now used by originals)
        for sep_obj in separated_objects:
            # Only remove if it was matched (its data is now used)
            if sep_obj in used_separated:
                bpy.data.objects.remove(sep_obj, do_unlink=True)
        
        # Clean up original objects' custom properties - use the stored list to avoid accessing deleted objects
        for orig_obj, _ in objects_to_cleanup:
            # Check if object still exists before accessing it
            try:
                if "speedsculpt_multi_sculpt_id" in orig_obj:
                    del orig_obj["speedsculpt_multi_sculpt_id"]
                if "speedsculpt_multi_sculpt_index" in orig_obj:
                    del orig_obj["speedsculpt_multi_sculpt_index"]
                if "speedsculpt_original_loc" in orig_obj:
                    del orig_obj["speedsculpt_original_loc"]
                if "speedsculpt_original_rot" in orig_obj:
                    del orig_obj["speedsculpt_original_rot"]
                if "speedsculpt_original_scale" in orig_obj:
                    del orig_obj["speedsculpt_original_scale"]
            except ReferenceError:
                # Object was deleted, skip
                pass
        
        # Clean up temporary collection
        temp_collection_name = context.scene.get("speedsculpt_temp_collection")
        if temp_collection_name and temp_collection_name in bpy.data.collections:
            temp_collection = bpy.data.collections[temp_collection_name]
            
            # Remove all remaining objects in temp collection
            for obj in list(temp_collection.objects):
                try:
                    bpy.data.objects.remove(obj, do_unlink=True)
                except ReferenceError:
                    # Object already removed
                    pass
            
            # Remove collection
            bpy.data.collections.remove(temp_collection)
            
            # Clean scene property
            if "speedsculpt_temp_collection" in context.scene:
                del context.scene["speedsculpt_temp_collection"]
        
        self.report({'INFO'}, f"Applied multi-sculpt to {updated_count} object(s)")
        return {'FINISHED'}

class SPEEDSCULPT_OT_cancel_multi_sculpt(Operator):
    bl_idname = 'object.speedsculpt_cancel_multi_sculpt'
    bl_label = "Cancel Multi-Object Sculpt"
    bl_description = "Cancel multi-object sculpting and restore original objects"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.get("speedsculpt_combined_id")

    def execute(self, context):
        combined_obj = context.active_object
        sculpt_id = combined_obj.get("speedsculpt_combined_id")
        
        if not sculpt_id:
            self.report({'ERROR'}, "Active object is not a multi-sculpt combined object")
            return {'CANCELLED'}
        
        # Find and unhide original objects
        original_objects = [obj for obj in bpy.data.objects 
                           if obj.get("speedsculpt_multi_sculpt_id") == sculpt_id]
        
        for obj in original_objects:
            obj.hide_viewport = False
            obj.select_set(True)
            
            # Clean up custom properties
            if "speedsculpt_multi_sculpt_id" in obj:
                del obj["speedsculpt_multi_sculpt_id"]
            if "speedsculpt_multi_sculpt_index" in obj:
                del obj["speedsculpt_multi_sculpt_index"]
            if "speedsculpt_original_loc" in obj:
                del obj["speedsculpt_original_loc"]
            if "speedsculpt_original_rot" in obj:
                del obj["speedsculpt_original_rot"]
            if "speedsculpt_original_scale" in obj:
                del obj["speedsculpt_original_scale"]
        
        # Clean up temporary collection
        temp_collection_name = context.scene.get("speedsculpt_temp_collection")
        if temp_collection_name and temp_collection_name in bpy.data.collections:
            temp_collection = bpy.data.collections[temp_collection_name]
            
            # Remove all objects in temp collection
            for obj in list(temp_collection.objects):
                bpy.data.objects.remove(obj, do_unlink=True)
            
            # Remove collection
            bpy.data.collections.remove(temp_collection)
            
            # Clean scene property
            if "speedsculpt_temp_collection" in context.scene:
                del context.scene["speedsculpt_temp_collection"]
        
        self.report({'INFO'}, "Cancelled multi-sculpt session")
        return {'FINISHED'}

def generic_copy(source, target, string=""):
    """Copy attributes from source to target that have string in them"""
    for attr in dir(source):
        if attr.find(string) > -1:
            try:
                setattr(target, attr, getattr(source, attr))
            except:
                pass
    return

class SPEEDSCULPT_OT_copy_active_data_to_selection(Operator):
    bl_idname = "object.speedsculpt_copy_active_data_to_selection"
    bl_label = "Copy Active Object Data to Selection"
    bl_description = "Copy active object data to the selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    make_single_user: BoolProperty(
        name="Make Single User",
        description="Make all selected objects' data single-user before copying",
        default=False
    )
    copy_materials: BoolProperty(
        name="Copy Materials",
        description="Copy materials to the selected objects",
        default=False
    )
    copy_modifiers: BoolProperty(
        name="Copy Modifiers",
        description="Copy modifiers to the selected objects",
        default=False
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=200)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "make_single_user")
        layout.prop(self, "copy_materials")
        layout.prop(self, "copy_modifiers")

    def execute(self, context):
        import bpy
        active = context.active_object
        sel_objs = [obj for obj in context.selected_objects if obj != active]

        if not active or not sel_objs:
            self.report({'WARNING'}, "Need active object and an additional selection!")
            return {'CANCELLED'}

        # Save original selection to restore later
        original_selection = [obj for obj in context.selected_objects]
        original_active = context.view_layer.objects.active

    
        # Now iterate and copy data/materials/modifiers as requested
        for obj in sel_objs:
            # Copy the datablock reference, if compatible
            if active.type == obj.type and hasattr(obj, "data") and hasattr(active, "data"):
                obj.data = active.data

            # Copy materials
            if self.copy_materials and hasattr(active.data, "materials") and hasattr(obj.data, "materials"):
                bpy.ops.object.make_links_data(type='MATERIAL')


            # Copy modifiers, skip those referencing objects (ARMATURE, etc.)
            if self.copy_modifiers:
                # Clear all current modifiers
                for mod in list(obj.modifiers):
                    obj.modifiers.remove(mod)
                for mod in active.modifiers:
                    # Don't duplicate those that reference external objects
                    if hasattr(mod, "object") and mod.object:
                        continue
                    new_mod = obj.modifiers.new(type=mod.type, name=mod.name)
                    generic_copy(mod, new_mod)
        
        # If any options are enabled, set selection and run the corresponding operator for all selection
        if self.make_single_user or self.copy_materials or self.copy_modifiers:
            # Deselect all
            bpy.ops.object.select_all(action='DESELECT')
            # Select all selection (including active)
            for obj in sel_objs:
                obj.select_set(True)
            active.select_set(True)
            context.view_layer.objects.active = active

            # Apply make single user if requested (without materials if not checked)
            if self.make_single_user:
                bpy.ops.object.make_single_user(
                    object=True,
                    obdata=True,
                    material=self.copy_materials,
                    animation=False,
                    obdata_animation=False
                )

            # Restore selection 
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selection:
                obj.select_set(True)
            context.view_layer.objects.active = original_active

        # Feedback
        info_msgs = []
        if self.make_single_user:
            info_msgs.append(f"copied data from '{active.name}' and made single user to {len(sel_objs)} object(s)")
        elif self.copy_materials:
            info_msgs.append(f"copied data from '{active.name}' and copied materials to {len(sel_objs)} object(s)")
        if self.copy_modifiers:
            info_msgs.append(f"copied data from '{active.name}' and copied modifiers to {len(sel_objs)} object(s)")
        for msg in info_msgs:
            self.report({'INFO'}, msg)

        return {'FINISHED'}
    
class SPEEDSCULPT_OT_create_group_from_selection(Operator):
    bl_idname = "object.speedsculpt_create_group_from_selection"
    bl_label = "Create Group"
    bl_description = "Create a new group from the selected objects\n\nthe origin of the group will be at the center of the scene"
    bl_options = {'REGISTER', 'UNDO'}

    group_name: StringProperty(
        name="Group Name",
        description="Name of the new group",
        default="Group"
    )# type: ignore

    group_type: EnumProperty(
            items=(("EMPTY","Empty","", "OUTLINER_OB_EMPTY", 1),
                   ("MESH", "Mesh","", "OUTLINER_OB_MESH", 2)),
                   default="EMPTY",
                   description="Group type") # type: ignore

    origin: EnumProperty(
            items=(("Selection", "Selection","", "OBJECT_HIDDEN", 1),
                   ("Cursor","Cursor","", "PIVOT_CURSOR", 2),
                   ("Origin","Origin","", "GRID", 3)),
                   default="Selection",
                   description="Origin of the Group") # type: ignore

    move_to_center: BoolProperty(
            name="Move To Center",
            default=False,
            description="Move the Group to the Center of the Scene") # type: ignore

    origin_to_bottom: BoolProperty(
            name="Origin to Bottom",
            default=False,
            description="Origin of the Group to the bottom of the selection") # type: ignore

    empty_type : EnumProperty(
            items=(("PLAIN_AXES", "Plain Axe","","EMPTY_AXIS", 1),
                   ("ARROWS","Arrows", "", "EMPTY_ARROWS", 2),
                   ("SINGLE_ARROW","Single Arrow","","EMPTY_SINGLE_ARROW", 3),
                   ("CIRCLE","Circle","","MESH_CIRCLE", 4),
                   ("CUBE","Cube","","CUBE", 5),
                   ("SPHERE","Sphere","","SPHERE", 6),
                   ("CONE","Cone","","CONE", 7)),
                   default="PLAIN_AXES",
                   description="Empty Type") # type: ignore
    
    empty_size: FloatProperty(
            name="Name",
            default=True,
            min=0.01, max=100,
            description="Empty size") # type: ignore

    bound_bottom: BoolProperty(
            name="Bound Bottom",
            default=False,
            description="Bound the Bottom of the Group") # type: ignore

    @classmethod
    def poll(cls, context):
        return context.selected_objects and context.mode == 'OBJECT'

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=250, title="")

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = True

        row = layout.row()
        row.prop(self, "group_type", expand=True, text= "Group Type")

        if self.group_type == 'EMPTY':
            row = layout.row()
            row.prop(self, "empty_type",text= "Type")
            row = layout.row()
            row.prop(self, "empty_size", text= "Size")


        row = layout.row()
        row.grid_flow(columns=3, align=True).prop(self, "origin", text="Origin")

        if self.origin == 'Selection':
            layout.prop(self, "origin_to_bottom", text="Origin To Bottom")
            
            selected_objects = context.selected_objects.copy()
            if self.bound_bottom:
                for obj in selected_objects:
                    if obj.children:
                        layout.prop(self, "bound_bottom", text="Children Bound Bottom")

            layout.prop(self, "move_to_center", text="Group To Center")

        layout.prop(self, "group_name", text="Name")

    def execute(self, context):
        # Sauvegarder la sélection actuelle
        selected_objects = context.selected_objects.copy()
        cursor_location = context.scene.cursor.location.copy()

        if self.origin == 'Selection':
            bpy.ops.view3d.snap_cursor_to_selected()

        elif self.origin == 'Origin':
            context.scene.cursor.location[1] = 0
            context.scene.cursor.location[2] = 0
            context.scene.cursor.location[0] = 0
        
        # Désélectionner tous les objets
        bpy.ops.object.select_all(action='DESELECT')

        if self.group_type == 'MESH':
            bpy.ops.mesh.primitive_cube_add(size=2, enter_editmode=True, align='WORLD')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.delete(type='FACE')
            bpy.ops.object.mode_set(mode='OBJECT')
        
        elif self.group_type == 'EMPTY':
            bpy.ops.object.empty_add(type=self.empty_type, radius=self.empty_size, align='WORLD', scale=(1, 1, 1))

        new_object = context.active_object
        new_object.name = self.group_name
        if new_object.type == 'MESH':
            new_object.data.name = self.group_name
        new_object["GROUP"] = True

        if self.origin in {'Cursor', 'Origin'}:
            self.origin_to_bottom = False
            self.move_to_center = False

        if self.origin_to_bottom:
            # Collect all objects to consider (including children if bound_bottom is True)
            objects_to_consider = set(selected_objects)
            
            if self.bound_bottom:
                for obj in selected_objects:
                    if obj.children:
                        # Add all children recursively
                        def add_children_recursive(parent):
                            for child in parent.children:
                                objects_to_consider.add(child)
                                add_children_recursive(child)
                        add_children_recursive(obj)

                # Get the bounding box of all objects to consider in global space
            min_z = float('inf')
            for obj in objects_to_consider:
                if obj.type == 'MESH' and obj.data.vertices:
                    # For mesh objects, use actual vertex positions for more accurate bounds
                    for vertex in obj.data.vertices:
                        world_pos = obj.matrix_world @ vertex.co
                        min_z = min(min_z, world_pos.z)
                else:
                    # For non-mesh objects, use bounding box
                    bounds = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
                    obj_min_z = min(corner.z for corner in bounds)
                    min_z = min(min_z, obj_min_z)

            # Set cursor Z to the minimum Z coordinate
            context.scene.cursor.location.z = min_z
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)

        # Désélectionner le nouvel objet
        bpy.ops.object.select_all(action='DESELECT')
        
        # Resélectionner les objets d'origine
        for obj in selected_objects:
            obj.select_set(True)
        
        # Sélectionner aussi le nouvel objet et le définir comme actif
        new_object.select_set(True)
        context.view_layer.objects.active = new_object
        
        # Parenter les objets sélectionnés au nouvel objet
        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)

    
        bpy.ops.object.select_all(action='DESELECT')
        new_object.select_set(True)
        context.view_layer.objects.active = new_object

        if self.move_to_center:
            bpy.ops.object.location_clear(clear_delta=False)

        context.scene.cursor.location = cursor_location
        
        self.report({'INFO'}, f"Created group '{self.group_name}' with {len(selected_objects)} children")
        return {'FINISHED'}

class SPEEDSCULPT_OT_separate(Operator):
    bl_idname = 'object.speedsculpt_separate'
    bl_label = "Separate/Extract/Duplicate"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Separate/Extract Selection"

    loose_geometry: BoolProperty(
        name="Loose Geometry",
        description="Separate Loose Geometry",
        default=False
    ) # type: ignore

    material: BoolProperty(
        name="Material",
        description="Separate by Material",
        default=False
    ) # type: ignore

    selected: BoolProperty(
        name="Selected",
        description="Separate the selected from the Active Object",
        default=False
    ) # type: ignore

    extract: BoolProperty(
        name="Extract",
        description="Extract the selection to a new Object",
        default=False
    ) # type: ignore

    @classmethod
    def description(cls, context, properties):
        separate_name = "Loose Geometry"
        if properties.extract:
            return f"Extract Selection"
        elif properties.loose_geometry:
            return f"Separate by Loose Geometry Part"
        elif properties.material:
            return f"Separate by Material"
        elif properties.selected:
            return f"Separate the selected from the Active Object"
    

    def execute(self, context):
        obj = context.active_object

        active_object = context.active_object

        if self.material:
            bpy.ops.mesh.separate(type='MATERIAL')

        if self.selected:

            bpy.ops.mesh.separate(type='SELECTED')
            
            
            bpy.ops.object.mode_set(mode='OBJECT', toggle=False)
            new_obj = context.selected_objects[1]
            bpy.ops.object.select_all(action='DESELECT')
            new_obj.select_set(True)
            context.view_layer.objects.active = new_obj

        if self.loose_geometry:
            bpy.ops.mesh.separate(type='LOOSE')

        return {'FINISHED'}


#--------------------------------------------------------------------------------
# PARENTS
#--------------------------------------------------------------------------------
def find_parent(ob, lst):

    lst.append(ob)
    if ob.parent:
        find_parent(ob.parent, lst)

def find_child(ob, lst):
    for x in ob.children:
        lst.append(x)
        find_child(x, lst)

def Last_Parent():
    lst = []  # list for all objects
    find_parent(bpy.context.object, lst)  # find parent
    if len(lst) > 0:

        last_parent = lst[0]
        for p in lst:
            # parent of everything has no parent itself
            if not p.parent: last_parent = p
            bpy.ops.object.select_all(action='DESELECT')
            bpy.context.view_layer.objects.active = last_parent
            last_parent.select_set(state=True)

class SPEEDSCULPT_OT_set_parent(Operator):
    bl_idname = 'object.speedsculpt_set_parent'
    bl_label = "Set Parent"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set The Active Object as Parent for the selection"

    def execute(self, context):
        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
        return {'FINISHED'}

class SPEEDSCULPT_OT_select_parent(Operator):
    bl_idname = 'object.speedsculpt_select_parent'
    bl_label = "Select Parent"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Select The direct Parent for the selection"

    def execute(self, context):
        bpy.ops.object.select_hierarchy(direction='PARENT', extend=False)
        return {'FINISHED'}

class SPEEDSCULPT_OT_select_last_parent(Operator):
    bl_idname = 'object.speedsculpt_select_last_parent'
    bl_label = "Select Last Parent"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Select The Last Parent of the selection"

    def execute(self, context):
        parent_list = []

        for obj in context.selected_objects:
            bpy.ops.object.select_all(action='DESELECT')
            context.view_layer.objects.active = obj
            Last_Parent()

            for obj in context.selected_objects:
                parent_list.append(obj)

        for obj in parent_list:
            context.view_layer.objects.active = obj
            obj.select_set(state=True)


        print("Parent List:", parent_list)
        return {'FINISHED'}

class SPEEDSCULPT_OT_select_hierarchy(Operator):
    bl_idname = "object.speedsculpt_select_hierarchy"
    bl_label = "select hierarchy"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Set The complete Hierarchy of the selection"

    def execute(self, context):
        lst = []  # list for all objects
        find_parent(context.object, lst)  # find parent

        if len(lst) > 0:
            last_parent = lst[0]
            for p in lst:
                # parent of everything has no parent itself
                if not p.parent: last_parent = p

            # find children for each parent
            for c in lst: find_child(c, lst)

            # select all
            for x in lst: x.select_set(state=True)

            # make parent active
            context.view_layer.objects.active = last_parent

        # print(lst)
        # context.space_data.pivot_point = 'ACTIVE_ELEMENT'
        return {'FINISHED'}

class SPEEDSCULPT_OT_select_children(Operator):
    bl_idname = "object.speedsculpt_select_children"
    bl_label = "Select Children"
    bl_description = "Set all the Children of the selection"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Get the active object
        obj = context.object

        # Check if the object has children
        if obj.children:
            # Deselect the parent
            obj.select_set(False)

            # Select all the descendants
            self.select_descendants(obj)

            # Set the first child as the active object
            bpy.context.view_layer.objects.active = obj.children[0]
        else:
            self.report({'INFO'}, "The object has no children.")

        return {'FINISHED'}

    def select_descendants(self, obj):
        for child in obj.children:
            child.select_set(True)
            self.select_descendants(child)

class SPEEDSCULPT_OT_unparent_hierarchy(Operator):
    bl_idname = "object.speedsculpt_unparent_hierarchy"
    bl_label = "Unparent Hierarchy"
    bl_description = "Remove parent from all objects in the hierarchy of selected objects"
    bl_options = {'REGISTER', 'UNDO'}

    keep_transform: BoolProperty(
        name="Keep Transform",
        description="Keep the world transform after unparenting",
        default=True
    ) # type: ignore

    @classmethod
    def poll(cls, context):
        return context.selected_objects and context.mode == 'OBJECT'

    def _collect_hierarchy(self, obj, collected):
        collected.add(obj)
        for child in obj.children:
            self._collect_hierarchy(child, collected)

    def execute(self, context):
        all_objects = set()

        for obj in context.selected_objects:
            root = obj
            while root.parent:
                root = root.parent
            self._collect_hierarchy(root, all_objects)

        unparented = 0
        for obj in all_objects:
            if obj.parent is not None:
                if self.keep_transform:
                    matrix = obj.matrix_world.copy()
                obj.parent = None
                if self.keep_transform:
                    obj.matrix_world = matrix
                unparented += 1

        self.report({'INFO'}, f"Unparented {unparented} object(s)")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "keep_transform")

class SPEEDSCULPT_OT_scale_reduction(Operator):
    bl_idname = "object.speedsculpt_scale_reduction"
    bl_label = "Scale Reduction"
    bl_options = {'REGISTER', 'UNDO'}
    bl_description = "Reduce scale of selected objects using empty parenting technique"

    edit_scale_operation: EnumProperty(
        name="Operation",
        description="Choose the operation to perform",
        items=[
            ('DIVIDE', "Divide", "Divide the current scale by the value"),
            ('MULTIPLY', "Multiply", "Multiply the current scale by the value"),
        ],
        default='DIVIDE'
    )# type: ignore
    
    edit_scale_value: FloatProperty(
        name="Scale Value",
        description="Value to use for the scale operation",
        default=10,
        min=0.00001,
        max=100000.0,
        precision=3
    )# type: ignore

    origin_scale: EnumProperty(
            items=(("Selection", "Selection","", "OBJECT_HIDDEN", 1),
                   ("Cursor","Cursor","", "PIVOT_CURSOR", 2),
                   ("Origin","Origin","", "GRID", 3)),
                   default="Selection",
                   description="Origin of the Group") # type: ignore

    origin_scale_at_bottom: BoolProperty(
            name="Origin Scale at Bottom",
            default=False,
            description="Origin Scale at the bottom of the selection") # type: ignore
    
    @classmethod
    def poll(cls, context):
        
        obj = context.object
        # Vérifier si l'objet a des données partagées (multi-user)
        if obj.data and obj.data.users > 1:
            return False
        
        return True

    def adjust_modifier_values(self, obj, scale_factor):
        """Adjust modifier values to maintain consistency after scale change"""
        for modifier in obj.modifiers:
            if modifier.type == 'BEVEL':
                if hasattr(modifier, 'width'):
                    modifier.width *= scale_factor
                if hasattr(modifier, 'offset_type') and modifier.offset_type == 'WIDTH':
                    modifier.width *= scale_factor
                    
            elif modifier.type == 'SOLIDIFY':
                if hasattr(modifier, 'thickness'):
                    modifier.thickness *= scale_factor
                    
            elif modifier.type == 'ARRAY':
                if hasattr(modifier, 'constant_offset_displace'):
                    modifier.constant_offset_displace *= scale_factor
                if hasattr(modifier, 'relative_offset_displace'):
                    modifier.relative_offset_displace *= scale_factor
                    
            elif modifier.type == 'MIRROR':
                if hasattr(modifier, 'use_clip'):
                    # Mirror doesn't need adjustment for scale
                    pass
                    
            elif modifier.type == 'BOOLEAN':
                # Boolean modifiers don't need scale adjustment
                pass
                
            elif modifier.type == 'SUBSURF':
                # Subdivision surface doesn't need scale adjustment
                pass
                
            elif modifier.type == 'MULTIRES':
                # Multires doesn't need scale adjustment
                pass
                
            elif modifier.type == 'DISPLACE':
                if hasattr(modifier, 'strength'):
                    modifier.strength *= scale_factor
                    
            elif modifier.type == 'SIMPLE_DEFORM':
                if hasattr(modifier, 'deform_method') and modifier.deform_method in ['BEND', 'TAPER', 'STRETCH']:
                    if hasattr(modifier, 'factor'):
                        modifier.factor *= scale_factor
                        
            elif modifier.type == 'LATTICE':
                # Lattice modifier values are relative
                pass
                
            elif modifier.type == 'CAST':
                if hasattr(modifier, 'factor'):
                    modifier.factor *= scale_factor
                    
            elif modifier.type == 'CURVE':
                if hasattr(modifier, 'deform_axis'):
                    # Curve modifier doesn't need scale adjustment
                    pass
                    
            elif modifier.type == 'HOOK':
                if hasattr(modifier, 'strength'):
                    modifier.strength *= scale_factor
                    
            elif modifier.type == 'WAVE':
                if hasattr(modifier, 'height'):
                    modifier.height *= scale_factor
                if hasattr(modifier, 'width'):
                    modifier.width *= scale_factor
                    
            elif modifier.type == 'CLOTH':
                # Cloth simulation parameters might need adjustment
                if hasattr(modifier, 'settings'):
                    if hasattr(modifier.settings, 'quality'):
                        # Adjust quality based on scale
                        pass
                        
            elif modifier.type == 'FLUID':
                # Fluid simulation might need domain resizing
                pass
                
            elif modifier.type == 'SMOKE':
                # Smoke simulation might need domain resizing
                pass
          
    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=250)
    
    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = True
        layout.prop(self, "edit_scale_operation", expand=True)
        layout.prop(self, "edit_scale_value")
        layout.prop(self, "origin_scale")
        layout.prop(self, "origin_scale_at_bottom", text="Origin Scale at Bottom")

    def execute(self, context):
        cursor_location = context.scene.cursor.location.copy()

        # Calculate the scale factor based on operation and value
        if self.edit_scale_operation == 'MULTIPLY':
            scale_factor = self.edit_scale_value
        else:  # DIVIDE
            scale_factor = 1.0 / self.edit_scale_value
        
        # Store original selection
        original_selection = [obj for obj in bpy.context.selected_objects]
        
        if not original_selection:
            self.report({'WARNING'}, "No objects selected")
            return {'CANCELLED'}

        # Check if there's only one object in the scene
        selected_mesh_objects = [obj for obj in original_selection if obj.type == 'MESH']

        if self.origin_scale == 'Selection':
            # Calculer le centre de tous les objets sélectionnés en utilisant les bounds visuels
            all_bounds = []
            for obj in original_selection:
                # Obtenir les bounds visuels de l'objet dans l'espace global
                if obj.type == 'MESH':
                    # Pour les objets mesh, utiliser les coordonnées des vertices après application des modifiers
                    depsgraph = context.evaluated_depsgraph_get()
                    eval_obj = obj.evaluated_get(depsgraph)
                    mesh = eval_obj.data
                    
                    # Transformer chaque vertex dans l'espace global
                    for vertex in mesh.vertices:
                        world_vertex = obj.matrix_world @ vertex.co
                        all_bounds.append(world_vertex)
                else:
                    # Pour les autres types d'objets, utiliser la bounding box
                    bounds = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
                    all_bounds.extend(bounds)
            
            # Calculer le centre de la bounding box combinée
            if all_bounds:
                min_x = min(corner.x for corner in all_bounds)
                max_x = max(corner.x for corner in all_bounds)
                min_y = min(corner.y for corner in all_bounds)
                max_y = max(corner.y for corner in all_bounds)
                min_z = min(corner.z for corner in all_bounds)
                max_z = max(corner.z for corner in all_bounds)
                
                center_x = (min_x + max_x) / 2
                center_y = (min_y + max_y) / 2
                center_z = (min_z + max_z) / 2
                
                context.scene.cursor.location = (center_x, center_y, center_z)
                
        
        elif self.origin_scale == 'Origin':
            context.scene.cursor.location = (0, 0, 0)
            # self.origin_scale_at_bottom = False

        elif self.origin_scale == 'Cursor':
            context.scene.cursor.location = cursor_location
            # self.origin_scale_at_bottom = False
        
        if self.origin_scale_at_bottom:
            # Get the bounding box of all selected objects in global space
            min_z = float('inf')
            for obj in original_selection:
                # Get object bounds in global space
                bounds = [obj.matrix_world @ Vector(corner) for corner in obj.bound_box]
                # Find minimum Z coordinate
                obj_min_z = min(corner.z for corner in bounds)
                min_z = min(min_z, obj_min_z)
        
            # Set cursor Z to the minimum Z coordinate
            context.scene.cursor.location.z = min_z
            # bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)


        if len(selected_mesh_objects) == 1:
            # Single object case - just scale it directly
            obj = selected_mesh_objects[0]
            # obj.scale = (scale_factor, scale_factor, scale_factor)
            bpy.ops.transform.resize(value=(scale_factor, scale_factor, scale_factor), 
                                     orient_type='GLOBAL', 
                                     orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), 
                                     orient_matrix_type='GLOBAL', mirror=False, 
                                     use_proportional_edit=False, 
                                     proportional_edit_falloff='SMOOTH',
                                     proportional_size=1, 
                                     use_proportional_connected=False, 
                                     use_proportional_projected=False, 
                                     snap=False, snap_elements={'INCREMENT'}, 
                                     use_snap_project=False, snap_target='CLOSEST', 
                                     use_snap_self=True, use_snap_edit=True, 
                                     use_snap_nonedit=True, use_snap_selectable=False)

            # Adjust modifier values before applying scale
            self.adjust_modifier_values(obj, scale_factor)
            
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            
            operation_text = "multiplied by" if self.edit_scale_operation == 'MULTIPLY' else "divided by"
            self.report({'INFO'}, f"Single object {operation_text} {self.edit_scale_value}")
            return {'FINISHED'}
        
        bpy.ops.object.empty_add(type='PLAIN_AXES', radius=1, align='WORLD', scale=(1, 1, 1))
        empty = context.active_object
        empty.name = "Scale_Reduction_Empty"

        
        # Find root objects (objects without parents or with parents not in selection)
        root_objects = []
        for obj in original_selection:
            is_root = True
            # Check if this object has a parent that's also in the selection
            if obj.parent and obj.parent in original_selection:
                is_root = False
            if is_root:
                root_objects.append(obj)
        
        bpy.ops.object.select_all(action='DESELECT')
        
        # Select only root objects
        for obj in root_objects:
            obj.select_set(True)
        
        # Parent root objects to empty
        for obj in root_objects:
            # obj.parent = empty
            obj.select_set(True)
        
        empty.select_set(True)
        context.view_layer.objects.active = empty

        bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)

        empty.scale = (scale_factor, scale_factor, scale_factor)
        bpy.ops.transform.resize(value=(scale_factor, scale_factor, scale_factor), 
                                     orient_type='GLOBAL', 
                                     orient_matrix=((1, 0, 0), (0, 1, 0), (0, 0, 1)), 
                                     orient_matrix_type='GLOBAL', mirror=False, 
                                     use_proportional_edit=False, 
                                     proportional_edit_falloff='SMOOTH',
                                     proportional_size=1, 
                                     use_proportional_connected=False, 
                                     use_proportional_projected=False, 
                                     snap=False, snap_elements={'INCREMENT'}, 
                                     use_snap_project=False, snap_target='CLOSEST', 
                                     use_snap_self=True, use_snap_edit=True, 
                                     use_snap_nonedit=True, use_snap_selectable=False)

        bpy.ops.object.select_all(action='DESELECT')
        
        # Select root objects again
        for obj in root_objects:
            obj.select_set(True)
        
        bpy.ops.object.parent_clear(type='CLEAR_KEEP_TRANSFORM')
        
        bpy.data.objects.remove(empty, do_unlink=True)
        
        bpy.ops.object.select_all(action='DESELECT')
        
        for obj in original_selection:
            obj.select_set(True)
        
        # Adjust modifier values for all original objects before applying scale
        for obj in original_selection:
            if obj.type == 'MESH':
                self.adjust_modifier_values(obj, scale_factor)
        
        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
        
        bpy.ops.outliner.orphans_purge(do_recursive=True)
        
        # Restore original selection
        bpy.ops.object.select_all(action='DESELECT')
        for obj in original_selection:
            obj.select_set(True)
            context.view_layer.objects.active = obj
        
        operation_text = "multiplied by" if self.edit_scale_operation == 'MULTIPLY' else "divided by"
        self.report({'INFO'}, f"Scale {operation_text} {self.edit_scale_value} completed on {len(original_selection)} objects")
        return {'FINISHED'}

# STORE VIEWS
class SPEEDSCULPT_OT_store_view3d(Operator):
    bl_idname = "view3d.speedsculpt_store_3dview"
    bl_label = "Store 3D View"
    bl_description = "Store 3D View in the List\n\nYou can Rename, Update & Delete the stored views"

    def execute(self, context):
        region_3d = context.space_data.region_3d

        if not region_3d:
            self.report({'ERROR'}, "No 3D view found!")
            return {'CANCELLED'}

        scene = context.scene
        new_view = scene.view3d_views.add()
        new_view.name = f"View {len(scene.view3d_views)}"
        new_view.view_store_location = region_3d.view_location[:]
        new_view.view_store_rotation = region_3d.view_rotation[:]  # Quaternion
        new_view.view_store_distance = region_3d.view_distance  # Store zoom level

        scene.view3d_views_index = len(scene.view3d_views) - 1
        self.report({'INFO'}, "3Dview Stored.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_update_view3d(Operator):
    bl_idname = "view3d.speedsculpt_update_3dview"
    bl_label = "Update 3D View"
    bl_description = "pdate the 3D View in the List"

    index: IntProperty() # type: ignore

    def execute(self, context):
        region_3d = context.space_data.region_3d

        if not region_3d:
            self.report({'ERROR'}, "No 3Dview found!")
            return {'CANCELLED'}

        scene = context.scene

        if self.index < 0 or self.index >= len(scene.view3d_views):
            self.report({'ERROR'}, "Invalid view index!")
            return {'CANCELLED'}

        view = scene.view3d_views[self.index]
        view.view_store_location = region_3d.view_location[:]
        view.view_store_rotation = region_3d.view_rotation[:]  # Quaternion
        view.view_store_distance = region_3d.view_distance  # Store zoom level

        # Sélectionner automatiquement la vue mise à jour
        scene.view3d_views_index = self.index

        self.report({'INFO'}, f"Updated and selected view: {view.view_store_name}.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_delete_view3d(Operator):
    bl_idname = "view3d.speedsculpt_delete_3dview"
    bl_label = "Delete 3D View"
    bl_description = "Delete the 3D View in the List"

    index: IntProperty() # type: ignore

    def execute(self, context):
        scene = context.scene

        if self.index < 0 or self.index >= len(scene.view3d_views):
            self.report({'ERROR'}, "Invalid view index!")
            return {'CANCELLED'}

        scene.view3d_views.remove(self.index)
        scene.view3d_views_index = max(0, self.index - 1)

        self.report({'INFO'}, f"Deleted view {self.index + 1}.")
        return {'FINISHED'}

class SPEEDSCULPT_UL_view3d_views_ui_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            icons = load_icons()
            is_active = (getattr(active_data, active_property) == index)
            row.prop(item, "name", text="", emboss=False, icon_value=icons.get("icon_areas").icon_id if is_active else icons.get("icon_areas_off").icon_id)
                                
            op_update = row.operator("view3d.speedsculpt_update_3dview", text="", icon='FILE_REFRESH', emboss=False)
            op_update.index = index
            
        elif self.layout_type in {'GRID'}:
            layout.label(text=item.name)

# CURSOR TOOLS
class SPEEDSCULPT_OT_copy_cursor_transform(Operator):
    bl_idname = "object.speedsculpt_copy_cursor_transform"
    bl_label = "Copy Cursor Transform"
    bl_description = "Copy rotation and/or location from 3D cursor to selected objects"
    bl_options = {'REGISTER', 'UNDO'}
    
    transform_type: EnumProperty(
        name="Transform Type",
        description="Choose which transform to copy from cursor",
        items=[
            ('LOCATION', "Location", "Copy only location from cursor"),
            ('ROTATION', "Rotation", "Copy only rotation from cursor"),
            ('BOTH', "Location + Rotation", "Copy both location and rotation from cursor"),
        ],
        default='BOTH'
    ) # type: ignore

    @classmethod
    def description(cls, context, properties):
        if properties.transform_type == 'LOCATION':
            return "Copy location from 3D cursor to selected objects"
        if properties.transform_type == 'ROTATION':
            return "Copy rotation from 3D cursor to selected objects"
        if properties.transform_type == 'BOTH':
            return "Copy location and rotation from 3D cursor to selected objects"
    
    @classmethod
    def poll(cls, context):
        return context.selected_objects and context.mode == 'OBJECT'
    
    def _cursor_rotation_matrix(self, cursor):
        mode = cursor.rotation_mode
        if mode == 'QUATERNION':
            return cursor.rotation_quaternion.to_matrix().to_4x4()
        elif mode == 'AXIS_ANGLE':
            angle, x, y, z = cursor.rotation_axis_angle
            return Matrix.Rotation(angle, 4, Vector((x, y, z)))
        else:
            return cursor.rotation_euler.to_matrix().to_4x4()

    def _apply_rotation(self, obj, rot_matrix):
        mode = obj.rotation_mode
        if mode == 'QUATERNION':
            obj.rotation_quaternion = rot_matrix.to_quaternion()
        elif mode == 'AXIS_ANGLE':
            axis, angle = rot_matrix.to_quaternion().to_axis_angle()
            obj.rotation_axis_angle = [angle, axis.x, axis.y, axis.z]
        else:
            obj.rotation_euler = rot_matrix.to_euler(mode)

    def execute(self, context):
        cursor = context.scene.cursor
        rot_matrix = self._cursor_rotation_matrix(cursor)
        copied_objects = 0

        for obj in context.selected_objects:
            if self.transform_type in ('LOCATION', 'BOTH'):
                obj.location = cursor.location.copy()

            if self.transform_type in ('ROTATION', 'BOTH'):
                self._apply_rotation(obj, rot_matrix)

            copied_objects += 1

        transform_text = {
            'LOCATION': "location",
            'ROTATION': "rotation",
            'BOTH': "location and rotation"
        }

        self.report({'INFO'}, f"Copied cursor {transform_text[self.transform_type]} to {copied_objects} object(s)")
        return {'FINISHED'}
    
    def draw(self, context):
        layout = self.layout
        layout.prop(self, "transform_type")

class SPEEDSCULPT_OT_copy_object_transform_to_cursor(Operator):
    bl_idname = "object.speedsculpt_copy_object_transform_to_cursor"
    bl_label = "Copy Object Transform to Cursor"
    bl_description = "Copy rotation and/or location from active object to 3D cursor"
    bl_options = {'REGISTER', 'UNDO'}

    transform_type: EnumProperty(
        name="Transform Type",
        description="Choose which transform to copy to cursor",
        items=[
            ('LOCATION', "Location", "Copy only location to cursor"),
            ('ROTATION', "Rotation", "Copy only rotation to cursor"),
            ('BOTH', "Location + Rotation", "Copy both location and rotation to cursor"),
        ],
        default='BOTH'
    ) # type: ignore

    @classmethod
    def poll(cls, context):
        return context.active_object and context.mode == 'OBJECT'

    @classmethod
    def description(cls, context, properties):
        if properties.transform_type == 'LOCATION':
            return "Copy location from active object to 3D cursor"
        if properties.transform_type == 'ROTATION':
            return "Copy rotation from active object to 3D cursor"
        if properties.transform_type == 'BOTH':
            return "Copy location and rotation from active object to 3D cursor"

    def execute(self, context):
        obj = context.active_object
        cursor = context.scene.cursor

        if self.transform_type in ('LOCATION', 'BOTH'):
            cursor.location = obj.location.copy()

        if self.transform_type in ('ROTATION', 'BOTH'):
            rot_matrix = obj.matrix_world.to_3x3().to_4x4()
            cursor_mode = cursor.rotation_mode
            if cursor_mode == 'QUATERNION':
                cursor.rotation_quaternion = rot_matrix.to_quaternion()
            elif cursor_mode == 'AXIS_ANGLE':
                axis, angle = rot_matrix.to_quaternion().to_axis_angle()
                cursor.rotation_axis_angle = [angle, axis.x, axis.y, axis.z]
            else:
                cursor.rotation_euler = rot_matrix.to_euler(cursor_mode)

        transform_text = {
            'LOCATION': "location",
            'ROTATION': "rotation",
            'BOTH': "location and rotation"
        }

        self.report({'INFO'}, f"Copied object {transform_text[self.transform_type]} to 3D cursor")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "transform_type")

class SPEEDSCULPT_OT_clear_cursor_transform(Operator):
    bl_idname = "object.speedsculpt_clear_cursor_transform"
    bl_label = "Clear Cursor Transform"
    bl_description = "Clear rotation and/or location of the 3D cursor"
    bl_options = {'REGISTER', 'UNDO'}

    transform_type: EnumProperty(
        name="Transform Type",
        description="Choose which transform to clear on cursor",
        items=[
            ('LOCATION', "Location", "Clear only cursor location"),
            ('ROTATION', "Rotation", "Clear only cursor rotation"),
            ('BOTH', "Location + Rotation", "Clear both cursor location and rotation"),
        ],
        default='BOTH'
    ) # type: ignore

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        cursor = context.scene.cursor

        if self.transform_type in ('LOCATION', 'BOTH'):
            cursor.location = (0.0, 0.0, 0.0)

        if self.transform_type in ('ROTATION', 'BOTH'):
            cursor_mode = cursor.rotation_mode
            if cursor_mode == 'QUATERNION':
                cursor.rotation_quaternion = (1.0, 0.0, 0.0, 0.0)
            elif cursor_mode == 'AXIS_ANGLE':
                cursor.rotation_axis_angle = (0.0, 0.0, 1.0, 0.0)
            else:
                cursor.rotation_euler = (0.0, 0.0, 0.0)

        transform_text = {
            'LOCATION': "location",
            'ROTATION': "rotation",
            'BOTH': "location and rotation"
        }

        self.report({'INFO'}, f"Cleared cursor {transform_text[self.transform_type]}")
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "transform_type")

class SPEEDSCULPT_OT_store_cursor(Operator):
    bl_idname = "view3d.speedsculpt_store_cursor"
    bl_label = "Store 3D Cursor"
    bl_description = "Store 3D Cursor Position and Rotation in the List\n\nYou can Rename, Update & Delete the stored cursors"

    def execute(self, context):
        cursor = context.scene.cursor

        scene = context.scene
        new_cursor = scene.cursor_views.add()
        new_cursor.name = f"Cursor {len(scene.cursor_views)}"
        new_cursor.cursor_store_location = cursor.location[:]
        new_cursor.cursor_store_rotation_mode = cursor.rotation_mode
        new_cursor.cursor_store_rotation = cursor.rotation_euler[:]

        scene.cursor_views_index = len(scene.cursor_views) - 1
        self.report({'INFO'}, "3D Cursor Stored.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_update_cursor(Operator):
    bl_idname = "view3d.speedsculpt_update_cursor"
    bl_label = "Update 3D Cursor"
    bl_description = "Update the 3D Cursor in the List"

    index: IntProperty() # type: ignore

    def execute(self, context):
        cursor = context.scene.cursor
        scene = context.scene

        if self.index < 0 or self.index >= len(scene.cursor_views):
            self.report({'ERROR'}, "Invalid cursor index!")
            return {'CANCELLED'}

        cursor_data = scene.cursor_views[self.index]
        cursor_data.cursor_store_location = cursor.location[:]
        cursor_data.cursor_store_rotation_mode = cursor.rotation_mode
        cursor_data.cursor_store_rotation = cursor.rotation_euler[:]

        # Automatically select the updated cursor
        scene.cursor_views_index = self.index

        self.report({'INFO'}, f"Updated and selected cursor: {cursor_data.name}.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_delete_cursor(Operator):
    bl_idname = "view3d.speedsculpt_delete_cursor"
    bl_label = "Delete 3D Cursor"
    bl_description = "Delete the 3D Cursor in the List"

    index: IntProperty() # type: ignore

    def execute(self, context):
        scene = context.scene

        if self.index < 0 or self.index >= len(scene.cursor_views):
            self.report({'ERROR'}, "Invalid cursor index!")
            return {'CANCELLED'}

        scene.cursor_views.remove(self.index)
        scene.cursor_views_index = max(0, self.index - 1)

        self.report({'INFO'}, f"Deleted cursor {self.index + 1}.")
        return {'FINISHED'}

class SPEEDSCULPT_UL_cursor_views_ui_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            icons = load_icons()
            row = layout.row(align=True)
            is_active = (getattr(active_data, active_property) == index)
            row.prop(item, "name", text="", emboss=False, icon_value=icons.get("icon_cursor").icon_id if is_active else icons.get("icon_cursor_off").icon_id)
               
            op_update = row.operator("view3d.speedsculpt_update_cursor", text="", icon='FILE_REFRESH', emboss=False)
            op_update.index = index
        elif self.layout_type in {'GRID'}:
            layout.label(text=item.name)

CLASSES =  [SPEEDSCULPT_OT_array_curve,
            SPEEDSCULPT_OT_remove_array_curve,
            SPEEDSCULPT_OT_apply_array_curve,
            SPEEDSCULPT_OT_toggle_array_curve_visibility,
            SPEEDSCULPT_OT_connect_array_curve,

            SPEEDSCULPT_OT_backup_selection,
            SPEEDSCULPT_OT_increment_remesh_and_execute,
            SPEEDSCULPT_OT_increment_remesh_and_execute_shortcut,
            SPEEDSCULPT_UL_backups_list,
            SPEEDSCULPT_OT_clear_all_scene_backups,
            SPEEDSCULPT_OT_clear_all_backups,
            SPEEDSCULPT_OT_delete_backup_by_index,
            SPEEDSCULPT_OT_apply_backup_by_index,
            SPEEDSCULPT_OT_create_backup,
            SPEEDSCULPT_OT_create_mesh_from_backup,

            # OBJECT_OT_activate_brush,
            BPM_OT_switch_smooth_brush,
            SPEEDSCULPT_OT_brush_intensity_modal,
            SPEEDSCULPT_OT_draw_curve,
            SPEEDSCULPT_OT_flip_mesh,
            SPEEDSCULPT_OT_toggle_modifiers,
            SPEEDSCULPT_OT_mirror_with_hierarchy,
            SPEEDSCULPT_OT_isolate_objects,
            SPEEDSCULPT_OT_unisolate_objects,
            SPEEDSCULPT_OT_grid_scale,
            SPEEDSCULPT_OT_toggle_geomesh_mirror,
            SPEEDSCULPT_OT_convert_geomesh_to_mesh,
            SPEEDSCULPT_OT_rename_geomesh,
            SPEEDSCULPT_OT_select_geomesh,
            SPEEDSCULPT_OT_delete_geomesh,
            SPEEDSCULPT_OT_lock_geomesh,
            SPEEDSCULPT_OT_toggle_geomesh_visibility,
            SPEEDSCULPT_OT_toggle_geomesh_visibility_shortcut,
            SPEEDSCULPT_OT_append_geomesh,
            SPEEDSCULPT_OT_boolean_sculpt_rebool,
            SPEEDSCULPT_OT_boolean_sculpt_union_difference,
            SPEEDSCULPT_OT_update_dyntopo,
            SPEEDSCULPT_OT_smooth_mesh_only,
            SPEEDSCULPT_OT_remesh_selection,
            SPEEDSCULPT_OT_add_assets_to_scene,
            SPEEDSCULPT_OT_cutter_primitives,
            SPEEDSCULPT_OT_voxel_size_edit,SPEEDSCULPT_OT_dyntopo_detail_size_edit,
            SPEEDSCULPT_OT_voxel_size_finalize,
            SPEEDSCULPT_OT_add_bsurface,
            SPEEDSCULPT_OT_bsurface_start,
            SPEEDSCULPT_OT_bsurface_finalize,
            SPEEDSCULPT_OT_edit_voxel_size,
            SPEEDSCULPT_OT_scale_macro,
            SPEEDSCULPT_OT_scale_finalize,
            SPEEDSCULPT_OT_pick_remesh_size,
            SPEEDSCULPT_OT_remesh_shortcut,
            SPEEDSCULPT_OT_set_bsurface_info,
            SPEEDSCULPT_OT_set_looptools_info,
            SPEEDSCULPT_OT_add_assets_insert,
            SPEEDSCULPT_OT_toggle_flat_shading,

            SPEEDSCULPT_OT_prepare_multi_sculpt,
            SPEEDSCULPT_OT_apply_multi_sculpt,
            SPEEDSCULPT_OT_cancel_multi_sculpt,
            SPEEDSCULPT_OT_copy_active_data_to_selection,
            SPEEDSCULPT_OT_create_group_from_selection,
            SPEEDSCULPT_OT_separate,
            SPEEDSCULPT_OT_copy_cursor_transform,
            SPEEDSCULPT_OT_copy_object_transform_to_cursor,
            SPEEDSCULPT_OT_set_parent,
            SPEEDSCULPT_OT_select_parent,
            SPEEDSCULPT_OT_select_last_parent,
            SPEEDSCULPT_OT_select_hierarchy,
            SPEEDSCULPT_OT_select_children,
            SPEEDSCULPT_OT_unparent_hierarchy,

            SPEEDSCULPT_OT_scale_reduction,

            # STORE VIEWS
            SPEEDSCULPT_OT_store_view3d,
            SPEEDSCULPT_OT_update_view3d,
            SPEEDSCULPT_OT_delete_view3d,
            SPEEDSCULPT_UL_view3d_views_ui_list,

            # STORE CURSORS
            SPEEDSCULPT_OT_store_cursor,
            SPEEDSCULPT_OT_update_cursor,
            SPEEDSCULPT_OT_delete_cursor,
            SPEEDSCULPT_UL_cursor_views_ui_list,
            SPEEDSCULPT_OT_clear_cursor_transform,
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

    SPEEDSCULPT_OT_voxel_size_edit.define("OBJECT_OT_voxel_size_edit")
    SPEEDSCULPT_OT_voxel_size_edit.define("OBJECT_OT_speedsculpt_finalize")
    SPEEDSCULPT_OT_add_bsurface.define("SPEEDSCULPT_OT_bsurface_start")
    SPEEDSCULPT_OT_add_bsurface.define("SPEEDSCULPT_OT_bsurface_finalize")

    SPEEDSCULPT_OT_scale_macro.define("SPEEDSCULPT_OT_scale_finalize")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)

# import random
# # Create Material
# class SPEEDSCULPT_OT_create_random_materials(bpy.types.Operator):
#     bl_idname = 'object.create_random_materials'
#     bl_label = "Create Random Materials"
#     bl_options = {'REGISTER'}
#
#     @classmethod
#     def poll(cls, context):
#         return True
#
#     def execute(self, context):
#         obj = bpy.context.active_object
#         bpy.context.scene.tool_settings.sculpt.show_diffuse_color = True
#
#         for obj in bpy.context.selected_objects:
#             bpy.context.scene.objects.active=obj
#
#             # Create a new material
#             material = bpy.data.materials.new(name=obj.name)
#             material.use_nodes = True
#             material_output = material.node_tree.nodes.get('Material Output')
#             # remove diffuse
#             diffuse = material.node_tree.nodes['Diffuse BSDF']
#             material.node_tree.nodes.remove(diffuse)
#             # add Principled
#             shader = material.node_tree.nodes.new('ShaderNodeBsdfPrincipled')
#             shader.location[0] = 50
#             shader.location[1] = 306
#
#             # link shader to material
#             material.node_tree.links.new(material_output.inputs[0], shader.outputs[0])
#             # set active material to your new material
#             obj.active_material = material
#
#             val = lambda: random.random()
#             C = (val(), val(), val())
#             bpy.context.object.active_material.diffuse_color = (C[0], C[1], C[2])
#             bpy.context.object.active_material.node_tree.nodes['Principled BSDF'].inputs[0].default_value = (
#                 C[0], C[1], C[2], 1)
#
#         return {'FINISHED'}
#
# class SPEEDSCULPT_OT_SC_Remove_Shaders(bpy.types.Operator):
#     bl_idname = 'object.sc_remove_shaders'
#     bl_label = "Remove Shader from selection"
#     bl_options = {'REGISTER'}
#
#     @classmethod
#     def poll(cls, context):
#         return True
#
#     def execute(self, context):
#         selection = bpy.context.selected_objects
#
#         for obj in selection:
#             obj.select_set(state=True)
#             context.view_layer.objects.active = obj
#             if obj.material_slots:
#                 bpy.ops.object.material_slot_remove()
#
#         return {'FINISHED'}
#
#
# class SPEEDSCULPT_OT_Random_Color(bpy.types.Operator):
#     """    RANDOM COLOR
#
#     CLICK - Add Random Color
#     SHIFT - Add the same Shader to Selection
#     CTRL  - Remove Shader
#     ALT    - Link Shader
#     CTRL + SHIFT - Select objects with the same material
#     CTRL + ALT - Single User"""
#
#     bl_idname = "object.random_color"
#     bl_label = "Speedsculpt Random Color"
#     bl_options = {"REGISTER", "UNDO"}
#
#     def invoke(self, context, event):
#         selection = bpy.context.selected_objects
#
#         bpy.context.object.show_transparent = True
#         bpy.context.space_data.show_backface_culling = True
#
#         if event.ctrl and event.shift:
#             bpy.ops.object.select_linked(type='MATERIAL')
#
#         elif event.ctrl and event.alt:
#             bpy.ops.object.make_single_user(type='SELECTED_OBJECTS', object=False, obdata=False, material=True,
#                                             texture=True, animation=False)
#
#         elif event.shift:
#             for obj in selection:
#                 obj.select_set(state=True)
#                 context.view_layer.objects.active = obj
#                 bpy.ops.object.create_random_materials()
#                 bpy.ops.object.make_links_data(type='MATERIAL')
#
#         elif event.ctrl:
#             for obj in selection:
#                 obj.select_set(state=True)
#                 context.view_layer.objects.active = obj
#                 if obj.material_slots:
#                     bpy.ops.object.material_slot_remove()
#
#         elif event.alt:
#             bpy.ops.object.make_links_data(type='MATERIAL')
#
#         else:
#             bpy.ops.object.create_random_materials()
#
#         return {"FINISHED"}
#
#
# def Speedsculpt_Set_Material_Color(self, context):
#     selection = bpy.context.selected_objects
#     WM = bpy.context.window_manager
#
#     for obj in selection:
#         obj.select_set(state=True)
#         context.view_layer.objects.active = obj
#
#         if len(obj.material_slots):
#             bpy.context.object.active_material.diffuse_color = WM.speedsculpt_set_material_color
#             bpy.context.object.active_material.node_tree.nodes['Principled BSDF'].inputs[0].default_value = (
#                 WM.speedsculpt_set_material_color[0], WM.speedsculpt_set_material_color[1],
#                 WM.speedsculpt_set_material_color[2], 1)