import bpy
import os
import sys
import glob
import subprocess
from pathlib import Path
from bpy.types import Operator, UIList
from bpy.props import IntProperty
import time

# --- VARIABLES GLOBALES ---
FRAME_COUNT = 0
HAS_CHANGED = False
LAST_EVENT_TIME = 0.0
IDLE_TIMEOUT = 5.0

# --- TIMER FUNCTION (The capture loop) ---
def capture_tick():
    global FRAME_COUNT, HAS_CHANGED
    settings = bpy.context.scene.sculpt_timelapse

    if not settings.is_recording or not settings.camera or not HAS_CHANGED:
        settings.is_paused = settings.is_recording  # Paused si recording mais sans activité
        return settings.interval if settings.is_recording else None

    settings.is_paused = False  # Active → pas en pause

    abs_path = Path(bpy.path.abspath(settings.save_path))
    abs_path.mkdir(parents=True, exist_ok=True)
    filepath = str(abs_path / f"sculpt_frame_{FRAME_COUNT:04d}.png")
    
    # 1. Search for a 3D window that looks through the camera
    target_window = None
    target_area = None
    target_region = None

    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                for space in area.spaces:
                    if space.type == 'VIEW_3D' and space.region_3d.view_perspective == 'CAMERA':
                        target_window = window  # ← stocker la référence
                        target_area = area
                        for region in area.regions:
                            if region.type == 'WINDOW':
                                target_region = region
                                break
                        break

    if target_area and target_region:
        # 2. OVERRIDE : Make Blender think we're clicking in this window
        override = bpy.context.copy()
        override['window'] = target_window
        override['screen'] = target_window.screen
        override['area'] = target_area
        override['region'] = target_region
        override['space_data'] = target_area.spaces.active
        override['region_data'] = target_area.spaces.active.region_3d
        
        old_filepath = bpy.context.scene.render.filepath
        bpy.context.scene.render.filepath = filepath
        
        try:
            with bpy.context.temp_override(**override):
                bpy.context.object.update_tag()
                bpy.ops.render.opengl(write_still=True, view_context=True)
            
            FRAME_COUNT += 1
            settings.frame_count = FRAME_COUNT
            HAS_CHANGED = False
        except Exception as e:
            print(f"Capture error: {e}")
        finally:
            bpy.context.scene.render.filepath = old_filepath
    else:
        print("Error: No 3D view configured on the Camera has been found.")

    return settings.interval

# --- EXTERNAL COMPILATION FUNCTION (FFMPEG) ---
def compile_mp4_external(settings, name, scale='1.0', crf='23', preset='medium', fps=30):
    abs_path = bpy.path.abspath(settings.save_path)
    fps = settings.framerate

    # Scale filter — keeps dimensions divisible by 2 (required by libx264)
    if float(scale) != 1.0:
        vf = f'-vf "scale=trunc(iw*{scale}/2)*2:trunc(ih*{scale}/2)*2"'
    else:
        vf = ''

    if os.name == 'nt':  # Windows
        script_file = os.path.join(abs_path, "compile_video.bat")
        cmd = (f'ffmpeg -y -framerate {fps} -i "sculpt_frame_%%04d.png" -r {fps} '
               f'{vf} -c:v libx264 -crf {crf} -preset {preset} '
               f'-pix_fmt yuv420p "{name}.mp4"')
        with open(script_file, 'w') as f:
            f.write(cmd)
    else:  # Mac / Linux
        script_file = os.path.join(abs_path, "compile_video.sh")
        cmd = (f'ffmpeg -y -framerate {fps} -i "sculpt_frame_%04d.png" -r {fps} '
               f'{vf} -c:v libx264 -crf {crf} -preset {preset} '
               f'-pix_fmt yuv420p "{name}.mp4"')
        with open(script_file, 'w') as f:
            f.write(f"#!/bin/bash\n{cmd}")
        os.chmod(script_file, 0o755)

    try:
        subprocess.Popen(script_file, cwd=abs_path, shell=True)
        return True, f"Compilation launched (CRF {crf}, {preset}, scale x{scale}) !"
    except Exception as e:
        return False, f"Launch error: {e}"

class SPEEDSCULPT_OT_start_timelapse(bpy.types.Operator):
    bl_idname = "object.speedsculpt_start_timelapse"
    bl_label = "Start Timelapse"
    bl_description = "Start the timelapse recording"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        global FRAME_COUNT, HAS_CHANGED
        settings = context.scene.sculpt_timelapse

        bpy.context.scene.view_settings.view_transform = 'Standard'
        
        if not settings.camera:
            self.report({'ERROR'}, "Please select a camera.")
            return {'CANCELLED'}
        
        settings.is_recording = True
        HAS_CHANGED = True # Force the first capture
        
        abs_path = bpy.path.abspath(settings.save_path)
        existing_files = glob.glob(os.path.join(abs_path, "sculpt_frame_*.png"))
        if existing_files:
            numbers = [int(f.split('_')[-1].split('.')[0]) for f in existing_files]
            FRAME_COUNT = max(numbers) + 1
            settings.frame_count = FRAME_COUNT
            settings.has_frames = True # We have frames to compile
        else:
            FRAME_COUNT = 0
            
        # Lancer le watcher d'événements
        bpy.ops.object.speedsculpt_timelapse_event_watcher('INVOKE_DEFAULT')
        # Lancer le timer de capture
        bpy.app.timers.register(capture_tick)

        self.report({'INFO'}, "Timelapse Started.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_stop_timelapse(bpy.types.Operator):
    bl_idname = "object.speedsculpt_stop_timelapse"
    bl_label = "Stop Recording"
    bl_description = "Stop the timelapse recording"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        settings = context.scene.sculpt_timelapse
        settings.is_recording = False

        bpy.context.scene.view_settings.view_transform = 'AgX'
        settings.has_frames = True
        
        return {'FINISHED'}

class SPEEDSCULPT_OT_reset_timelapse(bpy.types.Operator):
    bl_idname = "object.speedsculpt_reset_timelapse"
    bl_label = "Reset (Delete images)"
    bl_description = "Reset the timelapse recording and delete the images"
    bl_options = {'REGISTER'}

    confirm_message: bpy.props.StringProperty(
        name="Confirm Message",
        default="Are you sure you want to reset the timelapse recording and delete the images?\nThis action cannot be undone."
    )

    def invoke(self, context, event):
        # Use an operator dialog for custom messages (so draw is called)
        return context.window_manager.invoke_props_dialog(self, width=410)

    def draw(self, context):
        layout = self.layout
        for line in self.confirm_message.split('\n'):
            layout.label(text=line)

    def execute(self, context):
        settings = context.scene.sculpt_timelapse
        abs_path = bpy.path.abspath(settings.save_path)

        files_to_delete = glob.glob(os.path.join(abs_path, "sculpt_frame_*.png"))
        count = 0
        for f in files_to_delete:
            try:
                os.remove(f)
                count += 1
            except Exception:
                pass

        try:
            if os.path.exists(os.path.join(abs_path, "compile_video.bat")):
                os.remove(os.path.join(abs_path, "compile_video.bat"))
            if os.path.exists(os.path.join(abs_path, "timelapse_final.mp4")):
                os.remove(os.path.join(abs_path, "timelapse_final.mp4"))
        except:
            pass

        global FRAME_COUNT
        FRAME_COUNT = 0
        settings.frame_count = 0
        settings.has_frames = False  # We don't have frames to compile
        self.report({'INFO'}, f"Reset completed: {count} images deleted.")
        return {'FINISHED'}

def has_selected_objects(context):
    selected_objects = [obj for obj in context.selected_objects]
    if len(selected_objects) > 0:
        for obj in selected_objects:
            if obj.type != 'CAMERA':
                if obj.mode != 'OBJECT':
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.select_all(action='DESELECT')
    return True

class SPEEDSCULPT_OT_create_camera_timelapse(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_create_camera_timelapse'
    bl_label = "Create Camera Timelapse"
    bl_description = "Create a Camera Timelapse"
    bl_options = {'REGISTER', 'UNDO'}

    camera_name: bpy.props.StringProperty(
        name="Camera Name",
        description="Name for the new timelapse camera",
        default="Camera_Timelapse"
    )

    add_target: bpy.props.BoolProperty(
        name="Add Target",
        description="Add a target to the camera",
        default=False
    )

    @classmethod
    def poll(cls, context):
        return True

    def invoke(self, context, event):
        # Set the default value to Camera_Timelapse or last used value if desired
        if not self.camera_name:
            self.camera_name = "Camera_Timelapse"
        wm = context.window_manager
        return wm.invoke_props_dialog(self, width=250)

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = True
        layout.prop(self, "camera_name")
        layout.prop(self, "add_target", text="Add Target")
        
    def execute(self, context):
        settings = context.scene.sculpt_timelapse
        active_object = context.active_object

        if active_object.type != 'CAMERA':
            current_mode = active_object.mode

        has_selected_objects(context)

        if active_object and active_object.type == 'CAMERA':
            bpy.ops.object.select_all(action='DESELECT')

            # Set the camera to the current view
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    for space in area.spaces:
                        if space.type == 'VIEW_3D':
                            for region in area.regions:
                                if region.type == 'WINDOW':
                                    override = {
                                        'window': window,
                                        'screen': window.screen,
                                        'area': area,
                                        'region': region,
                                        'space_data': space,
                                        'region_data': space.region_3d,
                                    }
                                    with context.temp_override(**override):
                                        if space.region_3d.view_perspective == 'CAMERA':
                                            bpy.ops.view3d.view_camera()  # toggle OFF
                                    break
        
        # Set the camera resolution
        if settings.camera_resolutions == 'Horizontal':
            bpy.context.scene.render.resolution_x = 1920
            bpy.context.scene.render.resolution_y = 1080
        elif settings.camera_resolutions == 'Vertical':
            bpy.context.scene.render.resolution_x = 1080
            bpy.context.scene.render.resolution_y = 1920
        elif settings.camera_resolutions == 'Square':
            bpy.context.scene.render.resolution_x = 1080
            bpy.context.scene.render.resolution_y = 1080
        
        # Create a new camera
        bpy.ops.object.camera_add(location=(0, 0, 0), rotation=(0, 0, 0))
        camera = context.active_object
        camera.name = self.camera_name
        camera.data.name = self.camera_name
        settings.camera = camera
        context.scene.camera = camera 
        bpy.context.object.data.show_name = True

        # Activer lock_camera dans toutes les vues 3D existantes
        for window in bpy.context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.spaces.active.lock_camera = True
        camera.hide_viewport = True



        collection_name = "SPEEDSCULPT_TIMELAPSE"
        # Check if collection exists
        if collection_name in bpy.data.collections:
            timelapse_collection = bpy.data.collections[collection_name]
        else:
            timelapse_collection = bpy.data.collections.new(collection_name)
            bpy.context.scene.collection.children.link(timelapse_collection)
        # Unlink camera from existing parent collection if needed
        for coll in camera.users_collection:
            coll.objects.unlink(camera)
        # Add camera to the SPEEDSCULPT_TIMELAPSE collection
        if camera.name not in timelapse_collection.objects:
            timelapse_collection.objects.link(camera)


        
        
        bpy.ops.view3d.camera_to_view()

        objects = list(context.scene.objects)
        for i, obj in enumerate(objects):
            if obj == camera:
                settings.camera_list_index = i  # déclenche update → vue caméra
                break

        # Add a Track To constraint to the camera to track the active object
        constraint_mod = camera.constraints.new(type='TRACK_TO')
        if self.add_target:
            constraint_mod.target = active_object

        bpy.ops.object.select_all(action='DESELECT')
        active_object.select_set(state=True)
        context.view_layer.objects.active = active_object

        if current_mode:
            bpy.ops.object.mode_set(mode=current_mode, toggle=False)
        
        bpy.ops.view3d.view_selected()

        return {'FINISHED'}

class SPEEDSCULPT_OT_delete_timelapse_camera(bpy.types.Operator):
    bl_idname = "object.speedsculpt_delete_timelapse_camera"
    bl_label = "Delete Timelapse Camera"
    bl_description = "Delete the active timelapse camera"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        settings = context.scene.sculpt_timelapse
        cam_to_delete = settings.camera

        if not cam_to_delete:
            self.report({'WARNING'}, "No camera selected.")
            return {'CANCELLED'}

        # Liste triée par nom (même ordre que la UIList)
        cameras = sorted(
            [obj for obj in context.scene.objects if obj.type == 'CAMERA'],
            key=lambda o: o.name
        )

        if cam_to_delete not in cameras:
            return {'CANCELLED'}

        current_idx = cameras.index(cam_to_delete)
        cameras_remaining = [c for c in cameras if c != cam_to_delete]

        # Supprimer la caméra
        bpy.data.objects.remove(cam_to_delete, do_unlink=True)

        # Mettre la précédente (ou suivante si c'était la 1ère) active
        if cameras_remaining:
            new_cam = cameras_remaining[max(0, current_idx - 1)]
            settings.camera = new_cam
            context.scene.camera = new_cam
            # Trouver le nouvel index dans scene.objects (après suppression)
            all_objects = list(context.scene.objects)
            for i, obj in enumerate(all_objects):
                if obj == new_cam:
                    settings.camera_list_index = i
                    break
        else:
            settings.camera = None

        return {'FINISHED'}

class SPEEDSCULPT_OT_save_to_mp4(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_save_to_mp4'
    bl_label = "Save to MP4"
    bl_description = "Save the timelapse recording to a MP4 file"
    bl_options = {'REGISTER'}

    name: bpy.props.StringProperty(
        name="Name",
        description="Name of the MP4 file",
        default="timelapse_final"
    )
    resolution_scale: bpy.props.EnumProperty(
        name="Resolution",
        items=[
            ('0.5', "0.5 - Half", "Scale down by 0.5x"),
            ('1.0', "1 - Native", "Keep original resolution"),
            ('1.5', "1.5 - Medium", "Scale up by 1.5x"),
            ('2.0', "2 - Double", "Scale up by 2x"),
        ],
        default='1.0'
    )
    quality: bpy.props.EnumProperty(
        name="Quality",
        items=[
            ('28', "Draft (CRF 28)", "Small file, lower quality"),
            ('23', "Medium (CRF 23)", "Default FFmpeg quality"),
            ('18', "High (CRF 18)", "High quality"),
            ('14', "Best (CRF 14)", "Near lossless"),
        ],
        default='23'
    )

    encode_speed: bpy.props.EnumProperty(
        name="Encode Speed",
        items=[
            ('ultrafast', "Fast", "Quick encode, larger file"),
            ('medium',    "Medium", "Balanced"),
            ('slow',      "Slow", "Better compression, same quality"),
        ],
        default='medium'
    )

    framerate: bpy.props.IntProperty(
        name="Framerate",
        default=30,
        min=1,
        max=60
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = True
        layout.prop(self, "name")
        layout.prop(self, "resolution_scale")
        layout.prop(self, "quality")
        layout.prop(self, "encode_speed")
        layout.prop(self, "framerate")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=280)

    def execute(self, context):
        settings = context.scene.sculpt_timelapse
        
        success, message = compile_mp4_external(
            settings, self.name,
            scale=self.resolution_scale,
            crf=self.quality,
            preset=self.encode_speed,
            fps=self.framerate,
            
        )
        if success:
            self.report({'INFO'}, message)
        else:
            self.report({'ERROR'}, message)
        return {'FINISHED'}

class SPEEDSCULPT_OT_set_timelapse_camera(bpy.types.Operator):
    bl_idname = "object.speedsculpt_set_timelapse_camera"
    bl_label = "Set Timelapse Camera"
    bl_options = {'REGISTER', 'UNDO'}

    camera_name: bpy.props.StringProperty()

    def execute(self, context):
        settings = context.scene.sculpt_timelapse
        obj = context.scene.objects.get(self.camera_name)
        if obj and obj.type == 'CAMERA':
            settings.camera = obj
            context.scene.camera = obj  # Change aussi la caméra active de la scène
        return {'FINISHED'}

class SPEEDSCULPT_OT_add_target_to_timelapse_camera(bpy.types.Operator):
    bl_idname = 'object.speedsculpt_add_target_to_timelapse_camera'
    bl_label = "Add Target to Timelapse Camera"
    bl_description = "Add a target to the timelapse camera"
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        camera = context.scene.camera
        if camera and camera.type == 'CAMERA':
            if camera.constraints.get("Track To"):
                pass
            else:
                camera.constraints.new(type='TRACK_TO')
                camera.constraints['Track To'].target = context.active_object
        
        return {'FINISHED'}

class SPEEDSCULPT_OT_check_timelapse_folder(bpy.types.Operator):
    bl_idname = "object.speedsculpt_check_timelapse_folder"
    bl_label = "Check Timelapse Folder"
    bl_description = "Check if the timelapse folder is empty"
    bl_options = {'REGISTER'}

    def execute(self, context):
        settings = context.scene.sculpt_timelapse
        abs_path = bpy.path.abspath(settings.save_path)

        if not os.path.exists(abs_path):
            self.report({'WARNING'}, f"Folder does not exist: {abs_path}")
            return {'CANCELLED'}

        existing_files = glob.glob(os.path.join(abs_path, "sculpt_frame_*.png"))

        if existing_files:
            settings.has_frames = True
            settings.frame_count = len(existing_files)
            self.report({'WARNING'}, f"Folder is NOT empty: {len(existing_files)} frame(s) found.")
        else:
            settings.has_frames = False
            settings.frame_count = 0
            self.report({'INFO'}, "Folder is empty. Ready to record.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_open_timelapse_folder(bpy.types.Operator):
    bl_idname = "object.speedsculpt_open_timelapse_folder"
    bl_label = "Open Timelapse Folder"
    bl_description = "Open the timelapse save folder in the file explorer"
    bl_options = {'REGISTER'}

    def execute(self, context):
        settings = context.scene.sculpt_timelapse
        abs_path = bpy.path.abspath(settings.save_path)

        if not os.path.exists(abs_path):
            os.makedirs(abs_path, exist_ok=True)

        if os.name == 'nt':  # Windows
            os.startfile(abs_path)
        elif sys.platform == 'darwin':  # macOS
            subprocess.Popen(['open', abs_path])
        else:  # Linux
            subprocess.Popen(['xdg-open', abs_path])

        return {'FINISHED'}

# -----------------------------------------------------------------------------
#    CAMERA VIEWS
# -----------------------------------------------------------------------------
def update_camera_view(self, context):
    # self = l'objet camera (car la prop est sur bpy.types.Object)
    cam = self
    if not cam or cam.type != 'CAMERA' or cam.camera_views_index < 0:
        return
    if cam.camera_views_index >= len(cam.camera_views):
        return
    view = cam.camera_views[cam.camera_views_index]
    cam.location = view.store_camera_view_location
    cam.rotation_euler = view.store_camera_view_rotation

class SPEEDSCULPT_OT_Store_camera_view(Operator):
    bl_idname = "object.speedsculpt_store_camera_view"
    bl_label = "Store Camera View"
    bl_description = "Store the Camera View in the List\n\nYou can then, select, rename (Double Click), and Delete the view"
    bl_options = {'REGISTER','UNDO'}

    def execute(self, context):
        bpy.ops.ed.undo_push(message="Add an undo step")
        scene = context.scene
        cam = context.scene.sculpt_timelapse.camera

        if not cam or cam.type != 'CAMERA':
            self.report({'ERROR'}, "Active object is not a camera!")
            return {'CANCELLED'}

        # if "camera_views" not in cam:
        #     cam["camera_views"] = []

        new_view = cam.camera_views.add()
        new_view.name = f"View {len(cam.camera_views)}"
        new_view.store_camera_view_location = cam.location
        new_view.store_camera_view_rotation = cam.rotation_euler

        cam.camera_views_index = len(cam.camera_views) - 1
        self.report({'INFO'}, "Camera view stored.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_delete_camera_view(Operator):
    bl_idname = "object.speedsculpt_delete_camera_view"
    bl_label = "Delete Camera View"
    bl_description = "Delete the Selected Camera View"
    bl_options = {'REGISTER','UNDO'}

    index: IntProperty() # type: ignore

    def execute(self, context):
        cam = context.scene.sculpt_timelapse.camera

        if not cam or cam.type != 'CAMERA':
            self.report({'ERROR'}, "Active object is not a camera!")
            return {'CANCELLED'}

        if self.index < 0 or self.index >= len(cam.camera_views):
            self.report({'ERROR'}, "Invalid view index!")
            return {'CANCELLED'}

        cam.camera_views.remove(self.index)
        cam.camera_views_index = max(0, self.index - 1)

        self.report({'INFO'}, f"Deleted view {self.index + 1}.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_update_camera_view(Operator):
    bl_idname = "object.speedsculpt_update_camera_view"
    bl_label = "Update Camera View"
    bl_description = "Update the Camera View"
    bl_options = {'REGISTER','UNDO'}

    index: IntProperty()# type: ignore

    def execute(self, context):
        bpy.ops.ed.undo_push(message="Add an undo step")
        cam = context.scene.sculpt_timelapse.camera  # On prend l'objet actif, qui doit être une caméra

        if not cam or cam.type != 'CAMERA':
            self.report({'ERROR'}, "Active object is not a camera!")
            return {'CANCELLED'}

        if self.index < 0 or self.index >= len(cam.camera_views):
            self.report({'ERROR'}, "Invalid view index!")
            return {'CANCELLED'}

        view = cam.camera_views[self.index]
        view.store_camera_view_location = cam.location
        view.store_camera_view_rotation = cam.rotation_euler

        # Rendre l'élément mis à jour actif
        cam.camera_views_index = self.index

        self.report({'INFO'}, f"Updated and activated view {view.name}.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_clear_all_camera_views(Operator):
    bl_idname = "object.speedsculpt_clear_all_camera_views"
    bl_label = "Delete All Camera Views"
    bl_description = "Delete All the Camera Views"
    bl_options = {'REGISTER','UNDO'}


    def execute(self, context):
        cam = context.scene.sculpt_timelapse.camera  # On prend l'objet actif, qui doit être une caméra

        if not cam or cam.type != 'CAMERA':
            self.report({'ERROR'}, "Active object is not a camera!")
            return {'CANCELLED'}

        cam.camera_views.clear()
        cam.camera_views_index = -1
        self.report({'INFO'}, "All camera views cleared.")
        return {'FINISHED'}

class SPEEDSCULPT_UL_camera_views_uilist(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_property, index):
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            row.prop(item, "name", text="", emboss=False, icon='OUTLINER_OB_CAMERA')
            op_update = row.operator("object.speedsculpt_update_camera_view", text="", icon='FILE_REFRESH')
            # op_update.index = index
            # op_delete = row.operator("object.speedsculpt_delete_camera_view", text="", icon='X')
            # op_delete.index = index
        elif self.layout_type in {'GRID'}:
            layout.label(text=item.name)

class SPEEDSCULPT_OT_timelapse_event_watcher(bpy.types.Operator):
    bl_idname = "object.speedsculpt_timelapse_event_watcher"
    bl_label = "Timelapse Event Watcher"

    def modal(self, context, event):
        global HAS_CHANGED, LAST_EVENT_TIME

        settings = context.scene.sculpt_timelapse
        if not settings.is_recording:
            return {'CANCELLED'}

        # Filtrer les vrais événements utilisateur
        is_user_event = (
            event.type == 'MOUSEMOVE' or
            event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE',
                           'WHEELUPMOUSE', 'WHEELDOWNMOUSE'} or
            (event.type not in {'TIMER', 'NONE', 'INBETWEEN_MOUSEMOVE'} and
             event.value in {'PRESS', 'RELEASE'})
        )

        if is_user_event:
            LAST_EVENT_TIME = time.time()
            HAS_CHANGED = True

        # Vérifier le timeout d'inactivité
        if time.time() - LAST_EVENT_TIME > IDLE_TIMEOUT:
            HAS_CHANGED = False
            settings.is_paused = True
        else:
            settings.is_paused = False

        return {'PASS_THROUGH'}

    def invoke(self, context, event):
        global LAST_EVENT_TIME
        LAST_EVENT_TIME = time.time()
        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

CLASSES =  [
            SPEEDSCULPT_OT_start_timelapse,
            SPEEDSCULPT_OT_stop_timelapse,
            SPEEDSCULPT_OT_reset_timelapse, 
            SPEEDSCULPT_OT_create_camera_timelapse,
            SPEEDSCULPT_OT_delete_timelapse_camera,
            SPEEDSCULPT_OT_save_to_mp4,
            SPEEDSCULPT_OT_set_timelapse_camera,
            SPEEDSCULPT_OT_add_target_to_timelapse_camera,
            SPEEDSCULPT_OT_check_timelapse_folder,
            SPEEDSCULPT_OT_open_timelapse_folder,
            # CAMERA VIEWS
            SPEEDSCULPT_OT_Store_camera_view,
            SPEEDSCULPT_OT_delete_camera_view,
            SPEEDSCULPT_OT_update_camera_view,
            SPEEDSCULPT_OT_clear_all_camera_views,
            SPEEDSCULPT_UL_camera_views_uilist,
            SPEEDSCULPT_OT_timelapse_event_watcher
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
