# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
import bmesh
from bpy.props import (StringProperty,
                       BoolProperty,
                       PointerProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       BoolVectorProperty,
                       CollectionProperty)


def HideLattice(self, context):
    """Hide the Lattice Modifier on selected objects"""
    
    obj = context.active_object
    obj_list = [obj for obj in context.selected_objects]
    
    for obj in obj_list:
        for mod in obj.modifiers:
            if mod.type == 'LATTICE':
                mod.show_viewport = not mod.show_viewport

class SPEEDSCULPT_OT_lattice_add_mask(bpy.types.Operator):
    bl_idname = "object.lattice_add_mask"
    bl_label = "Lattice Add Mask"
    bl_description = "Add Mask to the Lattice"
    bl_options = {"REGISTER"}

    def execute(self, context):
        obj = context.active_object

        for mod in obj.modifiers:
            if mod.type=='LATTICE':
                mod.show_viewport = False

        bpy.ops.object.mode_set(mode='SCULPT')
        if bpy.app.version < (4, 3, 0):
            bpy.ops.paint.brush_select(sculpt_tool='MASK')
        else:
            bpy.ops.wm.tool_set_by_id(name="builtin_brush.mask")
        return {"FINISHED"}
    
class SPEEDSCULPT_OT_lattice_smooth_mask(bpy.types.Operator):
    bl_idname = "object.lattice_smooth_mask"
    bl_label = "Lattice Smooth Mask"
    bl_description = "Smooth The Mask"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        
        for vgroup in obj.vertex_groups:
            if vgroup.name == "SpeedLattice_Group":
                bpy.ops.object.mode_set(mode = 'EDIT')
                bpy.ops.mesh.select_all(action='DESELECT')
                bpy.ops.object.mode_set(mode='WEIGHT_PAINT') 
                bpy.context.object.data.use_paint_mask_vertex = True
                bpy.ops.object.vertex_group_set_active(group='SpeedLattice_Group')
                bpy.ops.object.vertex_group_select()
                bpy.ops.object.vertex_group_smooth(factor=1)
                bpy.ops.object.vertex_group_smooth(repeat=200)
                bpy.context.object.data.use_paint_mask_vertex = False
                bpy.ops.object.mode_set(mode = 'OBJECT')
        return {"FINISHED"}
           
class SPEEDSCULPT_OT_valid_lattice_mask(bpy.types.Operator):
    bl_idname = "object.valid_lattice_mask"
    bl_label = "Valide Lattice Mask"
    bl_description = "Valid the Lattice mask"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        obj = context.active_object

            
        #Remove Vgroups
        for vgroup in obj.vertex_groups:
            if vgroup.name == "SpeedLattice_Group":
                obj.vertex_groups.remove(vgroup)
        
        #Create selection
        # bpy.ops.paint.hide_show(action='HIDE', area='MASKED')
        bpy.ops.paint.hide_show_masked(action='HIDE')
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.select_all(action='INVERT')
        bpy.ops.mesh.reveal()                           
        
        #Add Vgroup
        obj.vertex_groups.new(name="SpeedLattice_Group")

        bpy.ops.object.vertex_group_assign()
            
        bpy.ops.object.lattice_smooth_mask()

        lattice_mods = [mod for mod in obj.modifiers if mod.type == 'LATTICE']
        for mod in lattice_mods:
            mod.show_viewport = True
            mod.vertex_group = "SpeedLattice_Group"

        bpy.ops.object.mode_set(mode='OBJECT')    
            
        return {"FINISHED"}   
        
class SPEEDSCULPT_OT_add_lattice(bpy.types.Operator):
    bl_idname = "object.add_lattice"
    bl_label = "Add Lattice"
    bl_description = "Add a Lattice on selected objects"
    bl_options = {"REGISTER","UNDO"}

    scale_factor: FloatVectorProperty(
        name="Scale Factor",
        description="Factor to multiply the object dimensions by",
        default=(1.0, 1.0, 1.0),
        min=0.01,
        max=100.0,
        subtype='XYZ') # type: ignore

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        obj = context.active_object
        obj_list = [obj for obj in context.selected_objects]
        
        #Remove Vgroup             
        for vgroup in obj.vertex_groups:
            if vgroup.name == "SpeedLattice_Group":
                obj.vertex_groups.remove(vgroup)

        # Object 1 selection
        if len([obj for obj in context.selected_objects if obj.type == 'MESH' and not context.object.mode == 'SCULPT' and context.object.mode == "OBJECT"]) == 1:
            
            bpy.ops.object.duplicate_move()
            context.active_object.name= "BBox_Object"
            
            if speedsculpt.copy_orientation :
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
        
        #EDIT           
        if context.object.mode == "EDIT":
                
            obj.vertex_groups.new(name="SpeedLattice_Group")
            
            for vgroup in obj.vertex_groups:
                if vgroup.name == "SpeedLattice_Group":
                    bpy.ops.object.vertex_group_assign()
               
            act_obj = context.active_object.name
            
            bpy.ops.mesh.duplicate_move()
            bpy.ops.mesh.separate(type="SELECTED")
            bpy.ops.object.mode_set(mode = 'OBJECT')
            
            obj_list1 = [obj for obj in context.selected_objects]
            for obj in obj_list1:
                act_obj = context.active_object
                act_obj.select_set(state=False)

            for obj in context.selected_objects :
                context.view_layer.objects.active = obj
                context.active_object.name= "BBox_Object"
                if speedsculpt.copy_orientation :
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)
            
            del(obj_list1[:]) 
                
        #SCULPT        
        if bpy.context.object.mode == "SCULPT":

            #convert mask to vertex group
            bpy.ops.paint.hide_show_masked(action='HIDE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.select_all(action='INVERT')
            bpy.ops.mesh.reveal()

            me = obj.data
            bm = bmesh.from_edit_mesh(me)
            if [v for v in bm.verts if v.select] :

                obj.vertex_groups.new(name="SpeedLattice_Group")
                for vgroup in obj.vertex_groups:
                    if vgroup.name == "SpeedLattice_Group":
                        bpy.ops.object.vertex_group_assign()

                #Smooth vertex group
                bpy.ops.object.mode_set(mode='WEIGHT_PAINT')
                bpy.context.object.data.use_paint_mask_vertex = True
                bpy.ops.object.vertex_group_set_active(group='SpeedLattice_Group')
                bpy.ops.object.vertex_group_select()
                bpy.ops.object.vertex_group_smooth(factor=1)
                bpy.ops.object.vertex_group_smooth(repeat=100)
                bpy.context.object.data.use_paint_mask_vertex = False
            else:
                bpy.ops.object.mode_set(mode='SCULPT')
                self.report({'WARNING'}, "No Mask on the Mesh")
                return {'FINISHED'}

            bpy.ops.object.mode_set(mode = 'EDIT')

            act_obj = context.active_object.name

            bpy.ops.mesh.duplicate_move()
            bpy.ops.mesh.separate(type="SELECTED")
            bpy.ops.object.mode_set(mode = 'OBJECT')

            obj_list1 = [obj for obj in bpy.context.selected_objects]
            for obj in obj_list1:
                act_obj = context.active_object
                act_obj.select_set(state=False)

            for obj in context.selected_objects :
                context.view_layer.objects.active = obj
                bpy.context.active_object.name= "BBox_Object"
                if speedsculpt.copy_orientation :
                    bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)


            del(obj_list1[:])

        #Hide Mirror
        for obj in obj_list:
            context.view_layer.objects.active = obj
            if obj.modifiers:
                if "Mirror" in obj.modifiers:
                    obj.modifiers["Mirror"].show_viewport = False

        # Si object > 1
        if len([obj for obj in context.selected_objects if obj.type == 'MESH' and not context.object.mode == 'SCULPT']) > 1:

            bpy.ops.object.duplicate_move()
            bpy.ops.object.join()
            context.active_object.name= "BBox_Object"
            if speedsculpt.copy_orientation :
                bpy.ops.object.transform_apply(location=False, rotation=True, scale=False)

        # 3
        from mathutils import Vector  # Import here, before using it
        selected = context.selected_objects
        lattice_object = None  # Initialize lattice_object
        depsgraph = context.evaluated_depsgraph_get()

        for obj in selected:
            #ensure origin is centered on bounding box center
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='BOUNDS')
            
            # Duplicata temporaire pour le calcul du bounding box visible
            # si l'objet n'a aucun modificateur
            if len(obj.modifiers) == 0:
                # Create lattice only once
                if lattice_object is None:
                    bpy.ops.object.add(radius=1, type='LATTICE', align='WORLD', enter_editmode=False, location=(0, 0, 0))
                    lattice_object = context.active_object
                
                # Use evaluated object to get real dimensions with scale applied
                obj_eval = obj.evaluated_get(depsgraph)
                bbox_corners = [obj_eval.matrix_world @ Vector(corner) for corner in obj_eval.bound_box]
                min_coord = Vector((min(v[0] for v in bbox_corners), min(v[1] for v in bbox_corners), min(v[2] for v in bbox_corners)))
                max_coord = Vector((max(v[0] for v in bbox_corners), max(v[1] for v in bbox_corners), max(v[2] for v in bbox_corners)))
                bbox_dimensions = max_coord - min_coord
                bbox_location = (max_coord + min_coord) / 2
                
                # Set position and rotation
                lattice_object.location = bbox_location
                lattice_object.rotation_euler = obj.rotation_euler
                
                # Set SCALE instead of dimensions (this is what works!)
                lattice_object.scale.x = bbox_dimensions.x * self.scale_factor[0]
                lattice_object.scale.y = bbox_dimensions.y * self.scale_factor[1]
                lattice_object.scale.z = bbox_dimensions.z * self.scale_factor[2]
                
            else:
                tmp_obj = None
                try:
                    # On duplique l'objet
                    tmp_obj = obj.copy()
                    tmp_obj.data = obj.data.copy()
                    context.collection.objects.link(tmp_obj)
                    context.view_layer.objects.active = tmp_obj
                    tmp_obj.select_set(True)
                    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

                    # On supprime le mirror AVANT d'appliquer les modificateurs
                    for mod in tmp_obj.modifiers:
                        if mod.type == 'MIRROR':
                            tmp_obj.modifiers.remove(mod)

                    bpy.ops.object.convert(target='MESH')

                    # Calculer la bounding box de l'objet temporaire SANS le mirror
                    tmp_obj_eval = tmp_obj.evaluated_get(depsgraph)
                    bbox_corners = [tmp_obj_eval.matrix_world @ Vector(corner) for corner in tmp_obj_eval.bound_box]
                    min_coord = Vector((min(v[0] for v in bbox_corners), min(v[1] for v in bbox_corners), min(v[2] for v in bbox_corners)))
                    max_coord = Vector((max(v[0] for v in bbox_corners), max(v[1] for v in bbox_corners), max(v[2] for v in bbox_corners)))
                    bbox_dimensions = max_coord - min_coord
                    bbox_location = (max_coord + min_coord) / 2

                    # Create lattice only once
                    if lattice_object is None:
                        bpy.ops.object.add(radius=1, type='LATTICE', align='WORLD', enter_editmode=False, location=(0, 0, 0))
                        lattice_object = context.active_object

                    # Set position and rotation
                    lattice_object.location = bbox_location
                    lattice_object.rotation_euler = tmp_obj.rotation_euler
                    
                    # Set SCALE instead of dimensions (this is what works!)
                    lattice_object.scale.x = bbox_dimensions.x * self.scale_factor[0]
                    lattice_object.scale.y = bbox_dimensions.y * self.scale_factor[1]
                    lattice_object.scale.z = bbox_dimensions.z * self.scale_factor[2]

                finally:
                    # Nettoyage de l'objet temporaire
                    if tmp_obj:
                        bpy.data.objects.remove(tmp_obj, do_unlink=True)

        # Ensure updates are applied
        context.view_layer.update()

        # Use lattice_object instead of bound_box
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            newMod = obj.modifiers.new("Lattice", 'LATTICE')
            bpy.ops.object.modifier_move_to_index(modifier="Lattice", index=0)

            newMod.object = lattice_object

            # Assign Vertex Group
            for v in bpy.context.object.vertex_groups:
                newMod.vertex_group = "SpeedLattice_Group"

        # #Affiche le mirror
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            if obj.modifiers:
                if "Mirror" in obj.modifiers:
                    context.object.modifiers["Mirror"].show_viewport = True

        #On deselectionne tout et on supprime le BBox_Object
        if "BBox_Object" in context.scene.objects:

            bpy.ops.object.select_all(action='DESELECT')
            bpy.data.objects["BBox_Object"].select_set(state=True)
            bpy.ops.object.delete(use_global=False)

        #Make Lattice Active object
        bpy.ops.object.select_all(action='DESELECT')
        lattice_object.select_set(state=True)
        context.view_layer.objects.active = lattice_object

        bpy.ops.object.mode_set(mode = 'EDIT')
        # bpy.ops.lattice.select_all(action='SELECT')


        del(obj_list[:])

        bpy.context.scene.cursor.location[0] = 0
        bpy.context.scene.cursor.location[1] = 0
        bpy.context.scene.cursor.location[2] = 0

        return {"FINISHED"}

class SPEEDSCULPT_OT_remove_lattice_modifier(bpy.types.Operator):
    bl_idname = "object.remove_lattice_modifier"
    bl_label = "Remove Lattice Modifier" 
    bl_description = "Remove Lattice from selected objects"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        obj_list = [obj for obj in context.selected_objects]
        
        # Store current mode
        current_mode = obj.mode

        # Switch to object mode if needed
        if current_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
        
        bpy.ops.object.select_all(action='DESELECT')
            
        for obj in obj_list:
            context.view_layer.objects.active = obj
            
            # Remove all lattice modifiers
            lattice_mods = [mod for mod in obj.modifiers if mod.type == 'LATTICE']
            for mod in lattice_mods:
                obj.modifiers.remove(mod)
                
        # Restore previous mode
        if current_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode=current_mode)
        
        del(obj_list[:]) 
        return {"FINISHED"}
    
class SPEEDSCULPT_OT_apply_lattice_modifier(bpy.types.Operator):
    bl_idname = "object.apply_lattice_modifier"
    bl_label = "Apply Lattice Modifier"
    bl_description = "Apply Lattice on selected objects"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        obj = context.active_object
        obj_list = [obj for obj in context.selected_objects]

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        view_layer_objects = set(o.name for o in context.view_layer.objects)

        for obj in obj_list:
            if obj.name not in view_layer_objects:
                # Skip objects not in view layer to avoid selection errors
                continue
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            lattice_mods = [mod for mod in obj.modifiers if mod.type == "LATTICE"]
            for mod in lattice_mods:
                if bpy.app.version >= (2, 90, 0):
                    bpy.ops.object.modifier_apply(modifier=mod.name)
                else:
                    bpy.ops.object.modifier_apply(apply_as='DATA', modifier=mod.name)

            # Remove Vgroup
            # Need to make a copy of the list to avoid removing during iteration
            remove_vgroups = [vgroup for vgroup in obj.vertex_groups if vgroup.name == "SpeedLattice_Group"]
            for vgroup in remove_vgroups:
                obj.vertex_groups.remove(vgroup)

        del(obj_list[:])    
        return {"FINISHED"}

class SPEEDSCULPT_OT_delete_lattice(bpy.types.Operator):
    bl_idname = "object.delete_lattice"
    bl_label = "Delete Lattice"
    bl_description = "Remove the Lattice"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        bpy.ops.object.delete(use_global=False)
        return {"FINISHED"}

class SPEEDSCULPT_OT_apply_lattice_objects(bpy.types.Operator):
    bl_idname = "object.apply_lattice_objects"
    bl_label = "Apply Lattice Objects"
    bl_description = "Apply Lattice on all objects and Delete the Lattice"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        act_obj = context.active_object.name
        active_lattice = context.active_object
        
        bpy.ops.object.mode_set(mode = 'OBJECT')
        bpy.ops.object.select_all(action='DESELECT')
        for obj in bpy.data.objects:
            if obj.type == 'MESH':
                lattice = False
                for mod in obj.modifiers:
                    if mod.type == "LATTICE":
                        lattice = True
                        
                if lattice :
                    obj.select_set(state=True)
                    context.view_layer.objects.active = obj
                    if act_obj in bpy.context.object.modifiers:
                        if bpy.app.version >= (2, 90, 0):
                            bpy.ops.object.modifier_apply(modifier=act_obj)
                        else:
                            bpy.ops.object.modifier_apply(apply_as='DATA', modifier=act_obj)
                        
                        #Remove Vertex Group
                        for vgroup in obj.vertex_groups:
                            if vgroup.name == "SpeedLattice_Group":
                                obj.vertex_groups.remove(vgroup)
                        
        bpy.ops.object.select_all(action='DESELECT')

        active_lattice.select_set(state=True)
        context.view_layer.objects.active = active_lattice
        bpy.ops.object.delete(use_global=False)
 
        
        return {"FINISHED"}

class SPEEDSCULPT_OT_remove_lattice_objects(bpy.types.Operator):
    bl_idname = "object.remove_lattice_objects"
    bl_label = "Remove Lattice Objects"
    bl_description = "Remove Lattice on all objects and Delete the Lattice"
    bl_options = {"REGISTER","UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        act_obj = context.active_object.name
        active_lattice = context.active_object

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.select_all(action='DESELECT')

        # Only operate on objects in current view layer
        objects_in_view_layer = [obj for obj in context.view_layer.objects if obj.type == 'MESH']
        for obj in objects_in_view_layer:
            lattice = False
            for mod in obj.modifiers:
                if mod.type == "LATTICE":
                    lattice = True
            if lattice:
                # Try to select object only if selectable
                try:
                    obj.select_set(state=True)
                except RuntimeError:
                    continue
                context.view_layer.objects.active = obj
                if act_obj in [m.name for m in obj.modifiers]:
                    bpy.ops.object.modifier_remove(modifier=act_obj)

                    for vgroup in obj.vertex_groups:
                        if vgroup.name == "SpeedLattice_Group":
                            obj.vertex_groups.remove(vgroup)

        bpy.ops.object.select_all(action='DESELECT')

        # Only select and delete the lattice if it's in the current view layer
        if active_lattice.name in context.view_layer.objects:
            context.view_layer.objects.active = active_lattice
            try:
                active_lattice.select_set(state=True)
            except RuntimeError:
                pass
            bpy.ops.object.delete(use_global=False)

        return {"FINISHED"}

# class SPEEDSCULPT_OT_remove_lattice_objects(bpy.types.Operator):
#     bl_idname = "object.remove_lattice_objects"
#     bl_label = "Remove Lattice Objects"
#     bl_description = "Remove Lattice on all objects and Delete the Lattice"
#     bl_options = {"REGISTER","UNDO"}

#     @classmethod
#     def poll(cls, context):
#         return True

#     def execute(self, context):
#         act_obj = context.active_object.name
#         active_lattice = context.active_object
        
#         bpy.ops.object.mode_set(mode = 'OBJECT') 
#         bpy.ops.object.select_all(action='DESELECT')
#         for obj in bpy.data.objects:                
#             if obj.type == 'MESH':                  
#                 lattice = False
#                 for mod in obj.modifiers:
#                     if mod.type == "LATTICE":
#                         lattice = True
#                 if lattice :
#                     obj.select_set(state=True)
#                     context.view_layer.objects.active = obj
#                     if act_obj in bpy.context.object.modifiers: 
#                         bpy.ops.object.modifier_remove(modifier=act_obj)  
                        
#                         for vgroup in obj.vertex_groups:
#                             if vgroup.name == "SpeedLattice_Group":
#                                 obj.vertex_groups.remove(vgroup)
                                
                                
#         bpy.ops.object.select_all(action='DESELECT')

#         active_lattice.select_set(state=True)
#         context.view_layer.objects.active = active_lattice
#         bpy.ops.object.delete(use_global=False)
 
        
#         return {"FINISHED"}                

class SPEEDSCULPT_OT_connect_lattice(bpy.types.Operator):
    bl_idname = "object.connect_lattice"
    bl_label = "Connect Object To Lattice"
    bl_description = "Connect Objects to selected Lattice"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        actObj = context.active_object        
        for selObj in context.selected_objects:
            if selObj != context.active_object and(selObj.type == "MESH"):
                if not "Lattice" in selObj.modifiers:
                    newMod = selObj.modifiers.new("Lattice", 'LATTICE')
                    newMod.object = actObj

                context.view_layer.objects.active = selObj
                # bpy.context.scene.objects.active = selObj
                bpy.ops.object.select_all(action='DESELECT')
                
            selObj.select_set(state=True)
            for vgroup in selObj.vertex_groups:
                if vgroup.name == "SpeedLattice_Group":
                    for mod in bpy.context.active_object.modifiers:
                        mod.vertex_group = "SpeedLattice_Group"
                      
                        
        return {"FINISHED"}
        
#Interpolation
def LatticeInterpolation(self, context):
    speedsculpt = context.scene.speedsculpt
    
    context.object.data.interpolation_type_u = speedsculpt.lattice_interp
    context.object.data.interpolation_type_v = speedsculpt.lattice_interp
    context.object.data.interpolation_type_w = speedsculpt.lattice_interp

CLASSES =  [SPEEDSCULPT_OT_connect_lattice,
            SPEEDSCULPT_OT_remove_lattice_objects,
            SPEEDSCULPT_OT_apply_lattice_objects,
            SPEEDSCULPT_OT_delete_lattice,
            SPEEDSCULPT_OT_apply_lattice_modifier,
            SPEEDSCULPT_OT_remove_lattice_modifier,
            SPEEDSCULPT_OT_add_lattice,
            SPEEDSCULPT_OT_valid_lattice_mask,
            SPEEDSCULPT_OT_lattice_smooth_mask,
            SPEEDSCULPT_OT_lattice_add_mask,
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)
    

                