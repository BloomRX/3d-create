'''
Copyright (C) 2015 Pistiwique, Pitiwazou
 
Created by Pistiwique, Pitiwazou
 
    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
 
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
 
    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''


import os
import bpy
import bpy.utils.previews

speedsculpt_icon_collections = {}
speedsculpt_icons_loaded = False


def load_icons():
    global speedsculpt_icon_collections
    global speedsculpt_icons_loaded

    if speedsculpt_icons_loaded: return speedsculpt_icon_collections["main"]

    custom_icons = bpy.utils.previews.new()

    icons_dir = os.path.join(os.path.dirname(__file__))

    # modals
    custom_icons.load("icon_market", os.path.join(icons_dir, "market.png"), 'IMAGE')
    custom_icons.load("icon_artstation", os.path.join(icons_dir, "artstation.png"), 'IMAGE')
    custom_icons.load("icon_gumroad", os.path.join(icons_dir, "gumroad.png"), 'IMAGE')
    custom_icons.load("icon_youtube", os.path.join(icons_dir, "youtube.png"), 'IMAGE')
    custom_icons.load("icon_tutocom", os.path.join(icons_dir, "tutocom.png"), 'IMAGE')
    custom_icons.load("icon_discord", os.path.join(icons_dir, "discord.png"), 'IMAGE')
    custom_icons.load("icon_twitter", os.path.join(icons_dir, "twitter.png"), 'IMAGE')
    custom_icons.load("icon_web", os.path.join(icons_dir, "web.png"), 'IMAGE')
    custom_icons.load("icon_patreon", os.path.join(icons_dir, "patreon.png"), 'IMAGE')
    custom_icons.load("icon_facebook", os.path.join(icons_dir, "facebook.png"), 'IMAGE')
    custom_icons.load("icon_tipeee", os.path.join(icons_dir, "tipeee.png"), 'IMAGE')
    custom_icons.load("icon_instagram", os.path.join(icons_dir, "instagram.png"), 'IMAGE')



    custom_icons.load("icon_sym_plus_x", os.path.join(icons_dir, "sym_plus_x.png"), 'IMAGE')
    custom_icons.load("icon_sym_minus_x", os.path.join(icons_dir, "sym_minus_x.png"), 'IMAGE')
    custom_icons.load("icon_sym_plus_y", os.path.join(icons_dir, "sym_plus_y.png"), 'IMAGE')
    custom_icons.load("icon_sym_minus_y", os.path.join(icons_dir, "sym_minus_y.png"), 'IMAGE')
    custom_icons.load("icon_sym_plus_z", os.path.join(icons_dir, "sym_plus_z.png"), 'IMAGE')
    custom_icons.load("icon_sym_minus_z", os.path.join(icons_dir, "sym_minus_z.png"), 'IMAGE')

    custom_icons.load("icon_symmetrize", os.path.join(icons_dir, "symmetrize.png"), 'IMAGE')
    custom_icons.load("icon_speedsculpt", os.path.join(icons_dir, "speedsculpt.png"), 'IMAGE')
    custom_icons.load("icon_surface", os.path.join(icons_dir, "surface.png"), 'IMAGE')
    custom_icons.load("icon_enveloppe", os.path.join(icons_dir, "enveloppe.png"), 'IMAGE')
    custom_icons.load("icon_lathe", os.path.join(icons_dir, "lathe.png"), 'IMAGE')
    custom_icons.load("icon_curve", os.path.join(icons_dir, "curve.png"), 'IMAGE')
    custom_icons.load("icon_skin", os.path.join(icons_dir, "skin.png"), 'IMAGE')
    custom_icons.load("icon_cutter", os.path.join(icons_dir, "cutter.png"), 'IMAGE')
    custom_icons.load("icon_s", os.path.join(icons_dir, "s.png"), 'IMAGE')
    custom_icons.load("icon_u", os.path.join(icons_dir, "u.png"), 'IMAGE')
    custom_icons.load("icon_corrective_smooth", os.path.join(icons_dir, "corrective_smooth.png"), 'IMAGE')
    custom_icons.load("icon_options", os.path.join(icons_dir, "options.png"), 'IMAGE')
    custom_icons.load("icon_draw_mesh", os.path.join(icons_dir, "draw_mesh.png"), 'IMAGE')
    custom_icons.load("icon_draw_skin", os.path.join(icons_dir, "draw_skin.png"), 'IMAGE')
    custom_icons.load("icon_bevel", os.path.join(icons_dir, "bevel.png"), 'IMAGE')
    custom_icons.load("icon_subsurf", os.path.join(icons_dir, "subsurf.png"), 'IMAGE')
    custom_icons.load("icon_union", os.path.join(icons_dir, "union.png"), 'IMAGE')
    custom_icons.load("icon_difference", os.path.join(icons_dir, "difference.png"), 'IMAGE')
    custom_icons.load("icon_rebool", os.path.join(icons_dir, "rebool.png"), 'IMAGE')
    custom_icons.load("icon_lattice", os.path.join(icons_dir, "lattice.png"), 'IMAGE')
    custom_icons.load("icon_quick_pose", os.path.join(icons_dir, "quick_pose.png"), 'IMAGE')
    custom_icons.load("icon_bones", os.path.join(icons_dir, "bones.png"), 'IMAGE')
    custom_icons.load("icon_pose", os.path.join(icons_dir, "pose.png"), 'IMAGE')
    custom_icons.load("icon_primitives", os.path.join(icons_dir, "primitives.png"), 'IMAGE')
    custom_icons.load("icon_tools", os.path.join(icons_dir, "tools.png"), 'IMAGE')
    custom_icons.load("icon_library", os.path.join(icons_dir, "library.png"), 'IMAGE')
    custom_icons.load("icon_mask", os.path.join(icons_dir, "mask.png"), 'IMAGE')
    custom_icons.load("icon_hook", os.path.join(icons_dir, "hook.png"), 'IMAGE')
    custom_icons.load("icon_empty", os.path.join(icons_dir, "empty.png"), 'IMAGE')
    custom_icons.load("icon_remesh", os.path.join(icons_dir, "remesh.png"), 'IMAGE')
    custom_icons.load("icon_decimate", os.path.join(icons_dir, "decimate.png"), 'IMAGE')
    custom_icons.load("icon_valid", os.path.join(icons_dir, "valid.png"), 'IMAGE')
    custom_icons.load("icon_import", os.path.join(icons_dir, "import.png"), 'IMAGE')
    custom_icons.load("icon_blanck", os.path.join(icons_dir, "blanck.png"), 'IMAGE')
    custom_icons.load("icon_shading", os.path.join(icons_dir, "shading.png"), 'IMAGE')
    custom_icons.load("icon_muscles", os.path.join(icons_dir, "muscles.png"), 'IMAGE')
    custom_icons.load("icon_quadriflow", os.path.join(icons_dir, "quadriflow.png"), 'IMAGE')
    custom_icons.load("icon_face_set", os.path.join(icons_dir, "face_set.png"), 'IMAGE')
    custom_icons.load("icon_clipping", os.path.join(icons_dir, "clipping.png"), 'IMAGE')
    custom_icons.load("icon_solidify", os.path.join(icons_dir, "solidify.png"), 'IMAGE')
    custom_icons.load("icon_geomesh", os.path.join(icons_dir, "geomesh.png"), 'IMAGE')
    custom_icons.load("icon_add", os.path.join(icons_dir, "add.png"), 'IMAGE')
    custom_icons.load("icon_mirror_off", os.path.join(icons_dir, "mirror_off.png"), 'IMAGE')
    custom_icons.load("icon_mirror_on", os.path.join(icons_dir, "mirror_on.png"), 'IMAGE')
    custom_icons.load("icon_grid", os.path.join(icons_dir, "grid.png"), 'IMAGE')

    custom_icons.load("icon_isolate", os.path.join(icons_dir, "isolate.png"), 'IMAGE')
    custom_icons.load("icon_exit_isolate", os.path.join(icons_dir, "exit_isolate.png"), 'IMAGE')
    custom_icons.load("icon_symmetrize_selection", os.path.join(icons_dir, "symmetrize_selection.png"), 'IMAGE')
    custom_icons.load("icon_flip_x", os.path.join(icons_dir, "flip_x.png"), 'IMAGE')
    custom_icons.load("icon_flip_y", os.path.join(icons_dir, "flip_y.png"), 'IMAGE')
    custom_icons.load("icon_flip_z", os.path.join(icons_dir, "flip_z.png"), 'IMAGE')
    custom_icons.load("icon_draw_curve", os.path.join(icons_dir, "draw_curve.png"), 'IMAGE')
    custom_icons.load("icon_backup", os.path.join(icons_dir, "backup.png"), 'IMAGE')
    custom_icons.load("icon_trash", os.path.join(icons_dir, "trash.png"), 'IMAGE')
    custom_icons.load("icon_backup_mesh", os.path.join(icons_dir, "backup_mesh.png"), 'IMAGE')
    custom_icons.load("icon_mesh", os.path.join(icons_dir, "mesh.png"), 'IMAGE')
    custom_icons.load("icon_collection", os.path.join(icons_dir, "collection.png"), 'IMAGE')
    custom_icons.load("icon_list", os.path.join(icons_dir, "list.png"), 'IMAGE')
    custom_icons.load("icon_superhive", os.path.join(icons_dir, "superhive.png"), 'IMAGE')
    custom_icons.load("icon_delete", os.path.join(icons_dir, "delete.png"), 'IMAGE')
    custom_icons.load("icon_array_curve", os.path.join(icons_dir, "array_curve.png"), 'IMAGE')

    # TIMELAPSE ICONS
    custom_icons.load("icon_camera", os.path.join(icons_dir, "camera.png"), 'IMAGE')
    custom_icons.load("icon_timelapse_horizontal", os.path.join(icons_dir, "timelapse_horizontal.png"), 'IMAGE')
    custom_icons.load("icon_timelapse_vertical", os.path.join(icons_dir, "timelapse_vertical.png"), 'IMAGE')
    custom_icons.load("icon_timelapse_square", os.path.join(icons_dir, "timelapse_square.png"), 'IMAGE')
    custom_icons.load("icon_timelapse", os.path.join(icons_dir, "timelapse.png"), 'IMAGE')
    custom_icons.load("icon_search_in_folder", os.path.join(icons_dir, "search_in_folder.png"), 'IMAGE')

    # TOOLS
    
    custom_icons.load("icon_line_project", os.path.join(icons_dir, "line_project.png"), 'IMAGE')
    custom_icons.load("icon_trim", os.path.join(icons_dir, "trim.png"), 'IMAGE')
    custom_icons.load("icon_copy", os.path.join(icons_dir, "copy.png"), 'IMAGE')
    custom_icons.load("icon_modifiers", os.path.join(icons_dir, "modifiers.png"), 'IMAGE')
    custom_icons.load("icon_group", os.path.join(icons_dir, "group.png"), 'IMAGE')
    custom_icons.load("icon_separate", os.path.join(icons_dir, "separate.png"), 'IMAGE')
    custom_icons.load("icon_cursor", os.path.join(icons_dir, "cursor.png"), 'IMAGE')
    custom_icons.load("icon_parent", os.path.join(icons_dir, "parent.png"), 'IMAGE')
    custom_icons.load("icon_object", os.path.join(icons_dir, "object.png"), 'IMAGE')
    custom_icons.load("icon_areas", os.path.join(icons_dir, "areas.png"), 'IMAGE')
    custom_icons.load("icon_areas_off", os.path.join(icons_dir, "areas_off.png"), 'IMAGE')
    custom_icons.load("icon_cursor_off", os.path.join(icons_dir, "cursor_off.png"), 'IMAGE')
    custom_icons.load("icon_brush", os.path.join(icons_dir, "brush.png"), 'IMAGE')

    speedsculpt_icon_collections["main"] = custom_icons
    speedsculpt_icons_loaded = True

    return speedsculpt_icon_collections["main"]


def speedsculpt_clear_icons():
    global speedsculpt_icons_loaded
    for icon in speedsculpt_icon_collections.values():
        bpy.utils.previews.remove(icon)
    speedsculpt_icon_collections.clear()
    speedsculpt_icons_loaded = False