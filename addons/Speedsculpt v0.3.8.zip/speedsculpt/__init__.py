'''-*- coding:utf-8 -*-
SpeedSculpt Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

bl_info = {
    "name": "SpeedSculpt",
    "description": "Create models for sculpt and manage Dyntopo sculpt",
    "author": "pitiwazou",
    "version": (0, 3, 8),
    "blender": (4, 3, 0),
    "location": "Property Panel, Press N in the 3DView",
    "doc_url": "https://blscripts.notion.site/SPEEDSCULPT-607c7a94883248b6aed67ded368714f4",
    "category": "3D View"}

# Import des modules
if "bpy" in locals():
    import importlib
    reloadable_modules = [
        "armature",
        "curves",
        "extract_mask",
        "lattice",
        "operators",
        "primitives",
        "quick_pose",
        "remesh_decimate",
        "solo",
        "symmetrize",
        "ui",
        "preview",
        "modals",
        "cutter",
        "timelapse"
    ]
    for module in reloadable_modules:
        if module in locals():
            importlib.reload(locals()[module])

from . import  (armature,
                curves,
                extract_mask,
                functions,
                operators,
                lattice,
                primitives,
                quick_pose,
                remesh_decimate,
                solo,
                symmetrize,
                ui,
                preview,
                modals,
                cutter,
                timelapse,
                )

import bpy
from bpy.types import Operator, Menu, Panel, PropertyGroup, AddonPreferences, Scene, WindowManager, BlendData
from bpy.props import (StringProperty,
                       BoolProperty,
                       PointerProperty,
                       FloatVectorProperty,
                       FloatProperty,
                       EnumProperty,
                       IntProperty,
                       BoolVectorProperty,
                       CollectionProperty)
import urllib.request
import json
import sys
import os
from .ui import *
from .icon.icons import load_icons, speedsculpt_clear_icons
from .remesh_decimate import RemeshOctreeDepth
from .primitives import UpdateMetaballs, ClippingMerge
from .lattice import HideLattice, LatticeInterpolation
from .remesh_decimate import HideRemeshSmooth,RemeshSmoothRepeat, Hidedecimate, DecimateRatio
from .functions import *
import rna_keymap_ui
from bpy.app.handlers import persistent
from bpy_extras.io_utils import ImportHelper, ExportHelper
from .ui import draw_troubleshooting
# -----------------------------------------------------
# CATEGORY
# -----------------------------------------------------
def SC_update_panel(self, context):
    prefs = context.preferences.addons[__name__].preferences
    if hasattr(bpy.types, 'VIEW3D_PT_speedsculpt_panel'):
        try:
            bpy.utils.unregister_class(bpy.types.VIEW3D_PT_speedsculpt_panel)
        except:
            pass
    VIEW3D_PT_speedsculpt_panel.bl_category = prefs.category
    bpy.utils.register_class(VIEW3D_PT_speedsculpt_panel)

# -----------------------------------------------------
# LIBRARY
# -----------------------------------------------------
class SPEEDSCULPT_PropertyGroup_categories(PropertyGroup):
    path : StringProperty(subtype = 'DIR_PATH') # type: ignore

class SPEEDSCULPT_OT_add_categories_path(Operator):
    bl_idname = "object.speedsculpt_add_categories_path"
    bl_label = "Add Categories Path"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        addon_pref = get_addon_preferences()
        addon_pref.categories.add()
        return {'FINISHED'}

class SPEEDSCULPT_OT_remove_categories_path(Operator):
    bl_idname = "object.speedsculpt_remove_categories_path"
    bl_label = "Add Categories Path"
    bl_description = ""
    bl_options = {'REGISTER', 'UNDO'}

    index : IntProperty() # type: ignore

    def execute(self, context):
        addon_pref = get_addon_preferences()
        addon_pref.categories.remove(self.index)
        return {'FINISHED'}

def call_back_enum(self, context):
    addon_pref = get_addon_preferences()
    directory = os.path.join(os.path.dirname(__file__), "library")
    mes_reps = ["body_parts", "muscles"]
    categories = [(os.path.join(directory, rep), rep, "" ) for rep in mes_reps]

    for cat in addon_pref.categories:
        root, dirs, files = next(os.walk(cat.path)) # on liste le path, reps et noms de fichiers
        if "files" in dirs and "icons" in dirs:
            categories.append((cat.path, os.path.basename(os.path.abspath(cat.path)), ""))

    return categories

def check_for_updates_and_notify():
    # Utiliser directement __name__ comme dans speedsculpt
    addon_idname = "speedsculpt"
    
    try:
        # URL où le fichier JSON est hébergé
        url = 'https://www.blscripts.com/blscripts_addons_updates.json'
        response = urllib.request.urlopen(url)
        data = json.load(response)

        # Get local version from bl_info directly
        local_version = bl_info['version']
        local_version_str = '.'.join(map(str, local_version))

        update_message = ""
        has_update = False

        # Check for update specific to this addon (comme dans speedsculpt)
        if addon_idname in data:
            addon_data = data[addon_idname]
            if local_version_str != addon_data['version'] and addon_data['version'] > local_version_str:
                update_message = f"New version available: {addon_data['version']} (current: {local_version_str})\n"
                has_update = True
                print("Add-on Name: " + addon_idname + " New Version: " + addon_data['version'])
            else:
                update_message = "No updates available."
                print(addon_idname + ": No Update Available")
        else:
            update_message = "No updates available."
            print(addon_idname + ": No Update Available")

        # CORRECTION : Set the update message in preferences
        try:
            preferences = bpy.context.preferences.addons[__package__].preferences
            preferences.update_available = update_message
            
            # Afficher un message d'information si une mise à jour est disponible
            try:
                online_access_enabled = bpy.context.preferences.system.use_online_access
            except AttributeError:
                online_access_enabled = True
                
            if has_update and online_access_enabled:
                bpy.ops.wm.gc_show_update_notification('INVOKE_DEFAULT')
                
        except KeyError:
            print(f"Could not find addon preferences for {__package__}")
        except Exception as e:
            pass

        return update_message  # Retourner seulement le message
        
    except Exception as e:
        error_message = f"Error checking for updates: {str(e)}"
        print(error_message)
        return error_message  # Retourner seulement le message d'erreur

class SPEEDSCULPT_OT_check_updates(bpy.types.Operator):
    bl_idname = "wm.speedsculpt_check_updates"
    bl_label = "Check for Updates"

    def execute(self, context):
        check_for_updates_and_notify()
        update_message = check_for_updates_and_notify()
        self.report({'INFO'}, update_message)
        return {'FINISHED'}

class SPEEDSCULPT_MT_addon_prefs(AddonPreferences):
    bl_idname = __name__
        
    prefs_tabs : EnumProperty(
        items=(('info', "Info", "Information about the Addon"),
               ('options', "Options", "Options of the Addon"),
               ('keymaps','Keymaps', 'Keymaps of the addon'),
               ('links', "Links", "Links")),
               default='info'
               ) # type: ignore
    category : StringProperty(name="Category",description="Choose a name for the category of the panel",default="Speedsculpt",
            update=SC_update_panel) # type: ignore
    
    # CHECK FOR UPDATES
    update_available: bpy.props.StringProperty(
        name="Update Available",
        description="Message indicating if there is an update available.",
        default="") # type: ignore

    check_for_updates: BoolProperty(name="Check for Updates",description="Check for Updates",default=False)# type: ignore

    # SHOWS
    info: BoolProperty(name="",default=False,description="INFO") # type: ignore
    show_help : BoolProperty(default=True,description="Show the help on the Addon", name="") # type: ignore
    show_warning : BoolProperty(default=True,description="Show the warning on the Addon", name="") # type: ignore
    show_troubleshooting : BoolProperty(default=False,description="Show the troubleshooting on the Addon", name="") # type: ignore
    show_remesh_settings: BoolProperty(default=False, description="Show/Hide Remesh Settings") # type: ignore
    show_dyntopo_settings: BoolProperty(default=False, description="Show/Hide Dyntopo Settings") # type: ignore
    show_library_settings: BoolProperty(default=False, description="Show/Hide Assets Library Settings") # type: ignore
    show_general_settings: BoolProperty(default=True, description="Show/Hide General Settings") # type: ignore
    show_references_settings: BoolProperty(default=True, description="Show/Hide References Settings") # type: ignore
    show_extract_remesh_settings: BoolProperty(default=False, description="Show/Hide Extract Settings") # type: ignore
    show_extract_dyntopo_settings: BoolProperty(default=False, description="Show/Hide Extract Settings") # type: ignore
    show_face_set_settings: BoolProperty(default=False, description="Show/Hide Face Set Settings") # type: ignore
    show_mask_settings: BoolProperty(default=False, description="Show/Hide Face Set Settings") # type: ignore
    show_geomesh_settings: BoolProperty(default=False, description="Show/Hide Geomesh Settings") # type: ignore
    show_shading_settings: BoolProperty(default=True, description="Show/Hide Shading Settings") # type: ignore

    # ENVIRONMENT MODAL
    env_modal_speed: FloatProperty(
            name="Env Modal Speed",
            default=1,
            min=0.001,
            max=1000,
            description="Speed of the Environment Modal") # type: ignore

    auto_save : BoolProperty(default=True,description="Auto save the scene when updating a mesh or making booleans", name="") # type: ignore
    smooth_mesh : BoolProperty(default=True,description="\nAdd a Smooth Modifier when updating the REMESH/DYNTOPO.\n\nYou can Edit the Value of the Remesh in the Settings", name="") # type: ignore
    smooth_mesh_value: IntProperty(min=1,max=10,default=2,description="Smooth Mesh Value", name="") # type: ignore
    fill_holes : BoolProperty(default=False,description="Close holes on the mesh", name="") # type: ignore
    update_detail_flood_fill : BoolProperty(default=True,description="Triangulate the Mesh", name="") # type: ignore
    add_remesh : BoolProperty(default=False,description="Add a Remesh Modifier to cut objects", name="") # type: ignore
    remesh_value : IntProperty(min=0,max=15,default=6,description="remesh value",update=RemeshOctreeDepth, name="") # type: ignore
    apply_mirror: BoolProperty(default=False, description="Apply Mirror") # type: ignore
    mirror_settings: BoolProperty(default=False, description="Show Mirror Settings") # type: ignore
    mirror_smooth_settings: BoolProperty(default=False, description="Show Mirror Settings") # type: ignore
    
    # SOLO
    sc_solo_color: FloatVectorProperty(name="", default=(0.2, 0.7, 1, 0.3), min=0, max=1, size=4,
                                       subtype='COLOR') # type: ignore
    
    # PRIMITIVE
    primitive_size: EnumProperty(
            items=(("mm", "mm",""),
                   ("cm","cm",""),
                   ("m","m",""),
                   ("custom","custom","")),
                   default="m",
                   description="Size of the Primitive") # type: ignore
    
    primitive_size_custom: FloatProperty(name="Custom Size", default=1, min=0.0001, max=10000, precision=3) # type: ignore

    add_smooth_remesh_modal: BoolProperty(default=True, name="", description="Add Smooth Remesh Modal") # type: ignore

    # REMESH / DYNTOPO
    remesh_description = "Use REMESH to automatically rebuild the geometry into Quads.\n\n" \
                         "It's faster than Dyntopo and then it's better to use it to Combine/Cut or Rebool Objects.\n\n" \
                         "You can select several Objects and combine them on the fly.\n\n" \
                         "Note: When Updating, it will Remesh the entire Mesh, you will lose details."
    dyntopo_description = "Use DYNTOPO to add details to your Sculpting.\n\n" \
                          "Dyntopo is a dynamic tessellation sculpting method that produce Tris.\n\n" \
                          "It preserve details when updating it contrary to REMESH."
    
    def update_dyntopo_or_remesh(self, context):
        """Callback function to auto-enable/disable dyntopo when switching modes"""
        if (context.object and 
            context.object.type == 'MESH' and 
            context.object.mode == 'SCULPT' and 
            context.sculpt_object):
            
            if self.dyntopo_or_remesh == 'dyntopo':
                # Enable dyntopo if it's not already active
                if not context.sculpt_object.use_dynamic_topology_sculpting:
                    try:
                        bpy.ops.sculpt.dynamic_topology_toggle()
                    except:
                        # In case the operator fails, we silently continue
                        pass
            
            elif self.dyntopo_or_remesh == 'remesh':
                # Disable dyntopo if it's currently active
                if context.sculpt_object.use_dynamic_topology_sculpting:
                    try:
                        bpy.ops.sculpt.dynamic_topology_toggle()
                    except:
                        # In case the operator fails, we silently continue
                        pass
    
    dyntopo_or_remesh : EnumProperty(
        items=(('remesh', "REMESH", remesh_description, "SPHERE", 0),
               ('dyntopo', "DYNTOPO", dyntopo_description, "MESH_ICOSPHERE", 1)),
        default='remesh',
        update=update_dyntopo_or_remesh) # type: ignore

    # REMESH
    remesh_mesh_value_description = "\n"\
                                    "Value for the Remeshing in Quads.\n" \
                                    "Smaller Value gives smaller quads.\n\n" \
                                    "Note: With huge Meshes and small values, it can take time,\n" \
                                    "make some tests before if you can"
    remesh_mesh_value: FloatProperty(default=0.1,min=0.0001, max=1000,precision=3,description=remesh_mesh_value_description, name="REMESH VALUE") # type: ignore
    remesh_mesh_voxel_adaptivity: FloatProperty(default=0,min=0, max=10,precision=3,description="Remesh Voxel Adaptivity") # type: ignore
    remesh_mesh_smooth_normals: BoolProperty(default=True,description="Smooth the normals of the mesh", name="") # type: ignore
    remesh_mesh_use_remesh_preserve_volume: BoolProperty(default=True,description="Preserve Volume", name="") # type: ignore
    remesh_mesh_preserve_paint_mask: BoolProperty(default=False,description="Preserve Paint Mask") # type: ignore
    remesh_mesh_fix_poles: BoolProperty(default=True,description="Fix Poles", name="") # type: ignore
    remesh_mesh_preserve_sculpt_face_sets: BoolProperty(default=False,description="Preserve Sculpt Face Sets", name="") # type: ignore
    remesh_mesh_preserve_attributes: BoolProperty(default=False,description="Preserve Attributes", name="") # type: ignore
    update_remesh: BoolProperty(default=True, 
                                description="\nUpdate the Topology of the mesh in REMESH/DYNTOPO according to the Settings.\n\n" \
                                "You can disable it if you want to only make some Operations.\n" \
                                "It will not Remesh the Mesh.", 
                                name="Update Topology") # type: ignore
    remesh_mesh_preserve_vertex_colors: BoolProperty(default=False,description="Preserve Vertex Color", name="") # type: ignore
    modal_smooth: BoolProperty(default=True, description="Adjust the Smooth of the Mesh with the mouse", name="") # type: ignore
    
    # LIBRARY
    show_path_info: BoolProperty(default=False) # type: ignore
    preview_scale: IntProperty(name="", default=4, min=2, max=10, description="Size of the Preview Images") # type: ignore
    preview_scale_popup: IntProperty(name="", default=5, min=2, max=10, description="Size of the Preview Images in the Popup") # type: ignore
    preview_show_labels: BoolProperty(name='', default=True, description="Show the Label of the Images") # type: ignore
    categories: CollectionProperty(type=SPEEDSCULPT_PropertyGroup_categories) # type: ignore
    
    # FLAT SHADING TOGGLE SETTINGS
    flat_shading_color_type: EnumProperty(
        name="Color Type",
        description="Color type to use in flat shading mode",
        items=[
            ('MATERIAL', "Material", "Material"),
            ('RANDOM', "Random", "Random"),
            ('TEXTURE', "Texture", "Texture"),
            ('OBJECT', "Object", "Object"),
            ('ATTRIBUTE', "Attribute", "Attribute"),
            ('SINGLE', "Single", "Single"),
        ],
        default='SINGLE'
    ) # type: ignore

    flat_shading_custom_color: FloatVectorProperty(
        name="Custom Color",
        description="Custom color to use in flat shading mode",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(1, 1, 1)
    ) # type: ignore
    
    flat_shading_toggle_overlays: BoolProperty(
        name="Toggle Overlays",
        description="Toggle overlays on/off when enabling flat shading",
        default=True
    ) # type: ignore
    
    flat_shading_use_background_color: BoolProperty(
        name="Use Background Color",
        description="Set a custom background color when enabling flat shading",
        default=True
    ) # type: ignore
    
    flat_shading_background_color: FloatVectorProperty(
        name="Background Color",
        description="Background color to use in flat shading mode",
        subtype='COLOR',
        size=3,
        min=0.0,
        max=1.0,
        default=(0, 0, 0)
    ) # type: ignore
    
    def reset_preferences(self):
        # Vérifier et réinitialiser toutes les préférences aux valeurs par défaut
        for prop in dir(self):
            if prop.startswith('__'):  # Skip built-in attributes
                continue
            try:
                self.property_unset(prop)  # Réinitialiser la propriété
            except:
                pass  # Skip if property cannot be unset


    # SAVE AND LOAD PREFERENCES
    json_directory_path: StringProperty(
        name="JSON Directory Path",
        description="Directory to save and load the preferences JSON file",
        default="",  # Chemin par défaut vide
        subtype='DIR_PATH'
    )  # type: ignore
    
    def save_preferences_to_json(self, filepath=""):
        """Sauvegarde les préférences de l'onglet Options dans un fichier JSON"""
        import json
        import os
        
        # Utiliser le filepath fourni ou celui des préférences
        if not filepath:
            if not self.json_directory_path:
                return False, "No directory specified"
            json_file_path = os.path.join(self.json_directory_path, "speedsculpt_preferences.json")
        else:
            json_file_path = filepath
        
        try:
            # Liste des propriétés à sauvegarder (uniquement celles de l'onglet Options)
            preferences_to_save = {
                # Panel settings
                'category': self.category,
                'show_help': self.show_help,
                'show_warning': self.show_warning,
                'show_troubleshooting': self.show_troubleshooting,
                'auto_save': self.auto_save,
                'smooth_mesh': self.smooth_mesh,
                'smooth_mesh_value': self.smooth_mesh_value,
                'apply_mirror': self.apply_mirror,
                'fill_holes': self.fill_holes,
                'add_smooth_remesh_modal': self.add_smooth_remesh_modal,
                'primitive_size': self.primitive_size,
                'primitive_size_custom': self.primitive_size_custom,
                'env_modal_speed': self.env_modal_speed,
                
                # Remesh settings
                'remesh_mesh_value': self.remesh_mesh_value,
                'remesh_mesh_voxel_adaptivity': self.remesh_mesh_voxel_adaptivity,
                'remesh_mesh_smooth_normals': self.remesh_mesh_smooth_normals,
                'remesh_mesh_use_remesh_preserve_volume': self.remesh_mesh_use_remesh_preserve_volume,
                'remesh_mesh_preserve_paint_mask': self.remesh_mesh_preserve_paint_mask,
                'remesh_mesh_fix_poles': self.remesh_mesh_fix_poles,
                'remesh_mesh_preserve_sculpt_face_sets': self.remesh_mesh_preserve_sculpt_face_sets,
                'remesh_mesh_preserve_attributes': self.remesh_mesh_preserve_attributes,
                'remesh_mesh_preserve_vertex_colors': self.remesh_mesh_preserve_vertex_colors,
                'modal_smooth': self.modal_smooth,
                
                # Dyntopo settings
                'update_detail_flood_fill': self.update_detail_flood_fill,
                'add_remesh': self.add_remesh,
                'remesh_value': self.remesh_value,
                
                # Shading settings
                'sc_solo_color': list(self.sc_solo_color),
                'flat_shading_color_type': self.flat_shading_color_type,
                'flat_shading_custom_color': list(self.flat_shading_custom_color),
                'flat_shading_toggle_overlays': self.flat_shading_toggle_overlays,
                'flat_shading_use_background_color': self.flat_shading_use_background_color,
                'flat_shading_background_color': list(self.flat_shading_background_color),
                
                # Library settings
                'preview_scale': self.preview_scale,
                'preview_scale_popup': self.preview_scale_popup,
                'preview_show_labels': self.preview_show_labels,
            }
            
            # Sauvegarder
            with open(json_file_path, 'w', encoding='utf-8') as json_file:
                json.dump(preferences_to_save, json_file, indent=2, ensure_ascii=False)
            
            return True, f"Preferences saved to {json_file_path}"
            
        except Exception as e:
            return False, f"Error saving preferences: {str(e)}"

    def load_preferences_from_json(self, filepath=""):
        """Charge les préférences de l'onglet Options depuis un fichier JSON"""
        import json
        import os
        
        # Utiliser le filepath fourni ou celui des préférences
        if not filepath:
            if not self.json_directory_path:
                return False, "No directory specified"
            json_file_path = os.path.join(self.json_directory_path, "speedsculpt_preferences.json")
        else:
            json_file_path = filepath
        
        if not os.path.exists(json_file_path):
            return False, f"File not found: {json_file_path}"
        
        try:
            with open(json_file_path, 'r', encoding='utf-8') as json_file:
                preferences_dict = json.load(json_file)
            
            # Charger les propriétés
            for key, value in preferences_dict.items():
                if hasattr(self, key):
                    try:
                        # Gérer les listes (couleurs)
                        if isinstance(value, list):
                            setattr(self, key, tuple(value))
                        else:
                            setattr(self, key, value)
                    except Exception as e:
                        print(f"Error setting {key}: {e}")
            
            return True, f"Preferences loaded from {json_file_path}"
            
        except Exception as e:
            return False, f"Error loading preferences: {str(e)}"

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        wm = context.window_manager

        row= layout.row(align=True)
        row.scale_y = 1.5   
        row.prop(self, "prefs_tabs", expand=True)
        if self.prefs_tabs == 'info':

            # UPDATE
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.prop(self, "check_for_updates")
            if self.check_for_updates:
                show_update = False
                if bpy.app.version < (4, 1, 0):
                    show_update = True

                elif bpy.app.version >= (4, 2, 0) and bpy.context.preferences.system.use_online_access:
                        show_update = True
                
                # box = layout.box()
                if show_update:
                    row = box.row(align=True)
                    update = True if self.update_available == "No updates available." else False
                    row.alert = update
                    row.label(text=self.update_available if self.update_available else "No updates available.")
                    row.alert = False
                    row.operator("wm.speedsculpt_check_updates", text="Check for Updates", icon='FILE_REFRESH')
                
                if bpy.app.version >= (4, 2, 0):
                    if not bpy.context.preferences.system.use_online_access:
                        row = box.row(align=True)
                        row.alert = True
                        row.label(text="Activate Allow Online Acess in the System/Network to check for updates", icon="ERROR")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_superhive")
            row.operator("wm.url_open", text="SUPERHIVE",
                         icon_value=icon.icon_id).url = "https://superhivemarket.com/products/speedsculpt"
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/l/SpeedSculpt"
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://pitiwazou.artstation.com/store/JmKn/speedsculpt"

            # CUSTOMERS
            box = layout.box()
            icon = icons.get("icon_discord")
            row = box.row(align=True)
            row.scale_y = 2
            row.operator("wm.url_open", text="SUPPORT ON DISCORD FOR CUSTOMERS",
                         icon_value=icon.icon_id).url = "https://discord.gg/8M8mFVegZ8"
            row.scale_x = 2
            row.prop(self, 'info', icon='INFO')
            if self.info:
                box = layout.box()
                split = box.split()
                col = split.column()
                row = col.row(align=True)
                row.label(text="Join our Discord community for customer support! As a valued customer, you’ll gain access to exclusive benefits:")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="1. Add-on Support Channel: To access this channel, simply send us a copy of your receipt to our email address below.")
                row = col.row(align=True)
                row.label(text="2. Latest Builds: Stay up-to-date with the latest builds of our add-ons.")
                row = col.row(align=True)
                row.label(text="3. Feature Requests: Have a feature in mind? Feel free to ask—we’re here to listen!")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="🔗 Discord Invite Link: https://discord.gg/8M8mFVegZ8")
                row = col.row(align=True)
                row.label(text="📧 Email: mail.blscripts@gmail.com")
                row = col.row(align=True)
                row.separator()
                row = col.row(align=True)
                row.label(text="Thank you for supporting our work! If you haven’t purchased the add-on yet, ")
                row = col.row(align=True)
                row.label(text="consider doing so it helps sustain years of effort and support for all our add-ons.")

            draw_troubleshooting(self, context, layout)
            
            box = layout.box()
            box.label(text="Welcome to SpeedSculpt, this addon allows you to create objects for sculpting")
            box.label(text="You can make booleans, adjust the Detail Size etc")
            box.separator()
            box.label(text="Note: The Addon is located in the Property Panel, Press N in the 3DView.")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_youtube")
            row.operator("wm.url_open", text="DOCUMENTATION",
                            icon_value=icon.icon_id).url = "https://youtu.be/6BFCV7jobrM"

            
        if self.prefs_tabs == 'options':

            # GENERAL SETTINGS
            box = layout.box()
            row = box.row()
            row.scale_y = 1.3
            row.operator("object.speedsculpt_save_options_preferences", text="Save Preferences", icon='FILE_TICK')
            row.operator("object.speedsculpt_load_options_preferences", text="Load Preferences", icon='FILEBROWSER')
            row.operator("object.speedsculpt_reset_preferences", text="Reset Preferences", icon='RECOVER_LAST')

            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='SETTINGS')
            row.prop(self, "show_general_settings", text="GENERAL SETTINGS",
                     icon='TRIA_UP' if self.show_general_settings else 'TRIA_RIGHT')
            if self.show_general_settings:
                split = box.split()
                col = split.column()
                col.label(text="Change Category")
                col = split.column(align=True)
                col.prop(self, "category", text="")

                split = box.split()
                col = split.column()
                col.label(text="Show Help")
                col = split.column(align=True)
                col.prop(self, "show_help")

                split = box.split()
                col = split.column()
                col.label(text="Show Warning")
                col = split.column(align=True)
                col.prop(self, "show_warning")

                split = box.split()
                col = split.column()
                col.label(text="Show Troubleshooting")
                col = split.column(align=True)
                col.prop(self, "show_troubleshooting")

                if sys.platform.startswith('win'):
                    split = box.split()
                    col = split.column()
                    col.label(text="Auto Save Scene")
                    col = split.column(align=True)
                    col.prop(self, "auto_save")
                
                split = box.split()
                col = split.column()
                col.label(text="Apply Mirror")
                col = split.column(align=True)
                col.prop(self, "apply_mirror")
                
                split = box.split()
                col = split.column()
                col.label(text="Shade Smooth")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_smooth_normals")

                split = box.split()
                col = split.column()
                col.label(text="Fill Holes")
                col = split.column(align=True)
                col.prop(self, "fill_holes")

                split = box.split()
                col = split.column()
                col.label(text="Smooth the Mesh")
                col = split.column(align=True)
                col.prop(self, "smooth_mesh")

                if self.smooth_mesh:
                    split = box.split()
                    col = split.column()
                    col.label(text="Smooth Mesh Value")
                    col = split.column(align=True)
                    col.prop(self, "smooth_mesh_value", text="")


                split = box.split()
                col = split.column()
                col.label(text="Add Smooth in the Remesh Modal")
                col = split.column(align=True)
                col.prop(self, "add_smooth_remesh_modal", text="")

                split = box.split()
                col = split.column()
                col.label(text="Primitive Size")
                col = split.column(align=True)
                col.prop(self, "primitive_size", expand=True)

                row = box.row(align=True)
                row.label(text="Environment Modal Speed")
                row.prop(self, "env_modal_speed", text="")

            # REMESH SETTINGS
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='SPHERE')
            row.prop(self, "show_remesh_settings", text="REMESH SETTINGS",
                     icon='TRIA_UP' if self.show_remesh_settings else 'TRIA_RIGHT')
            if self.show_remesh_settings:
                split = box.split()
                col = split.column()
                col.label(text="Remesh Value")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_value", text="")

                split = box.split()
                col = split.column()
                col.label(text="Voxel Adaptibility")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_voxel_adaptivity", text="")

                split = box.split()
                col = split.column()
                col.label(text="Fix Poles")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_fix_poles")

                split = box.split()
                col = split.column()
                col.label(text="Preserve Volume")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_use_remesh_preserve_volume")

                if bpy.app.version < (4, 1, 0):
                    split = box.split()
                    col = split.column()
                    col.label(text="Preserve Paint Mask")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_preserve_paint_mask")

                    split = box.split()
                    col = split.column()
                    col.label(text="Preserve Sculpt Face Sets")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_preserve_sculpt_face_sets")

                    split = box.split()
                    col = split.column()
                    col.label(text="Preserve Vertex Colors")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_preserve_vertex_colors")

                if bpy.app.version >= (4, 1, 0):
                    split = box.split()
                    col = split.column()
                    col.label(text="Preserve Attributes")
                    col = split.column(align=True)
                    col.prop(self, "remesh_mesh_preserve_attributes")

                split = box.split()
                col = split.column()
                col.label(text="Modal Smooth")
                col = split.column(align=True)
                col.prop(self, "modal_smooth")

            # DYNTOPO SETTINGS
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='MESH_ICOSPHERE')
            row.prop(self, "show_dyntopo_settings", text="DYNTOPO SETTINGS",
                     icon='TRIA_UP' if self.show_dyntopo_settings else 'TRIA_RIGHT')
            if self.show_dyntopo_settings:
                split = box.split()
                col = split.column()
                col.label(text="Update the Mesh")
                col = split.column(align=True)
                col.prop(self, "update_detail_flood_fill")

                split = box.split()
                col = split.column()
                col.label(text="Smooth Shading")
                col = split.column(align=True)
                col.prop(self, "remesh_mesh_smooth_normals")

                split = box.split()
                col = split.column()
                col.label(text="Add Remesh Modifier to cut object")
                col = split.column(align=True)
                col.prop(self, "add_remesh")

                split = box.split()
                col = split.column()
                col.label(text="Remesh Value")
                col = split.column(align=True)
                col.prop(self, "remesh_value", text="")

            # SHADING SETTINGS
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='SHADING_RENDERED')
            row.prop(self, "show_shading_settings", text="SHADING",
                     icon='TRIA_UP' if self.show_shading_settings else 'TRIA_RIGHT')
            if self.show_shading_settings:
                split = box.split()
                col = split.column()
                col.label(text="Solo Color")
                col = split.column(align=True)
                col.prop(self, "sc_solo_color", text="")

                # Flat Shading Toggle Settings
                box.separator()
                row = box.row(align=True)
                row.label(text="Silhouette Toggle Settings", icon='SHADING_SOLID')
                
                split = box.split()
                col = split.column()
                col.label(text="Color Type")
                col = split.column(align=True)
                col.prop(self, "flat_shading_color_type", text="")

                if self.flat_shading_color_type == 'SINGLE':
                    split = box.split()
                    col = split.column()
                    col.label(text="Custom Color")
                    col = split.column(align=True)
                    col.prop(self, "flat_shading_custom_color", text="")
                
                split = box.split()
                col = split.column()
                col.label(text="Disable Overlays")
                col = split.column(align=True)
                col.prop(self, "flat_shading_toggle_overlays", text="")
                
                split = box.split()
                col = split.column()
                col.label(text="Use Background Color")
                col = split.column(align=True)
                col.prop(self, "flat_shading_use_background_color", text="")
                
                if self.flat_shading_use_background_color:
                    split = box.split()
                    col = split.column()
                    col.label(text="Background Color")
                    col = split.column(align=True)
                    col.prop(self, "flat_shading_background_color", text="")

            # LIBRARY SETTINGS
            box = layout.box()
            row = box.row(align=True)
            row.scale_y = 1.5
            row.label(text="", icon='MONKEY')
            row.prop(self, "show_library_settings", text="ASSETS LIBRARY SETTINGS",
                     icon='TRIA_UP' if self.show_library_settings else 'TRIA_RIGHT')
            if self.show_library_settings:
                split = box.split()
                col = split.column()
                row = col.row(align=True)
                row.label(text="ASSET LIBRARY SETTINGS")
                row = col.row(align=True)
                row.label(text="Preview Thumbnails Scale")
                row.prop(self, "preview_scale")
                row = col.row(align=True)
                row.label(text="Popup Thumbnails Scale")
                row.prop(self, "preview_scale_popup")
                row = col.row(align=True)
                row.label(text="Show thumbnails Labels")
                row.prop(self, "preview_show_labels", text="      ")

                split = box.split()
                col = split.column()
                row = col.row(align=True)
                row.label(text="LIBRARY PATH")
                row.alignment = 'RIGHT'
                row.scale_y = 1.5
                row.operator("object.speedsculpt_add_categories_path", text="ADD NEW CATEGORY", icon='ADD')
                row.prop(self, "show_path_info", text="", icon='QUESTION')

                if self.show_path_info:
                    box = layout.box()
                    box.label(text="ADD ASSET MANAGEMENT PATH", icon='QUESTION')
                    box.label(text="")
                    box.label(text="To add assets from the Asset Management Addon, you need to select a category.")
                    box.label(text="")
                    box.label(text="- Click on 'ADD NEW CATEGORY'", icon='ADD')
                    box.label(text="- A new Path will be created", icon='GRIP')
                    box.label(text="- Click on the folder", icon='FILEBROWSER')
                    box.label(text="- Go to you Asset Management library", icon='MENU_PANEL')
                    box.label(text="- Enter in a category", icon='COPY_ID')
                    box.label(text="- Press ENTER to validate", icon='EVENT_RETURN')
                    box.label(text="")
                    box.label(text="Note 1:", icon='INFO')
                    box.label(text="A Category is a directory and inside it, you have 2 folders")
                    box.label(text="'files'", icon='BLENDER')
                    box.label(text="'icons'", icon='IMAGE_DATA')
                    box.label(text="If you don't see them, you are not in a Category")
                    box.label(text="")
                    box.label(text="Note 2:", icon='INFO')
                    box.label(text="If you don't have the Asset Management Add-on,")
                    box.label(text="you still can add another library or create your own")
                    box.label(text="You just need to follow the same hierarchy")
                    box.label(text="")
                    box.label(text="LIBRARY FOLDER > CATEGORY > files and icons")
                    box.label(text="")
                    box.label(text="You can add as many categories as you want!")
                    box.label(text="")
                    box.label(text="Note 3:", icon='INFO')
                    box.label(text="Even if you could copy files into the addon library,")
                    box.label(text="It's better to add a custom path to an external library.")
                    box.label(text="You will not lose your files when updating the addon.")

                for index, cat in enumerate(self.categories):
                    if self.show_path_info:
                        box = layout.box()
                        split = box.split()
                        col = split.column()

                    row = col.row(align=True)
                    row.prop(cat, 'path', text="")
                    row.operator('object.speedsculpt_remove_categories_path', text="", icon='REMOVE').index = index

        if self.prefs_tabs == 'keymaps':
            AddonKeymaps.draw_keymap_items(wm, layout)
            box = layout.box()
            split = box.split()
            col = split.column()
            row = col.row(align=True)
            row.label(text="If you want to use the same keys as blender for the remesh and Voxel Size")
            row = col.row(align=True)
            row.label(text="Disable them in the Blender Preference > Keymap")
            row = col.row(align=True)
            row.label(text="And set the Speedsculpt Keymaps with the keys")
            row = col.row(align=True)
            row.label(text="Remesh: CTRL + R")
            row = col.row(align=True)
            row.label(text="Voxel Size: SHIFT + R")
            row = col.row(align=True)
            row.operator("wm.url_open", text="EDIT BLENDER KEYMAPS",
                         icon ='FILE_MOVIE').url = "http://blscripts.com/speedsculpt_videos/Speedsculpt_keymaps.mp4"
            

        if self.prefs_tabs == 'links':

            # TUTORIALS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="TUTORIALS & ADD-ONS")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_web")
            row.operator("wm.url_open", text="MY ADDONS",
                         icon_value=icon.icon_id).url = "https://blscripts.notion.site/MY-BLENDER-ADD-ONS-177b22ccb5a080bfa87aef5fa7392697"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_gumroad")
            row.operator("wm.url_open", text="GUMROAD",
                         icon_value=icon.icon_id).url = "https://pitiwazou-1.gumroad.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            row.operator("wm.url_open", text="GUMROAD - SPEEDFLOW",
                         icon_value=icon.icon_id).url = "https://pitiwazou.gumroad.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_superhive")
            row.operator("wm.url_open", text="SUPERHIVE",
                         icon_value=icon.icon_id).url = "https://superhivemarket.com/creators/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.scale_y = 1.3
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/a/651436"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_youtube")
            row.operator("wm.url_open", text="YOUTUBE",
                         icon_value=icon.icon_id).url = "https://www.youtube.com/user/pitiwazou"

            # LINKS
            box = layout.box()
            row = box.row(align=True)
            row.label(text="SOCIAL")

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_web")
            row.operator("wm.url_open", text="PITIWAZOU.COM",
                         icon_value=icon.icon_id).url = "http://www.pitiwazou.com/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_artstation")
            row.operator("wm.url_open", text="ARTSTATION",
                         icon_value=icon.icon_id).url = "https://www.artstation.com/artist/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_twitter")
            row.operator("wm.url_open", text="TWITTER",
                         icon_value=icon.icon_id).url = "https://twitter.com/#!/pitiwazou"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_facebook")
            row.operator("wm.url_open", text="FACEBOOK",
                         icon_value=icon.icon_id).url = "https://www.facebook.com/Pitiwazou-C%C3%A9dric-Lepiller-120591657966584/"

            row = box.row(align=True)
            row.scale_y = 1.3
            icon = icons.get("icon_instagram")
            row.operator("wm.url_open", text="INSTAGRAM",
                         icon_value=icon.icon_id).url = "https://www.instagram.com/pitiwazou/"

# -----------------------------------------------------
# SAVE/RESET/LOAD PREFERENCES
# -----------------------------------------------------
class SPEEDSCULPT_OT_save_preferences(Operator):
    bl_idname = 'object.speedsculpt_save_preferences'
    bl_label = "Save preferences"
    bl_description = "Save the preferences to keep the presets when restarting Blender\n\n"\
        "Notes:\n\n"\
        "If the presets was previously saved, the addon will overwrite it when saving the preferences.\n"\
        "If it was not saved, you will still have it, but you can lose it if you delete it from the list.\n\n"\
        "Take this into account when saving the preferences."
    bl_options = {'REGISTER','UNDO'}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        
        # Pour tous les presets dans la liste, on les sauvegarde si possible
        prefs = get_addon_preferences(context)
            
        bpy.ops.wm.save_userpref()
        return {'FINISHED'}

class SPEEDSCULPT_OT_reset_preferences(Operator):
    """Reset all addon preferences to default values"""
    bl_idname = "object.speedsculpt_reset_preferences"
    bl_label = "Reset Preferences"
    bl_description = "Reset all addon preferences to their default values"
    bl_options = {'REGISTER', 'UNDO'}
    
    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
    def execute(self, context):
        prefs = get_addon_preferences(context)
        prefs.reset_preferences()
        self.report({'INFO'}, "Preferences have been reset to default values.")
        return {'FINISHED'}

class SPEEDSCULPT_OT_save_options_preferences(Operator, ExportHelper):
    """Save addon preferences (Options tab) to JSON file"""
    bl_idname = "object.speedsculpt_save_options_preferences"
    bl_label = "Save Options Preferences"
    bl_description = "Save addon preferences (Options tab settings) to JSON file"
    bl_options = {'REGISTER'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})
    
    def execute(self, context):
        prefs = get_addon_preferences(context)
        success, message = prefs.save_preferences_to_json(filepath=self.filepath)
        
        if success:
            self.report({'INFO'}, message)
        else:
            self.report({'ERROR'}, message)
        
        return {'FINISHED'}

class SPEEDSCULPT_OT_load_options_preferences(Operator, ImportHelper):
    """Load addon preferences (Options tab) from JSON file"""
    bl_idname = "object.speedsculpt_load_options_preferences"
    bl_label = "Load Options Preferences"
    bl_description = "Load addon preferences (Options tab settings) from JSON file"
    bl_options = {'REGISTER', 'UNDO'}
    
    filename_ext = ".json"
    filter_glob: StringProperty(default="*.json", options={'HIDDEN'})
    
    def execute(self, context):
        prefs = get_addon_preferences(context)
        success, message = prefs.load_preferences_from_json(filepath=self.filepath)
        
        if success:
            self.report({'INFO'}, message)
        else:
            self.report({'ERROR'}, message)
        
        return {'FINISHED'}

# -----------------------------------------------------
# KEYMAPS
# -----------------------------------------------------
class AddonKeymaps:
    _addon_keymaps = []
    _keymaps = {}

    @classmethod
    def new_keymap(cls, name, kmi_name, kmi_value=None, km_name='3D View',
                   space_type="VIEW_3D", region_type="WINDOW",
                   event_type=None, event_value=None, ctrl=False, shift=False,
                   alt=False, key_modifier="NONE"):

        cls._keymaps.update({name: [kmi_name, kmi_value, km_name, space_type,
                                    region_type, event_type, event_value,
                                    ctrl, shift, alt, key_modifier]
                             })

    @classmethod
    def add_hotkey(cls, kc, keymap_name):

        items = cls._keymaps.get(keymap_name)
        if not items:
            return

        kmi_name, kmi_value, km_name, space_type, region_type = items[:5]
        event_type, event_value, ctrl, shift, alt, key_modifier = items[5:]
        km = kc.keymaps.new(name=km_name, space_type=space_type,
                            region_type=region_type)

        kmi = km.keymap_items.new(kmi_name, event_type, event_value,
                                  ctrl=ctrl,
                                  shift=shift, alt=alt,
                                  key_modifier=key_modifier
                                  )
        if kmi_value:
            kmi.properties.name = kmi_value

        kmi.active = True

        cls._addon_keymaps.append((km, kmi))

    @staticmethod
    def register_keymaps():
        wm = bpy.context.window_manager
        kc = wm.keyconfigs.addon
        # In background mode, there's no such thing has keyconfigs.user,
        # because headless mode doesn't need key combos.
        # So, to avoid error message in background mode, we need to check if
        # keyconfigs is loaded.
        if not kc:
            return

        for keymap_name in AddonKeymaps._keymaps.keys():
            AddonKeymaps.add_hotkey(kc, keymap_name)

    @classmethod
    def unregister_keymaps(cls):
        kmi_values = [item[1] for item in cls._keymaps.values() if item]
        kmi_names = [item[0] for item in cls._keymaps.values() if
                     item not in ['wm.call_menu', 'wm.call_menu_pie']]

        for km, kmi in cls._addon_keymaps:
            # remove addon keymap for menu and pie menu
            if hasattr(kmi.properties, 'name'):
                if kmi_values:
                    if kmi.properties.name in kmi_values:
                        km.keymap_items.remove(kmi)

            # remove addon_keymap for operators
            else:
                if kmi_names:
                    if kmi.idname in kmi_names:
                        km.keymap_items.remove(kmi)

        cls._addon_keymaps.clear()

    @staticmethod
    def get_hotkey_entry_item(name, kc, km, kmi_name, kmi_value, col):

        # for menus and pie_menu
        if kmi_value:
            for km_item in km.keymap_items:
                if km_item.idname == kmi_name and km_item.properties.name == kmi_value:
                    col.context_pointer_set('keymap', km)
                    rna_keymap_ui.draw_kmi([], kc, km, km_item, col, 0)
                    return

            col.label(text=f"No hotkey entry found for {name}")
            col.operator(SPEEDSCULPT_OT_restore_hotkey.bl_idname,
                         text="Restore keymap",
                         icon='ADD').km_name = km.name

        # for operators
        else:
            if km.keymap_items.get(kmi_name):
                col.context_pointer_set('keymap', km)
                rna_keymap_ui.draw_kmi([], kc, km, km.keymap_items[kmi_name],
                                       col, 0)

            else:
                col.label(text=f"No hotkey entry found for {name}")
                col.operator(SPEEDSCULPT_OT_restore_hotkey.bl_idname,
                             text="Restore keymap",
                             icon='ADD').km_name = km.name

    @staticmethod
    def draw_keymap_items(wm, layout):
        kc = wm.keyconfigs.user

        for name, items in AddonKeymaps._keymaps.items():
            kmi_name, kmi_value, km_name = items[:3]
            box = layout.box()
            split = box.split()
            col = split.column()
            col.label(text=name)
            col.separator()
            km = kc.keymaps[km_name]
            AddonKeymaps.get_hotkey_entry_item(name, kc, km, kmi_name,
                                             kmi_value, col)

class SPEEDSCULPT_OT_restore_hotkey(Operator):
    bl_idname = "speedsculpt.restore_hotkey"
    bl_label = "Restore hotkeys"
    bl_options = {'REGISTER', 'INTERNAL'}

    km_name: StringProperty() # type: ignore

    def execute(self, context):
        context.preferences.active_section = 'KEYMAP'
        wm = context.window_manager
        kc = wm.keyconfigs.addon
        km = kc.keymaps.get(self.km_name)
        if km:
            km.restore_to_default()
            context.preferences.is_dirty = True
        context.preferences.active_section = 'ADDONS'
        return {'FINISHED'}

# -----------------------------------------------------
# PROPERTYGROUP
# -----------------------------------------------------
class SPEEDSCULPT_GeomeshItem(PropertyGroup):
    name: StringProperty(name="Name") # type: ignore
    value: StringProperty(name="Value") # type: ignore

class SPEEDSCULPT_PropertyGroup(bpy.types.PropertyGroup):
    boolean_operation: EnumProperty(
        items=(('union', "Union", "Make an Union (Boolean Operations can take time)"),
               ('difference', "Difference", "Remove a part of your Mesh (Boolean Operations can take time)"),
               ('rebool', "rebool", "Slice the active object from your selection (Boolean Operations can take time)")),
        default='union') # type: ignore
    sculpt_mode : BoolProperty(default=False,description="The Active Object is in sculpt mode") # type: ignore
    ref_obj: PointerProperty(type=bpy.types.Object) # type: ignore
    create_primitives: EnumProperty(
        items=(('mouse', "Mouse", "MOUSE\n\nCreate the Primitive on your mouse to place it in the 3Dview."),
               ('origin', "Origin", "ORIGIN\n\nCreate the primitive at the scene origin, regardless of cursor location and rotation."),
               ('cursor', "Cursor", "CURSOR\n\nCreate the Primitive on the Cursor.\nYou can use the Cursor Rotation Option Just below"),
               ('selection', "Selection", "SELECTION\n\nCreate the Primitive on the selection.\nIf you selected several Objects, it will Create the primitive at the Center of them."),
               ('insert', "Insert", "INSERT\n\nInsert the Primitive in the view.\nYou scale or move it, and do in sculpt mode"),),
        default='origin') # type: ignore
    copy_cursor_orientation: BoolProperty(name="Cursor Rotation",default=False, description="Copy Cursor Orientation for the Primitives/Assets") # type: ignore
    add_mirror : BoolProperty(default=False,description="Add a Mirror Modifier to the New Object.\n\nIt will take the current Selection as Reference Object for the Modifier.", update=set_ref_obj) # type: ignore
    mirror_x : BoolProperty(default=True,description="X Axis") # type: ignore
    mirror_y : BoolProperty(default=False,description="Y Axis") # type: ignore
    mirror_z : BoolProperty(default=False,description="Z Axis") # type: ignore
    primitives_parenting : BoolProperty(default=False,description="Make the new object children to the active object") # type: ignore
    metaballs_pos_neg : EnumProperty(
        items=(('positive', "Positive", ""),
               ('negative', "Negative", "")),
        default='positive',
        update=UpdateMetaballs) # type: ignore
    use_clipping : BoolProperty(default=False,description="Use Clipping/Merger",update=ClippingMerge) # type: ignore
    # CURVE
    bbox : BoolProperty(default=False, description="Add Solidify") # type: ignore
    direct_cut : BoolProperty(default=False, description="Cut Directly the mesh") # type: ignore
    direct_rebool : BoolProperty(default=False, description="Directly Rebool") # type: ignore
    create_lathe : BoolProperty(default=False, description="Create Lathe") # type: ignore
    bbox_bevel : FloatProperty(min=0, max=100, default=0.1,description="Bbox Bevel") # type: ignore
    bbox_depth : FloatProperty(min=0, max=100, default=1,description="Bbox Depth") # type: ignore
    bbox_offset : FloatProperty(min=-100, max=100, default=-0.1,description="Bbox Offset") # type: ignore
    bbox_apply_solidify : BoolProperty(default=True,description="Apply solidify") # type: ignore
    bbox_convert : BoolProperty(default=False,description="Convert to Dyntopo") # type: ignore
    smooth_result : BoolProperty(default=False,description="Smooth the object") # type: ignore
    
    # LATTICE
    copy_orientation : BoolProperty(name="Copy orientation",description="Copy the orientation of the active Object",
                                    default=False) # type: ignore
    hide_lattice : BoolProperty(default=True,description="Hide Lattice on selected objects",update=HideLattice) # type: ignore
    lattice_u : IntProperty(min=2, max=100, default=2) # type: ignore
    lattice_v : IntProperty(min=2, max=100, default=2) # type: ignore
    lattice_w : IntProperty(min=2, max=100, default=2) # type: ignore
    lattice_interp : EnumProperty(
        items=(('KEY_LINEAR', 'linear', ""),
               ('KEY_BSPLINE', 'bspline', ""),
               ('KEY_CATMULL_ROM', 'catmull_rom', ""),
               ('KEY_CARDINAL', 'cardinal', "")),
        default='KEY_BSPLINE',
        update=LatticeInterpolation) # type: ignore
    
    # REMESH
    hide_remesh_smooth : BoolProperty(default=True,description="Hide Remesh and smooth",update=HideRemeshSmooth) # type: ignore
    remesh_smooth_repeat : IntProperty(min=0,max=100,default=10,update=RemeshSmoothRepeat) # type: ignore
    
    # DECIMATE
    hide_decimate : BoolProperty(default=True,description="Hide Decimate",update=Hidedecimate) # type: ignore
    decimate_ratio : FloatProperty(min=0,max=1,default=1,update=DecimateRatio,description="Decimate Ratio") # type: ignore
    
    # EXTRACT MASK
    extract_cut_delete : EnumProperty(
        items=(('extract', "Extract", "Extract Mask to New Object"),
               ('cut', "Cut", "Cut the Masked Part"),
               ('duplicate', "Duplicate", "Duplicate the Masked Part")),
        default='extract') # type: ignore
    face_set_or_mask_operation : EnumProperty(
            items=(('FACE_SET', "Face Sets", ""),
                   ('MASK', "Mask", ""),
                   ),
            default='FACE_SET',
            description="Select the Operation you want to perform") # type: ignore
    add_solidify : BoolProperty(name="Add Solidify",description="Add Solidify to the extracted object",default=False) # type: ignore
    comeback_in_sculpt_mode : BoolProperty(default=False, description="Comme Back in Sculpt mode",) # type: ignore
    apply_solidify : BoolProperty(default=True,description="Apply Solidify") # type: ignore

    update_dyntopo : BoolProperty(default=True,description="Update Dyntopo") # type: ignore
    rim_only : BoolProperty(default=False,name="Rim Only",description="Use Rim Only") # type: ignore
    solidify_thickness : FloatProperty(min=0.01, max=300, default=0.1,description="Solidify Thickness") # type: ignore
    solidify_offset : FloatProperty(min=-1, max=1, default=0.6,description="Solidify Offset") # type: ignore
    
    # QUICK POSE
    use_mask : BoolProperty(name="Use Mask",description="Use Mask",default=True) # type: ignore
    
    # SHOW/HIDE MENUS
    show_options : BoolProperty(default=False,description="\nSettings for REMESH/DYNTOPO\n\nYou can setup the Remeshing in this menu.", name="SETTINGS") # type: ignore
    show_basic_primitives: BoolProperty(default=False, description="PRIMITIVES\n\nAdd Basic Primitive to your Scene.\n\n" \
                                        "They will use the Options Selected UPDATE REMESH/MOUSE/ORIGIN/CURSOR ROTATION, etc.\n\n" \
                                        "You can combine POLY and METABALLS Primitives.") # type: ignore
    show_shading : BoolProperty(default=False,description="SHADING SETTINGS\n\nEdit the settings of the Shading for the Viewport.") # type: ignore
    creation_tools_description = "CREATION TOOLS\n\n" \
                                 "A bunch of Tools to create your sculpts as fast as possible!\n" \
                                 "You can add Primitives or assets from your library and combine them.\n\n" \
                                 "There are also other usefull Tools"
    show_creation_tools : BoolProperty(default=False,description=creation_tools_description, name="CREATION TOOLS") # type: ignore
    show_extract : BoolProperty(default=False,description="MASK TOOLS\n\nExtract, Duplicate, etc, parts of your Mesh using Masks") # type: ignore
    show_symmetrize : BoolProperty(default=False,description="SYMMETRIZE TOOLS\n\nSymmetrize your Mesh by choosing the direction") # type: ignore
    show_remesh : BoolProperty(default=False,description="REMESH TOOLS\n\nREMESH/DECIMATE/RETOPOLOGIZE your Mesh") # type: ignore
    show_lattice : BoolProperty(default=False,description="LATTICE TOOLS\n\nCreate a Lattice from Selection of Mask") # type: ignore
    show_quickpose : BoolProperty(default=False,description="QUICK POSE TOOLS\n\nMake a Quick Pose of your Mesh or only a part of it using Masks") # type: ignore
    show_geo_remesh : BoolProperty(default=False,description="GEO REMESH TOOLS\n\nCreate a Geo Remesh from Selection of Mask") # type: ignore
    show_muscles : BoolProperty(default=False,description="MUSCLES TOOLS\n\nCreate Muscles from the Library") # type: ignore
    show_draw_mesh: BoolProperty(default=False, description="DRAW MESH TOOLS\n\nDraw Mesh in the 3Dview.\nYou can set the Size in the Settings") # type: ignore
    show_cutter: BoolProperty(default=False, description="CUTTER TOOLS\n\nCut or Create Meshes") # type: ignore
    show_draw_surface: BoolProperty(default=False, 
                                    description="SURFACE TOOL\n\nCreate Mesh in the 3Dview on on the surface of other Meshes.\n\n" \
                                    "You can Edit the Settings") # type: ignore
    show_backup : BoolProperty(default=False, description="BACKUP TOOLS\n\nBackup your Mesh") # type: ignore
    show_flat_shading_settings: BoolProperty(default=False, description="FLAT SHADING SETTINGS\n\nToggle the Flat Shading of the Viewport") # type: ignore
    show_timelapse: BoolProperty(default=False, description="TIMELAPSE TOOLS\n\nRecord a Timelapse of your Sculpt") # type: ignore
    show_tools: BoolProperty(default=False, description="TOOLS\n\nCopy Data to Selection") # type: ignore
    show_hierarchy: BoolProperty(default=False, description="HIERARCHY\n\nSet Parent, Select Parent, Select Children, Select Hierarchy") # type: ignore
    # LIBRARY
    show_asset_lib: BoolProperty(default=False, description="ASSET LIBRARY\n\n" \
                                "Add Asset from your Library to the Scene.\n\n" \
                                "You can add your own Assets to the Library or link Assets from The Asset Management Addon.\n\n" \
                                "Check the Preferences of the Addon.") # type: ignore
    show_warning_message : BoolProperty(default=False, description="Show the warning message on the Addon", name="") # type: ignore
    ui_categories : EnumProperty(name="", items=call_back_enum) # type: ignore
    snap_to_faces : BoolProperty(default=False, description="Snap To Faces", update=snap_faces) # type: ignore
    
    # DRAW REMESH
    draw_remesh_size : FloatProperty(min=0.001, max=100, default=0.5, description="Width of the Mesh you will create") # type: ignore
    draw_remesh_placement: EnumProperty(
        items=(('surface', "Surface", "Draw the Mesh on the Surface of other Meshes", "FACESEL", 0),
               ('cursor', "Cursor", "Draw the Mesh on the Cursor Location", "CURSOR", 1),
               ),
        default='cursor') # type: ignore

    # DRAW SURFACE
    draw_surface_thickness: FloatProperty(min=0.001, max=100, default=1, description="Thickness of the Mesh you will create",precision=3) # type: ignore
    draw_surface_offset: FloatProperty(min=-1, max=1, default=1,
                                          description="Offset of the Mesh you will create", precision=3) # type: ignore
    draw_surface_update_remesh: BoolProperty(default=True, description="Update the Remesh") # type: ignore
    draw_surface_placement: EnumProperty(
        items=(('SURFACE', "Surface", "Draw the Surface on the Surface of the Mesh", "FACESEL", 0),
               ('CURSOR', "Cursor", "Draw the Surface on the Cursor Location", "CURSOR", 1)),
        default='SURFACE') # type: ignore
    
    # CUTTER
    cutter_difference: BoolProperty(default=False, description="Remove a part of your mesh from your selection") # type: ignore
    cutter_rebool: BoolProperty(default=False, description="Slice the active object from your selection") # type: ignore
    cutter_union: BoolProperty(default=False, description="Make an union of your selection") # type: ignore
    primitive_created: BoolProperty(default=False, description="The Primitive has been created") # type: ignore
    cutter_new_mesh: BoolProperty(default=False, description="Create a new Mesh") # type: ignore
    cutter_plan: BoolProperty(default=False, description="Create or Cut from a Rectangle") # type: ignore
    cutter_vertex_line: BoolProperty(default=False, description="Create or Cut from a Form made from Edges") # type: ignore
    cutter_curve: BoolProperty(default=False, description="Create or Cut from a Curve") # type: ignore
    cutter_sphere: BoolProperty(default=False, description="Create or Cut from a Sphere") # type: ignore
    cutter_cylinder: BoolProperty(default=False, description="Create or Cut from a Cylinder") # type: ignore
    cutter_cube: BoolProperty(default=False, description="Create or Cut from a Cube") # type: ignore
    cutter_circle: BoolProperty(default=False, description="Create or Cut from a Circle") # type: ignore
    from_library: BoolProperty(default=False, description="") # type: ignore
    operation_type_union : BoolProperty(default=False, description="Make an union of your selection") # type: ignore
    operation_type_difference : BoolProperty(default=False, description="Remove a part of your mesh from your selection") # type: ignore
    operation_type_rebool : BoolProperty(default=False, description="Slice the active object from your selection") # type: ignore
    cutter_creation_width: FloatProperty(min=0.01, max=1000, default=1, description="With of the Cutter Creation") # type: ignore
    cutter_create_boolean: EnumProperty(
        items=(('create', "Create", "Create a new mesh"),
               ('boolean', "Boolean", "Add/Remove a part of your Mesh"),),
        default='boolean') # type: ignore
    cutter_view_surface: EnumProperty(
        items=(('view', "View", "Cut or create from the view or the surface of a Mesh"),
               ('surface', "Surface", "Cut or create from the the surface of a Mesh")),
        default='view') # type: ignore
    cutter_primitives: EnumProperty(
        items=(('rectangle', " ", "Cut or create with a Rectangle", "MESH_PLANE", 0),
               ('circle', " ", "Cut or create with a Circle", "MESH_CIRCLE", 1),
               ('vertex', " ", "Cut or create with a Shape", "HANDLE_VECTOR", 2),
               ('curve', " ", "Cut or create with a Curve", "MOD_CURVE", 3)),
                default='rectangle') # type: ignore
    
    # SHADING
    shading: EnumProperty(
        items=(('studio', "Studio", "Studio", "", 0),
               ('matcap', "Matcap", "Matcap", "", 1),
               ('flat', "Flat", "Flat", "", 2)),
        default='matcap',
        update = update_shading) # type: ignore

    shading_icons: EnumProperty(
        items=(('studio', " ", "STUDIO MODE\n\nYou can rotate the Environment with CTRL SHIFT MMB", "LIGHT_SPOT", 0),
               ('matcap', " ", "MATCAP MODE", "NODE_MATERIAL", 1),),
                default='matcap',
                name="",
                update=update_shading_icons) # type: ignore
    

    hide_mirror_modifiers_prop: BoolProperty(default=True, update=show_hide_mirror_visibility) # type: ignore
    
    
    # MUSCLES
    hide_all_modifiers_prop: BoolProperty(default=True, update=hide_all_modifiers) # type: ignore
    edit_muscles_tickness: FloatProperty(min=0.001, max=1000, default=0.1,
                                         description="Thickness of the Mesh you will create",
                                         precision=3,
                                         update=muscles_tickness) # type: ignore
    edit_muscles_offset: FloatProperty(min=-1, max=1, default=0,
                                         description="Offset of the Mesh you will create",
                                         precision=3,
                                         update=muscles_offset) # type: ignore
    edit_muscles_factor: FloatProperty(min=0.001, max=1, default=0.1,
                                         description="Factor of the Mesh you will create",
                                         precision=3,
                                         update=muscles_factor) # type: ignore
    
    # GEOMESH
    collection_selection: PointerProperty(
        type=bpy.types.Collection, 
        name="Select Collection", 
        description="Select a collection from the available collections")# type: ignore
    
    def get_collection_info(self):
        """Version sécurisée - désactive sur library overrides"""
        try:
            act_obj = bpy.context.active_object
            if not act_obj:
                return ""
            
            # Désactiver sur les library overrides
            if hasattr(act_obj, 'library') and act_obj.library:
                return ""  # Valeur par défaut pour les objets liés
            if hasattr(act_obj, 'override_library') and act_obj.override_library:
                return ""  # Valeur par défaut pour les overrides
            
            # Vérifier l'existence du modifier avant d'accéder
            if not hasattr(act_obj, 'modifiers'):
                return ""
                
            modifier = act_obj.modifiers.get("GeometryNodes_Geomesh")
            if modifier and hasattr(modifier, 'node_group') and modifier.node_group:
                geo_group = modifier.node_group
                
                # Vérifier l'existence des nodes avant d'accéder
                if hasattr(geo_group, 'nodes'):
                    collection_info = geo_group.nodes.get("Collection Info")
                    if (collection_info and hasattr(collection_info, 'inputs') and 
                        len(collection_info.inputs) > 0 and 
                        hasattr(collection_info.inputs[0], 'default_value') and
                        collection_info.inputs[0].default_value):
                        return collection_info.inputs[0].default_value.name
        except (AttributeError, ReferenceError, RuntimeError, IndexError):
            pass
        return ""

    def set_collection_info(self, value):
        """Version sécurisée - désactive sur library overrides"""
        try:
            act_obj = bpy.context.active_object
            if not act_obj:
                return
            
            # Ne rien faire sur les library overrides
            if hasattr(act_obj, 'library') and act_obj.library:
                return  # Ignorer complètement
            if hasattr(act_obj, 'override_library') and act_obj.override_library:
                return  # Ignorer complètement
            
            # Vérifier l'existence du modifier avant d'accéder
            if not hasattr(act_obj, 'modifiers'):
                return
                
            modifier = act_obj.modifiers.get("GeometryNodes_Geomesh")
            if modifier and hasattr(modifier, 'node_group') and modifier.node_group:
                geo_group = modifier.node_group
                
                # Vérifier l'existence des nodes avant d'accéder
                if hasattr(geo_group, 'nodes'):
                    collection_info = geo_group.nodes.get("Collection Info")
                    if (collection_info and hasattr(collection_info, 'inputs') and 
                        len(collection_info.inputs) > 0 and 
                        hasattr(collection_info.inputs[0], 'default_value')):
                        
                        # Vérifier l'existence de la collection avant de l'assigner
                        if hasattr(bpy.data, 'collections'):
                            collection = bpy.data.collections.get(value)
                            if collection:
                                collection_info.inputs[0].default_value = collection
                                # Mise à jour sécurisée
                                if hasattr(bpy.context, 'view_layer'):
                                    bpy.context.view_layer.update()
        except (AttributeError, ReferenceError, RuntimeError, IndexError):
            pass
        
    collection_info_selection: StringProperty(
        name="Select Collection",
        description="Select a collection from the available collections",
        get=get_collection_info,
        set=set_collection_info
    ) # type: ignore

    active_geomesh_name: StringProperty(default="") # type: ignore

    geomesh_name: StringProperty(name="Geomesh Name")# type: ignore

    show_grid_scale: BoolProperty(
        name="Show Grid Scale",
        description="Show/Hide Grid Scale",
        default=False,
        update=update_grid_scale_visibility
    ) # type: ignore
    
    # NEW ---------------------------------------------------
    
    def update_show_in_front(self, context):
        """Met à jour la propriété show_in_front de l'objet Geomesh actif"""
        speedsculpt = context.window_manager.speedsculpt
        
        # Vérifie si on a des items dans la collection
        if len(speedsculpt.geomesh_objects) > 0:
            # Vérifie si l'index est valide
            if 0 <= speedsculpt.geomesh_active_index < len(speedsculpt.geomesh_objects):
                # Récupère l'item actif
                active_item = speedsculpt.geomesh_objects[speedsculpt.geomesh_active_index]
                
                # Récupère l'objet Blender correspondant
                active_geomesh = bpy.data.objects.get(active_item.name)
                if active_geomesh:
                    # Met à jour show_in_front
                    active_geomesh.show_in_front = self.show_in_front
                    
                    # Force la mise à jour de l'interface
                    context.view_layer.update()
                    for area in context.screen.areas:
                        if area.type == 'VIEW_3D':
                            area.tag_redraw()

    show_in_front: BoolProperty(
        name="Show In Front",
        description="Show the object in front of other objects",
        default=False,
        update=update_show_in_front
    ) # type: ignore

    # Collection pour stocker les geomesh objects
    geomesh_objects: CollectionProperty(
        type=SPEEDSCULPT_GeomeshItem,
        name="Geomesh Objects"
    ) # type: ignore
    
    geomesh_active_index: IntProperty(default=0) # type: ignore

    active_collection: StringProperty(name="Active Collection", default="")# type: ignore

    mirror_selection_options: BoolProperty(
        name=" Mirror The Selection Tool Options",
        description="Options for Mirror The Selection Tool",
        default=False,
    ) # type: ignore

    mirror_selection_make_instances: BoolProperty(
        name="Make Instances",
        description="Make the duplicate objects instances of the first ones",
        default=False,
    ) # type: ignore

    mirror_selection_add_suffixes: BoolProperty(
        name="Add suffixes",
        description="Add suffixes (_L & _R) to the selection",
        default=False,
    ) # type: ignore

    def draw_curve_projection_mode(self, context):
        context.scene.tool_settings.curve_paint_settings.depth_mode = self.draw_curve_surface_cursor

    def set_array_curve_object(self, context):
        array_mod = context.object.modifiers.get("Array Curve")
        curve_mod = context.object.modifiers.get("Curve")
        if array_mod and curve_mod:
            self.array_curve_object = context.selected_objects[0]

    draw_curve_surface_cursor: EnumProperty(
            items=(("SURFACE", "Surface","", "FACESEL", 0),
                   ("CURSOR","Cursor","", "CURSOR", 1)),
                   default="CURSOR",
                   description="Draw on surface or cursor",
                   update=draw_curve_projection_mode) # type: ignore
    
    show_draw_curve_settings: BoolProperty(
            name="Draw Curve Settings",
            default=False,
            description="Settings for the Draw Curve Tool") # type: ignore

    show_array_curve_settings: BoolProperty(
            name="Array Curve Settings",
            default=False,
            description="Settings for the Array Curve Tool") # type: ignore
    
    array_curve_surface_cursor: EnumProperty(
            items=(("SURFACE", "Surface","", "FACESEL", 0),
                   ("CURSOR","Cursor","", "CURSOR", 1)),
                   default="CURSOR",
                   description="Array on surface or cursor",
                   update=draw_curve_projection_mode) # type: ignore
    
    array_curve_object: PointerProperty(
        type=bpy.types.Object, 
        name="Array Curve Object", 
        description="Array Curve Object") # type: ignore
    
    curve_mirror_target : PointerProperty(
        type=bpy.types.Object, 
        name="Mirror Object", 
        description="Mirror Object")# type: ignore
    
    # Propriétés pour sauvegarder la brosse précédente
    previous_brush_name: StringProperty(
        name="Previous Brush Name",
        description="Name of the previously active brush",
        default=""
    ) # type: ignore
    
    previous_brush_type: StringProperty(
        name="Previous Brush Type", 
        description="Type of the previously active brush",
        default=""
    ) # type: ignore

    # BACKUP SYSTEM
    backup_options: BoolProperty(default=False, name="Backup Options") # type: ignore

    go_in_sculpt_mode: BoolProperty(default=True, name="Go in Sculpt Mode") # type: ignore

    def set_insert_object(self, context):
        if self.use_existing_object and len(context.selected_objects) == 1:
            self.insert_object = context.selected_objects[0]
                
    use_existing_object: BoolProperty(default=False, name="Use Existing Object", update=set_insert_object, description="Use an existing object to insert it in the scene") # type: ignore
    insert_object: PointerProperty(type=bpy.types.Object) # type: ignore
    copy_normal_orientation: BoolProperty(default=True, name="Copy Normal Orientation", description="Copy the normal orientation of the object") # type: ignore

    # VIEW STORE
    view_store_name: StringProperty(name="Store View Name", default="3D View") # type: ignore
    view_store_location: FloatVectorProperty(name="Location", size=3)# type: ignore
    view_store_rotation: FloatVectorProperty(name="Rotation", size=4) # type: ignore # Quaternion
    view_store_distance: FloatProperty(name="Distance", default=1, min=0.01, max=100000000, precision=3, description="Distance") # type: ignore
    view_store_zoom: FloatProperty(name="Zoom", default=1, min=0.01, max=100000000, precision=3, description="Zoom") # type: ignore
    view_store_perspective: BoolProperty(name="Perspective", default=True, description="Perspective") # type: ignore
    view_store_matrix: FloatVectorProperty(name="Matrix", size=16) # type: ignore

    # CURSOR STORE
    cursor_store_name: StringProperty(name="Cursor Store Name", default="Cursor") # type: ignore
    cursor_store_location: FloatVectorProperty(name="Location", size=3, subtype='TRANSLATION') # type: ignore
    cursor_store_rotation: FloatVectorProperty(name="Rotation", size=3, subtype='EULER') # type: ignore
    cursor_store_rotation_mode: StringProperty(name="Rotation Mode", default='XYZ') # type: ignore

class SPEEDSCULPT_UnifiedBackupItem(PropertyGroup):
    """Item pour stocker un backup d'objet (commun aux deux addons)"""
    name: StringProperty(default="Backup") # type: ignore
    timestamp: StringProperty(default="") # type: ignore
    object_data: PointerProperty(type=bpy.types.Mesh) # type: ignore
    object_name: StringProperty(default="") # type: ignore
    is_fake_user: BoolProperty(default=True) # type: ignore
    backup_id: StringProperty(default="") # type: ignore - Identifiant unique

class SPEEDSCULPT_UnifiedObjectBackup(PropertyGroup):
    """Collection de backups pour un objet (commun aux deux addons)"""
    backups: CollectionProperty(type=SPEEDSCULPT_UnifiedBackupItem) # type: ignore
    active_backup_index: IntProperty(default=0) # type: ignore

# Timelapse Camera Settings
def update_camera_resolution(self, context):

    if self.camera_resolutions == 'Horizontal':
        bpy.context.scene.render.resolution_x = 1920
        bpy.context.scene.render.resolution_y = 1080
    elif self.camera_resolutions == 'Square':
        bpy.context.scene.render.resolution_x = 1080
        bpy.context.scene.render.resolution_y = 1080
    elif self.camera_resolutions == 'Vertical':
        bpy.context.scene.render.resolution_x = 1080
        bpy.context.scene.render.resolution_y = 1920

def update_timelpase_speed(self, context):
    render = context.scene.render
    if self.timelpase_speed == 'Fast':
        self.interval = 1
        render.resolution_percentage = 50
        self.render_resolution = '0.5'

    elif self.timelpase_speed == 'Medium':
        self.interval = 3
        render.resolution_percentage = 75
        self.render_resolution = '0.75'
    elif self.timelpase_speed == 'Slow':
        self.interval = 5
        render.resolution_percentage = 100
        self.render_resolution = '1'

def update_camera_list_index(self, context):
    objects = list(context.scene.objects)
    idx = self.camera_list_index
    if 0 <= idx < len(objects):
        obj = objects[idx]
        if obj.type == 'CAMERA':
            self.camera = obj
            context.scene.camera = obj
            # Force camera view in the first found 3D viewport
            # for area in context.screen.areas:
            #     if area.type == 'VIEW_3D':
            #         for space in area.spaces:
            #             if space.type == 'VIEW_3D':
            #                 space.region_3d.view_perspective = 'CAMERA'
            #         break

class SPEEDSCULPT_PropertyGroup_timelapse(PropertyGroup):
    icons = load_icons()
    save_path: StringProperty(
        name="Folder",
        subtype='DIR_PATH',
        default="//timelapse_frames/"
    )
    camera: PointerProperty(
        name="Camera",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'CAMERA'
    )

    interval: FloatProperty(
        name="Capture Interval (s)",
        default=5,      # Default: 0.2s (5 images per second)
        min=0.05,         # Allow down to 20 images per second
        description="Capture per second (0.1 = 10 captures/sec.)\n"\
        "Note: The capture interval is the time between each capture. "\
        "The higher the interval, the less captures per second. "\
        "Warning: Low value can cause performance issues. "\
    )

    framerate: IntProperty(
        name="Video FPS",
        default=30,       # Increase the framerate of the final video for fluidity
        min=1,
        max=60
    )
    is_recording: BoolProperty(
        name="Recording",
        default=False
    )

    # camera_resolutions: EnumProperty(
    #     name="Camera Resolutions",
    #     items=[
    #         ('Horizontal', "Horizontal", "Horizontal", icons.get("icon_timelapse_horizontal").icon_id, 0),
    #         ('Square', "Square", "Square", icons.get("icon_timelapse_square").icon_id, 1),
    #         ('Vertical', "Vertical", "Vertical", icons.get("icon_timelapse_vertical").icon_id, 2),
    #     ],
    #     default='Horizontal',
    #     description="Camera resolution for the timelapse\n\n" \
    #     "Horizontal = 1920x1080\n" \
    #     "Square = 1080x1080\n" \
    #     "Vertical = 1080x1920\n\n" \
    #     "Note: You can change the resolution in the Settings (Timelapse Settings).",
    #     update=update_camera_resolution
    # )

    camera_resolutions: EnumProperty(
        name="Camera Resolutions",
        items=[
            ('Horizontal', "Horizontal", "Horizontal"),
            ('Square', "Square", "Square"),
            ('Vertical', "Vertical", "Vertical"),
        ],
        default='Horizontal',
        description="Camera resolution for the timelapse\n\n" \
        "Horizontal = 1920x1080\n" \
        "Square = 1080x1080\n" \
        "Vertical = 1080x1920\n\n" \
        "Note: You can change the resolution in the Settings (Timelapse Settings).",
        update=update_camera_resolution
    )

    camera_list_index: IntProperty(
        name="Active Camera Index",
        default=0,
        update=update_camera_list_index
    )
    
    has_frames: BoolProperty(
        name="Has Frames",
        default=False
    )

    resolution_settings: BoolProperty(
        name="Resolution Settings",
        default=False
    )

    timelpase_speed: EnumProperty(
        name="Timelapse Speed",
        items=[
            ('Fast', "Fast", "Fast, 0.5x resolution & 1 screenshot every second"),
            ('Medium', "Medium", "Medium, 0.75x resolution & 1 screenshot every 3 seconds"),
            ('Slow', "Slow", "Slow, 1x resolution & 1 screenshot every 5 seconds"),
        ],
        default='Fast',
        update=update_timelpase_speed
    )

    render_resolution: EnumProperty(
        name="Render Resolution",
        items=[
            ('0.5', "0.5", "0.5"),
            ('0.75', "0.75", "0.75"),
            ('1', "1", "1"),
        ],
        default='0.5',
    )

    frame_count: bpy.props.IntProperty(
        name="Frame Count",
        default=0
    )

    store_cameras_visibility: BoolProperty(name="",default=False,description="Show Hide Store Cameras Visibility") # type: ignore

    is_paused: BoolProperty(
        name="Paused (waiting for activity)",
        default=False
    )

class SPEEDSCULPT_CameraViewItem(PropertyGroup):
    name: StringProperty(name="Name", default="View") # type: ignore
    store_camera_view_location: FloatVectorProperty(name="Location") # type: ignore
    store_camera_view_rotation: FloatVectorProperty(name="Rotation") # type: ignore

@persistent
def load_post_handler(dummy):
    """Handler appelé après le chargement d'un fichier"""
    scene = bpy.context.scene
    # Réinitialiser la liste
    scene.speedsculpt.geomesh_objects.clear()
    
    # Ajouter tous les objets Geomesh existants
    for obj in scene.objects:
        if obj.name.endswith("_Geomesh"):
            # print(f"Found Geomesh: {obj.name}")
            item = scene.speedsculpt.geomesh_objects.add()
            item.name = obj.name
            item.value = obj.name

# -----------------------------------------------------
# REGISTER
# -----------------------------------------------------
CLASSES = [
            # PropertyGroup categories DOIT être enregistré en premier
            SPEEDSCULPT_PropertyGroup_categories,
            SPEEDSCULPT_PropertyGroup_timelapse,
            SPEEDSCULPT_CameraViewItem,
            
            # GEOMESH ITEM - DOIT être enregistré AVANT SPEEDSCULPT_PropertyGroup
            SPEEDSCULPT_GeomeshItem,
            
            # BACKUP SYSTEM - DOIT être enregistré AVANT SPEEDSCULPT_PropertyGroup
            SPEEDSCULPT_UnifiedBackupItem,
            SPEEDSCULPT_UnifiedObjectBackup,
            
            # ADDON PREFERENCES - Utilise SPEEDSCULPT_PropertyGroup_categories
            SPEEDSCULPT_MT_addon_prefs,
            
            # PROPERTY GROUP - Utilise SPEEDSCULPT_GeomeshItem et les backup items
            SPEEDSCULPT_PropertyGroup,

            # CHECK FOR UPDATES
            SPEEDSCULPT_OT_check_updates,

            # SAVE/RESET/LOAD PREFERENCES
            SPEEDSCULPT_OT_save_preferences,
            SPEEDSCULPT_OT_save_options_preferences,
            SPEEDSCULPT_OT_load_options_preferences,
            SPEEDSCULPT_OT_reset_preferences,

            # RESTORE HOTKEY
            SPEEDSCULPT_OT_restore_hotkey,

            # CATEGORY/PATH MANAGEMENT
            SPEEDSCULPT_OT_add_categories_path,
            SPEEDSCULPT_OT_remove_categories_path,
        ]

def register():
    armature.register()
    curves.register()
    extract_mask.register()
    lattice.register()
    operators.register()
    primitives.register()
    quick_pose.register()
    remesh_decimate.register()
    solo.register()
    symmetrize.register()
    ui.register()
    preview.register()
    modals.register()
    cutter.register()
    timelapse.register()
    speedsculpt_clear_icons()

    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")
    
    global preferences
    preferences = bpy.context.preferences.addons[__name__].preferences

    if not hasattr(bpy.types, "ASSETM_OT_ibl_manupilate"):
        AddonKeymaps.new_keymap('IBL Manipulate', 'speedsculpt.ibl_manipulate', None,
                                '3D View Generic', 'VIEW_3D', 'WINDOW', 'MIDDLEMOUSE',
                                'PRESS', True, True, False, 'NONE'
                                )

    AddonKeymaps.new_keymap('Voxel Remesh', 'object.speedsculpt_remesh_shortcut', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'R',
                            'PRESS', True, False, False, 'NONE'
                            )

    AddonKeymaps.new_keymap('Voxel Size Edition', 'object.speedsculpt_edit_voxel_size', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'R',
                            'PRESS', False, True, False, 'NONE'
                            )

    AddonKeymaps.new_keymap('Smooth Mesh', 'object.speedsculpt_smooth_modal', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'R',
                            'PRESS', True, True, False, 'NONE'
                            )
    
    AddonKeymaps.new_keymap('Toggle Geomesh Visibility', 'object.speedsculpt_toggle_geomesh_visibility_shortcut', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'Q',
                            'PRESS', True, True, False, 'NONE'
                            )
    
    AddonKeymaps.new_keymap('Toggle Modifiers Visibility', 'object.speedsculpt_toggle_modifiers', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'Q',
                            'PRESS', True, False, True, 'NONE'
                            )
    
    AddonKeymaps.new_keymap('Transform Translate Modal', 'object.speedsculpt_quick_translate', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'G',
                            'PRESS', False, False, True, 'NONE'
                            )
    
    AddonKeymaps.new_keymap('Transform Rotate Modal', 'object.speedsculpt_quick_rotate', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'R',
                            'PRESS', False, False, True, 'NONE'
                            )
    
    AddonKeymaps.new_keymap('Transform Scale Modal', 'object.speedsculpt_quick_scale', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'S',
                            'PRESS', False, False, True, 'NONE')
    
    AddonKeymaps.new_keymap('Quick Cursor', 'object.speedsculpt_quick_cursor', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'C',
                            'PRESS', True, True, False, 'NONE'
                            )
    
    AddonKeymaps.new_keymap('Toggle Flat Shading', 'object.speedsculpt_toggle_flat_shading', None,
                            '3D View Generic', 'VIEW_3D', 'WINDOW', 'W',
                            'PRESS', True, True, False, 'NONE'
                            )
    
    # AddonKeymaps.new_keymap('Brush Intensity Modal', 'sculpt.bpm_switch_smooth_brush', None,
    #                         '3D View Generic', 'VIEW_3D', 'WINDOW', 'F',
    #                         'PRESS', False, False, True, 'NONE'
    #                         )

    # AddonKeymaps.new_keymap('Increment Remesh/Dyntopo', 'object.speedsculpt_increment_remesh_and_execute_shortcut', None,
    #                         '3D View Generic', 'VIEW_3D', 'WINDOW', 'R',
    #                         'PRESS', False, False, False, 'NONE'
    #                         )


    AddonKeymaps.register_keymaps()

    # PROPERTYGROUP
    bpy.types.Scene.speedsculpt = PointerProperty(type=SPEEDSCULPT_PropertyGroup)

    bpy.types.Scene.sculpt_timelapse = PointerProperty(type=SPEEDSCULPT_PropertyGroup_timelapse)

    bpy.app.handlers.load_post.append(load_post_handler)

    # Thumbnails
    bpy.types.WindowManager.speedsculpt_previews = EnumProperty(name="Thumbnails", items=speedsculpt_generate_previews,
                                                            description="Select a Mesh")
    
    # BACKUP SYSTEM
    bpy.types.Object.unified_object_backup = PointerProperty(type=SPEEDSCULPT_UnifiedObjectBackup)

    bpy.types.Object.camera_views = bpy.props.CollectionProperty(type=SPEEDSCULPT_CameraViewItem)
    bpy.types.Object.camera_views_index = bpy.props.IntProperty(
        name="Camera Views Index",
        default=-1,
        update=update_camera_view
    )

    # STORE 3DViews
    bpy.types.Scene.view3d_views = CollectionProperty(type=SPEEDSCULPT_PropertyGroup)
    bpy.types.Scene.view3d_views_index = IntProperty(update=update_view3d_view)

    # # STORE CURSORS
    # bpy.types.Scene.cursor_views = CollectionProperty(type=BPM_PropertyGroup)
    # bpy.types.Scene.cursor_views_index = IntProperty(update=update_cursor_view)

    # Library
    pcoll = bpy.utils.previews.new()
    pcoll.images_location = ""
    pcoll.speedsculpt_previews = ()
    speedsculpt_collection["main"] = pcoll

    # CATEGORY
    SC_update_panel(None, bpy.context)

    # CHECK FOR UPDATE
    if preferences.check_for_updates:
        check_update = False
        if bpy.app.version < (4, 2, 0):
            check_update = True

        if bpy.app.version >= (4, 2, 0) and bpy.context.preferences.system.use_online_access:
            check_update = True
            
        if check_update:
            check_for_updates_and_notify()

def unregister():
    AddonKeymaps.unregister_keymaps()
    armature.unregister()
    curves.unregister()
    extract_mask.unregister()
    lattice.unregister()
    operators.unregister()
    primitives.unregister()
    quick_pose.unregister()
    remesh_decimate.unregister()
    solo.unregister()
    symmetrize.unregister()
    ui.unregister()
    preview.unregister()
    modals.unregister()
    cutter.unregister()
    timelapse.unregister()
    speedsculpt_clear_icons()

    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES:
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)

    for previews in speedsculpt_collection.values():
        bpy.utils.previews.remove(previews)

    speedsculpt_collection.clear()

    bpy.app.handlers.load_post.remove(load_post_handler)

    del bpy.types.Object.camera_views
    del bpy.types.Object.camera_views_index
    
    del bpy.types.Scene.view3d_views
    del bpy.types.Scene.view3d_views_index


