'''-*- coding:utf-8 -*-

ProFlow Add-on
Copyright (C) 2020 Cedric Lepiller aka Pitiwazou

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

<pep8 compliant>'''

from ipaddress import collapse_addresses
from tokenize import RARROW
import bpy
from bpy.types import Panel, Operator, UIList, Menu
from .operators import *
from .lattice import *
from .curves import *
from .functions import get_addon_preferences
from .preview import *
from .timelapse import *
import os
from .icon.icons import load_icons
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper


def is_bsurface_activated():
    return any('bsurface' in addon.lower() for addon in bpy.context.preferences.addons.keys())

def is_looptools_activated():
    return any('looptools' in addon.lower() for addon in bpy.context.preferences.addons.keys())

# -----------------------------------------------------------------------------
#    Help
# -----------------------------------------------------------------------------

class SPEEDSCULPT_OT_help(Operator):
    bl_idname = "object.speedsculpt_help"
    bl_label = "Help"
    bl_description = "Help menu"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        icons = load_icons()
        prefs = get_addon_preferences()
        layout = self.layout
        layout.prop(prefs, 'show_help', text="Show Addon Help")
        layout.prop(prefs, 'show_warning', text="Show Addon Warning")
        layout.prop(prefs, 'show_troubleshooting', text="Show Addon Troubleshooting")
        layout.separator()
        layout.label(text="Speedsculpt Help menu", icon_value=icons.get("icon_speedsculpt").icon_id)
        layout.separator()
        layout.label(text="What Speedsculpt can do for you:")
        layout.separator()
        layout.label(text="• Base Creation quickly with Primitives tools")
        layout.label(text="• Access to an Asset Library for reusable elements and kitbashing")
        layout.label(text="• Powerful Creation Tools for blocking out your character or concept")
        layout.label(text="• Advanced Boolean and Cut Tools for fast modeling workflows")
        layout.label(text="• Curve tools for creating ropes, cables, horns, tentacles, and more")
        layout.label(text="• Skin, Envelope, and Lattice tools for non-destructive modeling and deformation")
        layout.label(text="• Remesh and Dyntopo support for dynamic topology and clean meshes")
        layout.label(text="• Store, update, and recall 3D cursor and camera views easily")
        layout.label(text="• Quick pose, extract mask, quick rig, and muscle helpers")
        layout.label(text="• Powerful backup utilities and one-click backup system")
        layout.label(text="• Backup your meshes and restore them easily")
        layout.label(text="• Store and update your 3D cursor and camera views easily")
        layout.label(text="• Timelapse camera to record your progress directly in Blender")
        layout.label(text="• And much more...")
        layout.separator()
        layout.label(text="Unleash your speed in sculpting with all-in-one tools and assets!")

class SPEEDSCULPT_OT_help_dyntopo_remesh(Operator):
    bl_idname = "object.speedsculpt_help_dyntopo_remesh"
    bl_label = "Remesh / Dyntopo"
    bl_description = "Help Remesh / Dyntopo, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout

        icons = load_icons()
        prefs = get_addon_preferences()

        layout = self.layout
        layout.label(text="With Blender you can now choose Between Remesh or Dyntopo.")
        layout.separator()
        layout.label(text="REMESH -", icon='MESH_UVSPHERE')
        layout.label(text="Remeshing is a technique that automatically rebuilds the geometry")
        layout.label(text="with a more uniform topology.")
        layout.label(text="Remeshing can either add or remove the amount of topology")
        layout.label(text="depending on a defined resolution.")
        layout.label(text="This technique is especially useful for sculpting,")
        layout.label(text="to generate better topology")
        layout.label(text="after blocking out the initial shape.")
        layout.separator()
        layout.label(text="DYNTOPO -", icon='MESH_ICOSPHERE')
        layout.label(text="Dyntopo is a dynamic tessellation sculpting method,")
        layout.label(text="adds and removes details on-the-fly,")
        layout.label(text="whereas regular sculpting only affects the shape of a mesh.")
        layout.separator()
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="Both are great, but Remesh gives better results and performances.")
        layout.label(text="The best is to use Remesh to make the base of your model.")
        layout.label(text="Once ok, start using Dyntopo to be able to add details.")

        row = layout.row(align=True)
        row.scale_y = 1.3
        row.operator("wm.url_open", text="DOCUMENTATION",
                            icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/6BFCV7jobrM"

        # layout.separator()
        # layout.operator("wm.url_open", text="Remesh / Dyntopo video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_dyntopo_remesh_setting(Operator):
    bl_idname = "object.speedsculpt_help_remesh_dyntopo_settings"
    bl_label = "Remesh / Dyntopo - Settings"
    bl_description = "Help Remesh / Dyntopo - Settings, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout

        icons = load_icons()
        layout.label(text="REMESH/DYNTOPO - Settings")
        layout.separator()
        
        layout.label(text="Will smooth the mesh to have better forms.", icon_value=icons.get("icon_s").icon_id)
        
        layout.label(text="Update, it will convert the mesh using Remesh or Dyntopo.",icon_value=icons.get("icon_u").icon_id)
        
        layout.label(text="        REMESH")
        layout.label(text="        The resulting mesh will be remeshed with Quads.")
        
        layout.label(text="        DYNTOPO")
        layout.label(text="        The resulting mesh will be remeshed with Triangles.")
        
        layout.label(text="Will smooth the mesh without updating the geometry.", icon_value=icons.get("icon_corrective_smooth").icon_id)
        
        layout.label(text="Options for each mode to edit the shading, fill holes, etc.", icon_value=icons.get("icon_options").icon_id)

        # layout.operator("wm.url_open", text="Remesh / Dyntopo Settings video tutorial",
        #                 icon_value=icons.get("icon_youtube").get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_dyntopo_remesh_value(Operator):
    bl_idname = "object.speedsculpt_help_remesh_dyntopo_value"
    bl_label = "Remesh / Dyntopo - Value"
    bl_description = "Help Remesh / Dyntopo - Value, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="REMESH MODE - Remesh Value", icon='MESH_UVSPHERE')
        layout.separator()
        layout.label(text="The resolution or the amount of detail the remeshed mesh will have.")
        layout.label(text="The value is used to define the size, in object space, of the quads.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="Smaller value gives smaller quads.")
        layout.separator()
        layout.label(text="DYNTOPO Mode - Resolution", icon='MESH_ICOSPHERE')
        layout.separator()
        layout.label(text="The resolution or the amount of detail the remeshed mesh will have.")
        layout.label(text="The value is used to define the size, in object space, of the Triangles.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="Higher value gives smaller Triangles.")

        # layout.operator("wm.url_open", text="Remesh / Dyntopo Value video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_shading(Operator):
    bl_idname = "object.speedsculpt_help_shading"
    bl_label = "Help Shading"
    bl_description = "Help Shading, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="You can edit settings by clicking on the SHADING button")
        
        layout.separator()
        
        layout.label(text="SOLO", icon_value=icons.get("icon_shading").icon_id)
        layout.label(text="Make non selected objects transparent.")
        
        layout.separator()
        layout.label(text="CLICK - Solo the Selection.")
        layout.label(text="SHIFT+CLICK - Add the Selection.")
        layout.label(text="CTRL+CLICK - Remove the Selection.")
        layout.label(text="ALT+CLICK - Invert the Selection.")
        layout.label(text="CTRL+SHIFT+CLICK - Exit.")
        
        layout.separator()
        
        layout.label(text="STUDIO", icon='LIGHT_SPOT')
        layout.label(text="Studio Shading.")
        layout.separator()
        layout.label(text="CTRL+SHIFT+CLICK - Rotate the Environment.")
        
        layout.separator()
        
        layout.label(text="MATCAPS", icon='NODE_MATERIAL')
        layout.label(text="Basic Matcaps.")
        
        layout.separator()
        
        layout.label(text="SILOUHETE", icon='OUTLINER_OB_VOLUME')
        layout.label(text="Silhouete Shading to check your Mesh proportions.")
        layout.label(text="You can change the color in the SHADING part.")
        
        layout.separator()
        
        layout.label(text="WIREFRAME", icon='SHADING_WIRE')
        layout.label(text="Activate the Wireframe.")

class SPEEDSCULPT_OT_help_creation_tools(Operator):
    bl_idname = "object.speedsculpt_help_creation_tools"
    bl_label = "Help Creation Tools"
    bl_description = "Help Creation Tools, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="Speedsculpt gives you a bunch of tools to simplify the creation of your assets.", icon_value=icons.get("icon_tools").icon_id)
        layout.label(text="You will have first the choose about how you will create the assets.")
        layout.separator()
        layout.label(text="MOUSE", icon='MOUSE_MMB')
        layout.label(text="The asset will be created on your mouse, you will directly move it where you want.")
        layout.separator()
        layout.label(text="Origin", icon='OBJECT_ORIGIN')
        layout.label(text="The asset will be created at the origin of the scene (center of the grid).")
        layout.separator()
        layout.label(text="CURSOR", icon='PIVOT_CURSOR')
        layout.label(text="The asset will be created at the Cursor location.")
        layout.label(text="If you activate the 'Cursor Rot' option, the asset will copy the Cursor Rotation.")
        layout.separator()
        layout.label(text="SELECTION", icon='RESTRICT_SELECT_OFF')
        layout.label(text="The asset will be created at the center of your selection.")
        layout.separator()
        layout.label(text="PARENT", icon='ORIENTATION_PARENT')
        layout.label(text="The new asset will be the child of your active object selected.")
        layout.label(text="This is usefull to create a hierarchy of objects")
        layout.label(text="and edit a bunch of objects at the same time.")
        layout.separator()
        layout.label(text="MIRROR", icon='MOD_MIRROR')
        layout.label(text="The new asset will have a mirror modifier.")
        layout.label(text="You will choose the Axis you want and the object as reference.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="All the tools created with speedsculpt will take these settings into account.")
        layout.label(text="It can be all the settings, or only Parent and Mirror.")

        # layout.operator("wm.url_open", text="Creation Tools video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_primitives(Operator):
    bl_idname = "object.speedsculpt_help_primitives"
    bl_label = "Help Primitives"
    bl_description = "Help Primitives, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Basic set of Primitives to make your assets.", icon_value=icons.get("icon_primitives").icon_id)
        layout.label(text="Depending of the mode (REMESH/DYNTOPO), your primitives will be made of quads or triangles")
        layout.label(text="if you activate the Update Option.")
        layout.separator()
        layout.label(text="WORKFLOW")
        layout.label(text="- Select the MOUSE mode, click on a primitive and move it where you want.")
        layout.label(text="   You can now edit it with Sculpting tools and merge it with other objects.")
        layout.label(text="- If you have a selection, you can set the PARENT and MIRROR options and create your primitive.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="You can place Meshes primitives and Metaballs at the same time, the addon will convert them.")

        # layout.operator("wm.url_open", text="Creation Tools video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_asset_library(Operator):
    bl_idname = "object.speedsculpt_help_asset_library"
    bl_label = "Help Assets Library"
    bl_description = "Help Assets Library, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="With the Assets Library, yout can add custom objects to your scene.", icon_value=icons.get("icon_library").icon_id)
        layout.label(text="The Assets Library takes into account the options (MOUSE, CURSOR, ORIGIN, SELECTION, PARENT, MIRROR).")
        layout.label(text="This is the best solution to gain time on your sculpt with custom assets.")
        layout.separator()
        layout.label(text="You can add your own assets to the library.")
        layout.label(text="You can add Categories.")
        layout.separator()
        layout.label(text="If you bought the Asset Management Addon, you will be able to display some categories inside speedsculpt.")
        layout.label(text="To do this, go into the preferences of speedsculpt in the Blender Preferences > Add-ons > Speedscukpt.")
        layout.label(text="And go into the Option tab > ASSETS LIBRARY SETTINGS and click on the ADD NEW CATEGORY button.")
        layout.label(text="Go to you Asset Management library, enter inside a category and validate.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="You can check the information button for more insite.")

        layout.operator("wm.url_open",text="ASSET MANAGEMENT ADDON", icon_value=icons.get("icon_gumroad").icon_id).url = "https://gumroad.com/l/asset_management"

        # layout.operator("wm.url_open", text="Assets Library video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_draw_mesh(Operator):
    bl_idname = "object.speedsculpt_help_draw_mesh"
    bl_label = "Help Draw Mesh"
    bl_description = "Help Draw Mesh, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="The DRAW MESH tool is a really nice way to make objects.", icon_value=icons.get("icon_draw_mesh").icon_id)
        layout.label(text="It works with the Grease Pencil.")
        layout.separator()
        layout.label(text="Start by selecting the option you want, CURSOR or SURFACE.")
        layout.label(text="")
        layout.label(text="CURSOR", icon='PIVOT_CURSOR')
        layout.label(text="Will draw the Grease Pencil at the Cursor location.")
        layout.label(text="")
        layout.label(text="SURFACE", icon='SURFACE_NSURFACE')
        layout.label(text="Will draw the Grease Pencil on the surface of objects in the scene.")
        layout.label(text="")
        layout.label(text="DRAW SIZE", icon='SURFACE_NCYLINDER')
        layout.label(text="Will determine the widh of the mes created.")
        layout.separator()
        layout.label(text="Once the settings are OK, click on the Draw Mesh button and start to draw.")
        layout.label(text="You will be in a draw mode, you will have information at the bottom left of the 3DView.")
        layout.label(text="Press SPACE to validate and exit the Draw Mode.")

        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="- You can draw more than one line.")
        layout.label(text="- The tool works with the MIRROR option.")
        layout.label(text="- If you have a selection, the drawing will be merged with your selection.")
        layout.label(text="- If you have nothin selected, the drawing will creates a new object.")

        # layout.operator("wm.url_open", text="Draw Mesh video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_draw_surface(Operator):
    bl_idname = "object.speedsculpt_help_draw_surface"
    bl_label = "Help Draw Surface"
    bl_description = "Help Draw Surface, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Create surfaces with Bsurface and Grease Pencil.", icon_value=icons.get("icon_surface").icon_id)
    
        layout.separator()
        layout.label(text="Edit the Settings & Click on DRAW SURFACE.")
        layout.label(text="Draw parrallel lines and press SPACE/ENTER.")
        layout.label(text="That will create an object and you will be able to edit it with the Thickness setting")
        layout.label(text="if you disable the Update and Smooth settings.")
        layout.label(text="You can add a Mirror and a Bevel Modifier too.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="- You need to create the lines in the same direction, check Bsurface videos on Youtube for more information.")
        layout.label(text="- To delete a drawing, press D + RIGHT MOUSE BUTTON and Drag.")

class SPEEDSCULPT_OT_help_draw_curve(Operator):
    bl_idname = "object.speedsculpt_help_draw_curve"
    bl_label = "Help Draw Curve"
    bl_description = "Help Draw Curve, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Create Curves with Rounded Caps.", icon_value=icons.get("icon_draw_curve").icon_id)
    
        layout.separator()
        layout.label(text="Edit the Settings & Click on DRAW CURVE.")
        layout.label(text="Draw a line and the curve will appear.")
        layout.label(text="To edit the Thickness of a point, select it")
        layout.label(text="and press ALT + S.")
        layout.label(text="You can add a Mirror and Parent.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="- You need to select the tweak tool after creating the Curve.")

class SPEEDSCULPT_OT_help_create_cut_tools(Operator):
    bl_idname = "object.speedsculpt_help_create_cut_tools"
    bl_label = "Help Create or cut tools"
    bl_description = "Help Create or cut tools, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        
        layout.label(text="CUTTER TOOLS is a suite of tool to create forms or to cut Meshes.", icon_value=icons.get("icon_cutter").icon_id)

        layout.separator()
        
        layout.label(text="CREATE", icon='MESH_CUBE')
        layout.label(text="Set Width of the Mesh you will create.")
        layout.label(text="Select the tool you will use (RECTANGLE, CIRCLE, Line or Curve).")
        layout.label(text="You will enter in a modal, a mode with option at the bottom left corner of the 3DView.")
        layout.label(text="Click and drag to draw you cutting object.")

        layout.separator()
        
        layout.label(text="CUT", icon='MOD_BOOLEAN')
        layout.label(text="Select the operation you want to do, UNION, DIFFERENCE OR REBOOL.")
        layout.label(text="Select the tool you will use .")
        layout.label(text="You will enter in a modal.")
        layout.label(text="Click and drag to draw you cutting object.")

        layout.separator()
        
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="- The cutting part can take time on dense objects, be patient.")
        layout.label(text="- By pressing CTRL when clicking on an object, you will set the Cursor on the surface of the object.")
        layout.label(text="- The new mesh will follow the Cursor rotation.")

        # layout.operator("wm.url_open", text="Cutter tools video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_skin(Operator):
    bl_idname = "object.speedsculpt_help_skin"
    bl_label = "Help Skin"
    bl_description = "Help Skin, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="Create objects with skin Modifier.")
        layout.label(text="Perfect to create Characters or parts like Teeth, etc.")
        layout.separator()
        layout.label(text="DRAW SKIN", icon_value=icons.get("icon_draw_skin").icon_id)
        layout.label(text="Click and trace the form you want.")
        layout.label(text="Go in edit mode to edit it.")
        layout.label(text="To scale a point, press CTRL + A.")
        layout.separator()
        layout.label(text="ADD SKIN", icon_value=icons.get("icon_skin").icon_id)
        layout.label(text="When activating the tool, you will have only one vertex.")
        layout.label(text="place it where you want.")
        layout.label(text="To Extrude it, use E key or CTRL + RMB.")
        layout.label(text="To scale a point, press CTRL + A.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="When using a mirror modifier and Origin setting,")
        layout.label(text="The vertex will be at the center of the scene.")
        layout.label(text="To Extrude it, use CTRL + RMB and move your mouse.") 

        # layout.operator("wm.url_open", text="Assets Library video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_envelope(Operator):
    bl_idname = "object.speedsculpt_help_envelope"
    bl_label = "Help Envelope"
    bl_description = "Help Envelope, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Create Armature to make your character.", icon_value=icons.get("icon_enveloppe") .icon_id)
        
        layout.label(text="You can use the origin option from primitives to place it at the center of the grid.")
        layout.separator()
        layout.label(text="You can select and symmetrize bones.")
        layout.label(text="And use the X-Axis Mirror to tweak both sides.")
        layout.separator()
        layout.label(text="Change the Dyntopo or Remsh Value with Smooth Options/Update and Click on the Convert button.")
        layout.separator()
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="To scale a bone, press ALT + S.")
        layout.label(text="To extrude a bone, press E or CTRL + RMB.")

        # layout.operator("wm.url_open", text="Enveloppe video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_curves(Operator):
    bl_idname = "object.speedsculpt_help_curves"
    bl_label = "Help Curves"
    bl_description = "Help Curves, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.separator()
        
        layout.label(text="LATHE", icon_value=icons.get("icon_lathe").icon_id)
        layout.label(text="Create a Lathe by drawing in the 3Dview.")
        
        layout.separator()
        
        layout.label(text="CURVE", icon_value=icons.get("icon_curve").icon_id)
        layout.label(text="Create a curve by drawing in the 3Dview.")
        layout.label(text="You can Edit the Resolution of the curve.")
        layout.label(text="You can convert the Curve into a skin Modifier.")
        
        layout.separator()
        
        layout.label(text="You can also make a mesh from it by clicking ont the BBox button.")
        layout.label(text="Edit the Settings for the Depth, Offset and Bevel.")
        
        layout.separator()
        
        layout.label(text="If you stay in Curve Mode, you can Edit the settings and the Curve itself.")
        layout.label(text="After that, you can convert it in REMESH or DYNTOPO.")
        # layout.separator()
        # layout.label(text="Examples :")
        # layout.operator("wm.url_open", text="Convert Curve to skin").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/convert_curve.gif"
        # layout.operator("wm.url_open", text="Slice/Cut/Rebool objects with curves").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/curves_slice.gif"

class SPEEDSCULPT_OT_help_symmetrize(Operator):
    bl_idname = "object.speedsculpt_help_symmetrize"
    bl_label = "Help Symmetrize"
    bl_description = "Help Symmetrize, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Symmetrize your selection.", icon_value=icons.get("icon_symmetrize").icon_id)
        
        layout.separator()
        
        
        layout.label(text="You can choose the direction of the Symmetrize.", icon_value=icons.get("icon_sym_plus_x").icon_id)
        layout.label(text="The mesh will be symmetrized.")
        layout.label(text="If you Activated the UPDATE button, the mesh will be remeshed")
        layout.label(text="depending of the mode you chose REMESH/DYNTOPO.")

        # layout.operator("wm.url_open", text="Symmetrize video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_tools(Operator):
    bl_idname = "object.speedsculpt_help_tools"
    bl_label = "Help Tools"
    bl_description = "Help Tools, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        
        layout.label(text="Bunch of tools to help you in your sculpting process.")
        layout.separator()
        layout.label(text="COPY DATA TO SELECTION:")
        layout.label(text="You can copy the data from the active object to the selection.")
        layout.label(text="A pop-up will appear to choose the options you want to copy.")
        layout.label(text="Materials, modifiers and make the selected objects single user.")
        layout.separator()
        layout.label(text="The tool will always copy the datas from the active object to the selection.")
        layout.separator()
        layout.label(text="CREATE GROUP:")
        layout.label(text="You can create a group from the selection.")
        layout.label(text="A pop-up will appear to choose the options you want to create the group.")
        layout.separator()
        layout.label(text="EDIT OBJECT SIZE:")
        layout.label(text="You can edit the size of the selected objects.")
        layout.label(text="A pop-up will appear to choose the options you want to edit the size.")
        layout.separator()
        layout.label(text="SEPARATE BY LOOSE PART:")
        layout.label(text="You can separate the selected objects by loose part.")
        layout.separator()
        layout.label(text="SEPARATE BY MATERIAL:")
        layout.label(text="You can separate the selected objects by material.")
        layout.separator()
        layout.label(text="SEPARATE SELECTED:")
        layout.label(text="You can separate the selected faces, edges and vertices.")
        layout.separator()
        layout.label(text="SCULPT MODE - LINE PROJECT:")
        layout.label(text="Cut the selection from a line in the 3Dview.")
        layout.separator()
        layout.label(text="SCULPT MODE - TRIM TOOLS:")
        layout.label(text="Cut the selection from a box/Lasso/Line in the 3Dview.")
        layout.separator()
        layout.label(text="SCULPT MODE - ADD TOOLS:")
        layout.label(text="Add a box/Lasso mesh in the 3Dview.")

class SPEEDSCULPT_OT_help_lattice(Operator):
    bl_idname = "object.speedsculpt_help_lattice"
    bl_label = "Help Lattice"
    bl_description = "Help Lattice, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Create Lattice and deform your mesh", icon_value=icons.get("icon_lattice").icon_id)
        
        layout.separator()
        
        layout.label(text="You can Edit the Lattice and connect/Disconnect Objects from it")
        layout.label(text="You can also use Mask to create the Lattice on your Mesh")
        # layout.separator()
        # layout.label(text="Example :")
        # layout.operator("wm.url_open", text="Add Lattice and deform objects").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/lattices.gif"
        # layout.operator("wm.url_open", text="Lattice video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_remesh(Operator):
    bl_idname = "object.speedsculpt_help_remesh"
    bl_label = "Help Remesh"
    bl_description = "Help Remesh, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()        
        layout.label(text="REMESH", icon_value=icons.get("icon_remesh").icon_id)
        
        layout.label(text="Add a Remesh Modifier.")
        layout.label(text="You can Edit the Settings and Apply/Remlove it.")
        
        layout.separator()
        
        layout.label(text="DECIMATE", icon_value=icons.get("icon_decimate").icon_id)
        
        layout.label(text="Simplify your mesh or use mask to simplify a part of it")
        layout.label(text="You can Edit the Settings and Apply/Remlove it.")
        
        layout.separator()
        
        layout.label(text="QUADRIFLOW", icon_value=icons.get("icon_quadriflow").icon_id)
        
        layout.label(text="It's a retopology tool")
        layout.label(text="Edit the Settings and click on OK.")
        
        # layout.separator()
        # layout.label(text="Examples :")
        # layout.operator("wm.url_open", text="Remesh object").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/remesh.gif"
        # layout.operator("wm.url_open", text="Decimate mesh with mask").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/decimate.gif"
        # layout.operator("wm.url_open", text="Remesh video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"

class SPEEDSCULPT_OT_help_extract_mask(Operator):
    bl_idname = "object.speedsculpt_help_extract_mask"
    bl_label = "Help Extract Mask"
    bl_description = "Help Extract Mask, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Mask Operations to Extract, Cut, and Slice a part of your Mesh.", icon_value=icons.get("icon_mask").icon_id)

        layout.separator()
        layout.label(text="You will have to choose between Mask and Face Sets")
        layout.label(text="You will have 3 possible Operations")
        layout.label(text="EXTRACT - CUT - SLICE")
        
        layout.separator()
        layout.label(text="EXTRACT", icon='OVERLAY')
        layout.label(text="Create a new object from the mask or the Face Set")
        
        layout.separator()
        
        layout.label(text="CUT", icon='MOD_SUBSURF')
        layout.label(text="Cut the mesh from the mask or the Face Set")

        layout.label(text=" ")
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="It will add a hole in the mesh,")
        layout.label(text="You can use the Fill Hole setting in dyntopo to close it")
        
        layout.separator()
        
        layout.label(text="SLICE", icon='SEQ_STRIP_DUPLICATE')
        layout.label(text="It will Slice the mesh from the mask or the Face Set")

        layout.label(text=" ")
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="When Using Face Sets, you need to isolate the part you want to edit")
        layout.label(text="Using SHIFT + H")
        layout.label(text="ALT + H will reveal the hidden parts")
        
        layout.separator()


        layout.label(text="You will be able to Add a Thichness with a Solidify Modifier,")
        layout.label(text="and edit it's value")
        layout.label(text="After that you will be able to apply the solidify and go to Sculpt mod")

        layout.label(text=" ")
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="This tool work for Remesh and dyntopo")

class SPEEDSCULPT_OT_help_quickpose(Operator):
    bl_idname = "object.speedsculpt_help_quickpose"
    bl_label = "Help Quick Pose"
    bl_description = "Help Quick Pose, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Make a quick pose of your model.", icon_value=icons.get("icon_quick_pose").icon_id)
        layout.label(text="You can use mask to pose only a part")
        layout.separator()
        layout.label(text="Direct Pose", icon='POSE_HLT')
        layout.label(text="Click on Create Bones, place the vertice, extrude it")
        layout.label(text="Click on the Pose button and make your pose")
        layout.separator()
        layout.label(text="Mask Pose", icon='MOD_MASK')
        layout.label(text="Click on Use Mask and Add Mask")
        layout.label(text="Paint your mask")
        layout.label(text="Click on Create Bones, place the vertice, extrude it")
        layout.label(text="Click on the Pose button and make your pose")
        layout.separator()
        layout.label(text="You can Edit and smooth your mask")
        layout.separator()
        layout.label(text="The creation of the Armature don't work in Local View", icon='ERROR')
        
        # layout.operator("wm.url_open", text="Quick Pose video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"
        # layout.separator()
        # layout.label(text="Example :")
        # layout.operator("wm.url_open", text="Quick Pose with mask").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/quick_pose_mask.gif"

class SPEEDSCULPT_OT_help_muscles(Operator):
    bl_idname = "object.speedsculpt_help_muscles"
    bl_label = "Help Muscles"
    bl_description = "Help Muscles, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="This tools allow you to edit the Muscles from the library")
        layout.separator()
        layout.label(text="You can edit the Thickness of the Muscle to change his form.")
        layout.label(text="You can change the Offset to make different type of Muscle.")
        layout.label(text="And also the Factor to change the tips Thickness.")
        layout.separator()
        layout.label(text="In Edit Mode, you will be abble to add vertices to the Vertex Group.")
        layout.label(text="That will allow you to put the selection in the vertex group")
        layout.label(text="and change the form of the Muscles.")
        layout.label(text="You can add or remove vertices from the Vertex Group with the buttons")
        layout.label(text="Assign and Remove, aslo select the vertices in the Vertex Group.")
        layout.separator()
        layout.label(text="Notes", icon='TEXT')
        layout.label(text="This tool will only work with the Muscles from the library.")
        layout.label(text="Once you make a Remesh, you will not be able to edit the muscles no more.")
        
        # layout.operator("wm.url_open", text="Quick Pose video tutorial",
        #                 icon_value=icons.get("icon_youtube").icon_id).url = "https://youtu.be/Xzxsq0BGExs?list=PLU9vgvxEeKSUY8C4IN9o2a283itPlivEp"
        # layout.separator()
        # layout.label(text="Example :")
        # layout.operator("wm.url_open", text="Quick Pose with mask").url = "http://www.pitiwazou.com/wp-content/uploads/2016/08/quick_pose_mask.gif"

class SPEEDSCULPT_OT_help_geomesh(Operator):
    bl_idname = "object.speedsculpt_help_geomesh"
    bl_label = "Help Geomesh"
    bl_description = "Help Geomesh, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Create Geomesh objects.", icon_value=icons.get("icon_geomesh").icon_id)
        layout.label(text="To create a Geomesh Object, you need to put the objects in a Collection")
        layout.label(text="Then you can create a Geomesh Object from the Collection")
        layout.separator()
        layout.label(text="1 - Click on the Geomesh button in the Creation Tools")
        layout.label(text="2 - Select the Collection you want to use")
        layout.label(text="3 - Add a name to the Geomesh Object")
        layout.label(text="4 - Click on Create Geomesh")
        layout.label(text="The Geomesh Object will be created at the root of the Collections")
        layout.separator()
        layout.label(text="In the UI, you will see the Geomesh Object in a List")
        layout.label(text="Within this List, you will be able to:")
        layout.label(text=" ")
        layout.label(text="Rename the Geomesh Object by clicking on the Icon", icon_value=icons.get("icon_geomesh").icon_id)
        layout.label(text="Select the Item in the list to Edit the Geomesh Object")
        layout.label(text="Show/Hide the Geomesh Object", icon='HIDE_OFF')
        layout.label(text="Select the Geomesh Object", icon='RESTRICT_SELECT_OFF')
        layout.label(text="Lock the Geomesh Object", icon='DECORATE_LOCKED')
        layout.label(text="Use Show In Front", icon='CLIPUV_DEHLT')
        layout.label(text="Toggle the Mirror Modifier", icon='HIDE_OFF')
        layout.label(text="Delete the Geomesh Object", icon_value=icons.get("icon_trash").icon_id)
        layout.separator()
        layout.label(text="Once you select an item in the list, you will be able to:")
        layout.label(text="• Edit the Voxel Size (The density of the mesh), Smaller is more detailed")
        layout.label(text="• Smooth the Mesh")
        layout.label(text="• Activate the Shade Smooth")
        layout.label(text="• Use Booleans")
        layout.separator()
        layout.label(text="If the Boolean is activated, you will have to select a Collection")
        layout.label(text="The Boolean Mode used will be 'DIFFERENT' to Cut the Geomesh Object")
        layout.separator()
        layout.label(text="Show/Hide the Geomesh Object", icon='HIDE_OFF')
        layout.label(text="Use the Shortcut CTRL+SHIFT+Q to toggle the Geomesh Object visibility")
        layout.label(text="You can change it in the Preferences")

class SPEEDSCULPT_OT_help_backup(Operator):
    bl_idname = "object.speedsculpt_help_backup"
    bl_label = "Help Backup"
    bl_description = "Help Backup, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()

        layout.label(text="Backup to Collection", icon_value=icons.get("icon_collection").icon_id)
        layout.separator()
        layout.label(text="Copy selected objects to BACKUPS collection.")
        layout.separator()
        layout.label(text="Backup to List", icon_value=icons.get("icon_list").icon_id)
        layout.separator()
        layout.label(text="Create a backup of the active object and add it to the list.")
        layout.label(text="The Backups are in the scene and not visible in the outliner.")
        layout.label(text="You can create Backups of your Mesh and restore them later.")
        layout.separator()
        layout.label(text="Apply a Backup to your Mesh to restore it to previous state.", icon_value=icons.get("icon_valid").icon_id)
        layout.label(text="Add back the backup to the scene.", icon_value=icons.get("icon_mesh").icon_id)
        layout.label(text="Delete a Backup from the list.", icon_value=icons.get("icon_trash").icon_id)
        layout.separator()
        layout.label(text="Clear all backups by clicking on the Trash icon", icon_value=icons.get("icon_trash").icon_id)
        layout.label(text="next to Backup to List.")
        layout.separator()
        layout.label(text="Clear all backups in the scene by clicking on the Trash icon", icon_value=icons.get("icon_trash").icon_id)
        layout.label(text=" below the list.")

class SPEEDSCULPT_OT_help_array_curve(Operator):
    bl_idname = "object.speedsculpt_help_array_curve"
    bl_label = "Help Array Curve"
    bl_description = "Help Array Curve, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Create Array Curve", icon_value=icons.get("icon_array_curve").icon_id)
        
        layout.separator()
        layout.label(text="This tool allows you to create horns")
        layout.label(text="You can Array Curve from a mesh or simply draw it in the 3D View")
        layout.label(text="You can use the surface of a mesh or the cursor to place the curve")
        
        layout.separator()
        layout.label(text="If you have a selection, the Array Curve will be created from the selection")
        layout.label(text="If you don't have a selection, the Array Curve will be created with a sphere")
        layout.label(text="If you set the Curve Object, the Array Curve will be created with the curve object")
        layout.separator()
        layout.label(text="Note: If Curve Object is set, the Array Curve will always use the curve object", icon='INFO')
        
        layout.separator()
        layout.label(text="Once the Array Curve is created, you can edit it in the settings")
        layout.label(text="Visibility, Apply, Remove")
        layout.label(text="Offset, in X, Y and Z, you can change the offset direction too.")
        layout.label(text="You can add a start and end cap to the array.")
        
        layout.separator()
        layout.label(text="If you activate the mirror setting, the Array Curve will be mirrored on the X, Y or Z axis")
        
        layout.separator()
        layout.label(text="Once you are OK, you can Remesh the Mesh to apply the Array Curve")

class SPEEDSCULPT_OT_help_timelapse(Operator):
    bl_idname = "object.speedsculpt_help_timelapse"
    bl_label = "Help Timelapse"
    bl_description = "Help Timelapse, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Timelapse", icon_value=icons.get("icon_timelapse").icon_id)
        
        layout.separator()
        layout.label(text="Timelapse lets you record your scene as images.")
        layout.label(text="Select or add a camera, then start recording.")
        layout.label(text="Images are saved in your chosen folder.")
        layout.label(text="You can compile the images into a video.")
        layout.separator()
        layout.label(text="SETTING UP THE TIMELAPSE")
        layout.separator()
        layout.label(text="1- Set the path to save the images")
        layout.label(text="2- Choose a mode, Fast, Medium or Slow")
        layout.label(text="3- Set the capture interval (in seconds)")
        layout.label(text="4- Set the Format (Horizontal, Square or Vertical)")
        layout.label(text="5- Select or add a camera")
        layout.label(text="6- Start the recording")
        layout.label(text="7- Stop the recording")
        layout.label(text="8- Compile the video")
        layout.separator()
        layout.label(text="- You can use as many cameras as you want")
        layout.label(text="    and switch between them by clicking on the camera in the list")
        layout.label(text="- You can store the camera views.")
        layout.label(text="- You can add a target to the camera to track the camera to the target")
        layout.label(text="- When you click on Compile MP4, the tool will compile the video from the images")
        layout.label(text="- You can set the video settings in the popup window")
        layout.label(text="- Once the compilation is done, you can open the folder to see the video", icon_value=icons.get("icon_search_in_folder").icon_id)

class SPEEDSCULPT_OT_help_cursor(Operator):
    bl_idname = "object.speedsculpt_help_cursor"
    bl_label = "Help Cursor"
    bl_description = "Help Cursor, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Cursor", icon_value=icons.get("icon_cursor").icon_id)
        layout.label(text="Cursor to Selection:")
        layout.label(text="Place the Cursor at the location of the selected objects.")
        layout.separator()
        layout.label(text="SELECTION TO CURSOR:")
        layout.label(text="Move the Object to the location of the Cursor.")
        layout.separator()
        layout.label(text="CURSOR TO OBJECT:")
        layout.label(text="Copy the transforms of the Cursor to the selected objects.")
        layout.separator()
        layout.label(text="OBJECT TO CURSOR:")
        layout.label(text="Copy the transforms of the selected objects to the Cursor.")
        layout.separator()
        layout.label(text="CLEAR CURSOR TRANSFORMS:")
        layout.label(text="Clear the transforms of the Cursor.")
        layout.separator()
        layout.label(text="STORE CURSOR TRANSFORMS:")
        layout.label(text="Store the transforms of the Cursor in the list.")
        layout.label(text="You can rename, update and delete the stored cursors.")

class SPEEDSCULPT_OT_help_store_views(Operator):
    bl_idname = "object.speedsculpt_help_store_views"
    bl_label = "Help Store Views"
    bl_description = "Help Store Views, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Store Views", icon_value=icons.get("icon_areas").icon_id)
        layout.label(text="Store the views of the 3D View in the list.")
        layout.label(text="You can rename, update and delete the stored views.")

class SPEEDSCULPT_OT_help_hierarchy(Operator):
    bl_idname = "object.speedsculpt_help_hierarchy"
    bl_label = "Help Hierarchy"
    bl_description = "Help Hierarchy, click on the button"

    def execute(self, context):
        return {'FINISHED'}

    def check(self, context):
        return True

    def invoke(self, context, event):
        dpi_value = bpy.context.preferences.view.ui_scale
        coef = dpi_value * (-175) + 525
        return context.window_manager.invoke_popup(self, width=int(dpi_value * coef))

    def draw(self, context):
        layout = self.layout
        icons = load_icons()
        
        layout.label(text="Hierarchy", icon_value=icons.get("icon_parent").icon_id)
        layout.label(text="Hierarchy lets you organize your scene.")
        layout.separator()
        layout.label(text="SELECT PARENT:")
        layout.label(text="Select the direct parent of the selected objects.")
        layout.separator()
        layout.label(text="SELECT LAST PARENT:")
        layout.label(text="Select the last parent of the selected objects.")
        layout.separator()
        layout.label(text="SELECT CHILDREN:")
        layout.label(text="Select the children of the selected objects.")
        layout.separator()
        layout.label(text="SELECT HIERARCHY:")
        layout.label(text="Select the hierarchy of the selected objects.")
        layout.separator()
        layout.label(text="CLEAR PARENT:")
        layout.label(text="Clear the selection from it's parent.")
        layout.label(text="Keep the transform of the selection.")
        layout.separator()
        layout.label(text="CLEAR HIERARCHY:")
        layout.label(text="Clear the hierarchy of the selected objects.")
        layout.label(text="All the objects will be unparented.")
# -----------------------------------------------------------------------------  
# UI
# -----------------------------------------------------------------------------
def Options(self, context):
    layout = self.layout
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    prefs = get_addon_preferences()
    icons = load_icons()

    
    if prefs.dyntopo_or_remesh == "dyntopo":
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        
        row = box.row(align=True)
        row.prop(prefs, "apply_mirror", text="Apply Mirror")
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_smooth_normals', text='Shade Smooth')
        
        row = box.row(align=True)
        row.prop(prefs, "fill_holes", text="Fill Holes")
            
        if not prefs.smooth_mesh:
            row = box.row(align=True)
            row.prop(prefs, "smooth_mesh", text="Smooth Mesh")
        else:
            row = box.row(align=True)
            row.prop(prefs, "smooth_mesh", text="")
            row.prop(prefs, "smooth_mesh_value", text="Smooth Mesh Value")
        
        if not prefs.add_remesh:
            row = box.row(align=True)
            row.prop(prefs, "add_remesh", text="Remesh Mesh")
        else:
            row = box.row(align=True)
            row.prop(prefs, "add_remesh", text="")
            row.prop(prefs, "remesh_value", text="Remesh Value")
    else:
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        
        row = box.row(align=True)
        row.prop(prefs, "apply_mirror", text="Apply Mirror")
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_smooth_normals', text='Shade Smooth')

        row = box.row(align=True)
        row.prop(prefs, "fill_holes", text="Fill Holes")
        
        row = box.row(align=True)
        if not prefs.smooth_mesh:
            row.prop(prefs, "smooth_mesh", text="Smooth Mesh")

        else:
            row.prop(prefs, "smooth_mesh", text="")
            row.prop(prefs, "smooth_mesh_value", text="Smooth Mesh Value")
                
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        
        row = box.row(align=True)
        row.label(text="Remesh Settings")
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_voxel_adaptivity', text='Voxel Adaptivity')
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_fix_poles', text='Fix Poles')
        
        row = box.row(align=True)
        row.prop(prefs, 'remesh_mesh_use_remesh_preserve_volume', text='Preserve Volume')

        if bpy.app.version >= (4, 1, 0):
            row = box.row(align=True)
            row.prop(prefs, 'remesh_mesh_preserve_attributes', text='Preserve Attributes')

        if bpy.app.version < (4, 1, 0):
            row = box.row(align=True)
            row.prop(prefs, 'remesh_mesh_preserve_paint_mask', text='Preserve Paint Mask')
        
            row = box.row(align=True)
            row.prop(prefs, 'remesh_mesh_preserve_sculpt_face_sets', text='Preserve Sculpt Face Sets')

        if bpy.app.version >= (2, 90, 0):
            row = box.row(align=True)
            row.prop(prefs, 'remesh_mesh_preserve_vertex_colors', text='Preserve Vertex Color')

def Shading(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    icons = load_icons()
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    overlay = context.space_data.overlay
    shading = context.space_data.shading
    view = context.space_data
    isolate_collection = bpy.data.collections.get("ISOLATE")


    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    row.scale_y = 1.2
    row.operator("object.speedsculpt_solo", text=" ", icon_value=icons.get("icon_shading").icon_id)
    row.prop_enum(speedsculpt, "shading_icons", "studio")
    row.prop_enum(speedsculpt, "shading_icons", "matcap")
    row.operator("object.speedsculpt_toggle_flat_shading", text=" ", icon='OUTLINER_OB_VOLUME')
    row.prop(overlay, "show_wireframes", text=" ", icon='SHADING_WIRE')
    row.prop(speedsculpt, "show_grid_scale", text=" ", icon_value=icons.get("icon_grid").icon_id)

    if isolate_collection:
        row.operator("object.speedsculpt_unisolate_objects", text=" ", icon_value=icons.get("icon_exit_isolate").icon_id)
    else:
        row.operator("object.speedsculpt_isolate_objects", text=" ", icon_value=icons.get("icon_isolate").icon_id)

    row.prop(speedsculpt, "show_shading", text=" ", icon_value=icons.get("icon_options").icon_id)

    if prefs.show_help:
        row.scale_x = 1
        row.operator("object.speedsculpt_help_shading", text="", icon='HELP', emboss=False)

    if speedsculpt.show_shading:
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.2   

        row.operator("object.speedsculpt_toggle_flat_shading", text="Toggle Silhouette", icon='OUTLINER_OB_VOLUME')
        row.prop(speedsculpt, "show_flat_shading_settings", text="", icon_value=icons.get("icon_options").icon_id)
        if speedsculpt.show_flat_shading_settings:
            split = box.split()
            col = split.column()
            col.label(text="Color Type")
            col = split.column(align=True)
            col.prop(prefs, "flat_shading_color_type", text="")

            if prefs.flat_shading_color_type == 'SINGLE':
                split = box.split()
                col = split.column()
                col.label(text="Custom Color")
                col = split.column(align=True)
                col.prop(prefs, "flat_shading_custom_color", text="")
            
            split = box.split()
            col = split.column()
            col.label(text="Disable Overlays")
            col = split.column(align=True)
            col.prop(prefs, "flat_shading_toggle_overlays", text="")
            
            split = box.split()
            col = split.column()
            col.label(text="Use Background Color")
            col = split.column(align=True)
            col.prop(prefs, "flat_shading_use_background_color", text="")
            
            if prefs.flat_shading_use_background_color:
                split = box.split()
                col = split.column()
                col.label(text="Background Color")
                col = split.column(align=True)
                col.prop(prefs, "flat_shading_background_color", text="")


        # Solo
        if len(context.visible_objects)>=2:
            box = layout.box()
            split = box.split()
            col = split.column(align=True)
            row = col.row(align=True)
            row.scale_y = 1.2
            row.scale_x = 1
            row.operator("object.speedsculpt_solo", text="Solo", icon_value=icons.get("icon_shading").icon_id)

            row.scale_x = 0.5
            row.prop(prefs, "sc_solo_color", text="")

        # studio / matcap selection
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.prop(bpy.context.space_data.shading, "light", expand=True)

        if view.shading.light in ["STUDIO", "MATCAP"]:
            row = col.row(align=True)
            row.template_icon_view(view.shading, "studio_light", show_labels=True, scale=4, scale_popup=3)
        if view.shading.light == "STUDIO":
            row = col.row(align=True)
            row.prop(shading, "use_world_space_lighting", text="", icon='WORLD')
            row.prop(shading, "studiolight_rotate_z", text="Rotation")

        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.grid_flow(columns=3, align=True).prop(view.shading, "color_type", expand=True)
        if shading.light == 'FLAT':
            row = col.row(align=True)
            row.prop(shading, 'single_color', text="")

        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        row.prop(view.shading, "background_type", expand=True)
        if shading.background_type == 'VIEWPORT':
            row = col.row(align=True)
            row.prop(shading, 'background_color', text="")
        
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        col.prop(overlay, "show_wireframes", text="Overlay Wireframe", icon='SHADING_WIRE')
        if overlay.show_wireframes:
            col.prop(overlay, "wireframe_threshold", text="")

def Geomesh(self, context):
    prefs = get_addon_preferences()
    prefs.show_help = prefs.show_help
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()
    layout = self.layout
    obj = context.object

    box = layout.box()
    row = box.row(align=True)
    header, panel = row.panel("geomesh_panel", default_closed=True)
    header.label(text="GEOMESH", icon_value=icons.get("icon_geomesh").icon_id)
    if prefs.show_help :
        header.operator("object.speedsculpt_help_geomesh",text="", icon='HELP', emboss=False)
    if panel:
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator("object.speedsculpt_append_geomesh", text="CREATE GEOMESH", icon_value=icons.get("icon_geomesh").icon_id)

        # Vérifie si il y a des objets dans la collection
        if len(speedsculpt.geomesh_objects) > 0:
            box.template_list("SPEEDSCULPT_UL_geomesh", "", 
                            speedsculpt, "geomesh_objects", 
                            speedsculpt, "geomesh_active_index", 
                            rows=len(speedsculpt.geomesh_objects))
            # Récupère l'objet actif de la collection
            if speedsculpt.geomesh_active_index >= 0:
                active_item = speedsculpt.geomesh_objects[speedsculpt.geomesh_active_index]
                # Récupère l'objet Blender correspondant
                active_geomesh = bpy.data.objects.get(active_item.name)
                
                if active_geomesh:
                    modifier = active_geomesh.modifiers.get("GeometryNodes_Geomesh")
                    if modifier:
                        row = box.row(align=True)
                        row.label(text=active_geomesh.name, icon_value=icons.get("icon_options").icon_id)

                        if modifier["Socket_7"]:
                            box.prop(modifier, '["Socket_8"]', text="Voxel Size")
                        else:
                            box.prop(modifier, '["Socket_4"]', text="Voxel Size")
                        box.prop(modifier, '["Socket_11"]', text="Adaptability") 
                        box.prop(modifier, '["Socket_5"]', text="Smooth") 
                        box.prop(modifier, '["Socket_10"]', text="Shade Smooth")
                        box.prop(modifier, '["Socket_7"]', text="Use Booleans")
                        if modifier["Socket_7"]:
                            box.prop_search(modifier, '["Socket_3"]', bpy.data, 'collections', text="")
                        
                        box.prop_search(modifier, '["Socket_12"]', bpy.data, 'materials', text="Material", icon='MATERIAL')

                        op = box.operator("object.speedsculpt_convert_geomesh_to_mesh", text="Convert Geomesh", icon_value=icons.get("icon_valid").icon_id)
                        op.object_name = active_geomesh.name
                        op.index = speedsculpt.geomesh_active_index

def AddPrimitives(self, context):
    """ Sub panel for the adding assets """
    icons = load_icons()
    layout = self.layout
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    obj = context.active_object
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    wm = context.window_manager

    modifier_flags = {"SOLIDIFY": False, "MIRROR": False, "SHRINKWRAP": False, "BEVEL": False,  "SKIN": False}
    
    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer):
        for mod in context.active_object.modifiers:
            if mod.type in modifier_flags:
                modifier_flags[mod.type] = True

    # Access the flags as needed
    solidify = modifier_flags["SOLIDIFY"]
    mirror = modifier_flags["MIRROR"]
    shrinkwrap = modifier_flags["SHRINKWRAP"]
    bevel = modifier_flags["BEVEL"]
    skin = modifier_flags["SKIN"]

    box = layout.box()
    split = box.split()
    col = split.column()
    row = col.row(align=True)
    row.scale_y = 1.2
    row.label(text="", icon_value=icons.get("icon_tools").icon_id)
    header, panel = row.panel("creation_tools_panel", default_closed=True)
    header.label(text="CREATION TOOLS")
    if prefs.show_help :
        header.operator("object.speedsculpt_help_creation_tools",text="", icon='HELP', emboss=False)
    if panel:
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        row = box.row(align=True)
        row.prop(speedsculpt, 'create_primitives', expand = True)

        if speedsculpt.create_primitives in ['origin','cursor','selection','insert']:
            row = box.row(align=True)
            row.prop(speedsculpt, "go_in_sculpt_mode", text="Comeback in Sculpt Mode")

        if speedsculpt.create_primitives == 'insert':
            row = box.row(align=True)
            row.prop(speedsculpt, "copy_normal_orientation", text="Copy Normal Orientation")
        
        # CURSOR
        if speedsculpt.create_primitives == 'cursor':
            row = box.row(align=True)
            row.prop(speedsculpt, "copy_cursor_orientation", text="Copy Cursor Rotation")

        # PARENTING
        if context.object is not None and context.selected_objects and context.active_object and context.object.visible_get(view_layer=context.view_layer):
            
            row = box.row(align=True)
            row.prop(speedsculpt, "primitives_parenting", text ="Set Selection as Parent")
        
        # MIRROR
        row = box.row()
        row.prop(speedsculpt, "add_mirror", text ="Add Mirror to the new Mesh")

        if speedsculpt.add_mirror :
            row = box.row(align=True)
            row.prop(speedsculpt, "mirror_x", text="", icon='EVENT_X')
            row.prop(speedsculpt, "mirror_y", text="", icon='EVENT_Y')
            row.prop(speedsculpt, "mirror_z", text="", icon='EVENT_Z')
            row.prop_search(speedsculpt, "ref_obj", bpy.data, 'objects', text="")
            
            if not mirror  and context.selected_objects:
                box = layout.box()
                row = box.row()
                row.operator("object.speedsculpt_add_mirror", text="Add Mirror", icon_value=icons.get("icon_symmetrize").icon_id)

        if mirror:
            box = layout.box()
            row = box.row(align=True)
            for mod in context.active_object.modifiers:
                if mod.type == 'MIRROR':
                    row.prop(mod, "show_viewport", text="Hide Mirror" if mod.show_viewport else "Show Mirror")
                    row.operator("object.speedsculpt_apply_mirror", text="", icon_value=icons.get("icon_valid").icon_id)
                    row.operator("object.speedsculpt_remove_mirror", text = "", icon_value=icons.get("icon_delete").icon_id)
                    row.prop(prefs,"mirror_settings", text = "", icon_value=icons.get("icon_options").icon_id)
                    if prefs.mirror_settings:
                        split = box.split()
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.label(text="Axis")
                        row.scale_x = 0.8
                        row.prop(mod, "use_axis", index=0, text="X", toggle = True)
                        row.prop(mod, "use_axis", index=1, text="Y", toggle = True)
                        row.prop(mod, "use_axis", index=2, text="Z", toggle = True)

                        row = col.row(align=True)
                        row.label(text="Bisect")
                        row.scale_x = 0.8
                        row.prop(mod, "use_bisect_axis", index=0, text="X", toggle = True)
                        row.prop(mod, "use_bisect_axis", index=1, text="Y", toggle = True)
                        row.prop(mod, "use_bisect_axis", index=2, text="Z", toggle = True)

                        row = col.row(align=True)
                        row.label(text="Flip")
                        row.scale_x = 0.8
                        row.prop(mod, "use_bisect_flip_axis", index=0, text="X", toggle = True)
                        row.prop(mod, "use_bisect_flip_axis", index=1, text="Y", toggle = True)
                        row.prop(mod, "use_bisect_flip_axis", index=2, text="Z", toggle = True)

                        row = box.row(align=True)
                        row.label(text="Object")
                        row.scale_x = 2.4
                        row.prop(mod, "mirror_object", text="" )

                        row = box.row(align=True)
                        row.prop(mod, "use_clip", text = "Clipping")

                        row = box.row(align=True)
                        row.prop(mod, "use_mirror_merge", text = "Merge")
                        if mod.use_mirror_merge:
                            row.scale_x = 2.3
                            row.prop(mod, "merge_threshold", text ="")

                        if any([mod.use_bisect_axis[0],mod.use_bisect_axis[1],mod.use_bisect_axis[2]]):
                            row = box.row(align=True)
                            row.prop(mod, "bisect_threshold", text = "Bisect Distance")

        if speedsculpt.create_primitives == 'insert':
            row = box.row(align=True)
            row.prop(speedsculpt, "use_existing_object", text="Use existing Object")
            if speedsculpt.use_existing_object:
                row = box.row(align=True)
                row.prop(speedsculpt, "insert_object", text="Object")
                row = box.row(align=True)
                row.separator()
                row = box.row(align=True)
                row.operator("object.speedsculpt_insert_object_modal", text="Insert Object", icon_value=icons.get("icon_primitives").icon_id)

        # PRIMITIVES
        box = layout.box()
        split = box.split()
        col = split.column(align=True)
        row = col.row(align=True)
        header, panel = row.panel("primitives_panel", default_closed=True)
        # if speedsculpt.create_primitives == 'insert':
        #     header.operator("object.add_primitives_insert", text = "", icon_value=icons.get("icon_primitives").icon_id, emboss=False).primitive = "sphere"
        # else:
        #     header.operator("object.add_custom_primitives", text = "", icon_value=icons.get("icon_primitives").icon_id, emboss=False).primitive = "sphere"
        header.label(text="PRIMITIVES", icon_value=icons.get("icon_primitives").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_primitives",text="", icon='HELP', emboss=False)
        if panel:
            row = box.row()
            row.prop(prefs, "primitive_size", expand=True)
            if prefs.primitive_size == 'custom':
                row = box.row()
                row.prop(prefs, "primitive_size_custom", text="Custom Size")

            if speedsculpt.create_primitives == 'insert':
                row = box.row(align=True)
                row.scale_x = 3
                row.operator("object.add_primitives_insert", text = "", icon = 'MATSPHERE').primitive = "sphere"
                row.operator("object.add_primitives_insert",text="", icon ='MESH_CYLINDER').primitive = "cylinder"
                row.operator("object.add_primitives_insert",text="", icon ='MESH_CUBE').primitive = "cube"
                row.operator("object.add_primitives_insert",text="", icon ='MESH_CONE').primitive = "cone"
                row.operator("object.add_primitives_insert",text="", icon ='MESH_TORUS').primitive = "torus"

                # Metaballs
                row = box.row(align=True)
                row.scale_x = 3
                row.operator("object.add_metaballs_insert",text="", icon ='META_BALL').metaballs = "ball"
                row.operator("object.add_metaballs_insert",text="", icon ='META_CAPSULE').metaballs = "capsule"
                row.operator("object.add_metaballs_insert",text="", icon ='META_CUBE').metaballs = "cube"
                row.operator("object.add_metaballs_insert",text="", icon ='META_ELLIPSOID').metaballs = "hellipsoid"
                row.operator("object.add_metaballs_insert",text="", icon ='META_PLANE').metaballs = "plane"
            else:
                row = box.row(align=True)
                row.scale_x = 3
                row.operator("object.add_custom_primitives", text = "", icon = 'MATSPHERE').primitive = "sphere"
                row.operator("object.add_custom_primitives",text="", icon ='MESH_CYLINDER').primitive = "cylinder"
                row.operator("object.add_custom_primitives",text="", icon ='MESH_CUBE').primitive = "cube"
                row.operator("object.add_custom_primitives",text="", icon ='MESH_CONE').primitive = "cone"
                row.operator("object.add_custom_primitives",text="", icon ='MESH_TORUS').primitive = "torus"

                # Metaballs
                row = box.row(align=True)
                row.scale_x = 3
                row.operator("object.add_custom_metaballs", text = "", icon = 'META_BALL').metaballs = "ball"
                row.operator("object.add_custom_metaballs",text="", icon ='META_CAPSULE').metaballs = "capsule"
                row.operator("object.add_custom_metaballs",text="", icon ='META_CUBE').metaballs = "cube"
                row.operator("object.add_custom_metaballs",text="", icon ='META_ELLIPSOID').metaballs = "hellipsoid"
                row.operator("object.add_custom_metaballs",text="", icon ='META_PLANE').metaballs = "plane"

            if any([obj for obj in context.selected_objects if context.active_object.type == 'META']) and context.active_object.type == 'META':
                    split = box.split()
                    col = split.column(align=True)
                    col.label(text="Metaballs Options:")
                    row = col.row(align=True)
                    row.prop(bpy.context.object.data, "resolution", text="Resolution")
                    row = col.row(align=True)
                    row.prop(bpy.context.object.data, "threshold", text="Threshold")
                    row = col.row(align=True)
                    row.prop(speedsculpt, "metaballs_pos_neg", expand=True)

                    if len([obj for obj in context.selected_objects if obj.type == 'META' and obj.mode == "EDIT"]) == 1:
                        col.prop(bpy.context.object.data.elements.active, "stiffness", text="Stiffness")
                        col.prop(bpy.context.object.data.elements.active, "hide", text="Hide")

        # LIBRARY
        box = layout.box()
        row = box.row(align=True)
        header, panel = row.panel("library_panel", default_closed=True)
        header.label(text="ASSETS LIBRARY", icon_value=icons.get("icon_library").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_asset_library",text="", icon='HELP', emboss=False)
        if panel:
            row = box.row(align=True)
            row.prop(speedsculpt, "ui_categories", text="")
            row = box.row(align=True)
            row = row.column()
            row.template_icon_view(wm, "speedsculpt_previews", show_labels=prefs.preview_show_labels,
                                   scale=prefs.preview_scale,
                                   scale_popup=prefs.preview_scale_popup)
            row = box.row(align=True)
            row.scale_y = 1.2
            row.operator("object.speedsculpt_add_assets_to_scene", text="IMPORT ASSET", icon_value=icons.get("icon_import").icon_id)

        # GEOMESH
        Geomesh(self, context)

        # CUTTER
        if prefs.dyntopo_or_remesh == 'remesh':
            box = layout.box()
            row = box.row(align=True)
            header, panel = row.panel("cutter_panel", default_closed=True)
            header.label(text="CUTTER TOOLS", icon_value=icons.get("icon_cutter").icon_id)
            if prefs.show_help :
                header.operator("object.speedsculpt_help_create_cut_tools",text="", icon='HELP', emboss=False)
            if panel:
                row = box.row()
                row.prop(speedsculpt, 'cutter_create_boolean', expand=True)

                row = box.row()
                row.prop(speedsculpt, 'cutter_view_surface', expand=True)
                if context.selected_objects and context.object.visible_get(view_layer=context.view_layer):
                    if speedsculpt.cutter_create_boolean == 'boolean':
                        row = box.row()
                        row.prop(speedsculpt, 'boolean_operation', expand=True)

                        if speedsculpt.boolean_operation == 'union':
                            row = box.row()
                            row.prop(speedsculpt, 'cutter_creation_width', text="Mesh Width")

                elif speedsculpt.cutter_create_boolean == 'create':
                    row = box.row()
                    row.prop(speedsculpt, 'cutter_creation_width', text="Mesh Width")
                row = box.row(align=True)
                row.operator("object.speedsculpt_cutter_primitives", text=" ", icon='MESH_PLANE').launch_cutter_primitives = "rectangle"
                row.operator("object.speedsculpt_cutter_primitives", text=" ", icon='MESH_CIRCLE').launch_cutter_primitives = "circle"
                row.operator("object.speedsculpt_cutter_primitives", text=" ", icon='HANDLE_VECTOR').launch_cutter_primitives = "vertex"
                row.operator("object.speedsculpt_cutter_primitives", text=" ", icon='MOD_CURVE').launch_cutter_primitives = "curve"

        # DRAW CURVE
        box = layout.box()
        row = box.row(align=True)
        # row.operator("object.speedsculpt_draw_curve", text="", icon_value=icons.get("icon_draw_curve").icon_id, emboss=False)
        header, panel = row.panel("draw_curve_panel", default_closed=True)
        header.label(text="DRAW CURVE", icon_value=icons.get("icon_draw_curve").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_draw_curve",text="", icon='HELP', emboss=False)
        if panel:
            row = box.row(align=True)
            row.prop(speedsculpt, 'draw_curve_surface_cursor', expand=True)
            row = box.row(align=True)
            row.operator("object.speedsculpt_draw_curve", text="DRAW CURVE", icon_value=icons.get("icon_draw_curve").icon_id)
        
        # ARRAY CURVE
        box = layout.box()
        row = box.row(align=True)
        # row.operator("object.speedsculpt_array_curve", text="", icon_value=icons.get("icon_array_curve").icon_id, emboss=False)
        header, panel = row.panel("array_curve_panel", default_closed=True)
        header.label(text="ARRAY CURVE", icon_value=icons.get("icon_array_curve").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_array_curve",text="", icon='HELP', emboss=False)
        if panel:
            array_mod = context.object.modifiers.get("Array Curve") if context.object and context.object.modifiers else None
            curve_mod = context.object.modifiers.get("Curve") if context.object and context.object.modifiers else None
            
            if array_mod:
                row = box.row(align=True)
                
                if array_mod.show_viewport:
                    row.operator("object.speedsculpt_toggle_array_curve_visibility", text="Hide Array", icon='RESTRICT_VIEW_OFF')
                else:
                    row.operator("object.speedsculpt_toggle_array_curve_visibility", text="Show Array", icon='RESTRICT_VIEW_ON')

                row.operator("object.speedsculpt_apply_array_curve", text="", icon_value=icons.get("icon_valid").icon_id)
                row.scale_x = 1.1
                row.operator("object.speedsculpt_remove_array_curve", text="", icon_value=icons.get("icon_delete").icon_id)

            # Associated curve object
            if not array_mod:
                row = box.row()
                row.label(text="Curve Object")
                row.scale_x = 2.3
                row.prop(speedsculpt, 'array_curve_object', text="")

            if array_mod:
                # Advanced parameters
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.scale_x = 2.3
                row.prop(array_mod, "relative_offset_displace", index=0, text="X")
                row = col.row(align=True)
                row.scale_x = 2.3
                row.prop(array_mod, "relative_offset_displace", index=1, text="Y")
                row = col.row(align=True)
                row.scale_x = 2.3
                row.prop(array_mod, "relative_offset_displace", index=2, text="Z")
                row = box.row(align=True)
                row.scale_x = 2.3
                row.prop(curve_mod, "deform_axis", text="")

                split = box.split()
                col = split.column(align=True)
                row = col.row()
                row.label(text="Start Cap")
                row.scale_x = 2.3
                row.prop(array_mod, "start_cap", text="")
                row = col.row()
                row.label(text="End Cap")
                row.scale_x = 2.3
                row.prop(array_mod, "end_cap", text="")
            else:
                row = box.row(align=True)
                row.prop(speedsculpt, 'array_curve_surface_cursor', expand=True)
                row = box.row(align=True)
                row.scale_y = 1.2
                row.operator("object.speedsculpt_array_curve", text="ARRAY CURVE", icon_value=icons.get("icon_array_curve").icon_id)

                if len(context.selected_objects) == 2 and context.selected_objects[1].type == 'CURVE':
                    row = box.row(align=True)
                    row.scale_y = 1.2
                    row.operator("object.speedsculpt_connect_array_curve", text="CONNECT OBJECT TO CURVE", icon_value=icons.get("icon_array_curve").icon_id)

        # DRAW SURFACE
        box = layout.box()
        row = box.row(align=True)
        # row.operator("object.speedsculpt_draw_surface", text="", icon_value=icons.get("icon_surface").icon_id, emboss=False)
        header, panel = row.panel("draw_surface_panel", default_closed=True)
        header.label(text="DRAW SURFACE", icon_value=icons.get("icon_surface").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_draw_surface",text="", icon='HELP', emboss=False)
        if panel:
            if context.selected_objects and "Solidify" in obj.modifiers:
                # Solidify
                if solidify:
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    row.scale_y = 1
                    solidify_mod = context.object.modifiers.get("Solidify")
                    row.prop(solidify_mod, "thickness", text="Thickness")
                    row = col.row(align=True)
                    col.prop(solidify_mod, "offset", text="Offset")

                if shrinkwrap:
                    row = box.row(align=True)
                    shrinkwrap_mod = context.object.modifiers.get("Shrinkwrap")
                    if shrinkwrap_mod.show_viewport:
                        row.prop(shrinkwrap_mod, "show_viewport",
                                 text="Hide Shrinkwrap")
                    else:
                        row.prop(shrinkwrap_mod, "show_viewport",
                                 text="Show Shrinkwrap")
                    row.operator("object.remove_shrinkwrap", text="", icon_value=icons.get("icon_delete").icon_id)

                # Bevel
                if not bevel:
                    row = box.row(align=True)
                    row.operator("object.add_gp_bevel", text="Add Bevel", icon_value=icons.get("icon_bevel").icon_id)

                else:
                    row = box.row(align=True)
                    bevel_mod = context.object.modifiers.get("Bevel")
                    if bevel_mod.show_viewport:
                        row.prop(bevel_mod, "show_viewport", text="Hide Bevel")
                    else:
                        row.prop(bevel_mod, "show_viewport", text="Show Bevel")

                    row.operator("object.remove_bevel", text="", icon_value=icons.get("icon_delete").icon_id)
                    if bevel_mod.show_viewport:
                        split = box.split()
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.prop(bevel_mod, "width", text="Bevel Offset")
                        row = col.row(align=True)
                        row.prop(bevel_mod, "angle_limit", text="Bevel Angle Limit")
                        row = col.row(align=True)
                        row.prop(bevel_mod, "segments", text="Bevel Segments")

            else:
                if is_bsurface_activated():
                    row = box.row(align=True)
                    row.prop(speedsculpt, 'draw_surface_placement', expand=True)
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    row.prop(speedsculpt, 'draw_surface_thickness', text='Thickness')
                    row = col.row(align=True)
                    row.prop(speedsculpt, 'draw_surface_offset', text='Offset')

                    if not prefs.smooth_mesh and not prefs.update_remesh:
                        split = box.split()
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.prop(context.scene.bsurfaces, "SURFSK_edges_U")
                        row = col.row(align=True)
                        row.prop(context.scene.bsurfaces, "SURFSK_edges_V")

                    row = box.row(align=True)
                    row.prop(speedsculpt, 'draw_surface_update_remesh', text="Remesh the Object")

                    row = box.row(align=True)
                    row.scale_y = 1.2
                    row.operator("object.speedsculpt_draw_surface", text="DRAW SURFACE", icon_value=icons.get("icon_surface").icon_id)
                else:
                    row = box.row()
                    row.scale_y = 1.3
                    row.alert = True
                    row.operator("object.speedsculpt_set_bsurface_info",text="Install or Active Bsurface", icon='ERROR')
                    
        # DRAW MESH
        box = layout.box()
        row = box.row(align=True)
        # row.operator("object.speedsculpt_draw_remesh", text="", icon_value=icons.get("icon_draw_mesh").icon_id, emboss=False)
        header, panel = row.panel("draw_mesh_panel", default_closed=True)
        header.label(text="DRAW MESH", icon_value=icons.get("icon_draw_mesh").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_draw_mesh",text="", icon='HELP', emboss=False)
        if panel:
            if is_bsurface_activated():
                row = box.row(align=True)
                row.prop(speedsculpt, 'draw_remesh_placement', expand=True)
                row = box.row(align=True)
                row.prop(speedsculpt, 'draw_remesh_size', text="Draw Size")
                row = box.row(align=True)
                row.scale_y = 1.2
                row.operator("object.speedsculpt_draw_remesh", text="DRAW MESH", icon_value=icons.get("icon_draw_mesh").icon_id)
            else:
                row = box.row()
                row.scale_y = 1.3
                row.alert = True
                row.operator("object.speedsculpt_set_bsurface_info",text="Install or Active Bsurface", icon='ERROR')

        # SKIN
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator("object.speedsculpt_draw_skin", text="DRAW SKIN", icon_value=icons.get("icon_draw_skin").icon_id)
        row.operator("object.add_skin",text="ADD SKIN", icon_value=icons.get("icon_skin").icon_id)

        if prefs.show_help :
            row.operator("object.speedsculpt_help_skin",text="", icon='HELP', emboss=False)

        if context.object is not None and context.object.visible_get(view_layer=context.view_layer):
            skin = False
            bevel = False
            subsurf = False
            armature = False
            for mod in context.active_object.modifiers:
                if mod.type == "SKIN":
                    skin = True
                if mod.type == 'BEVEL':
                    bevel = True
                if mod.type == 'SUBSURF':
                    subsurf = True
                if mod.type == 'ARMATURE':
                    armature = True

            # SKIN
            if skin and context.object.mode == "EDIT":
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.operator("object.skin_root_mark", text='Mark Root', icon='PIVOT_CURSOR')
                row = col.row(align=True)
                row.operator("object.skin_loose_mark_clear", text='Mark Loose').action='MARK'
                row.operator("object.skin_loose_mark_clear", text='Clear Loose').action='CLEAR'
                row = col.row(align=True)
                row.operator("object.skin_radii_equalize", text="Equalize Radii")
                for mod in context.active_object.modifiers:
                    if mod.type == 'SKIN':
                        row = col.row(align=True)
                        row.prop(mod, "branch_smoothing", text="Branch Smoothing")
                    if mod.type == 'SUBSURF' and "Subdivision" in obj.modifiers:
                        row = col.row(align=True)
                        row.prop(mod, "show_only_control_edges", text="Optimal Display", toggle=True)
            elif skin:
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                if not armature:
                    row.operator("object.speedsculpt_skin_armature", text='Armature from skin', icon_value=icons.get("icon_pose").icon_id)
                else:
                    for mod in context.object.modifiers:
                        if mod.type == 'ARMATURE':
                            row.prop(mod, "show_viewport", text="Hide Armature" if mod.show_viewport else "Show Armature")
                            row.operator("object.speedsculpt_apply_skin_armature", text='', icon_value=icons.get("icon_valid").icon_id)
                            row.operator("object.speedsculpt_remove_skin_armature", text='', icon_value=icons.get("icon_delete").icon_id)


            #Bevel
            if skin and bevel:
                for mod in context.object.modifiers:
                    if mod.type == 'BEVEL':
                        split = box.split()
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.prop(mod, "show_viewport", text="Hide Bevel" if mod.show_viewport else "Show Bevel")
                        row.operator("object.remove_bevel", text="", icon_value=icons.get("icon_delete").icon_id)
                        row = col.row(align=True)
                        row.prop(context.active_object.modifiers[mod.name], "width", text="Bevel Width")
                        row = col.row(align=True)
                        row.prop(context.active_object.modifiers[mod.name], "angle_limit", text="Bevel Angle")
            elif skin:
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.operator("object.add_gp_bevel", text="Add Bevel", icon_value=icons.get("icon_bevel").icon_id)

            #Smooth Skin
            if skin and  subsurf and "Smooth_skin" in obj.modifiers:
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.prop(context.active_object.modifiers["Smooth_skin"], "show_viewport", text="Hide Smooth" if context.active_object.modifiers["Smooth_skin"].show_viewport else "Show Smooth")
                row.operator("object.remove_smooth_skin", text="", icon_value=icons.get("icon_delete").icon_id)
                row = col.row(align=True)
                row.prop(context.active_object.modifiers["Smooth_skin"], "levels", text="Smooth Level")
            elif skin:
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.operator("object.add_smooth_skin", text="Add Smooth", icon_value=icons.get("icon_subsurf").icon_id)

        # LATHE & CURVE
        box = layout.box()
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator("object.create_lathe", text="LATHE", icon_value=icons.get("icon_lathe").icon_id)
        row.operator("object.speedsculpt_create_curve", text="CURVE", icon_value=icons.get("icon_curve").icon_id)
        if prefs.show_help :
            row.operator("object.speedsculpt_help_curves",text="", icon='HELP', emboss=False)

        if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer):
            screw = False
            for mod in bpy.context.active_object.modifiers:
                if mod.type == "SCREW":
                    screw = True

            if not screw :
                if len(context.selected_objects) == 1:
                    obj1 = context.active_object
                    if obj1.type == 'CURVE' :
                        row = col.row(align=True)
                        row.prop(context.object.data,"resolution_u", text="Resolution")
                        row = col.row(align=True)
                        row.operator("object.convert_curve_to_skin", text="CONVERT TO SKIN", icon_value=icons.get("icon_draw_skin").icon_id)


                if len(context.selected_objects) >= 2:
                    obj1 = context.active_object

                # Bbox
                if len(context.selected_objects) == 1:
                    obj1 = context.active_object
                    if obj1.type == 'CURVE' :
                        box = layout.box()
                        split = box.split()
                        col = split.column(align=True)

                        if context.object.data.bevel_depth == 0 :
                            row = col.row(align=True)
                            row.prop(speedsculpt, "bbox_bevel", text="Bevel")
                            row = col.row(align=True)
                            row.prop(speedsculpt, "bbox_offset", text="Offset")
                            row = col.row(align=True)
                            row.prop(speedsculpt, "bbox_depth", text="Depth")

                        elif context.object.data.bevel_depth > 0 :
                            row = col.row(align=True)
                            row.prop(context.object.data,"bevel_depth", text="Bevel")
                            row = col.row(align=True)
                            row.prop(context.object.data,"offset", text="Offset")
                            row = col.row(align=True)
                            row.prop(context.object.data,"extrude", text="Depth")

                        else:
                            pass
                        row = col.row()
                        row.prop(speedsculpt, "bbox_convert", text="Stay in curve Mode")
                        row = col.row()
                        row.prop(speedsculpt, "smooth_result", text="Smooth the mesh")
                        row = col.row()
                        row.operator("object.bbox", text="BBOX", icon='MOD_DYNAMICPAINT')
            else :
                for mod in bpy.context.active_object.modifiers:
                    if mod.type == "SCREW":
                        row = col.row(align=True)
                        row.scale_x=0.5
                        row.prop(context.active_object.modifiers[mod.name], "axis", text="Axis")
                        row = col.row(align=True)
                        row.prop(context.active_object.modifiers[mod.name], "steps", text="Steps")
                        row = col.row(align=True)
                        row.prop(context.active_object.modifiers[mod.name], "use_normal_flip", text="Flip Normals")


                if len([obj for obj in context.selected_objects if context.object is not None if obj.type == 'CURVE']) == 1:
                    row = col.row(align=True)
                    row.operator("object.speedsculpt_create_empty", text="Add empty", icon_value=icons.get("icon_empty").icon_id)

        # Envelope
        box = layout.box()
        split = box.split()
        box = split.column(align=True)
        row = box.row(align=True)
        row.scale_y = 1.2
        row.operator("object.create_envelope", text="ENVELOPE", icon_value=icons.get("icon_enveloppe").icon_id)
        if prefs.show_help:
            row.operator("object.speedsculpt_help_envelope", text="", icon='HELP', emboss=False)

        if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
            obj = context.active_object
            if obj.type == 'ARMATURE' and  obj.mode == "EDIT":
                row = box.row(align=True)
                row.separator()
                row = box.row(align=True)
                row.operator("object.enveloppe_symmetrize", text="Symmetrize Bones", icon='MOD_MIRROR')
                arm = context.active_object.data
                row = box.row(align=True)
                row.prop(arm, "use_mirror_x")

def Tools(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    toolsettings = context.tool_settings
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    has_selection = False
    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
        if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode in ["EDIT","OBJECT","SCULPT"] ]) >= 1:
            has_selection = True
    
    box = layout.box()
    split = box.split()
    col = split.column()
    row = col.row(align=True)
    row.scale_y = 1.2
    row.label(text="", icon_value=icons.get("icon_modifiers").icon_id)
    header, panel = row.panel("tools_panel", default_closed=True)
    header.label(text="EDITING & OTHER TOOLS")
    if prefs.show_help :
        header.operator("object.speedsculpt_help_tools",text="", icon='HELP', emboss=False)
    if panel:
        if has_selection or context.selected_objects:
            box = layout.box()
            split = box.split()
            box = split.column()
            col = box.column()
            if has_selection and len(context.selected_objects) >= 2:
                row = col.row()
                row.scale_y = 1.3
                row.operator("object.speedsculpt_copy_active_data_to_selection", text="Copy Data to Selection", icon_value=icons.get("icon_copy").icon_id)
            
            if has_selection and context.object.mode == "SCULPT":
                
                row = col.row()
                header, panel = row.panel("brushes_tools_panel_id", default_closed=True)
                header.label(text="Brushes Tools", icon_value=icons.get("icon_brush").icon_id)
                if panel:
                    
                    warning_message= not all(abs(axis - context.object.scale[0]) < 1e-5 for axis in context.object.scale)
                    if warning_message and prefs.show_warning:
                        row = col.row()
                        row.alert = True
                        row.label(text="Scale non uniform")
                        row = col.row()
                        row.alert = True
                        row.label(text="Some tools may not work correctly")

                    row = col.row()
                    row.scale_y = 1.5
                    active_tool = context.workspace.tools.from_space_view3d_mode(bpy.context.mode, create=False)

                    is_mesh_sculpt_all_line_project = (active_tool is not None) and (active_tool.idname == "builtin.line_project")
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.line_project')
                    row.operator("wm.tool_set_by_id", text="Line Project", icon_value=icon_id, depress=is_mesh_sculpt_all_line_project).name = "builtin.line_project"

                    row = col.row(align=True)
                    row.scale_y = 1.5
                    
                    is_mesh_sculpt_all_mask = (active_tool is not None) and (active_tool.idname == "builtin_brush.mask")
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('brush.sculpt.mask')
                    row.operator("wm.tool_set_by_id", text="Mask", icon_value=icon_id, depress=is_mesh_sculpt_all_mask).name = "builtin_brush.mask"

                    row = col.row(align=True)
                    row.scale_y = 1.5
                    is_mesh_sculpt_all_dfs = (active_tool is not None) and (active_tool.idname == "builtin_brush.draw_face_sets")
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('brush.sculpt.draw_face_sets')
                    row.operator("wm.tool_set_by_id", text="Draw Face Sets", icon_value=icon_id, depress=is_mesh_sculpt_all_dfs).name = "builtin_brush.draw_face_sets"

                    # TRIM
                    is_mesh_sculpt_all_box_trim = (active_tool is not None) and (active_tool.idname == "builtin.box_trim")
                    is_mesh_sculpt_all_lasso_trim = (active_tool is not None) and (active_tool.idname == "builtin.lasso_trim")
                    is_mesh_sculpt_all_line_project = (active_tool is not None) and (active_tool.idname == "builtin.line_project")
                    is_mesh_sculpt_all_line_trim = (active_tool is not None) and (active_tool.idname == "builtin.line_trim")
                    is_mesh_sculpt_all_polyline_trim = (active_tool is not None) and (active_tool.idname == "builtin.polyline_trim")
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.label(text="Trim", icon='SELECT_SET')
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.box_trim')
                    row.operator("wm.tool_set_by_id", text="Box Trim", icon_value=icon_id, depress=is_mesh_sculpt_all_box_trim).name = "builtin.box_trim"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.lasso_trim')
                    row.operator("wm.tool_set_by_id", text="Lasso Trim", icon_value=icon_id, depress=is_mesh_sculpt_all_lasso_trim).name = "builtin.lasso_trim"
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.line_trim')
                    row.operator("wm.tool_set_by_id", text="Line Trim", icon_value=icon_id, depress=is_mesh_sculpt_all_line_trim).name = "builtin.line_trim"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.polyline_trim')
                    row.operator("wm.tool_set_by_id", text="Polyline Trim", icon_value=icon_id, depress=is_mesh_sculpt_all_polyline_trim).name = "builtin.polyline_trim"

                    # MASKING
                    is_mesh_sculpt_all_box_mask = (active_tool is not None) and (active_tool.idname == "builtin.box_mask")
                    is_mesh_sculpt_all_lasso_mask = (active_tool is not None) and (active_tool.idname == "builtin.lasso_mask")
                    is_mesh_sculpt_all_line_mask = (active_tool is not None) and (active_tool.idname == "builtin.line_mask")
                    is_mesh_sculpt_all_polyline_mask = (active_tool is not None) and (active_tool.idname == "builtin.polyline_mask")
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.label(text="Masking", icon='MOD_MASK')
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.border_mask')
                    row.operator("wm.tool_set_by_id", text="Box Mask", icon_value=icon_id, depress=is_mesh_sculpt_all_box_mask).name = "builtin.box_mask"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.lasso_mask')
                    row.operator("wm.tool_set_by_id", text="Lasso Mask", icon_value=icon_id, depress=is_mesh_sculpt_all_lasso_mask).name = "builtin.lasso_mask"
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.line_mask')
                    row.operator("wm.tool_set_by_id", text="Line Mask", icon_value=icon_id, depress=is_mesh_sculpt_all_line_mask).name = "builtin.line_mask"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.polyline_mask')
                    row.operator("wm.tool_set_by_id", text="PolyLine Mask", icon_value=icon_id, depress=is_mesh_sculpt_all_polyline_mask).name = "builtin.polyline_mask"
                    
                    # HIDE
                    is_mesh_sculpt_all_box_hide = (active_tool is not None) and (active_tool.idname == "builtin.box_hide")
                    is_mesh_sculpt_all_lasso_hide = (active_tool is not None) and (active_tool.idname == "builtin.lasso_hide")
                    is_mesh_sculpt_all_line_hide = (active_tool is not None) and (active_tool.idname == "builtin.line_hide")
                    is_mesh_sculpt_all_polyline_hide = (active_tool is not None) and (active_tool.idname == "builtin.polyline_hide")
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    row.label(text="Hide", icon='SELECT_SUBTRACT')
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.border_hide')
                    row.operator("wm.tool_set_by_id", text="Box Hide", icon_value=icon_id, depress=is_mesh_sculpt_all_box_hide).name = "builtin.box_hide"
                    con_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.lasso_hide')
                    row.operator("wm.tool_set_by_id", text="Lasso Hide", icon_value=icon_id, depress=is_mesh_sculpt_all_lasso_hide).name = "builtin.lasso_hide"
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.line_hide')
                    row.operator("wm.tool_set_by_id", text="Line Hide", icon_value=icon_id, depress=is_mesh_sculpt_all_line_hide).name = "builtin.line_hide"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.polyline_hide')
                    row.operator("wm.tool_set_by_id", text="Polyine Hide", icon_value=icon_id, depress=is_mesh_sculpt_all_polyline_hide).name = "builtin.polyline_hide"

                    # FACE SETS
                    is_mesh_sculpt_all_box_face_set = (active_tool is not None) and (active_tool.idname == "builtin.box_face_set")
                    is_mesh_sculpt_all_lasso_face_set = (active_tool is not None) and (active_tool.idname == "builtin.lasso_face_set")
                    is_mesh_sculpt_all_line_face_set = (active_tool is not None) and (active_tool.idname == "builtin.line_face_set")
                    is_mesh_sculpt_all_polyline_face_set = (active_tool is not None) and (active_tool.idname == "builtin.polyline_face_set")
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.label(text="Face Sets", icon='FACESEL')
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.border_face_set')
                    row.operator("wm.tool_set_by_id", text="Box Face Set", icon_value=icon_id, depress=is_mesh_sculpt_all_box_face_set).name = "builtin.box_face_set"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.lasso_face_set')
                    row.operator("wm.tool_set_by_id", text="Lasso Face Set", icon_value=icon_id, depress=is_mesh_sculpt_all_lasso_face_set).name = "builtin.lasso_face_set"
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.line_face_set')
                    row.operator("wm.tool_set_by_id", text="Line Face Set", icon_value=icon_id, depress=is_mesh_sculpt_all_line_face_set).name = "builtin.line_face_set"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.polyline_face_set')
                    row.operator("wm.tool_set_by_id", text="Polyline Face Set", icon_value=icon_id, depress=is_mesh_sculpt_all_polyline_face_set).name = "builtin.polyline_face_set"
                    
                    # Filters
                    is_mesh_sculpt_all_mesh_filter = (active_tool is not None) and (active_tool.idname == "builtin.mesh_filter")
                    is_mesh_sculpt_all_cloth_filter = (active_tool is not None) and (active_tool.idname == "builtin.cloth_filter")
                    is_mesh_sculpt_all_color_filter = (active_tool is not None) and (active_tool.idname == "builtin.color_filter")
                    is_mesh_sculpt_all_face_set_edit = (active_tool is not None) and (active_tool.idname == "builtin.face_set_edit")
                    is_mesh_sculpt_all_mask_by_color = (active_tool is not None) and (active_tool.idname == "builtin.mask_by_color")
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.label(text="Filter", icon='FILTER')
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.mesh_filter')
                    row.operator("wm.tool_set_by_id", text="Mesh Filter", icon_value=icon_id, depress=is_mesh_sculpt_all_mesh_filter).name = "builtin.mesh_filter"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.cloth_filter')
                    row.operator("wm.tool_set_by_id", text="Cloth Filter", icon_value=icon_id, depress=is_mesh_sculpt_all_cloth_filter).name = "builtin.cloth_filter"
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.color_filter')
                    row.operator("wm.tool_set_by_id", text="Color Filter", icon_value=icon_id, depress=is_mesh_sculpt_all_color_filter).name = "builtin.color_filter"
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.face_set_edit')
                    row.operator("wm.tool_set_by_id", text="Edit Face Set", icon_value=icon_id, depress=is_mesh_sculpt_all_face_set_edit).name = "builtin.face_set_edit"
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('ops.sculpt.mask_by_color')
                    row.operator("wm.tool_set_by_id", text="Mask by Color", icon_value=icon_id, depress=is_mesh_sculpt_all_mask_by_color).name = "builtin.mask_by_color"

                    # row = col.row(align=True)
                    # row.label(text="Add Tools", icon='MESH_PLANE')
                    # row = col.row(align=True)
                    # row.operator("sculpt.trim_box_gesture", text="Box Add").trim_mode='JOIN'
                    # row.operator("sculpt.trim_lasso_gesture", text="Lasso Add").trim_mode='JOIN'

                    row = col.row(align=True)
                    row.separator()

                    row = col.row(align=True)
                    row.operator("sculpt.mesh_filter", text="Smooth").type='SMOOTH'
                    row.operator("sculpt.mesh_filter", text="Surface Smooth").type='SURFACE_SMOOTH'

                    row = col.row(align=True)
                    row.operator("sculpt.mesh_filter", text="Relax Topology").type='RELAX'
                    row.operator("sculpt.mesh_filter", text="Relax Face Sets").type='RELAX_FACE_SETS'

                    row = col.row(align=True)
                    row.operator("sculpt.mesh_filter", text="Inflate").type='INFLATE'

                    row = col.row(align=True)
                    row.operator("sculpt.mesh_filter", text="Sharpen").type='SHARPEN'

                    row = col.row(align=True)
                    row.operator("sculpt.mesh_filter", text="Random").type='RANDOM'

            if has_selection and context.object.mode == "OBJECT":
                row = col.row()
                row.scale_y = 1.3
                row.operator("object.speedsculpt_create_group_from_selection", text="Create Group", icon_value=icons.get("icon_group").icon_id)

            if has_selection and context.object.mode == "OBJECT":
                row = col.row(align=True)
                row.scale_y = 1.3
                row.operator("object.speedsculpt_scale_reduction", text="Edit Object Size", icon_value=icons.get("icon_object").icon_id)

                row = col.row(align=True)
                row.scale_y = 1.3
                row.operator("object.speedsculpt_separate", text="Separate by loose Part", icon_value=icons.get("icon_separate").icon_id).loose_geometry = True

                if len(context.active_object.material_slots) > 0:
                    row = col.row(align=True)
                    row.scale_y = 1.3
                    row.operator("object.speedsculpt_separate", text="Separate by Material", icon_value=icons.get("icon_separate").icon_id).material = True

            if has_selection and context.object.mode == "EDIT":
                row = col.row()
                row.scale_y = 1.3
                row.operator("object.speedsculpt_separate", text="Separate Selected", icon_value=icons.get("icon_separate").icon_id).selected = True
            
            # HIERARCHY
            if has_selection and (context.object.parent or context.object.children or len(context.selected_objects) >= 2) and context.object.mode == "OBJECT":
                box = layout.box()
                col = box.column()
                row = col.row()
                header, panel = row.panel("hierarchy_panel", default_closed=True)
                header.label(text="Hierarchy", icon_value=icons.get("icon_parent").icon_id)
                if prefs.show_help :
                    header.operator("object.speedsculpt_help_hierarchy",text="", icon='HELP', emboss=False)
                if panel:
                    if has_selection and context.object.mode == "OBJECT":
                        if len(context.selected_objects) >= 2:
                            row = col.row(align=True)
                            row.scale_y = 1.3
                            row.operator("object.speedsculpt_set_parent", text="Set Parent", icon='ORIENTATION_PARENT')
                        if context.object.parent:
                            row = col.row(align=True)
                            row.scale_y = 1.3
                            row.operator("object.speedsculpt_select_parent", text="Select Parent", icon='PARTICLES')
                            row = col.row(align=True)
                            row.scale_y = 1.3
                            row.operator("object.speedsculpt_select_last_parent", text="Select Last Parent", icon='CON_CHILDOF')
                            
                        if context.object.children:
                            row = col.row(align=True)
                            row.scale_y = 1.3
                            row.operator("object.speedsculpt_select_children", text="Select Children", icon='STICKY_UVS_VERT')
                            row = col.row(align=True)
                            row.scale_y = 1.3
                            row.operator("object.speedsculpt_select_hierarchy", text="Select Hierarchy", icon='MOD_PARTICLES')
                        
                        if context.object.parent:
                            row = col.row(align=True)
                            row.scale_y = 1.3
                            row.operator("object.parent_clear", text="Clear Parent (Keep Transform)", icon='ORIENTATION_PARENT').type='CLEAR_KEEP_TRANSFORM'
                        
                        if context.object.parent or context.object.children:
                            row = col.row(align=True)
                            row.scale_y = 1.3
                            row.operator("object.speedsculpt_unparent_hierarchy", text="Clear Hierarchy", icon='STICKY_UVS_DISABLE')

        # CURSOR TOOLS
        box = layout.box()
        split = box.split()
        col = split.column()
        row = col.row(align=True)
        header, panel = row.panel("cursor_tools_panel", default_closed=True)
        header.label(text="Cursor Tools", icon_value=icons.get("icon_cursor").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_cursor",text="", icon='HELP', emboss=False)
        if panel:
            if has_selection and context.object.mode == "OBJECT":
                row = col.row(align=True)
                row.scale_y = 1.3
                row.operator("view3d.snap_cursor_to_selected", text="Cursor to Selection")
                row.operator("view3d.snap_selected_to_cursor", text="Selection to Cursor")

                row = col.row(align=True)
                row.label(text="Cursor to Object")
                row = col.row(align=True)
                row.scale_y = 1.3
                row.operator("object.speedsculpt_copy_cursor_transform", text="Location", icon='ORIENTATION_GLOBAL').transform_type = 'LOCATION'
                row.operator("object.speedsculpt_copy_cursor_transform", text="Rotation", icon='ORIENTATION_GIMBAL').transform_type = 'ROTATION'
                row.operator("object.speedsculpt_copy_cursor_transform", text="Both", icon='ORIENTATION_LOCAL').transform_type = 'BOTH'

                row = col.row(align=True)
                row.label(text="Object to Cursor")
                row = col.row(align=True)
                row.scale_y = 1.3
                row.operator("object.speedsculpt_copy_object_transform_to_cursor", text="Location", icon='ORIENTATION_GLOBAL').transform_type = 'LOCATION'
                row.operator("object.speedsculpt_copy_object_transform_to_cursor", text="Rotation", icon='ORIENTATION_GIMBAL').transform_type = 'ROTATION'
                row.operator("object.speedsculpt_copy_object_transform_to_cursor", text="Both", icon='ORIENTATION_LOCAL').transform_type = 'BOTH'

            row = col.row(align=True)
            row.label(text="Clear Cursor Transforms")
            row = col.row(align=True)
            row.scale_y = 1.3
            row.operator("object.speedsculpt_clear_cursor_transform", text="Location", icon='ORIENTATION_GLOBAL').transform_type = 'LOCATION'
            row.operator("object.speedsculpt_clear_cursor_transform", text="Rotation", icon='ORIENTATION_GIMBAL').transform_type = 'ROTATION'
            row.operator("object.speedsculpt_clear_cursor_transform", text="Both", icon='ORIENTATION_LOCAL').transform_type = 'BOTH'

            row = col.row(align=True)
            row.separator()

            scene = context.scene

            # Ligne pour les boutons
            if len(scene.cursor_views) == 0:
                row = col.row()
                row.scale_y = 1.3
                row.operator("view3d.speedsculpt_store_cursor", text="Store Cursor transforms", icon_value=icons.get("icon_cursor").icon_id )

            # Assurez-vous que la liste des vues est non vide
            if scene.cursor_views:
                if len(scene.cursor_views) >=1:
                    row_groups = col.row()
                    row_groups.label(text="Stored cursors", icon_value=icons.get("icon_cursor").icon_id)

                row_groups = col.row()
                row_groups.template_list("SPEEDSCULPT_UL_cursor_views_ui_list", "",scene,"cursor_views",scene,"cursor_views_index",rows=2)
                col_groups = row_groups.column(align=True)
                col_groups.operator("view3d.speedsculpt_store_cursor", text="", icon='ADD')
                col_groups.operator("view3d.speedsculpt_delete_cursor", text="", icon='REMOVE').index = scene.cursor_views_index

        # VIEW STORE
        box = layout.box()
        split = box.split()
        col = split.column()
        row = col.row(align=True)
        header, panel = row.panel("view_store_panel", default_closed=True)
        header.label(text="Store Views", icon_value=icons.get("icon_areas").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_store_views",text="", icon='HELP', emboss=False)
        if panel:
            scene = context.scene

            # Ligne pour les boutons
            if len(scene.view3d_views) == 0:
                row = col.row()
                row.scale_y = 1.3
                row.operator("view3d.speedsculpt_store_3dview", text="Store 3D views", icon_value=icons.get("icon_areas").icon_id )

            # Assurez-vous que la liste des vues est non vide
            if scene.view3d_views:
                row_groups = col.row()
                row_groups.template_list("SPEEDSCULPT_UL_view3d_views_ui_list", "",scene,"view3d_views",scene,"view3d_views_index",rows=2)
                col_groups = row_groups.column(align=True)
                col_groups.operator("view3d.speedsculpt_store_3dview", text="", icon='ADD')
                col_groups.operator("view3d.speedsculpt_delete_3dview", text="", icon='REMOVE').index = scene.view3d_views_index
        
        Symmetrize(self, context)
        Lattice(self, context)
        backup_system(self,context)
        Remesh(self, context)
        ExtractMask(self, context)
        QuickPose(self, context)
        Muscles(self, context)
        Timelapse(self, context)
        
def Symmetrize(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    # Symmetrize
    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
        if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode in ["OBJECT","SCULPT"] ]) >= 1:

            box = layout.box()
            split = box.split()
            col = split.column()
            row = col.row(align=True)
            row.scale_y = 1.2
            header, panel = row.panel("symmetrize_panel", default_closed=True)
            header.label(text="SYMMETRIZE", icon_value=icons.get("icon_symmetrize").icon_id)
            if prefs.show_help :
                header.operator("object.speedsculpt_help_symmetrize",text="", icon='HELP', emboss=False)
            if panel:
                # box = layout.box()
                # split = box.split()
                # box = split.column(align=True)
                row = col.row(align=True)
                row.label(text="Symmetrize one Object")
                row = col.row(align=True)
                row.operator("object.symmetrize", text = "+X to -X", icon_value=icons.get("icon_sym_plus_x").icon_id).symmetrize_axis = "positive_x"
                row.operator("object.symmetrize", text = "-X to +X", icon_value=icons.get("icon_sym_minus_x").icon_id).symmetrize_axis = "negative_x"
                row = col.row(align=True)
                row.operator("object.symmetrize", text = "+Y to -Y", icon_value=icons.get("icon_sym_plus_y").icon_id).symmetrize_axis = "positive_y"
                row.operator("object.symmetrize", text = "-Y to +Y", icon_value=icons.get("icon_sym_minus_y").icon_id).symmetrize_axis = "negative_y"
                row = col.row(align=True)
                row.operator("object.symmetrize", text = "+Z to -Z", icon_value=icons.get("icon_sym_plus_z").icon_id).symmetrize_axis = "positive_z"
                row.operator("object.symmetrize", text = "-Z to +Z", icon_value=icons.get("icon_sym_minus_z").icon_id).symmetrize_axis = "negative_z"

                row = col.row()
                row.separator()
                row = col.row()
                row.separator()
                row = col.row(align=True)
                row.operator("object.speedsculpt_flip_mesh", text="Flip X", icon_value=icons.get("icon_flip_x").icon_id).flip_axis = 'X'
                row.operator("object.speedsculpt_flip_mesh", text="Flip Y", icon_value=icons.get("icon_flip_y").icon_id).flip_axis = 'Y'
                row.operator("object.speedsculpt_flip_mesh", text="Flip Z", icon_value=icons.get("icon_flip_z").icon_id).flip_axis = 'Z'
                
                if context.object.mode == 'OBJECT':
                    row = col.row()
                    row.separator()
                    row = col.row()
                    row.separator()
                    row = col.row(align=True)
                    row.operator("object.speedsculpt_mirror_with_hierarchy", text="Mirror the Selection", icon_value=icons.get("icon_symmetrize_selection").icon_id)
                    row.prop(speedsculpt, "mirror_selection_options", text="", icon_value=icons.get("icon_options").icon_id)
                    if speedsculpt.mirror_selection_options:
                        row = col.row(align=True)
                        row.prop(speedsculpt, "mirror_selection_add_suffixes", text="Add Suffixes")
                        row = col.row(align=True)
                        row.prop(speedsculpt, "mirror_selection_make_instances", text="Make Instances")

def Lattice(self, context):
    """ Sub panel for the adding assets """
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()
    layout = self.layout

    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
        obj = context.active_object

        if len([obj for obj in context.selected_objects if obj.type in ['MESH', 'LATTICE'] ]) >= 1:
            box = layout.box()
            split = box.split()
            col = split.column()
            row = col.row(align=True)
            row.scale_y = 1.2
            header, panel = row.panel("lattice_panel", default_closed=True)
            header.label(text="LATTICE", icon_value=icons.get("icon_lattice").icon_id)
            if prefs.show_help :
                header.operator("object.speedsculpt_help_lattice",text="", icon='HELP', emboss=False)
            if panel:
                if obj.type == 'MESH' :
                    lattice = False
                    for mod in obj.modifiers:
                        if mod.type == "LATTICE":
                            lattice = True

                    if not lattice:
                        row = col.row(align=True)
                        row.prop(speedsculpt, "copy_orientation", text="Don't Copy Orientation")
                        row = col.row(align=True)
                        row.prop(speedsculpt, "lattice_u", text="U:")
                        row = col.row(align=True)
                        row.prop(speedsculpt, "lattice_v", text="V:")
                        row = col.row(align=True)
                        row.prop(speedsculpt, "lattice_w", text="W:")
                        if context.object.mode == "SCULPT":
                            row = col.row(align=True)
                            row.separator()
                            row = col.row(align=True)
                            row.scale_y = 1.2
                            row.operator("object.add_lattice", text="ADD LATTICE FROM MASK", icon_value=icons.get("icon_mask").icon_id)
                        else :
                            row = col.row(align=True)
                            row.separator()
                            row = col.row(align=True)
                            row.scale_y = 1.2
                            row.operator("object.add_lattice",text="ADD LATTICE", icon_value=icons.get("icon_lattice").icon_id)

                    else :
                        box = layout.box()
                        split = box.split()
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.scale_y = 1.2
                        if speedsculpt.hide_lattice:
                            row.prop(speedsculpt, "hide_lattice", text="Hide Lattice", icon='RESTRICT_VIEW_ON')
                        else:
                            row.prop(speedsculpt, "hide_lattice", text="Show Lattice", icon='RESTRICT_VIEW_OFF')

                        row.operator("object.apply_lattice_modifier", text="", icon_value=icons.get("icon_valid").icon_id)
                        row.operator("object.remove_lattice_modifier", text="", icon_value=icons.get("icon_delete").icon_id)


                        if context.object.mode == "OBJECT":
                            if context.object.vertex_groups:
                                for vgroup in context.object.vertex_groups:
                                    if vgroup.name.startswith("S"):
                                        if len(context.selected_objects) == 1:
                                            row = col.row(align=True)
                                            row.separator()
                                            row = col.row(align=True)
                                            row.operator("object.lattice_add_mask", text="Edit Mask", icon_value=icons.get("icon_mask").icon_id)
                                            row = col.row(align=True)
                                            row.operator("object.lattice_smooth_mask", text="Smooth Mask", icon='MOD_MASK')

                            else :
                                if len(context.selected_objects) == 1:
                                    row = col.row(align=True)
                                    row.scale_y = 1.2
                                    row.operator("object.lattice_add_mask", text="Add Mask", icon_value=icons.get("icon_mask").icon_id)

                        if context.object.mode == "SCULPT":

                                row = col.row(align=True)
                                row.scale_y = 1.2
                                row.operator("object.valid_lattice_mask", text="Valid Mask", icon_value=icons.get("icon_valid").icon_id)


                elif len([obj for obj in context.selected_objects]) >= 2:
                    box = layout.box()
                    split = box.split()
                    box = split.column(align=True)
                    row.scale_y = 1.2
                    box.operator("object.connect_lattice", text="Connect to Lattice", icon_value=icons.get("icon_lattice").icon_id)


                elif len([obj for obj in context.selected_objects if obj.type == 'LATTICE' ]) == 1:
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    row.operator("object.apply_lattice_objects", text="Apply Lattice", icon_value=icons.get("icon_valid").icon_id)
                    row.scale_x = 1.1
                    row.operator("object.remove_lattice_objects", text="", icon_value=icons.get("icon_delete").icon_id)
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.prop(context.object.data, "points_u")
                    row = col.row(align=True)
                    row.prop(context.object.data, "points_v")
                    row = col.row(align=True)
                    row.prop(context.object.data, "points_w")
                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.prop(speedsculpt, "lattice_interp", text="")

def Remesh(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    # Remesh
    if context.object is not None and context.object.visible_get(view_layer=context.view_layer):
        obj = context.active_object

        if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode in ["OBJECT","SCULPT"]]) >= 1:
            box = layout.box()
            split = box.split()
            col = split.column()
            row = col.row(align=True)
            row.scale_y = 1.2
            header, panel = row.panel("remesh_panel", default_closed=True)
            header.label(text="REMESH/DECIMATE", icon_value=icons.get("icon_remesh").icon_id)
            if prefs.show_help :
                header.operator("object.speedsculpt_help_remesh",text="", icon='HELP', emboss=False)
            if panel:
                # Remesh
                remesh = False
                smooth = False
                for mod in context.active_object.modifiers:
                    if mod.type == "REMESH":
                        remesh = True
                        self.remesh_mod = mod
                    if mod.type == "SMOOTH":
                        smooth = True
                        self.smooth_mod = mod
                if not remesh :
                    if context.object.mode == "OBJECT":
                        box = layout.box()
                        split = box.split()
                        box = split.column(align=True)
                        row = box.row(align=True)
                        row.scale_y = 1.2
                        row.operator("object.remesh", text="Remesh", icon_value=icons.get("icon_remesh").icon_id)

                if remesh and smooth :
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    if speedsculpt.hide_remesh_smooth:
                        row.prop(speedsculpt, "hide_remesh_smooth", text="Hide Remesh" , icon='RESTRICT_VIEW_OFF')
                    else:
                        row.prop(speedsculpt, "hide_remesh_smooth", text="Show Remesh" , icon='RESTRICT_VIEW_ON')

                    row.operator("object.apply_remesh_smooth", text="", icon_value=icons.get("icon_valid").icon_id)
                    row.operator("object.remove_remesh_smooth", text="", icon_value=icons.get("icon_delete").icon_id)

                    row = col.row(align=True)
                    row.separator()

                    row = col.row()
                    row.prop(self.remesh_mod, "mode", expand=True)

                    row = col.row(align=True)
                    row.separator()

                    if remesh and self.remesh_mod.mode in ['BLOCKS','SMOOTH','SHARP']:
                        row = col.row()
                        row.prop(self.remesh_mod, "octree_depth", text="Octree Depth:")

                        row = col.row(align=True)
                        row.prop(self.remesh_mod, "scale", text="Scale:")
                    
                    elif remesh and self.remesh_mod.mode == 'VOXEL':
                        row = col.row()
                        row.prop(self.remesh_mod, "voxel_size", text="Voxel Size:")
                        row = col.row(align=True)
                        row.prop(self.remesh_mod, "adaptivity", text="Adaptivity:")
                        row = col.row(align=True)
                        row.prop(self.remesh_mod, "use_smooth_shade", text="Smooth Shade:")
                    
                    if remesh and self.remesh_mod.mode =='SHARP':
                        row = col.row(align=True)
                        row.prop(self.remesh_mod, "sharpness", text="Sharpness:")

                    row = col.row(align=True)
                    row.prop(self.remesh_mod, "use_remove_disconnected", text="Remove Disconnected:")
                    row = col.row(align=True)
                    row.prop(self.remesh_mod, "threshold", text="Threshold:")
                    row = col.row(align=True)
                    row.prop(self.remesh_mod, "use_smooth_shade", text="Smooth Shade:")

                    row = col.row(align=True)
                    row.separator()
                    row = col.row(align=True)
                    row.prop(self.smooth_mod, "iterations", text="Iterations")

                # Decimate
                decimate = False
                for mod in context.active_object.modifiers:
                    if mod.type == "DECIMATE":
                        decimate = True

                if not decimate :
                    if context.object.mode == "SCULPT":
                        box = layout.box()
                        split = box.split()
                        box = split.column(align=True)
                        row = box.row(align=True)
                        row.scale_y = 1.2
                        row.operator("object.decimate_mask", text="Mask Decimate", icon_value=icons.get("icon_mask").icon_id)

                    elif context.object.mode == "OBJECT":
                        box = layout.box()
                        split = box.split()
                        box = split.column(align=True)
                        row = box.row(align=True)
                        row.scale_y = 1.2
                        row.operator("object.decimate", text="Decimate", icon_value=icons.get("icon_decimate").icon_id)

                if decimate:
                    box = layout.box()
                    split = box.split()
                    col = split.column(align=True)
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    if speedsculpt.hide_decimate:
                        row.prop(speedsculpt, "hide_decimate", text="Hide Decimate" , icon='RESTRICT_VIEW_OFF')
                    else:
                        row.prop(speedsculpt, "hide_decimate", text="Show Decimate" , icon='RESTRICT_VIEW_ON')

                    row.operator("object.apply_decimate", text="", icon_value=icons.get("icon_valid").icon_id)
                    row.operator("object.remove_decimate", text="", icon_value=icons.get("icon_delete").icon_id)

                    row = col.row(align=True)
                    row.prop(speedsculpt, "decimate_ratio", text="Ratio:")
                    row = col.row(align=True)

                    row.prop(context.active_object.modifiers["Decimate"], "face_count", text="Face Count:")

                    if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode == "OBJECT"]) == 1:
                        row = col.row(align=True)
                        if not context.object.modifiers["Decimate"].vertex_group :
                            row.operator("object.add_mask", text="Add Mask", icon_value=icons.get("icon_mask").icon_id)

                        else :
                            row.operator("object.edit_decimate_mask", text="Edit Mask", icon='MOD_MASK')
                            row.prop(bpy.context.active_object.modifiers["Decimate"],"invert_vertex_group", text="", icon='ARROW_LEFTRIGHT')
                            row.operator("object.remove_mask", text="", icon_value=icons.get("icon_delete").icon_id)

                    elif context.object.mode == "SCULPT":
                        row = col.row(align=True)
                        row.operator("object.valid_decimate_mask", text="Valid Mask", icon_value=icons.get("icon_valid").icon_id)


                box = layout.box()
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.scale_y = 1.2
                row.operator("object.quadriflow_remesh", text="QuadriFlow Remesh", icon_value=icons.get("icon_quadriflow").icon_id)

def ExtractMask(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    toolsettings = context.tool_settings
    sculpt = toolsettings.sculpt
    obj = bpy.context.active_object
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    # Extract Mask
    if context.object is not None and context.object.visible_get(view_layer=context.view_layer):
        obj = context.active_object
        
        if len([obj for obj in context.selected_objects if obj.type == 'MESH' if context.object.mode == "SCULPT"]) == 1:

            box = layout.box()
            split = box.split()
            col = split.column()
            row = col.row(align=True)
            row.scale_y = 1.2
            header, panel = row.panel("extract_mask_panel", default_closed=True)
            header.label(text="EXTRACT OPERATIONS", icon_value=icons.get("icon_mask").icon_id)
            if prefs.show_help :
                header.operator("object.speedsculpt_help_extract_mask",text="", icon='HELP', emboss=False)
            if panel:
                if bpy.context.object.mode == "SCULPT":
                    if speedsculpt.face_set_or_mask_operation == 'FACE_SET':
                        self.extract = "extract_face_set"
                        self.cut = "cut_face_set"
                        self.slice = "slice_face_set"
                        self.icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('brush.sculpt.draw_face_sets')
                        self.setting_name = "Face Sets Settings"
                    elif speedsculpt.face_set_or_mask_operation == 'MASK':
                        self.extract = "extract_mask"
                        self.cut = "cut_mask"
                        self.slice = "slice_mask"
                        self.icon_id = ToolSelectPanelHelper._icon_value_from_icon_handle('brush.sculpt.mask')
                        self.setting_name = "Mask Settings"

                    box = layout.box()
                    split = box.split()
                    box = split.column(align=True)
                    row = box.row(align=True)
                    row.scale_y = 1.2
                    row.prop(speedsculpt, "face_set_or_mask_operation", expand=True)
                    
                    # SETTINGS
                    box = layout.box()
                    row = box.row(align=True)
                    row.scale_y = 1.2
                    row.prop(prefs, "show_face_set_settings", text=self.setting_name, icon_value=self.icon_id)
                    if prefs.show_face_set_settings:
                        split = box.split()
                        col = split.column(align=True)
                        col.prop(speedsculpt, "add_solidify", text="Add Solidify", icon_value=icons.get("icon_solidify").icon_id)
                        solidify_mod = context.object.modifiers.get("Solidify")

                        if solidify_mod:
                            col.prop(solidify_mod, "thickness", text="Thickness")
                            col.prop(solidify_mod, "offset", text="Offset")
                        else:
                            if speedsculpt.add_solidify :
                                col.prop(speedsculpt, "solidify_thickness", text="Thickness")
                                col.prop(speedsculpt, "solidify_offset", text="Offset")

                        col.separator()

                        if prefs.dyntopo_or_remesh == "remesh":
                            if speedsculpt.add_solidify:
                                col.prop(prefs, "update_remesh", text="Apply Solidify & Remesh", icon_value=icons.get("icon_u").icon_id)
                            else:
                                col.prop(prefs, "update_remesh", text="Remesh", icon_value=icons.get("icon_u").icon_id)

                        elif prefs.dyntopo_or_remesh == "dyntopo":
                            if speedsculpt.add_solidify:
                                col.prop(prefs, 'update_detail_flood_fill', text="Apply Solidify & Dyntopo", icon_value=icons.get("icon_u").icon_id)
                            else:
                                col.prop(prefs, 'update_detail_flood_fill', text="Update Dyntopo", icon_value=icons.get("icon_u").icon_id)
                        

                        col.separator()
                        col.prop(speedsculpt, "comeback_in_sculpt_mode", text="Go To Sculpt", icon='SCULPTMODE_HLT')
                        

                    box = layout.box()
                    split = box.split()
                    box = split.column(align=True)
                    row = box.row(align=True)
                    row.scale_y = 1.2
                    row.operator("object.speedsculpt_extract_operation", text="Extract").face_set_mask_action = self.extract
                    row.operator("object.speedsculpt_extract_operation", text="Cut ").face_set_mask_action = self.cut

                    # INFO FACE SET
                    if speedsculpt.face_set_or_mask_operation == 'FACE_SET':
                        row = box.row(align=True)
                        row.label(text="Note: Isolate the Face Set", icon='INFO')
                        row = box.row(align=True)
                        row.label(text="         with Shift+H to make it work")

                elif bpy.context.object.mode == "OBJECT":

                    solidify = False
                    for mod in context.active_object.modifiers:
                        if mod.type == "SOLIDIFY":
                            solidify = True

                        if solidify:
                            box = layout.box()
                            split = box.split()
                            box = split.column(align=True)
                            box.operator("object.speedsculpt_clean_boundary", text="Clean Boundary Vertices", icon='MOD_OUTLINE')

                            box = layout.box()
                            split = box.split()
                            col = split.column(align=True)
                            col.label(text="Solidify Settings")
                            col.prop(mod, "thickness", text="Thickness")
                            col.prop(mod, "offset", text="Offset")
                            col.prop(mod, "use_rim_only", text="Only Rim")

                        else:
                            box = layout.box()
                            split = box.split()
                            box = split.column(align=True)
                            row = box.row(align=True)
                            row.scale_y=1.5
                            row.operator("object.add_extract_mask", text="Add Mask", icon_value=icons.get("icon_mask").icon_id)

def QuickPose(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    obj = bpy.context.active_object
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    if len([obj for obj in context.selected_objects if obj.type == 'MESH']) == 1:
        box = layout.box()
        split = box.split()
        col = split.column()
        row = col.row(align=True)
        row.scale_y = 1.2
        header, panel = row.panel("quickpose_panel", default_closed=True)
        header.label(text="QUICK POSE", icon_value=icons.get("icon_quick_pose").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_quickpose",text="", icon='HELP', emboss=False)
        if panel:
            # Armature
            armature = False
            for mod in bpy.context.active_object.modifiers:
                if mod.type == "ARMATURE":
                    armature = True

            if not armature :
                if bpy.context.object.mode == "SCULPT":
                    # box = layout.box()
                    # split = box.split()
                    # col = split.column(align=True)
                    row = col.row(align=True)
                    row.operator("object.quick_pose_add_mask", text="Add Mask", icon_value=icons.get("icon_mask").icon_id)
                    box.operator("object.quick_pose_create_bones", text="Create Bones", icon_value=icons.get("icon_bones").icon_id)

                elif bpy.context.object.mode == "OBJECT":
                    # box = layout.box()
                    # split = box.split()
                    # col = split.column(align=True)
                    row = col.row()
                    row.prop(speedsculpt, "use_mask", text="Use Mask")
                    row = col.row()
                    if speedsculpt.use_mask:
                        row.operator("object.quick_pose_add_mask", text="Add Mask", icon_value=icons.get("icon_mask").icon_id)
                    else :
                        box.operator("object.quick_pose_create_bones", text="Create Bones", icon_value=icons.get("icon_bones").icon_id)

                elif bpy.context.object.mode == 'EDIT':

                    bs_vertex = True
                    for obj in bpy.context.selected_objects:
                        if obj.name != "BS_Vertex" :
                            bs_vertex = False
                            break
                    if bs_vertex :
                        # box = layout.box()
                        # split = box.split()
                        # col = split.column(align=True)
                        row = col.row()
                        row.operator("object.quick_pose_convert_bones", text="Pose", icon_value=icons.get("icon_pose").icon_id)
            if armature:
                if bpy.context.object.mode == "OBJECT":
                    # box = layout.box()
                    # split = box.split()
                    # col = split.column(align=True)
                    row = col.row(align=True)
                    if not "Armature" in obj.modifiers:
                        if speedsculpt.use_mask:
                            row.operator("object.quick_pose_add_mask", text="Add Mask", icon_value=icons.get("icon_mask").icon_id)
                        else :
                            row.operator("object.quick_pose_create_bones", text="Create Bones",  icon_value=icons.get("icon_bones").icon_id)
                    else :
                        row.prop(bpy.context.active_object.modifiers["Armature"], "show_viewport", text="Hide Armature")
                        row.operator("object.apply_quick_pose_modifier", text="", icon_value=icons.get("icon_valid").icon_id)
                        row.operator("object.remove_quick_pose_modifier", text="", icon_value=icons.get("icon_delete").icon_id)


                        if speedsculpt.use_mask:
                            row = col.row(align=True)
                            row.operator("object.edit_quick_pose_mask", text="Edit Mask", icon_value=icons.get("icon_mask").icon_id)
                            if bpy.app.version < (4, 3, 0):
                                row = col.row(align=True)
                                row.operator("object.quick_pose_smooth_mask", text="Smooth Mask", icon='BRUSH_SMOOTH')
                            else:
                                row = col.row(align=True)
                                row.operator("object.quick_pose_smooth_mask", text="Smooth Mask", icon='MOD_MASK')

                elif bpy.context.object.mode == "SCULPT":
                    # box = layout.box()
                    # split = box.split()
                    # row = split.row(align=True)
                    row = col.row(align=True)
                    row.operator("object.valid_quick_pose_mask", text="Valid Mask", icon_value=icons.get("icon_valid").icon_id)

def Muscles(self, context):
    """ Sub panel for the adding assets """
    layout = self.layout
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt
    icons = load_icons()

    # Check for solidify
    self.solidify = False
    self.has_muscles_prop = False

    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
        obj = context.active_object

        if obj.type == 'MESH':
            for mod in obj.modifiers:
                if mod.type == "SOLIDIFY":
                    self.solidify = True

            if obj.get("speedsculpt_muscles"):
                self.has_muscles_prop = True


            if len([obj for obj in context.selected_objects if obj.type == 'MESH']) >= 1:

                if self.has_muscles_prop and self.solidify :

                    box = layout.box()
                    split = box.split()
                    col = split.column()
                    row = col.row(align=True)
                    row.scale_y = 1.2
                    header, panel = row.panel("muscles_panel", default_closed=True)
                    header.label(text="MUSCLES", icon_value=icons.get("icon_muscles").icon_id)
                    if prefs.show_help :
                        header.operator("object.speedsculpt_help_muscles",text="", icon='HELP', emboss=False)
                    if panel:
                        box = layout.box()
                        split = box.split(align=True)
                        col = split.column(align=True)
                        row = col.row()
                        row.prop(speedsculpt, "hide_all_modifiers_prop", text='Show/Hide Modifiers', icon='MODIFIER', expand=True)
                        col.prop(speedsculpt, "edit_muscles_tickness", text="Thickness")
                        col.prop(speedsculpt, "edit_muscles_offset", text="Offset")
                        col.prop(speedsculpt, "edit_muscles_factor", text="Factor")

                        if obj.mode == 'EDIT':
                            row = col.row(align=True)
                            row.label(text='Vertex Groups')
                            col.prop(context.tool_settings, "vertex_group_weight", text="Weight")
                            row = col.row(align=True)
                            row.operator("object.vertex_group_assign", text="Assign")
                            row.operator("object.vertex_group_remove_from", text="Remove", icon_value=icons.get("icon_delete").icon_id)
                            row = col.row(align=True)
                            row.operator("object.vertex_group_select", text="Select")
                            row.operator("object.vertex_group_deselect", text="Deselect")

def backup_system(self,context):
    layout = self.layout
    icons = load_icons()
    
    prefs = get_addon_preferences()
    speedsculpt = context.scene.speedsculpt

    if context.object is not None and context.object.visible_get(view_layer=context.view_layer):
        obj = context.object
        box = layout.box()
        split = box.split()
        col = split.column()
        row = col.row(align=True)
        row.scale_y = 1.2
        # row.operator("object.speedsculpt_backup_selection", text="", icon_value=icons.get("icon_backup").icon_id, emboss=False)

        header, panel = row.panel("backup_settings_panel", default_closed=True)
        header.label(text="BACKUP", icon_value=icons.get("icon_backup").icon_id)
        if prefs.show_help :
            header.operator("object.speedsculpt_help_backup",text="", icon='HELP', emboss=False)
        if panel:
            backups = obj.unified_object_backup.backups
            box = layout.box()
            row = box.row()
            row.scale_y = 1.2
            row.operator("object.speedsculpt_backup_selection", text="Create Backup to Collection", icon_value=icons.get("icon_collection").icon_id)
            box = layout.box()
            row = box.row()
            if len(backups) >= 1:
                row.scale_y = 1.2
                row.operator("object.speedsculpt_create_backup", text="Create new Backup to List", icon_value=icons.get("icon_list").icon_id)
                row.operator("object.speedsculpt_clear_all_backups", text="", icon_value=icons.get("icon_trash").icon_id)

            else:
                row.scale_y = 1.2
                row.operator("object.speedsculpt_create_backup", text="Create Backup to List", icon_value=icons.get("icon_list").icon_id)
            
            rows = 1    
            if backups:
                rows = len(backups)
            
                row = box.row(align=True)
                row.template_list("SPEEDSCULPT_UL_backups_list", "", obj.unified_object_backup, "backups", obj.unified_object_backup, "active_backup_index", rows=rows)

            if len([obj for obj in context.scene.objects if backups]) > 0:
                row = box.row(align=True)
                row.operator("object.speedsculpt_clear_all_scene_backups", text="Clear All Scene Backups", icon_value=icons.get("icon_trash").icon_id)

def Multi_Object_Sculpt(self, context):
    layout = self.layout
    icons = load_icons()
    layout.operator("object.speedsculpt_prepare_multi_sculpt", text="Prepare Multi-Object Sculpt", icon='MESH_CIRCLE')
    layout.operator("object.speedsculpt_apply_multi_sculpt", text="Apply Multi-Object Sculpt", icon='MESH_CIRCLE')
    layout.operator("object.speedsculpt_cancel_multi_sculpt", text="Cancel Multi-Object Sculpt", icon='MESH_CIRCLE')

# -----------------------------------------------------------------------------
#    Timelapse Cameras
# -----------------------------------------------------------------------------
class SPEEDSCULPT_UL_timelapse_cameras(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        icons = load_icons()
        settings = context.scene.sculpt_timelapse
        is_active = settings.camera and settings.camera.name == item.name

        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            if is_active:
                row.prop(item, "name", text="", emboss=False, icon_value=icons.get("icon_camera").icon_id)

            else:
                row.prop(item, "name", text="", emboss=False, icon='CAMERA_DATA')

            row.prop(item, "hide_select", text="", emboss=False)
            row.prop(item, "hide_viewport", text="", emboss=False)

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        helper = bpy.types.UI_UL_list
        flags = []
        for item in items:
            if item.type == 'CAMERA':
                flags.append(self.bitflag_filter_item)
            else:
                flags.append(0)
        order = helper.sort_items_by_name(items, "name")
        return flags, order

def Timelapse(self, context):
    layout = self.layout
    speedsculpt = context.scene.speedsculpt
    settings = context.scene.sculpt_timelapse
    icons = load_icons()
    prefs = get_addon_preferences()

    box = layout.box()
    split = box.split()
    col = split.column()
    row = col.row(align=True)
    row.scale_y = 1.2
    row.alert = True if settings.is_recording else False
    row.alert = False
    header, panel = row.panel("timelapse_panel", default_closed=True)
    header.label(text="TIMELAPSE", icon_value=icons.get("icon_timelapse").icon_id)
    if prefs.show_help :
        header.operator("object.speedsculpt_help_timelapse",text="", icon='HELP', emboss=False)
    if panel:
        box = layout.box()
        row = box.row(align=True)
        header, panel = row.panel("timelapse_settings_panel", default_closed=True)
        header.label(text="Timelapse Settings")
        if panel:
            row = box.row()
            row.prop(settings, "save_path", text="")
            if settings.save_path:
                row.scale_x = 1.2
                row.operator("object.speedsculpt_open_timelapse_folder", text="", icon='FOLDER_REDIRECT')
            row = box.row()
            row.prop(settings, "timelpase_speed", expand=True, slider=False)
            col = box.column(align=True)
            col.prop(settings, "interval")
            row = box.row(align=True)
            row.prop(settings, "camera_resolutions", expand=True, slider=False)

            col = box.column(align=True)
            col.prop(bpy.context.scene.render, "resolution_x", text="Resolution X")
            col.prop(bpy.context.scene.render, "resolution_y", text="Resolution Y")
            col.prop(bpy.context.scene.render, "resolution_percentage", text="Resolution %")

        camera_list = [obj for obj in context.scene.objects if obj.type == 'CAMERA']
        if camera_list:
            box = layout.box()
            rows = min(len(camera_list), 5)  # max 5 lignes visibles
            row = box.row(align=True)
            row.label(text="Timelapse Cameras")
            row = box.row(align=True)
            row.template_list(
                "SPEEDSCULPT_UL_timelapse_cameras", "",
                context.scene, "objects",   # source = objets de la scène
                settings, "camera_list_index",
                rows=rows
            )

            # Boutons Add / Delete à droite
            col = row.column(align=True)
            col.operator("object.speedsculpt_create_camera_timelapse", text="", icon='ADD')
            col.operator("object.speedsculpt_delete_timelapse_camera", text="", icon='REMOVE')

            # STORE CAMERA VIEWS
            camera = settings.camera
            if camera and camera.type == 'CAMERA':
                if camera.camera_views:
                    is_sortable = len(camera.camera_views) > 1
                    rows = 2 if is_sortable else 1
                    row = box.row(align=True)
                    row.label(text="Store Camera Views")
                    row = box.row(align=True)
                    row.template_list("SPEEDSCULPT_UL_camera_views_uilist", "", camera, "camera_views", camera, "camera_views_index", rows=rows)
                    col = row.column(align=True)
                    col.operator("object.speedsculpt_store_camera_view", text="", icon='ADD')
                    op_del = col.operator("object.speedsculpt_delete_camera_view", text="", icon='REMOVE')
                    op_del.index = camera.camera_views_index
                else:
                    row = box.row(align=True)
                    row.operator("object.speedsculpt_store_camera_view", text="Store a Camera View", icon='ADD')

            # Track To target si la caméra active a ce constraint
            if settings.camera and settings.camera.constraints.get("Track To"):
                row = box.row(align=True)
                row.prop(settings.camera.constraints["Track To"], "target", text="Target")
            else:
                row = box.row(align=True)
                row.operator("object.speedsculpt_add_target_to_timelapse_camera", text="Add Target", icon='CON_TRACKTO')

            box = layout.box()
            row = box.row()
            if not settings.is_recording:
                row.scale_y = 1.2
                if settings.frame_count > 0:
                    text = f"Start Recording ({settings.frame_count})"
                else:
                    text = "Start Recording"
                row.operator("object.speedsculpt_start_timelapse",text=text, icon='REC')
            else:
                row.scale_y = 1.2
                row.alert = True
                row.operator("object.speedsculpt_stop_timelapse",text=f"Stop Recording ({settings.frame_count})", icon='PAUSE', depress=True)
                row.alert = False

            row.scale_x = 1.2
            row.operator("object.speedsculpt_check_timelapse_folder", text="", icon_value=icons.get("icon_search_in_folder").icon_id)
            
            if not settings.is_recording and settings.has_frames:
                row = box.row()
                row.scale_y = 1.2
                row.operator("object.speedsculpt_reset_timelapse",text=f"Reset (Delete {settings.frame_count} images)", icon='TRASH')

                row = box.row()
                row.scale_y = 1.2
                row.operator("object.speedsculpt_save_to_mp4", icon='FILE_MOVIE', text="Compile MP4")
                row.scale_x = 1.2
                row.operator("object.speedsculpt_open_timelapse_folder", text="", icon='FOLDER_REDIRECT')
        else:
            box = layout.box()
            row = box.row()
            row.scale_y = 1.2
            row.operator("object.speedsculpt_create_camera_timelapse", icon_value=icons.get("icon_camera").icon_id)
    
# -----------------------------------------------------------------------------
#    Geomesh
# -----------------------------------------------------------------------------
class SPEEDSCULPT_OT_select_geomesh_in_list(Operator):
    bl_idname = "object.speedsculpt_select_geomesh_in_list"
    bl_label = "Select Geomesh"
    bl_description = "Select this Geomesh in the list"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore

    def execute(self, context):
        # speedsculpt = context.scene.speedsculpt  
        speedsculpt = context.scene.speedsculpt
        # Met à jour directement l'index actif
        speedsculpt.geomesh_active_index = self.index
        return {'FINISHED'}

class SPEEDSCULPT_OT_rename_geomesh_item(Operator):
    bl_idname = "object.speedsculpt_rename_geomesh_item"
    bl_label = "Rename Geomesh"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: StringProperty() # type: ignore
    index: IntProperty() # type: ignore
    new_name: StringProperty() # type: ignore

    def invoke(self, context, event):
        self.new_name = self.object_name
        return context.window_manager.invoke_props_dialog(self, width=200)

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        item = speedsculpt.geomesh_objects[self.index]
        
        # Renomme l'item et l'objet
        obj = bpy.data.objects.get(item.name)
        if obj:
            new_name = self.new_name + "_Geomesh"
            obj.name = new_name
            obj.data.name = new_name
            item.name = new_name
            item.value = new_name
            
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "new_name", text="Name")

class SPEEDSCULPT_UL_geomesh(UIList):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.use_filter_sort = True

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
    
        icons = load_icons()
        obj = bpy.data.objects.get(item.name)

        row = layout.row(align=True)
        
        # Display item name with rename icon and selectable label
        op = row.operator("object.speedsculpt_rename_geomesh_item", text="", icon_value=icons.get("icon_geomesh").icon_id, emboss=False)
        op.object_name = item.name
        op.index = index
        
        # Make the label activate the item in the list without selecting the object
        row.label(text=item.name)
        
        if obj:
            # Hide/Show button
            op = row.operator("object.speedsculpt_toggle_geomesh_visibility", text="", icon='HIDE_ON' if obj.hide_viewport else 'HIDE_OFF', emboss=False)
            op.object_name = item.name
            op.index = index

        # Add select button
        if obj and not obj.hide_select:
            op = row.operator("object.speedsculpt_select_geomesh", text="", icon='RESTRICT_SELECT_OFF', emboss=False)
            op.object_name = item.name
            op.index = index

        
        if obj:
            # Lock button
            op = row.operator("object.speedsculpt_lock_geomesh", text="", icon='LOCKED' if obj.hide_select else 'UNLOCKED', emboss=False)
            op.object_name = item.name
            op.index = index

            # Show in front button
            row.prop(obj, "show_in_front", text="", icon='CLIPUV_HLT' if obj.show_in_front else 'CLIPUV_DEHLT', emboss=False)

            # Mirror
            mirror_mod = obj.modifiers.get("Mirror")
            if mirror_mod:
                if mirror_mod.show_viewport:
                    icon = icons.get("icon_mirror_on")
                else:
                    icon = icons.get("icon_mirror_off")
                op = row.operator("object.speedsculpt_toggle_geomesh_mirror", text="", icon_value=icon.icon_id, emboss=False)
                op.object_name = item.name
                op.index = index
            else:
                op = row.operator("object.speedsculpt_toggle_geomesh_mirror", text="", icon_value=icons.get("icon_mirror_off").icon_id, emboss=False)
                op.object_name = item.name
                op.index = index

        # Delete button
        op = row.operator("object.speedsculpt_delete_geomesh", text="", icon_value=icons.get("icon_trash").icon_id, emboss=False)
        op.object_name = item.name
        op.index = index

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        helper = bpy.types.UI_UL_list
        
        # Créer les flags pour tous les items
        flags = [self.bitflag_filter_item] * len(items)
        
        # Tri alphabétique
        order = helper.sort_items_by_name(items, "name")
        
        return flags, order
    
# -----------------------------------------------------------------------------
#    Panel
# -----------------------------------------------------------------------------
def warning_message_information(layout):
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    col.label(text="Scene units and mesh size affect remesh/dyntopo behavior and results.")
    col.label(text="Large objects (e.g. 2 meters) with very small triangles/quads")
    col.label(text="can quickly create millions of polygons and severely impact performance.")
    col.label(text="This can cause Blender to become unstable or even crash")
    col.label(text="this is a Blender limitation, not a problem with the addon.")
    col.label(text="Always set remesh/dyntopo values appropriate to your object's real size.")
    col.label(text="Make some tests before and backup your scene and objects.")
    
class VIEW3D_PT_speedsculpt_panel(Panel):
    bl_label = "SPEEDSCULPT"
    bl_region_type = 'UI'
    bl_space_type = "VIEW_3D"
    bl_category = "Tools"
    bl_ui_units_x = 12

    def draw_header(self, context):
        layout = self.layout
        icons = load_icons()
        layout.label(text="", icon_value=icons.get("icon_speedsculpt").icon_id)
    
    def draw_header_preset(self, context):
        """Affiche le numéro de version dans le header"""
        prefs = get_addon_preferences()
        layout = self.layout
        # Récupérer la version depuis bl_info
        import sys
        addon_name = __package__.split('.')[0] if '.' in __package__ else __package__
        if addon_name in sys.modules:
            addon_module = sys.modules[addon_name]
            if hasattr(addon_module, 'bl_info'):
                version = addon_module.bl_info.get('version', (0, 0, 0))
                version_str = f"{version[0]}.{version[1]}.{version[2]}"

                new_version = None
                update_message = getattr(prefs, "update_available", "") if prefs else ""
                if update_message and update_message.strip() and "New version available" in update_message:
                    layout.alert = True
                    # Try to extract the new version safely
                    parts = update_message.split("New version available: ")
                    if len(parts) > 1:
                        nv_split = parts[1].split(" (current: ")
                        if len(nv_split) > 0:
                            new_version = nv_split[0].strip()
                    if new_version:
                        layout.label(text=f"v{version_str} (New: {new_version})")
                    else:
                        layout.label(text=f"v{version_str}")
                else:
                    layout.label(text=f"v{version_str}")
        
        layout.operator("object.speedsculpt_help", text="", icon='HELP', emboss=False)
    
    def draw(self, context):
        layout = self.layout
        # UI_Menus(self, context)
        icons = load_icons()
        toolsettings = context.tool_settings
        sculpt = toolsettings.sculpt
        obj = context.active_object
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt

        # Warning for Remesh / Dyntopo
        show_warning = False
        warning_text = ""
        show_warning_text_2 = False
        if prefs.dyntopo_or_remesh == "remesh":
            voxel = prefs.remesh_mesh_value
            if voxel <= 0.01:
                show_warning = True
                show_warning_text_2 = True
                warning_text_1 = ("Small value when remeshing")
                warning_text_2 = ("can impact performance or stability")
            elif voxel >= 0.5:
                show_warning = True
                show_warning_text_2 = False
                warning_text_1 = ("Big value can create coarse geometry")
                warning_text_2 = ("")

        elif prefs.dyntopo_or_remesh == "dyntopo":
            method = sculpt.detail_type_method
            if method in {'CONSTANT', 'MANUAL'}:
                res = sculpt.constant_detail_resolution
                if res >= 20.0:
                    show_warning = True
                    show_warning_text_2 = True
                    warning_text_1 = ("Big value when remeshing")
                    warning_text_2 = ("can impact performance or stability")
                elif res <= 1:
                    show_warning = True
                    show_warning_text_2 = False
                    warning_text_1 = ( "Small value can create coarse geometry")
                    warning_text_2 = ("")

        if (context.object and context.object.visible_get(view_layer=context.view_layer)) and obj.type == 'ARMATURE' and context.object.mode == 'POSE' and not obj.name.startswith(
                "Envelope"):
            layout.operator("object.symmetrize_bones", text="Symmetrize Bones", icon_value=icons.get("icon_symmetrize").icon_id)

        elif (context.object and context.object.visible_get(view_layer=context.view_layer)) and context.object.mode == 'EDIT' and obj.type == 'ARMATURE' and not obj.name.startswith(
                "Envelope"):
            layout.operator("object.update_armature", text="Update Armature", icon='OUTLINER_OB_ARMATURE')

        else:
            if bpy.context.area.type == 'VIEW_3D':
                box = layout.box()
                split = box.split()
                col = split.column(align=True)
                row = col.row(align=True)
                row.scale_y = 1.3
                row.prop(prefs, 'dyntopo_or_remesh', expand=True)
                if prefs.show_help:
                    row.operator("object.speedsculpt_help_dyntopo_remesh", text="", icon='HELP', emboss=False)

                if prefs.dyntopo_or_remesh == "dyntopo":
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    row.scale_x = 1.5
                    row.operator("object.speedsculpt_increment_remesh_and_execute", text="", icon='TRIA_LEFT').direction = 'DOWN'

                    if sculpt.detail_type_method == 'RELATIVE':
                        row.prop(sculpt, "detail_size")

                    elif sculpt.detail_type_method in {'CONSTANT','MANUAL'}:
                        row.prop(sculpt, "constant_detail_resolution", text="")

                    elif sculpt.detail_type_method == 'BRUSH':
                        row.prop(sculpt, "detail_percent")
                    
                    row.operator("object.speedsculpt_increment_remesh_and_execute", text="", icon='TRIA_RIGHT').direction = 'UP'

                    if sculpt.detail_type_method in {'CONSTANT','MANUAL'}:
                        if context.object is not None and context.object.mode == 'SCULPT':
                            row.operator("sculpt.sample_detail_size", text="", icon='EYEDROPPER')

                        if context.selected_objects:
                            
                            row.scale_y = 1.5
                            row.operator("object.update_dyntopo", text="", icon_value=icons.get("icon_valid").icon_id)

                    if prefs.show_help:
                        row.scale_x = 1
                        row.operator("object.speedsculpt_help_remesh_dyntopo_value", text="", icon='HELP', emboss=False)

                    if show_warning and prefs.show_warning:
                        row = col.row(align=True)
                        row.alert = True
                        row.label(text=warning_text_1)
                        
                        if show_warning_text_2:
                            row = col.row(align=True)
                            row.alert = True
                            row.label(text=warning_text_2)
                        row.alert = False
                        row.prop(speedsculpt, 'show_warning_message', text="", icon='HELP', emboss=False)
                        if speedsculpt.show_warning_message:
                            box = col.box()
                            split = box.split()
                            col = split.column(align=True)
                            col.alert = True
                            col.label(text="Scene units and mesh size affect remesh/dyntopo behavior and results.")
                            col.label(text="Large objects (e.g. 2 meters) with very small triangles/quads")
                            col.label(text="can quickly create millions of polygons and severely impact performance.")
                            col.label(text="This can cause Blender to become unstable or even crash")
                            col.label(text="this is a Blender limitation, not a problem with the addon.")
                            col.label(text="Always set remesh/dyntopo values appropriate to your object's real size.")
                            col.label(text="Make some tests before and backup your scene and objects.")

                    if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
                        row = col.row(align=True)
                        row.prop(sculpt, "detail_type_method", text="")
                        if prefs.show_help:
                            row.label(text="", icon='BLANK1')
                        row = col.row(align=True)
                        row.prop(sculpt, "detail_refine_method", text="")
                        if prefs.show_help:
                            row.label(text="", icon='BLANK1')

                elif prefs.dyntopo_or_remesh == "remesh":
                    row = col.row(align=True)
                    row.scale_y = 1.5
                    row.operator("object.speedsculpt_increment_remesh_and_execute", text="", icon='TRIA_LEFT').direction = 'UP'
                    row.prop(prefs, 'remesh_mesh_value', text='')
                    row.operator("object.speedsculpt_increment_remesh_and_execute", text="", icon='TRIA_RIGHT').direction = 'DOWN'

                    if context.selected_objects:
                        row.scale_x = 2
                        row.operator("object.speedsculpt_pick_remesh_size", text="", icon='EYEDROPPER')
                        row.operator("object.speedsculpt_remesh_selection", text="", icon_value=icons.get("icon_valid").icon_id)

                    if prefs.show_help:
                        row.enabled = True
                        row.scale_x = 1
                        row.operator("object.speedsculpt_help_remesh_dyntopo_value", text="", icon='HELP', emboss=False)

                    if show_warning and prefs.show_warning:
                        row = col.row(align=True)
                        row.alert = True
                        row.label(text=warning_text_1)

                        if show_warning_text_2:
                            row = col.row(align=True)
                            row.alert = True
                            row.label(text=warning_text_2)

                        row.alert = False
                        row.prop(speedsculpt, 'show_warning_message', text="", icon='HELP', emboss=False)
                        if speedsculpt.show_warning_message:
                            box = col.box()
                            split = box.split()
                            col = split.column(align=True)
                            col.alert = True
                            col.label(text="Scene units and mesh size affect remesh/dyntopo behavior and results.")
                            col.label(text="Large objects (e.g. 2 meters) with very small triangles/quads")
                            col.label(text="can quickly create millions of polygons and severely impact performance.")
                            col.label(text="This can cause Blender to become unstable or even crash")
                            col.label(text="this is a Blender limitation, not a problem with the addon.")
                            col.label(text="Always set remesh/dyntopo values appropriate to your object's real size.")
                            col.label(text="Make some tests before and backup your scene and objects.")
                        

                row = col.row(align=True)
                row.alert = False
                row.scale_x = 3
                row.scale_y = 1.2
                row.prop(prefs, 'smooth_mesh', text="", icon_value=icons.get("icon_s").icon_id)
                row.prop(prefs, 'update_remesh', text="", icon_value=icons.get("icon_u").icon_id)

                if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
                    if context.selected_objects:
                        row.operator('object.speedsculpt_smooth_mesh_only', text="", icon_value=icons.get("icon_corrective_smooth").icon_id)

                row.prop(speedsculpt, "show_options", text="", icon_value=icons.get("icon_options").icon_id)
                if prefs.show_help:
                    row.scale_x = 1
                    row.operator("object.speedsculpt_help_remesh_dyntopo_settings", text="", icon='HELP', emboss=False)

                if context.object is not None and context.selected_objects and context.object.visible_get(view_layer=context.view_layer) :
                    if len([obj for obj in context.selected_objects]) == 1:
                        if not context.object.mode in ["SCULPT", "POSE"]:
                            if context.object.modifiers:
                                if "Mirror_primitive" in context.object.modifiers:
                                    row = col.row(align=True)
                                    row.scale_y = 1.5
                                    row.operator("object.boolean_sculpt_union_difference", text="Union/Apply Modifiers",
                                                icon_value=icons.get("icon_union").icon_id).operation_type = 'UNION'

                    meta_objects = False
                    if context.object is not None and context.object.type == 'META':
                        meta_objects = True

                    no_modifiers = True
                    if len(context.selected_objects) >= 2:
                        split = layout.split()
                        col = split.column(align=True)
                        row = col.row(align=True)
                        row.scale_y = 1.2
                        row.prop(speedsculpt, 'boolean_operation', expand=True)

            if speedsculpt.show_options:
                Options(self, context)
                
            Shading(self, context)
            AddPrimitives(self, context)
            Tools(self, context)

        if prefs.show_troubleshooting:
            draw_troubleshooting(self, context)

def draw_troubleshooting(self, context):
    layout = self.layout
    box = layout.box()
    split = box.split()
    col = split.column(align=True)
    row = col.row(align=True)
    row.scale_y = 1.2
    row.alert = True
    row.label(text="", icon='ERROR')
    header, panel = row.panel("troubleshooting_panel", default_closed=True)
    header.alert = True
    header.label(text="TROUBLESHOOTING")
    if panel:
        
        row_bc = col.row(align=True)
        row.scale_y = 1.2
        header, panel = row_bc.panel("blender_crashes_panel", default_closed=True)
        header.alert = True
        header.label(text="Blender Crashes when remesh or Dyntopo")
        if panel:
            col.separator()
            col.label(text="If Blender crashes when using the remesh or Dyntopo tools")
            col.label(text="it may be because of the value you are using.")
            col.label(text="Remesh and Dyntopo values depend on the size of the mesh")
            col.label(text="and the unit of the scene.")
            col.separator()
            col.label(text="On a big object with a small value, the number of quads will be very high.")
            col.label(text="Blender may crash due to memory issues or huge calculations.")
            col.separator()
            col.label(text="Before using values who may make Blender crash, try to use a bigger value and see if it works.")
            col.separator()
            col.label(text="Note:")
            col.label(text="Remesh uses small values to add high details")
            col.label(text="Dyntopo uses high values to add high details.")
            col.separator()
            col.label(text="To solve this issue, you can use the following method:")
            col.label(text="1. Use a bigger value on a sphere to test.")
            col.label(text="2. If it's ok, duplicate or backup your object and use the wanted value.")
            col.label(text="3. If it's ok, you can procede on your object.")
            col.separator()
            col.label(text="Also, if Blender creashes, it can also be an issue with video drivers.")
            col.label(text="Try to update your video drivers and see if it works.")
        
        row = col.row(align=True)
        row.scale_y = 1.2
        header, panel = row.panel("addon_does_not_work_panel", default_closed=True)
        header.alert = True
        header.label(text="Addon Does Not Work")
        if panel:
            col.separator()
            col.label(text="If the addon does not work, it can be an issue with the version of Blender.")
            col.label(text="or the version of the addon. Use the proper version for your Blender version.")
            col.separator()
            col.label(text="The versioning works like this: speedsculpt_v_0_3_8_blender_5_1_0")
            col.label(text="speedsculpt_v_0_3_8: Version of the addon")
            col.label(text="blender_5_1_0: Version of Blender")
            col.separator()
            col.label(text="If this is still not working, try with a portable version of Blender.")
            col.label(text="1- Download the portable version of Blender (zip file).")
            col.label(text="2- Extract the zip file.")
            col.label(text="3- Create a new folder named 'portable'")
            col.label(text="4- Launch Blender and install the addon.")
            col.label(text="5- If it's working, your current blender version is not working.")
            col.label(text="6- Make a fresh install of Blender and install the addon.")
            col.separator()
            col.label(text="This way, you will know if the issue is with the blender version or the addon.")
            col.label(text="If it's the addon's fault, please contact the developer on discord,")
            col.label(text="the link is in the addon preferences.")
            col.separator()
            col.label(text="Note: copying preferences from the previous blender to this new one")
            col.label(text="can add errors due to old settings/operators not available in the new blender version.")
            col.label(text="So, it's better to start fresh with a new blender version.")
    
        row = col.row(align=True)
        row.scale_y = 1.2
        header, panel = row.panel("update_the_addon_panel", default_closed=True)
        header.alert = True
        header.label(text="Update the Addon")
        if panel:
            col.separator()
            col.label(text="To perfectly update the addon, follow these steps.")
            col.label(text="1- Unninstall the addon.")
            col.label(text="2- Restart Blender.")
            col.label(text="3- Download the latest version of the addon (the one for this blender version).")
            col.label(text="4- Install the addon.")

class SPEEDSCULPT_OT_print_path(Operator):
    '''  '''
    bl_idname = 'object.speedsculpt_printpath'
    bl_label = "Print"
    bl_options = {'REGISTER'}

    def execute(self, context):
        print(os.path.dirname(__file__))
        return {'FINISHED'}

CLASSES =  [SPEEDSCULPT_OT_rename_geomesh_item,
            SPEEDSCULPT_OT_print_path,
            SPEEDSCULPT_OT_select_geomesh_in_list,
            SPEEDSCULPT_UL_geomesh,
            SPEEDSCULPT_UL_timelapse_cameras,
            
            # HELP
            SPEEDSCULPT_OT_help,
            SPEEDSCULPT_OT_help_primitives,
            SPEEDSCULPT_OT_help_skin,
            SPEEDSCULPT_OT_help_create_cut_tools,
            SPEEDSCULPT_OT_help_envelope,
            SPEEDSCULPT_OT_help_curves,
            SPEEDSCULPT_OT_help_draw_surface,
            SPEEDSCULPT_OT_help_lattice,
            SPEEDSCULPT_OT_help_symmetrize,
            SPEEDSCULPT_OT_help_tools,
            SPEEDSCULPT_OT_help_remesh,
            SPEEDSCULPT_OT_help_extract_mask,
            SPEEDSCULPT_OT_help_quickpose,
            SPEEDSCULPT_OT_help_dyntopo_remesh,
            SPEEDSCULPT_OT_help_dyntopo_remesh_value,
            SPEEDSCULPT_OT_help_dyntopo_remesh_setting,
            SPEEDSCULPT_OT_help_creation_tools,
            SPEEDSCULPT_OT_help_asset_library,
            SPEEDSCULPT_OT_help_draw_mesh,
            SPEEDSCULPT_OT_help_shading,
            SPEEDSCULPT_OT_help_muscles,
            SPEEDSCULPT_OT_help_geomesh,
            SPEEDSCULPT_OT_help_draw_curve,
            SPEEDSCULPT_OT_help_backup,
            SPEEDSCULPT_OT_help_array_curve,
            SPEEDSCULPT_OT_help_timelapse,
            SPEEDSCULPT_OT_help_cursor,
            SPEEDSCULPT_OT_help_store_views,
            SPEEDSCULPT_OT_help_hierarchy,

            # PANEL
            VIEW3D_PT_speedsculpt_panel,
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)


