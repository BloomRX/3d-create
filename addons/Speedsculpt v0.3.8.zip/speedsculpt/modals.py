import bpy
from bpy.props import IntProperty, FloatProperty,FloatVectorProperty
from bpy.types import Operator
from bpy.props import (
    BoolProperty,
    FloatProperty,
    IntProperty,
    StringProperty,
    PointerProperty,
    EnumProperty,
)
import blf
from mathutils import Matrix, Vector
import bpy_extras
import bpy_extras.view3d_utils
from bpy_extras import object_utils
from math import radians
from .functions import get_addon_preferences
from .operators import fill_holes, CheckDyntopo, CheckSmoothMesh
import os
import sys
from .operators import save_tmp

class MyHandleClass:
    _handler = None

    @classmethod
    def add_handler(cls, function, args=()):
        cls._handler = bpy.types.SpaceView3D.draw_handler_add(
                function, args, 'WINDOW', 'POST_PIXEL'
                )

    @classmethod
    def remove_handler(cls):
        if cls._handler is not None:
            bpy.types.SpaceView3D.draw_handler_remove(cls._handler, 'WINDOW')
            cls._handler = None

def is_bsurface_activated():
    return any('bsurface' in addon.lower() for addon in bpy.context.preferences.addons.keys())

def is_looptools_activated():
    return any('looptools' in addon.lower() for addon in bpy.context.preferences.addons.keys())
# ----------------------------------------------------------------------------------------------------------------------
# DRAW TEXT ------------------------------------------------------------------------------------------------------------
# ----------------------------------------------------------------------------------------------------------------------
font_info = {
    "font_id": 0,
    "handler": None,
}

def Speedsculpt_draw_callback_px(x, y, packed_strings, obj, active_area_hash):
    # Vérifier si nous sommes dans la vue active
    if hash(bpy.context.area) != active_area_hash:
        return

    # addon_pref = get_addon_preferences()

    text_size = 20
    font_id = 0
    dpi = 1
    if bpy.app.version < (4, 0, 0):
        blf.size(font_id, text_size, 72)
    else:
        blf.size(font_id, text_size * dpi)
    # blf.size(font_id, text_size, 72)
    x_offset = 0
    y_offset = 0
    shadow_color = (0, 0, 0, 0.2)
    shadow_x = 2
    shadow_y = -2
    text_pos_x = 1#addon_pref.text_pos_x
    text_pos_y = 80#addon_pref.text_pos_y
    overlap = bpy.context.preferences.system.use_region_overlap
    t_panel_width = 0
    text_shadow = True#addon_pref.text_shadow
    if overlap:
        for region in bpy.context.area.regions:
            if region.type == 'TOOLS':
                t_panel_width = region.width

    width = bpy.context.region.width
    height = bpy.context.region.height

    pos_x = min((width - t_panel_width - 250) * text_pos_x / 100 + t_panel_width, width - 250)
    pos_y = height / 2 + text_pos_y

    line_height = (blf.dimensions(font_id, "M")[1] )

    for command in packed_strings:
        if len(command) == 2:
            pstr, pcol = command
            blf.color(0, *pcol)
            text_width, text_height = blf.dimensions(font_id, pstr)
            if text_shadow:
                blf.enable(0, blf.SHADOW)
                blf.shadow_offset(0, shadow_x, shadow_y)
                blf.shadow(0, 3, shadow_color[0], shadow_color[1], shadow_color[2], shadow_color[3])
            blf.position(font_id, (pos_x + x_offset), (pos_y + y_offset), 0)
            blf.draw(font_id, pstr)
            x_offset += text_width
        else:
            x_offset = 0
            y_offset -= line_height

x = 0
y = 0
y1 = 100
RED = (1, 0, 0, 1)
GREEN = (0, 1, 0, 1)
BLUE = (0, 0, 1, 1)
WHITE = (1,1,1,1)

CR = "Carriage Return"

# DRAW MESH
ps =   [("DRAW MESH TOOL", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("SHIFT + RMB: ", WHITE), ("Place Cursor", GREEN),CR,
        ("", WHITE),CR,
        ("CTRL + LMB: ", WHITE), ("Erase annotation", GREEN),CR,
        ("", WHITE),CR,
        ("1,2,3: ", WHITE), ("Annotation Tools", GREEN),CR,
        ("", WHITE),CR,
        ("Numpad 1,3,7: ", WHITE), ("Change View", GREEN),CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Confirm & Exit", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
      ]

# DRAW SKIN
ps1 =  [("DRAW SKIN", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("CTRL + LMB: ", WHITE), ("Create on surface", GREEN),CR,
        ("", WHITE),CR,
        ("Numpad 1,3,7: ", WHITE), ("Change View", GREEN),CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Confirm & Exit", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
      ]

# DRAW SURFACE
ps2 =  [("DRAW SURFACE", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("Numpad 1,3,7: ", WHITE), ("Change View", GREEN),CR,
        ("", WHITE),CR,
        ("SPACE/ENTER: ", WHITE), ("Confirm & Exit", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
      ]

# INSERT PRIMITIVE
insert_primitive =  [("INSERT PRIMITIVE", WHITE),CR,
        ("", WHITE),CR,
        ("", WHITE),CR,
        ("G: ", WHITE), ("Translate", GREEN),CR,
        ("", WHITE),CR,
        ("R: ", WHITE), ("Rotate", GREEN),CR,
        ("", WHITE),CR,
        ("S: ", WHITE), ("Scale", GREEN),CR,
        ("", WHITE),CR,
        ("CTRL + SPACE: ", WHITE), ("Create new primitive", GREEN),CR,
        ("", WHITE),CR,
        ("RMB/ENTER/SPACE/LMB: ", WHITE), ("Confirm & Exit", GREEN),CR,
        ("", WHITE),CR,
        ("ESC: ", WHITE), ("Escape", GREEN)
      ]

# TRANSFORM MODAL
transform_modal_help = [("TRANSFORM MODAL", WHITE),CR,
    ("", WHITE),CR,
    ("", WHITE),CR,
    ("G: ", WHITE), ("Translate", GREEN),CR,
    ("", WHITE),CR,
    ("R: ", WHITE), ("Rotate", GREEN),CR,
    ("", WHITE),CR,
    ("S: ", WHITE), ("Scale", GREEN),CR,
    ("", WHITE),CR,
    ("ENTER/RMB: ", WHITE), ("Confirm & Exit", GREEN),CR,
    ("", WHITE),CR,
    ("ESC: ", WHITE), ("Cancel & Exit", GREEN)
  ]

# def clear_annotations():
#     # Get the active scene
#     scene = bpy.context.scene
    
#     if bpy.app.version < (4, 3, 0):
#         gpencil = 'GPENCIL'
#     else:
#         gpencil = 'GREASEPENCIL'
#     if bpy.app.version < (4, 3, 0):
#         # Iterate over all the objects in the scene
#         for obj in scene.objects:
#             # Check if the object has annotations
#             if obj.type == gpencil:
#                 # Get the annotation data
#                 annotation_data = obj.grease_pencil
#                 # Clear the annotation layers
#                 for layer in annotation_data.layers:
#                     annotation_data.layers.remove(layer)
#     else:
#         gpencil_data = bpy.context.scene.grease_pencil
#         if gpencil_data is not None:
#             annotation_layers = gpencil_data.layers
#             for layer in annotation_layers:
#                 bpy.ops.gpencil.layer_annotation_remove()
def clear_annotations():
    # Get the active scene
    scene = bpy.context.scene
    
    if bpy.app.version < (4, 3, 0):
        gpencil = 'GPENCIL'
    else:
        gpencil = 'GREASEPENCIL'
    if bpy.app.version < (4, 3, 0):
        # Iterate over all the objects in the scene
        for obj in scene.objects:
            # Check if the object has annotations
            if obj.type == gpencil:
                # Get the annotation data
                annotation_data = obj.grease_pencil
                # Clear the annotation layers
                for layer in annotation_data.layers:
                    annotation_data.layers.remove(layer)
    else:
        # Blender 4.3.0+ - compatible with 4.x and 5.0+
        if bpy.app.version >= (5, 0, 0):
            # Blender 5.0+ uses context.scene.annotation
            gpencil_data = getattr(scene, 'annotation', None)
        else:
            # Blender 4.x uses context.scene.grease_pencil
            gpencil_data = getattr(scene, 'grease_pencil', None)
        
        if gpencil_data is not None and gpencil_data.layers:
            # Remove all layers by iterating through a copy of the list
            # since we're modifying the collection during iteration
            layers_to_remove = list(gpencil_data.layers)
            
            if bpy.app.version >= (5, 0, 0):
                # Blender 5.0+ - use layers.remove() directly
                for layer in layers_to_remove:
                    gpencil_data.layers.remove(layer)
            else:
                # Blender 4.x - use operator after setting active layer
                for layer in layers_to_remove:
                    # Try to set as active if possible, otherwise use remove directly
                    if hasattr(gpencil_data.layers, 'active'):
                        gpencil_data.layers.active = layer
                        bpy.ops.gpencil.layer_annotation_remove()
                    else:
                        gpencil_data.layers.remove(layer)

class SPEEDSCULPT_OT_convert_annotations(Operator):
    bl_idname = "object.speedsculpt_convert_annotations"
    bl_label = "Convert Annotations"
    bl_description = ""
    bl_options = {"REGISTER"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        newCurve = bpy.data.curves.new('gpencil_curve', type='CURVE')
        newCurve.dimensions = '3D'
        CurveObject = object_utils.object_data_add(context, newCurve)
        
        if bpy.app.version < (4, 3, 0):
            grease_pencil = bpy.data.grease_pencils[0]
            strokes = grease_pencil.layers.active.active_frame.strokes
        else:
            # Blender 4.3.0+ - compatible with 4.x and 5.0+
            if bpy.app.version >= (5, 0, 0):
                # Blender 5.0+ uses context.scene.annotation
                gpencil_data = getattr(context.scene, 'annotation', None)
            else:
                # Blender 4.x uses context.scene.grease_pencil
                gpencil_data = getattr(context.scene, 'grease_pencil', None)
            
            if gpencil_data and gpencil_data.layers:
                layer = gpencil_data.layers[0]
                frame = layer.frames[0] 
                strokes = frame.strokes


        CurveObject.location = (0.0, 0.0, 0.0)
        CurveObject.rotation_euler = (0.0, 0.0, 0.0)
        CurveObject.scale = (1.0, 1.0, 1.0)

        if bpy.app.version < (4, 3, 0):
            for i, stroke in enumerate(strokes):
                stroke_points = strokes[i].points
                data_list = [(point.co.x, point.co.y, point.co.z)
                            for point in stroke_points]
                points_to_add = len(data_list) - 1

                flat_list = []
                for point in data_list:
                    flat_list.extend(point)

                spline = newCurve.splines.new(type='BEZIER')
                spline.bezier_points.add(points_to_add)
                spline.bezier_points.foreach_set("co", flat_list)

            for point in spline.bezier_points:
                point.handle_left_type = "AUTO"
                point.handle_right_type = "AUTO"
        else:
            for stroke in strokes:
                stroke_points = stroke.points
                data_list = [(point.co.x, point.co.y, point.co.z) for point in stroke_points]
                points_to_add = len(data_list) - 1

                flat_list = [coord for point in data_list for coord in point]

                spline = newCurve.splines.new(type='BEZIER')
                spline.bezier_points.add(points_to_add)
                spline.bezier_points.foreach_set("co", flat_list)

            for point in spline.bezier_points:
                point.handle_left_type = "AUTO"
                point.handle_right_type = "AUTO"


        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.curve.select_all(action='SELECT')
        bpy.ops.curve.spline_type_set(type='POLY')

        bpy.ops.object.mode_set(mode='OBJECT')
        bpy.ops.object.convert(target='MESH')
        bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY', center='MEDIAN')
        # annotation_layers = bpy.context.scene.grease_pencil
        # if annotation_layers and annotation_layers.data.layers:
        active_layer = bpy.context.active_annotation_layer
        if active_layer is not None:
            bpy.ops.gpencil.layer_annotation_remove()
        # clear_annotations()
        bpy.ops.object.convert(target='CURVE')
        return {"FINISHED"}

class SPEEDSCULPT_OT_draw_remesh(bpy.types.Operator):
    """Draw a mesh on a surface or on the view"""
    bl_idname = "object.speedsculpt_draw_remesh"
    bl_label = "Draw Remesh"

    def finalize(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        bpy.ops.object.speedsculpt_convert_annotations()

        self.new_obj = context.active_object
        context.object.data.bevel_depth = speedsculpt.draw_remesh_size
        context.object.data.bevel_resolution = 12
        context.object.data.splines[0].use_smooth = True
        bpy.ops.object.mode_set(mode='OBJECT')

        if not self.start_with_selection:
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

        bpy.ops.object.convert(target='MESH')
        fill_holes()

        new_obj = context.active_object

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                self.act_obj.select_set(state=False)
                self.new_obj.select_set(state=True)
                context.view_layer.objects.active = self.new_obj

        if self.start_with_selection and not speedsculpt.add_mirror:
        # if self.start_with_selection :
            self.act_obj.select_set(state=True)
            context.view_layer.objects.active = self.act_obj

        speedsculpt.boolean_operation = 'union'
        bpy.ops.object.speedsculpt_remesh_selection()

        if prefs.dyntopo_or_remesh == 'dyntopo':
            if prefs.update_detail_flood_fill:
                bpy.ops.object.update_dyntopo()

        if self.sculpt:
           bpy.ops.object.mode_set(mode='SCULPT')

        if speedsculpt.add_mirror:
            mod_mirror = new_obj.modifiers.new("Mirror", 'MIRROR')
            mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
            for prop, axis_index in mirror_axes.items():
                if getattr(speedsculpt, prop):
                    mod_mirror.use_axis[axis_index] = True
            if speedsculpt.ref_obj:
                mod_mirror.mirror_object = speedsculpt.ref_obj
            elif len([obj for obj in context.selected_objects]) == 1:
                mod_mirror.mirror_object = self.act_obj

        speedsculpt.boolean_operation = self.boolean_mode

    def modal(self, context, event):
        if event.type == "Z" and event.ctrl:
            return {"RUNNING_MODAL"}

        # CURSOR
        if event.shift and event.type == 'RIGHTMOUSE':
            return {'PASS_THROUGH'}

        # VIEWS
        if event.type in {'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_7', 'NUMPAD_5'} or event.ctrl and event.type in {'NUMPAD_1',
                                                                                                           'NUMPAD_3',
                                                                                                           'NUMPAD_7',
                                                                                                           'NUMPAD_5'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type == 'MIDDLEMOUSE' and event.value == 'DRAG':
            return {'PASS_THROUGH'}

        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.shift and event.type == 'C' :
            return {'PASS_THROUGH'}

        if event.type == 'ONE' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate", cycle=False, space_type='VIEW_3D')

        elif event.type == 'TWO' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate_line", cycle=False, space_type='VIEW_3D')

        elif event.type == 'THREE' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate_polygon", cycle=False, space_type='VIEW_3D')


        if event.type in {'RET','SPACE','ENTER'} and event.value == 'PRESS':
            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            self.finalize(context)


            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if self.start_with_selection:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj

            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            
            active_layer = bpy.context.active_annotation_layer
            if active_layer is not None:
                bpy.ops.gpencil.layer_annotation_remove()

            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        # Stocker le hash de la vue active
        self.active_area_hash = hash(context.area)

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()

        self.boolean_mode = speedsculpt.boolean_operation

        if context.area and context.area.type == 'VIEW_3D':
            self.sculpt = False
            self.act_obj = False
            self.start_with_selection = False

            if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
                speedsculpt.primitives_parenting = False
                speedsculpt.add_mirror = False
            else:
                self.act_obj = context.active_object

                if context.selected_objects:
                    self.start_with_selection = True

                if context.active_object.mode == 'SCULPT':
                    self.sculpt = True

                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.select_all(action='DESELECT')


            bpy.ops.wm.tool_set_by_id(name="builtin.annotate", cycle=False, space_type='VIEW_3D')
            
            if speedsculpt.draw_remesh_placement == 'cursor':
                context.scene.tool_settings.annotation_stroke_placement_view3d = 'CURSOR'
            elif speedsculpt.draw_remesh_placement == 'view':
                context.scene.tool_settings.annotation_stroke_placement_view3d = 'VIEW'
            elif speedsculpt.draw_remesh_placement == 'surface':
                context.scene.tool_settings.annotation_stroke_placement_view3d = 'SURFACE'

            MyHandleClass.remove_handler()
            MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps, context.object, self.active_area_hash))
            context.area.tag_redraw()

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_draw_surface(bpy.types.Operator):
    """Draw a Surface on a mesh or on the view"""
    bl_idname = "object.speedsculpt_draw_surface"
    bl_label = "Draw Surface"

    start_with_selection = False
    active_area_hash = None  # Nouvelle propriété pour stocker le hash

    def draw_surface_start(self, context):

        # Vérifier si nous sommes dans la vue active
        if hash(bpy.context.area) != self.active_area_hash:
            return
    
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        # selected = (obj for obj in context.selected_objects if len(obj) == 1)
        actObj = context.active_object if context.object is not None else None

        if bpy.app.version < (4, 2, 0):
            bpy.ops.preferences.addon_enable(module="mesh_bsurfaces")

        # prepare GP
        if speedsculpt.draw_surface_placement == 'SURFACE':
            context.scene.tool_settings.annotation_stroke_placement_view3d = 'SURFACE'
        elif speedsculpt.draw_surface_placement == 'CURSOR':
            context.scene.tool_settings.annotation_stroke_placement_view3d = 'CURSOR'

        
        context.scene.bsurfaces.SURFSK_shade_smooth = True

        if not prefs.update_remesh or prefs.update_detail_flood_fill:
            context.scene.bsurfaces.SURFSK_edges_U = 8
            context.scene.bsurfaces.SURFSK_edges_V = 2
        else:
            context.scene.bsurfaces.SURFSK_edges_U = 6
            context.scene.bsurfaces.SURFSK_edges_V = 4

        # Create Empty mesh
        bpy.ops.mesh.primitive_plane_add(size=2, enter_editmode=False, align='WORLD')

        gp_surface = context.active_object
        context.active_object.name = "GP_Surface"

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.delete(type='VERT')
        bpy.ops.object.mode_set(mode='OBJECT')
        if bpy.app.version < (4, 1, 0):
            bpy.ops.object.shade_smooth(use_auto_smooth=True)
        else:
            bpy.ops.object.shade_smooth_by_angle()


        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                actObj.select_set(state=True)
                context.view_layer.objects.active = actObj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                actObj.select_set(state=False)
                gp_surface.select_set(state=True)
                context.view_layer.objects.active = gp_surface

        # Add Solidify
        mod_solidify = gp_surface.modifiers.new("Solidify", 'SOLIDIFY')
        mod_solidify.thickness = speedsculpt.draw_surface_thickness
        mod_solidify.offset = speedsculpt.draw_surface_offset
        mod_solidify.use_quality_normals = True
        mod_solidify.use_even_offset = True

        # Add subsurf
        mod_subsurf = gp_surface.modifiers.new("Subsurf", 'SUBSURF')
        mod_subsurf.levels = 3

        context.scene.bsurfaces.SURFSK_object_with_retopology = gp_surface
        context.scene.bsurfaces.SURFSK_mesh = gp_surface
        bpy.ops.object.mode_set(mode='EDIT')

    def finalize(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        bpy.ops.speedsculpt.add_bsurface()
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent(inside=False)
        bpy.ops.object.mode_set(mode='OBJECT')

        if prefs.dyntopo_or_remesh == 'remesh':
            if not self.start_with_selection:
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

            # if prefs.update_remesh:
            if speedsculpt.draw_surface_update_remesh:
                bpy.ops.object.speedsculpt_remesh_selection()

            if self.start_with_selection:
                if self.sculpt:
                    bpy.ops.object.mode_set(mode='SCULPT')

        elif prefs.dyntopo_or_remesh == 'dyntopo':
            if not self.start_with_selection:
                bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)

            if prefs.update_detail_flood_fill :
                bpy.ops.object.update_dyntopo()

            if self.start_with_selection:
                if self.sculpt:
                    bpy.ops.object.mode_set(mode='SCULPT')


        # ADD MIRROR
        if speedsculpt.add_mirror:
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_MASS', center='MEDIAN')

            mod_mirror = context.object.modifiers.new("Mirror", 'MIRROR')
            mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
            for prop, axis_index in mirror_axes.items():
                if getattr(speedsculpt, prop):
                    mod_mirror.use_axis[axis_index] = True

            mod_mirror.use_mirror_merge = False

            if speedsculpt.ref_obj:
                mod_mirror.mirror_object = speedsculpt.ref_obj
            elif len([obj for obj in context.selected_objects]) == 1:
                mod_mirror.mirror_object = self.act_obj
            else:
                bpy.ops.object.modifier_remove(modifier="Mirror")

    def modal(self, context, event):
        if event.type == "Z" and event.ctrl:
            return {"RUNNING_MODAL"}

        # CURSOR
        if event.shift and event.type == 'RIGHTMOUSE':
            return {'PASS_THROUGH'}

        # VIEWS
        if event.type in {'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_7', 'NUMPAD_5'} or event.ctrl and event.type in {'NUMPAD_1',
                                                                                                           'NUMPAD_3',
                                                                                                           'NUMPAD_7',
                                                                                                           'NUMPAD_5'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.alt and event.type == 'MIDDLEMOUSE' and event.value == 'DRAG':
            return {'PASS_THROUGH'}

        if event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
            return {'PASS_THROUGH'}

        if event.shift and event.type == 'C' :
            return {'PASS_THROUGH'}

        if event.type == 'ONE' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate", cycle=False, space_type='VIEW_3D')

        elif event.type == 'TWO' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate_line", cycle=False, space_type='VIEW_3D')

        elif event.type == 'THREE' :
            bpy.ops.wm.tool_set_by_id(name="builtin.annotate_polygon", cycle=False, space_type='VIEW_3D')


        if event.type in {'RET','SPACE','ENTER'} and event.value == 'PRESS':
            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            self.finalize(context)

            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')

            clear_annotations()
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            if context.selected_objects:
                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.delete()

            if self.start_with_selection:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj

            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            # bpy.data.grease_pencils['Annotations'].layers['Note'].clear()
            clear_annotations()
            active_layer = bpy.context.active_annotation_layer
            if active_layer is not None:
                bpy.ops.gpencil.layer_annotation_remove()

            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):

        # Stocker le hash de la vue active
        self.active_area_hash = hash(context.area)

        bpy.ops.ed.undo_push()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()


        if context.area and context.area.type == 'VIEW_3D':
            if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
                speedsculpt.primitives_parenting = False
                speedsculpt.add_mirror = False
            else:
                self.act_obj = context.active_object

                if context.selected_objects:
                    self.start_with_selection = True


                self.sculpt = False
                if context.active_object.mode == 'SCULPT':
                    self.sculpt = True

                bpy.ops.object.mode_set(mode='OBJECT')
                bpy.ops.object.select_all(action='DESELECT')

            self.draw_surface_start(context)

            bpy.ops.wm.tool_set_by_id(name="builtin.annotate", cycle=False, space_type='VIEW_3D')


            MyHandleClass.remove_handler()
            MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps2, context.object, self.active_area_hash))
            context.area.tag_redraw()

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_draw_skin(bpy.types.Operator):
    bl_idname = "object.speedsculpt_draw_skin"
    bl_label = "DRAW SKIN"
    bl_description = "DRAW SKIN\n\nDraw a line in the 3Dview, it will add a Skin Modifier.\n\nYou will be able to Go in Edit Mode and Edit it.\n\nCTRL A to Scale a Vertex"

    prim_curve = False
    start_with_selection = False
    on_surface = False
    active_area_hash = None  # Nouvelle propriété pour stocker le hash

    def create_curve(self, context):
        speedsculpt = context.scene.speedsculpt

        bpy.ops.curve.primitive_bezier_curve_add(enter_editmode=False, align='VIEW')
        self.curve = context.active_object
        speedsculpt.primitive_created = True
        self.prim_curve = True

        context.space_data.overlay.display_handle = 'NONE'
        context.space_data.overlay.show_curve_normals = False

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.curve.delete(type='VERT')

    def create_skin(self, context):
        bpy.ops.object.convert(target='MESH')
        mod_skin = context.object.modifiers.new("Skin", 'SKIN')
        mod_skin.use_smooth_shade = True
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        context.tool_settings.mesh_select_mode = (False, True, False)
        bpy.ops.mesh.unsubdivide()

        if not self.on_surface :
            bpy.ops.mesh.unsubdivide()

        if is_looptools_activated():
            bpy.ops.mesh.looptools_space(influence=100, input='selected', interpolation='cubic', lock_x=False, lock_y=False, lock_z=False)

        if not self.on_surface:
            bpy.ops.object.add_smooth_skin()
        bpy.ops.object.skin_root_mark()
        context.tool_settings.mesh_select_mode = (True, False, False)
        bpy.ops.object.mode_set(mode='OBJECT')

        # Add Subdiv
        mod_subsurf = context.object.modifiers.new("Subsurf", 'SUBSURF')
        mod_subsurf.levels = 3

    def finalize(self, context):
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        context.scene.tool_settings.curve_paint_settings.depth_mode = 'CURSOR'
        self.new_obj = context.active_object


        bpy.ops.object.mode_set(mode='OBJECT')
        context.object.data.dimensions = '2D'
        context.object.data.resolution_u = 3
        new_obj = context.active_object

        self.create_skin(context)

        if speedsculpt.add_mirror:
            mod_mirror = new_obj.modifiers.new("Mirror_Skin", 'MIRROR')
            mirror_axes = {'mirror_x': 0, 'mirror_y': 1, 'mirror_z': 2}
            for prop, axis_index in mirror_axes.items():
                if getattr(speedsculpt, prop):
                    mod_mirror.use_axis[axis_index] = True
 
            if speedsculpt.ref_obj:
                mod_mirror.mirror_object = speedsculpt.ref_obj
            elif len([obj for obj in context.selected_objects]) == 1:
                mod_mirror.mirror_object = self.act_obj

        # Parenting
        if speedsculpt.primitives_parenting:
            if not context.active_object.parent:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                self.act_obj.select_set(state=False)
                new_obj.select_set(state=True)
                context.view_layer.objects.active = new_obj
        
        bpy.ops.object.mode_set(mode='EDIT')

        MyHandleClass.remove_handler()
        context.area.tag_redraw()

        bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')

    def modal(self, context, event):
        if event.type == "Z" and event.ctrl:
            return {"RUNNING_MODAL"}

        # CURSOR
        if event.shift and event.type == 'RIGHTMOUSE':
            return {'PASS_THROUGH'}

        # VIEWS
        if event.type in {'NUMPAD_1', 'NUMPAD_3', 'NUMPAD_7', 'NUMPAD_5'} or event.ctrl and event.type in {'NUMPAD_1',
                                                                                                           'NUMPAD_3',
                                                                                                           'NUMPAD_7',
                                                                                                           'NUMPAD_5'}:
            return {'PASS_THROUGH'}

        # if event.type =='MIDDLEMOUSE':
        #     return {'PASS_THROUGH'}

        # if event.alt and event.type == 'MIDDLEMOUSE' and event.value == 'DRAG':
        #     return {'PASS_THROUGH'}

        # if event.type in {'LEFTMOUSE', 'RIGHTMOUSE', 'MIDDLEMOUSE'}:
        #     return {'PASS_THROUGH'}

        if event.shift and event.type == 'C' :
            return {'PASS_THROUGH'}

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' :
            self.create_curve(context)

            if event.ctrl:
                self.on_surface = True
                context.scene.tool_settings.curve_paint_settings.depth_mode = 'SURFACE'
            else:
                context.scene.tool_settings.curve_paint_settings.depth_mode = 'CURSOR'

            bpy.ops.wm.tool_set_by_id(name="builtin.draw")
            bpy.ops.curve.draw('INVOKE_DEFAULT', error_threshold=0.05, fit_method='SPLIT', corner_angle=60,
                               use_cyclic=False,
                               stroke=[],
                               wait_for_input=False)

        if event.value == 'RELEASE' and self.prim_curve:
            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            self.finalize(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            MyHandleClass.remove_handler()
            context.area.tag_redraw()
            bpy.ops.wm.tool_set_by_id(name="builtin.select", cycle=False, space_type='VIEW_3D')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        # Stocker le hash de la vue active
        self.active_area_hash = hash(context.area)

        # AUTO SAVE
        if prefs.auto_save:
            if sys.platform.startswith('win'):
                save_tmp()

        if context.area and context.area.type == 'VIEW_3D':

            if context.object is None or not context.object.visible_get(view_layer=context.view_layer) :
                speedsculpt.primitives_parenting = False
                speedsculpt.add_mirror = False
            else:
                self.act_obj = context.active_object
                if context.selected_objects:
                    self.start_with_selection = True
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.select_all(action='DESELECT')

            MyHandleClass.remove_handler()
            MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, ps1, context.object, self.active_area_hash))
            context.area.tag_redraw()

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_assets_on_surface(bpy.types.Operator):
    """Move an object with the mouse, example"""
    bl_idname = "object.speedsculpt_assets_on_surface"
    bl_label = "Assets on Surface"

    first_mouse_x: IntProperty() # type: ignore
    x_value: FloatProperty() # type: ignore
    first_mouse_y: IntProperty() # type: ignore
    primitive_created = False

    def get_spin(self):
        obj = bpy.context.object
        return obj.rotation_euler.to_matrix().to_euler('ZYX').z

    def set_spin(self, value):
        obj = bpy.context.object
        rot = obj.rotation_euler.to_matrix().to_euler('ZYX')
        rot.z = value
        obj.rotation_euler = rot.to_matrix().to_euler(obj.rotation_mode)

    def get_scale_x(self):
        obj = bpy.context.active_object
        return obj.scale.x

    def set_scale_x(self, value):
        obj = bpy.context.active_object
        obj.scale.x = value

    def get_scale_y(self):
        obj = bpy.context.active_object
        return obj.scale.y

    def set_scale_y(self, value):
        obj = bpy.context.active_object
        obj.scale.y = value

    def get_scale_z(self):
        obj = bpy.context.active_object
        return obj.scale.z

    def set_scale_z(self, value):
        obj = bpy.context.active_object
        obj.scale.z = value

    spin: FloatProperty(
        unit='ROTATION',
        get=get_spin,
        set=set_spin, ) # type: ignore

    scaling_x: FloatProperty(
        unit='ROTATION',
        get=get_scale_x,
        set=set_scale_x, ) # type: ignore

    scaling_y: FloatProperty(
        unit='ROTATION',
        get=get_scale_y,
        set=set_scale_y, ) # type: ignore

    scaling_z: FloatProperty(
        unit='ROTATION',
        get=get_scale_z,
        set=set_scale_z, ) # type: ignore

    def create_cube(self, context):
        bpy.ops.object.speedsculpt_add_assets_to_scene('INVOKE_DEFAULT')
        bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
        context.object.rotation_euler = self.cursor_rot
        self.primitive_created = True
        self.act_obj = context.active_object

        bpy.ops.wm.tool_set_by_id(name="builtin.select")

    def finalize(self, context):
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()

        if prefs.dyntopo_or_remesh == 'remesh':
            if prefs.update_remesh:
                if self.start_with_selection:
                    self.start_obj.select_set(state=True)
                    context.view_layer.objects.active = self.start_obj
                speedsculpt.boolean_operation = 'union'
                bpy.ops.object.speedsculpt_remesh_selection()

        elif prefs.dyntopo_or_remesh == 'dyntopo':
            if prefs.update_detail_flood_fill:
                if self.start_with_selection:
                    self.start_obj.select_set(state=True)
                    context.view_layer.objects.active = self.start_obj
                bpy.ops.object.update_dyntopo()

        if self.sculpt:
           bpy.ops.object.mode_set(mode='SCULPT')


    def modal(self, context, event):
        prefs = get_addon_preferences()

        if event.type == 'LEFTMOUSE' and event.value == 'PRESS' and not self.primitive_created:
            # CURSOR
            bpy.ops.wm.tool_set_by_id(name="builtin.cursor")
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT', use_depth=True, orientation='GEOM')
            self.cursor_rot = context.scene.cursor.rotation_euler.copy()
            bpy.ops.view3d.snap_selected_to_cursor(use_offset=False)
            context.object.rotation_euler = self.cursor_rot
            bpy.ops.wm.tool_set_by_id(name="builtin.select")
            self.primitive_created = True
            self.act_obj = context.active_object
            # self.create_cube(context)

        if self.primitive_created:

            if event.type in {'MOUSEMOVE', 'INBETWEEN_MOUSEMOVE'}:
                delta_y = self.first_mouse_y + event.mouse_y
                speed = 0.33 if event.shift else 1

                # ROTATE
                self.spin = delta_y * 0.005 * speed * 0.85

                # SCALE
                self.scaling_x = self.act_obj.scale.x + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed
                self.scaling_y = self.act_obj.scale.y + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed
                self.scaling_z = self.act_obj.scale.z + (event.mouse_x - event.mouse_prev_x) * 0.05 * speed

        if event.type == 'LEFTMOUSE' and event.value == 'RELEASE':


            self.finalize(context)
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:

            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        if context.area and context.area.type == 'VIEW_3D':

            self.first_mouse_x = event.mouse_x
            self.first_mouse_y = event.mouse_y

            self.sculpt = False
            self.start_obj = False
            self.start_with_selection = False

            if context.object is not None and context.selected_objects:
                self.start_with_selection = True
                self.start_obj = context.active_object

                if context.active_object.mode == 'SCULPT':
                    self.sculpt = True

                bpy.ops.object.mode_set(mode='OBJECT')

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:

            return {'CANCELLED'}

class SPEEDSCULPT_OT_smooth_modal(bpy.types.Operator):
    """Move an object with the mouse, example"""
    bl_idname = "object.speedsculpt_smooth_modal"
    bl_label = "Smooth Modal Operator"

    first_mouse_x: IntProperty() # type: ignore
    first_value: FloatProperty() # type: ignore

    def modal(self, context, event):

        if event.type in 'MOUSEMOVE':
            delta = self.first_mouse_x - event.mouse_x

            if event.shift:
                delta = delta / 2

            self.act_mod.iterations = int(self.first_value - delta * 0.1)

        if event.type == 'LEFTMOUSE':
            bpy.ops.object.modifier_apply(modifier=self.act_mod.name)
            if self.prefs.sculpt_mode:
                bpy.ops.object.mode_set(mode='SCULPT')

            return {'FINISHED'}

        if event.type in {'RIGHTMOUSE', 'ESC'}:
            bpy.ops.object.modifier_remove(modifier=self.act_mod.name)
            if self.prefs.sculpt_mode:
                bpy.ops.object.mode_set(mode='SCULPT')
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        bpy.ops.ed.undo_push()
        if bpy.context.selected_objects:
            self.prefs = get_addon_preferences()
            self.first_mouse_x = event.mouse_x

            self.act_obj = bpy.context.active_object
            self.sel = [o for o in bpy.context.selected_objects]


            if context.object.mode == 'SCULPT':
                self.prefs.sculpt_mode = True
            else:
                self.prefs.sculpt_mode = False

            bpy.ops.object.mode_set(mode='OBJECT')
            bpy.ops.object.select_all(action='DESELECT')

            for obj in self.sel:
                obj.select_set(state=True)
                bpy.context.view_layer.objects.active = obj

                has_smooth = bpy.context.object.modifiers.get("Smooth_Modal")

                if has_smooth:
                    self.smooth_mod = has_smooth
                else:
                    self.smooth_mod = obj.modifiers.new('Smooth_Modal', 'SMOOTH')
                    self.smooth_mod.factor = 1
                    self.smooth_mod.iterations = 0

            for obj in self.sel:
                obj.select_set(state=True)

            bpy.context.view_layer.objects.active = self.act_obj

            self.act_mod = self.smooth_mod
            self.first_value = self.smooth_mod.iterations

            self.mod_created = True

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}
        else:
            self.report({'WARNING'}, "No active object, could not finish")
            return {'CANCELLED'}

tmp_verts = []
tmp_verts_storage = []

class SPEEDSCULPT_OT_scale(bpy.types.Operator):
    """Scale mesh with mouse"""
    bl_idname = "object.speedsculpt_scale"
    bl_label = "Simple Modal Operator"
    bl_options = {'GRAB_CURSOR','BLOCKING'}

    first_mouse_x: IntProperty() # type: ignore
    first_value: FloatProperty() # type: ignore
    action_scale = False

    obj_matrix_save = None
    start_end_cap = False
    random = False

    def modal(self, context, event):
        prefs = get_addon_preferences()

        if event.type == 'MOUSEMOVE' :
            speed = 0.01 if event.shift else 0.5
            # delta = 1. - 0.01 * (self.first_mouse_x - event.mouse_x) * speed #* addon_pref.modal_speed
            for mesh in self.meshes:
                obj = mesh["obj"]
                matrix = mesh["matrix"]

                delta = 0.05 * (event.mouse_x - self.first_mouse_x) * speed / 100
                obj.matrix_world = matrix @ Matrix.Scale(1 + delta, 4)

        elif event.type in {'LEFTMOUSE', 'SPACE'} :
            if prefs.dyntopo_or_remesh == "remesh":
                if prefs.update_remesh:
                    bpy.ops.object.speedsculpt_remesh_selection()

            elif prefs.dyntopo_or_remesh == "dyntopo":
                CheckDyntopo()
                CheckSmoothMesh()
            return {'FINISHED'}

        elif event.type in {'RIGHTMOUSE', 'ESC'}:
            context.view_layer.objects.active = self.act_obj
            self.act_obj.select_set(state=True)

            context.object.location.x = self.first_value
            return {'CANCELLED'}

        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        self.act_obj = context.active_object

        self.meshes = []
        for obj in self.sel:
            obj.select_set(state=True)
            self.meshes.append({
                "obj": obj,
                "matrix": obj.matrix_world.copy()
            })

            self.first_mouse_x = event.mouse_x

            context.window_manager.modal_handler_add(self)
            return {'RUNNING_MODAL'}

        else:
            self.report({'WARNING'}, "PROUT")
            return {'CANCELLED'}

class SPEEDSCULPT_OT_insert_primitive_modal(bpy.types.Operator):
    bl_idname = "object.speedsculpt_insert_primitive_modal"
    bl_label = "Insert Primitive Modal"
    bl_description = "Insert primitive with interactive scaling, moving and rotation"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    active_area_hash = None

    # Primitive type to create
    primitive_type: StringProperty(default="none") # type: ignore
    metaballs: StringProperty(default="none") # type: ignore
    imported_objects = [] # type: ignore
    use_existing_object: BoolProperty(default=False) # type: ignore
    
    # Modal state tracking
    mode: StringProperty(default="SCALE") # type: ignore  # SCALE, MOVE, ROTATE
    initial_mouse_x: IntProperty() # type: ignore
    initial_mouse_y: IntProperty() # type: ignore
    initial_scale: FloatVectorProperty(size=3, default=(1.0, 1.0, 1.0)) # type: ignore
    initial_location: FloatVectorProperty(size=3) # type: ignore
    initial_rotation: FloatVectorProperty(size=3) # type: ignore
    
    # State flags
    mouse_pressed: BoolProperty(default=False) # type: ignore
    object_created: BoolProperty(default=False) # type: ignore

    @classmethod
    def poll(cls, context):
        return context.area.type == 'VIEW_3D'


    def create_primitive_at_cursor(self, context, mouse_x, mouse_y):
        """Create a primitive at the 3D cursor position based on mouse coordinates"""
        import mathutils  # DÉPLACER L'IMPORT AU DÉBUT DE LA FONCTION
        speedsculpt = context.scene.speedsculpt
        
        # Convert mouse coordinates to 3D location
        region = context.region
        rv3d = context.region_data
        
        view_vector = bpy_extras.view3d_utils.region_2d_to_vector_3d(region, rv3d, (mouse_x, mouse_y))
        ray_origin = bpy_extras.view3d_utils.region_2d_to_origin_3d(region, rv3d, (mouse_x, mouse_y))
        
        # Perform raycast to find surface
        depsg = context.evaluated_depsgraph_get()
        hit, location_hit, normal, face_index, object_hit, matrix = context.scene.ray_cast(depsg, ray_origin, view_vector)
        
        # CORRECTION : Calculer l'offset selon les unités
        prefs = get_addon_preferences()
        if prefs.primitive_size == 'mm':
            offset_distance = 0.0001  # Plus petit offset pour millimètres
        elif prefs.primitive_size == 'cm':
            offset_distance = 0.001   # Offset adapté pour centimètres
        elif prefs.primitive_size == 'm':
            offset_distance = 0.01    # Offset normal pour mètres
        else:
            offset_distance = 0.01    # Par défaut
        
        # Initialize rotation variable
        rotation = None

        # if hit and object_hit and object_hit.type == 'MESH':
        if hit and object_hit :
            # Place on the surface of the hit mesh
            location = location_hit
            # CORRECTION : Offset adapté selon les unités
            location = location + normal * offset_distance
            
            # Calculate rotation from face normal
            if speedsculpt.copy_normal_orientation:
                z_axis = normal.normalized()
                # Create arbitrary perpendicular vector for x_axis
                if abs(z_axis.z) < 0.9:
                    x_axis = mathutils.Vector((0, 0, 1)).cross(z_axis).normalized()
                else:
                    x_axis = mathutils.Vector((1, 0, 0)).cross(z_axis).normalized()
                y_axis = z_axis.cross(x_axis).normalized()
                
                # Create rotation matrix
                rotation_matrix = mathutils.Matrix([
                    [x_axis.x, y_axis.x, z_axis.x, 0],
                    [x_axis.y, y_axis.y, z_axis.y, 0],
                    [x_axis.z, y_axis.z, z_axis.z, 0],
                    [0, 0, 0, 1]
                ])
                rotation = rotation_matrix.to_euler()
        else:
            
            # Place dans le plan du cursor (comme view annotation)
            cursor_location = context.scene.cursor.location
            
            # Calculer l'intersection du ray de la souris avec le plan passant par le cursor
            # et perpendiculaire à la direction de vue
            region = context.region
            rv3d = context.region_data
            
            # Direction de vue (inversée car c'est vers la caméra)
            view_direction = rv3d.view_matrix.to_3x3() @ mathutils.Vector((0, 0, -1))
            
            # Plan perpendiculaire à la vue passant par le cursor
            plane_normal = view_direction.normalized()
            plane_point = cursor_location
            
            # Calculer l'intersection ray/plan
            # Formule: ray_origin + t * ray_direction = point sur le plan
            # (point - plane_point) . plane_normal = 0
            # t = (plane_point - ray_origin) . plane_normal / (ray_direction . plane_normal)
            
            denominator = view_vector.dot(plane_normal)
            if abs(denominator) > 0.001:  # Éviter division par zéro
                t = (plane_point - ray_origin).dot(plane_normal) / denominator
                if t > 0:  # Intersection devant la caméra
                    location = ray_origin + view_vector * t
                else:
                    # Si intersection derrière, utiliser position par défaut
                    location = cursor_location
            else:
                # Ray parallèle au plan, utiliser cursor directement
                location = cursor_location
            
            # rotation = (0, 0, 0) 
            rotation = None
             # Pas de rotation spéciale
        
        # Store the location in 3D cursor temporarily
        old_cursor_location = context.scene.cursor.location.copy()
        old_cursor_rotation = context.scene.cursor.rotation_euler.copy()
        context.scene.cursor.location = location
        if rotation and speedsculpt.copy_normal_orientation:
            context.scene.cursor.rotation_euler = rotation
        
        # NOUVELLE LOGIQUE : Gérer l'objet existant
        if self.use_existing_object and speedsculpt.insert_object:
            # Dupliquer l'objet existant
            source_object = speedsculpt.insert_object

            bpy.ops.object.mode_set(mode='OBJECT')

            
            
            # Désélectionner tout
            bpy.ops.object.select_all(action='DESELECT')
            
            # Sélectionner et activer l'objet source
            source_object.select_set(True)
            context.view_layer.objects.active = source_object
            
            # Dupliquer l'objet
            bpy.ops.object.duplicate()
            
            # L'objet dupliqué devient l'objet actif
            duplicated_object = context.active_object
            duplicated_object.scale = (0.2, 0.2, 0.2)
            
            # Positionner l'objet dupliqué
            duplicated_object.location = location
            if rotation and speedsculpt.copy_normal_orientation:
                duplicated_object.rotation_euler = rotation
            
            self.created_object = duplicated_object
            self.imported_objects = []  # Pas d'objets importés dans ce cas

        else:
        
            # Get speedsculpt preferences for size
            prefs = get_addon_preferences()
            if prefs.primitive_size == 'mm':
                size = 0.001 / 10
            elif prefs.primitive_size == 'cm':
                size = 0.01 / 10
            elif prefs.primitive_size == 'm':
                size = 1 / 10
            elif prefs.primitive_size == 'custom':
                size = prefs.primitive_size_custom / 10

            # MESHES
            if context.active_object and context.active_object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
            
            if self.primitive_type in ['sphere', 'cylinder', 'cube', 'cone', 'torus']:
                
                # Create the primitive directly based on type
                if self.primitive_type == 'sphere':
                    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=5, radius=size, enter_editmode=False)

                elif self.primitive_type == 'cylinder':
                    bpy.ops.mesh.primitive_cylinder_add(vertices=64, radius=size, depth=size , end_fill_type='TRIFAN',
                                                        align='WORLD', enter_editmode=False)
                
                elif self.primitive_type == 'cube':
                    bpy.ops.mesh.primitive_cube_add(align='WORLD', enter_editmode=False, size=size)
                
                elif self.primitive_type == 'cone':
                    bpy.ops.mesh.primitive_cone_add(vertices=128, radius1=size, radius2=0, depth=size * 2, end_fill_type='TRIFAN', enter_editmode=False)
                    bpy.ops.object.mode_set(mode='EDIT')
                    bpy.ops.mesh.select_all(action='SELECT')
                    bpy.ops.transform.translate(value=(0, 0, size * 0.6))
                    bpy.ops.object.mode_set(mode='OBJECT')

                elif self.primitive_type == 'torus':
                    bpy.ops.mesh.primitive_torus_add(align='WORLD',
                                                    major_segments=120, minor_segments=64, mode='MAJOR_MINOR',
                                                    major_radius=size, minor_radius=size / 4, abso_major_rad=size * 1.25,
                                                    abso_minor_rad=size * 0.75)
            
            # METABALLS
            if self.metaballs in ['ball', 'capsule', 'hellipsoid', 'cube', 'plane']:
                # Metaballs
                if self.metaballs == 'ball':
                    bpy.ops.object.metaball_add(type='BALL', radius=size)
                elif self.metaballs == 'capsule':
                    bpy.ops.object.metaball_add(type='CAPSULE', radius=size)
                elif self.metaballs == 'hellipsoid':
                    bpy.ops.object.metaball_add(type='ELLIPSOID', radius=size)
                elif self.metaballs == 'cube':
                    bpy.ops.object.metaball_add(type='CUBE', radius=size)
                elif self.metaballs == 'plane':
                    bpy.ops.object.metaball_add(type='PLANE', radius=size)
                
                if context.active_object.type == 'META':
                    if prefs.primitive_size == 'mm':
                        context.object.data.resolution = 0.0005
                        context.object.data.threshold = 0.01
                    elif prefs.primitive_size == 'cm':
                        context.object.data.resolution = 0.005
                        context.object.data.threshold = 0.1
                    elif prefs.primitive_size == 'm':
                        context.object.data.resolution = 0.05
                        context.object.data.threshold = 0.1
                    context.object.data.update_method = 'HALFRES'
            
            # ASSETS
            if self.primitive_type == 'asset':
                # Créer l'asset depuis la bibliothèque
                wm = context.window_manager
                filepath = wm.speedsculpt_previews
                
                if filepath and os.path.exists(filepath):
                    # Sauvegarder la sélection actuelle
                    current_selection = list(context.selected_objects)
                    bpy.ops.object.select_all(action='DESELECT')
                    
                    # Charger l'asset
                    with bpy.data.libraries.load(filepath) as (data_from, data_to):
                        data_to.objects = [name for name in data_from.objects]
                    
                    imported_objects = []
                    for obj in data_to.objects:
                        context.collection.objects.link(obj)
                        obj.select_set(True)
                        imported_objects.append(obj)
                    
                    # Trouver l'objet parent principal
                    root_parent = None
                    for obj in imported_objects:
                        if obj.parent is None:
                            root_parent = obj
                            break
                    
                    if root_parent:
                        context.view_layer.objects.active = root_parent
                        self.imported_objects = imported_objects  # Stocker pour la finalisation
                        
                        # CORRECTION : Positionner l'objet selon le raycast
                        root_parent.location = location
                        if rotation and speedsculpt.copy_normal_orientation:
                            root_parent.rotation_euler = rotation
                            
                    else:
                        # Si pas de parent, prendre le premier objet
                        if imported_objects:
                            context.view_layer.objects.active = imported_objects[0]
                            self.imported_objects = imported_objects
                            
                            # CORRECTION : Positionner le premier objet selon le raycast
                            imported_objects[0].location = location
                            if rotation and speedsculpt.copy_normal_orientation:
                                imported_objects[0].rotation_euler = rotation
                else:
                    # Fallback sur une sphere si aucun asset sélectionné
                    bpy.ops.mesh.primitive_ico_sphere_add(subdivisions=5, radius=size, enter_editmode=False)
                    self.imported_objects = []
        
        if bpy.app.version > (4, 2, 0):
            bpy.ops.object.shade_auto_smooth()
        
        # Get the created object
        self.created_object = context.active_object
        if self.created_object:
            # Apply rotation from face normal if we hit a surface
            if rotation and speedsculpt.copy_normal_orientation:
                self.created_object.rotation_euler = rotation
                
            # Store initial values
            self.initial_scale = self.created_object.scale.copy()
            self.initial_location = self.created_object.location.copy()
            self.initial_rotation = self.created_object.rotation_euler.copy()
            self.object_created = True
            
            # Apply smooth shading and configure for sculpting
            if context.active_object.type == 'MESH':
                bpy.ops.object.mode_set(mode='SCULPT')
                bpy.context.scene.tool_settings.sculpt.detail_type_method = 'CONSTANT'
                bpy.ops.object.mode_set(mode='OBJECT')
            
            if bpy.app.version < (4, 1, 0):
                self.created_object.data.use_auto_smooth = False
        
        if speedsculpt.add_mirror and context.active_object.type == 'MESH':
            bpy.ops.object.speedsculpt_add_mirror()
        
        # Parenting
        if speedsculpt.primitives_parenting :
            if not context.active_object.parent:
                self.act_obj.select_set(state=True)
                context.view_layer.objects.active = self.act_obj
                bpy.ops.object.parent_set(type='OBJECT', keep_transform=True)
                self.act_obj.select_set(state=False)
                self.created_object.select_set(state=True)
                context.view_layer.objects.active = self.created_object
        
        # Restore cursor location and rotation
        context.scene.cursor.location = old_cursor_location
        context.scene.cursor.rotation_euler = old_cursor_rotation
        
        return self.created_object is not None

    def update_scale(self, context, delta_x):
        """Update object scale based on mouse movement - seulement pour le mode initial"""
        if not self.created_object:
            return
            
        # Calculate scale factor based on horizontal mouse movement
        scale_sensitivity = 0.05  # RÉDUIRE la sensibilité
        scale_factor = 1.0 + (delta_x * scale_sensitivity)
        scale_factor = max(0.001, min(500, scale_factor))  # LIMITER entre 0.1 et 5.0
        
        # Apply scale en partant de l'échelle initiale
        base_scale = self.initial_scale
        new_scale = (
            base_scale[0] * scale_factor,
            base_scale[1] * scale_factor, 
            base_scale[2] * scale_factor
        )
        
        self.created_object.scale = new_scale

    def finish_and_sculpt(self, context):
        prefs = get_addon_preferences()
        speedsculpt = context.scene.speedsculpt
        """Finish the modal and enter sculpt mode"""
        
        MyHandleClass.remove_handler()
        context.area.tag_redraw()

        tool_settings = context.scene.tool_settings
        tool_settings.use_snap = self.snap_active
        tool_settings.snap_elements_base = self.snap_elements
        tool_settings.use_snap_align_rotation = self.snap_align_rotation
        tool_settings.snap_target = self.snap_target


        if self.primitive_type == 'asset':
            # Finalisation spéciale pour les assets
            
            # Appliquer les transformations sur tous les objets importés
            if hasattr(self, 'imported_objects') and self.imported_objects:
                for obj in self.imported_objects:
                    if obj.type == 'MESH':
                        obj.select_set(True)
                        context.view_layer.objects.active = obj
                        bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

                        # Normals Outside
                        bpy.ops.object.mode_set(mode='EDIT')
                        bpy.ops.mesh.select_all(action='SELECT')
                        bpy.ops.mesh.normals_make_consistent(inside=False)
                        bpy.ops.object.mode_set(mode='OBJECT')

                        if speedsculpt.go_in_sculpt_mode:
                            bpy.ops.object.mode_set(mode='SCULPT')
                            if prefs.dyntopo_or_remesh == "dyntopo":
                                
                                if not context.sculpt_object.use_dynamic_topology_sculpting:
                                    bpy.ops.sculpt.dynamic_topology_toggle()
            
            return {'FINISHED'}

        elif self.created_object and self.created_object.type == 'MESH':
            context.view_layer.objects.active = self.created_object
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            # Normals Outside
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.normals_make_consistent(inside=False)
            bpy.ops.object.mode_set(mode='OBJECT')

            if speedsculpt.go_in_sculpt_mode:
                bpy.ops.object.mode_set(mode='SCULPT')
                if prefs.dyntopo_or_remesh == "dyntopo":
                    
                    if not context.sculpt_object.use_dynamic_topology_sculpting:
                        bpy.ops.sculpt.dynamic_topology_toggle()
            
            return {'FINISHED'}
        
        elif self.created_object and self.created_object.type == 'META':
            context.view_layer.objects.active = self.created_object
            # CORRECTION : Éviter transform_apply pour les ELLIPSOID qui doublent de taille
            if (self.created_object.type == 'META' and 
                hasattr(self, 'metaballs') and self.metaballs == 'hellipsoid'):
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                self.created_object.scale = (0.5, 0.5, 0.5)
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                # Ne pas appliquer transform pour les ellipsoïdes
                pass
            else:
                bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)

            return {'FINISHED'}

    def ensure_object_selected(self, context):
        """S'assurer que seul notre objet est sélectionné"""
        if self.created_object:
            # Désélectionner tous les objets
            bpy.ops.object.select_all(action='DESELECT')
            # Sélectionner uniquement notre objet
            self.created_object.select_set(True)
            context.view_layer.objects.active = self.created_object
    
    def cancel(self, context):
        """Cancel the modal and remove the created object"""
        tool_settings = context.scene.tool_settings
        tool_settings.use_snap = self.snap_active
        tool_settings.snap_elements_base = self.snap_elements
        tool_settings.use_snap_align_rotation = self.snap_align_rotation
        tool_settings.snap_target = self.snap_target
        
        # NETTOYER le callback
        MyHandleClass.remove_handler()
        
        if self.created_object:
            bpy.data.objects.remove(self.created_object, do_unlink=True)
        return {'CANCELLED'}

    def modal(self, context, event):
        # FORCER la sélection de notre objet
        if self.created_object:
            self.ensure_object_selected(context)
        
        if event.type in {'LEFTMOUSE', 'G', 'R', 'S', 'SPACE'} and event.value == 'PRESS':
            context.area.tag_redraw()
        
        

        if event.type == 'SPACE' and event.value == 'PRESS' and event.ctrl:
            bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
            
            # Nettoyer l'état actuel si nécessaire
            if self.in_transform:
                # Si on est en transformation, on la termine proprement
                self.in_transform = False
            
            # GARDER l'objet précédent - juste réinitialiser les variables de suivi
            # Ne pas supprimer : bpy.data.objects.remove(self.created_object, do_unlink=True)
            
            # Réinitialiser seulement l'état du modal pour une nouvelle primitive
            self.created_object = None  # Prêt pour un nouvel objet
            self.mouse_pressed = False
            self.object_created = False
            self.mode = "SCALE"
            self.paused = False
            self.in_transform = False

            # Optionnel : déselectionner tous les objets pour un placement propre
            bpy.ops.object.select_all(action='DESELECT')
            
            # Message pour l'utilisateur
            self.report({'INFO'}, "Ready for new primitive. Click to place")
            
            return {'RUNNING_MODAL'}

        elif event.type == 'SPACE' and event.value == 'PRESS':
            if self.paused and not self.in_transform:
                return self.finish_and_sculpt(context)
            return {'RUNNING_MODAL'}

        # NOUVELLE LOGIQUE : Détecter automatiquement la fin des transformations
        if self.in_transform:
            # Vérifier si on est toujours en mode transformation
            if context.mode == 'OBJECT':
                # On est revenu en mode objet = transformation terminée
                self.in_transform = False
                self.paused = True
                self.report({'INFO'}, "Transformation finished. Press G/R/S or click to finish")
                return {'RUNNING_MODAL'}
            else:
                # Toujours en transformation, laisser passer
                return {'PASS_THROUGH'}
        
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            
            if not self.created_object:
                # ÉTAPE 1 : Créer la primitive au premier clic
                if self.create_primitive_at_cursor(context, event.mouse_region_x, event.mouse_region_y):
                    self.mode = "SCALE"
                    self.paused = False
                    self.in_transform = False
                    self.mouse_pressed = True
                    self.initial_mouse_x = event.mouse_region_x
                    self.initial_mouse_y = event.mouse_region_y
                    self.initial_scale = self.created_object.scale.copy()
                    self.report({'INFO'}, "Scale mode. Drag to scale, click to confirm")
                    return {'RUNNING_MODAL'}
                    
            elif self.mouse_pressed and not self.in_transform:
                # ÉTAPE 2 : Confirmer le scale personnalisé
                self.mouse_pressed = False
                self.paused = True
                self.report({'INFO'}, "Scale confirmed. Press G/R/S for transformation, or click to finish")
                return {'RUNNING_MODAL'}
                
            elif self.paused and not self.in_transform:
                # ÉTAPE 3 : Clic final pour entrer en mode sculpt
                return self.finish_and_sculpt(context)
        
        # Mouvement de souris pour le scale personnalisé
        elif event.type == 'MOUSEMOVE' and self.mouse_pressed and not self.in_transform:
            delta_x = event.mouse_region_x - self.initial_mouse_x
            self.update_scale(context, delta_x)
            return {'RUNNING_MODAL'}
        
        # Gestion des touches G, R, S quand en pause
        elif event.type in {'G', 'R', 'S'} and event.value == 'PRESS':
            
            if self.paused and not self.in_transform:
                
                if event.type == 'G':
                    self.mode = "MOVE"
                    result = bpy.ops.transform.translate('INVOKE_DEFAULT', True)
                
                elif event.type == 'R':
                    self.mode = "ROTATE"
                    result = bpy.ops.transform.rotate('INVOKE_DEFAULT', True)
                
                elif event.type == 'S':
                    self.mode = "SCALE"
                    result = bpy.ops.transform.resize('INVOKE_DEFAULT', True)
                    
                self.in_transform = True
                self.paused = False
                self.report({'INFO'}, f"{self.mode} mode. Transformation will auto-pause when finished")
                return {'RUNNING_MODAL'}
            
        elif event.type in {'RET', 'ENTER', 'NUMPAD_ENTER','RIGHTMOUSE'}:
            return self.finish_and_sculpt(context)
        
        # Échap pour annuler
        elif event.type == 'ESC' and event.value == 'PRESS':
            if self.in_transform:
                self.in_transform = False
            
            return self.cancel(context)
        
        return {'PASS_THROUGH'}
        
    def invoke(self, context, event):
        # Initialize state
        self.mouse_pressed = False
        self.object_created = False
        self.created_object = None  # Variable normale, pas PointerProperty
        self.mode = "SCALE"
        self.paused = False
        self.in_transform = False
        self.act_obj = context.active_object
        self.active_area_hash = hash(context.area)

        tool_settings = context.scene.tool_settings
        self.snap_active = tool_settings.use_snap
        self.snap_elements = tool_settings.snap_elements_base
        self.snap_align_rotation = tool_settings.use_snap_align_rotation
        self.snap_target = tool_settings.snap_target

        # Activer les settings snap pour le modal
        # tool_settings.use_snap = True
        tool_settings.use_snap_align_rotation = True
        tool_settings.snap_elements_base = {'FACE'}
        tool_settings.snap_target = 'MEDIAN'

        speedsculpt = context.scene.speedsculpt

        if context.object is None or not context.object.visible_get(view_layer=context.view_layer):
            speedsculpt.primitives_parenting = False
            speedsculpt.add_mirror = False
        
        # Add modal handler
        MyHandleClass.remove_handler()
        MyHandleClass.add_handler(Speedsculpt_draw_callback_px, (x, y, insert_primitive, context.object, self.active_area_hash))
        context.area.tag_redraw()
        
        # Add modal handler
        context.window_manager.modal_handler_add(self)
        
        # Show instructions
        self.report({'INFO'}, "Click to place primitive and start scaling")
        
        return {'RUNNING_MODAL'}

    def execute(self, context):
        return {'FINISHED'}

class SPEEDSCULPT_OT_insert_object_modal(bpy.types.Operator):
    bl_idname = "object.speedsculpt_insert_object_modal"
    bl_label = "Insert Object Modal"
    bl_description = "Insert object with interactive scaling, moving and rotation"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        speedsculpt = context.scene.speedsculpt
        return (context.area.type == 'VIEW_3D' and 
                speedsculpt.insert_object is not None)

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        if speedsculpt.insert_object:
            bpy.ops.object.speedsculpt_insert_primitive_modal('INVOKE_DEFAULT', 
                                                            use_existing_object=True)
        else:
            self.report({'WARNING'}, "No object selected to insert")
        return {'FINISHED'}

class SPEEDSCULPT_OT_quick_translate(Operator):
    bl_idname = "object.speedsculpt_quick_translate"
    bl_label = "Quick Translate"
    bl_description = "Translate and return to original mode"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}
    
    _timer = None
    
    @classmethod
    def poll(cls, context):
        return (context.area.type == 'VIEW_3D' and 
                context.active_object is not None and
                context.mode == 'SCULPT')
    
    def modal(self, context, event):
        if event.type == 'TIMER':
            # Vérifier si on peut changer de mode de façon silencieuse
            current_mode = context.mode
            
            if current_mode == 'OBJECT':
                # Vérifier si on peut changer de mode sans générer d'erreur
                try:
                    # Test silencieux : essayer de définir le même mode
                    bpy.ops.object.mode_set(mode='OBJECT')
                    # Si ça passe, on peut changer de mode
                    bpy.ops.object.mode_set(mode='SCULPT')
                    
                    # Nettoyer le timer
                    if self._timer:
                        context.window_manager.event_timer_remove(self._timer)
                        self._timer = None
                    
                    return {'FINISHED'}
                except RuntimeError:
                    # Transform encore actif, on attend
                    pass
        
        return {'PASS_THROUGH'}
    
    def invoke(self, context, event):
        # Passer en mode Object
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Lancer le translate
        bpy.ops.transform.translate('INVOKE_DEFAULT')
        
        # Créer un timer pour vérifier périodiquement
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        return self.invoke(context, None)

class SPEEDSCULPT_OT_quick_rotate(Operator):
    bl_idname = "object.speedsculpt_quick_rotate"
    bl_label = "Quick Rotate"
    bl_description = "Rotate and return to original mode"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}
    
    _timer = None
    
    @classmethod
    def poll(cls, context):
        return (context.area.type == 'VIEW_3D' and 
                context.active_object is not None and
                context.mode == 'SCULPT')
    
    def modal(self, context, event):
        if event.type == 'TIMER':
            # Vérifier si on peut changer de mode de façon silencieuse
            current_mode = context.mode
            
            if current_mode == 'OBJECT':
                # Vérifier si on peut changer de mode sans générer d'erreur
                try:
                    # Test silencieux : essayer de définir le même mode
                    bpy.ops.object.mode_set(mode='OBJECT')
                    # Si ça passe, on peut changer de mode
                    bpy.ops.object.mode_set(mode='SCULPT')
                    
                    # Nettoyer le timer
                    if self._timer:
                        context.window_manager.event_timer_remove(self._timer)
                        self._timer = None
                    
                    return {'FINISHED'}
                except RuntimeError:
                    # Transform encore actif, on attend
                    pass
        
        return {'PASS_THROUGH'}
    
    def invoke(self, context, event):
        # Passer en mode Object
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Lancer le translate
        bpy.ops.transform.rotate('INVOKE_DEFAULT')
        
        # Créer un timer pour vérifier périodiquement
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        return self.invoke(context, None)

class SPEEDSCULPT_OT_quick_scale(Operator):
    bl_idname = "object.speedsculpt_quick_scale"
    bl_label = "Quick Scale"
    bl_description = "Scale and return to original mode"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}
    
    _timer = None
    
    @classmethod
    def poll(cls, context):
        return (context.area.type == 'VIEW_3D' and 
                context.active_object is not None and
                context.mode == 'SCULPT')
    
    def modal(self, context, event):
        if event.type == 'TIMER':
            # Vérifier si on peut changer de mode de façon silencieuse
            current_mode = context.mode
            
            if current_mode == 'OBJECT':
                # Vérifier si on peut changer de mode sans générer d'erreur
                try:
                    # Test silencieux : essayer de définir le même mode
                    bpy.ops.object.mode_set(mode='OBJECT')
                    bpy.ops.object.transform_apply(location=False, rotation=False, scale=True)
                    # Si ça passe, on peut changer de mode
                    bpy.ops.object.mode_set(mode='SCULPT')
                    
                    
                    
                    # Nettoyer le timer
                    if self._timer:
                        context.window_manager.event_timer_remove(self._timer)
                        self._timer = None
                    
                    
                    return {'FINISHED'}
                except RuntimeError:
                    # Transform encore actif, on attend
                    pass
        
        return {'PASS_THROUGH'}
    
    def invoke(self, context, event):
        # Passer en mode Object
        bpy.ops.object.mode_set(mode='OBJECT')
        
        # Lancer le translate
        bpy.ops.transform.resize('INVOKE_DEFAULT')
        
        # Créer un timer pour vérifier périodiquement
        self._timer = context.window_manager.event_timer_add(0.1, window=context.window)
        context.window_manager.modal_handler_add(self)
        
        return {'RUNNING_MODAL'}
    
    def execute(self, context):
        return self.invoke(context, None)

from bpy_extras import view3d_utils

class SPEEDSCULPT_OT_quick_cursor(Operator):
    bl_idname = "object.speedsculpt_quick_cursor"
    bl_label = "Quick Cursor"
    bl_description = "Set the Cursor and return in Sculpt Mode"
    bl_options = {'REGISTER', 'UNDO', 'BLOCKING'}

    _previous_tool = None
    _return_mode = None

    @classmethod
    def poll(cls, context):
        return (context.area.type == 'VIEW_3D' and 
                context.active_object is not None and
                context.mode == 'SCULPT')

    def modal(self, context, event):
        # Permettre le placement du curseur avec un clic gauche et terminer l'action
        if event.type == 'LEFTMOUSE' and event.value == 'PRESS':
            # Convertir la position de la souris en coordonnées 3D
            region = context.region
            rv3d = context.region_data
            coord = (event.mouse_region_x, event.mouse_region_y)
            view_vector = view3d_utils.region_2d_to_vector_3d(region, rv3d, coord)
            ray_origin = view3d_utils.region_2d_to_origin_3d(region, rv3d, coord)
            ray_target = ray_origin + (view_vector * 1000.0)

            result, location, normal, index, obj, matrix = context.scene.ray_cast(
                context.view_layer.depsgraph, ray_origin, view_vector
            )
            if result:
                context.scene.cursor.location = location
            else:
                # Si pas d'objet touché, placer sur le plan de la grille
                plane_point = ray_origin + view_vector * ((-ray_origin.z) / view_vector.z)
                context.scene.cursor.location = plane_point

            # Finir l'action après le placement du curseur
            
            if self._previous_tool and self._previous_tool != 'builtin.cursor':
                bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name=self._previous_tool)
            
            bpy.ops.object.mode_set(mode='SCULPT')
            return {'FINISHED'}

        # Sortir avec RMB, ESC ou ENTER
        if event.type in {'RIGHTMOUSE', 'ESC', 'RET', 'NUMPAD_ENTER'} and event.value == 'PRESS':
            bpy.ops.object.mode_set(mode='SCULPT')
            if self._previous_tool and self._previous_tool != 'builtin.cursor':
                print(self._previous_tool)
                bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name=self._previous_tool)
            return {'FINISHED'}
        return {'RUNNING_MODAL'}

    def invoke(self, context, event):
        from bpy_extras import view3d_utils
        self.view3d_utils = view3d_utils  # Stocker pour l'accès dans modal

        bpy.ops.object.mode_set(mode='OBJECT')
        self._previous_tool = context.workspace.tools.from_space_view3d_mode(context.mode, create=False).idname
        self._return_mode = context.mode

        print(self._previous_tool)

        
        if self._previous_tool != 'builtin.cursor':
            bpy.ops.wm.tool_set_by_id('INVOKE_DEFAULT', name="builtin.cursor")
            # Set the 3D cursor orientation to match the geometry under the cursor
            bpy.ops.view3d.cursor3d('INVOKE_DEFAULT', orientation='GEOM')

        
        self.report({'INFO'}, "Click to place cursor and return in Sculpt Mode")

        context.window_manager.modal_handler_add(self)
        return {'RUNNING_MODAL'}

    def execute(self, context):
        return self.invoke(context, None)

class SPEEDSCULPT_OT_ibl_manupilate(Operator):
    """ Rotates the environement """
    bl_idname = 'speedsculpt.ibl_manipulate'
    bl_label = "IBL manupulate"
    bl_description = "Rotate the environment\n\nMOUSE X DIRECTION: Adjust Size\nMOUSE Y DIRECTION: Adjust Strength\nRELEASE: Confirm"
    bl_options = {'REGISTER', "BLOCKING", "GRAB_CURSOR"}

    mouse_pos_x: IntProperty()  # type: ignore
    mouse_pos_y: IntProperty()  # type: ignore
    initial_mouse_pos: FloatVectorProperty(size=2, default=(0.0, 0.0))  # type: ignore
    end_position = 0
    tmp_pos_x = 0

    initial_strength: FloatProperty()  # type: ignore

    # AREA
    initial_size: FloatProperty()  # type: ignore
    size_value: FloatProperty(default=1.0)  # type: ignore

    # SUN
    initial_angle: FloatProperty()  # type: ignore
    angle_value: FloatProperty(default=0.0)  # type: ignore

    # SPOT-POINT
    initial_shadow_soft_size: FloatProperty()  # type: ignore
    shadow_soft_value: FloatProperty(default=1.0)  # type: ignore

    rotation_value: FloatProperty(default=0.0)  # type: ignore
    strength_value: FloatProperty(default=1.0)  # type: ignore
    shading_rotation: FloatProperty()  # type: ignore

    movement_mode: StringProperty(default='NONE')  # type: ignore

    is_light = False
    is_solid = False

    _handler = None
    active_area_hash = None  # Nouvelle propriété pour stocker le hash

    def ibl_rotation_info(self, context, _region):
        # Vérifier si nous sommes dans la vue active
        if hash(bpy.context.area) != self.active_area_hash:
            return
        
        # Define colors
        color_orange = (0, 1, 0, 1)
        
        color_white = (1.0, 1.0, 1.0, 1.0)
        

        # Font settings
        font_id = 0
        font_size_title = 24
        font_size_text = 20
        blf.size(font_id, font_size_title)

        # Calculate position
        height = bpy.context.area.height  # Utiliser bpy.context au lieu de context
        t_panel_width = 0
        if bpy.context.preferences.system.use_region_overlap:  # Utiliser bpy.context ici aussi
            for region in bpy.context.area.regions:  # Et ici
                if region.type == 'TOOLS':
                    t_panel_width = region.width

        # Starting position
        y = height / 2 + 100
        x = t_panel_width + 20


        if self.is_light:

            # Draw lights names
            y -= 40

            if self.is_light and self.light.type == "SUN":
                text = "SUN"
            elif self.is_light and self.light.type == "POINT":
                text = "POINT"
            elif self.is_light and self.light.type == "SPOT":
                text = "SPOT"
            elif self.is_light and self.light.type == "AREA":
                text = "AREA"

            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_white) 
            blf.draw(font_id, text)
            
            # Draw Strength value
            y -= 40
            if self.light.type == "SUN":
                strength_text = "STRENGTH: "
                strength_value = f"{self.strength_value:.3f}"
            else:
                strength_text = "POWER: "
                power_in_watts = self.strength_value / 10000
                if power_in_watts < 0.001:
                    strength_value = f"{power_in_watts * 1000000:.2f} µW"
                elif power_in_watts < 1:
                    strength_value = f"{power_in_watts * 1000:.2f} mW"
                else:
                    strength_value = f"{power_in_watts:.2f} W"

            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_orange)
            blf.draw(font_id, strength_text)

            blf.position(font_id, x + blf.dimensions(font_id, strength_text)[0], y, 0)
            blf.color(font_id, *color_white)
            blf.draw(font_id, strength_value)

            # Draw Size value
            y -= 40
            if self.light.type == "SUN":
                size_text = "ANGLE: "
                size_value = f"{self.angle_value * (180.0 / 3.14159):.1f} °"  # Convertir les radians en degrés

            elif self.light.type in {"SPOT", "POINT"}:
                size_text = "RADIUS: "
                size_value = f"{self.shadow_soft_value:.2f} cm"    
            else:
                size_text = "SIZE: "    
                size_value = f"{self.size_value:.1f} cm"

            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_orange)
            blf.draw(font_id, size_text)

            blf.position(font_id, x + blf.dimensions(font_id, size_text)[0], y, 0)
            blf.color(font_id, *color_white)
            blf.draw(font_id, size_value)


            # Draw instructions
            y -= 40
            blf.size(font_id, font_size_text)

            instructions = {
                "MOUSE X: ": "Adjust Size",
                "MOUSE Y: ": "Adjust Strength",
                "RELEASE: ": "Confirm"
            }
        
        elif self.is_solid:
            y -= 40
            text = "STUDIO"

            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_white) 
            blf.draw(font_id, text)

            y -= 40
            # Draw Rotation value
            rotation_text = "ROTATION: "
            # Convertir la valeur de radians en degrés et la formater
            rotation_degrees = (self.rotation_value * 180.0 / 3.14159) % 360
            rotation_value = f"{rotation_degrees:.1f}°"

            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_orange)
            blf.draw(font_id, rotation_text)

            blf.position(font_id, x + blf.dimensions(font_id, rotation_text)[0], y, 0)
            blf.color(font_id, *color_white)
            blf.draw(font_id, rotation_value)
            # Draw instructions
            y -= 40
            blf.size(font_id, font_size_text)

            instructions = {
                "MOUSE X: ": "Rotate Environement",
                "RELEASE: ": "Confirm"
            }

        else:
            y -= 40
            text = "ENVIRONMENT"

            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_white) 
            blf.draw(font_id, text)

            y -= 40
            # Draw Rotation value
            rotation_text = "ROTATION: "
            # Convertir la valeur de radians en degrés et la formater
            rotation_degrees = (self.rotation_value * 180.0 / 3.14159) % 360
            rotation_value = f"{rotation_degrees:.1f}°"

            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_orange)
            blf.draw(font_id, rotation_text)

            blf.position(font_id, x + blf.dimensions(font_id, rotation_text)[0], y, 0)
            blf.color(font_id, *color_white)
            blf.draw(font_id, rotation_value)

            # Draw Strength value
            y -= 40
            strength_text = "STRENGTH: "
            strength_value = f"{self.strength_value:.2f}"

            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_orange)
            blf.draw(font_id, strength_text)

            blf.position(font_id, x + blf.dimensions(font_id, strength_text)[0], y, 0)
            blf.color(font_id, *color_white)
            blf.draw(font_id, strength_value)

            # Draw instructions
            y -= 40
            blf.size(font_id, font_size_text)

            instructions = {
                "MOUSE X: ": "Rotate HDRI",
                "MOUSE Y: ": "Adjust Strength",
                "RELEASE: ": "Confirm"
            }

        
        for key, description in instructions.items():
            blf.position(font_id, x, y, 0)
            blf.color(font_id, *color_orange)
            blf.draw(font_id, key)
            
            blf.position(font_id, x + 100, y, 0)
            blf.color(font_id, *color_white)
            blf.draw(font_id, description)
            
            y -= font_size_text

    def get_background_node(self, world):
        nodes = world.node_tree.nodes
        background_node = self.get_node_from_type(nodes, "BACKGROUND")
        if not background_node:
            group_node = self.get_node_from_type(nodes, "GROUP")
            if group_node:
                background_node = self.get_node_from_type(group_node.node_tree.nodes, "BACKGROUND")
        return background_node

    def get_node_from_type(self, nodes, nType):
        for node in nodes:
            if node.type == nType:
                return node
        return None

    def get_mapping_node(self, world):
        nodes = world.node_tree.nodes
        mapping_node = self.get_node_from_type(nodes, "MAPPING")
        if not mapping_node:
            group_node = self.get_node_from_type(nodes, "GROUP")
            if group_node:
                mapping_node = self.get_node_from_type(group_node.node_tree.nodes, "MAPPING")
        return mapping_node

    def get_shading_type(self, shading):
        if shading.type != "WIREFRAME" or \
           (shading.type == "SOLID" and shading.light == "STUDIO") or \
           shading.type in {"MATERIAL", "RENDERED"}:
            return shading.type
        return

    def set_shading_rotation(self, mapping_node):
        self.shading_rotation = mapping_node.inputs[2].default_value[2]

    def set_z_axis(self, mapping_node, value):
        mapping_node.inputs[2].default_value[2] = value

    def get_internal_mapping_node(self, group_node):
        """
        Récupère le node Mapping à l'intérieur d'un node group
        """
        if group_node and group_node.node_tree:
            for node in group_node.node_tree.nodes:
                if node.type == 'MAPPING':
                    return node
        return None
    
    def is_connected_node(self, node):
        """
        Vérifie si le node donné est connecté dans le node tree.
        Retourne True si au moins une de ses sorties est liée.
        """
        for output in node.outputs:
            if output.is_linked:
                return True
        return False
    
    def detect_environment_source(self, context):
        """
        Détecte la source d'environnement à modifier.
        """
        world = context.scene.world
        env_type = None
        env_node = None
        
        # Parcours de tous les nodes pour chercher un node group connecté
        for node in world.node_tree.nodes:
            if node.type == 'GROUP' and node.node_tree is not None and self.is_connected_node(node):
                if node.node_tree.name.startswith("AM_environment"):
                    # Pour AM_environment, on vérifie qu'il y a un input strength et un mapping interne
                    has_strength = any("strength" in inp.name.lower() for inp in node.inputs)
                    has_mapping = self.get_internal_mapping_node(node) is not None
                    if has_strength and has_mapping:
                        env_type = "am_environment"
                        env_node = node
                        break
                else:
                    # Pour les autres groupes, on cherche strength et rotation dans les inputs
                    names = [inp.name.lower() for inp in node.inputs]
                    has_strength = any("strength" in name for name in names)
                    has_rotation = any("rotation" in name for name in names)
                    if has_strength or has_rotation:
                        env_type = "env_group"
                        env_node = node
                        break

        # Si aucun node group n'est trouvé, on cherche un background node
        if env_node is None:
            bg_node = self.get_background_node(world)
            if bg_node is not None and self.is_connected_node(bg_node):
                env_type = "background"
                env_node = bg_node
                
        # Dernière possibilité : fallback sur studiolight
        if env_type is None:
            env_type = "studiolight"
            env_node = None
            
        return env_type, env_node

    def get_strength_input(self, node):
        """
        Récupère l'input de force approprié selon le type de node
        """
        strength_keywords = ["strength", "power", "energy"]
        for inp in node.inputs:
            if any(keyword in inp.name.lower() for keyword in strength_keywords):
                return inp
        return None

    def invoke(self, context, event):
        prefs = get_addon_preferences()
        # Stocker le hash de la vue active
        self.active_area_hash = hash(context.area)
        # Initialisation des attributs pour éviter les erreurs
        self.background_node = None
        self.env_group = None
        self.env_modal_speed = prefs.env_modal_speed

        self.shading = context.space_data.shading
        self.shading_type = self.get_shading_type(self.shading)
        world = context.scene.world
        self.movement_mode = 'NONE'
        self.initial_mouse_pos = (event.mouse_x, event.mouse_y)

        if context.object is not None and context.selected_objects and context.object.type == "LIGHT":
            self.is_light = True
            self.light = context.object.data
            self.initial_strength = self.light.energy  # Initialisation de la force initiale pour tous les types
            
            # Initialisation des autres valeurs selon le type
            if self.light.type == "SUN":
                self.initial_angle = self.light.angle
                self.angle_value = self.light.angle
                self.strength_value = self.light.energy  # Ajout de l'initialisation de strength_value
            elif self.light.type in {"SPOT", "POINT"}:
                self.initial_shadow_soft_size = self.light.shadow_soft_size
                self.shadow_soft_value = self.light.shadow_soft_size
                self.strength_value = self.light.energy  # Ajout de l'initialisation de strength_value
            else:  # AREA
                self.initial_size = self.light.size
                self.size_value = self.light.size
                self.strength_value = self.light.energy  # Ajout de l'initialisation de strength_value
            
            self.mouse_pos_y = event.mouse_y
            self.mouse_pos_x = event.mouse_x
            context.window_manager.modal_handler_add(self)
            args = (self, context)
            self._handler = context.space_data.draw_handler_add(self.ibl_rotation_info, args, 'WINDOW', 'POST_PIXEL')
            return {'RUNNING_MODAL'}
                
        # Cas environnement (non lumière)
        else:
            self.is_light = False
            self.mapping_node = self.get_mapping_node(world)

            # Initialiser la force initiale selon le mode
            if self.shading_type == "SOLID" or \
               (self.shading_type == "MATERIAL" and not self.shading.use_scene_world) or \
               (self.shading_type == "RENDERED" and not self.shading.use_scene_world_render):
                self.initial_strength = self.shading.studiolight_intensity
                self.strength_value = self.shading.studiolight_intensity
            else:
                env_type, env_node = self.detect_environment_source(context)
                
                if env_node and env_node.type == 'GROUP':
                    self.env_group = env_node
                    if env_type == "am_environment":
                        # Pour AM_environment
                        for inp in env_node.inputs:
                            if "light strength" in inp.name.lower():
                                self.initial_strength = inp.default_value
                                self.strength_value = inp.default_value
                                break
                        internal_mapping = self.get_internal_mapping_node(env_node)
                        if internal_mapping:
                            self.initial_rotation = internal_mapping.inputs[2].default_value[2]
                            self.mapping_node = internal_mapping
                    else:
                        # Pour les autres groupes
                        strength_input = self.get_strength_input(env_node)
                        if strength_input:
                            self.initial_strength = strength_input.default_value
                            self.strength_value = strength_input.default_value
                        for inp in env_node.inputs:
                            if "rotation" in inp.name.lower():
                                if isinstance(inp.default_value, (list, tuple)):
                                    self.initial_rotation = inp.default_value[2]
                                else:
                                    self.initial_rotation = inp.default_value
                else:
                    # Cas des nodes standards (background)
                    self.background_node = env_node
                    if self.background_node:
                        self.initial_strength = self.background_node.inputs[1].default_value
                        self.strength_value = self.background_node.inputs[1].default_value
                    # On cherche toujours un mapping node pour la rotation
                    if self.mapping_node:
                        self.initial_rotation = self.mapping_node.inputs[2].default_value[2]

            # Gestion des modes de shading
            if self.shading_type == "SOLID":
                self.is_solid = True
                self.shading.use_world_space_lighting = True
                if context.space_data.shading.light == 'STUDIO':
                    self.shading_rotation = self.shading.studiolight_rotate_z
                else:
                    return {'CANCELLED'}
            else:
                self.is_solid = False
                if (self.shading_type == "MATERIAL" and self.shading.use_scene_world) or \
                   (self.shading_type == "RENDERED" and self.shading.use_scene_world_render):
                    if not hasattr(world, "node_tree"):
                        self.report({'WARNING'}, "No environment")
                        return {'CANCELLED'}
                    if self.mapping_node:
                        self.set_shading_rotation(self.mapping_node)
                    else:
                        self.shading_rotation = self.shading.studiolight_rotate_z
                else:
                    self.shading_rotation = self.shading.studiolight_rotate_z

            self.mouse_pos_x = event.mouse_x
            self.mouse_pos_y = event.mouse_y
            context.window_manager.modal_handler_add(self)
            self.rotation_value = self.shading_rotation
            args = (self, context)
            self._handler = context.space_data.draw_handler_add(self.ibl_rotation_info, args, 'WINDOW', 'POST_PIXEL')
            return {'RUNNING_MODAL'}

    def modal(self, context, event):
        
        if event.type == "MOUSEMOVE":
            if not self.is_light:
                offset_x = abs(event.mouse_x - self.initial_mouse_pos[0])
                offset_y = abs(event.mouse_y - self.initial_mouse_pos[1])
                if self.movement_mode == 'NONE' and max(offset_x, offset_y) > 10:
                    self.movement_mode = 'ROTATION' if offset_x > offset_y else 'STRENGTH'
                    if self.movement_mode == 'ROTATION':
                        self.mouse_pos_x = event.mouse_x
                    else:
                        self.mouse_pos_y = event.mouse_y

                if self.movement_mode == 'ROTATION':
                    offset = (event.mouse_x - self.mouse_pos_x) / 300.0
                    if self.shading_type == "SOLID":
                        self.shading.studiolight_rotate_z = self.shading_rotation - offset
                    elif self.shading_type == "MATERIAL" and self.shading.use_scene_world or \
                         self.shading_type == "RENDERED" and self.shading.use_scene_world_render:
                        if self.env_group is not None:
                            new_rotation = self.shading_rotation - offset
                            if self.env_group.node_tree.name.startswith("AM_environment"):
                                if self.mapping_node:
                                    self.set_z_axis(self.mapping_node, new_rotation)
                            else:
                                for inp in self.env_group.inputs:
                                    if "rotation" in inp.name.lower():
                                        if isinstance(inp.default_value, (list, tuple)):
                                            new_val = list(inp.default_value)
                                            new_val[2] = new_rotation
                                            inp.default_value = new_val
                                        else:
                                            inp.default_value = new_rotation
                                        break
                        elif self.mapping_node:
                            self.set_z_axis(self.mapping_node, self.shading_rotation - offset)
                    else:
                        self.shading.studiolight_rotate_z = self.shading_rotation - offset

                elif self.movement_mode == 'STRENGTH':
                    delta_y = event.mouse_y - self.mouse_pos_y
                    new_strength = max(0, self.initial_strength + (delta_y / 600.0) * 2)
                    
                    if self.shading_type == "SOLID" or \
                       (self.shading_type == "MATERIAL" and not self.shading.use_scene_world) or \
                       (self.shading_type == "RENDERED" and not self.shading.use_scene_world_render):
                        self.shading.studiolight_intensity = new_strength
                    else:
                        if self.env_group is not None:
                            if self.env_group.node_tree.name.startswith("AM_environment"):
                                for inp in self.env_group.inputs:
                                    if "light strength" in inp.name.lower():
                                        inp.default_value = new_strength
                                        break
                            else:
                                strength_input = self.get_strength_input(self.env_group)
                                if strength_input:
                                    strength_input.default_value = new_strength
                        elif self.background_node:
                            self.background_node.inputs[1].default_value = new_strength

                # Mise à jour des variables d'affichage
                if self.shading_type == "SOLID" or \
                   (self.shading_type == "MATERIAL" and not self.shading.use_scene_world) or \
                   (self.shading_type == "RENDERED" and not self.shading.use_scene_world_render):
                    self.rotation_value = self.shading.studiolight_rotate_z
                    self.strength_value = self.shading.studiolight_intensity
                else:
                    if self.env_group is not None:
                        if self.env_group.node_tree.name.startswith("AM_environment"):
                            for inp in self.env_group.inputs:
                                if "light strength" in inp.name.lower():
                                    self.strength_value = inp.default_value
                                    break
                            if self.mapping_node:
                                self.rotation_value = self.mapping_node.inputs[2].default_value[2]
                        else:
                            for inp in self.env_group.inputs:
                                if "rotation" in inp.name.lower():
                                    if isinstance(inp.default_value, (list, tuple)):
                                        self.rotation_value = inp.default_value[2]
                                    else:
                                        self.rotation_value = inp.default_value
                                if "strength" in inp.name.lower():
                                    self.strength_value = inp.default_value
                    elif self.mapping_node and self.background_node:
                        self.rotation_value = self.mapping_node.inputs[2].default_value[2]
                        self.strength_value = self.background_node.inputs[1].default_value
                    else:
                        self.rotation_value = self.shading.studiolight_rotate_z
                        self.strength_value = self.shading.studiolight_intensity

                # Forcer la mise à jour du node tree et du viewport
                context.scene.world.node_tree.update_tag()
                
            else:  # Light handling
                offset_x = abs(event.mouse_x - self.initial_mouse_pos[0])
                offset_y = abs(event.mouse_y - self.initial_mouse_pos[1])
                
                # Determine movement mode if not already set
                if self.movement_mode == 'NONE' and max(offset_x, offset_y) > 10:
                    self.movement_mode = 'SIZE' if offset_x > offset_y else 'STRENGTH'
                    if self.movement_mode == 'SIZE':
                        self.mouse_pos_x = event.mouse_x
                    else:
                        self.mouse_pos_y = event.mouse_y

                # Handle size/angle adjustments
                if self.movement_mode == 'SIZE':
                    delta_x = event.mouse_x - self.mouse_pos_x
                    if self.light.type == "SUN":
                        self.angle_value = max(0, self.initial_angle + (delta_x / 1000.0) * self.env_modal_speed)
                        self.light.angle = self.angle_value
                    elif self.light.type in {"SPOT", "POINT"}:
                        self.shadow_soft_value = max(0, self.initial_shadow_soft_size + (delta_x / 100.0) * self.env_modal_speed)
                        self.light.shadow_soft_size = self.shadow_soft_value
                    else:  # AREA
                        self.size_value = max(0, self.initial_size + (delta_x / 100.0) * self.env_modal_speed)
                        self.light.size = self.size_value

                # Handle strength adjustments
                elif self.movement_mode == 'STRENGTH':
                    delta_y = event.mouse_y - self.mouse_pos_y
                    if self.light.type == "SUN":
                        new_strength = max(0, self.initial_strength + (delta_y / 200) * self.env_modal_speed)
                    else:
                        new_strength = max(0, self.initial_strength + (delta_y ) * self.env_modal_speed)
                    self.strength_value = new_strength

                    self.light.energy = new_strength  # Mise à jour directe de l'énergie de la lumière
                
            # Force viewport update
            for area in context.screen.areas:

                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        if event.value == "RELEASE":
            context.space_data.draw_handler_remove(self._handler, 'WINDOW')
            context.area.tag_redraw()
            return {"FINISHED"}

        return {"RUNNING_MODAL"}
    
CLASSES =  [SPEEDSCULPT_OT_draw_remesh,
            SPEEDSCULPT_OT_convert_annotations,
            SPEEDSCULPT_OT_draw_skin,
            SPEEDSCULPT_OT_draw_surface,
            SPEEDSCULPT_OT_ibl_manupilate,
            SPEEDSCULPT_OT_assets_on_surface,
            SPEEDSCULPT_OT_smooth_modal,
            SPEEDSCULPT_OT_scale,
            SPEEDSCULPT_OT_insert_primitive_modal,
            SPEEDSCULPT_OT_insert_object_modal,
            SPEEDSCULPT_OT_quick_translate,
            SPEEDSCULPT_OT_quick_rotate,
            SPEEDSCULPT_OT_quick_scale,
            SPEEDSCULPT_OT_quick_cursor

            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)
