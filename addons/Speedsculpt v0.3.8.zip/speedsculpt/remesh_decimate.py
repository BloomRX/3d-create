# -*- coding:utf-8 -*-

# ProFlow Add-on
# Copyright (C) 2020 Cedric Lepiller aka Pitiwazou
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.

# <pep8 compliant>

import bpy
from .functions import get_addon_preferences
##------------------------------------------------------  
#
# Remesh/Decimate
#
##------------------------------------------------------ 

class SPEEDSCULPT_OT_simple_remesh(bpy.types.Operator):
    bl_idname = "object.simple_remesh"
    bl_label = "Remesh Object"
    bl_description = "Add simple remesh"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        prefs = get_addon_preferences()

        for obj in context.selected_objects:
            simple_remesh = obj.modifiers.new("R_Remesh", 'REMESH')
            simple_remesh.octree_depth = prefs.remesh_value
            simple_remesh.mode = 'SMOOTH'
            simple_remesh.use_smooth_shade = True
            simple_remesh.scale = 0.99

        return {"FINISHED"}

class SPEEDSCULPT_OT_remesh(bpy.types.Operator):
    bl_idname = "object.remesh"
    bl_label = "REMESH OBJECT"
    bl_description = "REMESH OBJECT\n\nAdd a REMESH Modifier to Remesh you Mesh.\nUseful whith DYNTOPO.\n\nYou can Edit the Settings and Apply it"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object
        modcount = len(obj.modifiers)
        speedsculpt = context.scene.speedsculpt
        prefs = get_addon_preferences()
        remesh_value = prefs.remesh_value
        
        for obj in context.selected_objects:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            if obj.type != 'MESH':
                bpy.ops.object.convert(target='MESH')
                obj = context.active_object


            skin = context.object.modifiers.get("Skin")
            remesh = context.object.modifiers.get("R_Remesh")
            smooth = context.object.modifiers.get("R_Smooth")
            subsurf = context.object.modifiers.get("Subsurf")

            # check for Skin and Apply
            if skin:
                if bpy.app.version >= (2, 90, 0):
                    bpy.ops.object.modifier_apply(modifier="Skin")
                    if subsurf:
                        bpy.ops.object.modifier_apply(modifier="Subsurf")

                else:
                    bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Skin")
                    if subsurf:
                        bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Subsurf")


            if not remesh and not smooth:
                # Add Remesh
                r_remesh = obj.modifiers.new("R_Remesh", 'REMESH')
                r_remesh.octree_depth = remesh_value
                r_remesh.mode = 'SMOOTH'
                r_remesh.use_smooth_shade = True
                r_remesh.scale = 0.99

                # Add Smooth
                r_smooth = obj.modifiers.new("R_Smooth", 'SMOOTH')
                r_smooth.factor = 1
                r_smooth.iterations = speedsculpt.remesh_smooth_repeat

                bpy.ops.object.modifier_move_down(modifier="R_Smooth")
                bpy.ops.object.modifier_move_down(modifier="R_Smooth")


                if modcount:
                    for i in range(modcount):
                        bpy.ops.object.modifier_move_up(modifier="R_Remesh")
                        bpy.ops.object.modifier_move_down(modifier="R_Smooth")

            else:
                for i in range(modcount):
                    bpy.ops.object.modifier_move_up(modifier="R_Remesh")
                    bpy.ops.object.modifier_move_down(modifier="R_Smooth")

        return {"FINISHED"}

class SPEEDSCULPT_OT_remove_remesh_smooth(bpy.types.Operator):
    bl_idname = "object.remove_remesh_smooth"
    bl_label = "Remove Remesh Smooth"
    bl_description = "Delete the Remesh modifier"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object

        for obj in context.selected_objects:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj

            remesh = context.object.modifiers.get("R_Remesh")
            smooth = context.object.modifiers.get("R_Smooth")
            if remesh and smooth:
                bpy.ops.object.modifier_remove(modifier="R_Remesh")
                bpy.ops.object.modifier_remove(modifier="R_Smooth")
            
            
        return {"FINISHED"}

class SPEEDSCULPT_OT_apply_remesh_smooth(bpy.types.Operator):
    bl_idname = "object.apply_remesh_smooth"
    bl_label = "Apply Remesh Smooth"
    bl_description = "Apply Remesh and smooth"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj = context.active_object

        for obj in context.selected_objects:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            remesh = context.object.modifiers.get("R_Remesh")
            smooth = context.object.modifiers.get("R_Smooth")
            if remesh and smooth:
                # if bpy.app.version >= (2, 90, 0):
                bpy.ops.object.modifier_apply(modifier="R_Remesh")
                bpy.ops.object.modifier_apply(modifier="R_Smooth")
                # else:
                #     bpy.ops.object.modifier_apply(apply_as='DATA', modifier="R_Remesh")
                #     bpy.ops.object.modifier_apply(apply_as='DATA', modifier="R_Smooth")

        return {"FINISHED"}
    
def HideRemeshSmooth(self, context):
    bl_description = "Hide the Remesh Modifier"

    for obj in context.selected_objects:
        obj.select_set(state=True)
        context.view_layer.objects.active = obj
        if context.object.modifiers["R_Remesh"].show_viewport == True :
            context.object.modifiers["R_Remesh"].show_viewport = False
            context.object.modifiers["R_Smooth"].show_viewport = False
        else:
            context.object.modifiers["R_Remesh"].show_viewport = True
            context.object.modifiers["R_Smooth"].show_viewport = True

def RemeshOctreeDepth(self, context):
    prefs = get_addon_preferences()
    remesh_value = prefs.remesh_value

    for obj in context.selected_objects:
        context.view_layer.objects.active = obj
        remesh = context.object.modifiers.get("R_Remesh")
        if remesh:
            obj.modifiers["R_Remesh"].octree_depth = remesh_value

def RemeshSmoothRepeat(self, context):
    speedsculpt = context.scene.speedsculpt

    for obj in context.selected_objects:
        context.view_layer.objects.active = obj
        smooth = context.object.modifiers.get("R_Smooth")
        if smooth:
            obj.modifiers["R_Smooth"].iterations = speedsculpt.remesh_smooth_repeat

class SPEEDSCULPT_OT_decimate(bpy.types.Operator):
    bl_idname = "object.decimate"
    bl_label = "DECIMATE OBJECT"
    bl_description = "DECIMATE OBJECT\n\nAdd a DECIMATE Modifier to Simplify you Mesh.\n\nYou can Edit the Settings and Apply it"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        speedsculpt = context.scene.speedsculpt
        obj = context.active_object

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            decimate = context.object.modifiers.get("Decimate")
            if not decimate :
                decimate = obj.modifiers.new("Decimate", 'DECIMATE')
                # decimate.ratio = speedsculpt.decimate_ratio
                decimate.ratio = 0.8
                speedsculpt.decimate_ratio = 0.8

        return {"FINISHED"}    

class SPEEDSCULPT_OT_apply_decimate(bpy.types.Operator):
    bl_idname = "object.apply_decimate"
    bl_label = "Apply decimate"
    bl_description = "Apply Decimate modifier"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        obj = context.active_object

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            decimate = context.object.modifiers.get("Decimate")
            if decimate:
                if bpy.app.version >= (2, 90, 0):
                    bpy.ops.object.modifier_apply(modifier="Decimate")
                else:
                    bpy.ops.object.modifier_apply(apply_as='DATA', modifier="Decimate")

        return {"FINISHED"}

def Hidedecimate(self, context):
    for obj in context.selected_objects:
        obj.select_set(state=True)
        context.view_layer.objects.active = obj

        for mod in obj.modifiers:
            if mod.type=='DECIMATE':
                if mod.show_viewport == True:
                    mod.show_viewport = False
                else:
                    mod.show_viewport = True

def DecimateRatio(self, context):
    bl_description = "Decimate Ratio"

    speedsculpt = context.scene.speedsculpt

    for obj in context.selected_objects:
        context.view_layer.objects.active = obj
        decimate = context.object.modifiers.get("Decimate")
        if decimate:
            obj.modifiers["Decimate"].ratio = speedsculpt.decimate_ratio
    
    context.area.tag_redraw()

class SPEEDSCULPT_OT_remove_decimate(bpy.types.Operator):
    bl_idname = "object.remove_decimate"
    bl_label = "Remove decimate"
    bl_description = "Remove Decimate modifier"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        obj = context.active_object

        for obj in context.selected_objects:
            context.view_layer.objects.active = obj
            decimate = context.object.modifiers.get("Decimate")
            if decimate:
                bpy.ops.object.modifier_remove(modifier="Decimate")

        return {"FINISHED"}        

class SPEEDSCULPT_OT_decimate_mask(bpy.types.Operator):
    bl_idname = "object.decimate_mask"
    bl_label = "Decimate Mask"
    bl_description = "Decimate the masking part"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context):
        obj_list = [obj for obj in context.selected_objects]
        obj = context.active_object
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            
            #Remove Vgroups
            for vgroup in obj.vertex_groups:
                if vgroup.name == 'Mask_Group':
                    obj.vertex_groups.remove(vgroup)
            
            # convert mask to vertex group
            bpy.ops.object.mode_set(mode='SCULPT')
            bpy.ops.paint.hide_show_masked(action='HIDE')
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.select_all(action='INVERT')
            bpy.ops.mesh.reveal()

            # create vertex group and assign vertices
            obj.vertex_groups.new(name="Mask_Group")
            for vgroup in obj.vertex_groups:
                if vgroup.name == "Mask_Group":
                    bpy.ops.object.vertex_group_assign()

            bpy.ops.object.mode_set(mode='OBJECT')
            mod_decimate = obj.modifiers.new("Skin", 'SKIN')
            mod_decimate.vertex_group = "Mask_Group"
            mod_decimate.ratio = 1

        return {"FINISHED"}   
  
class SPEEDSCULPT_OT_edit_decimate_mask(bpy.types.Operator):
    bl_idname = "object.edit_decimate_mask"
    bl_label = "Edit Decimate Mask"
    bl_description = "Edit the Decimate mask"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        for mod in context.object.modifiers:
            if mod.type == 'DECIMATE':
                mod.show_viewport = False

        bpy.ops.object.mode_set(mode='SCULPT')
        if bpy.app.version < (4, 3, 0):
            bpy.ops.paint.brush_select(sculpt_tool='MASK')
        else:
            bpy.ops.wm.tool_set_by_id(name="builtin_brush.mask")
        return {"FINISHED"}
          
class SPEEDSCULPT_OT_valid_decimate_mask(bpy.types.Operator):
    bl_idname = "object.valid_decimate_mask"
    bl_label = "Valide Decimate Mask"
    bl_description = "Valid the Decimate mask"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        
        obj_list = [obj for obj in context.selected_objects]
        obj = context.active_object
        for obj in obj_list:
            obj.select_set(state=True)
            context.view_layer.objects.active = obj
            
            #Remove Vgroups
            for vgroup in obj.vertex_groups:
                if vgroup.name == 'Mask_Group':
                    obj.vertex_groups.remove(vgroup)
            

            # bpy.ops.paint.hide_show(action='HIDE', area='MASKED')
            bpy.ops.paint.hide_show_masked(action='HIDE')

            bpy.ops.object.mode_set(mode='EDIT')
            
            bpy.ops.mesh.select_mode(use_extend=False, use_expand=False, type='VERT')
            bpy.ops.mesh.select_all(action='SELECT')
            bpy.ops.mesh.select_all(action='INVERT')
            bpy.ops.mesh.reveal()                           
            
            #Add Vgroup
            obj.vertex_groups.new(name="Mask_Group")
            for vgroup in obj.vertex_groups:
                if vgroup.name == 'Mask_Group':
                    bpy.ops.object.vertex_group_assign()

            decimate_mod = context.object.modifiers.get("Decimate")
            decimate_mod.vertex_group = "Mask_Group"

            bpy.ops.object.mode_set(mode='OBJECT')
            decimate_mod.show_viewport = True
            
        return {"FINISHED"}   

class SPEEDSCULPT_OT_add_mask(bpy.types.Operator):
    bl_idname = "object.add_mask"
    bl_label = "Add Mask"
    bl_description = "Add Mask to Decimate custom areas"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        obj = context.active_object

        decimate_mod = obj.modifiers.get("Decimate")
        decimate_mod.show_viewport = False
        # context.object.modifiers["Decimate"].show_viewport = False
        bpy.ops.object.mode_set(mode='SCULPT')
        if bpy.app.version < (4, 3, 0):
            bpy.ops.paint.brush_select(sculpt_tool='MASK')
        else:
            bpy.ops.wm.tool_set_by_id(name="builtin_brush.mask")

        return {"FINISHED"}
        
class SPEEDSCULPT_OT_remove_mask(bpy.types.Operator):
    bl_idname = "object.remove_mask"
    bl_label = "Remove Mask"
    bl_description = "Remove Mask"
    bl_options = {"REGISTER","UNDO"}

    def execute(self, context):
        obj = context.active_object
        #Remove Vgroups
        for vgroup in obj.vertex_groups:
            if vgroup.name == 'Mask_Group':
                obj.vertex_groups.remove(vgroup)
        decimate_mod = context.object.modifiers.get("Decimate")
        decimate_mod.vertex_group = ""
        
        return {"FINISHED"}

CLASSES =  [SPEEDSCULPT_OT_remove_mask,
            SPEEDSCULPT_OT_add_mask,
            SPEEDSCULPT_OT_valid_decimate_mask,
            SPEEDSCULPT_OT_edit_decimate_mask,
            SPEEDSCULPT_OT_decimate_mask,
            SPEEDSCULPT_OT_remove_decimate,
            SPEEDSCULPT_OT_apply_decimate,
            SPEEDSCULPT_OT_decimate,
            SPEEDSCULPT_OT_apply_remesh_smooth,
            SPEEDSCULPT_OT_remove_remesh_smooth,
            SPEEDSCULPT_OT_remesh,
            SPEEDSCULPT_OT_simple_remesh
            ]

def register():
    for cls in CLASSES:
        try:
            bpy.utils.register_class(cls)
        except:
            print(f"{cls.__name__} already registred")

def unregister():
    for cls in reversed(CLASSES):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass
    # for cls in CLASSES :
    #     if hasattr(bpy.types, cls.__name__):
    #         bpy.utils.unregister_class(cls)