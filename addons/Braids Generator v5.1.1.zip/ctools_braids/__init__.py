# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 3 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful, but
# WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTIBILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
# General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program. If not, see <http://www.gnu.org/licenses/>.

bl_info = {
    "name" : "CTools Braids",
    "author" : "Carlsu", 
    "description" : "",
    "blender" : (3, 0, 3),
    "version" : (5, 1, 1),
    "location" : "",
    "warning" : "",
    "doc_url": "", 
    "tracker_url": "", 
    "category" : "3D View" 
}


import bpy
import bpy.utils.previews
import os




def string_to_int(value):
    if value.isdigit():
        return int(value)
    return 0


def string_to_icon(value):
    if value in bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items.keys():
        return bpy.types.UILayout.bl_rna.functions["prop"].parameters["icon"].enum_items[value].value
    return string_to_int(value)


addon_keymaps = {}
_icons = None
convert = {'sna_braids_node': None, 'sna_braidsnodename': '_Hair Braids Generator', 'sna_realize_node': None, 'sna_realizenodename': 'RealizeObject', 'sna_active_node': None, 'sna_obj': None, }


def property_exists(prop_path, glob, loc):
    try:
        eval(prop_path, glob, loc)
        return True
    except:
        return False


class SNA_OT_Convert_Uv_Attr_2F19D(bpy.types.Operator):
    bl_idname = "sna.convert_uv_attr_2f19d"
    bl_label = "convert_uv_attr"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_attr_index: bpy.props.IntProperty(name='attr_index', description='', options={'HIDDEN'}, default=0, subtype='NONE')
    sna_replace: bpy.props.BoolProperty(name='replace', description='', options={'HIDDEN'}, default=False)
    sna_replace_index: bpy.props.IntProperty(name='replace_index', description='', options={'HIDDEN'}, default=0, subtype='NONE')

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if self.sna_replace:
            bpy.context.active_object.data.uv_layers.active_index = self.sna_replace_index
            bpy.ops.mesh.uv_texture_remove()
        bpy.context.active_object.data.attributes.active_index = self.sna_attr_index
        bpy.ops.geometry.attribute_convert(mode='UV_MAP')
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_CONVERT_UVMAP_D0FEB(bpy.types.Panel):
    bl_label = 'Convert UVMap'
    bl_idname = 'SNA_PT_CONVERT_UVMAP_D0FEB'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_2F930 = layout.column(heading='', align=True)
        col_2F930.alert = False
        col_2F930.enabled = True
        col_2F930.active = True
        col_2F930.use_property_split = False
        col_2F930.use_property_decorate = False
        col_2F930.scale_x = 1.0
        col_2F930.scale_y = 1.0
        col_2F930.alignment = 'Expand'.upper()
        col_2F930.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        for i_7C907 in range(len(bpy.context.active_object.data.attributes)):
            if (bpy.context.active_object.data.attributes[i_7C907].domain == 'CORNER' and bpy.context.active_object.data.attributes[i_7C907].data_type == 'FLOAT_VECTOR' ):
                box_33004 = col_2F930.box()
                box_33004.alert = False
                box_33004.enabled = True
                box_33004.active = True
                box_33004.use_property_split = False
                box_33004.use_property_decorate = False
                box_33004.alignment = 'Expand'.upper()
                box_33004.scale_x = 1.0
                box_33004.scale_y = 1.2000000476837158
                if not True: box_33004.operator_context = "EXEC_DEFAULT"
                row_F6F76 = box_33004.row(heading='', align=True)
                row_F6F76.alert = False
                row_F6F76.enabled = True
                row_F6F76.active = True
                row_F6F76.use_property_split = False
                row_F6F76.use_property_decorate = False
                row_F6F76.scale_x = 1.0
                row_F6F76.scale_y = 1.0
                row_F6F76.alignment = 'Expand'.upper()
                row_F6F76.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
                row_F6F76.label(text=str(bpy.context.active_object.data.attributes[i_7C907].name), icon_value=0)
                op = row_F6F76.operator('sna.convert_uv_attr_2f19d', text=('Replace' if (property_exists("eval('bpy.context.active_object.data.uv_layers')", globals(), locals()) and str(bpy.context.active_object.data.attributes[i_7C907].name) in eval('bpy.context.active_object.data.uv_layers')) else 'Convert'), icon_value=0, emboss=True, depress=False)
                op.sna_attr_index = i_7C907
                op.sna_replace = (property_exists("eval('bpy.context.active_object.data.uv_layers')", globals(), locals()) and str(bpy.context.active_object.data.attributes[i_7C907].name) in eval('bpy.context.active_object.data.uv_layers'))
                op.sna_replace_index = eval('bpy.context.active_object.data.uv_layers').find(str(bpy.context.active_object.data.attributes[i_7C907].name))


class SNA_OT_Convertattribute_0C40B(bpy.types.Operator):
    bl_idname = "sna.convertattribute_0c40b"
    bl_label = "ConvertAttribute"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and True:
            cls.poll_message_set('')
        return not False

    def execute(self, context):
        bpy.ops.wm.call_panel(name="SNA_PT_CONVERT_UVMAP_D0FEB", keep_open=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_OT_Add_Braids_Dc824(bpy.types.Operator):
    bl_idname = "sna.add_braids_dc824"
    bl_label = "Add braids"
    bl_description = "Add braids modifier to active object"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        if bpy.context.active_object.type.startswith("CURVE"):
            sna_setbraidsnode_81A0C()
            if bpy.context.view_layer.objects.active.type == 'CURVE':
                exec('curve = bpy.context.object.data')
                exec('curve.bevel_depth = 0')
                exec('curve.extrude = 0')
            if (property_exists("bpy.context.active_object.modifiers.active.node_group", globals(), locals()) and eval('bpy.context.active_object.modifiers.active.node_group == None')):
                pass
            else:
                bpy.ops.object.modifier_add(type='NODES')
            bpy.context.active_object.modifiers.active.node_group = convert['sna_braids_node']
            exec('bpy.context.object.select_set(True)')
        else:
            bpy.ops.wm.call_panel(name="SNA_PT_CURVE_ERROR_EE245", keep_open=False)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_CURVE_ERROR_EE245(bpy.types.Panel):
    bl_label = 'Curve error'
    bl_idname = 'SNA_PT_CURVE_ERROR_EE245'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_context = ''
    bl_order = 0
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not (False)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        layout.label(text='Select a curve', icon_value=string_to_icon('ERROR'))


def sna_getrealizeobject_1C864():
    if (property_exists("bpy.data.node_groups", globals(), locals()) and convert['sna_realizenodename'] in bpy.data.node_groups):
        convert['sna_realize_node'] = bpy.data.node_groups[convert['sna_realizenodename']]
    else:
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=os.path.join(os.path.dirname(__file__), 'assets', 'Realize.blend') + r'\NodeTree', filename=convert['sna_realizenodename'], link=True)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_DFE21 = None if not new_data else new_data[0]
        convert['sna_realize_node'] = appended_DFE21
    return str(convert['sna_realize_node'].name)


def sna_setbraidsnode_81A0C():
    if (property_exists("bpy.data.node_groups", globals(), locals()) and convert['sna_braidsnodename'] in bpy.data.node_groups):
        convert['sna_braids_node'] = bpy.data.node_groups[convert['sna_braidsnodename']]
    else:
        before_data = list(bpy.data.node_groups)
        bpy.ops.wm.append(directory=(os.path.join(os.path.dirname(__file__), 'assets', 'Braids_4.2_v5.01.blend') if eval('bpy.app.version >= (4, 2, 0)') else (os.path.join(os.path.dirname(__file__), 'assets', 'Braids_4.0_v4.02.blend') if eval('bpy.app.version >= (4, 0, 0)') else (os.path.join(os.path.dirname(__file__), 'assets', 'Braids_3.5_v4.02.blend') if eval('bpy.app.version >= (3, 5, 0)') else os.path.join(os.path.dirname(__file__), 'assets', 'Braids_3.3_v4.01.blend')))) + r'\NodeTree', filename=convert['sna_braidsnodename'], link=True)
        new_data = list(filter(lambda d: not d in before_data, list(bpy.data.node_groups)))
        appended_75E87 = None if not new_data else new_data[0]
        convert['sna_braids_node'] = appended_75E87


def sna_extra_28E03(layout_function, ):
    if property_exists("bpy.context.active_object.data", globals(), locals()):
        col_D7F66 = layout_function.column(heading='', align=True)
        col_D7F66.alert = False
        col_D7F66.enabled = True
        col_D7F66.active = True
        col_D7F66.use_property_split = False
        col_D7F66.use_property_decorate = False
        col_D7F66.scale_x = 1.0
        col_D7F66.scale_y = 1.0
        col_D7F66.alignment = 'Expand'.upper()
        col_D7F66.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_E495E = col_D7F66.row(heading='', align=True)
        row_E495E.alert = False
        row_E495E.enabled = True
        row_E495E.active = True
        row_E495E.use_property_split = False
        row_E495E.use_property_decorate = False
        row_E495E.scale_x = 1.0
        row_E495E.scale_y = 1.0
        row_E495E.alignment = 'Expand'.upper()
        row_E495E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_E495E.operator('sna.realizeobject_002d8', text='Convert to Mesh', icon_value=string_to_icon('MESH_DATA'), emboss=True, depress=False)
        if eval('bpy.app.version < (3, 5, 0)'):
            row_DACE0 = row_E495E.row(heading='', align=True)
            row_DACE0.alert = False
            row_DACE0.enabled = (eval("bpy.context.active_object.type == 'MESH'") and eval("[attr for attr in bpy.context.active_object.data.attributes if attr.data_type == 'FLOAT_VECTOR' and attr.domain == 'CORNER' ] != []"))
            row_DACE0.active = True
            row_DACE0.use_property_split = False
            row_DACE0.use_property_decorate = False
            row_DACE0.scale_x = 1.2000000476837158
            row_DACE0.scale_y = 1.0
            row_DACE0.alignment = 'Expand'.upper()
            row_DACE0.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            op = row_DACE0.operator('sna.convertattribute_0c40b', text='', icon_value=string_to_icon('UV'), emboss=True, depress=False)
    else:
        layout_function.label(text='Active object hidden', icon_value=string_to_icon('ERROR'))


def realize_object(modifier_name):
    C = bpy.context
    D = bpy.data
    realize_object = D.node_groups[modifier_name]
    if not realize_object:
        return print("No realize object node group found")
    obj = C.view_layer.objects.active
    mesh = D.meshes.new(obj.name+"_mesh")
    new_obj = D.objects.new(obj.name+"_mesh", mesh)
    C.collection.objects.link(new_obj)
    C.view_layer.objects.active = new_obj
    bpy.ops.object.modifier_add(type='NODES')
    C.active_object.modifiers[-1].node_group = D.node_groups[modifier_name]
    C.active_object.modifiers[-1]['Input_2'] = D.objects[obj.name]
    bpy.ops.object.modifier_apply(modifier="GeometryNodes")
    new_obj.select_set(True)


class SNA_OT_Realizeobject_002D8(bpy.types.Operator):
    bl_idname = "sna.realizeobject_002d8"
    bl_label = "RealizeObject"
    bl_description = "Converts object to mesh regardless of type (made for hair curves)."
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        modifier_name_0_34c48 = sna_getrealizeobject_1C864()
        return_0A646 = realize_object(modifier_name=modifier_name_0_34c48)
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


class SNA_PT_BRAIDS_GENERATOR_0C5A2(bpy.types.Panel):
    bl_label = 'Braids Generator'
    bl_idname = 'SNA_PT_BRAIDS_GENERATOR_0C5A2'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_context = ''
    bl_category = 'CTools'
    bl_order = 2
    bl_ui_units_x=0

    @classmethod
    def poll(cls, context):
        return not ( not bpy.context.preferences.addons['ctools_braids'].preferences.sna_enabled)

    def draw_header(self, context):
        layout = self.layout

    def draw(self, context):
        layout = self.layout
        col_36583 = layout.column(heading='', align=True)
        col_36583.alert = False
        col_36583.enabled = True
        col_36583.active = True
        col_36583.use_property_split = False
        col_36583.use_property_decorate = False
        col_36583.scale_x = 1.0
        col_36583.scale_y = 1.25
        col_36583.alignment = 'Expand'.upper()
        col_36583.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        row_75C8A = col_36583.row(heading='', align=True)
        row_75C8A.alert = False
        row_75C8A.enabled = True
        row_75C8A.active = True
        row_75C8A.use_property_split = False
        row_75C8A.use_property_decorate = False
        row_75C8A.scale_x = 1.0
        row_75C8A.scale_y = 1.0
        row_75C8A.alignment = 'Expand'.upper()
        row_75C8A.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
        op = row_75C8A.operator('sna.add_braids_dc824', text='Add braids', icon_value=string_to_icon('OUTLINER_OB_CURVES'), emboss=True, depress=False)
        layout_function = col_36583
        sna_extra_28E03(layout_function, )


class SNA_AddonPreferences_F63C1(bpy.types.AddonPreferences):
    bl_idname = 'ctools_braids'
    sna_enabled: bpy.props.BoolProperty(name='Enabled', description='', default=True)

    def draw(self, context):
        if not (False):
            layout = self.layout 
            layout_function = layout
            sna_title_6D14E(layout_function, )
            row_21BC1 = layout.row(heading='', align=True)
            row_21BC1.alert = False
            row_21BC1.enabled = True
            row_21BC1.active = True
            row_21BC1.use_property_split = False
            row_21BC1.use_property_decorate = False
            row_21BC1.scale_x = 1.0
            row_21BC1.scale_y = 1.2000000476837158
            row_21BC1.alignment = 'Left'.upper()
            row_21BC1.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
            row_21BC1.prop(bpy.context.preferences.addons['ctools_braids'].preferences, 'sna_enabled', text=('Addon Enabled' if bpy.context.preferences.addons['ctools_braids'].preferences.sna_enabled else 'Addon Disabled'), icon_value=0, emboss=True, toggle=True)


class SNA_OT_Open_Link_53Ce0(bpy.types.Operator):
    bl_idname = "sna.open_link_53ce0"
    bl_label = "Open link"
    bl_description = ""
    bl_options = {"REGISTER", "UNDO"}
    sna_link: bpy.props.StringProperty(name='Link', description='', options={'HIDDEN'}, default='', subtype='NONE', maxlen=0)

    @classmethod
    def poll(cls, context):
        if bpy.app.version >= (3, 0, 0) and False:
            cls.poll_message_set()
        return not False

    def execute(self, context):
        exec('import webbrowser')
        exec("webbrowser.open('" + str(self.sna_link) + "')")
        return {"FINISHED"}

    def invoke(self, context, event):
        return self.execute(context)


def sna_title_6D14E(layout_function, ):
    row_ADB18 = layout_function.row(heading='', align=False)
    row_ADB18.alert = False
    row_ADB18.enabled = True
    row_ADB18.active = True
    row_ADB18.use_property_split = False
    row_ADB18.use_property_decorate = False
    row_ADB18.scale_x = 1.0
    row_ADB18.scale_y = 1.0
    row_ADB18.alignment = 'Expand'.upper()
    row_ADB18.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_52B2E = row_ADB18.row(heading='', align=False)
    row_52B2E.alert = False
    row_52B2E.enabled = True
    row_52B2E.active = True
    row_52B2E.use_property_split = False
    row_52B2E.use_property_decorate = False
    row_52B2E.scale_x = 1.0
    row_52B2E.scale_y = 1.0
    row_52B2E.alignment = 'Left'.upper()
    row_52B2E.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    row_52B2E.label(text='Braids Generator', icon_value=0)
    row_E47DC = row_ADB18.row(heading='', align=False)
    row_E47DC.alert = False
    row_E47DC.enabled = True
    row_E47DC.active = True
    row_E47DC.use_property_split = False
    row_E47DC.use_property_decorate = False
    row_E47DC.scale_x = 1.0
    row_E47DC.scale_y = 1.0
    row_E47DC.alignment = 'Right'.upper()
    row_E47DC.operator_context = "INVOKE_DEFAULT" if True else "EXEC_DEFAULT"
    op = row_E47DC.operator('sna.open_link_53ce0', text='Ko-Fi', icon_value=string_to_icon('URL'), emboss=True, depress=False)
    op.sna_link = 'https://ko-fi.com/carlsu'


def register():
    global _icons
    _icons = bpy.utils.previews.new()
    bpy.utils.register_class(SNA_OT_Convert_Uv_Attr_2F19D)
    bpy.utils.register_class(SNA_PT_CONVERT_UVMAP_D0FEB)
    bpy.utils.register_class(SNA_OT_Convertattribute_0C40B)
    bpy.utils.register_class(SNA_OT_Add_Braids_Dc824)
    bpy.utils.register_class(SNA_PT_CURVE_ERROR_EE245)
    bpy.utils.register_class(SNA_OT_Realizeobject_002D8)
    bpy.utils.register_class(SNA_PT_BRAIDS_GENERATOR_0C5A2)
    bpy.utils.register_class(SNA_AddonPreferences_F63C1)
    bpy.utils.register_class(SNA_OT_Open_Link_53Ce0)


def unregister():
    global _icons
    bpy.utils.previews.remove(_icons)
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    for km, kmi in addon_keymaps.values():
        km.keymap_items.remove(kmi)
    addon_keymaps.clear()
    bpy.utils.unregister_class(SNA_OT_Convert_Uv_Attr_2F19D)
    bpy.utils.unregister_class(SNA_PT_CONVERT_UVMAP_D0FEB)
    bpy.utils.unregister_class(SNA_OT_Convertattribute_0C40B)
    bpy.utils.unregister_class(SNA_OT_Add_Braids_Dc824)
    bpy.utils.unregister_class(SNA_PT_CURVE_ERROR_EE245)
    bpy.utils.unregister_class(SNA_OT_Realizeobject_002D8)
    bpy.utils.unregister_class(SNA_PT_BRAIDS_GENERATOR_0C5A2)
    bpy.utils.unregister_class(SNA_AddonPreferences_F63C1)
    bpy.utils.unregister_class(SNA_OT_Open_Link_53Ce0)
