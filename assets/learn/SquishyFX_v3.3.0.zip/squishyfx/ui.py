# -*- coding: utf-8 -*-
"""
SquishyFX - ui.py
Sidebar (N-Panel) in the 3D Viewport, "SquishyFX" tab.
Includes: object / Vertex Group pickers, effect buttons, presets, the
stack of active effects with editable parameters, and the bake tools
(Control Empty, Bake a Shape Keys).
"""

import bpy
from bpy.types import Panel, Menu

from . import geometry_nodes as gn
from .operators import (
    EFFECT_ITEMS,
    is_squishyfx_modifier,
    input_socket_items,
    _sock_struct,
    mod_get_attribute,
)
from .presets import PRESETS, load_custom_presets


# ---------------------------------------------------------------------------
# Preset menus (built-in + user presets)
# ---------------------------------------------------------------------------

def _effect_icon(effect):
    return next((i[3] for i in EFFECT_ITEMS if i[0] == effect), 'PRESET')


# Cycle-warning cache: walking bone constraints on every redraw would be
# expensive; it is recomputed only when collection membership changes.
_cycle_cache = {"key": None, "names": []}


def _risky_colliders(coll):
    key = tuple(sorted(o.name for o in coll.objects))
    if key != _cycle_cache["key"]:
        from .operators import collider_cycle_risk
        _cycle_cache["key"] = key
        _cycle_cache["names"] = [o.name for o in coll.objects
                                 if collider_cycle_risk(o)]
    return _cycle_cache["names"]


class SQUISHYFX_MT_presets(Menu):
    bl_idname = "SQUISHYFX_MT_presets"
    bl_label = "SquishyFX Presets"

    def draw(self, context):
        layout = self.layout
        for name, data in PRESETS.items():
            op = layout.operator("squishyfx.apply_preset", text=name,
                                 icon=_effect_icon(data["effect"]))
            op.preset = name

        custom = load_custom_presets()
        if custom:
            layout.separator()
            layout.label(text="Custom", icon='BOOKMARKS')
            for name, data in custom.items():
                op = layout.operator("squishyfx.apply_preset", text=name,
                                     icon=_effect_icon(data.get("effect")))
                op.preset = name
            layout.separator()
            layout.menu("SQUISHYFX_MT_delete_preset", icon='TRASH')


class SQUISHYFX_MT_delete_preset(Menu):
    bl_idname = "SQUISHYFX_MT_delete_preset"
    bl_label = "Delete Custom Preset"

    def draw(self, context):
        layout = self.layout
        for name in load_custom_presets():
            op = layout.operator("squishyfx.delete_preset", text=name,
                                 icon='X')
            op.preset = name


# ---------------------------------------------------------------------------
# Panel principal
# ---------------------------------------------------------------------------

class SQUISHYFX_PT_main(Panel):
    bl_label = "SquishyFX"
    bl_idname = "SQUISHYFX_PT_main"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SquishyFX"

    def draw(self, context):
        layout = self.layout
        props = context.scene.squishyfx
        obj = context.active_object

        # ---------------------------------------------------------- objetivo
        box = layout.box()
        col = box.column(align=True)
        col.label(text="Target", icon='OBJECT_DATA')

        if obj is None or obj.type != 'MESH':
            col.label(text="Selecciona un objeto Mesh", icon='ERROR')
            return

        row = col.row(align=True)
        row.label(text=obj.name, icon='MESH_DATA')

        # prop_search on the active object: search + automatic refresh
        col.prop_search(props, "vertex_group", obj, "vertex_groups",
                        text="", icon='GROUP_VERTEX')
        if props.vertex_group and props.vertex_group not in obj.vertex_groups:
            col.label(text="Vertex Group no encontrado", icon='ERROR')
        elif not props.vertex_group:
            col.label(text="No mask: effect applies to the whole mesh",
                      icon='INFO')

        # AUTOMATIC colliders: any object with Collision physics collides
        # on its own, with no collection to manage. The button is an
        # optional manual refresh; "Add Collider" creates a ready sphere.
        coll = bpy.data.collections.get("SquishyFX Colliders")
        n = len([c for c in coll.objects]) if coll else 0
        col.label(text=f"Automatic colliders: {n} active",
                  icon='PHYSICS')
        col.label(text="Da 'Collision' (Physics) a un objeto y colisiona",
                  icon='INFO')
        row = col.row(align=True)
        row.operator("squishyfx.detect_colliders",
                     text="Refrescar", icon='FILE_REFRESH')
        row.operator("squishyfx.add_collider_sphere",
                     text="Add Collider", icon='MESH_UVSPHERE')

        # Negative scale = inside-out geometry in world space: the inside
        # test misfires and spikes appear (worse with 2+ colliders).
        # Clear warning so the user applies the scale (Ctrl+A).
        if coll:
            bad = [c.name for c in coll.objects
                   if c.matrix_world.determinant() < 0.0]
            if bad:
                col.label(text=f"Escala negativa (aplica Ctrl+A): "
                          f"{', '.join(bad[:3])}", icon='ERROR')
            risky = _risky_colliders(coll)
            if risky:
                col.label(text=f"Cycle - remove it and use Self Collision: "
                          f"{', '.join(risky[:2])}", icon='ERROR')

        # ---------------------------------------------------------- efectos
        box = layout.box()
        box.label(text="Apply Effect", icon='MODIFIER')
        grid = box.grid_flow(row_major=True, columns=2, even_columns=True,
                             align=True)
        for eid, label, desc, icon, _idx in EFFECT_ITEMS:
            op = grid.operator("squishyfx.apply_effect", text=label, icon=icon)
            op.effect = eid

        # ---------------------------------------------------------- presets
        row = layout.row(align=True)
        row.menu("SQUISHYFX_MT_presets", text="Presets", icon='PRESET')
        row.operator("squishyfx.rebuild_node_groups", text="", icon='FILE_REFRESH')


# ---------------------------------------------------------------------------
# Sub-panel: stack of active effects with editable parameters
# ---------------------------------------------------------------------------

class SQUISHYFX_PT_stack(Panel):
    bl_label = "Active Effects"
    bl_idname = "SQUISHYFX_PT_stack"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SquishyFX"
    bl_parent_id = "SQUISHYFX_PT_main"

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def draw(self, context):
        layout = self.layout
        obj = context.active_object

        mods = [m for m in obj.modifiers if is_squishyfx_modifier(m)]
        if not mods:
            layout.label(text="No SquishyFX effects", icon='INFO')
            return

        for mod in mods:
            box = layout.box()

            # Cabecera: expandir/colapsar, visibilidad, nombre, guardar
            # preset, remove. The expanded state lives in
            # mod.show_expanded (native to the modifier: persists in the
            # file and stays in sync with the Properties stack).
            header = box.row(align=True)
            header.prop(mod, "show_expanded", text="", emboss=False,
                        icon='TRIA_DOWN' if mod.show_expanded
                        else 'TRIA_RIGHT')
            header.prop(mod, "show_viewport", text="",
                        icon='HIDE_OFF' if mod.show_viewport else 'HIDE_ON')
            header.label(text=mod.name.replace(f"{gn.PREFIX} - ", ""),
                         icon='GEOMETRY_NODES')
            op = header.operator("squishyfx.save_preset", text="",
                                 icon='BOOKMARKS')
            op.modifier_name = mod.name
            op.preset_name = mod.name.replace(f"{gn.PREFIX} - ", "")
            op = header.operator("squishyfx.remove_effect", text="", icon='X')
            op.modifier_name = mod.name

            if not mod.show_expanded:
                continue

            # Parameters: read from the node group interface and edited as
            # modifier idprops -> the addon's property panel.
            col = box.column(align=True)
            for item in input_socket_items(mod.node_group):
                ident = item.identifier

                if item.name in ("Playing", "Energy", "Velocity", "Drag"):
                    continue  # internal: written by the addon every frame

                sock = _sock_struct(mod, ident)

                if item.name == "Mask":
                    attr = mod_get_attribute(mod, ident)
                    if attr and sock is not None:
                        row = col.row(align=True)
                        row.label(text="", icon='GROUP_VERTEX')
                        row.prop(sock, "attribute_name", text="Mask")
                    elif attr:
                        row = col.row(align=True)
                        row.label(text="", icon='GROUP_VERTEX')
                        row.prop(mod, f'["{ident}_attribute_name"]',
                                 text="Mask")
                    else:
                        col.label(text="Mask: (whole mesh)",
                                  icon='GROUP_VERTEX')
                    continue

                if sock is not None:  # API 5.2+
                    try:
                        col.prop(sock, "value", text=item.name)
                    except Exception:
                        value = getattr(sock, "value", None)
                        name = getattr(value, "name", str(value))
                        col.label(text=f"{item.name}: {name}")
                    continue

                # API 4.x / 5.1: idprops on the modifier
                try:
                    if ident not in mod.keys():
                        continue
                    col.prop(mod, f'["{ident}"]', text=item.name)
                except TypeError:
                    continue
                except Exception:
                    value = mod.get(ident)
                    name = getattr(value, "name", str(value))
                    col.label(text=f"{item.name}: {name}")


# ---------------------------------------------------------------------------
# Sub-panel: bake a Shape Keys
# ---------------------------------------------------------------------------

class SQUISHYFX_PT_bake(Panel):
    bl_label = "Bake to Shape Keys"
    bl_idname = "SQUISHYFX_PT_bake"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "SquishyFX"
    bl_parent_id = "SQUISHYFX_PT_main"
    bl_options = {'DEFAULT_CLOSED'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def draw(self, context):
        layout = self.layout
        props = context.scene.squishyfx

        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(props, "bake_start")
        row.prop(props, "bake_end")
        col.prop(props, "bake_step")
        col.prop(props, "bake_disable_after")

        layout.operator("squishyfx.bake_shapekeys",
                        icon='SHAPEKEY_DATA')
        layout.operator("squishyfx.bake_current_frame",
                        text="Bake Current Frame", icon='KEYFRAME')
        layout.label(text="Ripple is enabled only during the bake",
                     icon='INFO')


# ---------------------------------------------------------------------------
# Registro
# ---------------------------------------------------------------------------

classes = (
    SQUISHYFX_MT_presets,
    SQUISHYFX_MT_delete_preset,
    SQUISHYFX_PT_main,
    SQUISHYFX_PT_stack,
    SQUISHYFX_PT_bake,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
