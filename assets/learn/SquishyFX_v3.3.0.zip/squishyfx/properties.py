# -*- coding: utf-8 -*-
"""
SquishyFX - properties.py
PropertyGroup holding the addon's global settings (stored in the Scene).
"""

import bpy
from bpy.props import (
    StringProperty,
    IntProperty,
    BoolProperty,
    PointerProperty,
)


class SQUISHYFX_Props(bpy.types.PropertyGroup):
    """Addon settings stored in context.scene.squishyfx."""

    vertex_group: StringProperty(
        name="Vertex Group",
        description=(
            "Vertex Group used as the effect mask "
            "(weight = local intensity). Looked up on the active object"
        ),
        default="",
    )

    # ------------------------------------------------------------------ bake
    bake_start: IntProperty(
        name="Start",
        description="First frame of the Shape Key bake",
        default=1,
    )

    bake_end: IntProperty(
        name="End",
        description="Last frame of the Shape Key bake",
        default=100,
    )

    bake_step: IntProperty(
        name="Step",
        description="Create a Shape Key every N frames (1 = every frame)",
        default=1,
        min=1,
        max=25,
    )

    bake_disable_after: BoolProperty(
        name="Disable Modifiers After Bake",
        description=(
            "After baking, disable the SquishyFX modifiers in viewport and "
            "render so the animation lives only in the Shape Keys"
        ),
        default=True,
    )


def register():
    bpy.utils.register_class(SQUISHYFX_Props)
    bpy.types.Scene.squishyfx = PointerProperty(type=SQUISHYFX_Props)


def unregister():
    del bpy.types.Scene.squishyfx
    bpy.utils.unregister_class(SQUISHYFX_Props)
