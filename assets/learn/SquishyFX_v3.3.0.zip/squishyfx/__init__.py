# -*- coding: utf-8 -*-
"""
SquishyFX - Non-destructive soft-body system built on Geometry Nodes.

Applies squish, ripple, squish-inflate and soft-body effects using the
selected Vertex Group as an intensity mask. Each effect creates its own
stackable Geometry Nodes modifier, with every parameter exposed in the
addon panel.

Installation:
  Edit > Preferences > Add-ons > Install... > pick the .zip
  (or copy the 'squishyfx' folder into scripts/addons).
"""

bl_info = {
    "name": "SquishyFX",
    "author": "Bann0rTheFag",
    # 3.0.0, not 2.9.x: the 2.9.x line already existed (zips of the variant
    # without Penetration, later reverted); reusing it would confuse zips.
    "version": (3, 3, 0),
    "blender": (4, 2, 0),  # probado en 5.1
    "location": "3D Viewport > Sidebar (N) > SquishyFX",
    "description": ("Collision-reactive soft body with Geometry Nodes: "
                    "the mesh deforms only where an object with "
                    "Collision touches it. Squish, Ripple, Squish & Inflate, "
                    "Fat Jiggle, Penetration and Squish Organic (per-zone "
                    "stiffness + squash & stretch), masked by Vertex "
                    "Group"),
    "warning": "",
    "doc_url": "",
    "category": "Object",
}

# ---------------------------------------------------------------------------
# Reload support (F8 / Reload Scripts)
# ---------------------------------------------------------------------------

if "bpy" in locals():
    import importlib
    importlib.reload(geometry_nodes)
    importlib.reload(presets)
    importlib.reload(properties)
    importlib.reload(operators)
    importlib.reload(ui)
else:
    from . import geometry_nodes
    from . import presets
    from . import properties
    from . import operators
    from . import ui

import bpy  # noqa: E402  (after the reload block, standard pattern)


# ---------------------------------------------------------------------------
# Registro
# ---------------------------------------------------------------------------

_modules = (properties, operators, ui)


def register():
    for module in _modules:
        module.register()


def unregister():
    for module in reversed(_modules):
        module.unregister()


if __name__ == "__main__":
    register()
