# -*- coding: utf-8 -*-
"""
SquishyFX - geometry_nodes.py  (v2.0 — contacto stateless por Raycast)

Arquitectura aprendida del setup "Squish" de referencia:
  * SIN Simulation Zones en Squish / Squish & Inflate / Ripple:
    la deformación se calcula en cada evaluación del depsgraph, así que
    SE VE EN VIVO al mover el colisionador, sin reproducir el timeline,
    y la malla mantiene su forma original exacta hasta que hay contacto.
  * Test de interior por Raycast: rayo desde el punto a lo largo de +Normal;
    si golpea una cara del colisionador cuya normal apunta en el mismo
    sentido (dot > 0) el rayo salió por una cara trasera -> el punto está
    DENTRO del colisionador.
  * Conformado: un segundo rayo a lo largo de -Normal encuentra la
    superficie del colisionador por la que entró; el punto se recoloca
    sobre ella (+ Collision Offset), envolviendo al colisionador.
  * Spread: el módulo del desplazamiento se difunde con Blur Attribute
    (Capture Attribute para transportarlo entre etapas).
  * Volumen: Attribute Statistic mide la compresión total y la convierte
    en abultamiento/inflado a lo largo de la normal.
  * Corrective Smooth: suavizado de posiciones (Blur de Position mezclado
    solo en la zona afectada) para eliminar escalones del raycast.
  * El Ripple lleva un gate de reproducción: en el viewport solo se
    previsualiza mientras el timeline está en Play (flag "Playing" escrito
    por handlers del addon); en render siempre está activo (Is Viewport).

Escrito contra la API de Blender 5.1 (interface.new_socket,
capture_items, Blur Attribute, Raycast).
"""

import bpy

PREFIX = "SquishyFX"

NAME_SQUISH = f"{PREFIX} Squish"
NAME_RIPPLE = f"{PREFIX} Ripple"
NAME_SQUISH_INFLATE = f"{PREFIX} Squish & Inflate"
NAME_JIGGLE = f"{PREFIX} Fat Jiggle"
NAME_PENETRATION = f"{PREFIX} Penetration"
NAME_SQUISH_ORGANIC = f"{PREFIX} Squish Organic"

# Árboles retirados que rebuild_all_trees purga si quedan sin usuarios
LEGACY_TREES = (f"{PREFIX} Soft Body",)

# Efectos cuyo preview en viewport se gatea a la reproducción del timeline.
# Penetration está aquí SOLO para que el addon le escriba los flags Playing
# y Energy (pulso de contracción + jiggle). Su conform base es EN VIVO: la
# apertura/cierre y el agarre se ven al mover el penetrador sin reproducir;
# únicamente el pulso oscilante y el jiggle secundario esperan al Play.
# Squish Organic: su conform de contacto es EN VIVO; el addon le escribe
# Playing, Energy y además Velocity (squash & stretch por velocidad del
# centroide de la máscara — solo tiene sentido con el timeline avanzando).
PLAY_GATED_TREES = (NAME_RIPPLE, NAME_JIGGLE, NAME_PENETRATION,
                    NAME_SQUISH_ORGANIC)


_VALUE_OPS = {'DOT_PRODUCT', 'LENGTH', 'DISTANCE'}
RAY_LENGTH = 1000.0

# Profundidad máxima de penetración reconocida contra la PROPIA malla
# (hits del colisionador etiquetados "squishyfx_self"). La geometría self
# es un casco abierto: un rayo puede colarse por el agujero de la máscara
# y golpear una cara trasera lejana (falso "dentro"); la penetración real
# carne-contra-cuerpo sale por la pared cercana. 10 cm cubre cualquier
# aplastamiento razonable y descarta los cruces de cavidad (15-30 cm).
SELF_RANGE = 0.10

# Sello de versión de la ESTRUCTURA de los árboles. Súbelo cada vez que
# cambien los node groups (sockets, modelo de deformación...). Cada árbol
# se marca al construirse; get_or_create_tree / apply_effect lo comparan
# para detectar árboles obsoletos. Sin esto, un Ctrl+Z que cruce un
# rebuild resucita los árboles viejos del archivo y el botón de aplicar
# los REUTILIZA en silencio: pasó de verdad — "Squish" se construyó nuevo
# (no existía en el archivo) y funcionaba, mientras "Squish & Inflate"
# resucitó con el modelo antiguo y reproducía el defecto ya corregido.
# 40, no 20: la línea archivada v2.9.x ya usó el 20 (y líneas antiguas
# llegaron al 33). tree_is_stale compara por IGUALDAD: un .blend guardado
# con aquella v2.9.1 tendría árboles sellados "20" de OTRA estructura y
# pasarían por frescos. 40 está por encima de toda línea histórica.
TREE_VERSION = 43


def tree_is_stale(nt):
    """True si el árbol fue construido por una versión distinta del addon."""
    return nt is None or nt.get("squishyfx_tree_version") != TREE_VERSION


# ---------------------------------------------------------------------------
# Helpers de bajo nivel
# ---------------------------------------------------------------------------

def _plug(nt, dst_socket, src):
    if isinstance(src, bpy.types.NodeSocket):
        nt.links.new(src, dst_socket)
    elif src is not None:
        dst_socket.default_value = src


def _node(nt, type_id, loc=(0, 0), **props):
    node = nt.nodes.new(type_id)
    node.location = loc
    for key, value in props.items():
        setattr(node, key, value)
    return node


def _input(node, *names):
    """Primer input existente entre varios nombres (robustez entre versiones)."""
    for nm in names:
        s = node.inputs.get(nm)
        if s is not None:
            return s
    raise KeyError(f"{node.bl_idname}: no existe ninguno de {names}")


def _math(nt, op, a, b=None, loc=(0, 0), label=""):
    n = _node(nt, 'ShaderNodeMath', loc, operation=op)
    if label:
        n.label = label
    _plug(nt, n.inputs[0], a)
    if b is not None:
        _plug(nt, n.inputs[1], b)
    return n.outputs[0]


def _vmath(nt, op, a, b=None, scale=None, loc=(0, 0), label=""):
    n = _node(nt, 'ShaderNodeVectorMath', loc, operation=op)
    if label:
        n.label = label
    _plug(nt, n.inputs[0], a)
    if b is not None:
        _plug(nt, n.inputs[1], b)
    if scale is not None:
        _plug(nt, n.inputs[3], scale)
    if op in _VALUE_OPS:
        return n.outputs["Value"]
    return n.outputs["Vector"]



def _compare(nt, data_type, op, a, b, loc=(0, 0)):
    n = _node(nt, 'FunctionNodeCompare', loc, data_type=data_type, operation=op)
    enabled = [s for s in n.inputs if s.enabled]
    _plug(nt, enabled[0], a)
    _plug(nt, enabled[1], b)
    return n.outputs["Result"]


def _switch(nt, input_type, condition, false_val, true_val, loc=(0, 0)):
    n = _node(nt, 'GeometryNodeSwitch', loc, input_type=input_type)
    _plug(nt, n.inputs["Switch"], condition)
    _plug(nt, n.inputs["False"], false_val)
    _plug(nt, n.inputs["True"], true_val)
    return n.outputs[0]


def _bool(nt, op, a, b, loc=(0, 0)):
    n = _node(nt, 'FunctionNodeBooleanMath', loc, operation=op)
    _plug(nt, n.inputs[0], a)
    _plug(nt, n.inputs[1], b)
    return n.outputs[0]


def _blur(nt, value, data_type, iterations, weight, loc=(0, 0)):
    """iterations y weight aceptan valor o socket."""
    n = _node(nt, 'GeometryNodeBlurAttribute', loc, data_type=data_type)
    _plug(nt, n.inputs["Value"], value)
    _plug(nt, n.inputs["Iterations"], iterations)
    _plug(nt, n.inputs["Weight"], weight)
    return n.outputs["Value"]


def _mesh_density_factor(nt, geometry, loc=(0, 0)):
    """Factor de compensación de densidad para los Blur Attribute.

    Los blurs difunden por ANILLOS topológicos: en una malla densa el
    mismo número de iteraciones cubre milímetros en vez de centímetros y
    el suavizado colapsa (costuras afiladas, crestas espigadas). Se mide
    la arista media de la malla de entrada y se devuelve

        factor = clamp(ARISTA_REF / arista_media, 1, 6)

    con ARISTA_REF = 8 mm (densidad a la que se afinaron los valores por
    defecto). En mallas iguales o más gruesas el factor es 1: los sliders
    se comportan exactamente como siempre.
    """
    x, y = loc
    ev = _node(nt, 'GeometryNodeInputMeshEdgeVertices', (x, y))
    elen = _vmath(nt, 'DISTANCE', ev.outputs["Position 1"],
                  ev.outputs["Position 2"], loc=(x + 180, y))
    stat = _node(nt, 'GeometryNodeAttributeStatistic', (x + 360, y),
                 data_type='FLOAT', domain='EDGE')
    _plug(nt, stat.inputs["Geometry"], geometry)
    _plug(nt, _input(stat, "Attribute"), elen)
    mean_e = _math(nt, 'MAXIMUM', stat.outputs["Mean"], 1e-5,
                   (x + 560, y), "Arista media")
    return _math(nt, 'MINIMUM',
                 _math(nt, 'MAXIMUM',
                       _math(nt, 'DIVIDE', 0.008, mean_e, (x + 740, y)),
                       1.0, (x + 920, y)),
                 6.0, (x + 1100, y), "Factor densidad")


def _scaled_iters(nt, iterations, factor, loc=(0, 0)):
    """Iteraciones de Blur escaladas por densidad (tope 400), como INT.

    El Blur Attribute es DIFUSIÓN: cada iteración promedia con los vecinos
    inmediatos, así que el radio en espacio-mundo crece con la RAÍZ del
    número de iteraciones, no linealmente:

        radio ≈ arista · sqrt(iteraciones)

    Para mantener el radio constante cuando la arista se divide por k hay
    que multiplicar las iteraciones por k², no por k. Escalar linealmente
    dejaba el radio a la mitad a Subsurf 2 (28.3 mm → 13.7 mm medidos), y
    ese suavizado insuficiente es lo que afilaba la costura del contacto y
    duplicaba los picos (171 mm → 344 mm). Con factor² el radio queda en
    ARISTA_REF · sqrt(slider) para toda malla más fina que la referencia.
    """
    x, y = loc
    f2 = _math(nt, 'MULTIPLY', factor, factor, (x - 180, y), "Factor²")
    scaled = _math(nt, 'MINIMUM',
                   _math(nt, 'MULTIPLY', iterations, f2, (x, y)),
                   400.0, (x + 180, y))
    f2i = _node(nt, 'FunctionNodeFloatToInt', (x + 360, y))
    f2i.rounding_mode = 'ROUND'
    _plug(nt, f2i.inputs["Float"], scaled)
    return f2i.outputs["Integer"]


def _capture(nt, geometry, value, socket_type='FLOAT', loc=(0, 0)):
    """Capture Attribute (API 4.2+/5.x con capture_items).
    Devuelve (geometry_out, value_out)."""
    n = _node(nt, 'GeometryNodeCaptureAttribute', loc, domain='POINT')
    try:
        item = n.capture_items.new(socket_type, "Value")
    except (TypeError, RuntimeError):
        alt = {'FLOAT_VECTOR': 'VECTOR', 'VECTOR': 'FLOAT_VECTOR'}.get(
            socket_type, socket_type)
        item = n.capture_items.new(alt, "Value")
    _plug(nt, n.inputs["Geometry"], geometry)
    _plug(nt, n.inputs[item.name], value)
    return n.outputs["Geometry"], n.outputs[item.name]







def _set_position(nt, geometry, loc=(0, 0), position=None, offset=None):
    n = _node(nt, 'GeometryNodeSetPosition', loc)
    _plug(nt, n.inputs["Geometry"], geometry)
    if position is not None:
        _plug(nt, n.inputs["Position"], position)
    if offset is not None:
        _plug(nt, n.inputs["Offset"], offset)
    return n.outputs["Geometry"]


def _clamp01(nt, value, loc=(0, 0)):
    return _math(nt, 'MAXIMUM',
                 _math(nt, 'MINIMUM', value, 1.0, loc), 0.0,
                 (loc[0] + 150, loc[1]))


def _sock(nt, name, in_out='INPUT', stype='NodeSocketFloat',
          default=None, minv=None, maxv=None, subtype=None, desc=""):
    s = nt.interface.new_socket(name=name, in_out=in_out,
                                socket_type=stype, description=desc)
    try:
        if subtype is not None:
            s.subtype = subtype
        if default is not None:
            s.default_value = default
        if minv is not None:
            s.min_value = minv
        if maxv is not None:
            s.max_value = maxv
    except (AttributeError, TypeError):
        pass
    return s


def _base_tree(name):
    nt = bpy.data.node_groups.new(name, 'GeometryNodeTree')
    nt["squishyfx_tree_version"] = TREE_VERSION
    _sock(nt, "Geometry", 'INPUT', 'NodeSocketGeometry')
    gi = _node(nt, 'NodeGroupInput', (-2400, 0))
    go = _node(nt, 'NodeGroupOutput', (2600, 0))
    return nt, gi, go


def _finish_tree(nt, go, last_geo):
    _sock(nt, "Geometry", 'OUTPUT', 'NodeSocketGeometry')
    nt.links.new(last_geo, go.inputs["Geometry"])
    return nt


# ---------------------------------------------------------------------------
# Bloques compartidos: colisionadores y contacto por raycast
# ---------------------------------------------------------------------------

def _collider_sockets(nt):
    _sock(nt, "Collision Object", 'INPUT', 'NodeSocketObject', None, None,
          None, None, "Extra single collider object (optional)")
    _sock(nt, "Collision Collection", 'INPUT', 'NodeSocketCollection', None,
          None, None, None,
          "Collection holding the colliders (the addon fills it with the "
          "objects that have Collision physics)")


def _self_collision_sock(nt):
    """Socket "Self Collision" — SIEMPRE el último que se crea en el árbol.

    Misma regla de oro que Splay: los identificadores Socket_N se asignan
    por orden de creación y los modifiers guardados los referencian;
    insertar un socket en medio desplaza el significado de los
    posteriores y corrompe los archivos al recargar (crash medido con
    Object Info). Añadir sockets SOLO al final.
    """
    return _sock(nt, "Self Collision", 'INPUT', 'NodeSocketBool', False,
                 None, None, None,
                 "The rigid part of the mesh itself (mask weight ~ 0) "
                 "also acts as a collider: the masked flesh "
                 "hits the rest of the body instead of passing through it. "
                 "It does not detect flesh-vs-flesh (two deformable zones "
                 "against each other)")


def _collider_geometry(nt, gi, loc=(-2100, 800)):
    x, y = loc
    oi = _node(nt, 'GeometryNodeObjectInfo', (x, y), transform_space='RELATIVE')
    _plug(nt, oi.inputs["Object"], gi.outputs["Collision Object"])

    ci = _node(nt, 'GeometryNodeCollectionInfo', (x, y - 200),
               transform_space='RELATIVE')
    _plug(nt, ci.inputs["Collection"], gi.outputs["Collision Collection"])
    real = _node(nt, 'GeometryNodeRealizeInstances', (x + 200, y - 200))
    _plug(nt, real.inputs["Geometry"], ci.outputs["Instances"])

    # Self collision: la parte RÍGIDA de la propia malla (máscara ≈ 0) se
    # une al colisionador. El umbral por CARA (media de sus esquinas
    # < 0.005 — la evaluación FACE de un atributo de punto interpola al
    # promedio) deja un margen sin colisionador junto a la frontera de
    # la máscara, evitando falsos "dentro" en la costura. La zona deformable
    # nunca se incluye a sí misma, así que no hay retroalimentación; el
    # Switch es perezoso: apagado, no cuesta nada.
    #
    # La geometría self se ETIQUETA (atributo "squishyfx_self" = 1): el
    # cuerpo separado por la máscara es un casco ABIERTO, y el test de
    # interior por rayo puede colarse por el agujero de la máscara,
    # atravesar el interior del torso y golpear una cara trasera LEJANA →
    # falso "dentro" en reposo (medido: 68.7 mm de deformación fantasma
    # en el escote sin ningún colisionador cerca). Una penetración real
    # en el propio cuerpo sale por la pared cercana (< SELF_RANGE); los
    # tests de interior descartan hits self más lejanos. Los
    # colisionadores objeto no llevan la marca y conservan alcance total.
    sep = _node(nt, 'GeometryNodeSeparateGeometry', (x, y - 420),
                domain='FACE')
    _plug(nt, sep.inputs["Geometry"], gi.outputs["Geometry"])
    _plug(nt, _input(sep, "Selection"),
          _compare(nt, 'FLOAT', 'LESS_THAN', gi.outputs["Mask"], 0.005,
                   (x - 200, y - 420)))
    tag = _node(nt, 'GeometryNodeStoreNamedAttribute', (x + 200, y - 420),
                data_type='FLOAT', domain='FACE')
    _plug(nt, tag.inputs["Geometry"], sep.outputs["Selection"])
    _plug(nt, _input(tag, "Name"), "squishyfx_self")
    _plug(nt, _input(tag, "Value"), 1.0)
    self_geo = _switch(nt, 'GEOMETRY', gi.outputs["Self Collision"],
                       None, tag.outputs["Geometry"], (x + 400, y - 420))

    # Devuelve (completo, solo_objetos). Ripple/Fat Jiggle anclan la FASE y
    # el DECAY de sus ondas a la distancia al colisionador — contra el join
    # completo con Self Collision activo esa distancia es ~0 en toda la
    # zona enmascarada (el propio cuerpo está a un paso) y el falloff
    # colapsa. Las ondas miden contra solo_objetos; el conformado de la
    # huella usa el completo.
    join_obj = _node(nt, 'GeometryNodeJoinGeometry', (x + 420, y - 100))
    nt.links.new(oi.outputs["Geometry"], join_obj.inputs["Geometry"])
    nt.links.new(real.outputs["Geometry"], join_obj.inputs["Geometry"])
    join_full = _node(nt, 'GeometryNodeJoinGeometry', (x + 640, y - 160))
    nt.links.new(join_obj.outputs["Geometry"], join_full.inputs["Geometry"])
    nt.links.new(self_geo, join_full.inputs["Geometry"])
    return join_full.outputs["Geometry"], join_obj.outputs["Geometry"]


def _raycast(nt, target, source, direction, loc=(0, 0)):
    n = _node(nt, 'GeometryNodeRaycast', loc)
    _plug(nt, _input(n, "Target Geometry", "Target"), target)
    _plug(nt, _input(n, "Source Position"), source)
    _plug(nt, _input(n, "Ray Direction"), direction)
    _plug(nt, _input(n, "Ray Length"), RAY_LENGTH)
    return n


def _surrounded_veto(nt, collider, pos, nrm, loc=(0, 0)):
    """Factor 0/1: ¿el rayo OPUESTO (-Normal) también intersecta el
    colisionador?

    Un vértice de verdad dentro de un volumen está RODEADO: cualquier
    rayo desde él lo cruza, en particular el opuesto al de detección. Un
    falso positivo del test de cara trasera no lo está — medido con una
    esfera de escala NEGATIVA (espejo triple: la geometría queda del
    revés en espacio mundo y su cara cercana se lee como trasera), cada
    vértice cuya normal apuntaba a la esfera "estaba dentro" y salían
    picos de carne disparados hacia ella. El rayo opuesto de esos
    vértices no toca la esfera → veto. Independiente de la orientación
    de las normales del colisionador, así que también cubre mallas
    espejadas legítimas usadas como colisionador.
    """
    x, y = loc
    ray_b = _raycast(nt, collider, pos,
                     _vmath(nt, 'SCALE', nrm, scale=-1.0, loc=(x, y)),
                     (x + 180, y))
    return _switch(nt, 'FLOAT', ray_b.outputs["Is Hit"], 0.0, 1.0,
                   (x + 400, y))


def _self_range_ok(nt, ray, loc=(0, 0)):
    """Factor 0/1 que anula los falsos 'dentro' contra la propia malla.

    Conecta el atributo "squishyfx_self" al Raycast dado y devuelve 1
    salvo cuando el hit es geometría self a más de SELF_RANGE (un rayo
    que se coló por el agujero de la máscara y cruzó la cavidad del
    cuerpo). Los colisionadores objeto no llevan la marca (el atributo
    lee 0 en ellos) y conservan alcance completo.

    NOTA (auditado 2026-07-20): se probó y REVIRTIÓ un guard extra de
    "entrada" (exigir salida trasera cercana por -Normal a los hits
    self). Un empuje de 50 mm que parecía fantasma resultó ser CONTACTO
    REAL (la mano de la propia malla solapando el seno, verificado por
    BVH); el guard no cambiaba nada medible y añadía un raycast y
    riesgo en ángulos rasantes. No re-añadir sin un fantasma medido.
    """
    x, y = loc
    na = _node(nt, 'GeometryNodeInputNamedAttribute', (x, y),
               data_type='FLOAT')
    _plug(nt, _input(na, "Name"), "squishyfx_self")
    _plug(nt, ray.inputs["Attribute"], na.outputs["Attribute"])
    far = _compare(nt, 'FLOAT', 'GREATER_THAN',
                   ray.outputs["Hit Distance"], SELF_RANGE, (x + 180, y))
    self_far = _math(nt, 'MULTIPLY', ray.outputs["Attribute"], far,
                     (x + 360, y))
    return _math(nt, 'SUBTRACT', 1.0, self_far, (x + 540, y),
                 "Rango self OK")


AXIS_PROBE = (0.5774, 0.5774, 0.5774)


def _inside_axis(nt, collider, pos, loc=(0, 0)):
    """Interior por DOBLE rayo de direccion fija (tecnica del setup Softie).

    El test por la NORMAL del vertice falla cuando esa normal es rasante al
    colisionador o cuando el primer impacto es la cara frontal de OTRO
    colisionador: el punto hundido no se detecta y la carne queda
    atravesada (medido en esta escena: 715 vertices dentro del cubo con
    deformacion 0.000 mm). Aqui el rayo no depende de la normal.
    """
    x, y = loc
    vp = _node(nt, 'FunctionNodeInputVector', (x, y))
    vp.vector = AXIS_PROBE
    vm = _node(nt, 'FunctionNodeInputVector', (x, y - 220))
    vm.vector = (-AXIS_PROBE[0], -AXIS_PROBE[1], -AXIS_PROBE[2])

    def leg(vec_node, yy):
        ray = _raycast(nt, collider, pos, vec_node.outputs["Vector"],
                       (x + 200, yy))
        back = _compare(nt, 'FLOAT', 'GREATER_THAN',
                        _vmath(nt, 'DOT_PRODUCT', ray.outputs["Hit Normal"],
                               vec_node.outputs["Vector"], loc=(x + 400, yy)),
                        0.0, (x + 580, yy))
        return _math(nt, 'MULTIPLY',
                     _switch(nt, 'FLOAT', ray.outputs["Is Hit"], 0.0, 1.0,
                             (x + 760, yy + 120)),
                     _switch(nt, 'FLOAT', back, 0.0, 1.0, (x + 760, yy)),
                     (x + 940, yy))

    return _math(nt, 'MAXIMUM', leg(vp, y), leg(vm, y - 220),
                 (x + 1120, y - 110), "Inside (fixed dual ray)")


def _contact_conform(nt, collider, pos, nrm, offset, deep=None, gate_iters=None,
                     loc=(0, 0)):
    """Conformado de contacto robusto a geometría protuberante.

    - INTERIOR: raycast +Normal; si el primer impacto es una cara trasera
      del colisionador, el punto está dentro (colisionadores cerrados).
    - OBJETIVO: Geometry Proximity — el punto MÁS CERCANO de la
      superficie del colisionador. Es la dirección de escape mínima y no
      depende de la orientación de la normal: en volúmenes protuberantes
      (pechos, vientres) el rayo -Normal podía salir por la cara opuesta
      del colisionador y teletransportar el vértice al otro lado.

      OJO: "el punto más cercano no puede teletransportar por
      construcción" era FALSO. En cuanto la penetración supera el
      SEMIGROSOR del colisionador, la cara opuesta pasa a ser la más
      próxima y la carne sale por ella (medido: 147 vértices extruidos por
      la cara frontal de un cubo de 18.7 cm con 12.7 cm de penetración;
      el fallo arranca justo en 9.36 cm). Ese caso lo cubre `deep`.

    - `deep` (socket 0..1, OPCIONAL): guardián de cruce. Con deep>0.5, un
      escape que avanza A FAVOR de la normal del vértice se reinterpreta
      como cruce y se sustituye por la salida del lado de ENTRADA (rayo
      -Normal). Sube el coste y NO es gratis: un vértice lateral cuya
      normal apunta de lado puede escapar legítimamente a favor de ella,
      y ahí el guardián invierte la dirección (medido en glúteos: 2063
      vértices alterados, hasta 90 mm). Por eso va a 0 por defecto y solo
      debe activarse en el caso patológico. deep=None -> guardián ausente
      del árbol (Ripple/Fat Jiggle, que no exponen el socket).

    - PIEL con RAMPA por penetración real p = |más_cercano - pos|:
      eff = offset · min(p / (2·offset), 1); rasante -> 0 (sin adhesión),
      presión firme -> piel completa anti-clipping.

    Devuelve (conform, inside, penetración).
    """
    x, y = loc

    ray_a = _node(nt, 'GeometryNodeRaycast', (x, y), data_type='FLOAT')
    _plug(nt, ray_a.inputs["Target Geometry"], collider)
    _plug(nt, ray_a.inputs["Source Position"], pos)
    _plug(nt, ray_a.inputs["Ray Direction"], nrm)
    _plug(nt, ray_a.inputs["Ray Length"], RAY_LENGTH)
    facing = _vmath(nt, 'DOT_PRODUCT', ray_a.outputs["Hit Normal"], nrm,
                    loc=(x + 220, y - 40))
    inside = _math(nt, 'MULTIPLY',
                   _switch(nt, 'FLOAT', ray_a.outputs["Is Hit"], 0.0, 1.0,
                           (x + 220, y + 130)),
                   _switch(nt, 'FLOAT',
                           _compare(nt, 'FLOAT', 'GREATER_THAN', facing, 0.0,
                                    (x + 400, y - 40)),
                           0.0, 1.0, (x + 580, y - 40)),
                   (x + 760, y + 60), "Dentro (rayo normal)")

    inside = _math(nt, 'MAXIMUM', inside,
                   _inside_axis(nt, collider, pos, (x - 400, y + 900)),
                   (x + 940, y + 200), "Inside collider")
    inside = _math(nt, 'MULTIPLY', inside,
                   _self_range_ok(nt, ray_a, (x + 220, y + 260)),
                   (x + 940, y + 60))
    inside = _math(nt, 'MULTIPLY', inside,
                   _surrounded_veto(nt, collider, pos, nrm,
                                    (x + 220, y + 420)),
                   (x + 1120, y + 60))

    # Gate binario per-vértice: en una arista/punta afilada del colisionador
    # el test de interior parpadea de vértice a vértice y deja un borde de
    # contacto DENTADO con púas. Difuminar el gate unos anillos lo convierte
    # en una rampa 1->0 suave: el interior PROFUNDO (gate 1 rodeado de 1)
    # conserva empuje completo -> garantía intacta; solo el borde se atenúa.
    if gate_iters is not None:
        inside = _blur(nt, inside, 'FLOAT', gate_iters, 1.0,
                       (x + 1300, y + 60))

    prox = _node(nt, 'GeometryNodeProximity', (x + 220, y - 300),
                 target_element='FACES')
    _plug(nt, prox.inputs["Target"], collider)
    _plug(nt, _input(prox, "Sample Position"), pos)
    closest = prox.outputs["Position"]

    # --- Guardián de cruce, opt-in vía socket "Deep Contact" (v2.4.5) ----
    if deep is not None:
        esc_raw = _vmath(nt, 'SUBTRACT', closest, pos, loc=(x + 420, y - 300))
        outward = _vmath(nt, 'DOT_PRODUCT',
                         _vmath(nt, 'NORMALIZE', esc_raw,
                                loc=(x + 600, y - 380)),
                         nrm, loc=(x + 780, y - 380),
                         label="Escapes along the normal?")
        ray_b = _raycast(nt, collider, pos,
                         _vmath(nt, 'SCALE', nrm, scale=-1.0,
                                loc=(x + 220, y - 640)), (x + 420, y - 640))
        crossing = _bool(nt, 'AND',
                         _bool(nt, 'AND',
                               _compare(nt, 'FLOAT', 'GREATER_THAN', outward,
                                        0.0, (x + 960, y - 380)),
                               ray_b.outputs["Is Hit"], (x + 1140, y - 420)),
                         _compare(nt, 'FLOAT', 'GREATER_THAN', deep, 0.5,
                                  (x + 960, y - 500)),
                         (x + 1320, y - 460), )
        closest = _switch(nt, 'VECTOR', crossing, closest,
                          ray_b.outputs["Hit Position"], (x + 1500, y - 380))
        esc_raw = _vmath(nt, 'SUBTRACT', closest, pos, loc=(x + 1680, y - 300))
        pen = _vmath(nt, 'LENGTH', esc_raw, loc=(x + 1860, y - 340))
        escape = _vmath(nt, 'NORMALIZE', esc_raw,
                        loc=(x + 1860, y - 300), label="Escape direction")
    else:
        pen = prox.outputs["Distance"]
        escape = _vmath(nt, 'NORMALIZE',
                        _vmath(nt, 'SUBTRACT', closest, pos,
                               loc=(x + 420, y - 300)),
                        loc=(x + 600, y - 300), label="Escape direction")

    # Piel con rampa por penetración (v2.4.2), ahora con la p real
    ramp = _math(nt, 'MINIMUM',
                 _math(nt, 'DIVIDE', pen,
                       _math(nt, 'ADD',
                             _math(nt, 'MULTIPLY', offset, 2.0,
                                   (x + 200, y - 520)),
                             1e-5, (x + 380, y - 520)),
                       (x + 560, y - 520)),
                 1.0, (x + 740, y - 520), "Skin ramp")
    eff_offset = _math(nt, 'MULTIPLY', offset, ramp, (x + 920, y - 520))

    target = _vmath(nt, 'ADD', closest,
                    _vmath(nt, 'SCALE', escape, scale=eff_offset,
                           loc=(x + 780, y - 300)),
                    loc=(x + 960, y - 260))
    conform_raw = _vmath(nt, 'SUBTRACT', target, pos, loc=(x + 1140, y - 200))
    conform = _vmath(nt, 'SCALE', conform_raw, scale=inside,
                     loc=(x + 1320, y - 140), label="Conformado")
    return conform, inside, pen


def _flesh_conform(nt, gi, collider, pos, nrm, offset, splay, loc=(0, 0)):
    """Conformado de CARNE: aplanado direccional + derrame lateral (v2.5).

    El conform clásico (proyectar al punto más cercano del colisionador)
    nunca parece carne: succiona los vértices hacia la superficie, estampa
    la silueta del colisionador y pellizca crestas en sus aristas. La
    carne real hace dos cosas cuando algo la presiona:

      1. APLANARSE contra la cara que empuja. El eje de empuje `a` se
         estima como la normal media de la zona de contacto (ponderada
         por inside·Mask) invertida — la dirección en la que el
         colisionador comprime. Escape: raycast desde el vértice a lo
         largo de `a` hasta la cara de presión.
      2. DERRAMARSE lateralmente. Escape radial perpendicular a `a`,
         alejándose del eje del contacto, saliendo por los flancos del
         colisionador — el rebose característico alrededor del objeto.

    Cada vértice mezcla ambos escapes con un smooth-min sesgado por
    `splay` (0 = solo aplanar, 1 = solo derramar): gana el camino corto
    con transición continua. El campo de direcciones es suave en toda la
    malla (a es constante por contacto; el radial solo degenera en el eje,
    medida cero, y ahí cae al aplanado), así que no hay eje medial, no hay
    teletransporte al lado opuesto y la profundidad de penetración no
    tiene umbral patológico — los tres defectos medidos del modelo por
    proximidad quedan fuera por construcción.

    Devuelve (conform, inside, penetración).
    """
    x, y = loc

    # Inside collider: rayo +Normal golpea una cara trasera.
    ray_in = _node(nt, 'GeometryNodeRaycast', (x, y), data_type='FLOAT')
    _plug(nt, ray_in.inputs["Target Geometry"], collider)
    _plug(nt, ray_in.inputs["Source Position"], pos)
    _plug(nt, ray_in.inputs["Ray Direction"], nrm)
    _plug(nt, ray_in.inputs["Ray Length"], RAY_LENGTH)
    facing = _vmath(nt, 'DOT_PRODUCT', ray_in.outputs["Hit Normal"], nrm,
                    loc=(x + 200, y - 40))
    inside = _math(nt, 'MULTIPLY',
                   _switch(nt, 'FLOAT', ray_in.outputs["Is Hit"], 0.0, 1.0,
                           (x + 200, y + 130)),
                   _switch(nt, 'FLOAT',
                           _compare(nt, 'FLOAT', 'GREATER_THAN', facing, 0.0,
                                    (x + 380, y - 40)),
                           0.0, 1.0, (x + 560, y - 40)),
                   (x + 740, y + 60), "Inside collider")
    inside = _math(nt, 'MULTIPLY', inside,
                   _self_range_ok(nt, ray_in, (x + 200, y + 260)),
                   (x + 920, y + 60))
    inside = _math(nt, 'MULTIPLY', inside,
                   _surrounded_veto(nt, collider, pos, nrm,
                                    (x + 200, y + 420)),
                   (x + 1100, y + 60))

    # Estadísticas del contacto sobre la geometría de ENTRADA, ponderadas
    # por inside·Mask. LIMITACIÓN (documentada por la auditoría): son
    # reducciones globales — la máscara aísla este contacto solo si los
    # demás contactos caen FUERA de ella. Dos colisionadores presionando
    # zonas distintas de la MISMA máscara (o un pellizco con normales
    # opuestas) mezclan sus ejes; el factor de calidad `axis_q` de abajo
    # degrada esos casos hacia el escape radial + limpieza de la pasada 2
    # en vez de aplanar en una dirección inventada. Un contacto por
    # máscara es el caso soportado de primera clase.
    #
    # El peso lleva raycast dentro: se CAPTURA una vez para que las tres
    # estadísticas no re-evalúen el campo (3 pasadas de raycast ahorradas
    # por evaluación, medido por la auditoría de rendimiento).
    w_raw = _math(nt, 'MULTIPLY', inside, gi.outputs["Mask"],
                  (x + 200, y - 300), "Contact weight")
    geo_w, w = _capture(nt, gi.outputs["Geometry"], w_raw, 'FLOAT',
                        (x + 300, y - 220))
    stat_w = _node(nt, 'GeometryNodeAttributeStatistic', (x + 400, y - 300),
                   data_type='FLOAT', domain='POINT')
    _plug(nt, stat_w.inputs["Geometry"], geo_w)
    _plug(nt, _input(stat_w, "Attribute"), w)
    stat_p = _node(nt, 'GeometryNodeAttributeStatistic', (x + 400, y - 480),
                   data_type='FLOAT_VECTOR', domain='POINT')
    _plug(nt, stat_p.inputs["Geometry"], geo_w)
    _plug(nt, _input(stat_p, "Attribute"),
          _vmath(nt, 'SCALE', pos, scale=w, loc=(x + 200, y - 480)))
    stat_n = _node(nt, 'GeometryNodeAttributeStatistic', (x + 400, y - 660),
                   data_type='FLOAT_VECTOR', domain='POINT')
    _plug(nt, stat_n.inputs["Geometry"], geo_w)
    _plug(nt, _input(stat_n, "Attribute"),
          _vmath(nt, 'SCALE', nrm, scale=w, loc=(x + 200, y - 660)))

    inv_w = _math(nt, 'DIVIDE', 1.0,
                  _math(nt, 'MAXIMUM', stat_w.outputs["Mean"], 1e-6,
                        (x + 620, y - 300)),
                  (x + 800, y - 300))
    c_contact = _vmath(nt, 'SCALE', stat_p.outputs["Mean"], scale=inv_w,
                       loc=(x + 800, y - 480), label="Centroide contacto")
    push = _vmath(nt, 'SCALE',
                  _vmath(nt, 'NORMALIZE', stat_n.outputs["Mean"],
                         loc=(x + 620, y - 660)),
                  scale=-1.0, loc=(x + 800, y - 660), label="Push axis")

    # Axis quality: |media(nrm·w)| / media(w) ∈ [0,1]. Coherente → 1;
    # contacto envolvente o pellizco (normales que se cancelan) → 0, y el
    # aplanado pierde el voto en favor del derrame radial.
    axis_q = _math(nt, 'MINIMUM',
                   _math(nt, 'MULTIPLY',
                         _math(nt, 'MULTIPLY',
                               _vmath(nt, 'LENGTH', stat_n.outputs["Mean"],
                                      loc=(x + 620, y - 820)),
                               inv_w, (x + 800, y - 820)),
                         2.0, (x + 980, y - 820)),
                   1.0, (x + 1160, y - 820), "Axis quality")

    # Escape 1: APLANADO a lo largo del eje de empuje.
    ray_a = _raycast(nt, collider, pos, push, (x + 1000, y - 100))
    # Escape 2: DERRAME radial, perpendicular al eje, desde el centroide.
    rel = _vmath(nt, 'SUBTRACT', pos, c_contact, loc=(x + 1000, y - 420))
    tang = _vmath(nt, 'SUBTRACT', rel,
                  _vmath(nt, 'SCALE', push,
                         scale=_vmath(nt, 'DOT_PRODUCT', rel, push,
                                      loc=(x + 1180, y - 500)),
                         loc=(x + 1360, y - 500)),
                  loc=(x + 1540, y - 420))
    rdir = _vmath(nt, 'NORMALIZE', tang, loc=(x + 1720, y - 420),
                  label="Radial direction")
    ray_r = _raycast(nt, collider, pos, rdir, (x + 1900, y - 420))

    # Validez de cada escape: golpe + rango self. Sin el filtro, un rayo
    # de escape que cruza la cavidad del cuerpo (hit self lejano) se
    # convertía en objetivo y teletransportaba carne a la pared opuesta.
    valid_a = _math(nt, 'MULTIPLY', ray_a.outputs["Is Hit"],
                    _self_range_ok(nt, ray_a, (x + 1400, y + 100)),
                    (x + 2000, y - 60))
    valid_r = _math(nt, 'MULTIPLY', ray_r.outputs["Is Hit"],
                    _self_range_ok(nt, ray_r, (x + 1900, y - 720)),
                    (x + 2100, y - 640))

    # Mezcla smooth-min sesgada por Splay: gana el escape corto.
    d_a2 = _math(nt, 'MULTIPLY', ray_a.outputs["Hit Distance"],
                 ray_a.outputs["Hit Distance"], (x + 1400, y - 100))
    d_r2 = _math(nt, 'MULTIPLY', ray_r.outputs["Hit Distance"],
                 ray_r.outputs["Hit Distance"], (x + 2100, y - 420))
    # TOPE del derrame: la carne es cohesiva — solo rebosa por un borde la
    # que está CERCA de ese borde (~5 cm); la del centro del contacto se
    # aplana y apila en vez de deslizarse media cara hasta el borde
    # lejano. Sin este término, con un colisionador grande el escape
    # radial ganaba en medio seno y la carne se "derretía" 10-15 cm hasta
    # las caras superior/inferior del cubo. fall = 1/(1+(d_r/5cm)²).
    fall = _math(nt, 'DIVIDE', 1.0,
                 _math(nt, 'ADD', 1.0,
                       _math(nt, 'MULTIPLY', d_r2, 400.0,
                             (x + 2100, y - 560)),
                       (x + 2280, y - 560)),
                 (x + 2460, y - 560), "Spill cap")
    num = _math(nt, 'MULTIPLY',
                _math(nt, 'MULTIPLY', d_a2, splay, (x + 1580, y - 100)),
                fall, (x + 1760, y - 100))
    den = _math(nt, 'ADD',
                _math(nt, 'ADD', num,
                      _math(nt, 'MULTIPLY', d_r2,
                            _math(nt, 'SUBTRACT', 1.0, splay,
                                  (x + 2280, y - 420)),
                            (x + 2460, y - 420)),
                      (x + 2640, y - 300)),
                1e-8, (x + 2820, y - 300))
    w_r = _math(nt, 'DIVIDE', num, den, (x + 3000, y - 300), "Peso radial")
    # Si un rayo falla, el otro asume todo el peso; si fallan ambos, el
    # factor any_hit anula el conform (vértice degenerado, lo limpia la
    # pasada de Contact Hardness).
    w_r = _math(nt, 'MULTIPLY', w_r, valid_r, (x + 3180, y - 300))
    w_r = _math(nt, 'MAXIMUM', w_r,
                _math(nt, 'MULTIPLY',
                      _math(nt, 'SUBTRACT', 1.0, valid_a,
                            (x + 3180, y - 460)),
                      valid_r, (x + 3360, y - 460)),
                (x + 3540, y - 300))
    # Eje degenerado (axis_q→0): el aplanado apuntaría a cualquier parte —
    # el derrame radial asume el peso (si su rayo es válido).
    w_r = _math(nt, 'MAXIMUM', w_r,
                _math(nt, 'MULTIPLY',
                      _math(nt, 'SUBTRACT', 1.0, axis_q,
                            (x + 3360, y - 620)),
                      valid_r, (x + 3540, y - 620)),
                (x + 3720, y - 460))
    any_hit = _math(nt, 'MAXIMUM', valid_a, valid_r, (x + 3180, y - 620))

    target = _vmath(nt, 'ADD',
                    _vmath(nt, 'SCALE', ray_a.outputs["Hit Position"],
                           scale=_math(nt, 'SUBTRACT', 1.0, w_r,
                                       (x + 3540, y - 100)),
                           loc=(x + 3720, y - 100)),
                    _vmath(nt, 'SCALE', ray_r.outputs["Hit Position"],
                           scale=w_r, loc=(x + 3720, y - 300)),
                    loc=(x + 3900, y - 200), label="Escape target")

    # Piel con rampa por penetración (idéntica al conform clásico).
    esc = _vmath(nt, 'SUBTRACT', target, pos, loc=(x + 4080, y - 200))
    pen = _vmath(nt, 'LENGTH', esc, loc=(x + 4260, y - 280))
    ramp = _math(nt, 'MINIMUM',
                 _math(nt, 'DIVIDE', pen,
                       _math(nt, 'ADD',
                             _math(nt, 'MULTIPLY', offset, 2.0,
                                   (x + 4080, y - 480)),
                             1e-5, (x + 4260, y - 480)),
                       (x + 4440, y - 480)),
                 1.0, (x + 4620, y - 480), "Skin ramp")
    target2 = _vmath(nt, 'ADD', target,
                     _vmath(nt, 'SCALE',
                            _vmath(nt, 'NORMALIZE', esc,
                                   loc=(x + 4260, y - 380)),
                            scale=_math(nt, 'MULTIPLY', offset, ramp,
                                        (x + 4620, y - 380)),
                            loc=(x + 4800, y - 380)),
                     loc=(x + 4980, y - 280))
    conform = _vmath(nt, 'SCALE',
                     _vmath(nt, 'SUBTRACT', target2, pos,
                            loc=(x + 5160, y - 200)),
                     scale=_math(nt, 'MULTIPLY', inside, any_hit,
                                 (x + 5160, y - 380)),
                     loc=(x + 5340, y - 260), label="Flesh conform")
    return conform, inside, pen


def _mutual_iter(nt, gi, geometry, dens, loc=(0, 0)):
    """Una iteración de detección + separación de auto-contacto."""
    x, y = loc
    pos = _node(nt, 'GeometryNodeInputPosition', (x, y + 80)).outputs["Position"]
    nrm = _node(nt, 'GeometryNodeInputNormal', (x, y - 60)).outputs["Normal"]

    # DETECTOR: rayo +Normal desde 2 mm sobre la superficie contra TODA la
    # malla deformada. Si sale por una cara TRASERA cercana, este vértice
    # está dentro de otra carne. Los pliegues propios no disparan (su cara
    # opuesta se ve de FRENTE, dot < 0). La cota 2·SELF_RANGE descarta
    # salidas lejanas (rayo que cruza el cuerpo y sale por la espalda:
    # sin la cota, un vértice bajo la barbilla "salía" por la coronilla y
    # se detectaba dentro).
    src_o = _vmath(nt, 'ADD', pos,
                   _vmath(nt, 'SCALE', nrm, scale=0.002, loc=(x + 180, y + 40)),
                   loc=(x + 360, y + 80))
    ray_o = _raycast(nt, geometry, src_o, nrm, (x + 540, y + 80))
    inside_pair = _math(nt, 'MULTIPLY',
                        _math(nt, 'MULTIPLY',
                              ray_o.outputs["Is Hit"],
                              _compare(nt, 'FLOAT', 'GREATER_THAN',
                                       _vmath(nt, 'DOT_PRODUCT',
                                              ray_o.outputs["Hit Normal"],
                                              nrm, loc=(x + 740, y + 40)),
                                       0.0, (x + 920, y + 40)),
                              (x + 1100, y + 80)),
                        _compare(nt, 'FLOAT', 'LESS_THAN',
                                 ray_o.outputs["Hit Distance"],
                                 SELF_RANGE * 2.0, (x + 920, y + 180)),
                        (x + 1280, y + 80), "Inside other flesh")

    # RESOLUCIÓN: rayo -Normal hasta la superficie por la que entró. La
    # cota 0.5·SELF_RANGE limita a penetraciones de contacto reales — la
    # salida por el lado opuesto del PROPIO seno queda más lejos y no
    # cuenta (evita que la periferia fina se auto-atraiga).
    src_b = _vmath(nt, 'SUBTRACT', pos,
                   _vmath(nt, 'SCALE', nrm, scale=0.002,
                          loc=(x + 180, y - 260)),
                   loc=(x + 360, y - 220))
    dir_b = _vmath(nt, 'SCALE', nrm, scale=-1.0, loc=(x + 360, y - 360))
    ray_b = _raycast(nt, geometry, src_b, dir_b, (x + 540, y - 280))
    exit_ok = _compare(nt, 'FLOAT', 'GREATER_THAN',
                       _vmath(nt, 'DOT_PRODUCT',
                              ray_b.outputs["Hit Normal"], dir_b,
                              loc=(x + 740, y - 320)),
                       0.0, (x + 920, y - 320))
    depth_ok = _compare(nt, 'FLOAT', 'LESS_THAN',
                        ray_b.outputs["Hit Distance"], SELF_RANGE * 0.5,
                        (x + 920, y - 460))
    valid = _math(nt, 'MULTIPLY',
                  _math(nt, 'MULTIPLY', inside_pair,
                        ray_b.outputs["Is Hit"], (x + 1100, y - 320)),
                  _math(nt, 'MULTIPLY', exit_ok, depth_ok,
                        (x + 1100, y - 460)),
                  (x + 1280, y - 380))

    corr = _vmath(nt, 'SCALE', dir_b,
                  scale=_math(nt, 'MULTIPLY',
                              _math(nt, 'MULTIPLY',
                                    ray_b.outputs["Hit Distance"], 0.5,
                                    (x + 1280, y - 200)),
                              _math(nt, 'MULTIPLY', valid,
                                    gi.outputs["Mask"], (x + 1280, y - 60)),
                              (x + 1460, y - 130)),
                  loc=(x + 1640, y - 130), label="Mutual separation")

    geo_c, corr_cap = _capture(nt, geometry, corr, 'FLOAT_VECTOR',
                               (x + 1820, y))
    smooth = _blur(nt, corr_cap, 'FLOAT_VECTOR',
                   _scaled_iters(nt, 4, dens, (x + 1820, y - 260)),
                   0.85, (x + 2000, y - 130))
    return _set_position(nt, geo_c, (x + 2180, y), offset=smooth)


def _mutual_squish_pass(nt, gi, geometry, dens, loc=(0, 0)):
    """Pase de auto-contacto DEFORMABLE-vs-DEFORMABLE (Self Collision).

    El conformado principal corre sobre la geometría de ENTRADA, así que
    no puede ver solapamientos creados por la propia deformación: dos
    senos empujados uno contra otro se interpenetraban y la costura de
    intersección quedaba visible en el escote. Este pase corre DESPUÉS de
    deformar y separa las superficies solapadas a partes iguales.

    Los rayos apuntan a TODA la malla deformada, no solo a la máscara de
    este modifier: con un modifier por seno (máscaras separadas) el
    contacto ocurre ENTRE máscaras y un pase limitado a la propia no lo
    ve — el caso real que motivó este diseño. Solo los vértices de la
    propia máscara se MUEVEN (corr·Mask); el resto de la malla es solo
    obstáculo.

    DOS iteraciones: con una máscara que cubre ambos lados, cada lado
    retrocede la mitad y la primera iteración ya converge (la segunda no
    encuentra nada). Con máscaras separadas solo un lado puede moverse
    por modifier: la segunda iteración recorta el residuo a un cuarto.
    Solo se construye para Squish / Squish & Inflate y solo evalúa con
    Self Collision activo (Switch de geometría perezoso).
    """
    x, y = loc
    it1 = _mutual_iter(nt, gi, geometry, dens, (x, y))
    it2 = _mutual_iter(nt, gi, it1, dens, (x, y - 900))
    return _switch(nt, 'GEOMETRY', gi.outputs["Self Collision"],
                   geometry, it2, (x + 2500, y))


def _corrective_smooth(nt, geometry, halo, iterations_socket, loc=(0, 0)):
    """Blur de las posiciones mezclado solo en la zona afectada (halo)."""
    x, y = loc
    pos = _node(nt, 'GeometryNodeInputPosition', (x, y - 200)).outputs["Position"]
    blurred = _blur(nt, pos, 'FLOAT_VECTOR', iterations_socket, 0.85,
                    (x + 200, y - 200))
    gate = _switch(nt, 'FLOAT',
                   _compare(nt, 'INT', 'GREATER_THAN', iterations_socket, 0,
                            (x, y - 420)),
                   0.0, 1.0, (x + 200, y - 420))
    fac = _math(nt, 'MULTIPLY',
                _math(nt, 'MINIMUM',
                      _math(nt, 'MULTIPLY', halo, 12.0, (x + 200, y - 560)),
                      1.0, (x + 380, y - 560)),
                gate, (x + 560, y - 480))
    mixed = _vmath(nt, 'ADD', pos,
                   _vmath(nt, 'SCALE',
                          _vmath(nt, 'SUBTRACT', blurred, pos,
                                 loc=(x + 420, y - 260)),
                          scale=fac, loc=(x + 620, y - 260)),
                   loc=(x + 820, y - 200))
    return _set_position(nt, geometry, (x + 1020, y), position=mixed)


# ---------------------------------------------------------------------------
# Núcleo compartido: squish "carnoso" en dos pasadas (v2.1)
# ---------------------------------------------------------------------------

def _natural_squish_core(nt, gi, collider, strength_name, params=None):
    """Contacto de aspecto natural (carne blanda):

    Pasada 1 — HUELLA SUAVE: el vector de conformado se difunde con Blur
      Attribute (Shape Smoothing) ANTES de aplicarse; la huella pasa a ser
      el promedio local del contacto, así los bordes de colisionadores
      duros (cubos) se redondean y el borde exterior anticipa el
      hundimiento en vez de cortar en seco.
    Pasada 2 — LIMPIEZA PARCIAL: un segundo conformado en la posición ya
      desplazada empuja fuera lo que siga dentro, escalado por Contact
      Hardness (<1 permite un solapamiento leve, típico de carne).
    VOLUMEN: el halo (Blur del módulo de hundimiento) abulta por la normal
      (Volume Preservation) y fluye tangencialmente alejándose del
      centroide del contacto (Lateral Flow), calculado con Attribute
      Statistic y protegido contra división por cero.

    `params` (opcional): dict {nombre_socket: socket|valor} que SUSTITUYE
    la lectura de gi.outputs[nombre]. Permite a un builder derivar varios
    knobs internos de menos sliders (Squish Organic: Collision Softness ->
    Shape Smoothing/Spread/Contact Hardness; Mask -> campo de blandura
    Mask·(1-Stiffness)) sin duplicar el núcleo. Los builders existentes
    no pasan params y leen sus sockets como siempre.

    Devuelve (geometry, halo, d_cap).
    """
    def _p(name):
        if params is not None and name in params:
            return params[name]
        return gi.outputs[name]

    pos = _node(nt, 'GeometryNodeInputPosition', (-2100, -200)).outputs["Position"]
    nrm = _node(nt, 'GeometryNodeInputNormal', (-2100, -350)).outputs["Normal"]
    dens = _mesh_density_factor(nt, gi.outputs["Geometry"], (-2100, 1100))

    conform, _ins, _dl = _flesh_conform(
        nt, gi, collider, pos, nrm, _p("Collision Offset"),
        _p("Splay"), loc=(-1700, 700))

    yield_f = _clamp01(nt, _math(nt, 'MULTIPLY', _p("Mask"),
                                 _p(strength_name), (-620, 520)),
                       (-460, 520))
    seed = _vmath(nt, 'SCALE', conform, scale=yield_f, loc=(-240, 430),
                  label="Contact seed")

    geo_c1, seed_cap = _capture(nt, gi.outputs["Geometry"], seed,
                                'FLOAT_VECTOR', (-720, 60))
    # El módulo se deriva del campo YA CAPTURADO: derivarlo de `seed`
    # re-evaluaba el conform entero (raycasts incluidos) una segunda vez.
    d_seed = _vmath(nt, 'LENGTH', seed_cap, loc=(-60, 430))
    geo_c2, d_cap = _capture(nt, geo_c1, d_seed, 'FLOAT', (-480, 60))

    # Pasada 1: huella = blur del VECTOR de conformado
    soft = _blur(nt, seed_cap, 'FLOAT_VECTOR',
                 _scaled_iters(nt, _p("Shape Smoothing"), dens,
                               (-460, -240)), 0.85, (-260, -80))

    # Volumen APILADO sobre el contacto: la carne que converge contra una
    # cara del colisionador no se queda plana como una tortita — el
    # material desplazado se acumula y abomba SEPARÁNDOSE de la cara. Sin
    # este término, el escape radial estampaba la cara superior/lateral
    # del cubo como una repisa plana (medido en los senos: shelf horizontal
    # sobre la cara superior). El abombado va a lo largo de la dirección
    # de escape suavizada (= normal local de la cara donde aterrizó, hacia
    # FUERA del colisionador, así que nunca reintroduce penetración) y es
    # proporcional al material desplazado en la vecindad (halo = blur del
    # módulo de desplazamiento), escalado por Volume Preservation.
    halo = _blur(nt, d_cap, 'FLOAT',
                 _scaled_iters(nt, _p("Spread"), dens, (440, -440)),
                 0.9, (620, -280))
    pile = _vmath(nt, 'SCALE',
                  _vmath(nt, 'NORMALIZE', soft, loc=(-260, -280)),
                  scale=_math(nt, 'MULTIPLY',
                              _math(nt, 'MULTIPLY', halo, 0.35,
                                    (-80, -280)),
                              _math(nt, 'MULTIPLY',
                                    _p("Volume Preservation"),
                                    _p("Mask"), (-80, -420)),
                              (100, -280)),
                  loc=(280, -200), label="Volumen apilado")
    geo1 = _set_position(nt, geo_c2, (-40, 60),
                         offset=_vmath(nt, 'ADD', soft, pile,
                                       loc=(-40, -120)))

    # Pasada 2: limpieza parcial (Contact Hardness)
    pos1 = _node(nt, 'GeometryNodeInputPosition', (120, -260)).outputs["Position"]
    nrm1 = _node(nt, 'GeometryNodeInputNormal', (120, -410)).outputs["Normal"]
    conform2, _i2, _d2 = _contact_conform(
        nt, collider, pos1, nrm1, _p("Collision Offset"),
        loc=(300, 1600))
    hard = _vmath(nt, 'SCALE',
                  _vmath(nt, 'SCALE', conform2, scale=yield_f,
                         loc=(1600, 1500)),
                  scale=_p("Contact Hardness"), loc=(1780, 1500),
                  label="Limpieza dura")
    geo2 = _set_position(nt, geo1, (420, 60), offset=hard)

    # Anillo exterior (el halo ya se computó arriba para el apilado)
    basin = _math(nt, 'MAXIMUM',
                  _math(nt, 'SUBTRACT', halo, d_cap, (800, -280)),
                  0.0, (970, -280), "Halo exterior")

    # Centroide del contacto (zero-safe) para el flujo lateral
    posc = _node(nt, 'GeometryNodeInputPosition', (620, -520)).outputs["Position"]
    nrmc = _node(nt, 'GeometryNodeInputNormal', (620, -670)).outputs["Normal"]

    stat_d = _node(nt, 'GeometryNodeAttributeStatistic', (800, -820),
                   data_type='FLOAT', domain='POINT')
    _plug(nt, stat_d.inputs["Geometry"], geo2)
    _plug(nt, _input(stat_d, "Attribute"), d_cap)

    weighted = _vmath(nt, 'SCALE', posc, scale=d_cap, loc=(800, -560))
    stat_v = _node(nt, 'GeometryNodeAttributeStatistic', (980, -580),
                   data_type='FLOAT_VECTOR', domain='POINT')
    _plug(nt, stat_v.inputs["Geometry"], geo2)
    _plug(nt, _input(stat_v, "Attribute"), weighted)

    mean_d = _math(nt, 'MAXIMUM', stat_d.outputs["Mean"], 1e-6, (1160, -820))
    centroid = _vmath(nt, 'SCALE', stat_v.outputs["Mean"],
                      scale=_math(nt, 'DIVIDE', 1.0, mean_d, (1320, -820)),
                      loc=(1480, -680), label="Centroide contacto")

    radial = _vmath(nt, 'SUBTRACT', posc, centroid, loc=(1640, -520))
    r_dot_n = _vmath(nt, 'DOT_PRODUCT', radial, nrmc, loc=(1640, -680))
    tang = _vmath(nt, 'SUBTRACT', radial,
                  _vmath(nt, 'SCALE', nrmc, scale=r_dot_n, loc=(1800, -680)),
                  loc=(1960, -560))
    t_len = _math(nt, 'MAXIMUM',
                  _vmath(nt, 'LENGTH', tang, loc=(1960, -720)),
                  1e-6, (2120, -720))
    tdir = _vmath(nt, 'SCALE', tang,
                  scale=_math(nt, 'DIVIDE', 1.0, t_len, (2280, -720)),
                  loc=(2440, -600))

    amp_n = _math(nt, 'MULTIPLY',
                  _math(nt, 'MULTIPLY', basin,
                        _p("Volume Preservation"), (1150, -300)),
                  _p("Mask"), (1330, -300))
    amp_t = _math(nt, 'MULTIPLY',
                  _math(nt, 'MULTIPLY', basin,
                        _p("Lateral Flow"), (1150, -440)),
                  _p("Mask"), (1330, -440))
    bulge = _vmath(nt, 'ADD',
                   _vmath(nt, 'SCALE', nrmc, scale=amp_n, loc=(1510, -320)),
                   _vmath(nt, 'SCALE', tdir, scale=amp_t, loc=(1510, -470)),
                   loc=(1690, -380), label="Abultamiento + flujo")
    geo3 = _set_position(nt, geo2, (900, 60), offset=bulge)
    return geo3, halo, d_cap, dens


def _natural_squish_sockets(nt, strength_name, strength_desc, defaults=None):
    """`defaults` (opcional): dict {nombre_socket: valor} que SUSTITUYE el
    default de fábrica de cada socket. Squish y Squish & Inflate comparten
    esta función pero ya NO comparten defaults — cada builder pasa los suyos
    (afinados por el usuario). Un socket ausente del dict conserva el default
    histórico. NO cambia orden ni tipo de sockets: solo el valor por defecto,
    así que un modifier existente conserva su valor (el rebuild remapea por
    nombre) y solo los NUEVOS modifiers nacen con estos valores."""
    d = defaults or {}

    def _dv(name, fallback):
        return d.get(name, fallback)

    _sock(nt, "Mask", 'INPUT', 'NodeSocketFloat', _dv("Mask", 1.0), 0.0, 1.0,
          'FACTOR', "Vertex Group weight: 1 = deformable, 0 = rigid")
    _sock(nt, strength_name, 'INPUT', 'NodeSocketFloat',
          _dv(strength_name, 1.0), 0.0, 2.0, None, strength_desc)
    _sock(nt, "Shape Smoothing", 'INPUT', 'NodeSocketInt',
          _dv("Shape Smoothing", 7), 0, 15, None,
          "Rounds the footprint: averages the contact so hard-edged colliders "
          "duros (cubos) no marquen sus aristas")
    _sock(nt, "Spread", 'INPUT', 'NodeSocketInt', _dv("Spread", 9), 0, 25,
          None, "Width of the deformation halo around the contact")
    _sock(nt, "Volume Preservation", 'INPUT', 'NodeSocketFloat',
          _dv("Volume Preservation", 1.0), 0.0,
          2.0, None, "Ring bulge (displaced volume)")
    _sock(nt, "Lateral Flow", 'INPUT', 'NodeSocketFloat',
          _dv("Lateral Flow", 0.5), 0.0, 1.0,
          'FACTOR', "Flesh flows tangentially away from the contact")
    _sock(nt, "Contact Hardness", 'INPUT', 'NodeSocketFloat',
          _dv("Contact Hardness", 0.85), 0.0,
          1.0, 'FACTOR', "1 = the collider never passes through; lower = the "
          "flesh allows a subtle overlap (softer)")
    _sock(nt, "Corrective Smooth", 'INPUT', 'NodeSocketInt',
          _dv("Corrective Smooth", 3), 0, 10, None,
          "Final smoothing of the deformed region")
    _sock(nt, "Collision Offset", 'INPUT', 'NodeSocketFloat',
          _dv("Collision Offset", 0.015), 0.0,
          0.5, None, "Skin: extra distance above the collider")
    _collider_sockets(nt)


def _splay_sock(nt, default=0.5):
    """Socket "Splay" — SIEMPRE el último que se crea en el árbol.

    NO mover a _natural_squish_sockets ni insertarlo antes de otros
    sockets. Los identificadores (Socket_N) se asignan por orden de
    creación, y los modifiers de archivos ya guardados referencian ESOS
    identificadores. Insertar un socket en medio desplaza el significado
    de todos los posteriores: al añadir un socket en su posición "lógica"
    (junto a Collision Offset), Socket_11 pasó de Collision Collection a
    Collision Object y los modifiers existentes siguieron guardando un
    datablock Collection bajo un socket declarado Object. Blender lo
    toleraba en memoria, pero al RECARGAR el .blend el nodo Object Info
    leía esa Collection como Object* y moría con ACCESS_VIOLATION en el
    producto de matrices. Crear el socket al final mantiene intacto el
    significado de Socket_0..N-1. (Sustituye a "Deep Contact", que era el
    último: quitarlo y añadir éste no desplaza nada.)
    """
    _sock(nt, "Splay", 'INPUT', 'NodeSocketFloat', default, 0.0, 1.0,
          'FACTOR', "Split of the displaced volume: 0 = the flesh only "
          "flattens against the collider, 1 = it only spills out to the "
          "sides. 0.5 lets the shortest path win (natural)")


# ---------------------------------------------------------------------------
# 1) SQUISH — hundimiento carnoso con volumen y flujo lateral (EN VIVO)
# ---------------------------------------------------------------------------

def _hard_anticlip(nt, gi, collider, geometry, loc=(0, 0)):
    """Pasada anti-clip FINAL (garantía dura de no-atravesado).

    El resto del Squish es carne blanda: el conform se difumina, la limpieza
    se escala por Contact Hardness (<1 permite solapamiento) y el Corrective
    Smooth final re-difumina posiciones metiendo vértices DENTRO del
    colisionador otra vez. Sin una garantía dura, al empujar hondo (sobre todo
    con colisionadores FINOS y Collision Offset=0) el colisionador atraviesa la
    malla y asoma por fuera. Aquí, como ÚLTIMA operación sobre la malla ya
    deformada, se recalcula el conform a FUERZA COMPLETA y se expulsa cualquier
    vértice que siga dentro hasta la superficie + piel. La piel usa un SUELO
    de 1.5 mm (max(Collision Offset, 1.5mm)): aunque el usuario ponga Offset=0,
    queda un margen mínimo para que la punta no haga z-fighting ni asome. El
    gate de interior se difumina (borde de contacto suave, sin púas). Solo
    actúa sobre la carne enmascarada (peso×2 saturado). Nunca atraviesa."""
    x, y = loc
    pos = _node(nt, 'GeometryNodeInputPosition',
                (x, y - 200)).outputs["Position"]
    nrm = _node(nt, 'GeometryNodeInputNormal', (x, y - 360)).outputs["Normal"]
    # suelo mínimo de piel: aun con Offset=0 la punta no asoma
    skin = _math(nt, 'MAXIMUM', gi.outputs["Collision Offset"], 0.0015,
                 (x + 40, y - 520), "Minimum skin 1.5mm")
    dens = _mesh_density_factor(nt, geometry, (x + 200, y - 900))
    git = _scaled_iters(nt, 2.0, dens, (x + 400, y - 900))
    conform, _in, _pen = _contact_conform(
        nt, collider, pos, nrm, skin, gate_iters=git, loc=(x + 200, y))
    m = _clamp01(nt, _math(nt, 'MULTIPLY', gi.outputs["Mask"], 2.0,
                           (x + 1600, y - 500)), (x + 1740, y - 500))
    cm = _vmath(nt, 'SCALE', conform, scale=m, loc=(x + 1920, y - 140),
                label="Anti-clip final")
    return _set_position(nt, geometry, (x + 2120, y), offset=cm)


# Defaults "de fábrica" afinados por el usuario (2026-07-20): valores que
# tenía dialados en su escena y pidió fijar como default. Solo afectan a los
# NUEVOS modifiers; los existentes conservan su valor (rebuild remapea por
# nombre). Splay va aparte (socket final). Squish e Inflate divergen.
SQUISH_DEFAULTS = {
    "Intensity": 2.0,
    "Shape Smoothing": 15,
    "Spread": 1,
    "Volume Preservation": 0.21,
    "Lateral Flow": 0.291667,
    "Contact Hardness": 0.518519,
    "Corrective Smooth": 4,
    "Collision Offset": 0.0,
}
SQUISH_SPLAY_DEFAULT = 0.0

SQUISH_INFLATE_DEFAULTS = {
    "Squish Strength": 1.38,
    "Shape Smoothing": 11,
    "Spread": 9,
    "Volume Preservation": 0.26,
    "Lateral Flow": 0.0,
    "Contact Hardness": 0.0,
    "Corrective Smooth": 10,
    "Collision Offset": 0.0011,
}
SQUISH_INFLATE_PRESSURE_DEFAULT = 1.0
SQUISH_INFLATE_SPLAY_DEFAULT = 0.0


def build_squish(name=NAME_SQUISH):
    nt, gi, go = _base_tree(name)
    _natural_squish_sockets(nt, "Intensity",
                            "How much the surface yields to the collider",
                            defaults=SQUISH_DEFAULTS)
    _splay_sock(nt, default=SQUISH_SPLAY_DEFAULT)
    _self_collision_sock(nt)   # últimos sockets: no desplazar los Socket_N
    collider, _obj_only = _collider_geometry(nt, gi)
    geo3, halo, _d, dens = _natural_squish_core(
        nt, gi, collider, "Intensity")
    geo3b = _mutual_squish_pass(nt, gi, geo3, dens, (1200, 1200))
    geo4 = _corrective_smooth(
        nt, geo3b, halo,
        _scaled_iters(nt, gi.outputs["Corrective Smooth"], dens, (1200, 300)),
        (1400, 60))
    geo5 = _hard_anticlip(nt, gi, collider, geo4, (1700, 700))
    return _finish_tree(nt, go, geo5)


# ---------------------------------------------------------------------------
# 2) SQUISH & INFLATE — squish carnoso + inflado ponderado por cercanía
# ---------------------------------------------------------------------------

def build_squish_inflate(name=NAME_SQUISH_INFLATE):
    nt, gi, go = _base_tree(name)
    _natural_squish_sockets(nt, "Squish Strength",
                            "How much the surface yields to the collider",
                            defaults=SQUISH_INFLATE_DEFAULTS)
    _sock(nt, "Inflate Pressure", 'INPUT', 'NodeSocketFloat',
          SQUISH_INFLATE_PRESSURE_DEFAULT, 0.0, 3.0,
          None, "The compressed volume inflates the rest of the masked "
          "region, more strongly near the contact")
    _splay_sock(nt, default=SQUISH_INFLATE_SPLAY_DEFAULT)
    _self_collision_sock(nt)   # últimos sockets: no desplazar los Socket_N
    collider, _obj_only = _collider_geometry(nt, gi)

    geo3, halo, d_cap, dens = _natural_squish_core(nt, gi, collider,
                                                   "Squish Strength")

    stat = _node(nt, 'GeometryNodeAttributeStatistic', (1200, 300),
                 data_type='FLOAT', domain='POINT')
    _plug(nt, stat.inputs["Geometry"], geo3)
    _plug(nt, _input(stat, "Attribute"), d_cap)
    pressure = _math(nt, 'MULTIPLY',
                     _math(nt, 'MULTIPLY', stat.outputs["Mean"],
                           gi.outputs["Inflate Pressure"], (1400, 300)),
                     8.0, (1570, 300), "Pressure")

    contact_zone = _math(nt, 'MINIMUM',
                         _math(nt, 'MULTIPLY', halo, 6.0, (1200, 140)),
                         1.0, (1370, 140))
    away = _math(nt, 'SUBTRACT', 1.0, contact_zone, (1540, 140))
    near = _math(nt, 'MINIMUM',
                 _math(nt, 'MULTIPLY', halo, 2.5, (1200, 20)),
                 1.0, (1370, 20))
    ring_w = _math(nt, 'ADD', 0.25,
                   _math(nt, 'MULTIPLY', 0.75, near, (1540, 20)),
                   (1710, 60), "Peso anular")

    nrm_i = _node(nt, 'GeometryNodeInputNormal', (1570, -120)).outputs["Normal"]
    amt = _math(nt, 'MULTIPLY',
                _math(nt, 'MULTIPLY',
                      _math(nt, 'MULTIPLY', pressure, away, (1740, 220)),
                      ring_w, (1900, 200)),
                gi.outputs["Mask"], (2060, 180))
    inflate = _vmath(nt, 'SCALE', nrm_i, scale=amt, loc=(2220, 60),
                     label="Inflado")
    geo4 = _set_position(nt, geo3, (2380, 60), offset=inflate)

    geo4b = _mutual_squish_pass(nt, gi, geo4, dens, (2400, 1200))
    geo5 = _corrective_smooth(
        nt, geo4b, halo,
        _scaled_iters(nt, gi.outputs["Corrective Smooth"], dens, (2400, 300)),
        (2600, 60))
    geo6 = _hard_anticlip(nt, gi, collider, geo5, (2900, 700))
    return _finish_tree(nt, go, geo6)



def _impact_sockets(nt):
    _sock(nt, "Impact Sensitivity", 'INPUT', 'NodeSocketFloat', 1.5, 0.0,
          5.0, None, "How much energy an impact injects (contact change): "
          "the impulse fires both on impact AND on release")
    _sock(nt, "Relax Time", 'INPUT', 'NodeSocketFloat', 0.6, 0.05, 5.0,
          None, "Seconds for the wobble to settle after an impact; "
          "under sustained motionless contact the effect fades on its own")
    energy = _sock(nt, "Energy", 'INPUT', 'NodeSocketFloat', 0.0, 0.0, 2.0,
                   'FACTOR', "Internal: impulse energy; the addon writes "
                   "it every frame (impact -> rises, then decays)")
    try:
        energy.hide_in_modifier = True
    except AttributeError:
        pass



# ---------------------------------------------------------------------------
# 3) RIPPLE — ondas de IMPULSO: el golpe del colisionador inyecta energía
#    que decae con Relax Time (nalgada: ráfaga -> se calma -> reposo
#    perfecto). Contacto sostenido inmóvil = solo huella, sin ondas.
#    Preview solo durante la reproducción (flag "Playing" + Is Viewport).
# ---------------------------------------------------------------------------

def build_ripple(name=NAME_RIPPLE):
    nt, gi, go = _base_tree(name)

    _sock(nt, "Mask", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 1.0, 'FACTOR',
          "Vertex Group weight: where the waves may exist")
    _sock(nt, "Amplitude", 'INPUT', 'NodeSocketFloat', 0.15, 0.0, 5.0, None,
          "Wave height along the normal")
    _sock(nt, "Frequency", 'INPUT', 'NodeSocketFloat', 8.0, 0.0, 100.0, None,
          "Waves per unit of distance from the collider")
    _sock(nt, "Wave Speed", 'INPUT', 'NodeSocketFloat', 4.0, -50.0, 50.0,
          None, "Phase speed during playback")
    _sock(nt, "Decay", 'INPUT', 'NodeSocketFloat', 1.5, 0.0, 20.0, None,
          "Spatial falloff of the amplitude with distance from the contact")
    _sock(nt, "Dent Depth", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 2.0, None,
          "Static footprint while the collider presses")
    _impact_sockets(nt)
    _sock(nt, "Smoothing", 'INPUT', 'NodeSocketInt', 2, 0, 10, None,
          "Smoothing of the final deformation (footprint + waves)")
    _sock(nt, "Collision Offset", 'INPUT', 'NodeSocketFloat', 0.01, 0.0, 0.5,
          None, "Skin: extra distance above the collider surface")
    playing = _sock(nt, "Playing", 'INPUT', 'NodeSocketFloat', 0.0, 0.0, 1.0,
                    'FACTOR', "Internal: 1 during timeline "
                    "playback (written by the addon; do not edit)")
    try:
        playing.hide_in_modifier = True
    except AttributeError:
        pass
    _collider_sockets(nt)
    _self_collision_sock(nt)   # último socket: no desplazar los Socket_N

    collider, collider_obj = _collider_geometry(nt, gi)

    pos = _node(nt, 'GeometryNodeInputPosition', (-2100, -200)).outputs["Position"]
    nrm = _node(nt, 'GeometryNodeInputNormal', (-2100, -350)).outputs["Normal"]
    dens = _mesh_density_factor(nt, gi.outputs["Geometry"], (-2100, 1100))

    # Mismo contacto que Squish / Squish & Inflate (v3.3.0): aplanado
    # direccional por eje de contacto en vez de proyección al punto más
    # cercano, que estampaba la silueta del colisionador y pellizcaba
    # crestas en sus aristas.
    conform, inside_f, _dl = _flesh_conform(
        nt, gi, collider, pos, nrm, gi.outputs["Collision Offset"],
        0.0, loc=(-1700, 600))

    dent = _vmath(nt, 'SCALE', conform,
                  scale=_clamp01(nt,
                                 _math(nt, 'MULTIPLY', gi.outputs["Mask"],
                                       gi.outputs["Dent Depth"], (-500, 500)),
                                 (-340, 500)),
                  loc=(-100, 420), label="Huella")

    # Distancia para fase/decay de las ondas: contra SOLO los objetos —
    # el join completo con Self Collision daria distancia ~0 en toda la
    # zona enmascarada (el propio cuerpo) y colapsaria el falloff.
    prox = _node(nt, 'GeometryNodeProximity', (-1200, -600),
                 target_element='FACES')
    _plug(nt, _input(prox, "Geometry", "Target"), collider_obj)
    _plug(nt, _input(prox, "Sample Position"), pos)
    dist = prox.outputs["Distance"]

    # Envolvente de impulso: energía escrita por el addon (handler por frame)
    energy = gi.outputs["Energy"]

    time = _node(nt, 'GeometryNodeInputSceneTime', (-800, -750))
    phase = _math(nt, 'SUBTRACT',
                  _math(nt, 'MULTIPLY', dist, gi.outputs["Frequency"],
                        (-600, -600)),
                  _math(nt, 'MULTIPLY', time.outputs["Seconds"],
                        gi.outputs["Wave Speed"], (-600, -750)),
                  (-420, -650))
    att = _math(nt, 'EXPONENT',
                _math(nt, 'MULTIPLY',
                      _math(nt, 'MULTIPLY', dist, gi.outputs["Decay"],
                            (-420, -820)),
                      -1.0, (-260, -820)),
                None, (-100, -820))
    wave = _math(nt, 'MULTIPLY',
                 _math(nt, 'MULTIPLY',
                       _math(nt, 'MULTIPLY',
                             _math(nt, 'SINE', phase, None, (-260, -650)),
                             gi.outputs["Amplitude"], (-100, -650)),
                       att, (80, -680)),
                 _math(nt, 'MULTIPLY', energy, gi.outputs["Mask"],
                       (80, -520)),
                 (260, -600), "Impulse wave")

    offset_raw = _vmath(nt, 'ADD', dent,
                        _vmath(nt, 'SCALE', nrm, scale=wave, loc=(440, -500)),
                        loc=(640, -400))

    isvp = _node(nt, 'GeometryNodeIsViewport', (640, 300))
    play_gate = _switch(nt, 'FLOAT', isvp.outputs["Is Viewport"], 1.0,
                        gi.outputs["Playing"], (820, 300))
    offset_g = _vmath(nt, 'SCALE', offset_raw, scale=play_gate,
                      loc=(840, -350), label="Gate Play")

    geo_c, off_cap = _capture(nt, gi.outputs["Geometry"], offset_g, 'FLOAT_VECTOR', (900, 60))
    dens = _mesh_density_factor(nt, gi.outputs["Geometry"], (-1600, -1100))
    smooth = _blur(nt, off_cap, 'FLOAT_VECTOR',
                   _scaled_iters(nt, gi.outputs["Smoothing"], dens,
                                 (-1400, -1100)),
                   0.85, (1140, -120))
    out_geo = _set_position(nt, geo_c, (1360, 0), offset=smooth)
    return _finish_tree(nt, go, out_geo)


# ---------------------------------------------------------------------------
# 4) FAT JIGGLE — temblor de grasa por IMPULSO: la nalgada inyecta energía
#    que decae con Relax Time; la carne tiembla y vuelve perfecta al reposo.
#    Contacto sostenido inmóvil = solo huella, sin temblor infinito.
# ---------------------------------------------------------------------------

def build_jiggle(name=NAME_JIGGLE):
    nt, gi, go = _base_tree(name)

    _sock(nt, "Mask", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 1.0, 'FACTOR',
          "Vertex Group weight: where the fat wobbles")
    _sock(nt, "Amplitude", 'INPUT', 'NodeSocketFloat', 0.08, 0.0, 2.0, None,
          "Overall scale of the wobble")
    _sock(nt, "Wobble Scale", 'INPUT', 'NodeSocketFloat', 2.5, 0.1, 20.0,
          None, "Lobe size: lower = large fat masses, "
          "mayor = temblor fino")
    _sock(nt, "Wobble Speed", 'INPUT', 'NodeSocketFloat', 2.0, 0.0, 20.0,
          None, "Wobble speed during playback")
    _sock(nt, "Lateral Motion", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 2.0,
          None, "Tangential slosh: the fat shifts sideways")
    _sock(nt, "Normal Motion", 'INPUT', 'NodeSocketFloat', 0.6, 0.0, 2.0,
          None, "Bounce along the surface normal")
    _sock(nt, "Decay", 'INPUT', 'NodeSocketFloat', 1.2, 0.0, 20.0, None,
          "Spatial falloff of the wobble with distance from the collider")
    _sock(nt, "Dent Depth", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 2.0, None,
          "Static footprint while the collider presses")
    _impact_sockets(nt)
    _sock(nt, "Smoothing", 'INPUT', 'NodeSocketInt', 2, 0, 10, None,
          "Smoothing of the final deformation")
    _sock(nt, "Collision Offset", 'INPUT', 'NodeSocketFloat', 0.01, 0.0, 0.5,
          None, "Skin: extra distance above the collider surface")
    playing = _sock(nt, "Playing", 'INPUT', 'NodeSocketFloat', 0.0, 0.0, 1.0,
                    'FACTOR', "Internal: 1 during timeline "
                    "playback (written by the addon; do not edit)")
    try:
        playing.hide_in_modifier = True
    except AttributeError:
        pass
    _collider_sockets(nt)
    _self_collision_sock(nt)   # último socket: no desplazar los Socket_N

    collider, collider_obj = _collider_geometry(nt, gi)

    pos = _node(nt, 'GeometryNodeInputPosition', (-2100, -200)).outputs["Position"]
    nrm = _node(nt, 'GeometryNodeInputNormal', (-2100, -350)).outputs["Normal"]
    dens = _mesh_density_factor(nt, gi.outputs["Geometry"], (-2100, 1100))

    # Mismo contacto que Squish / Squish & Inflate (v3.3.0): aplanado
    # direccional por eje de contacto en vez de proyección al punto más
    # cercano, que estampaba la silueta del colisionador y pellizcaba
    # crestas en sus aristas.
    conform, inside_f, _dl = _flesh_conform(
        nt, gi, collider, pos, nrm, gi.outputs["Collision Offset"],
        0.0, loc=(-1700, 600))

    dent = _vmath(nt, 'SCALE', conform,
                  scale=_clamp01(nt,
                                 _math(nt, 'MULTIPLY', gi.outputs["Mask"],
                                       gi.outputs["Dent Depth"], (-500, 500)),
                                 (-340, 500)),
                  loc=(-100, 420), label="Huella")

    # Distancia para fase/decay de las ondas: contra SOLO los objetos —
    # el join completo con Self Collision daria distancia ~0 en toda la
    # zona enmascarada (el propio cuerpo) y colapsaria el falloff.
    prox = _node(nt, 'GeometryNodeProximity', (-1200, -600),
                 target_element='FACES')
    _plug(nt, _input(prox, "Geometry", "Target"), collider_obj)
    _plug(nt, _input(prox, "Sample Position"), pos)
    dist = prox.outputs["Distance"]

    # Envolvente de impulso: energía escrita por el addon (handler por frame)
    energy = gi.outputs["Energy"]

    # Campo de temblor: ruido 4D animado por el tiempo
    time = _node(nt, 'GeometryNodeInputSceneTime', (-1200, -900))
    noise = _node(nt, 'ShaderNodeTexNoise', (-800, -800),
                  noise_dimensions='4D')
    _plug(nt, noise.inputs["Vector"], pos)
    _plug(nt, noise.inputs["W"],
          _math(nt, 'MULTIPLY', time.outputs["Seconds"],
                gi.outputs["Wobble Speed"], (-1000, -900)))
    _plug(nt, noise.inputs["Scale"], gi.outputs["Wobble Scale"])
    _plug(nt, noise.inputs["Detail"], 2.0)
    _plug(nt, noise.inputs["Roughness"], 0.55)

    wob = _vmath(nt, 'SUBTRACT', noise.outputs["Color"], (0.5, 0.5, 0.5),
                 loc=(-560, -800), label="Ruido centrado")
    wn = _vmath(nt, 'DOT_PRODUCT', wob, nrm, loc=(-380, -740))
    w_tang = _vmath(nt, 'SUBTRACT', wob,
                    _vmath(nt, 'SCALE', nrm, scale=wn, loc=(-380, -880)),
                    loc=(-200, -820), label="Slosh tangencial")
    jig = _vmath(nt, 'ADD',
                 _vmath(nt, 'SCALE', w_tang,
                        scale=gi.outputs["Lateral Motion"], loc=(-20, -780)),
                 _vmath(nt, 'SCALE', nrm,
                        scale=_math(nt, 'MULTIPLY', wn,
                                    gi.outputs["Normal Motion"],
                                    (-200, -1000)),
                        loc=(-20, -960)),
                 loc=(160, -860), label="Temblor")

    att = _math(nt, 'EXPONENT',
                _math(nt, 'MULTIPLY',
                      _math(nt, 'MULTIPLY', dist, gi.outputs["Decay"],
                            (-420, -560)),
                      -1.0, (-260, -560)),
                None, (-100, -560))
    amp = _math(nt, 'MULTIPLY',
                _math(nt, 'MULTIPLY',
                      _math(nt, 'MULTIPLY', gi.outputs["Amplitude"], att,
                            (80, -600)),
                      gi.outputs["Mask"], (260, -620)),
                energy, (440, -640), "Impulse amplitude")

    offset_raw = _vmath(nt, 'ADD', dent,
                        _vmath(nt, 'SCALE', jig, scale=amp, loc=(620, -740)),
                        loc=(800, -520))

    isvp = _node(nt, 'GeometryNodeIsViewport', (640, 300))
    play_gate = _switch(nt, 'FLOAT', isvp.outputs["Is Viewport"], 1.0,
                        gi.outputs["Playing"], (820, 300))
    offset_g = _vmath(nt, 'SCALE', offset_raw, scale=play_gate,
                      loc=(1000, -420), label="Gate Play")

    geo_c, off_cap = _capture(nt, gi.outputs["Geometry"], offset_g, 'FLOAT_VECTOR', (1060, 60))
    dens = _mesh_density_factor(nt, gi.outputs["Geometry"], (-1600, -1100))
    smooth = _blur(nt, off_cap, 'FLOAT_VECTOR',
                   _scaled_iters(nt, gi.outputs["Smoothing"], dens,
                                 (-1400, -1100)),
                   0.85, (1300, -120))
    out_geo = _set_position(nt, geo_c, (1520, 0), offset=smooth)
    return _finish_tree(nt, go, out_geo)


TAU = 6.283185307


# ---------------------------------------------------------------------------
# 5) PENETRATION — canal de tejido blando: agarre envolvente sin clipping,
#    apertura/cierre stateless (gratis por el conform), pulso de contracción
#    y jiggle secundario. Núcleo: penetración + agarre (grip/clenching).
#
#    Filosofía SquishyFX: 100% procedural (proximity + raycast + normales),
#    sin simulación pesada. El conform sin-clipping ya da la APERTURA (el
#    eje desplaza las paredes hacia fuera) y el CIERRE (al salir, todo
#    vuelve al reposo, stateless). Encima:
#      * AGARRE: la carne del anillo circundante (fuera del eje) se tira
#        hacia la superficie del eje —envolviéndolo— con un tope duro a
#        Collision Offset para que NUNCA cruce (sin clipping).
#      * CONTRACCIÓN: el agarre se modula con un pulso senoidal (gate Play).
#      * JIGGLE: ruido 4D en la carne cercana, escalado por la energía del
#        impulso (responde al empuje). Gate Play.
#      * WETNESS: atributo "squishyfx_wet" para el shader (specular/sheen).
#
#    Penetrador = el objeto en "Collision Object" (o cualquiera de la
#    colección). Topología recomendada: canal = tubo de anillos de quads
#    (16-24 radiales), pesos de máscara 1.0 en el borde -> 0.3 al fondo;
#    penetrador = cápsula/cilindro CERRADO (manifold) con punta redondeada.
# ---------------------------------------------------------------------------

def build_penetration(name=NAME_PENETRATION):
    nt, gi, go = _base_tree(name)

    _sock(nt, "Mask", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 1.0, 'FACTOR',
          "Vertex Group weight of the channel: 1 at the entry rim, "
          "falling off inward; 0 on flesh that must not move")
    _sock(nt, "Grip Intensity", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 2.0,
          None, "How strongly the walls wrap and squeeze the axis")
    _sock(nt, "Tightness", 'INPUT', 'NodeSocketFloat', 0.6, 0.0, 1.0,
          'FACTOR', "How tight the grip sits: 1 = skin against the axis")
    _sock(nt, "Reach", 'INPUT', 'NodeSocketFloat', 0.03, 0.002, 0.3, None,
          "Distance (m) over which the surrounding flesh is gripped")
    _sock(nt, "Clench Amount", 'INPUT', 'NodeSocketFloat', 0.3, 0.0, 1.0,
          'FACTOR', "Amplitude of the pulsing clench (PLAYBACK ONLY)")
    _sock(nt, "Clench Speed", 'INPUT', 'NodeSocketFloat', 3.0, 0.0, 20.0,
          None, "Speed of the pulses/clenches (PLAYBACK ONLY)")
    _sock(nt, "Jiggle", 'INPUT', 'NodeSocketFloat', 0.4, 0.0, 2.0, None,
          "Organic secondary motion of the flesh while pushing (ON PLAYBACK)")
    _sock(nt, "Wetness", 'INPUT', 'NodeSocketFloat', 0.5, 0.0, 1.0, 'FACTOR',
          "Writes the 'squishyfx_wet' attribute for the shader (sheen/"
          "humedad); no deforma")
    _sock(nt, "Collision Offset", 'INPUT', 'NodeSocketFloat', 0.006, 0.0,
          0.2, None, "Skin thickness: minimum clearance above the axis "
          "(the grip's anti-clipping cap)")
    _sock(nt, "Smoothing", 'INPUT', 'NodeSocketInt', 3, 0, 10, None,
          "Final smoothing of the channel deformation")
    _impact_sockets(nt)
    playing = _sock(nt, "Playing", 'INPUT', 'NodeSocketFloat', 0.0, 0.0, 1.0,
                    'FACTOR', "Internal: 1 during playback (written "
                    "by the addon; do not edit)")
    drag = _sock(nt, "Drag", 'INPUT', 'NodeSocketVector', (0.0, 0.0, 0.0),
                 None, None, None, "Internal: per-frame displacement of "
                 "the penetrator in contact (written by the addon); the flesh "
                 "follows it = tension/drag on entry and exit")
    for hidden in (playing, drag):
        try:
            hidden.hide_in_modifier = True
        except AttributeError:
            pass
    _collider_sockets(nt)
    _self_collision_sock(nt)   # último socket: no desplazar los Socket_N

    collider, collider_obj = _collider_geometry(nt, gi)
    pos = _node(nt, 'GeometryNodeInputPosition', (-2100, -200)).outputs["Position"]
    nrm = _node(nt, 'GeometryNodeInputNormal', (-2100, -360)).outputs["Normal"]
    dens = _mesh_density_factor(nt, gi.outputs["Geometry"], (-2100, 1100))
    mask = gi.outputs["Mask"]

    # --- APERTURA + NO-CLIP: conform contra el eje (paredes sobre la
    # superficie, sin atravesar). Stateless: eje dentro -> paredes fuera;
    # eje fuera -> reposo. Usa collider_obj (el penetrador), no self.
    conform, inside_f, _pen = _flesh_conform(
        nt, gi, collider_obj, pos, nrm, gi.outputs["Collision Offset"],
        0.0, loc=(-1700, 700))
    dent = _vmath(nt, 'SCALE', conform, scale=_clamp01(nt, mask, (-1500, 500)),
                  loc=(-1300, 500), label="Apertura (conform)")

    # --- AGARRE ENVOLVENTE: la carne FUERA del eje se tira hacia su
    # superficie, con tope duro para no cruzarla (sin clipping).
    prox = _node(nt, 'GeometryNodeProximity', (-1700, -600),
                 target_element='FACES')
    _plug(nt, _input(prox, "Geometry", "Target"), collider_obj)
    _plug(nt, _input(prox, "Sample Position"), pos)
    closest, dist = prox.outputs["Position"], prox.outputs["Distance"]

    # --- ENGAGEMENT GLOBAL: el efecto se extiende a TODA la zona con pesos
    # (no solo el agujero), guiado por el PESO de cada vértice y por cuánto
    # estira el eje el canal EN CONJUNTO. El pico de estiramiento sobre la
    # máscara escala el arrastre de toda la carne enmascarada. Sin
    # penetración (estiramiento 0) -> reposo total. Así la vagina entera se
    # mueve siguiendo el empuje, con intensidad por el peso del vertex group.
    stretch = _vmath(nt, 'LENGTH', conform, loc=(-1300, 300))
    eng_stat = _node(nt, 'GeometryNodeAttributeStatistic', (-1120, 300),
                     data_type='FLOAT', domain='POINT')
    _plug(nt, eng_stat.inputs["Geometry"], gi.outputs["Geometry"])
    _plug(nt, _input(eng_stat, "Attribute"),
          _math(nt, 'MULTIPLY', stretch, mask, (-1300, 160)))
    engagement = _math(nt, 'MINIMUM',
                       _math(nt, 'DIVIDE', eng_stat.outputs["Max"], 0.005,
                             (-940, 300)),
                       1.2, (-760, 300), "Engagement (penetration)")

    # pulso de contracción (modula la fuerza del agarre; oscila solo en Play)
    time = _node(nt, 'GeometryNodeInputSceneTime', (-1500, -1260))
    isvp = _node(nt, 'GeometryNodeIsViewport', (-1320, -1420))
    play_gate = _switch(nt, 'FLOAT', isvp.outputs["Is Viewport"], 1.0,
                        gi.outputs["Playing"], (-1140, -1420))
    clench = _math(nt, 'SINE',
                   _math(nt, 'MULTIPLY',
                         _math(nt, 'MULTIPLY', time.outputs["Seconds"],
                               gi.outputs["Clench Speed"], (-1320, -1260)),
                         TAU, (-1140, -1260)),
                   None, (-960, -1260))
    pulse = _math(nt, 'ADD', 1.0,
                  _math(nt, 'MULTIPLY',
                        _math(nt, 'MULTIPLY', clench, gi.outputs["Clench Amount"],
                              (-780, -1260)),
                        play_gate, (-600, -1300)),
                  (-420, -1260), "Clench pulse")

    # --- ARRASTRE AXIAL (grip realista): la carne en contacto SIGUE el
    # desplazamiento del penetrador (socket "Drag", escrito por el addon
    # cada frame = fricción). Al ENTRAR, el eje la estira/arrastra hacia
    # dentro = tensión y agarre; al SALIR, la carne lo sigue de vuelta y el
    # conform stateless la devuelve al reposo. NO tira de la carne HACIA el
    # eje (eso la encogía): sigue la DIRECCIÓN del empuje. Tightness escala
    # cuánto se pega la carne al movimiento del eje.
    # Fuerza de arrastre = Grip Intensity · ENGAGEMENT global · (tightness) ·
    # pulso · PESO del vértice. El PESO es el gradiente espacial: toda la
    # zona con pesos se mueve, más donde el peso es mayor. Sin engagement
    # (sin penetración) -> 0 en todos lados.
    follow = _math(nt, 'MULTIPLY',
                   _math(nt, 'MULTIPLY',
                         _math(nt, 'MULTIPLY',
                               _math(nt, 'MULTIPLY',
                                     gi.outputs["Grip Intensity"],
                                     engagement, (-780, -940)),
                               _math(nt, 'ADD', 0.3,
                                     _math(nt, 'MULTIPLY', gi.outputs["Tightness"],
                                           0.7, (-620, -1080)),
                                     (-440, -1060)), (-260, -1000)),
                         pulse, (-80, -1000)),
                   mask, (120, -940), "Drag fraction")
    wrap0 = _vmath(nt, 'SCALE', gi.outputs["Drag"], scale=follow, loc=(360, -700),
                   label="Arrastre axial")
    # LÍMITE DE ESTIRAMIENTO: la piel se estira y luego RESBALA sobre el eje
    # (no lo sigue sin fin). Tope = 2·Reach (mín 6 mm). Sin esto, un empuje
    # rápido arrastraba la carne decímetros. |wrap| <= limit.
    wmag = _vmath(nt, 'LENGTH', wrap0, loc=(540, -820))
    limit = _math(nt, 'MAXIMUM',
                  _math(nt, 'MULTIPLY', gi.outputs["Reach"], 2.0, (540, -960)),
                  0.006, (720, -960), "Stretch cap")
    wrap = _vmath(nt, 'SCALE', wrap0,
                  scale=_math(nt, 'DIVIDE',
                              _math(nt, 'MINIMUM', wmag, limit, (720, -820)),
                              _math(nt, 'MAXIMUM', wmag, 1e-6, (720, -700)),
                              (900, -780)), loc=(1080, -700), label="Arrastre")

    # --- JIGGLE secundario: ruido 4D en la carne cercana, escalado por la
    # energía del impulso (responde al empuje). Gate Play.
    noise = _node(nt, 'ShaderNodeTexNoise', (-1500, -1650),
                  noise_dimensions='4D')
    _plug(nt, noise.inputs["Vector"], pos)
    _plug(nt, noise.inputs["W"],
          _math(nt, 'MULTIPLY', time.outputs["Seconds"], 1.5, (-1700, -1720)))
    _plug(nt, noise.inputs["Scale"], 6.0)
    _plug(nt, noise.inputs["Detail"], 2.0)
    jvec = _vmath(nt, 'SUBTRACT', noise.outputs["Color"],
                  (0.5, 0.5, 0.5), loc=(-1200, -1650), label="Temblor")
    # jiggle sobre TODA la zona con pesos (no solo el contacto), guiado por
    # el peso y el engagement global. Escalado a mm (el ruido va en ±0.5).
    jig_amt = _math(nt, 'MULTIPLY',
                    _math(nt, 'MULTIPLY',
                          _math(nt, 'MULTIPLY', gi.outputs["Jiggle"],
                                gi.outputs["Energy"], (-660, -1650)),
                          _math(nt, 'MULTIPLY', mask, play_gate,
                                (-660, -1500)), (-480, -1600)),
                    engagement, (-300, -1600))
    jig_amt = _math(nt, 'MULTIPLY', jig_amt, 0.02, (60, -1600),
                    "Escala jiggle (mm)")
    jig = _vmath(nt, 'SCALE', jvec, scale=jig_amt, loc=(60, -1600),
                 label="Jiggle")

    # --- COMBINAR + suavizar + escribir posición
    offset = _vmath(nt, 'ADD', _vmath(nt, 'ADD', dent, wrap, loc=(700, -200)),
                    jig, loc=(900, -200), label="Desplazamiento canal")
    geo_c, off_cap = _capture(nt, gi.outputs["Geometry"], offset,
                              'FLOAT_VECTOR', (1080, 60))
    smooth = _blur(nt, off_cap, 'FLOAT_VECTOR',
                   _scaled_iters(nt, gi.outputs["Smoothing"], dens,
                                 (900, -420)), 0.85, (1280, -100))
    out_geo = _set_position(nt, geo_c, (1480, 0), offset=smooth)

    # --- WETNESS: atributo para el shader (no deforma la malla). Húmedo
    # donde el eje penetra/estira (inside + estiramiento local), por peso.
    wet = _math(nt, 'MULTIPLY',
                _math(nt, 'MULTIPLY',
                      _clamp01(nt,
                               _math(nt, 'ADD', inside_f,
                                     _math(nt, 'DIVIDE', stretch, 0.003,
                                           (1480, -520)), (1480, -420)),
                               (1660, -420)),
                      gi.outputs["Wetness"], (1840, -420)),
                mask, (2020, -420), "Humedad")
    wet_store = _node(nt, 'GeometryNodeStoreNamedAttribute', (2200, 0),
                      data_type='FLOAT', domain='POINT')
    _plug(nt, wet_store.inputs["Geometry"], out_geo)
    _plug(nt, _input(wet_store, "Name"), "squishyfx_wet")
    _plug(nt, _input(wet_store, "Value"), wet)

    return _finish_tree(nt, go, wet_store.outputs["Geometry"])


# ---------------------------------------------------------------------------
# 6) SQUISH ORGANIC — squish carnoso con rigidez por zonas + squash &
#    stretch por velocidad + jiggle post-golpe. Pensado para personajes
#    (look "soft body de Pixar") sin romper la arquitectura stateless.
#
#    * STIFFNESS por zonas: campo soft = Mask · (1 − Stiffness). Stiffness
#      se conecta como atributo/vertex group (0 = grasa, 1 = rígido) y
#      sustituye a Mask DENTRO del núcleo compartido vía `params`: el
#      contacto, el volumen apilado y el bulge respetan la rigidez local.
#    * COLLISION SOFTNESS: un solo slider deriva los tres knobs internos
#      calibrados del núcleo (Shape Smoothing, Spread, Contact Hardness).
#    * SQUASH & STRETCH: SIN Simulation Zone. La velocidad llega por el
#      socket oculto "Velocity" (el addon la escribe cada frame, patrón
#      Drag/Energy): comprime a lo largo del movimiento (factor s) y
#      expande lateralmente 1/sqrt(s) — compensación de volumen exacta
#      para escala axial s. El árbol sigue siendo stateless: vista EN
#      VIVO del contacto y reposo perfecto garantizados.
#    * JIGGLE secundario: ruido 4D sobre la carne recién golpeada (gate
#      por el halo del contacto), escalado por la energía de impulso.
#    * Acabado idéntico a Squish: mutual pass -> corrective smooth ->
#      anti-clip duro FINAL (el squash y el jiggle pueden re-meter
#      vértices en el colisionador; la garantía va la última).
# ---------------------------------------------------------------------------

def build_squish_organic(name=NAME_SQUISH_ORGANIC):
    nt, gi, go = _base_tree(name)

    _sock(nt, "Mask", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 1.0, 'FACTOR',
          "Vertex Group weight: 1 = deformable, 0 = rigid")
    _sock(nt, "Squish Intensity", 'INPUT', 'NodeSocketFloat', 1.0, 0.0, 2.0,
          None, "Velocity-driven squash & stretch: compresses along the direction "
          "of motion and expands laterally (PLAYBACK ONLY)")
    _sock(nt, "Direction Influence", 'INPUT', 'NodeSocketFloat', 0.7, 0.0,
          1.0, 'FACTOR', "Weight of the directional squash (compress along "
          "the motion + expand laterally); volume is "
          "preserved across the whole range")
    _sock(nt, "Volume Preservation", 'INPUT', 'NodeSocketFloat', 0.9, 0.0,
          2.0, None, "Volume preservation: lateral expansion of the "
          "squash (1/sqrt(s)) and bulging of the contact ring")
    _sock(nt, "Collision Strength", 'INPUT', 'NodeSocketFloat', 1.2, 0.0,
          2.0, None, "How much the flesh yields to the collider")
    _sock(nt, "Collision Softness", 'INPUT', 'NodeSocketFloat', 0.4, 0.0,
          1.0, 'FACTOR', "Organic softness of the contact: rounds the "
          "footprint, widens the halo and allows subtle overlap (drives "
          "the core's Shape Smoothing, Spread and Contact Hardness)")
    _sock(nt, "Stiffness", 'INPUT', 'NodeSocketFloat', 0.6, 0.0, 1.0,
          'FACTOR', "Per-zone stiffness: plug in a vertex group or "
          "attribute (0 = soft fat, 1 = rigid). The deformation is "
          "stronger where stiffness is low")
    _sock(nt, "Velocity Influence", 'INPUT', 'NodeSocketFloat', 1.0, 0.0,
          1.0, 'FACTOR', "Global attenuator of the velocity squash")
    _sock(nt, "Jiggle", 'INPUT', 'NodeSocketFloat', 0.4, 0.0, 2.0, None,
          "Secondary wobble of freshly struck flesh (ON PLAYBACK)")
    _sock(nt, "Collision Offset", 'INPUT', 'NodeSocketFloat', 0.015, 0.0,
          0.5, None, "Skin: extra distance above the collider")
    _impact_sockets(nt)
    velocity = _sock(nt, "Velocity", 'INPUT', 'NodeSocketVector',
                     (0.0, 0.0, 0.0), None, None, None,
                     "Internal: world velocity of the flesh (centroid "
                     "of the mask); written by the addon every frame")
    playing = _sock(nt, "Playing", 'INPUT', 'NodeSocketFloat', 0.0, 0.0,
                    1.0, 'FACTOR', "Internal: 1 during playback "
                    "(lo escribe by the addon; do not edit)")
    for hidden in (velocity, playing):
        try:
            hidden.hide_in_modifier = True
        except AttributeError:
            pass
    _collider_sockets(nt)
    _self_collision_sock(nt)   # último socket: no desplazar los Socket_N

    collider, _obj_only = _collider_geometry(nt, gi)

    # Campo de blandura por zonas: sustituye a Mask dentro del núcleo.
    soft = _clamp01(nt,
                    _math(nt, 'MULTIPLY', gi.outputs["Mask"],
                          _math(nt, 'SUBTRACT', 1.0,
                                gi.outputs["Stiffness"], (-2300, -700)),
                          (-2140, -700), "Blandura Mask·(1-Stiffness)"),
                    (-1960, -700))

    softness = gi.outputs["Collision Softness"]
    params = {
        "Mask": soft,
        "Shape Smoothing": _math(nt, 'ADD', 3.0,
                                 _math(nt, 'MULTIPLY', softness, 9.0,
                                       (-2300, -900)), (-2140, -900)),
        "Spread": _math(nt, 'ADD', 4.0,
                        _math(nt, 'MULTIPLY', softness, 14.0,
                              (-2300, -1050)), (-2140, -1050)),
        "Contact Hardness": _math(nt, 'SUBTRACT', 1.0,
                                  _math(nt, 'MULTIPLY', softness, 0.5,
                                        (-2300, -1200)), (-2140, -1200)),
        # Fijos calibrados: sin slider propio para no engordar el panel.
        "Lateral Flow": 0.5,
        "Splay": 0.5,
    }

    geo3, halo, _d, dens = _natural_squish_core(
        nt, gi, collider, "Collision Strength", params)

    # --- SQUASH & STRETCH por velocidad (stateless; "Velocity" del addon).
    bx, by = 1000, -1600
    vel = gi.outputs["Velocity"]
    speed = _vmath(nt, 'LENGTH', vel, loc=(bx, by))
    vdir = _vmath(nt, 'NORMALIZE', vel, loc=(bx, by - 140))
    # Sin movimiento real no hay bloque: reposo bit-perfecto.
    gate_v = _switch(nt, 'FLOAT',
                     _compare(nt, 'FLOAT', 'GREATER_THAN', speed, 1e-3,
                              (bx + 180, by)),
                     0.0, 1.0, (bx + 360, by))
    isvp = _node(nt, 'GeometryNodeIsViewport', (bx, by + 200))
    play_gate = _switch(nt, 'FLOAT', isvp.outputs["Is Viewport"], 1.0,
                        gi.outputs["Playing"], (bx + 180, by + 200))

    # Centroide de la carne blanda (ponderado por soft, zero-safe): el
    # squash pivota sobre el centro de la zona enmascarada, no del objeto.
    geo_sc, soft_cap = _capture(nt, geo3, soft, 'FLOAT', (bx, by - 320))
    pos_q = _node(nt, 'GeometryNodeInputPosition',
                  (bx, by - 480)).outputs["Position"]
    stat_s = _node(nt, 'GeometryNodeAttributeStatistic', (bx + 200, by - 320),
                   data_type='FLOAT', domain='POINT')
    _plug(nt, stat_s.inputs["Geometry"], geo_sc)
    _plug(nt, _input(stat_s, "Attribute"), soft_cap)
    stat_p = _node(nt, 'GeometryNodeAttributeStatistic', (bx + 200, by - 500),
                   data_type='FLOAT_VECTOR', domain='POINT')
    _plug(nt, stat_p.inputs["Geometry"], geo_sc)
    _plug(nt, _input(stat_p, "Attribute"),
          _vmath(nt, 'SCALE', pos_q, scale=soft_cap, loc=(bx, by - 620)))
    inv_s = _math(nt, 'DIVIDE', 1.0,
                  _math(nt, 'MAXIMUM', stat_s.outputs["Mean"], 1e-6,
                        (bx + 420, by - 320)),
                  (bx + 600, by - 320))
    centroid = _vmath(nt, 'SCALE', stat_p.outputs["Mean"], scale=inv_s,
                      loc=(bx + 600, by - 500), label="Centroide blando")

    # Factor de compresión s ∈ [0.4, 1]: 1/(1+k·drive), k=0.15 (a 2 m/s
    # con Intensity 1 y soft 1 => s≈0.77, rango cartoon sin ser sello).
    drive = _math(nt, 'MULTIPLY',
                  _math(nt, 'MULTIPLY',
                        _math(nt, 'MULTIPLY', speed,
                              gi.outputs["Squish Intensity"],
                              (bx + 420, by - 60)),
                        gi.outputs["Velocity Influence"],
                        (bx + 600, by - 60)),
                  _math(nt, 'MULTIPLY', soft_cap, 0.15, (bx + 420, by - 180)),
                  (bx + 780, by - 60), "Squash drive")
    s = _math(nt, 'MAXIMUM',
              _math(nt, 'DIVIDE', 1.0,
                    _math(nt, 'ADD', 1.0, drive, (bx + 960, by - 60)),
                    (bx + 1140, by - 60)),
              0.4, (bx + 1320, by - 60), "s (compression)")
    # Expansión lateral 1/sqrt(s), dosificada por Volume Preservation
    # (clampada a 1: el exceso del socket solo alimenta el bulge del core).
    s_lat = _math(nt, 'ADD', 1.0,
                  _math(nt, 'MULTIPLY',
                        _math(nt, 'SUBTRACT',
                              _math(nt, 'POWER', s, -0.5,
                                    (bx + 1320, by - 220)),
                              1.0, (bx + 1500, by - 220)),
                        _clamp01(nt, gi.outputs["Volume Preservation"],
                                 (bx + 1320, by - 380)),
                        (bx + 1680, by - 220)),
                  (bx + 1860, by - 220), "s_lat (1/sqrt s)")

    # Descomposición axial/lateral alrededor del centroide.
    p_rel = _vmath(nt, 'SUBTRACT', pos_q, centroid, loc=(bx + 800, by - 500))
    ax_len = _vmath(nt, 'DOT_PRODUCT', p_rel, vdir, loc=(bx + 980, by - 560))
    axial = _vmath(nt, 'SCALE', vdir, scale=ax_len, loc=(bx + 1160, by - 560))
    lateral = _vmath(nt, 'SUBTRACT', p_rel, axial, loc=(bx + 1340, by - 500))
    p_dir = _vmath(nt, 'ADD', centroid,
                   _vmath(nt, 'ADD',
                          _vmath(nt, 'SCALE', axial, scale=s,
                                 loc=(bx + 1520, by - 560)),
                          _vmath(nt, 'SCALE', lateral, scale=s_lat,
                                 loc=(bx + 1520, by - 440)),
                          loc=(bx + 1700, by - 500)),
                   loc=(bx + 1880, by - 500), label="Squash direccional")
    # Direction Influence escala el squash direccional contra el REPOSO,
    # no contra una compresión uniforme: mezclar con esta última cancelaba
    # la expansión lateral en valores medios (medido en el grid de test:
    # a DI=0.7, Y quedaba en 1.004 en vez de 1.037 y el volumen perdía un
    # 10%). Contra el reposo, el volumen se conserva en TODO el slider
    # (p_dir lo conserva por construcción y pos trivialmente).
    off_v = _vmath(nt, 'SCALE',
                   _vmath(nt, 'SCALE',
                          _vmath(nt, 'SCALE',
                                 _vmath(nt, 'SUBTRACT', p_dir, pos_q,
                                        loc=(bx + 2060, by - 560)),
                                 scale=gi.outputs["Direction Influence"],
                                 loc=(bx + 2240, by - 560)),
                          scale=gate_v, loc=(bx + 2420, by - 560)),
                   scale=play_gate, loc=(bx + 2600, by - 560),
                   label="Offset squash")
    geo_sc2, off_cap = _capture(nt, geo_sc, off_v, 'FLOAT_VECTOR',
                                (bx + 3140, by - 400))
    off_smooth = _blur(nt, off_cap, 'FLOAT_VECTOR',
                       _scaled_iters(nt, 3.0, dens, (bx + 3140, by - 640)),
                       0.85, (bx + 3340, by - 480))
    geo4 = _set_position(nt, geo_sc2, (bx + 3540, by - 400),
                         offset=off_smooth)

    # --- JIGGLE secundario post-colisión: solo la carne recién golpeada
    # (gate por halo) y solo con energía de impulso (nalgada -> temblor
    # que decae con Relax Time; contacto sostenido inmóvil -> nada).
    jx, jy = 1000, -2600
    time = _node(nt, 'GeometryNodeInputSceneTime', (jx, jy))
    noise = _node(nt, 'ShaderNodeTexNoise', (jx + 200, jy),
                  noise_dimensions='4D')
    _plug(nt, noise.inputs["Vector"], pos_q)
    _plug(nt, noise.inputs["W"],
          _math(nt, 'MULTIPLY', time.outputs["Seconds"], 2.0,
                (jx, jy - 160)))
    _plug(nt, noise.inputs["Scale"], 5.0)
    _plug(nt, noise.inputs["Detail"], 2.0)
    _plug(nt, noise.inputs["Roughness"], 0.55)
    nrm_j = _node(nt, 'GeometryNodeInputNormal', (jx, jy - 300)).outputs["Normal"]
    jvec = _vmath(nt, 'SUBTRACT', noise.outputs["Color"], (0.5, 0.5, 0.5),
                  loc=(jx + 420, jy), label="Ruido centrado")
    wn = _vmath(nt, 'DOT_PRODUCT', jvec, nrm_j, loc=(jx + 600, jy - 60))
    w_tang = _vmath(nt, 'SUBTRACT', jvec,
                    _vmath(nt, 'SCALE', nrm_j, scale=wn,
                           loc=(jx + 600, jy - 200)),
                    loc=(jx + 780, jy - 120))
    jig = _vmath(nt, 'ADD', w_tang,
                 _vmath(nt, 'SCALE', nrm_j,
                        scale=_math(nt, 'MULTIPLY', wn, 0.6,
                                    (jx + 780, jy - 320)),
                        loc=(jx + 960, jy - 300)),
                 loc=(jx + 1140, jy - 160), label="Temblor")
    contact = _math(nt, 'MINIMUM',
                    _math(nt, 'MULTIPLY', halo, 6.0, (jx + 600, jy - 460)),
                    1.0, (jx + 780, jy - 460), "Contact gate")
    amp_j = _math(nt, 'MULTIPLY',
                  _math(nt, 'MULTIPLY',
                        _math(nt, 'MULTIPLY', gi.outputs["Jiggle"],
                              gi.outputs["Energy"], (jx + 960, jy - 460)),
                        _math(nt, 'MULTIPLY', soft_cap, contact,
                              (jx + 960, jy - 600)),
                        (jx + 1140, jy - 520)),
                  _math(nt, 'MULTIPLY', play_gate, 0.05,
                        (jx + 1140, jy - 680)),
                  (jx + 1320, jy - 520), "Amplitud jiggle")
    geo5 = _set_position(nt, geo4, (jx + 1500, jy - 300),
                         offset=_vmath(nt, 'SCALE', jig, scale=amp_j,
                                       loc=(jx + 1320, jy - 300)))

    # --- Acabado compartido: auto-contacto, suavizado y garantía dura.
    geo6 = _mutual_squish_pass(nt, gi, geo5, dens, (3600, 1200))
    geo7 = _corrective_smooth(
        nt, geo6, halo, _scaled_iters(nt, 3.0, dens, (3600, 300)),
        (3800, 60))
    geo8 = _hard_anticlip(nt, gi, collider, geo7, (4100, 700))
    return _finish_tree(nt, go, geo8)


# ---------------------------------------------------------------------------
# Registro de builders
# ---------------------------------------------------------------------------

BUILDERS = {
    'SQUISH': (NAME_SQUISH, build_squish),
    'RIPPLE': (NAME_RIPPLE, build_ripple),
    'SQUISH_INFLATE': (NAME_SQUISH_INFLATE, build_squish_inflate),
    'JIGGLE': (NAME_JIGGLE, build_jiggle),
    'PENETRATION': (NAME_PENETRATION, build_penetration),
    'SQUISH_ORGANIC': (NAME_SQUISH_ORGANIC, build_squish_organic),
}


def get_or_create_tree(effect):
    tree_name, builder = BUILDERS[effect]
    nt = bpy.data.node_groups.get(tree_name)
    if nt is None:
        nt = builder()
    return nt


def rebuild_all_trees():
    for effect, (tree_name, builder) in BUILDERS.items():
        old = bpy.data.node_groups.get(tree_name)
        if old is not None:
            old.name = tree_name + "_old"
            new = builder(tree_name)
            old.user_remap(new)
            bpy.data.node_groups.remove(old)
        else:
            builder(tree_name)
    for legacy in LEGACY_TREES:
        old = bpy.data.node_groups.get(legacy)
        if old is not None and old.users == 0:
            bpy.data.node_groups.remove(old)
