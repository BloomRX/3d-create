# -*- coding: utf-8 -*-
"""
SquishyFX — build de distribución (Auron3D).

Genera dos zips instalables en el Escritorio:

  SquishyFX-vX.Y.Z-source.zip    fuente completa (tu copia maestra y la
                                 versión válida para marketplaces que
                                 exigen cumplimiento GPL, p. ej.
                                 Blender Market / Extensions)
  SquishyFX-vX.Y.Z-compiled.zip  bytecode (.pyc) sin fuente: disuade la
                                 copia casual. El __init__.py se queda en
                                 texto plano (mínimo: bl_info + registro)
                                 porque Blender lo lee para listar el
                                 addon; toda la lógica (geometry_nodes,
                                 operators, presets, ui, properties) va
                                 compilada.

LÍMITES DEL COMPILADO (léelos antes de vender):
  * El bytecode está atado a la versión de Python de Blender: este build
    usa el Python 3.13 de Blender 5.2 — NO carga en Blender ≤4.x
    (Python distinto). Para cada serie de Blender hay que rebuilder con
    su Python.
  * .pyc es disuasión, no protección: existen descompiladores. Nada que
    Blender pueda ejecutar es imposible de leer para alguien decidido.

Uso:
  "C:/Program Files/Blender Foundation/Blender 5.2/5.2/python/bin/python.exe" build_release.py
"""

import os
import py_compile
import re
import shutil
import sys
import tempfile
import zipfile

SRC = os.path.dirname(os.path.abspath(__file__))
DESKTOP = os.path.join(os.path.expanduser("~"), "Desktop")
MODULES = ["geometry_nodes", "operators", "presets", "properties", "ui"]
EXTRA = ["README.md"]


def addon_version():
    init = open(os.path.join(SRC, "__init__.py"), encoding="utf-8").read()
    m = re.search(r'"version":\s*\((\d+),\s*(\d+),\s*(\d+)\)', init)
    return ".".join(m.groups())


def build_zip(out_path, compiled):
    tmp = tempfile.mkdtemp()
    pkg = os.path.join(tmp, "squishyfx")
    os.makedirs(pkg)
    # __init__.py siempre en fuente: Blender lee bl_info del .py
    shutil.copy(os.path.join(SRC, "__init__.py"), pkg)
    for name in EXTRA:
        p = os.path.join(SRC, name)
        if os.path.isfile(p):
            shutil.copy(p, pkg)
    for mod in MODULES:
        src_py = os.path.join(SRC, mod + ".py")
        if compiled:
            # .pyc "sourceless" junto al __init__: el import de Python lo
            # carga igual que un .py (SourcelessFileLoader)
            py_compile.compile(src_py, cfile=os.path.join(pkg, mod + ".pyc"),
                               doraise=True)
        else:
            shutil.copy(src_py, pkg)
    if os.path.exists(out_path):
        os.remove(out_path)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as z:
        for root, _dirs, files in os.walk(tmp):
            for f in files:
                full = os.path.join(root, f)
                z.write(full, os.path.relpath(full, tmp))
    shutil.rmtree(tmp)
    return out_path


def main():
    ver = addon_version()
    pyver = f"{sys.version_info.major}.{sys.version_info.minor}"
    src_zip = build_zip(
        os.path.join(DESKTOP, f"SquishyFX-v{ver}-source.zip"), compiled=False)
    cmp_zip = build_zip(
        os.path.join(DESKTOP, f"SquishyFX-v{ver}-compiled.zip"), compiled=True)
    print(f"OK  {src_zip}")
    print(f"OK  {cmp_zip}  (bytecode Python {pyver} — Blender con ese Python)")


if __name__ == "__main__":
    main()
