# -*- coding: utf-8 -*-
"""
SquishyFX - operators.py  (v1.1 — física reactiva a colisiones)
Operadores: aplicar efectos, presets, detección/creación de colisionadores,
eliminar efectos, bake a Shape Keys y reconstrucción de node groups.
"""

import bpy
from bpy.types import Operator
from bpy.props import EnumProperty, StringProperty
from bpy.app.handlers import persistent

from . import geometry_nodes as gn
from .presets import (
    PRESETS,
    all_presets,
    save_custom_preset,
    delete_custom_preset,
)

COLLIDER_COLLECTION = "SquishyFX Colliders"

EFFECT_ITEMS = [
    ('SQUISH', "Squish",
     "LIVE: the mesh dents and bulges wherever the collider touches it "
     "(no timeline playback needed)",
     'MOD_SIMPLEDEFORM', 0),
    ('RIPPLE', "Ripple",
     "LIVE: footprint + waves around the contact (the phase animates on "
     "playback)",
     'MOD_WAVE', 1),
    ('SQUISH_INFLATE', "Squish & Inflate",
     "LIVE: contact dent + reactive inflation of the rest",
     'MOD_CAST', 2),
    ('JIGGLE', "Fat Jiggle",
     "PLAYBACK ONLY: fat wobble (glutes, thighs) around the contact, "
     "with lateral slosh and bounce",
     'MOD_NOISE', 3),
    ('PENETRATION', "Penetration",
     "Soft-tissue channel: opening/closing and a wrapping grip without "
     "clipping around the penetrator (LIVE); pulsing clenches and jiggle "
     "ON PLAYBACK. Mask = the channel; penetrator = Collision Object",
     'MESH_CYLINDER', 4),
    ('SQUISH_ORGANIC', "Squish Organic",
     "Fleshy squish with per-zone stiffness (Stiffness attribute: 0 = fat, "
     "1 = rigid); LIVE contact, velocity-driven squash & stretch with "
     "volume preservation and post-impact jiggle ON PLAYBACK",
     'MOD_SOFT', 5),
]

EFFECT_LABELS = {item[0]: item[1] for item in EFFECT_ITEMS}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def input_identifier(tree, socket_name):
    for item in tree.interface.items_tree:
        if (getattr(item, "item_type", "") == 'SOCKET'
                and item.in_out == 'INPUT'
                and item.name == socket_name):
            return item.identifier
    return None


def input_socket_items(tree):
    for item in tree.interface.items_tree:
        if (getattr(item, "item_type", "") == 'SOCKET'
                and item.in_out == 'INPUT'
                and item.socket_type != 'NodeSocketGeometry'):
            yield item


def _cast_value(socket_type, value):
    if 'Int' in socket_type:
        return int(value)
    if 'Bool' in socket_type:
        return bool(value)
    if 'Float' in socket_type:
        return float(value)
    return value


def force_modifier_update(obj):
    obj.update_tag()
    if bpy.context.view_layer:
        bpy.context.view_layer.update()


# ---------------------------------------------------- compat inputs 4.x/5.2
# Blender 5.2 eliminó las IDProperties del NodesModifier: los valores viven
# en mod.properties.inputs.<identifier> (struct con .value, .type
# ['VALUE'|'ATTRIBUTE'] y .attribute_name). Estas funciones abstraen ambas
# APIs para que el addon funcione de 4.2 a 5.2+.

def _sock_struct(mod, ident):
    props = getattr(mod, "properties", None)
    inputs = getattr(props, "inputs", None) if props is not None else None
    if inputs is not None:
        return getattr(inputs, ident, None)
    return None


def mod_input_exists(mod, ident):
    if _sock_struct(mod, ident) is not None:
        return True
    try:
        return ident in mod.keys()
    except TypeError:
        return False


def mod_get_input(mod, ident, default=None):
    s = _sock_struct(mod, ident)
    if s is not None:
        return getattr(s, "value", default)
    try:
        return mod.get(ident, default)
    except TypeError:
        return default


def mod_set_input(mod, ident, value):
    s = _sock_struct(mod, ident)
    if s is not None:
        s.value = value
        return True
    try:
        mod[ident] = value
        return True
    except TypeError:
        return False


def mod_get_attribute(mod, ident):
    s = _sock_struct(mod, ident)
    if s is not None:
        if getattr(s, "type", 'VALUE') == 'ATTRIBUTE':
            return s.attribute_name
        return ""
    try:
        if mod.get(f"{ident}_use_attribute"):
            return mod.get(f"{ident}_attribute_name", "")
    except TypeError:
        pass
    return ""


def mod_set_attribute(mod, ident, attr_name):
    s = _sock_struct(mod, ident)
    if s is not None:
        s.type = 'ATTRIBUTE'
        s.attribute_name = attr_name
        return True
    try:
        mod[f"{ident}_use_attribute"] = True
        mod[f"{ident}_attribute_name"] = attr_name
        return True
    except TypeError:
        return False


def is_squishyfx_modifier(mod):
    return (mod.type == 'NODES'
            and mod.node_group is not None
            and mod.node_group.name.startswith(gn.PREFIX))


# ------------------------------------------------------------- colisionadores

def is_collider(obj):
    """Un objeto cuenta como colisionador si tiene la física Collision de
    Blender activada (modifier COLLISION o settings.use)."""
    if obj.type != 'MESH':
        return False
    if any(m.type == 'COLLISION' for m in obj.modifiers):
        return True
    settings = getattr(obj, "collision", None)
    return bool(settings and getattr(settings, "use", False))


def collider_cycle_risk(obj):
    """True si usar `obj` como colisionador crearía un CICLO de dependencias
    que mata la evaluación del efecto.

    Caso medido: el usuario duplicó los brazos del personaje (con su
    modifier Armature) y los metió en la colección. El esqueleto tenía
    constraints de hueso (Copy Location de huesos faciales auxiliares)
    apuntando a la malla del personaje → efecto(personaje) → colección →
    brazo → armature → constraint → malla del personaje = ciclo. El
    depsgraph lo rompe donde le conviene y el efecto queda en 0 SIN
    NINGÚN ERROR VISIBLE. Un colisionador así se excluye con aviso; la
    alternativa correcta para partes del propio cuerpo es Self Collision
    (misma malla, sin dependencias externas).
    """
    if any(is_squishyfx_modifier(m) for m in obj.modifiers):
        return True  # un colisionador con SquishyFX se lee a sí mismo
    sfx_targets = {ob for ob in bpy.data.objects
                   if ob.type == 'MESH'
                   and any(is_squishyfx_modifier(m) for m in ob.modifiers)}
    if not sfx_targets:
        return False
    if obj in sfx_targets:
        return True
    for m in obj.modifiers:
        arm = getattr(m, "object", None)
        if m.type != 'ARMATURE' or arm is None or arm.pose is None:
            continue
        for pb in arm.pose.bones:
            for c in pb.constraints:
                if getattr(c, "target", None) in sfx_targets:
                    return True
    return False


# --------------------------------------------------- proxy cerrado de colisión
# Un colisionador PROBLEMÁTICO —posado por un rig que depende del objetivo
# (ciclo de dependencias → el árbol lo ve en REPOSO, geometría obsoleta que no
# solapa nada → efecto 0), o un casco ABIERTO/no-manifold (el test de interior
# por raycast se cuela por los agujeros → el conform se pliega y fuga clip)—
# se sustituye por un PROXY: un snapshot de su geometría EVALUADA (posada), en
# espacio mundo, CERRADO por voxel remesh. Así CUALQUIER malla (abierta,
# no-manifold, auto-intersecante o riggeada) se comporta como un colisionador
# sólido y limpio. Medido en la malla del usuario: sin proxy, +291 pliegues y
# 47 mm de clip; con proxy cerrado, clip 0 y CERO auto-intersección añadida —
# idéntico a una esfera simple.
COLLIDER_PROXY_PREFIX = "SFX_Proxy_"
_proxy_building = [False]      # guarda contra reentrada en los handlers
_mesh_open_cache = {}          # (malla, nº verts) -> bool casco abierto


def _mesh_is_open(obj):
    """True si la malla base tiene aristas no-manifold (casco abierto).
    Cacheado por (malla, nº verts): recorrer bmesh en cada redraw sería caro."""
    me = obj.data
    key = (me.name, len(me.vertices))
    hit = _mesh_open_cache.get(key)
    if hit is not None:
        return hit
    import bmesh
    bm = bmesh.new()
    try:
        bm.from_mesh(me)
        open_hull = any(not e.is_manifold for e in bm.edges)
    finally:
        bm.free()
    _mesh_open_cache[key] = open_hull
    return open_hull


def collider_needs_proxy(obj):
    """El colisionador necesita un proxy cerrado si crea un ciclo (posado por
    un rig que depende del objetivo) o si es un casco abierto/no-manifold."""
    return collider_cycle_risk(obj) or _mesh_is_open(obj)


def _proxy_voxel_size(obj):
    """Voxel del remesh según la diagonal de la bbox mundo: fino para
    conservar detalle (dedos), con suelo/techo para no colapsar ni petar.

    diag/90 (~5.5 mm en unas manos) conserva los dedos y deja el proxy
    pegado a la malla real visible; un voxel grueso (diag/45) los achataba
    a burbujas y el seno conformaba a una forma que no coincidía con los
    dedos reales. Suelo 3 mm / techo 15 mm acota coste y colapso."""
    from mathutils import Vector
    bb = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    diag = (bb[6] - bb[0]).length
    return min(max(diag / 90.0, 0.003), 0.015)


def _rebuild_proxy_mesh(context, src, proxy):
    """(Re)construye la malla del proxy desde la geometría EVALUADA (posada)
    de src, en mundo, cerrada por voxel remesh. proxy queda en identidad
    (la geometría ya va en mundo, como espera CollectionInfo del árbol).

    DEBE correr bajo el guard _proxy_building: enlazar el objeto temporal
    dispara depsgraph_update y re-entraría en el autosync."""
    from mathutils import Matrix
    dg = context.evaluated_depsgraph_get()
    snap = bpy.data.meshes.new_from_object(src.evaluated_get(dg))
    snap.transform(src.matrix_world)
    tmp = bpy.data.objects.new(COLLIDER_PROXY_PREFIX + "_tmp", snap)
    rem = tmp.modifiers.new("Voxel", 'REMESH')
    rem.mode = 'VOXEL'
    rem.voxel_size = _proxy_voxel_size(src)
    rem.adaptivity = 0.0
    context.scene.collection.objects.link(tmp)
    try:
        dg2 = context.evaluated_depsgraph_get()
        closed = bpy.data.meshes.new_from_object(tmp.evaluated_get(dg2))
    finally:
        context.scene.collection.objects.unlink(tmp)
        bpy.data.objects.remove(tmp)
        if snap.users == 0:
            bpy.data.meshes.remove(snap)
    old = proxy.data
    proxy.data = closed
    proxy.matrix_basis = Matrix.Identity(4)
    if old is not None and old.users == 0:
        bpy.data.meshes.remove(old)


def _ensure_proxy(context, src, refresh=True):
    """Objeto proxy para el colisionador src (creado si falta, malla
    reconstruida si refresh). Va oculto (sigue colisionando estando oculto).

    refresh=False y sin proxy previo -> devuelve None: el autosync del
    depsgraph NO construye geometría (caro/arriesgado en un handler); la
    construcción la hace un operador (Detect/apply) o el bake."""
    name = COLLIDER_PROXY_PREFIX + src.name
    proxy = bpy.data.objects.get(name)
    if proxy is None:
        if not refresh:
            return None
        proxy = bpy.data.objects.new(name, bpy.data.meshes.new(name))
        proxy.hide_render = True
        proxy.hide_viewport = True
    if refresh:
        _rebuild_proxy_mesh(context, src, proxy)
    return proxy


def refresh_collider_proxies(context):
    """Reconstruye la malla de todos los proxies existentes desde la pose
    ACTUAL de su colisionador fuente. Para el botón Refrescar y el bake."""
    if _proxy_building[0]:
        return
    _proxy_building[0] = True
    try:
        for proxy in list(bpy.data.objects):
            if not proxy.name.startswith(COLLIDER_PROXY_PREFIX):
                continue
            src = bpy.data.objects.get(
                proxy.name[len(COLLIDER_PROXY_PREFIX):])
            if src is not None and is_collider(src):
                _rebuild_proxy_mesh(context, src, proxy)
    finally:
        _proxy_building[0] = False


def ensure_collider_collection(context, exclude=None, refresh_proxies=True):
    """Crea/recupera la colección de colisionadores y la puebla:
    - colisionadores cerrados y sin ciclo -> se usan EN VIVO.
    - colisionadores con ciclo o casco abierto -> se sustituyen por un PROXY
      cerrado (voxel remesh) que sí colisiona limpio (ver arriba).

    refresh_proxies=False (desde el autosync del depsgraph) reutiliza los
    proxies existentes sin reconstruir su malla — to_mesh dentro de ese
    handler es caro y arriesgado; la reconstrucción va por operador/bake.

    Devuelve (collection, num_miembros, num_proxied)."""
    coll = bpy.data.collections.get(COLLIDER_COLLECTION)
    if coll is None:
        coll = bpy.data.collections.new(COLLIDER_COLLECTION)
    try:
        context.scene.collection.children.link(coll)
    except RuntimeError:
        pass  # ya estaba enlazada

    # AUTO-DETECCIÓN: cualquier objeto con física Collision entra solo (los
    # proxies propios se excluyen — no son colisionadores de origen).
    colliders = [obj for obj in context.scene.objects
                 if obj is not exclude and is_collider(obj)
                 and not obj.name.startswith(COLLIDER_PROXY_PREFIX)]
    direct = {o for o in colliders if not collider_needs_proxy(o)}
    proxied = [o for o in colliders if collider_needs_proxy(o)]

    proxy_objs = {}
    if proxied:
        building = refresh_proxies and not _proxy_building[0]
        if building:
            _proxy_building[0] = True
        try:
            for src in proxied:
                p = _ensure_proxy(context, src, refresh=building)
                # con refresh_proxies=False no se crea uno nuevo vacío: solo
                # se usa si ya tiene geometría de una construcción previa.
                if p is not None and len(p.data.vertices) > 0:
                    proxy_objs[src] = p
        finally:
            if building:
                _proxy_building[0] = False

    desired = set(direct) | set(proxy_objs.values())
    for obj in desired:
        if obj.name not in coll.objects:
            coll.objects.link(obj)
    # Retira lo que ya no toca. Un proxy sin fuente (o cuya fuente ya no
    # necesita proxy) se BORRA. Para el resto: NUNCA huérfana un objeto — si
    # la colección es su único hogar, re-enlaza a la raíz antes de desenlazar
    # (un colisionador cíclico atrapado aquí dejaba el ciclo vivo y el efecto
    # entero en 0, medido).
    for obj in list(coll.objects):
        if obj in desired:
            continue
        if obj.name.startswith(COLLIDER_PROXY_PREFIX):
            coll.objects.unlink(obj)
            if obj.users == 0:
                me = obj.data
                bpy.data.objects.remove(obj)
                if me is not None and me.users == 0:
                    bpy.data.meshes.remove(me)
            continue
        if not any(c is not coll for c in obj.users_collection):
            try:
                context.scene.collection.objects.link(obj)
            except RuntimeError:
                pass  # ya enlazado u otra rareza: no perder el objeto
        if any(c is not coll for c in obj.users_collection):
            coll.objects.unlink(obj)
    return coll, len(coll.objects), len(proxied)


def link_colliders_to_modifier(context, obj, mod):
    """Conecta la colección de colisionadores al input del modifier."""
    tree = mod.node_group
    ident = input_identifier(tree, "Collision Collection")
    if ident is None:
        return 0
    coll, count, _skipped = ensure_collider_collection(context, exclude=obj)
    mod_set_input(mod, ident, coll)
    return count


def _position_after_armature(obj, mod):
    """Coloca el modifier SquishyFX justo tras el Armature (y tras otros
    SquishyFX ya colocados ahí).

    Blender añade modifiers al FINAL del stack — detrás de Subsurf y de
    los Displace. Ahí el efecto corre sobre la malla subdividida (hasta
    16× más vértices) y el bake pierde precisión: la tubería de captura
    (Displace antes del efecto) no coincide con la de reproducción de la
    Shape Key (Displace después). Justo tras el Armature es la posición
    correcta: física en espacio posado, Subsurf pule la deformación
    después, y el bake reproduce la misma tubería. Sin Armature no se
    mueve nada (el usuario sabrá dónde lo quiere).
    """
    mods = obj.modifiers
    arm_i = max((i for i, m in enumerate(mods) if m.type == 'ARMATURE'),
                default=-1)
    if arm_i < 0:
        return
    target = arm_i + 1
    while target < len(mods) and is_squishyfx_modifier(mods[target]):
        target += 1
    idx = next(i for i, m in enumerate(mods) if m == mod)
    if idx > target:
        mods.move(idx, target)


def apply_effect(context, effect, vertex_group=""):
    """Crea el modifier del efecto, conecta la máscara y los colisionadores.
    Devuelve (modifier, num_colisionadores_detectados)."""
    obj = context.active_object
    tree = gn.get_or_create_tree(effect)
    if gn.tree_is_stale(tree):
        # Un Ctrl+Z que cruce un rebuild (o un archivo guardado con una
        # versión anterior) resucita árboles obsoletos, y reutilizarlos
        # reproduce en silencio defectos ya corregidos. El Rebuild
        # blindado reconstruye TODOS los árboles y remapea los modifiers
        # existentes preservando sus valores por nombre.
        bpy.ops.squishyfx.rebuild_node_groups()
        tree = gn.get_or_create_tree(effect)

    mod = obj.modifiers.new(name=f"{gn.PREFIX} - {EFFECT_LABELS[effect]}",
                            type='NODES')
    mod.node_group = tree

    mask_id = input_identifier(tree, "Mask")
    if mask_id and vertex_group and vertex_group in obj.vertex_groups:
        mod_set_attribute(mod, mask_id, vertex_group)

    count = link_colliders_to_modifier(context, obj, mod)
    _position_after_armature(obj, mod)
    force_modifier_update(obj)
    return mod, count


# ------------------------------------------------------- gate de reproducción

def _set_ripple_playing(value):
    """Ripple y Fat Jiggle solo se previsualizan durante la reproducción:
    los handlers escriben este flag en el input oculto 'Playing' de sus
    modifiers. En render el node group ignora el flag (Is Viewport) y el
    bake lo activa temporalmente."""
    for obj in bpy.data.objects:
        touched = False
        for mod in obj.modifiers:
            if (mod.type == 'NODES' and mod.node_group is not None
                    and mod.node_group.name in gn.PLAY_GATED_TREES):
                ident = input_identifier(mod.node_group, "Playing")
                if ident:
                    mod_set_input(mod, ident, float(value))
                    touched = True
                # Al parar, la velocidad residual dejaría el squash de
                # Squish Organic congelado en el último frame reproducido
                # (en render el gate de Play no aplica y el socket manda).
                if not value:
                    vid = input_identifier(mod.node_group, "Velocity")
                    if vid:
                        mod_set_input(mod, vid, (0.0, 0.0, 0.0))
        if touched:
            obj.update_tag()


# Estado del impulso (por sesión): energía por modifier, posición previa
# de cada colisionador y de la carne (hueso), y último frame procesado.
_impulse_energy = {}
_collider_prev_pos = {}
_target_prev_pos = {}
_impulse_last_frame = [None]
# Centroide previo de la máscara por (objeto, modifier) — velocidad de la
# carne para el squash & stretch de Squish Organic (socket "Velocity").
_flesh_prev_pos = {}


def _world_bbox(obj):
    from mathutils import Vector
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    return (tuple(min(p[i] for p in pts) for i in range(3)),
            tuple(max(p[i] for p in pts) for i in range(3)))


def _deform_armature(obj):
    """Armature que deforma el objeto (None si no hay rig)."""
    for mod in obj.modifiers:
        if mod.type == 'ARMATURE' and mod.object is not None:
            return mod.object
    return None


def _target_point(obj, arm_obj, point):
    """Punto de la CARNE más cercano al colisionador: centro del hueso de
    deformación más próximo, que sigue la pose del rig frame a frame (a
    diferencia de matrix_world, que no se mueve al animar huesos). Sin
    armature, el origen del objeto. Devuelve (nombre_hueso, posición)."""
    if arm_obj is None:
        return ("", obj.matrix_world.translation.copy())
    mw = arm_obj.matrix_world
    best_name, best_pos, best_d2 = "", None, None
    for pb in arm_obj.pose.bones:
        if not pb.bone.use_deform:
            continue
        p = mw @ ((pb.head + pb.tail) * 0.5)
        d2 = (p - point).length_squared
        if best_d2 is None or d2 < best_d2:
            best_name, best_pos, best_d2 = pb.name, p, d2
    if best_pos is None:
        return ("", obj.matrix_world.translation.copy())
    return (best_name, best_pos)


def _target_bounds(obj, arm_obj):
    """AABB generoso del objetivo: bbox de la malla en reposo unida a los
    huesos de deformación posados, para que la caja siga al personaje
    cuando lo mueve la armadura (bound_box es estático bajo animación de
    rig). Puede sobrar: el falloff espacial del node group, que usa la
    distancia real a la superficie, afina el resultado."""
    from mathutils import Vector
    pts = [obj.matrix_world @ Vector(c) for c in obj.bound_box]
    if arm_obj is not None:
        mw = arm_obj.matrix_world
        for pb in arm_obj.pose.bones:
            if pb.bone.use_deform:
                pts.append(mw @ pb.head)
                pts.append(mw @ pb.tail)
    return (tuple(min(p[i] for p in pts) for i in range(3)),
            tuple(max(p[i] for p in pts) for i in range(3)))


def _boxes_overlap(a, b, margin=0.03):
    return all(a[0][i] - margin <= b[1][i] and b[0][i] - margin <= a[1][i]
               for i in range(3))


_mask_sample_cache = {}


def _mask_contact_samples(obj, mod, arm_obj, limit=32):
    """Muestra de vértices de la MÁSCARA del modifier, cada uno con su
    hueso dominante y su posición de reposo en espacio de armature, para
    testear contacto real por frame a coste fijo. Cacheada por
    (objeto, modifier, máscara)."""
    mask_name = mod_get_attribute(
        mod, input_identifier(mod.node_group, "Mask"))
    key = (obj.name, mod.name, mask_name, len(obj.data.vertices))
    hit = _mask_sample_cache.get(key)
    if hit is not None:
        return hit
    bones = ({pb.name for pb in arm_obj.pose.bones if pb.bone.use_deform}
             if arm_obj else set())
    gidx_by_name = {g.index: g.name for g in obj.vertex_groups}
    vg = obj.vertex_groups.get(mask_name) if mask_name else None
    if vg is not None:
        verts = [v for v in obj.data.vertices
                 for g in v.groups
                 if g.group == vg.index and g.weight > 0.4]
    else:
        verts = list(obj.data.vertices)
    step = max(len(verts) // limit, 1)
    samples = []
    a_inv = (arm_obj.matrix_world.inverted() if arm_obj else None)
    for v in verts[::step][:limit]:
        bone = None
        if arm_obj:
            best_w = 0.0
            for g in v.groups:
                name = gidx_by_name.get(g.group)
                if name in bones and g.weight > best_w:
                    best_w, bone = g.weight, name
        world_rest = obj.matrix_world @ v.co
        q = (a_inv @ world_rest) if (arm_obj and bone) else world_rest
        samples.append((bone, q))
    _mask_sample_cache[key] = samples
    return samples


def _mask_touches_collider(obj, mod, arm_obj, col, margin=0.005):
    """¿Algún vértice de la máscara (posado por su hueso dominante) está
    dentro del volumen local del colisionador? Test de contacto REAL: el
    AABB del personaje entero inyectaba energía con el colisionador cerca
    de CUALQUIER parte del cuerpo — el temblor arrancaba sin tocar y la
    carne parecía atraerse al colisionador al acercarlo (fantasma medido:
    9.5 mm de temblor a 15 mm de distancia)."""
    inv = col.matrix_world.inverted()
    bb = col.bound_box
    lo = [min(c[i] for c in bb) - margin for i in range(3)]
    hi = [max(c[i] for c in bb) + margin for i in range(3)]
    aw = arm_obj.matrix_world if arm_obj else None
    for bone, q in _mask_contact_samples(obj, mod, arm_obj):
        if bone and arm_obj:
            pb = arm_obj.pose.bones.get(bone)
            if pb is None:
                world = q
            else:
                world = aw @ (pb.matrix @
                              (pb.bone.matrix_local.inverted() @ q))
        else:
            world = q
        p = inv @ world
        if (lo[0] <= p.x <= hi[0] and lo[1] <= p.y <= hi[1]
                and lo[2] <= p.z <= hi[2]):
            return True
    return False


@persistent
def _sfx_impulse_update(scene):
    """frame_change_pre: envolvente de impulso tipo nalgada.

    e = e·exp(-dt/Relax) + golpe   donde el golpe es la velocidad
    RELATIVA entre el colisionador y la carne (hueso de deformación más
    cercano) mientras solapan: da igual si golpea el colisionador o si
    es el personaje quien se mueve contra él al animar el rig. Ambos
    quietos, o contacto lento/sostenido -> golpe ~0 -> decae a nada.
    Se escribe en el input oculto "Energy" de Ripple/Fat Jiggle.
    Funciona igual en reproducción, render y bake (frame_change)."""
    import math
    from mathutils import Vector
    fps = scene.render.fps / scene.render.fps_base
    last = _impulse_last_frame[0]
    dframes = 1 if last is None else max(abs(scene.frame_current - last), 1)
    dt = dframes / max(fps, 1.0)
    _impulse_last_frame[0] = scene.frame_current

    for obj in bpy.data.objects:
        touched = False
        for mod in obj.modifiers:
            if not (mod.type == 'NODES' and mod.node_group is not None
                    and mod.node_group.name in gn.PLAY_GATED_TREES):
                continue
            tree = mod.node_group
            e_id = input_identifier(tree, "Energy")
            if not e_id:
                continue
            sens = float(mod_get_input(
                mod, input_identifier(tree, "Impact Sensitivity"), 1.5) or 1.5)
            relax = max(float(mod_get_input(
                mod, input_identifier(tree, "Relax Time"), 0.6) or 0.6), 0.05)

            colliders = []
            c_obj = mod_get_input(mod, input_identifier(
                tree, "Collision Object"))
            if c_obj is not None:
                colliders.append(c_obj)
            c_col = mod_get_input(mod, input_identifier(
                tree, "Collision Collection"))
            if c_col is not None:
                colliders.extend(o for o in c_col.objects if o.type == 'MESH')

            arm_obj = _deform_armature(obj)

            # Velocidad de la CARNE para Squish Organic: centroide de la
            # muestra de la máscara posado por su hueso dominante (sigue
            # tanto al objeto como al rig); sin armature, el origen del
            # objeto. Independiente de colisionadores: un personaje que
            # corre se squashea aunque nada lo toque.
            vel_id = input_identifier(tree, "Velocity")
            if vel_id:
                if arm_obj is None:
                    cen = obj.matrix_world.translation.copy()
                else:
                    aw = arm_obj.matrix_world
                    acc = Vector((0.0, 0.0, 0.0))
                    cnt = 0
                    for bone, q in _mask_contact_samples(obj, mod, arm_obj):
                        if bone:
                            pb = arm_obj.pose.bones.get(bone)
                            if pb is not None:
                                q = aw @ (pb.matrix @
                                          (pb.bone.matrix_local.inverted()
                                           @ q))
                        acc += q
                        cnt += 1
                    cen = (acc / cnt) if cnt else obj.matrix_world.translation.copy()
                vkey = (obj.name, mod.name)
                prev = _flesh_prev_pos.get(vkey)
                v = ((cen - prev) / dt) if prev is not None \
                    else Vector((0.0, 0.0, 0.0))
                _flesh_prev_pos[vkey] = cen
                if v.length > 10.0:  # teleport / salto de scrub, no motion
                    v = Vector((0.0, 0.0, 0.0))
                mod_set_input(mod, vel_id, v)

            target_box = _target_bounds(obj, arm_obj)
            overlap, speed = 0.0, 0.0
            drag_vec = Vector((0.0, 0.0, 0.0))
            drag_best = -1.0
            drag_id = input_identifier(tree, "Drag")  # solo Penetration
            for col in colliders:
                if col is None or col is obj:
                    continue
                c_pos = col.matrix_world.translation.copy()
                c_prev = _collider_prev_pos.get(col.name)
                c_vel = ((c_pos - c_prev) / dt) if c_prev is not None \
                    else Vector((0.0, 0.0, 0.0))
                _collider_prev_pos[col.name] = c_pos

                # Velocidad de la carne justo en el contacto (sigue el rig)
                t_key = (obj.name, mod.name, col.name)
                b_name, t_pos = _target_point(obj, arm_obj, c_pos)
                t_prev = _target_prev_pos.get(t_key)
                if t_prev is not None and t_prev[0] == b_name:
                    t_vel = (t_pos - t_prev[1]) / dt
                else:  # primer frame o cambió el hueso: sin pico artificial
                    t_vel = Vector((0.0, 0.0, 0.0))
                _target_prev_pos[t_key] = (b_name, t_pos)

                # RELATIVA: da igual quién se mueva, el golpe es el mismo
                rel = (c_vel - t_vel).length
                # Doble puerta: el AABB barato descarta lo lejano; el test
                # de CONTACTO REAL con la máscara decide. Sin él, mover el
                # colisionador cerca (sin tocar) ya inyectaba energía.
                if (_boxes_overlap(target_box, _world_bbox(col))
                        and _mask_touches_collider(obj, mod, arm_obj, col)):
                    overlap = 1.0
                    speed = max(speed, rel)
                    # Penetration: guarda el DESPLAZAMIENTO relativo por
                    # frame del penetrador en contacto (la carne lo sigue =
                    # arrastre/fricción). Del más rápido si hay varios.
                    if drag_id and rel > drag_best:
                        drag_best = rel
                        rd = (c_vel - t_vel) * dt
                        if rd.length > 0.02:      # tope anti-salto (2cm/frame)
                            rd = rd.normalized() * 0.02
                        drag_vec = rd
            if drag_id:
                mod_set_input(mod, drag_id, drag_vec)

            key = (obj.name, mod.name)
            energy, _prev = _impulse_energy.get(key, (0.0, 0.0))
            energy *= math.exp(-dt / relax)
            # Solo la VELOCIDAD RELATIVA dentro de la zona inyecta: el
            # golpe rapido dispara la rafaga (al entrar Y al salir), lo
            # mueva el collider o el rig; una presion lenta o sostenida
            # no genera temblor. El falso positivo del AABB grueso lo
            # anula el falloff espacial (att) del node group, que usa la
            # distancia real a la superficie.
            hit = overlap * min(speed * 0.6, 1.0) * dt * 6.0
            energy = min(energy + hit * sens, 1.5)
            _impulse_energy[key] = (energy, overlap)
            mod_set_input(mod, e_id, energy)
            touched = True
        if touched:
            obj.update_tag()


@persistent
def _sfx_playback_start(scene):
    _impulse_energy.clear()
    _collider_prev_pos.clear()
    _target_prev_pos.clear()
    _flesh_prev_pos.clear()
    _impulse_last_frame[0] = None
    _set_ripple_playing(1.0)


@persistent
def _sfx_playback_stop(scene):
    _set_ripple_playing(0.0)


# ---------------------------------------------------------------------------
# Operadores
# ---------------------------------------------------------------------------

class SQUISHYFX_OT_apply_effect(Operator):
    """Aplica un efecto SquishyFX reactivo a colisiones. El Vertex Group
seleccionado es la máscara (weight = deformabilidad local) y los objetos
de la escena con física Collision se enlazan automáticamente"""
    bl_idname = "squishyfx.apply_effect"
    bl_label = "Apply SquishyFX Effect"
    bl_options = {'REGISTER', 'UNDO'}

    effect: EnumProperty(
        name="Effect",
        items=[(i[0], i[1], i[2], i[3], i[4]) for i in EFFECT_ITEMS],
        default='SQUISH',
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        props = context.scene.squishyfx
        obj = context.active_object

        vg = props.vertex_group
        if vg and vg not in obj.vertex_groups:
            self.report({'WARNING'},
                        f"Vertex Group '{vg}' does not exist on {obj.name}; "
                        "the effect is applied without a mask")
            vg = ""

        mod, colliders = apply_effect(context, self.effect, vg)

        if colliders == 0:
            self.report({'WARNING'},
                        f"'{mod.name}' created, but there are no colliders: "
                        "enable Collision on an object (e.g. your sphere) and "
                        "press Detect Colliders, or use Add Collider Sphere")
        else:
            self.report({'INFO'},
                        f"'{mod.name}' created with {colliders} "
                        f"collider(s). Live: move the collider "
                        f"over the mesh, no need to press Play")
        return {'FINISHED'}


class SQUISHYFX_OT_apply_preset(Operator):
    """Aplica un preset: crea el efecto correspondiente y configura sus
parámetros con valores predefinidos"""
    bl_idname = "squishyfx.apply_preset"
    bl_label = "Apply Preset"
    bl_options = {'REGISTER', 'UNDO'}

    # Enum DINÁMICO: incluye también los presets custom del usuario. La
    # caché a nivel de módulo es obligatoria — Blender no retiene las
    # strings devueltas por el callback y sin referencia viva el enum
    # muestra texto corrupto (pitfall conocido de EnumProperty).
    preset: EnumProperty(name="Preset", items=lambda self, context:
                         _preset_enum_cache_fill())

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj is not None and obj.type == 'MESH'

    def execute(self, context):
        props = context.scene.squishyfx
        obj = context.active_object
        data = all_presets().get(self.preset)
        if data is None:
            self.report({'ERROR'}, f"Preset '{self.preset}' does not exist")
            return {'CANCELLED'}
        if data.get("effect") not in EFFECT_LABELS:
            self.report({'ERROR'},
                        f"Preset '{self.preset}': unknown effect "
                        f"{data.get('effect')!r}")
            return {'CANCELLED'}

        vg = props.vertex_group if props.vertex_group in obj.vertex_groups else ""
        mod, colliders = apply_effect(context, data["effect"], vg)
        mod.name = f"{gn.PREFIX} - {self.preset}"

        tree = mod.node_group
        for socket_name, value in data["params"].items():
            for item in input_socket_items(tree):
                if item.name == socket_name:
                    # Un valor corrupto (JSON editado a mano) degrada a
                    # "parámetro omitido", nunca a un traceback.
                    try:
                        mod_set_input(mod, item.identifier,
                                      _cast_value(item.socket_type, value))
                    except (ValueError, TypeError, OverflowError):
                        pass
                    break

        force_modifier_update(obj)
        msg = f"Preset '{self.preset}' aplicado"
        if colliders == 0:
            msg += " - add a collider to see the effect"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


_preset_enum_cache = []


def _preset_enum_cache_fill():
    """Items del enum de presets con NÚMERO ESTABLE por nombre (CRC32).

    Sin número explícito Blender numera los items por posición, y el valor
    guardado en el panel de redo apuntaría a OTRO preset cuando la lista
    custom cambia (añadir/borrar) — un F9 aplicaría un preset distinto al
    elegido. El CRC del nombre es estable ante reordenaciones.
    """
    import zlib
    global _preset_enum_cache
    items, used = [], set()
    for name, data in all_presets().items():
        num = zlib.crc32(name.encode("utf-8")) & 0x3FFFFFFF
        while num in used:
            num = (num + 1) & 0x3FFFFFFF
        used.add(num)
        items.append((name, name, data.get("description", ""), 'NONE', num))
    _preset_enum_cache = items
    return _preset_enum_cache


def _effect_from_tree(tree):
    """Clave de efecto ('SQUISH', ...) a partir del node group del modifier."""
    for eff, (tree_name, _builder) in gn.BUILDERS.items():
        if tree.name == tree_name:
            return eff
    return None


# Sockets que no tienen sentido dentro de un preset: la máscara y los
# colisionadores son de la escena, y Playing/Energy/Velocity/Drag los
# escribe el addon cada frame.
_PRESET_SKIP = {"Mask", "Playing", "Energy", "Velocity", "Drag",
                "Collision Object", "Collision Collection"}


class SQUISHYFX_OT_save_preset(Operator):
    """Guarda los valores actuales de este efecto como preset propio.
Los presets custom persisten entre archivos y sesiones (JSON en la
configuración de Blender) y aparecen en el menú de Presets"""
    bl_idname = "squishyfx.save_preset"
    bl_label = "Save Custom Preset"
    bl_options = {'REGISTER'}

    modifier_name: StringProperty(options={'HIDDEN'})
    preset_name: StringProperty(
        name="Name",
        description="Preset name (an existing one is overwritten)",
        default="My Preset",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def execute(self, context):
        obj = context.active_object
        mod = obj.modifiers.get(self.modifier_name) if obj else None
        if mod is None or not is_squishyfx_modifier(mod):
            self.report({'ERROR'},
                        f"Modifier '{self.modifier_name}' not found")
            return {'CANCELLED'}
        effect = _effect_from_tree(mod.node_group)
        if effect is None:
            self.report({'ERROR'}, "Unrecognized SquishyFX tree; press "
                        "the refresh button and try again")
            return {'CANCELLED'}
        name = self.preset_name.strip()
        if not name:
            self.report({'ERROR'}, "The preset needs a name")
            return {'CANCELLED'}
        if name in PRESETS:
            # Sombras prohibidas: dos entradas con el mismo texto en el
            # menú y el integrado aplicando los valores del custom.
            self.report({'ERROR'},
                        f"'{name}' is a built-in preset; use another name")
            return {'CANCELLED'}

        params = {}
        for item in input_socket_items(mod.node_group):
            if item.name in _PRESET_SKIP:
                continue
            value = mod_get_input(mod, item.identifier)
            if isinstance(value, (int, float, bool)):
                params[item.name] = value
        try:
            save_custom_preset(name, effect, params,
                               description=f"Custom ({EFFECT_LABELS[effect]})")
        except OSError as exc:
            # Antivirus/permisos/disco lleno: reporte, no traceback
            self.report({'ERROR'}, f"Could not write the preset: {exc}")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Preset '{name}' saved "
                    f"({len(params)} parameters)")
        return {'FINISHED'}


class SQUISHYFX_OT_delete_preset(Operator):
    """Elimina un preset custom (los presets integrados no se pueden borrar)"""
    bl_idname = "squishyfx.delete_preset"
    bl_label = "Delete Custom Preset"
    bl_options = {'REGISTER'}

    preset: StringProperty()

    def execute(self, context):
        try:
            deleted = delete_custom_preset(self.preset)
        except OSError as exc:
            self.report({'ERROR'}, f"Could not update the preset "
                        f"presets: {exc}")
            return {'CANCELLED'}
        if deleted:
            self.report({'INFO'}, f"Preset '{self.preset}' eliminado")
            return {'FINISHED'}
        self.report({'ERROR'}, f"'{self.preset}' is not a custom preset")
        return {'CANCELLED'}


class SQUISHYFX_OT_detect_colliders(Operator):
    """Escanea la escena en busca de objetos con física Collision, los añade
a la colección 'SquishyFX Colliders' y la reconecta a todos los efectos
del objeto activo"""
    bl_idname = "squishyfx.detect_colliders"
    bl_label = "Detect Colliders"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = context.active_object
        coll, count, proxied = ensure_collider_collection(context, exclude=obj)

        relinked = 0
        if obj is not None:
            for mod in obj.modifiers:
                if is_squishyfx_modifier(mod):
                    ident = input_identifier(mod.node_group,
                                             "Collision Collection")
                    if ident:
                        mod_set_input(mod, ident, coll)
                        relinked += 1
            force_modifier_update(obj)

        if count == 0:
            self.report({'WARNING'},
                        "No object with Collision physics in the scene. "
                        "Select your sphere and enable Physics > Collision")
        elif proxied:
            self.report({'INFO'},
                        f"{count} collider(s) in '{coll.name}' "
                        f"({relinked} effect(s) relinked). {proxied} "
                        "rigged/open collider(s) use a proxy "
                        "closed proxy - if you re-pose them, press Refresh")
        else:
            self.report({'INFO'},
                        f"{count} collider(s) in '{coll.name}' "
                        f"({relinked} effect(s) relinked)")
        return {'FINISHED'}


class SQUISHYFX_OT_add_collider_sphere(Operator):
    """Crea una esfera con física Collision ya activada en el cursor 3D,
lista para empujar la malla (muévela o anímala sobre el objeto)"""
    bl_idname = "squishyfx.add_collider_sphere"
    bl_label = "Add Collider Sphere"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prev_active = context.active_object

        bpy.ops.mesh.primitive_uv_sphere_add(
            radius=0.5, segments=24, ring_count=16,
            location=context.scene.cursor.location)
        sphere = context.active_object
        sphere.name = "SFX_Collider_Sphere"
        sphere.modifiers.new(name="Collision", type='COLLISION')

        coll, _count, _proxied = ensure_collider_collection(
            context, exclude=prev_active)
        if sphere.name not in coll.objects:
            coll.objects.link(sphere)

        # Reconectar los efectos del objeto que estaba activo
        if prev_active is not None:
            for mod in prev_active.modifiers:
                if is_squishyfx_modifier(mod):
                    ident = input_identifier(mod.node_group,
                                             "Collision Collection")
                    if ident:
                        mod_set_input(mod, ident, coll)
            force_modifier_update(prev_active)

        self.report({'INFO'},
                    f"'{sphere.name}' created with Collision and linked")
        return {'FINISHED'}


class SQUISHYFX_OT_remove_effect(Operator):
    """Elimina este modifier SquishyFX del objeto"""
    bl_idname = "squishyfx.remove_effect"
    bl_label = "Remove Effect"
    bl_options = {'REGISTER', 'UNDO'}

    modifier_name: StringProperty()

    def execute(self, context):
        obj = context.active_object
        mod = obj.modifiers.get(self.modifier_name) if obj else None
        if mod is None:
            return {'CANCELLED'}
        obj.modifiers.remove(mod)
        return {'FINISHED'}


def _skinning_inverse_matrices(obj, np):
    """Matrices 3x3 por vértice que DES-POSAN un delta medido tras el
    Armature. None si no hay Armature activo aplicable.

    Las Shape Keys se evalúan ANTES del armature, pero SquishyFX deforma
    DESPUÉS (la física vive en espacio posado, que es lo correcto). Un
    delta posado guardado tal cual en una key vuelve a pasar por el
    skinning al reproducirse y queda re-rotado — medido en una pose real:
    43 mm de error medio y 80 mm de pico, el efecto entero apuntando a
    otro sitio. La inversa del linear-blend skinning por vértice
    (mezcla ponderada de matrices de hueso, invertida en bloque) lleva el
    delta a espacio de reposo. Con preserve_volume (dual quaternion) es
    una aproximación: el residuo práctico son milímetros.
    """
    am = next((m for m in obj.modifiers
               if m.type == 'ARMATURE' and m.show_viewport and m.object
               and m.use_vertex_groups), None)
    if am is None:
        return None
    arm = am.object
    mw = np.array(obj.matrix_world, dtype=np.float64)
    aw = np.array(arm.matrix_world, dtype=np.float64)
    conv = np.linalg.inv(mw) @ aw           # armature -> local de la malla
    conv_inv = np.linalg.inv(aw) @ mw
    bone_m = {}
    for pb in arm.pose.bones:
        if not pb.bone.use_deform:
            continue
        m = (np.array(pb.matrix, dtype=np.float64)
             @ np.array(pb.bone.matrix_local.inverted(), dtype=np.float64))
        bone_m[pb.name] = (conv @ m @ conv_inv)[:3, :3]
    if not bone_m:
        return None
    g2b = {g.index: bone_m[g.name] for g in obj.vertex_groups
           if g.name in bone_m}
    n = len(obj.data.vertices)
    Ms = np.repeat(np.eye(3)[None, :, :], n, axis=0)
    for v in obj.data.vertices:
        acc = None
        tw = 0.0
        for ge in v.groups:
            m = g2b.get(ge.group)
            if m is None or ge.weight <= 0.0:
                continue
            acc = m * ge.weight if acc is None else acc + m * ge.weight
            tw += ge.weight
        if acc is not None and tw > 1e-6:
            Ms[v.index] = acc / tw
    # vértices con mezcla degenerada -> identidad (no des-posar es mejor
    # que amplificar con una inversa casi singular)
    Ms[np.abs(np.linalg.det(Ms)) < 1e-8] = np.eye(3)
    return np.linalg.inv(Ms)


def _unpose_delta(obj, delta_flat, np):
    """Delta (n*3,) posado -> espacio de reposo (inversa LBS analítica)."""
    inv = _skinning_inverse_matrices(obj, np)
    if inv is None:
        return delta_flat
    d = delta_flat.reshape(-1, 3)
    return np.einsum('nij,nj->ni', inv, d).ravel()


def _empirical_inverse(obj, basis_co, a_off, eval_coords, np):
    """Matrices (n,3,3) que des-posan un delta: linealización MEDIDA.

    Tres Shape Keys temporales desplazadas +1 cm en X/Y/Z revelan, vértice
    a vértice, las columnas de la matriz de TODO lo que separa a las keys
    de la salida evaluada — armature con preserve_volume (dual quaternion)
    incluido. DEBE llamarse con los modifiers SquishyFX APAGADOS: con el
    efecto activo las sondas medían también su respuesta al desplazamiento
    y la matriz contaminada producía picos de 1.5 m al invertir (medido).
    None si la sonda falla (el caller degrada a la inversa LBS analítica).
    """
    eps = 0.01
    n = len(obj.data.vertices)
    cols = []
    tmp = []
    try:
        for ax in ((eps, 0.0, 0.0), (0.0, eps, 0.0), (0.0, 0.0, eps)):
            sk = obj.shape_key_add(name="SFX_TMP_AXIS", from_mix=False)
            tmp.append(sk)
            sk.data.foreach_set("co", basis_co + np.tile(np.array(ax), n))
            sk.value = 1.0
            p = eval_coords()
            sk.value = 0.0
            if p is None:
                return None
            cols.append((p - a_off) / eps)
    finally:
        for sk in tmp:
            obj.shape_key_remove(sk)
    M = np.stack([c.reshape(-1, 3) for c in cols], axis=2)
    M[np.abs(np.linalg.det(M)) < 1e-6] = np.eye(3)
    return np.linalg.inv(M)


def _refine_key(obj, sk, a_on, unpose, eval_coords, np, rounds=2):
    """Refinamiento por punto fijo: la linealización no captura la
    CURVATURA del skinning sobre deltas grandes (medido: 19 mm de residuo
    con deltas de 86 mm en articulaciones dobladas). Se evalúa cómo se
    reproduce la key de verdad y se corrige con el residuo; dos vueltas
    dejan la reproducción indistinguible del efecto en vivo. Requiere los
    modifiers SquishyFX apagados y sk.value=1 al entrar."""
    n3 = len(obj.data.vertices) * 3
    for _ in range(rounds):
        played = eval_coords()
        if played is None:
            return
        resid = a_on - played
        if np.abs(resid).max() < 5e-4:
            break
        cur = np.empty(n3)
        sk.data.foreach_get("co", cur)
        sk.data.foreach_set("co", cur + unpose(resid))
        # foreach_set NO invalida el depsgraph: sin este tag, la siguiente
        # evaluación devolvía la malla cacheada, el residuo se veía dos
        # veces y la corrección se aplicaba doble (sobre-corrección 2×
        # medida — la key empeoraba al vértice más de lo que lo arreglaba).
        sk.id_data.update_tag()
        obj.update_tag()


class SQUISHYFX_OT_bake_shapekeys(Operator):
    """Convierte la simulación SquishyFX a Shape Keys (una por frame según
Step) con keyframes de activación, y opcionalmente desactiva los
modifiers. Ideal para exportar o combinar con otra animación"""
    bl_idname = "squishyfx.bake_shapekeys"
    bl_label = "Bake to Shape Keys"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'MESH'
                and any(is_squishyfx_modifier(m) for m in obj.modifiers))

    # Modifiers que cambian la topología: se apagan temporalmente durante
    # el bake (y se restauran) para que el conteo de vértices coincida con
    # la malla base. El resto del stack (armature, morphs, displaces...)
    # queda activo y su aporte se CANCELA al restar on - off.
    _TOPO_TYPES = {'MASK', 'SUBSURF', 'MULTIRES', 'MIRROR', 'SOLIDIFY',
                   'BEVEL', 'ARRAY', 'BOOLEAN', 'DECIMATE', 'WELD',
                   'SCREW', 'SKIN', 'REMESH', 'TRIANGULATE', 'WIREFRAME',
                   'EDGE_SPLIT', 'BUILD'}

    def execute(self, context):
        import numpy as np
        props = context.scene.squishyfx
        scene = context.scene
        obj = context.active_object

        start, end, step = props.bake_start, props.bake_end, props.bake_step
        if end < start:
            self.report({'ERROR'}, "The end frame must be >= the start frame")
            return {'CANCELLED'}

        base_count = len(obj.data.vertices)
        if obj.data.shape_keys is None:
            obj.shape_key_add(name="Basis", from_mix=False)
        basis = obj.data.shape_keys.key_blocks[0]
        basis_co = np.empty(base_count * 3)
        basis.data.foreach_get("co", basis_co)

        original_frame = scene.frame_current
        created_keys = []

        # SOLO los modifiers VISIBLES: el bake captura lo que el usuario ve.
        # Antes se forzaba show_viewport=True en todos y un Fat Jiggle
        # oculto (o invisible por el gate de Play) se colaba en la key con
        # su huella de contacto — 19 mm de desajuste medido entre la key y
        # el viewport, invariante a todo lo demás.
        sfx_mods = [m for m in obj.modifiers
                    if is_squishyfx_modifier(m) and m.show_viewport]
        # Estado a restaurar SIEMPRE (try/finally):
        topo_restore = [(m, m.show_viewport) for m in obj.modifiers
                        if m.type in self._TOPO_TYPES]
        sfx_vp = [(m, m.show_viewport) for m in sfx_mods]
        ripple_restore = []
        for m in sfx_mods:
            if m.node_group.name in gn.PLAY_GATED_TREES:
                ident = input_identifier(m.node_group, "Playing")
                if ident:
                    ripple_restore.append(
                        (m, ident, float(mod_get_input(m, ident, 0.0))))

        def eval_coords():
            depsgraph = context.evaluated_depsgraph_get()
            ev = obj.evaluated_get(depsgraph)
            me = ev.to_mesh()
            n = len(me.vertices)
            if n != base_count:
                ev.to_mesh_clear()
                return None
            arr = np.empty(n * 3)
            me.vertices.foreach_get("co", arr)
            ev.to_mesh_clear()
            return arr

        try:
            for m, _ in topo_restore:
                m.show_viewport = False
            for m, ident, _prev in ripple_restore:
                mod_set_input(m, ident, 1.0)

            # Envolvente de impulso desde cero: sin energía residual de la
            # sesión, el bake es determinista y reproducible.
            _impulse_energy.clear()
            _collider_prev_pos.clear()
            _target_prev_pos.clear()
            _flesh_prev_pos.clear()
            _impulse_last_frame[0] = None

            for frame in range(min(start, scene.frame_start), end + 1):
                scene.frame_set(frame)
                if frame < start or (frame - start) % step != 0:
                    continue

                # Proxies de colisión al día con la pose de ESTE frame: un
                # colisionador riggeado/abierto se hornea contra su snapshot
                # cerrado, que debe seguir su animación (si no, todos los
                # frames usarían la pose en que se construyó el proxy).
                refresh_collider_proxies(context)
                if bpy.context.view_layer:
                    bpy.context.view_layer.update()

                for m in sfx_mods:
                    m.show_viewport = True
                a_on = eval_coords()
                for m in sfx_mods:
                    m.show_viewport = False
                a_off = eval_coords()

                if a_on is None or a_off is None:
                    self.report({'ERROR'},
                                "The vertex count does not match the "
                                "base mesh even with the topology modifiers "
                                "disabled; check the stack")
                    raise RuntimeError("vertex count")

                # La key contiene SOLO el delta SquishyFX sobre la Basis
                # (pose, morphs y displaces se cancelan en la resta),
                # DES-POSADO al espacio de reposo: las keys se evalúan
                # antes del armature y un delta posado se re-rotaría.
                # IMPORTANTE: SquishyFX debe seguir APAGADO durante el
                # des-posado empírico — sus sondas miden la matriz del
                # stack, y con el efecto activo medían también la
                # respuesta del efecto a la malla desplazada (matriz
                # contaminada → picos de 1.5 m al invertir, medidos).
                inv = _empirical_inverse(obj, basis_co, a_off,
                                         eval_coords, np)

                def unpose(dflat, _inv=inv):
                    if _inv is None:
                        return _unpose_delta(obj, dflat, np)
                    return np.einsum('nij,nj->ni', _inv,
                                     dflat.reshape(-1, 3)).ravel()

                sk = obj.shape_key_add(name=f"SFX_{frame:04d}",
                                       from_mix=False)
                sk.data.foreach_set("co", basis_co + unpose(a_on - a_off))
                sk.value = 1.0
                _refine_key(obj, sk, a_on, unpose, eval_coords, np)
                created_keys.append(sk.name)
                for m, vp in sfx_vp:
                    m.show_viewport = vp

                sk.value = 0.0
                sk.keyframe_insert("value", frame=frame - step)
                sk.value = 1.0
                sk.keyframe_insert("value", frame=frame)
                sk.value = 0.0
                sk.keyframe_insert("value", frame=frame + step)
                sk.value = 0.0

        except Exception as exc:
            for name in created_keys:
                kb = obj.data.shape_keys.key_blocks.get(name)
                if kb:
                    obj.shape_key_remove(kb)
            if not isinstance(exc, RuntimeError):
                raise
            return {'CANCELLED'}
        finally:
            for m, vp in topo_restore:
                m.show_viewport = vp
            for m, vp in sfx_vp:
                m.show_viewport = vp
            for m, ident, prev in ripple_restore:
                mod_set_input(m, ident, prev)
            scene.frame_set(original_frame)

        if props.bake_disable_after:
            for mod in sfx_mods:
                mod.show_viewport = False
                mod.show_render = False

        self.report({'INFO'},
                    f"Bake complete: {len(created_keys)} Shape Keys with "
                    f"the SquishyFX delta ({start}-{end}, step {step})")
        return {'FINISHED'}


class SQUISHYFX_OT_bake_current_frame(Operator):
    """Convierte la deformación SquishyFX del FRAME ACTUAL en una única
Shape Key estática (valor 1, sin keyframes) — para congelar una pose,
esculpir encima o exportar. Respeta 'Desactivar modifiers después'"""
    bl_idname = "squishyfx.bake_current_frame"
    bl_label = "Bake Current Frame"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return (obj is not None and obj.type == 'MESH'
                and any(is_squishyfx_modifier(m) for m in obj.modifiers))

    def execute(self, context):
        import numpy as np
        props = context.scene.squishyfx
        obj = context.active_object
        frame = context.scene.frame_current

        # Proxies de colisión al día con la pose actual antes de congelar.
        refresh_collider_proxies(context)
        if context.view_layer:
            context.view_layer.update()

        base_count = len(obj.data.vertices)
        if obj.data.shape_keys is None:
            obj.shape_key_add(name="Basis", from_mix=False)
        basis = obj.data.shape_keys.key_blocks[0]
        basis_co = np.empty(base_count * 3)
        basis.data.foreach_get("co", basis_co)

        # SOLO los modifiers VISIBLES: el bake captura lo que el usuario ve.
        # Antes se forzaba show_viewport=True en todos y un Fat Jiggle
        # oculto (o invisible por el gate de Play) se colaba en la key con
        # su huella de contacto — 19 mm de desajuste medido entre la key y
        # el viewport, invariante a todo lo demás.
        sfx_mods = [m for m in obj.modifiers
                    if is_squishyfx_modifier(m) and m.show_viewport]
        topo_restore = [(m, m.show_viewport) for m in obj.modifiers
                        if m.type in SQUISHYFX_OT_bake_shapekeys._TOPO_TYPES]
        sfx_vp = [(m, m.show_viewport) for m in sfx_mods]
        # A diferencia del bake de rango, aquí NO se fuerza Playing=1: este
        # operador congela EXACTAMENTE lo que se ve en el viewport. Un
        # Ripple/Fat Jiggle pausado (invisible por el gate) hornea nada,
        # que es lo que hay en pantalla.

        def eval_coords():
            depsgraph = context.evaluated_depsgraph_get()
            ev = obj.evaluated_get(depsgraph)
            me = ev.to_mesh()
            n = len(me.vertices)
            if n != base_count:
                ev.to_mesh_clear()
                return None
            arr = np.empty(n * 3)
            me.vertices.foreach_get("co", arr)
            ev.to_mesh_clear()
            return arr

        try:
            for m, _ in topo_restore:
                m.show_viewport = False
            for m in sfx_mods:
                m.show_viewport = True
            a_on = eval_coords()
            for m in sfx_mods:
                m.show_viewport = False
            a_off = eval_coords()
            if a_on is None or a_off is None:
                self.report({'ERROR'},
                            "The vertex count does not match the base "
                            "mesh even with the topology modifiers disabled")
                return {'CANCELLED'}

            inv = _empirical_inverse(obj, basis_co, a_off,
                                     eval_coords, np)

            def unpose(dflat, _inv=inv):
                if _inv is None:
                    return _unpose_delta(obj, dflat, np)
                return np.einsum('nij,nj->ni', _inv,
                                 dflat.reshape(-1, 3)).ravel()

            sk = obj.shape_key_add(name=f"SFX_Frame_{frame:04d}",
                                   from_mix=False)
            sk.data.foreach_set("co", basis_co + unpose(a_on - a_off))
            sk.value = 1.0
            _refine_key(obj, sk, a_on, unpose, eval_coords, np)
            try:
                sk.slider_max = max(sk.slider_max, 1.0)
            except Exception:
                pass
        finally:
            for m, vp in topo_restore:
                m.show_viewport = vp
            for m, vp in sfx_vp:
                m.show_viewport = vp

        if props.bake_disable_after:
            for mod in sfx_mods:
                mod.show_viewport = False
                mod.show_render = False

        self.report({'INFO'},
                    f"Shape Key '{sk.name}' created with the delta of "
                    f"frame {frame} (value 1, no keyframes)")
        return {'FINISHED'}


class SQUISHYFX_OT_rebuild_node_groups(Operator):
    """Reconstruye los node groups SquishyFX desde cero (útil tras
actualizar el addon). Los modifiers existentes se remapean al árbol nuevo"""
    bl_idname = "squishyfx.rebuild_node_groups"
    bl_label = "Rebuild Node Groups"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Snapshot por NOMBRE de socket: al reconstruir cambian los
        # identificadores (Socket_N) y las claves viejas colisionarian
        # con tipos distintos. Guardar -> purgar -> restaurar.
        snapshots = []
        for obj in bpy.data.objects:
            for mod in obj.modifiers:
                if is_squishyfx_modifier(mod):
                    vals, mask_attr = {}, ""
                    for item in input_socket_items(mod.node_group):
                        if mod_input_exists(mod, item.identifier):
                            vals[item.name] = mod_get_input(
                                mod, item.identifier)
                        if item.name == "Mask":
                            mask_attr = mod_get_attribute(
                                mod, item.identifier)
                    snapshots.append((obj.name, mod.name, vals, mask_attr))

        gn.rebuild_all_trees()

        for obj_name, mod_name, vals, mask_attr in snapshots:
            obj = bpy.data.objects.get(obj_name)
            mod = obj.modifiers.get(mod_name) if obj else None
            if mod is None or not is_squishyfx_modifier(mod):
                continue
            try:
                stale = [k for k in list(mod.keys())
                         if k.startswith(("Socket_", "Input_"))]
            except TypeError:
                # 5.2+: no hay IDProperties, pero eso NO significa que no
                # haya nada obsoleto que purgar: los bindings viven en
                # mod.properties.inputs y sobreviven al remap con su
                # identificador viejo. La purga real la hace el bucle de
                # abajo, que reescribe TODOS los sockets por nombre.
                stale = []
            for key in stale:
                del mod[key]
            for item in input_socket_items(mod.node_group):
                if item.name in vals:
                    val = vals[item.name]
                    if isinstance(val, (int, float)) and not isinstance(val, bool):
                        val = _cast_value(item.socket_type, val)
                    try:
                        mod_set_input(mod, item.identifier, val)
                    except (TypeError, OverflowError):
                        pass
                else:
                    # Socket nuevo (o renombrado): NO se puede dejar el
                    # binding heredado. Los identificadores Socket_N se
                    # renumeran al insertar un socket, así que el valor que
                    # el modifier guardaba bajo este identificador puede ser
                    # de OTRO TIPO. Ocurrió de verdad al añadir "Deep
                    # Contact": Socket_11 pasó de Collision Collection a
                    # Collision Object y el modifier siguió guardando ahí un
                    # datablock Collection. En memoria Blender lo toleraba;
                    # al RECARGAR el archivo, Object Info leía esa Collection
                    # como Object* y crasheaba con ACCESS_VIOLATION en el
                    # producto de matrices. Resetear siempre al default.
                    try:
                        mod_set_input(mod, item.identifier,
                                      getattr(item, "default_value", None))
                    except (TypeError, OverflowError, AttributeError):
                        pass
                if item.name == "Mask" and mask_attr:
                    mod_set_attribute(mod, item.identifier, mask_attr)
            force_modifier_update(obj)

        self.report({'INFO'},
                    "Node groups rebuilt; modifiers remapped without "
                    "losing values")
        return {'FINISHED'}


classes = (
    SQUISHYFX_OT_apply_effect,
    SQUISHYFX_OT_apply_preset,
    SQUISHYFX_OT_save_preset,
    SQUISHYFX_OT_delete_preset,
    SQUISHYFX_OT_detect_colliders,
    SQUISHYFX_OT_add_collider_sphere,
    SQUISHYFX_OT_remove_effect,
    SQUISHYFX_OT_bake_shapekeys,
    SQUISHYFX_OT_bake_current_frame,
    SQUISHYFX_OT_rebuild_node_groups,
)


_collider_sync_sig = [None]


@persistent
def _sfx_collider_autosync(scene, depsgraph=None):
    """Auto-sincroniza los colisionadores: activar Physics > Collision en
    cualquier objeto basta para que colisione — sin pulsar Detect
    Colliders. Solo actúa cuando cambia la FIRMA (qué objetos tienen
    Collision), así es un no-op barato en el resto de updates y no se
    retroalimenta: enlazar a la colección no cambia la firma. Los
    colisionadores con riesgo de ciclo/casco abierto se sustituyen por su
    proxy cerrado (construido bajo demanda; aquí NO se reconstruye malla)."""
    if _proxy_building[0]:
        return  # reentrada: estamos dentro de una reconstrucción de proxy
    try:
        screen = bpy.context.screen
        if screen is not None and screen.is_animation_playing:
            return
    except AttributeError:
        pass
    # La firma incluye si la auto-colección existe: borrarla (aun con los
    # mismos colisionadores) vuelve a disparar el re-enlace.
    sig = (frozenset(ob.name for ob in scene.objects
                     if ob.type == 'MESH' and is_collider(ob)),
           COLLIDER_COLLECTION in bpy.data.collections)
    if sig == _collider_sync_sig[0]:
        return
    _collider_sync_sig[0] = sig
    targets = [ob for ob in scene.objects if ob.type == 'MESH'
               and any(is_squishyfx_modifier(m) for m in ob.modifiers)]
    if not targets:
        return
    coll, _count, _skipped = ensure_collider_collection(
        bpy.context, refresh_proxies=False)
    for ob in targets:
        for mod in ob.modifiers:
            if not is_squishyfx_modifier(mod):
                continue
            ident = input_identifier(mod.node_group, "Collision Collection")
            if not ident:
                continue
            cur = mod_get_input(mod, ident)
            # Re-enlaza si el modifier no apunta a NADA, o a un datablock
            # con el nombre de la auto-colección (posible referencia
            # colgante tras borrar/rehacer). Una colección con OTRO nombre
            # es una elección manual del usuario y se respeta.
            if cur is None or (getattr(cur, "name", "") == COLLIDER_COLLECTION
                               and cur is not coll):
                mod_set_input(mod, ident, coll)
            elif cur is coll:
                pass  # ya correcto


@persistent
def _sfx_load_post(_dummy=None):
    """Al abrir un archivo, invalida la caché de firma para que el
    auto-sync corra fresco sobre la escena recién cargada."""
    _collider_sync_sig[0] = None


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    handlers = bpy.app.handlers
    if hasattr(handlers, "animation_playback_pre"):
        if _sfx_playback_start not in handlers.animation_playback_pre:
            handlers.animation_playback_pre.append(_sfx_playback_start)
        if _sfx_playback_stop not in handlers.animation_playback_post:
            handlers.animation_playback_post.append(_sfx_playback_stop)
    if _sfx_impulse_update not in handlers.frame_change_pre:
        handlers.frame_change_pre.append(_sfx_impulse_update)
    if _sfx_collider_autosync not in handlers.depsgraph_update_post:
        handlers.depsgraph_update_post.append(_sfx_collider_autosync)
    if _sfx_load_post not in handlers.load_post:
        handlers.load_post.append(_sfx_load_post)


def unregister():
    handlers = bpy.app.handlers
    if hasattr(handlers, "animation_playback_pre"):
        for lst, fn in ((handlers.animation_playback_pre, _sfx_playback_start),
                        (handlers.animation_playback_post, _sfx_playback_stop)):
            if fn in lst:
                lst.remove(fn)
    if _sfx_impulse_update in handlers.frame_change_pre:
        handlers.frame_change_pre.remove(_sfx_impulse_update)
    if _sfx_collider_autosync in handlers.depsgraph_update_post:
        handlers.depsgraph_update_post.remove(_sfx_collider_autosync)
    if _sfx_load_post in handlers.load_post:
        handlers.load_post.remove(_sfx_load_post)
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
