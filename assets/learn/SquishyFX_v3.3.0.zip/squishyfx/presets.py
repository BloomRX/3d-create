# -*- coding: utf-8 -*-
"""
SquishyFX - presets.py  (v2.0 - stateless Raycast-based contact)
The "params" keys must match the sockets declared in geometry_nodes.py.
"""

PRESETS = {
    "Soft Flesh": {
        "effect": 'SQUISH',
        "description": "Soft flesh (glutes, thighs): rounded footprint, "
                       "volumen y flujo lateral naturales",
        "params": {
            "Intensity": 1.0,
            "Shape Smoothing": 8,
            "Spread": 10,
            "Volume Preservation": 1.0,
            "Lateral Flow": 0.6,
            "Contact Hardness": 0.8,
            "Corrective Smooth": 3,
            "Collision Offset": 0.01,
        },
    },
    "Memory Foam": {
        "effect": 'SQUISH',
        "description": "Foam: wide halo, recovers without bulging",
        "params": {
            "Intensity": 1.0,
            "Shape Smoothing": 10,
            "Spread": 12,
            "Volume Preservation": 0.4,
            "Lateral Flow": 0.25,
            "Contact Hardness": 0.75,
            "Corrective Smooth": 3,
        },
    },
    "Elastic Rubber": {
        "effect": 'SQUISH',
        "description": "Goma: huella definida y abultamiento marcado",
        "params": {
            "Intensity": 1.0,
            "Shape Smoothing": 4,
            "Spread": 6,
            "Volume Preservation": 1.4,
            "Lateral Flow": 0.6,
            "Contact Hardness": 0.95,
            "Corrective Smooth": 2,
        },
    },
    "Glute Jiggle": {
        "effect": 'JIGGLE',
        "description": "Glute fat: large lobes, pronounced lateral slosh "
                       "(PLAYBACK ONLY)",
        "params": {
            "Amplitude": 0.06,
            "Wobble Scale": 2.2,
            "Wobble Speed": 2.5,
            "Lateral Motion": 1.2,
            "Normal Motion": 0.5,
            "Decay": 1.0,
            "Dent Depth": 1.0,
            "Impact Sensitivity": 2.5,
            "Relax Time": 0.5,
            "Smoothing": 3,
        },
    },
    "Heavy Fat": {
        "effect": 'JIGGLE',
        "description": "Heavy fat: large slow masses with a deep "
                       "bounce (PLAYBACK ONLY)",
        "params": {
            "Amplitude": 0.09,
            "Wobble Scale": 1.6,
            "Wobble Speed": 1.5,
            "Lateral Motion": 1.0,
            "Normal Motion": 0.8,
            "Decay": 0.7,
            "Dent Depth": 1.0,
            "Impact Sensitivity": 2.0,
            "Relax Time": 0.9,
            "Smoothing": 3,
        },
    },
    "Squishy Jelly": {
        "effect": 'RIPPLE',
        "description": "Jelly: dense fast waves while contact lasts",
        "params": {
            "Amplitude": 0.25,
            "Frequency": 10.0,
            "Wave Speed": 6.0,
            "Decay": 1.2,
            "Dent Depth": 1.0,
            "Impact Sensitivity": 2.0,
            "Relax Time": 0.7,
            "Smoothing": 2,
        },
    },
    "Water Surface": {
        "effect": 'RIPPLE',
        "description": "Water: wide slow waves that travel far",
        "params": {
            "Amplitude": 0.35,
            "Frequency": 4.0,
            "Wave Speed": 2.5,
            "Decay": 0.35,
            "Dent Depth": 1.0,
            "Impact Sensitivity": 1.5,
            "Relax Time": 1.2,
            "Smoothing": 3,
        },
    },
    "Soft Balloon": {
        "effect": 'SQUISH_INFLATE',
        "description": "Balloon: denting it visibly inflates the rest",
        "params": {
            "Squish Strength": 1.0,
            "Inflate Pressure": 1.6,
            "Shape Smoothing": 8,
            "Spread": 10,
            "Volume Preservation": 0.4,
            "Lateral Flow": 0.4,
            "Contact Hardness": 0.8,
            "Corrective Smooth": 2,
        },
    },
    "Tight Grip": {
        "effect": 'PENETRATION',
        "description": "Canal apretado: agarre firme y pegado, pulso marcado",
        "params": {
            "Grip Intensity": 1.5,
            "Tightness": 0.9,
            "Reach": 0.025,
            "Clench Amount": 0.5,
            "Clench Speed": 5.0,
            "Jiggle": 0.3,
            "Wetness": 0.4,
            "Collision Offset": 0.004,
            "Smoothing": 3,
        },
    },
    "Wet & Loose": {
        "effect": 'PENETRATION',
        "description": "Soft wet channel: gentle grip, high sheen and "
                       "jiggle",
        "params": {
            "Grip Intensity": 0.7,
            "Tightness": 0.4,
            "Reach": 0.05,
            "Clench Amount": 0.2,
            "Clench Speed": 2.0,
            "Jiggle": 0.6,
            "Wetness": 0.9,
            "Collision Offset": 0.01,
            "Smoothing": 4,
        },
    },
    "Pixar Flesh": {
        "effect": 'SQUISH_ORGANIC',
        "description": "Animated character flesh: very soft contact, "
                       "pronounced squash & stretch with preserved volume and "
                       "wobble after impact (squash/jiggle ON PLAYBACK)",
        "params": {
            "Squish Intensity": 1.2,
            "Direction Influence": 0.7,
            "Volume Preservation": 1.0,
            "Collision Strength": 1.2,
            "Collision Softness": 0.55,
            "Velocity Influence": 1.0,
            "Jiggle": 0.5,
            "Collision Offset": 0.01,
            "Impact Sensitivity": 2.0,
            "Relax Time": 0.6,
        },
    },
    "Bouncy Rubber": {
        "effect": 'SQUISH_INFLATE',
        "description": "Dense rubber: firm dent with subtle inflation",
        "params": {
            "Squish Strength": 1.0,
            "Inflate Pressure": 0.7,
            "Shape Smoothing": 5,
            "Spread": 6,
            "Volume Preservation": 0.6,
            "Lateral Flow": 0.5,
            "Contact Hardness": 0.9,
            "Corrective Smooth": 2,
        },
    },
}


def preset_enum_items():
    return [
        (name, name, data.get("description", ""))
        for name, data in PRESETS.items()
    ]


# ---------------------------------------------------------------------------
# User CUSTOM presets: JSON in Blender's configuration folder, so they
# persist across .blend files and across sessions.
#
# This file is a USER-EDITABLE surface (by hand, sync, other addon
# versions), so it is treated as hostile input: validated thoroughly on
# read (the audit found crashes in the menu and the enum with a non-dict
# JSON or unknown effects), written atomically, and an unreadable file is
# KEPT under a new name instead of being overwritten.
# ---------------------------------------------------------------------------

import json
import os

import bpy

# Valid effect keys (mirrors geometry_nodes.BUILDERS; deliberately static
# to avoid importing the heavy bpy stack here). Entries with another
# effect (a hand-made typo or a preset from a future version) are hidden
# from the menu but KEPT in the file.
VALID_EFFECTS = {'SQUISH', 'RIPPLE', 'SQUISH_INFLATE', 'JIGGLE',
                 'PENETRATION', 'SQUISH_ORGANIC'}

# mtime cache: the preset menu and the dynamic enum call
# load_custom_presets ON EVERY REDRAW; without a cache that is disk I/O
# per UI frame.
_cache = {"mtime": None, "presets": {}}


def _custom_presets_path():
    cfg = bpy.utils.user_resource('CONFIG', path="squishyfx", create=True)
    return os.path.join(cfg, "custom_presets.json")


def _load_raw():
    """Raw dict exactly as stored on disk; None if unreadable or not a dict."""
    path = _custom_presets_path()
    if not os.path.isfile(path):
        return {}
    try:
        with open(path, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError):
        return None
    return data if isinstance(data, dict) else None


def _entry_valid(name, p):
    return (isinstance(name, str) and name.strip()
            and name not in PRESETS          # never shadow the built-ins
            and isinstance(p, dict)
            and p.get("effect") in VALID_EFFECTS
            and isinstance(p.get("params"), dict)
            and isinstance(p.get("description", ""), str)
            and all(isinstance(v, (int, float, bool))
                    for v in p["params"].values()))


def load_custom_presets():
    """Dict {name: {effect, description, params}} - VALID entries only.
    Nunca lanza: un archivo corrupto/ajeno devuelve {} (y save lo preserva
     renamed before being overwritten)."""
    path = _custom_presets_path()
    try:
        mtime = os.path.getmtime(path)
    except OSError:
        return {}
    if _cache["mtime"] == mtime:
        return _cache["presets"]
    raw = _load_raw()
    presets = ({name: p for name, p in raw.items() if _entry_valid(name, p)}
               if raw else {})
    _cache["mtime"] = mtime
    _cache["presets"] = presets
    return presets


def _write_atomic(data):
    """Atomic write: tmp + os.replace. An interrupted write never leaves
    the file broken (a plain open('w') truncates first)."""
    path = _custom_presets_path()
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=2, ensure_ascii=False)
    os.replace(tmp, path)
    _cache["mtime"] = None  # invalidate: re-read on next access


def save_custom_preset(name, effect, params, description=""):
    """May raise OSError (disk full, permissions, antivirus): the calling
    operator catches and reports it."""
    raw = _load_raw()
    if raw is None:
        # File present but unreadable: keep it before writing;
        # overwriting would silently destroy the user's presets.
        path = _custom_presets_path()
        try:
            os.replace(path, path + ".corrupt")
        except OSError:
            pass
        raw = {}
    raw[name] = {"effect": effect, "description": description,
                 "params": params}
    _write_atomic(raw)


def delete_custom_preset(name):
    raw = _load_raw()
    if raw and name in raw:
        del raw[name]
        _write_atomic(raw)
        return True
    return False


def all_presets():
    """Built-ins + valid customs (built-ins cannot be overridden:
    _entry_valid rejects customs using a reserved name)."""
    merged = dict(PRESETS)
    merged.update(load_custom_presets())
    return merged
