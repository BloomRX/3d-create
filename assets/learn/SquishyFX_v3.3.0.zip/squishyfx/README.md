# SquishyFX

Non-destructive soft-body effects for Blender 5.2, driven by Geometry Nodes
and a small set of Python handlers. SquishyFX makes flesh react to
colliders — squashing, bulging, jiggling and rippling — without ever
touching the base mesh, without a physics cache, and without leaving the
modifier stack.

**Version 3.3.0**

---

## Table of contents

1. [How it works](#how-it-works)
2. [Quick start](#quick-start)
3. [The collision core](#the-collision-core)
4. [Effects reference](#effects-reference)
5. [Colliders](#colliders)
6. [Masking with vertex groups](#masking-with-vertex-groups)
7. [The impulse system](#the-impulse-system)
8. [Baking](#baking)
9. [Presets](#presets)
10. [Operator reference](#operator-reference)
11. [Placement in the modifier stack](#placement-in-the-modifier-stack)
12. [Troubleshooting](#troubleshooting)
13. [Changelog](#changelog)
14. [Architecture](#architecture)

---

## How it works

Every effect is a Geometry Nodes group generated procedurally by Python.
Adding an effect creates a node group (if it does not exist yet) and a
modifier that references it, so the deformation is evaluated live in the
viewport and at render time.

Two things live outside the node tree:

- **Frame handlers** compute the impulse envelope (see
  [The impulse system](#the-impulse-system)), because a Geometry Nodes
  tree cannot remember what happened on the previous frame without a
  Simulation Zone.
- **Operators** handle collider wiring, presets, baking and node group
  rebuilds.

Nothing is destructive. Disable the modifier and the mesh is exactly as it
was.

---

## Quick start

1. **Mark your colliders.** Select the objects that should push the flesh
   and press **Detect Colliders**, or press **Add Collider Sphere** to
   create one. Both put the objects into the `SquishyFX Colliders`
   collection.
2. **Select the flesh object** and, optionally, assign a vertex group to
   limit the effect to one region (a breast, a glute, a belly).
3. **Apply an effect** from the panel. Set **Mask** to your vertex group.
4. **Tune.** Start with *Collision Offset* and the effect's main strength
   slider; everything else is refinement.
5. Press **Play** for the motion-based effects (Fat Jiggle, Ripple,
   Penetration, Squish Organic) — they are gated on playback so the
   viewport stays responsive while you model.

---

## The collision core

All effects share the same contact solver, which is what gives them a
consistent look. Understanding it makes every slider obvious.

### Inside test

Before anything deforms, each vertex has to be classified as inside or
outside the collider. SquishyFX uses two independent probes and takes
whichever one fires:

- **Normal probe** — a ray along the vertex normal. If the first thing it
  hits is a *back face* of the collider, the vertex is inside.
- **Fixed dual-axis probe** — two rays along a generic direction and its
  opposite, independent of the vertex normal. This catches the cases the
  normal probe misses: normals lying tangent to the collider surface,
  protruding volumes, and contacts where the normal ray exits through a
  *different* collider's front face.

A veto pass then discards false positives (a vertex only counts as inside
if the opposite direction also hits the collider), and a self-collision
range guard prevents a mesh from detecting itself across the body.

### Flesh conform

Projecting each vertex onto the nearest point of the collider — the
classic approach — never looks like flesh: it sucks vertices onto the
surface, stamps the collider's silhouette into the mesh, and pinches
ridges along its edges. SquishyFX instead does what flesh does:

1. **Flattens** against the pushing face. The contact axis is estimated
   from the average normal of the contact region (weighted by
   inside × Mask), and each vertex escapes along that axis. Because the
   axis is constant across a contact, neighbouring vertices move
   coherently and the surface does not tear.
2. **Spills** sideways. A radial escape perpendicular to the contact axis
   pushes flesh out around the flanks of the collider — the bulge you
   expect around a pressing object.

The two escapes are blended per vertex with a biased smooth-minimum
controlled by **Splay** (0 = flatten only, 1 = spill only), so the shorter
path wins with a continuous transition.

### Skin ramp

**Collision Offset** is the thickness of skin kept between flesh and
collider. It is not applied as a constant: it ramps in with penetration
depth (`offset × min(p / 2·offset, 1)`). A grazing touch deforms almost
nothing and releases cleanly; firm pressure gets the full offset and never
clips. This is what removes the "suction" artifact when a collider pulls
away.

### Density-aware smoothing

Blur Attribute diffuses across topological rings, not distance. On a dense
mesh the same iteration count covers millimetres instead of centimetres and
the smoothing collapses into sharp seams and spiky ridges. SquishyFX
measures the mean edge length of the incoming mesh and scales the
iterations by `clamp(8 mm / mean_edge, 1, 6)`. On normal-density meshes
the factor is 1 and the sliders behave exactly as labelled.

---

## Effects reference

Every effect exposes **Mask**, **Collision Offset**, **Collision Object**
and **Collision Collection**. Only the distinctive parameters are listed
below.

### Squish

Pure compression. Flesh flattens where the collider presses and flows
around it. The workhorse for static poses and contact shots.

| Parameter | Meaning |
|---|---|
| Intensity | Overall amount of compression. |
| Shape Smoothing | Diffusion of the contact footprint. Higher = softer, wider deformation. |
| Spread | Radius of the surrounding halo that reacts to the contact. |
| Volume Preservation | How much displaced volume is pushed back out around the contact. |
| Lateral Flow | Sideways flow of flesh away from the contact centre. |
| Contact Hardness | Strength of the second, corrective pass that cleans up residual clipping. |
| Corrective Smooth | Final relaxation pass over the deformed region. |
| Splay | Flatten (0) vs. spill sideways (1). |
| Self Collision | Let the mesh collide with itself. |

### Squish & Inflate

Squish plus outward pressure, for flesh that reads as full rather than
merely compressed.

| Parameter | Default | Meaning |
|---|---|---|
| Squish Strength | 1.38 | Compression amount. |
| Inflate Pressure | 1.0 | Outward pressure applied across the masked region. |
| Shape Smoothing | 11 | Footprint diffusion. |
| Spread | 9 | Halo radius. |
| Volume Preservation | 0.26 | Volume pushed back out. |
| Lateral Flow | 0.0 | Sideways flow. |
| Contact Hardness | 0.0 | Corrective pass strength. |
| Corrective Smooth | 10 | Final relaxation. |
| Collision Offset | 0.0011 | Skin thickness. |
| Splay | 0.0 | Flatten vs. spill. |

### Squish Organic

Velocity-aware squish with secondary motion — flesh that reacts to *how*
the collider arrives, not just where it is.

| Parameter | Default | Meaning |
|---|---|---|
| Squish Intensity | 1.0 | Compression amount. |
| Direction Influence | 0.7 | How much the collider's travel direction steers the deformation. |
| Volume Preservation | 0.9 | Volume pushed back out. |
| Collision Strength | 1.2 | Weight of the contact term. |
| Collision Softness | 0.4 | Softness of the contact falloff. |
| Stiffness | 0.6 | Resistance of the flesh; higher settles faster. |
| Velocity Influence | 1.0 | How strongly relative velocity drives the effect. |
| Jiggle | 0.4 | Amount of secondary wobble. |
| Collision Offset | 0.015 | Skin thickness. |

Requires playback for the velocity and jiggle terms.

### Fat Jiggle

Physics-flavoured wobble that fires on impact and decays. The effect used
for glutes, breasts and bellies.

| Parameter | Default | Meaning |
|---|---|---|
| Amplitude | 0.08 | Size of the wobble, in metres. |
| Wobble Scale | 2.5 | Spatial frequency of the wobble field. |
| Wobble Speed | 2.0 | Oscillation rate. |
| Lateral Motion | 1.0 | Wobble component across the surface. |
| Normal Motion | 0.6 | Wobble component along the normal. |
| Decay | 1.2 | How fast the wobble dies down. |
| Dent Depth | 1.0 | Depth of the static contact dent. |
| Impact Sensitivity | 1.5 | How much a hit injects into the energy envelope. |
| Relax Time | 0.6 | Seconds for the energy to fall to 1/e. |
| Energy | 0.0 | Driven by the handler; do not key it by hand. |
| Smoothing | 2 | Diffusion of the wobble offsets. |

### Ripple

Travelling waves radiating from the impact point. Good for slaps and
impacts on broad surfaces.

| Parameter | Meaning |
|---|---|
| Amplitude | Wave height. |
| Frequency | Number of wave crests. |
| Wave Speed | Propagation speed. |
| Decay | Distance falloff of the wave train. |
| Dent Depth | Depth of the static contact dent. |

### Penetration

Contact-driven grip and clench around an inserted collider.

| Parameter | Default | Meaning |
|---|---|---|
| Grip Intensity | 1.0 | Overall strength of the grip. |
| Tightness | 0.6 | How closely the flesh wraps the collider. |
| Reach | 0.03 | Distance around the collider that responds, in metres. |
| Clench Amount | 0.3 | Amplitude of the rhythmic clench. |
| Clench Speed | 3.0 | Rate of the clench. |
| Jiggle | 0.4 | Secondary motion. |
| Wetness | 0.5 | Drives the `squishyfx_wet` attribute for shading. |
| Smoothing | 3 | Diffusion of the deformation. |
| Collision Offset | 0.006 | Skin thickness. |

---

## Colliders

Colliders are ordinary objects. Two ways to feed them to an effect:

- **Collision Collection** (recommended) — every object in the collection
  pushes the flesh. **Detect Colliders** and **Add Collider Sphere** both
  maintain the `SquishyFX Colliders` collection for you.
- **Collision Object** — a single object, when you want one effect to
  respond to one thing only.

Closed, manifold meshes work best: the inside test relies on crossing a
back face. Colliders may be animated, parented, or driven by an armature —
the impulse system measures *relative* velocity, so it makes no difference
whether the collider moves into the body or the body moves into the
collider.

**Self Collision** treats the deformed mesh as its own collider, with a
range guard so distant parts of the body do not falsely register.

---

## Masking with vertex groups

Set **Mask** to a vertex group and the effect only applies where the group
has weight. Weights are used as a multiplier, so feathered edges give
feathered transitions — paint a soft falloff at the border of a breast or
glute and the deformation will blend into the surrounding body instead of
stopping at a hard line.

The mask also weights the contact-axis estimate, so a well-painted group
makes the flesh conform behave better, not just smaller.

---

## The impulse system

Geometry Nodes has no memory between frames. SquishyFX keeps an energy
envelope in Python instead, updated on `frame_change_pre`:

```
E = E · exp(-dt / Relax Time) + hit · Impact Sensitivity
```

`hit` is derived from the **relative** speed between collider and flesh
while they overlap. When the collider is parented to or driven by an
armature, the flesh's own velocity is taken from the nearest deform bone,
so animating the character into a static collider injects energy exactly
like animating the collider into the character.

- **Energy** and **Playing** are written by the handler; they are hidden in
  the panel and should not be keyed by hand.
- Effects that depend on the envelope are gated on playback: with the
  timeline stopped, they contribute exactly zero.
- The envelope resets when playback starts and before a bake, so results
  are deterministic.

---

## Baking

**Bake to Shape Keys** converts the live effect into keyframed shape keys —
useful for handing a scene to someone without the addon, or for exporting.

The bake stores only the SquishyFX *delta*. For each frame the stack is
evaluated twice, once with the effects on and once with them off, and the
difference is written on top of the Basis. Armature pose, active morphs and
displacement modifiers therefore cancel out and are never baked twice.
Topology-changing modifiers (Mask, Subdivision, Mirror…) are disabled for
the measurement and restored automatically, together with the current
frame, the playback state and the impulse envelope.

Enable **Disable modifiers after baking** so the baked keys do not stack on
top of the still-live effect.

**Bake Current Frame** does the same for a single frame.

---

## Presets

**Save Preset** stores the current effect's parameters under a name;
**Apply Preset** restores them onto the selected effect; **Delete Preset**
removes one. Presets are per effect type, so a Fat Jiggle preset only
offers itself to Fat Jiggle modifiers.

---

## Operator reference

| Operator | What it does |
|---|---|
| Apply Effect | Creates the node group if needed and adds the modifier. |
| Remove Effect | Removes the modifier from the active object. |
| Detect Colliders | Collects flagged objects into `SquishyFX Colliders`. |
| Add Collider Sphere | Creates a sphere collider and registers it. |
| Apply / Save / Delete Preset | Preset management. |
| Bake to Shape Keys | Delta bake across a frame range. |
| Bake Current Frame | Delta bake of a single frame. |
| Rebuild Node Groups | Regenerates all trees from the current addon version, remapping existing modifiers by socket name so tuned values survive. |

Run **Rebuild Node Groups** after updating the addon: trees saved in a
`.blend` were built by whichever version created them, and the rebuild
brings them up to date without losing your settings.

---

## Placement in the modifier stack

Put SquishyFX modifiers **before Subdivision Surface**. The effect then
runs on the base cage instead of the subdivided mesh — visually equivalent,
an order of magnitude faster, and immune to the density issues that dense
topology causes in blur-based smoothing. Place them after the Armature, so
the flesh is deformed in its posed position.

---

## Troubleshooting

**Nothing deforms.**
Check that the collider is actually in the Collision Collection (or set as
Collision Object), that the collider mesh is closed, and that the vertex
group in Mask has weight where you expect. If the collider only grazes the
surface, raise Collision Offset — the skin ramp deliberately does almost
nothing at very shallow penetration.

**The mesh tears or spikes at the contact edge.**
Raise Shape Smoothing and Spread, and lower Contact Hardness. If the
collider engulfs a protruding volume, reduce how deep it sits: a collider
swallowing several centimetres of flesh has no non-violent solution.

**The collider seems to drag the flesh when it pulls away.**
That is the skin ramp doing its job in reverse; if it persists, lower
Collision Offset.

**Playback is slow.**
Move the modifiers before Subdivision, lower Corrective Smooth and
Smoothing, and prefer a Collision Collection with only the objects that
matter.

**Values look wrong after updating.**
Run Rebuild Node Groups.

**Questions contact Bann0r**
Got any questions? Hit me up Bann0r from ZoneGFX
Gey6
---

## Changelog

### 3.3.0
Fat Jiggle, Ripple and Penetration now use the same flesh conform as Squish
and Squish & Inflate — directional flattening along the contact axis
instead of nearest-point projection. Measured on a glute contact, edge
stretch in the contact region dropped from 1.16x to 1.03x (99th percentile
1.14x to 1.01x) while the dent deepened from 2.93 cm to 4.63 cm. Squish and
Squish & Inflate are unchanged.

### 3.2.0
Added the fixed dual-axis inside probe, combined with the existing normal
probe. Detection no longer depends on vertex normal orientation.

### 2.4.x
Density-aware blur iterations; contact conform via nearest-surface escape;
skin ramp on Collision Offset (removed the release "suction"); delta-based
Bake to Shape Keys with full stack restoration; relative collider/rig
velocity in the impulse envelope.

---

## Architecture

| File | Responsibility |
|---|---|
| `__init__.py` | Registration and `bl_info`. |
| `geometry_nodes.py` | All node group builders and the shared contact solver. |
| `operators.py` | Operators, the Blender 5.x modifier-socket compatibility layer, and the frame handlers. |
| `properties.py` | Scene and object property groups. |
| `ui.py` | Panels. |
| `presets.py` | Built-in and user presets. |

The socket compatibility layer matters if you extend the addon: in Blender
5.x a modifier's inputs are typed structs rather than plain values, and
actions store their curves in layers, so `mod_get_input` / `mod_set_input`
and the keyframe helpers in `operators.py` should be used instead of
touching the data directly.
