import bpy
import os

def _addon_id_from_package(pkg: str) -> str:
    # Works for both classic add-ons and namespaced Extensions
    parts = (pkg or "").split(".")
    if parts and parts[0] in {"bl_ext", "bl_contrib"} and len(parts) >= 2:
        return parts[1]           # <-- just the extension id, e.g. "JiggleMaker"
    return parts[0] if parts else ""

class MY_preferences(bpy.types.AddonPreferences):
    bl_idname = "bl_ext.user_default.JiggleMaker"

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        header = box.row()
        header.alignment = 'CENTER'
        header.scale_y = 1.2
        header.label(text="Custom Presets & Meshes", icon='INFO')

        info = [
            "• Open the 'resources/presets.blend' and add your meshes.",
            "• Each mesh appears as a button in the Jiggle Maker panel.",
            "• Press Refresh after changing the library file."
        ]
        for line in info:
            row = box.row()
            row.alignment = 'LEFT'
            row.label(text=line)

        warn = [
            "• The bundled presets file targets Blender 3.6 for compatibility.",
            "• Editing and saving it with Blender 4.x may break compatibility in 3.6."
        ]
        for line in warn:
            row = box.row()
            row.alignment = 'LEFT'
            row.alert = True
            row.label(text=line)

        row = layout.row(align=True)
        row.operator("wm.open_plugin_directory", icon='FILE_FOLDER')
        row.operator("wm.refresh_library", icon='FILE_REFRESH')
        row.operator("wm.jm_install_builtin_cloth_presets", icon='FILE_TICK', text="Install Cloth Presets")
