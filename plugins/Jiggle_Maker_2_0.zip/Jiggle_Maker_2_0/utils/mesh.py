import bpy

def make_invisible(obj):
    obj.display_type = 'WIRE'
    obj.visible_camera = False
    obj.visible_diffuse = False
    obj.visible_glossy = False
    obj.visible_transmission = False
    obj.visible_volume_scatter = False
    obj.visible_shadow = False
    obj.hide_render = True

def vertex_group_exists(target_object, group_name):
    return group_name in target_object.vertex_groups

def get_modifier_by_type(obj, modifier_type):
    for modifier in obj.modifiers:
        if modifier.type == modifier_type:
            return modifier
    return None

def make_group_stiff(obj, group_name):
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.mode_set(mode='EDIT')
    obj.vertex_groups.active = obj.vertex_groups[group_name]
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.object.vertex_group_select()
    bpy.ops.mesh.select_all(action='INVERT')
    bpy.context.scene.tool_settings.vertex_group_weight = 0.5
    bpy.ops.object.vertex_group_assign()
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.context.scene.tool_settings.vertex_group_weight = 1.0
    return group_name

def remove_vertex_group(obj, groupname):
    if groupname in obj.vertex_groups:
        obj.vertex_groups.remove(obj.vertex_groups[groupname])

def apply_transform(*objects):
    report_msgs = []
    for obj in objects:
        if obj is None:
            continue
        bpy.context.view_layer.objects.active = obj
        obj.select_set(True)
        changed = (
            obj.location.length != 0 or
            obj.rotation_euler.to_matrix().to_4x4() != bpy.context.scene.cursor.matrix or
            obj.scale.x != 1 or obj.scale.y != 1 or obj.scale.z != 1
        )
        if changed:
            bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
            report_msgs.append(f"Applied transforms on {obj.name}")
        obj.select_set(False)
    return "; ".join(report_msgs)

def remove_modifier(obj, name):
    for m in list(obj.modifiers):
        if m.name == name:
            obj.modifiers.remove(m)

def duplicate_object(obj, new_name):
    bpy.ops.object.mode_set(mode='OBJECT')
    bpy.ops.object.select_all(action='DESELECT')
    obj.select_set(True)
    bpy.context.view_layer.objects.active = obj
    bpy.ops.object.duplicate(linked=False)
    dup = bpy.context.selected_objects[0]
    dup.name = new_name
    return dup

def remove_if_found(name):
    obj = bpy.data.objects.get(name)
    if obj:
        data = getattr(obj, "data", None)
        try:
            bpy.data.objects.remove(obj, do_unlink=True)
        except:
            pass
        if data and data.users == 0:
            try:
                bpy.data.meshes.remove(data)
            except:
                pass

def duplicate_mirror(proxy):
    import bpy

    bpy.context.scene.transform_orientation_slots[0].type = 'GLOBAL'
    bpy.context.scene.tool_settings.use_keyframe_insert_auto = False

    base = proxy.name
    if base.endswith((".L", ".R", "_L", "_R")):
        base = base[:-2]

    existing_r = bpy.data.objects.get(base + ".R")
    if existing_r:
        # If the mirrored proxy already exists, just return it
        return existing_r

    # Otherwise, create the mirrored duplicate
    bpy.ops.object.select_all(action='DESELECT')
    proxy.select_set(True)
    bpy.context.view_layer.objects.active = proxy
    bpy.ops.object.duplicate()
    proxy2 = bpy.context.selected_objects[0]

    proxy.name = base + ".L"
    proxy2.name = base + ".R"

    bpy.ops.transform.resize(value=(-1, 1, 1), orient_type='GLOBAL')
    bpy.ops.object.transform_apply(location=True, rotation=True, scale=True)
    bpy.context.view_layer.objects.active = proxy2
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.normals_make_consistent(inside=False)
    bpy.ops.object.mode_set(mode='OBJECT')

    return proxy2

