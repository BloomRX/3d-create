import os

def addon_dir():
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

def resources_dir():
    return os.path.join(addon_dir(), "resources")

def meshes_dir():
    return os.path.join(resources_dir(), "meshes")

def presets_path():
    return os.path.join(resources_dir(), "presets.blend")

def mesh_path(size: str):
    filename = {
        "big": "Boob_Proxy_Big.fbx",
        "med": "Boob_Proxy_Med.fbx",
        "small": "Boob_Proxy_Small.fbx",
    }[size]
    return os.path.join(meshes_dir(), filename)
