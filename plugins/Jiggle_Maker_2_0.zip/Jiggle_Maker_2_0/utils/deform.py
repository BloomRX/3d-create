import bpy
from .mesh import vertex_group_exists
import math

def add_vertex_group_by_distance(source_obj, target_obj, group_name, max_distance):
    mask_mod_states = {}
    for modifier in target_obj.modifiers:
        if modifier.type == 'MASK':
            mask_mod_states[modifier] = modifier.show_viewport
            modifier.show_viewport = False

    deps = bpy.context.evaluated_depsgraph_get()
    source_eval = source_obj.evaluated_get(deps).data
    target_eval = target_obj.evaluated_get(deps).data

    vertex_group = target_obj.vertex_groups.new(name=group_name)

    for t_vert in target_eval.vertices:
        min_dist = min((s_vert.co - t_vert.co).length for s_vert in source_eval.vertices)
        if min_dist <= max_distance:
            vertex_group.add([t_vert.index], 1.0, 'REPLACE')

    bpy.context.view_layer.objects.active = target_obj
    if vertex_group_exists(target_obj, vertex_group.name):
        try:
            bpy.ops.paint.weight_paint_toggle()
            target_obj.vertex_groups.active = target_obj.vertex_groups[vertex_group.name]
            bpy.ops.object.vertex_group_smooth(group_select_mode='ACTIVE', factor=0.50, repeat=3, expand=0)
            bpy.ops.object.vertex_group_levels(group_select_mode='ACTIVE', offset=0.5, gain=1)
            bpy.ops.object.vertex_group_clean(group_select_mode='ACTIVE', limit=0.9, keep_single=False)
            bpy.ops.object.vertex_group_smooth(group_select_mode='ACTIVE', factor=0.8, repeat=3, expand=-0.1)
        finally:
            bpy.ops.paint.weight_paint_toggle()

    for mod, state in mask_mod_states.items():
        mod.show_viewport = state
    return vertex_group

def data_transfer(src, dst):
    bpy.context.view_layer.objects.active = src
    mod = src.modifiers.new(name="DataTransfer", type='DATA_TRANSFER')
    mod.object = dst
    mod.use_vert_data = True
    mod.data_types_verts = {'VGROUP_WEIGHTS'}
    mod.vert_mapping = 'POLYINTERP_NEAREST'
    bpy.ops.object.datalayout_transfer(modifier=mod.name)
    bpy.ops.object.modifier_apply(modifier=mod.name)
    remove_unused_weights(src, threshold=1e-6)


def surface_deform(proxy, mesh, name, vertex_group_name):
    bpy.ops.object.mode_set(mode='OBJECT')

    # Remove any existing SDef with the same name
    for m in list(mesh.modifiers):
        if m.name == name and m.type == 'SURFACE_DEFORM':
            mesh.modifiers.remove(m)

    # Create SDef
    mod = mesh.modifiers.new(name=name, type='SURFACE_DEFORM')
    mod.target = proxy
    mod.vertex_group = vertex_group_name  # set before binding

    # Find the first Armature modifier and place SDef right after it
    arm_idx = next((i for i, m in enumerate(mesh.modifiers) if m.type == 'ARMATURE'), None)
    target_index = (arm_idx + 1) if arm_idx is not None else (len(mesh.modifiers) - 1)

    # Move using RNA API (avoids operator context issues)
    from_index = mesh.modifiers.find(mod.name)
    if from_index != -1 and from_index != target_index:
        mesh.modifiers.move(from_index, target_index)

    # Bind
    bpy.context.view_layer.objects.active = mesh
    bpy.ops.object.surfacedeform_bind(modifier=mod.name)

    return mod

def remove_unused_weights(
    obj=None,
    threshold=1e-6,
    treat_negative_as_invalid=True,
    treat_nonfinite_as_invalid=True
):
    """
    Remove entire vertex groups based on actual assignments only:
      - Delete group if ANY assignment is invalid (NaN/Inf or negative).
      - Else delete if the group has NO assignments.
      - Else delete if the group's MAX valid weight <= threshold.
      - Otherwise keep the group.

    Implementation notes:
      - We do NOT modify individual vertex assignments.
      - We only consider vertices that are actually in each group.
      - Uses group *names* when removing to avoid Blender 4.5 __contains__ TypeError.
    """
    # Resolve object
    if obj is None:
        obj = bpy.context.object
    if obj is None or obj.type != 'MESH' or not obj.vertex_groups:
        return

    # Preserve context
    prev_active = bpy.context.view_layer.objects.active
    prev_mode = obj.mode
    try:
        bpy.context.view_layer.objects.active = obj
        if prev_mode != 'OBJECT':
            bpy.ops.object.mode_set(mode='OBJECT')
    except RuntimeError:
        pass

    mesh = obj.data

    # Snapshot groups (index -> (name, vg))
    groups_by_index = {vg.index: (vg.name, vg) for vg in obj.vertex_groups}

    # Per-group accumulators
    group_has_assignment = {gi: False for gi in groups_by_index.keys()}
    group_max_weight     = {gi: float('-inf') for gi in groups_by_index.keys()}
    group_has_invalid    = {gi: False for gi in groups_by_index.keys()}

    # Iterate only over actual assignments
    for v in mesh.vertices:
        for gref in v.groups:
            gi = gref.group
            entry = groups_by_index.get(gi)
            if entry is None:
                continue  # group not in our snapshot (unlikely, but safe)
            name, vg = entry
            try:
                w = vg.weight(v.index)  # robust fetch; raises if no assignment
            except RuntimeError:
                # Shouldn't happen since gref says it's assigned
                continue

            group_has_assignment[gi] = True

            nonfinite = (not math.isfinite(w)) if treat_nonfinite_as_invalid else False
            negative  = (w < 0.0) if treat_negative_as_invalid else False
            if nonfinite or negative:
                group_has_invalid[gi] = True
                # No need to track max; invalid already means delete
                continue

            if w > group_max_weight[gi]:
                group_max_weight[gi] = w

    # Decide which group *names* to delete
    groups_to_delete_names = []
    for gi, (name, _vg) in groups_by_index.items():
        if group_has_invalid[gi]:
            groups_to_delete_names.append(name)
            continue
        if not group_has_assignment[gi]:
            groups_to_delete_names.append(name)
            continue
        max_w = group_max_weight[gi]
        if max_w == float('-inf') or max_w <= threshold:
            groups_to_delete_names.append(name)

    # Remove by name (avoids __contains__ TypeError and index drift)
    for name in groups_to_delete_names:
        vg = obj.vertex_groups.get(name)
        if vg is not None:
            obj.vertex_groups.remove(vg)

    # Restore context
    try:
        if obj.mode != prev_mode:
            bpy.ops.object.mode_set(mode=prev_mode)
        if bpy.context.view_layer.objects.active != prev_active:
            bpy.context.view_layer.objects.active = prev_active
    except RuntimeError:
        pass




# def surface_deform(proxy, mesh, name, vertex_group_name):
#     bpy.ops.object.mode_set(mode='OBJECT')
#     for m in list(mesh.modifiers):
#         if m.name == name and m.type == 'SURFACE_DEFORM':
#             mesh.modifiers.remove(m)
#
#     mod = mesh.modifiers.new(name=name, type='SURFACE_DEFORM')
#     mod.target = proxy
#     bpy.context.view_layer.objects.active = mesh
#     bpy.ops.object.modifier_move_to_index(modifier=mod.name, index=1)
#     bpy.ops.object.surfacedeform_bind(modifier=mod.name)
#     mod.vertex_group = vertex_group_name
#     return mod
