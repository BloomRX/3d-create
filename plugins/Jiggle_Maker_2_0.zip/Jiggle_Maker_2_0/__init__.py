bl_info = {
    "name": "JiggleMaker",
    "description": "Premium jiggle-physics toolkit: preset proxies, vertex-group jiggle, custom proxy binding, cloth bake admin and preset saving / loading.",
    "author": "@Lewdineer <lewdineer@gmail.com>",
    "version": (2, 0, 0),
    "blender": (4, 0, 0),
    "location": "3D Viewport > N-Panel > JM",
    "doc_url": "",
    "category": "Object",
}

import bpy
from . import props
from .ui import panels, prefs, cloth_admin
from .operators import library, bind, preset_import, open_dir, cloth_bake
from .utils import paths
from . import handlers
from .ui.prefs import MY_preferences  # adjust path if your file moved

# --- JiggleMaker: built-in cloth preset installer ---------------------------
import os, pkgutil
import bpy

_BUILTIN_CLOTH_PRESETS = {
    "Firm.py":   "resources/cloth_presets/Firm.py",
    "Jiggly.py": "resources/cloth_presets/Jiggly.py",
    "Inflated.py": "resources/cloth_presets/Inflated.py",
    "Thighs.py": "resources/cloth_presets/Thighs.py",
    "Stiff.py": "resources/cloth_presets/Stiff.py",
    "NormalCloth.py": "resources/cloth_presets/NormalCloth.py",
}

def _read_resource_bytes(rel_path: str):
    """Read a resource packaged with the add-on (works zipped or as a folder)."""
    # When installed as a single .zip/.py add-on:
    try:
        data = pkgutil.get_data(__package__, rel_path)
        if data is not None:
            return data
    except Exception:
        pass
    # When installed as a normal folder:
    try:
        base = os.path.dirname(__file__)
        with open(os.path.join(base, rel_path), "rb") as f:
            return f.read()
    except Exception:
        return None

def ensure_builtin_cloth_presets():
    """Copy bundled presets into the user's cloth preset folder, idempotently."""
    dest_dir = bpy.utils.user_resource('SCRIPTS', path="presets/cloth", create=True)
    if not dest_dir:
        print("JM: Could not resolve user cloth preset directory")
        return
    for out_name, rel in _BUILTIN_CLOTH_PRESETS.items():
        data = _read_resource_bytes(rel)
        if not data:
            print(f"JM: Missing bundled preset {rel}")
            continue
        dst = os.path.join(dest_dir, out_name)
        try:
            # Only write if missing or content differs (don’t clobber user edits)
            if os.path.exists(dst):
                with open(dst, "rb") as f:
                    if f.read() == data:
                        continue
            with open(dst, "wb") as f:
                f.write(data)
            print(f"JM: Installed cloth preset -> {dst}")
        except Exception as ex:
            print(f"JM: Failed to install preset {out_name}: {ex}")

class JM_OT_InstallBuiltinClothPresets(bpy.types.Operator):
    bl_idname = "wm.jm_install_builtin_cloth_presets"
    bl_label = "Install JiggleMaker Cloth Presets"
    bl_description = "Copy JiggleMaker's bundled cloth presets into your user presets folder"
    def execute(self, context):
        ensure_builtin_cloth_presets()
        self.report({'INFO'}, "Installed JiggleMaker cloth presets.")
        return {'FINISHED'}
# ---------------------------------------------------------------------------


# Register everything EXCEPT the PropertyGroup here; we handle it explicitly.
classes = (
    # Operators
    library.RefreshLibrary,
    library.OBJECT_OT_AddPresetObject,
    preset_import.AddBoobsBig,
    preset_import.AddBoobsMed,
    preset_import.AddBoobsSmol,
    bind.BoobMagic,
    bind.BindProxy,
    bind.ConvertFromVertexGroup,
    open_dir.OpenPluginDirectoryOperator,
    cloth_bake.RefreshClothTargets,
    cloth_bake.BakeClothSelected,
    cloth_bake.FreeBakeClothSelected,
    cloth_bake.BakeClothSelectedModal,
    JM_OT_InstallBuiltinClothPresets,
    cloth_bake.WM_OT_toggle_armature_pose,
    library.AddCollision,

    # UI
    MY_preferences,
    panels.GeneralPanel,
    panels.ClothSettings,
    cloth_admin.ClothBakePanel,
    panels.ReadmePanel,

)

def register():
    # 1) PropertyGroup must be registered BEFORE we create the CollectionProperty that uses it.
    bpy.utils.register_class(props.ClothTarget)
    # 2) Create properties (including the CollectionProperty)
    props.register_props()
    # 3) Register all other classes
    for cls in classes:
        bpy.utils.register_class(cls)
    # 4) Handlers
    handlers.register_handlers()
    try:
        ensure_builtin_cloth_presets()
    except Exception as ex:
        print(f"JM: Could not ensure cloth presets: {ex}")

def unregister():
    # 1) Remove handlers
    handlers.unregister_handlers()
    # 2) Remove properties BEFORE unregistering the PropertyGroup
    props.unregister_props()
    # 3) Unregister all other classes
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    # 4) Finally, unregister the PropertyGroup
    bpy.utils.unregister_class(props.ClothTarget)

if __name__ == "__main__":
    register()
