
import bpy

def iter_cloth_modifiers(obj):
    for m in obj.modifiers:
        if m.type == 'CLOTH':
            yield m

class RefreshClothTargets(bpy.types.Operator):
    bl_idname = "wm.jm_refresh_cloth_targets"
    bl_label = "Refresh Cloth List"
    bl_description = "Scan the *current scene* for objects that have a Cloth modifier"

    def execute(self, context):
        scene = context.scene
        coll = scene.jm_cloth_targets

        # 1) Snapshot current checkbox states by object name
        prev_selected = {it.object.name: it.selected for it in coll if it.object}

        # Remember active row (by name) so we can restore it if it still exists
        active_name = None
        if 0 <= scene.jm_cloth_targets_index < len(coll):
            it = coll[scene.jm_cloth_targets_index]
            if it.object:
                active_name = it.object.name

        # 2) Build the new list from *this scene only*
        cloth_objs = [
            obj for obj in context.scene.objects
            if any(m.type == 'CLOTH' for m in obj.modifiers)
        ]

        # 3) Rebuild: clear everything so anything no longer in the scene is removed
        coll.clear()

        # (optional) stable ordering
        cloth_objs.sort(key=lambda o: o.name.casefold())

        for obj in cloth_objs:
            item = coll.add()
            item.object = obj
            # New entries start UNCHECKED; existing keep their previous state
            item.selected = prev_selected.get(obj.name, False)

        # 4) Restore active index if possible, otherwise clamp
        if active_name:
            for i, it in enumerate(coll):
                if it.object and it.object.name == active_name:
                    scene.jm_cloth_targets_index = i
                    break
            else:
                scene.jm_cloth_targets_index = 0 if len(coll) else -1
        else:
            scene.jm_cloth_targets_index = 0 if len(coll) else -1

        # 5) Redraw UI
        for area in context.screen.areas:
            if area.type in {'VIEW_3D', 'PROPERTIES'}:
                area.tag_redraw()

        self.report({'INFO'}, f"Found {len(cloth_objs)} cloth objects in this scene.")
        return {'FINISHED'}



class BakeClothSelected(bpy.types.Operator):
    bl_idname = "wm.jm_bake_cloth_selected"
    bl_label = "Bake Selected"
    bl_description = "Bake cloth caches for selected entries (blocking)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        targets = [it.object for it in scene.jm_cloth_targets if it.selected and it.object]
        if not targets:
            self.report({'WARNING'}, "No targets selected.")
            return {'CANCELLED'}

        baked = 0
        use_range = getattr(scene, 'jm_bake_use_range', False)
        s = int(getattr(scene, 'jm_bake_start', scene.frame_start))
        e = int(getattr(scene, 'jm_bake_end', scene.frame_end))
        if use_range and s > e:
            s, e = e, s
        _restore = []  # BAKE_RANGE_SENTINEL
        for obj in targets:
            for mod in iter_cloth_modifiers(obj):
                try:
                    with bpy.context.temp_override(scene=scene, active_object=obj, point_cache=mod.point_cache):
                        if use_range:
                            _restore.append((mod.point_cache, mod.point_cache.frame_start, mod.point_cache.frame_end))
                            mod.point_cache.frame_start = s
                            mod.point_cache.frame_end = e
                        bpy.ops.ptcache.bake(bake=True)
                    baked += 1
                except Exception as e:
                    self.report({'WARNING'}, f"{obj.name}:{mod.name} - {e}")
        for pc, os, oe in _restore:
            pc.frame_start, pc.frame_end = os, oe
        self.report({'INFO'}, f"Baked {baked} cloth cache(s) from {s} to {e}.")
        return {'FINISHED'}

class FreeBakeClothSelected(bpy.types.Operator):
    bl_idname = "wm.jm_free_bake_cloth_selected"
    bl_label = "Free Bake (Selected)"
    bl_description = "Clear baked caches for selected entries"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        targets = [it.object for it in scene.jm_cloth_targets if it.selected and it.object]
        if not targets:
            self.report({'WARNING'}, "No targets selected.")
            return {'CANCELLED'}

        freed = 0
        for obj in targets:
            for mod in iter_cloth_modifiers(obj):
                try:
                    with bpy.context.temp_override(scene=scene, active_object=obj, point_cache=mod.point_cache):
                        bpy.ops.ptcache.free_bake()
                        obj.modifiers["Cloth"].settings.quality=obj.modifiers["Cloth"].settings.quality
                    freed += 1
                except Exception as e:
                    self.report({'WARNING'}, f"{obj.name}:{mod.name} - {e}")
        self.report({'INFO'}, f"Freed {freed} cloth bake(s).")
        return {'FINISHED'}

class BakeClothSelectedModal(bpy.types.Operator):
    bl_idname = "wm.jm_bake_cloth_selected_modal"
    bl_label = "Bake Selected (Non-Blocking)"
    bl_description = "Plays through the frame range to fill caches while UI stays responsive."
    bl_options = {'REGISTER'}

    _timer = None
    _frame = 0
    _start = 0
    _end = 0
    _targets = None

    step: bpy.props.IntProperty(name='Step', default=1, min=1, max=10, description='Frames per tick')
    use_disk_cache: bpy.props.BoolProperty(name='Use Disk Cache', default=True, description='Enable disk cache before baking')
    free_before: bpy.props.BoolProperty(name='Free Before Bake', default=True, description='Clear existing bakes before starting')

    def _gather_targets(self, context):
        scene = context.scene
        targets = [it.object for it in scene.jm_cloth_targets if it.selected and it.object]
        pairs = []
        for obj in targets:
            for mod in obj.modifiers:
                if mod.type == 'CLOTH':
                    pairs.append((obj, mod, mod.point_cache))
        return pairs

    def invoke(self, context, event):
        pairs = self._gather_targets(context)
        if not pairs:
            self.report({'WARNING'}, "No selected cloth objects.")
            return {'CANCELLED'}

        use_range = getattr(context.scene, 'jm_bake_use_range', False)
        s = int(getattr(context.scene, 'jm_bake_start', context.scene.frame_start)) if use_range else context.scene.frame_start
        e = int(getattr(context.scene, 'jm_bake_end', context.scene.frame_end)) if use_range else context.scene.frame_end
        # NONBLOCK_RANGE_SENTINEL
        for _, _, pc in pairs:
            if pc.frame_start < s:
                s = pc.frame_start
            if pc.frame_end > e:
                e = pc.frame_end

        for obj, mod, pc in pairs:
            if use_range:
                pc.frame_start = s
                pc.frame_end = e
            if self.use_disk_cache:
                pc.use_disk_cache = True
            if self.free_before:
                try:
                    with bpy.context.temp_override(scene=context.scene, active_object=obj, point_cache=pc):
                        bpy.ops.ptcache.free_bake()
                except Exception as ex:
                    self.report({'WARNING'}, f"{obj.name}:{mod.name} free failed: {ex}")

        if s > e:
            s, e = e, s
        self._targets = pairs
        self._start = s
        self._end = e
        self._frame = s
        context.scene.frame_set(s)

        wm = context.window_manager
        self._timer = wm.event_timer_add(0.01, window=context.window)
        wm.modal_handler_add(self)
        self.report({'INFO'}, f"Non-blocking bake {s}..{e} (step {self.step})")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            return self._finish(context, cancelled=True)
        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}
        if self._frame > self._end:
            return self._finish(context)

        try:
            context.scene.frame_set(self._frame)
        except Exception as ex:
            self.report({'WARNING'}, f"Frame {self._frame}: {ex}")
            return self._finish(context, cancelled=True)

        self._frame += self.step
        return {'RUNNING_MODAL'}

    def _finish(self, context, cancelled=False):
        if self._timer:
            try:
                context.window_manager.event_timer_remove(self._timer)
            except Exception:
                pass
            self._timer = None
        if cancelled:
            self.report({'WARNING'}, "Bake cancelled.")
            return {'CANCELLED'}
        self.report({'INFO'}, f"Bake finished at frame {self._end}.")
        return {'FINISHED'}

# === Additional Cloth toggle operators ===
def _jm_selected_pairs(context):
    pairs = []
    scene = context.scene
    coll = getattr(scene, "jm_cloth_targets", None)
    if not coll:
        return pairs
    for it in coll:
        obj = getattr(it, "object", None)
        if not (getattr(it, "selected", False) and obj):
            continue
        for m in obj.modifiers:
            if m.type == 'CLOTH':
                pairs.append((obj, m))
    return pairs

def _jm_all_pairs():
    pairs = []
    for obj in bpy.data.objects:
        if obj.type != 'MESH':
            continue
        for m in obj.modifiers:
            if m.type == 'CLOTH':
                pairs.append((obj, m))
    return pairs

def _jm_toggle_pairs(pairs, enabled, op):
    if not pairs:
        op.report({'WARNING'}, "No Cloth modifiers found.")
        return {'CANCELLED'}
    changed, objs = 0, set()
    for obj, mod in pairs:
        mod.show_viewport = bool(enabled)
        mod.show_render = bool(enabled)
        objs.add(obj)
        changed += 1
    op.report({'INFO'}, f'{"Enabled" if enabled else "Disabled"} {changed} Cloth modifier(s) on {len(objs)} object(s).')
    return {'FINISHED'}

class JM_OT_EnableClothSelected(bpy.types.Operator):
    bl_idname = "wm.jm_enable_cloth_selected"
    bl_label = "Enable cloth physics on selected objects"
    bl_description = "Enable Cloth modifiers (viewport & render) on selected Cloth Bake Admin entries"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return _jm_toggle_pairs(_jm_selected_pairs(context), True, self)

class JM_OT_DisableClothSelected(bpy.types.Operator):
    bl_idname = "wm.jm_disable_cloth_selected"
    bl_label = "Disable cloth physics on selected objects"
    bl_description = "Disable Cloth modifiers (viewport & render) on selected Cloth Bake Admin entries"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return _jm_toggle_pairs(_jm_selected_pairs(context), False, self)

class JM_OT_EnableClothAll(bpy.types.Operator):
    bl_idname = "wm.jm_enable_cloth_all"
    bl_label = "Enable cloth physics on all meshes"
    bl_description = "Enable Cloth modifiers (viewport & render) on all meshes in the file"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return _jm_toggle_pairs(_jm_all_pairs(), True, self)

class JM_OT_DisableClothAll(bpy.types.Operator):
    bl_idname = "wm.jm_disable_cloth_all"
    bl_label = "Disable cloth physics on all meshes"
    bl_description = "Disable Cloth modifiers (viewport & render) on all meshes in the file"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        return _jm_toggle_pairs(_jm_all_pairs(), False, self)


class WM_OT_toggle_armature_pose(bpy.types.Operator):
    bl_idname = "wm.toggle_armature_pose"
    bl_label = "Toggle Armature Pose / Rest (Set to rest while binding)"
    bl_description = "Toggle Pose/Rest on armature(s) driving the current binding objects or the active armature"

    @classmethod
    def poll(cls, context):
        return True

    def execute(self, context):
        armatures = set()

        def add_from_obj(obj):
            if not obj:
                return
            for m in getattr(obj, "modifiers", []):
                if m.type == 'ARMATURE' and m.object and m.object.type == 'ARMATURE':
                    armatures.add(m.object)

        # 1) If the active object is an armature, include it directly
        active = context.active_object
        if active and active.type == 'ARMATURE':
            armatures.add(active)

        # 2) Armatures referenced by the panel’s binding objects
        scene = context.scene
        add_from_obj(getattr(scene, "jm_main", None))
        add_from_obj(getattr(scene, "jm_proxy", None))

        # 3) Any selected objects that have an Armature modifier
        for obj in getattr(context, "selected_objects", []) or []:
            add_from_obj(obj)

        if not armatures:
            self.report({'WARNING'}, "No armatures found (active, selected, or bound to Main/Proxy).")
            return {'CANCELLED'}

        # Decide the target state from the first found armature, then apply to all
        first = next(iter(armatures))
        current = first.data.pose_position  # 'POSE' or 'REST'
        target = 'REST' if current == 'POSE' else 'POSE'

        for arm in armatures:
            arm.data.pose_position = target

        self.report({'INFO'}, f"Set {len(armatures)} armature(s) to {target} position.")
        return {'FINISHED'}

# --- Safe auto-registration for toggle operators (so they work even if __init__.py doesn't list them) ---
def _jm_autoregister_toggle_ops():
    import bpy
    _classes = (
        JM_OT_EnableClothSelected,
        JM_OT_DisableClothSelected,
        JM_OT_EnableClothAll,
        JM_OT_DisableClothAll,
    )
    for cls in _classes:
        try:
            bpy.utils.register_class(cls)
        except Exception:
            # Already registered or Blender not ready
            pass

_jm_autoregister_toggle_ops()
