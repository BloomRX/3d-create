import bpy
from ..utils import paths

class AddBoobsBig(bpy.types.Operator):
    bl_idname = "wm.boobabig"
    bl_label = "Big"
    bl_description="Add Big boobs preset mesh"
    def execute(self, context):
        bpy.ops.import_scene.fbx(filepath=paths.mesh_path("big"))
        return {'FINISHED'}

class AddBoobsMed(bpy.types.Operator):
    bl_idname = "wm.boobamed"
    bl_label = "Middle"
    bl_description="Add Middle boobs preset mesh"
    def execute(self, context):
        bpy.ops.import_scene.fbx(filepath=paths.mesh_path("med"))
        return {'FINISHED'}

class AddBoobsSmol(bpy.types.Operator):
    bl_idname = "wm.boobasmol"
    bl_label = "Small"
    bl_description="Add Small boobs preset mesh"
    def execute(self, context):
        bpy.ops.import_scene.fbx(filepath=paths.mesh_path("small"))
        return {'FINISHED'}
