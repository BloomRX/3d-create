import bpy, os
from bpy.types import Operator
from ..utils import paths, library
from ..operators import bind
from ..utils import mesh as mu
from ..utils import library

class RefreshLibrary(Operator):
    bl_idname = "wm.refresh_library"
    bl_label = "Refresh Library"

    def execute(self, context):
        library.refresh_model_names()
        self.report({'INFO'}, f"Preset list refreshed ({len(library.model_names())} items).")
        return {'FINISHED'}

class OBJECT_OT_AddPresetObject(Operator):
    bl_idname = "object.add_preset_object"
    bl_label = "Add Preset Object"
    bl_options = {'REGISTER', 'UNDO'}

    object_name: bpy.props.StringProperty()

    def execute(self, context):
        try:
            lib_path = paths.presets_path()
            bpy.ops.wm.append(
                filepath=os.path.join(lib_path, "Object", self.object_name),
                filename=self.object_name,
                directory=os.path.join(lib_path, "Object/")
            )
            imported_obj = bpy.context.selected_objects[0]
            scene = context.scene
            scene.jm_proxy = imported_obj

#            if imported_obj:
#                imported_obj.name = "Imported_" + self.object_name
#                self.report({'INFO'}, f"Added and renamed to {imported_obj.name}")
#            else:
#                self.report({'WARNING'}, "No active object found after appending.")
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}
        return {'FINISHED'}

class AddCollision(bpy.types.Operator):
    """Convert a vertex group to a collision object"""  
    bl_idname = "object.add_collision"
    bl_label = "Convert group to collision"
    def execute(self, context):
        scene = context.scene
        mesh = scene.jm_main
        vertex_group = mesh.main_vertex_group
        obj_copy = mu.duplicate_object(mesh, f"{mesh.name}_{vertex_group}_collision")
        bind.create_proxy_from_mesh(obj_copy, vertex_group, shrink=False)
        mu.make_invisible(obj_copy)
        library.RemoveAllModifiersExceptArmature(obj_copy)
        #thickness = context.scene.collision_thickness
        active_obj = context.active_object
        active_obj.modifiers.new(name="Collision", type='COLLISION')
        active_obj.collision.thickness_outer=0.001
        active_obj.collision.thickness_inner=0.001
        return {'FINISHED'}
