import bpy
from bpy.types import Operator
from ..utils import mesh as mu
from ..utils import deform as du
from ..utils import armature_cloth as ac
from ..constants import FACE_INDICES
from ..utils import library

def _resolve_pin_group(obj):
    """Return the pin group name for an object.
    Prefers the object's custom_mesh_vertex_group. If empty, falls back to a group named 'Pin' if it exists.
    """
    try:
        name = getattr(obj, "custom_mesh_vertex_group", "") or ""
        if name:
            return name
        # Fallback: use 'Pin' if present
        if hasattr(obj, "vertex_groups") and "Pin" in obj.vertex_groups:
            return "Pin"
        return ""
    except Exception:
        return ""

def ensure_object_mode(obj):
    """
    Make `obj` the active object and switch to OBJECT mode safely,
    even if we're running from a non-3D area or with no active object.
    """
    ctx = bpy.context
    vl = ctx.view_layer

    # Make obj active & selected in this view layer
    for o in vl.objects:
        o.select_set(False)
    obj.select_set(True)
    vl.objects.active = obj

    # Try with a simple override first (works in most contexts)
    try:
        with ctx.temp_override(active_object=obj, object=obj, view_layer=vl, scene=ctx.scene):
            bpy.ops.object.mode_set(mode='OBJECT')
        return
    except RuntimeError:
        pass

    # Fallback: use a VIEW_3D area/region if available
    win = ctx.window
    if win:
        for area in win.screen.areas:
            if area.type == 'VIEW_3D':
                for region in area.regions:
                    if region.type == 'WINDOW':
                        with ctx.temp_override(
                            window=win, area=area, region=region,
                            active_object=obj, object=obj, view_layer=vl, scene=ctx.scene
                        ):
                            bpy.ops.object.mode_set(mode='OBJECT')
                        return

    # Last resort: call without override (may still fail if no UI)
    bpy.ops.object.mode_set(mode='OBJECT')



class BoobMagic(Operator):
    bl_idname = "wm.boob_magic"
    bl_label = "Apply Jiggle Physics"
    bl_description = "Bind preset proxy L/R, set up deform + cloth"

    def execute(self, context):
        scene = context.scene
        mesh = scene.jm_main
        proxy = scene.jm_proxy
        if not mesh or not proxy:
            self.report({"ERROR"}, "Please set both Main Mesh and Jiggle Mesh.")
            return {'CANCELLED'}

        # ✅ Ensure the main mesh is active *before* switching modes
        ensure_object_mode(mesh)

        result = bpy.ops.wm.bind_proxy()
        return {'CANCELLED'} if 'CANCELLED' in result else {'FINISHED'}


class BindProxy(Operator):
    bl_idname = "wm.bind_proxy"
    bl_label = "Bind Custom Proxy"
    bl_description = "Bind your custom proxy (optional mirror), surface deform and cloth"

    def execute(self, context):
        scene = context.scene
        mesh = scene.jm_main
        proxy = scene.jm_proxy

        bpy.context.scene.frame_current = 0

        if not mesh or not proxy:
            self.report({"ERROR"}, "Please set both Main Mesh and Proxy.")
            return {'CANCELLED'}

        ensure_object_mode(mesh)

        armature = None
        if scene.jm_bind_armature:
            arm_mod = mu.get_modifier_by_type(mesh, "ARMATURE")
            if not arm_mod or not arm_mod.object:
                self.report({"ERROR"}, "Main mesh needs an Armature modifier with object assigned.")
                return {'CANCELLED'}
            armature = arm_mod.object

        mu.make_invisible(proxy)
        report = mu.apply_transform(mesh, proxy)
        if report:
            self.report({'WARNING'}, report)

        if scene.jm_cleanup:
            # keep your original base logic
            base = proxy.name[:-2] if proxy.name.endswith((".L", ".R")) else proxy.name

            # only these exact modifier names should be removed
            sd_names = {
                f"{base}_Physics_Jiggle.L",
                f"{base}_Physics_Jiggle.R",
                f"{base}_Physics_Jiggle",
            }

            for m in list(mesh.modifiers):
                if m.type == 'SURFACE_DEFORM' and m.name in sd_names:
                    mesh.modifiers.remove(m)

            for suffix in ('.L', '.R', ''):
                mu.remove_vertex_group(mesh, f"{base}_Jiggle_Influence{suffix}")

            if proxy.name.endswith((".R", "_R")):
                proxy.name = proxy.name[:-2]
            #mu.remove_if_found(base + ".R")


        if scene.jm_bind_armature and armature:
            ac.apply_scale_bind_armature(proxy, mesh, armature)

        if scene.jm_mirror_mesh:
            bpy.context.object.use_mesh_mirror_x = True
            proxy2 = mu.duplicate_mirror(proxy)
        else:
            bpy.context.object.use_mesh_mirror_x = False
            proxy2 = None


        #if proxy.custom_mesh_vertex_group:
        #    mu.make_group_stiff(proxy, proxy.custom_mesh_vertex_group)

        if scene.jm_bind_armature:
            du.data_transfer(proxy, mesh)
            if proxy2:
                du.data_transfer(proxy2, mesh)

        if scene.jm_surface_deform:
            if proxy2:
                vg_left = du.add_vertex_group_by_distance(proxy, mesh, f"{proxy.name[:-2]}_Jiggle_Influence.L", scene.jm_proxy_parent_dist)
                vg_right = du.add_vertex_group_by_distance(proxy2, mesh, f"{proxy2.name[:-2]}_Jiggle_Influence.R", scene.jm_proxy_parent_dist)
                du.surface_deform(proxy, mesh, f"{proxy.name[:-2]}_Physics_Jiggle.L", vg_left.name)
                du.surface_deform(proxy2, mesh, f"{proxy2.name[:-2]}_Physics_Jiggle.R", vg_right.name)
            else:
                vg = du.add_vertex_group_by_distance(proxy, mesh, f"{proxy.name[:-2]}_Jiggle_Influence", scene.jm_proxy_parent_dist)
                du.surface_deform(proxy, mesh, f"{proxy.name[:-2]}_Physics_Jiggle", vg.name)

        pin_1 = _resolve_pin_group(proxy)
        if proxy2:
            pin_2 = _resolve_pin_group(proxy2)

        if scene.jm_add_cloth:
            ac.add_cloth_settings(proxy, pin_1, preset=getattr(bpy.context.window_manager, 'jm_cloth_preset', ''))
            if proxy2:
                ac.add_cloth_settings(proxy2, pin_2, preset=getattr(bpy.context.window_manager, 'jm_cloth_preset', ''))

        return {'FINISHED'}

class ConvertFromVertexGroup(Operator):
    bl_idname = "object.select_vertex_group"
    bl_label = "Convert Vertex Group to Jiggle"
    bl_description = "Convert a vertex group to a jiggle proxy"
    vertex_group: bpy.props.StringProperty(name="Vertex Group Name")

    def execute(self, context):
        scene = context.scene
        mesh = scene.jm_main
        if not mesh:
            self.report({'ERROR'}, "Select a Main Mesh")
            return {'CANCELLED'}

        ensure_object_mode(mesh)

        report = mu.apply_transform(mesh, mesh)
        if report:
            self.report({'WARNING'}, report)

        bpy.context.scene.frame_current = 0

        if scene.jm_cleanup and mesh.main_vertex_group:
            try:
                target_name = mesh.main_vertex_group + "_Custom_Jiggle"
                for m in list(mesh.modifiers):
                    if m.type == 'SURFACE_DEFORM' and m.name == target_name:
                        mesh.modifiers.remove(m)
                prev_proxy_name = f"{mesh.name}_{mesh.main_vertex_group}_phys"
                mu.remove_if_found(prev_proxy_name)
            except Exception as e:
                self.report({'WARNING'}, f"Cleanup skipped: {e}")

        obj_copy = mu.duplicate_object(mesh, f"{mesh.name}_{mesh.main_vertex_group}_phys")
        vertex_group = create_proxy_from_mesh(obj_copy, obj_copy.main_vertex_group, shrink=False)

        if scene.jm_surface_deform:
            du.surface_deform(obj_copy, mesh, obj_copy.main_vertex_group + "_Custom_Jiggle", mesh.main_vertex_group)

        if scene.jm_add_cloth:
            ac.add_cloth_settings(obj_copy, vertex_group.name, preset=getattr(bpy.context.window_manager, 'jm_cloth_preset', ''))

        obj_copy.data.update()
        mu.make_invisible(obj_copy)
        return {'FINISHED'}

def create_proxy_from_mesh(mesh, groupname, shrink = False):
    ensure_object_mode(mesh)
    mesh.vertex_groups.active = mesh.vertex_groups[groupname]
    bpy.ops.object.mode_set(mode='EDIT')
    bpy.ops.mesh.select_mode(type='FACE')
    bpy.ops.mesh.select_all(action='DESELECT')
    bpy.ops.object.vertex_group_select()

    vertex_group = mesh.vertex_groups.new(name=groupname + "_Pin")
    tmp_weight = bpy.context.scene.tool_settings.vertex_group_weight
    mesh.vertex_groups.active = mesh.vertex_groups[vertex_group.name]
    bpy.context.scene.tool_settings.vertex_group_weight = 0.5
    bpy.ops.object.vertex_group_assign()
    bpy.context.scene.tool_settings.vertex_group_weight = tmp_weight
    bpy.ops.mesh.select_all(action='INVERT')
    if shrink:
        bpy.ops.mesh.select_more()
    bpy.ops.mesh.delete(type='FACE')
    bpy.ops.mesh.select_mode(type='EDGE')
    bpy.ops.mesh.select_non_manifold()
    bpy.ops.mesh.edge_face_add()
    bpy.ops.mesh.poke()
    bpy.context.scene.tool_settings.vertex_group_weight = 1
    bpy.ops.object.vertex_group_assign()
    bpy.ops.mesh.select_all(action='SELECT')
    bpy.ops.mesh.vert_connect_concave()
    bpy.ops.object.mode_set(mode='OBJECT')

    library.RemoveAllModifiersExceptArmature(mesh)

    return vertex_group

