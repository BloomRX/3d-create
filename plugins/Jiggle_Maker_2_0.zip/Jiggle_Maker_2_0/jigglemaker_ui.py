# Compatibility shim for legacy imports: `import jigglemaker_ui`
from .ui.panels import *
from .ui.prefs import *
