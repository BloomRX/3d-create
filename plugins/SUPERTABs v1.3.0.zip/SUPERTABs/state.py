# -*- coding: utf-8 -*-

# This file is used to store the global state of the Addon
# To avoid circular import issues between complex modules

# Global variable to track dynamically created/modified classes
managed_panels = {}

# Flag to prevent UI updates during the import process
is_importing = False

# --- Global State for Status Bar ---
# Timer object for the status message countdown
status_timer = None

# --- Auto-Import Save State ---
# Stores the on-disk saved state of auto-import settings
saved_auto_import_enabled = None
saved_auto_import_filepath = None

# --- Poll Exception Save State ---
saved_poll_method_exceptions = None
restart_required_for_poll_exceptions = False