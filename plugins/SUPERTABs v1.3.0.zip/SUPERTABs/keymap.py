# -*- coding: utf-8 -*-

import bpy

# Store keymap items for proper registration/unregistration
addon_keymaps = []

def register():
    unregister_keymap()
    
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon
    if not kc:
        return

    package_name = __package__.split('.')[0]
    prefs = bpy.context.preferences.addons[package_name].preferences
    
    # --- Register Keymap for SUPERTABs Manager ---
    if prefs.manager_hotkey_enabled:
        prop_rna_manager = prefs.bl_rna.properties.get('hotkey_key')
        if prop_rna_manager:
            valid_keys_manager = {item.identifier for item in prop_rna_manager.enum_items}
            key_manager = str(prefs.hotkey_key)
            if key_manager in valid_keys_manager:
                km_manager = kc.keymaps.new(name='Window', space_type='EMPTY')
                kmi_manager = km_manager.keymap_items.new(
                    "st.open_supertabs_manager", key_manager, 'PRESS',
                    ctrl=prefs.hotkey_ctrl, shift=prefs.hotkey_shift, alt=prefs.hotkey_alt
                )
                addon_keymaps.append((km_manager, kmi_manager))

    # --- Register Keymap for Asset Browser ---
    if prefs.asset_browser_hotkey_enabled:
        prop_rna_asset = prefs.bl_rna.properties.get('asset_browser_hotkey_key')
        if prop_rna_asset:
            valid_keys_asset = {item.identifier for item in prop_rna_asset.enum_items}
            key_asset = str(prefs.asset_browser_hotkey_key)
            if key_asset in valid_keys_asset:
                km_asset = kc.keymaps.new(name='Window', space_type='EMPTY')
                kmi_asset = km_asset.keymap_items.new(
                    "st.toggle_asset_browser", key_asset, 'PRESS',
                    ctrl=prefs.asset_browser_hotkey_ctrl, shift=prefs.asset_browser_hotkey_shift, alt=prefs.asset_browser_hotkey_alt
                )
                addon_keymaps.append((km_asset, kmi_asset))

    # --- Register Keymap for Split/Join View ---
    if prefs.split_join_hotkey_enabled:
        prop_rna_split_join = prefs.bl_rna.properties.get('split_join_hotkey_key')
        if prop_rna_split_join:
            valid_keys_split_join = {item.identifier for item in prop_rna_split_join.enum_items}
            key_split_join = str(prefs.split_join_hotkey_key)
            if key_split_join in valid_keys_split_join:
                km_split_join = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
                kmi_split_join = km_split_join.keymap_items.new(
                    "view3d.manage_areas", key_split_join, 'PRESS',
                    ctrl=prefs.split_join_hotkey_ctrl, shift=prefs.split_join_hotkey_shift, alt=prefs.split_join_hotkey_alt
                )
                addon_keymaps.append((km_split_join, kmi_split_join))

    # --- Register Keymap for Pie Menu ---
    if prefs.pie_menu_hotkey_enabled and (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH'):
        prop_rna_pie = prefs.bl_rna.properties.get('pie_menu_hotkey_key')
        if prop_rna_pie:
            valid_keys_pie = {item.identifier for item in prop_rna_pie.enum_items}
            key_pie = str(prefs.pie_menu_hotkey_key)
            if key_pie in valid_keys_pie:
                # Keymap for 3D View
                km_pie_3d = kc.keymaps.new(name='3D View', space_type='VIEW_3D')
                kmi_pie_3d = km_pie_3d.keymap_items.new(
                    "wm.call_menu_pie", key_pie, 'PRESS',
                    ctrl=prefs.pie_menu_hotkey_ctrl, shift=prefs.pie_menu_hotkey_shift, alt=prefs.pie_menu_hotkey_alt
                )
                kmi_pie_3d.properties.name = "ST_MT_QuickPie"
                addon_keymaps.append((km_pie_3d, kmi_pie_3d))
                
                # Keymap for UV/Image Editor
                km_pie_image = kc.keymaps.new(name='Image', space_type='IMAGE_EDITOR')
                kmi_pie_image = km_pie_image.keymap_items.new(
                    "wm.call_menu_pie", key_pie, 'PRESS',
                    ctrl=prefs.pie_menu_hotkey_ctrl, shift=prefs.pie_menu_hotkey_shift, alt=prefs.pie_menu_hotkey_alt
                )
                kmi_pie_image.properties.name = "ST_MT_QuickPie"
                addon_keymaps.append((km_pie_image, kmi_pie_image))

                km_pie_node = kc.keymaps.new(name='Node Editor', space_type='NODE_EDITOR')
                kmi_pie_node = km_pie_node.keymap_items.new(
                    "wm.call_menu_pie", key_pie, 'PRESS',
                    ctrl=prefs.pie_menu_hotkey_ctrl, shift=prefs.pie_menu_hotkey_shift, alt=prefs.pie_menu_hotkey_alt
                )
                kmi_pie_node.properties.name = "ST_MT_QuickPie"
                addon_keymaps.append((km_pie_node, kmi_pie_node))
                
def unregister_keymap():
    for km, kmi in addon_keymaps:
        try:
            km.keymap_items.remove(kmi)
        except:
            pass
    addon_keymaps.clear()

def update_keymap_callback(self, context):
    register()

def unregister():
    unregister_keymap()
