import bpy

def draw_window_editors_section(layout, context):
    """
    Draws the user-selected favorite window editors
    based on the rcm_... properties.
    This layout is a simple list suitable for menus.
    """
    prefs = context.preferences.addons[__package__].preferences
    main_col = layout.column(align=True)

    # --- General ---
    if prefs.rcm_show_3Dview:
        op_3d = main_col.operator("st.open_editor_window", text="3D Viewport", icon='VIEW3D')
        op_3d.editor_type = 'VIEW_3D'
    if prefs.rcm_show_image:
        op_img = main_col.operator("st.open_editor_window", text="Image Editor", icon='IMAGE')
        op_img.editor_type = 'IMAGE_EDITOR'
    if prefs.rcm_show_uv:
        op_uv = main_col.operator("st.open_editor_window", text="UV Editor", icon='UV')
        op_uv.editor_type = 'UV'
        op_uv.mode = 'UV'
    if prefs.rcm_show_geo:
        op_geo = main_col.operator("st.open_editor_window", text="Geometry Node", icon='GEOMETRY_NODES')
        op_geo.editor_type = 'GeometryNodeTree'
        op_geo.tree_type = 'GeometryNodeTree'
    if prefs.rcm_show_comp:
        op_comp = main_col.operator("st.open_editor_window", text="Compositor", icon='NODE_COMPOSITING')
        op_comp.editor_type = 'CompositorNodeTree'
        op_comp.tree_type = 'CompositorNodeTree'
    if prefs.rcm_show_shader:
        op_shader = main_col.operator("st.open_editor_window", text="Shader Editor", icon='NODE_MATERIAL')
        op_shader.editor_type = 'ShaderNodeTree'
        op_shader.tree_type = 'ShaderNodeTree'
    if prefs.rcm_show_texture:
        op_texture = main_col.operator("st.open_editor_window", text="Texture Node Editor", icon='NODE_TEXTURE')
        op_texture.editor_type = 'TextureNodeTree'
        op_texture.tree_type = 'TextureNodeTree'
    if prefs.rcm_show_sequence:
        op_sequence = main_col.operator("st.open_editor_window", text="Viedeo Sequencer", icon='SEQUENCE')
        op_sequence.editor_type = 'SEQUENCE_EDITOR'
    if prefs.rcm_show_clip:
        op_clip = main_col.operator("st.open_editor_window", text="Movie Clip Editor", icon='TRACKER')
        op_clip.editor_type = 'CLIP_EDITOR'

    # --- Scripting ---
    if prefs.rcm_show_system_console or prefs.rcm_show_text or prefs.rcm_show_console or prefs.rcm_show_info:
        main_col.separator()
    if prefs.rcm_show_system_console:
        row_script = main_col.row(align=True)
        row_script.alert = True
        row_script.operator("wm.console_toggle", text="System Console", icon='SYSTEM')
    if prefs.rcm_show_text:
        op_text = main_col.operator("st.open_editor_window", text="Text Editor", icon='TEXT')
        op_text.editor_type = 'TEXT_EDITOR'
    if prefs.rcm_show_console:
        op_py_console = main_col.operator("st.open_editor_window", text="Python Console", icon='CONSOLE')
        op_py_console.editor_type = 'CONSOLE'
    if prefs.rcm_show_info:
        op_info = main_col.operator("st.open_editor_window", text="Info", icon='INFO')
        op_info.editor_type = 'INFO'
    if prefs.rcm_show_iconviewer:
        op_info = main_col.operator("iv.icons_show",text="Icon Viewer",icon="BLENDER")
    if prefs.rcm_show_serpen:
        op_info = main_col.operator("st.open_editor_window", text="Visual Scripting Editor (Serpen)", icon='FILE_SCRIPT')
        
    # --- Animation ---
    if prefs.rcm_show_dopesheet or prefs.rcm_show_timeline or prefs.rcm_show_graph or prefs.rcm_show_drivers or prefs.rcm_show_nla:
        main_col.separator()
    if prefs.rcm_show_dopesheet:
        op_dopesheet = main_col.operator("st.open_editor_window", text="Dope Sheet", icon='ACTION')
        op_dopesheet.editor_type = 'DOPESHEET'
    if prefs.rcm_show_timeline:
        op_timeline = main_col.operator("st.open_editor_window", text="Timeline", icon='TIME')
        op_timeline.editor_type = 'TIMELINE'
    if prefs.rcm_show_graph:
        op_graph = main_col.operator("st.open_editor_window", text="Graph Editor", icon='GRAPH')
        op_graph.editor_type = 'FCURVES'
    if prefs.rcm_show_drivers:
        op_drivers = main_col.operator("st.open_editor_window", text="Drivers", icon='DRIVER')
        op_drivers.editor_type = 'DRIVERS'
    if prefs.rcm_show_nla:
        op_nla = main_col.operator("st.open_editor_window", text="Nonlinear Animation", icon='NLA')
        op_nla.editor_type = 'NLA_EDITOR'

    # --- Data ---
    if prefs.rcm_show_outliner or prefs.rcm_show_props or prefs.rcm_show_file or prefs.rcm_show_spread or prefs.rcm_show_preferences:
        main_col.separator()
    if prefs.rcm_show_outliner:
        op_outliner = main_col.operator("st.open_editor_window", text="OutLiner", icon='OUTLINER')
        op_outliner.editor_type = 'OUTLINER'
    if prefs.rcm_show_props:
        op_props = main_col.operator("st.open_editor_window", text="Properties", icon='PROPERTIES')
        op_props.editor_type = 'PROPERTIES'
    if prefs.rcm_show_file:
        op_file = main_col.operator("st.open_editor_window", text="File Browser", icon='TRACKER')
        op_file.editor_type = 'FILES'
    if prefs.rcm_show_spread:
        op_spread = main_col.operator("st.open_editor_window", text="Spreadsheet", icon='SPREADSHEET')
        op_spread.editor_type = 'SPREADSHEET'
    if prefs.rcm_show_asset:
        op_spread = main_col.operator("st.open_editor_window", text="Asset Browser", icon='ASSET_MANAGER')
        op_spread.editor_type = 'ASSET'

def draw_window_editors_pie(layout, context):
    """
    Draws the user-selected favorite window editors
    based on the rcm_... properties.
    This layout uses a grid of boxes, similar to Quick Shortcuts.
    """
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    pie_column_count = prefs.pie_window_editor_columns
    
    main_grid = layout.grid_flow(
        columns=pie_column_count,
        even_columns=True,
        align=True
    )

    # --- Group 1: General ---
    has_general_items = (
        prefs.rcm_show_3Dview or prefs.rcm_show_image or prefs.rcm_show_uv or
        prefs.rcm_show_geo or prefs.rcm_show_comp or prefs.rcm_show_shader or
        prefs.rcm_show_texture or prefs.rcm_show_sequence or prefs.rcm_show_clip
    )

    if has_general_items:
        box_general = main_grid.box()
        box_general.label(text="General", icon='VIEW3D')
        col_general = box_general.column(align=True)

        if prefs.rcm_show_3Dview:
            op_3d = col_general.operator("st.open_editor_window", text="3D Viewport", icon='VIEW3D')
            op_3d.editor_type = 'VIEW_3D'
        if prefs.rcm_show_image:
            op_img = col_general.operator("st.open_editor_window", text="Image Editor", icon='IMAGE')
            op_img.editor_type = 'IMAGE_EDITOR'
        if prefs.rcm_show_uv:
            op_uv = col_general.operator("st.open_editor_window", text="UV Editor", icon='UV')
            op_uv.editor_type = 'UV'
            op_uv.mode = 'UV'
        if prefs.rcm_show_geo:
            op_geo = col_general.operator("st.open_editor_window", text="Geometry Node", icon='GEOMETRY_NODES')
            op_geo.editor_type = 'GeometryNodeTree'
            op_geo.tree_type = 'GeometryNodeTree'
        if prefs.rcm_show_comp:
            op_comp = col_general.operator("st.open_editor_window", text="Compositor", icon='NODE_COMPOSITING')
            op_comp.editor_type = 'CompositorNodeTree'
            op_comp.tree_type = 'CompositorNodeTree'
        if prefs.rcm_show_shader:
            op_shader = col_general.operator("st.open_editor_window", text="Shader Editor", icon='NODE_MATERIAL')
            op_shader.editor_type = 'ShaderNodeTree'
            op_shader.tree_type = 'ShaderNodeTree'
        if prefs.rcm_show_texture:
            op_texture = col_general.operator("st.open_editor_window", text="Texture Node Editor", icon='NODE_TEXTURE')
            op_texture.editor_type = 'TextureNodeTree'
            op_texture.tree_type = 'TextureNodeTree'
        if prefs.rcm_show_sequence:
            op_sequence = col_general.operator("st.open_editor_window", text="Viedeo Sequencer", icon='SEQUENCE')
            op_sequence.editor_type = 'SEQUENCE_EDITOR'
        if prefs.rcm_show_clip:
            op_clip = col_general.operator("st.open_editor_window", text="Movie Clip Editor", icon='TRACKER')
            op_clip.editor_type = 'CLIP_EDITOR'

    # --- Group 2: Scripting ---
    has_scripting_items = (
        prefs.rcm_show_system_console or prefs.rcm_show_text or
        prefs.rcm_show_console or prefs.rcm_show_info or
        prefs.rcm_show_iconviewer or prefs.rcm_show_serpen
    )

    if has_scripting_items:
        box_scripting = main_grid.box()
        box_scripting.label(text="Scripting", icon='FILE_SCRIPT')
        col_scripting = box_scripting.column(align=True)

        if prefs.rcm_show_system_console:
            row_script = col_scripting.row(align=True)
            row_script.alert = True
            row_script.operator("wm.console_toggle", text="System Console", icon='SYSTEM')
        if prefs.rcm_show_text:
            op_text = col_scripting.operator("st.open_editor_window", text="Text Editor", icon='TEXT')
            op_text.editor_type = 'TEXT_EDITOR'
        if prefs.rcm_show_console:
            op_py_console = col_scripting.operator("st.open_editor_window", text="Python Console", icon='CONSOLE')
            op_py_console.editor_type = 'CONSOLE'
        if prefs.rcm_show_info:
            op_info = col_scripting.operator("st.open_editor_window", text="Info", icon='INFO')
            op_info.editor_type = 'INFO'
        if prefs.rcm_show_iconviewer:
            op_info = col_scripting.operator("iv.icons_show",text="Icon Viewer",icon="BLENDER")
        if prefs.rcm_show_serpen:
            op_info = col_scripting.operator("st.open_editor_window", text="Visual Scripting Editor (Serpen)", icon='FILE_SCRIPT')

    # --- Group 3: Animation ---
    has_animation_items = (
        prefs.rcm_show_dopesheet or prefs.rcm_show_timeline or
        prefs.rcm_show_graph or prefs.rcm_show_drivers or prefs.rcm_show_nla
    )

    if has_animation_items:
        box_animation = main_grid.box()
        box_animation.label(text="Animation", icon='ACTION')
        col_animation = box_animation.column(align=True)

        if prefs.rcm_show_dopesheet:
            op_dopesheet = col_animation.operator("st.open_editor_window", text="Dope Sheet", icon='ACTION')
            op_dopesheet.editor_type = 'DOPESHEET'
        if prefs.rcm_show_timeline:
            op_timeline = col_animation.operator("st.open_editor_window", text="Timeline", icon='TIME')
            op_timeline.editor_type = 'TIMELINE'
        if prefs.rcm_show_graph:
            op_graph = col_animation.operator("st.open_editor_window", text="Graph Editor", icon='GRAPH')
            op_graph.editor_type = 'FCURVES'
        if prefs.rcm_show_drivers:
            op_drivers = col_animation.operator("st.open_editor_window", text="Drivers", icon='DRIVER')
            op_drivers.editor_type = 'DRIVERS'
        if prefs.rcm_show_nla:
            op_nla = col_animation.operator("st.open_editor_window", text="Nonlinear Animation", icon='NLA')
            op_nla.editor_type = 'NLA_EDITOR'

    # --- Group 4: Data ---
    has_data_items = (
        prefs.rcm_show_outliner or prefs.rcm_show_props or
        prefs.rcm_show_file or prefs.rcm_show_spread or prefs.rcm_show_asset
    )
    
    if has_data_items:
        box_data = main_grid.box()
        box_data.label(text="Data", icon='OUTLINER')
        col_data = box_data.column(align=True)

        if prefs.rcm_show_outliner:
            op_outliner = col_data.operator("st.open_editor_window", text="OutLiner", icon='OUTLINER')
            op_outliner.editor_type = 'OUTLINER'
        if prefs.rcm_show_props:
            op_props = col_data.operator("st.open_editor_window", text="Properties", icon='PROPERTIES')
            op_props.editor_type = 'PROPERTIES'
        if prefs.rcm_show_file:
            op_file = col_data.operator("st.open_editor_window", text="File Browser", icon='TRACKER')
            op_file.editor_type = 'FILES'
        if prefs.rcm_show_spread:
            op_spread = col_data.operator("st.open_editor_window", text="Spreadsheet", icon='SPREADSHEET')
            op_spread.editor_type = 'SPREADSHEET'
        if prefs.rcm_show_asset:
            op_spread = col_data.operator("st.open_editor_window", text="Asset Browser", icon='ASSET_MANAGER')
            op_spread.editor_type = 'ASSET'

def is_item_visible_in_node_editor(context, item_identifier):
    if context.space_data.type != 'NODE_EDITOR':
        return True

    from . import core
    get_target_panels = getattr(core, 'get_target_panels_for_item', None)
    
    if not get_target_panels:
        return True 

    try:
        item_type, item_name = item_identifier.split(':', 1)
        if item_type == 'tab':
            standard_tabs = {'Item', 'Tool', 'View', 'Node', 'Group', 'Options'}
            
            if item_name in {'Node', 'Options', 'View', 'Group'}:
                if not getattr(context.space_data, 'node_tree', None):
                    return False
            
            if item_name in standard_tabs:
                current_tree_type = getattr(context.space_data, 'tree_type', '')
                restricted_node_tabs = set()
                
                if current_tree_type == 'GeometryNodeTree': 
                    restricted_node_tabs = {'Node', 'Options'} 
                elif current_tree_type == 'ShaderNodeTree': 
                    restricted_node_tabs = {'Group'}
                elif current_tree_type == 'CompositorNodeTree': 
                    restricted_node_tabs = {'Group', 'Node', 'Options'}
                elif current_tree_type == 'TextureNodeTree': 
                    restricted_node_tabs = {'Group', 'Node', 'Options', 'View'}

                if item_name in restricted_node_tabs:
                    return False
                
                return True 
    except ValueError:
        pass

    # --- 2. Addon/Custom Panels Logic ---
    target_panels = get_target_panels(context, item_identifier, 'NODE_EDITOR')
    
    if not target_panels:
        return True 

    for p in target_panels:
        poll_passed = True
        try:
            if hasattr(p, 'st_original_poll') and p.st_original_poll:
                if not p.st_original_poll(context): poll_passed = False
            elif hasattr(p, 'poll'):
                if getattr(p.poll, '__name__', '') not in ('new_poll_method', 'new_blenderkit_poll_method'):
                    if not p.poll(context): poll_passed = False
        except: 
            pass 
        
        if poll_passed:
            return True 

    return False

def draw_quick_shortcuts_section(layout, context):
    """
    Draws the user-defined Quick Shortcuts (pinned items),
    grouped by their Main/Sub group, as a simple list.
    """
    prefs = context.preferences.addons[__package__].preferences
    wm = context.window_manager

    if not prefs.quick_shortcuts:
        layout.label(text="No Quick Shortcuts added.", icon='INFO')
        layout.label(text="Add them via Preferences > Tab Group Management.")
        return

    main_col = layout.column(align=True)
    current_group_label = None 
    current_space = context.area.type

    if current_space == 'VIEW_3D':
        target_space = 'VIEW_3D'
    elif current_space == 'IMAGE_EDITOR':
        target_space = 'IMAGE_EDITOR'
    elif current_space == 'NODE_EDITOR':
        target_space = 'NODE_EDITOR'
    else:
        target_space = 'VIEW_3D'

    main_col = layout.column(align=True)
    current_group_label = None 
    
    found_any = False

    for item in prefs.quick_shortcuts:
        if item.space_type != target_space:
            continue

        if target_space == 'NODE_EDITOR':
            if not is_item_visible_in_node_editor(context, item.identifier):
                continue

        found_any = True

        real_main, real_sub = get_real_item_location(prefs, item.identifier, target_space)
        display_main = real_main if real_main else item.main_group_name
        display_sub = real_sub if real_main else item.sub_group_name

        group_label = display_main
        if display_sub:
            group_label += f" / {display_sub}"

        if group_label != current_group_label:
            current_group_label = group_label
            if main_col.column(align=True) != layout.column(align=True):
                main_col.separator(factor=0.5) 
            main_col.label(text=group_label, icon='EVENT_S')

        state = None
        if hasattr(wm, "tab_group_states"):
            state = wm.tab_group_states.get(item.main_group_name)
        is_active = False
        is_pinned = False
        
        if state:
            is_active = (state.active_item == item.identifier)
            pinned_set = {p.strip() for p in state.pinned_items.split(',') if p.strip()}
            is_pinned = (item.identifier in pinned_set)
            
        show_as_depressed = is_active or is_pinned
        icon_to_show = 'PINNED' if show_as_depressed else 'UNPINNED'
        op = main_col.operator( 
            "st.activate_quick_shortcut", 
            text=item.display_name, 
            icon=icon_to_show,
            depress=show_as_depressed
        )
        op.item_identifier = item.identifier
        op.main_group_name = display_main

    if not found_any:
        layout.label(text=f"No Shortcuts for {target_space}", icon='INFO')

def draw_panel_presets_section(layout, context):
    """
    Draws the content formerly in ST_MT_FavoritePresetsRCM.
    This can be called by a Menu or a Pie Box.
    """
    try:
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        wm = context.window_manager

        current_space = context.area.type 
        if current_space == 'IMAGE_EDITOR': target_space = 'IMAGE_EDITOR'
        elif current_space == 'NODE_EDITOR': target_space = 'NODE_EDITOR'
        else: target_space = 'VIEW_3D'

        active_main_group_name = wm.st_last_active_main_group 
        active_group_state = wm.tab_group_states.get(active_main_group_name)

        current_pinned_set = set()
        if active_group_state:
            current_pinned_set = {item.strip() for item in active_group_state.pinned_items.split(',') if item.strip()}
        
        if not prefs.custom_favorite_presets:
            layout.label(text="No Presets Created", icon='INFO')
            return
        
        col = layout.column(align=True)

        for preset in prefs.custom_favorite_presets:
            if preset.space_type != target_space:
                continue
            
            found_any = True
            preset_owner_group_name = preset.main_group_name
            
            group_name_to_use = ""
            display_text = ""
            
            if preset_owner_group_name:
                group_name_to_use = preset_owner_group_name
                display_text = f"{preset.name} ({group_name_to_use})"
            else:
                if not active_main_group_name:
                    continue 
                group_name_to_use = active_main_group_name
                display_text = f"{preset.name} (Global)"
            is_active_group = (group_name_to_use == active_main_group_name)

            preset_items = {item.strip() for item in preset.items.split(',') if item.strip()}
            is_depressed = False
            if is_active_group and preset_items:
                is_depressed = preset_items.issubset(current_pinned_set)
            icon_to_show = 'FAKE_USER_ON' if is_depressed else preset.icon
            op = col.operator(
                "st.set_exclusive_favorite_preset", 
                text=display_text, 
                icon=icon_to_show, 
                depress=is_depressed
            )
            op.group_name = group_name_to_use 
            op.preset_name = preset.name
        if not found_any:
            layout.label(text="No Presets for this Space", icon='INFO')
    except Exception as e:
        # print(f"SUPERTABs RCM Error: {e}")
        layout.label(text="Error loading presets", icon='ERROR')

def draw_uv_tools_section(layout, context):
    """
    Draws the content formerly in UV_MT_ruv_submenu.
    This can be called by a Menu or a Pie Box.
    """
    space = context.space_data

    icon = "RADIOBUT_ON" if context.scene.tool_settings.use_uv_select_sync else "RADIOBUT_OFF"
    layout.operator(UV_OT_toggle_uv_sync.bl_idname, text="UV Sync", icon=icon)
    icon = "RADIOBUT_ON" if context.space_data.uv_editor.show_stretch else "RADIOBUT_OFF"
    layout.operator(UV_OT_toggle_stretch.bl_idname, text="UV Stretch Overlay", icon=icon)
    icon = "RADIOBUT_ON" if space.uv_editor.use_live_unwrap else "RADIOBUT_OFF"
    layout.operator(UV_OT_toggle_live_unwrap.bl_idname, text="Live Unwrap", icon=icon)    

    layout.separator()

    layout.operator("uv.average_islands_scale", text="Average Island Scale", icon='AUTOMERGE_ON')
    layout.operator("uv.pack_islands", text="Pack Islands", icon='PACKAGE')
    layout.operator("uv.select_overlap", text="Select Overlap UV", icon='RESTRICT_SELECT_OFF')
    layout.operator("uv.reset", text="Reset UV Projection", icon='FILE_REFRESH')
    layout.operator("uv.export_layout", text="Export UV Layout", icon='EXPORT')

def draw_panel_presets_pie(layout, context):
    """
    Draws the Panel Presets grouped by their Main Group
    in a grid layout for the Pie Menu.
    """
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    wm = context.window_manager
    pie_column_count = prefs.pie_panel_preset_columns 

    if not prefs.custom_favorite_presets:
        layout.label(text="No Presets Created", icon='INFO')
        return
    
    current_space = context.area.type 
    if current_space == 'IMAGE_EDITOR': target_space = 'IMAGE_EDITOR'
    elif current_space == 'NODE_EDITOR': target_space = 'NODE_EDITOR'
    else: target_space = 'VIEW_3D'

    active_main_group_name = wm.st_last_active_main_group 
    active_group_state = wm.tab_group_states.get(active_main_group_name)
    current_pinned_set = set()
    if active_group_state:
        current_pinned_set = {item.strip() for item in active_group_state.pinned_items.split(',') if item.strip()}

    main_grid = layout.grid_flow(
        columns=pie_column_count,
        even_columns=True,
        align=True
    )
    
    current_group_label = None 
    current_item_column = None

    sorted_presets = sorted(prefs.custom_favorite_presets, key=lambda p: p.main_group_name if p.main_group_name else "")

    found_any = False
    for preset in sorted_presets:

        if preset.space_type != target_space:
            continue
        found_any = True

        group_label = preset.main_group_name
        if not group_label:
            group_label = "Global (No Group)"

        if group_label != current_group_label:
            current_group_label = group_label
            group_box = main_grid.box() 
            group_box.label(text=group_label, icon='BOOKMARKS')
            current_item_column = group_box.column(align=True) 
        
        if current_item_column is None: # Fallback
             group_box = main_grid.box()
             current_item_column = group_box.column(align=True)

        group_name_to_use = preset.main_group_name
        if not group_name_to_use:
            if not active_main_group_name:
                continue 
            group_name_to_use = active_main_group_name
        
        is_active_group = (group_name_to_use == active_main_group_name)

        preset_items = {item.strip() for item in preset.items.split(',') if item.strip()}
        is_depressed = False
        if is_active_group and preset_items:
            is_depressed = preset_items.issubset(current_pinned_set)
        
        icon_to_show = 'FAKE_USER_ON' if is_depressed else preset.icon
        
        op = current_item_column.operator(
            "st.set_exclusive_favorite_preset", 
            text=preset.name,
            icon=icon_to_show, 
            depress=is_depressed
        )
        op.group_name = group_name_to_use 
        op.preset_name = preset.name
    if not found_any:
        layout.label(text="No Presets", icon='INFO')
        
def draw_quick_shortcuts_pie(layout, context):
    """
    Draws the user-defined Quick Shortcuts (pinned items)
    with the *Group Boxes* arranged in a grid.
    """
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    wm = context.window_manager
    pie_column_count = prefs.pie_quick_shortcut_columns 

    if not prefs.quick_shortcuts:
        layout.label(text="No Quick Shortcuts added.", icon='INFO')
        return
    
    current_space = context.area.type 
    if current_space == 'IMAGE_EDITOR': target_space = 'IMAGE_EDITOR'
    elif current_space == 'NODE_EDITOR': target_space = 'NODE_EDITOR'
    else: target_space = 'VIEW_3D'

    main_grid = layout.grid_flow(
        columns=pie_column_count,
        even_columns=True,
        align=True
    )
    
    current_group_label = None 
    current_item_column = None
    found_any = False

    for item in prefs.quick_shortcuts:
        if item.space_type != target_space:
            continue
        
        if target_space == 'NODE_EDITOR':
            if not is_item_visible_in_node_editor(context, item.identifier):
                continue

        found_any = True

        real_main, real_sub = get_real_item_location(prefs, item.identifier, target_space)
        display_main = real_main if real_main else item.main_group_name
        display_sub = real_sub if real_main else item.sub_group_name

        group_label = display_main
        if display_sub:
            group_label += f" / {display_sub}"

        if group_label != current_group_label:
            current_group_label = group_label
            group_box = main_grid.box() 
            group_box.label(text=group_label, icon='EVENT_S') 
            current_item_column = group_box.column(align=True) 
        state = None
        if hasattr(wm, "tab_group_states"):
            state = wm.tab_group_states.get(item.main_group_name)

        is_active = False
        is_pinned = False
        
        if state:
            is_active = (state.active_item == item.identifier)
            pinned_set = {p.strip() for p in state.pinned_items.split(',') if p.strip()}
            is_pinned = (item.identifier in pinned_set)
            
        show_as_depressed = is_active or is_pinned
        icon_to_show = 'PINNED' if show_as_depressed else 'UNPINNED'
        
        if current_item_column is None:
             group_box = main_grid.box()
             current_item_column = group_box.column(align=True)

        op = current_item_column.operator( 
            "st.activate_quick_shortcut", 
            text=item.display_name, 
            icon=icon_to_show,
            depress=show_as_depressed
        )
        op.item_identifier = item.identifier
        op.main_group_name = display_main

    if not found_any:
        layout.label(text=f"No Shortcuts for {target_space}", icon='INFO')
# --- Main Menu Function ---

def menu_func(self, context):
    layout = self.layout
    layout.operator("st.call_quick_use_popover", text="SUPERTABs Quick Menu", icon='EVENT_S')

def panel_presets_menu_func(self, context):
    layout = self.layout
    layout.menu("ST_MT_FavoritePresetsRCM", icon='SOLO_ON')

def uv_rightclick_menu(self, context):
    # prefs = context.preferences.addons[__package__].preferences
    # if prefs.show_uv_tools_menu:
    self.layout.menu(UV_MT_ruv_submenu.bl_idname, icon='EVENT_S')

def separator_func(self, context):
    """Custom function to draw a separator in a menu."""
    self.layout.separator()

def window_editors_menu_func(self, context):
    prefs = context.preferences.addons[__package__].preferences
    if prefs.enable_window_editors_rcm:
        layout = self.layout
        layout.menu("ST_MT_WindowEditorsRCM", icon='WINDOW')

def quick_shortcuts_menu_func(self, context):
    prefs = context.preferences.addons[__package__].preferences
    if prefs.enable_quick_shortcuts_rcm:
        layout = self.layout
        layout.menu("ST_MT_QuickShortcutsRCM", icon='PINNED')

def node_add_fav_menu_func(self, context):
    """Draws the Add to Favorites button in Node Editor"""
    
    node = getattr(context, "active_node", None)
    
    if not node or not node.select:
        return
    layout = self.layout
    layout.separator()
    layout.operator("st.add_node_to_favorites", text="SUPERTABs Add Fav-Node", icon='BOOKMARKS')

def toggle_show_stats(self, context):
    space_data = context.space_data
    if hasattr(space_data, "overlay"):
        space_data.overlay.show_stats = not space_data.overlay.show_stats

def get_real_item_location(prefs, item_identifier, target_space='VIEW_3D'):
    for group in prefs.tab_groups:
        if group.space_type != target_space:
            continue
            
        item_list = [x.strip() for x in group.items.split(',') if x.strip()]
        if item_identifier in item_list:
            parts = group.name.split(" / ", 1)
            main_name = parts[0].strip()
            sub_name = parts[1].strip() if len(parts) > 1 else ""
            return main_name, sub_name

    for group in prefs.tab_groups:
        item_list = [x.strip() for x in group.items.split(',') if x.strip()]
        if item_identifier in item_list:
            parts = group.name.split(" / ", 1)
            main_name = parts[0].strip()
            sub_name = parts[1].strip() if len(parts) > 1 else ""
            return main_name, sub_name
            
    return None, None
class ST_OT_CallQuickUsePopover(bpy.types.Operator):
    """Intermediary operator to call the Quick Use popover from a standard menu."""
    bl_idname = "st.call_quick_use_popover"
    bl_label = "Quick Use Section"
    bl_options = {'INTERNAL'}

    def execute(self, context):
        bpy.ops.st.quick_use_popover('INVOKE_DEFAULT')
        return {'FINISHED'}

class VIEW3D_ST_toggle_show_stats(bpy.types.Operator):
    bl_idname = "view3d.toggle_show_stats"
    bl_label = "Statistic"
    bl_description = "Toggle display of statistics in the 3D Viewport"

    def execute(self, context):
        toggle_show_stats(self, context)
        return {'FINISHED'}

class VIEW_ST_toggle_wireframe_overlay(bpy.types.Operator):
    """Toggle the Viewport Overlay Wireframe"""
    bl_idname = "view.toggle_wireframe_overlay"
    bl_label = "Wireframe"
    
    def execute(self, context):
        context.space_data.overlay.show_wireframes = not context.space_data.overlay.show_wireframes
        return {'FINISHED'}

class VIEW_ST_toggle_cavity(bpy.types.Operator):
    """Toggle the Cavity overlay"""
    bl_idname = "view.toggle_cavity"
    bl_label = "Cavity"
    
    def execute(self, context):
        context.space_data.shading.show_cavity = not context.space_data.shading.show_cavity
        return {'FINISHED'}

class VIEW_ST_toggle_face_orientation(bpy.types.Operator):
    """Toggle the Face Orientation overlay"""
    bl_idname = "view.toggle_face_orientation"
    bl_label = "FaceOrientation"
    
    def execute(self, context):
        context.space_data.overlay.show_face_orientation = not context.space_data.overlay.show_face_orientation
        return {'FINISHED'}
    
class VIEW_ST_toggle_lock_camera(bpy.types.Operator):
    """Toggle the Lock Camera"""
    bl_idname = "view.toggle_lock_camera"
    bl_label = "Lock Camera"
    
    def execute(self, context):
        context.space_data.lock_camera = not context.space_data.lock_camera
        return {'FINISHED'}
    
class VIEW_ST_toggle_all_obj_names(bpy.types.Operator):
    """Toggle Show Object Names(All)"""
    bl_idname = "view.toggle_obj_names"
    bl_label = "Object Names(All)"
    
    def execute(self, context):
        prefs = context.preferences.addons[__package__].preferences
        prefs.show_object_names_all = not prefs.show_object_names_all
        return {'FINISHED'}
    
class VIEW3D_ST_purgedata_submenu(bpy.types.Menu):
    bl_label = "Wireframe"
    bl_idname = "VIEW3D_ST_purgedata_submenu"

    def draw(self, context):

        layout = self.layout
        
        op_simple = layout.operator("outliner.orphans_purge", text="Purge All (Simple)", icon='ORPHAN_DATA')
        if op_simple:
            op_simple.do_recursive = False

        op_recursive = layout.operator("outliner.orphans_purge", text="Purge All (Recursive)", icon='FILE_REFRESH')
        if op_recursive:
            op_recursive.do_recursive = True

# =========================
# UV Editor Tools
# =========================
class UV_OT_toggle_stretch(bpy.types.Operator):
    bl_idname = "uv.toggle_stretch"
    bl_label = "Toggle UV Stretch"
    bl_description = "Toggle UV Stretch display"
    def execute(self, context):
        space = context.space_data
        if hasattr(space, "uv_editor"):
            space.uv_editor.show_stretch = not space.uv_editor.show_stretch
            return {'FINISHED'}
        self.report({'WARNING'}, "Not in UV Editor"); return {'CANCELLED'}

class UV_OT_toggle_live_unwrap(bpy.types.Operator):
    bl_idname = "uv.toggle_live_unwrap"
    bl_label = "Toggle UV live_unwrap"
    bl_description = "Toggle UV live_unwrap display"
    def execute(self, context):
        space = context.space_data
        if hasattr(space, "uv_editor"):
            space.uv_editor.use_live_unwrap = not space.uv_editor.use_live_unwrap
            return {'FINISHED'}
        self.report({'WARNING'}, "Not in UV Editor"); return {'CANCELLED'}
    
class UV_OT_toggle_uv_sync(bpy.types.Operator):
    bl_idname = "uv.toggle_uv_sync"
    bl_label = "Toggle UV Sync"
    bl_description = "Toggle UV Sync"
    def execute(self, context):
        space = context.space_data
        settings = context.scene.tool_settings
        if hasattr(space, "uv_editor"):
            settings.use_uv_select_sync = not settings.use_uv_select_sync
            return {'FINISHED'}
        self.report({'WARNING'}, "Not in UV Editor"); return {'CANCELLED'}

class UV_MT_ruv_submenu(bpy.types.Menu):
    bl_idname = "UV_ST_ruv_submenu"
    bl_label = "[SUPERTABs]UV"
    def draw(self, context):
        draw_uv_tools_section(self.layout, context)

class ST_MT_FavoritePresetsRCM(bpy.types.Menu):
    bl_label = "SUPERTABs Tabs Presets"
    bl_idname = "ST_MT_FavoritePresetsRCM"

    @classmethod
    def poll(cls, context):
        wm = context.window_manager
        return (
            hasattr(wm, "tab_group_states") and
            hasattr(wm, "st_last_active_main_group") and
            wm.st_last_active_main_group != ""
        )

    def draw(self, context):
        draw_panel_presets_section(self.layout, context)
class ST_MT_QuickPie(bpy.types.Menu):
    bl_label = "SUPERTABs Quick Pie"
    bl_idname = "ST_MT_QuickPie"

    def draw(self, context):
        layout = self.layout
        pie = layout.menu_pie()
        prefs = context.preferences.addons[__package__].preferences

        
        if context.area.type == 'VIEW_3D':

            viewport_Pie_1 = pie.box()

            # ---- ViewPie-Left ----
            if prefs.enable_window_editors_pie:
                header_col = viewport_Pie_1.column(align=True)
                header_row = header_col.row(align=True)
                header_row.label(text="Window Editors", icon='WINDOW')
                scaled_row = header_row.row(align=True)
                header_row.scale_x = 0.3
                header_row.prop(prefs, "pie_window_editor_columns", text="Columns")
                draw_window_editors_pie(viewport_Pie_1, context)
            scaled_row = viewport_Pie_1.row(align=True)
            scaled_row.scale_y = 1.5
            scaled_row.operator("st.quick_use_popover", text="Quick Menu", icon='EVENT_S')

            # ---- ViewPie-Right ----
            viewport_Pie_3 = pie.box()
            header_col = viewport_Pie_3.column(align=True)
            header_row = header_col.row(align=True)
            header_row.label(text="Tabs Presets", icon='SOLO_ON')
            header_row.scale_x = 0.3
            header_row.prop(prefs, "pie_panel_preset_columns", text="Columns")
            draw_panel_presets_pie(viewport_Pie_3, context)
            if prefs.enable_quick_shortcuts_pie:
                header_col = viewport_Pie_3.column(align=True)
                header_row = header_col.row(align=True)
                header_row.label(text="Quick Shortcuts", icon='PINNED')
                header_row.scale_x = 0.3
                header_row.prop(prefs,"pie_quick_shortcut_columns",text="Columns")
                draw_quick_shortcuts_pie(viewport_Pie_3, context)

            # ---- ViewPie-Top ----
            pie.separator()
            viewport_Pie_5 = pie.menu_pie(); viewport_Pie_5.separator()
            viewport_Pie_6 = pie.menu_pie(); viewport_Pie_6.separator()
            viewport_Pie_7 = pie.menu_pie(); viewport_Pie_7.separator()
            viewport_Pie_8 = pie.menu_pie(); viewport_Pie_8.separator()
        elif context.area.type == 'IMAGE_EDITOR':
            uv_pie_1 = pie.box()
            if prefs.enable_window_editors_pie:
                header_col = uv_pie_1.column(align=True)
                header_row = header_col.row(align=True)
                header_row.label(text="Window Editors", icon='WINDOW')
                
                col_row = header_row.row(align=True)
                col_row.scale_x = 0.3
                col_row.prop(prefs, "pie_window_editor_columns", text="Columns")

                draw_window_editors_pie(uv_pie_1, context)

            scaled_row = uv_pie_1.row(align=True)
            scaled_row.scale_y = 1.5
            scaled_row.operator("st.quick_use_popover", text="Quick Menu", icon='EVENT_S')
            uv_pie_2 = pie.box()
            
            # Panel Presets
            header_col = uv_pie_2.column(align=True)
            header_row = header_col.row(align=True)
            header_row.label(text="Tabs Presets", icon='SOLO_ON')
            header_row.scale_x = 0.3
            header_row.prop(prefs, "pie_panel_preset_columns", text="Columns")
            draw_panel_presets_pie(uv_pie_2, context)
            
            # Quick Shortcuts
            if prefs.enable_quick_shortcuts_pie:
                header_col = uv_pie_2.column(align=True)
                header_row = header_col.row(align=True)
                header_row.label(text="Quick Shortcuts", icon='PINNED')
                header_row.scale_x = 0.3
                header_row.prop(prefs, "pie_quick_shortcut_columns", text="Columns")
                draw_quick_shortcuts_pie(uv_pie_2, context)

        elif context.area.type == 'NODE_EDITOR':
            # --- Slot 1 (West) ---
            node_pie_1 = pie.box()
            if prefs.enable_window_editors_pie:
                header = node_pie_1.row(align=True)
                header.label(text="Window Editors", icon='WINDOW')
                header.scale_x = 0.3
                header.prop(prefs, "pie_window_editor_columns", text="Cols")
                draw_window_editors_pie(node_pie_1, context)

            # --- Quick Menu Button ---
            row = node_pie_1.row(align=True)
            row.scale_y = 1.5 
            row.operator("st.call_quick_use_popover", text="Quick Menu", icon='EVENT_S')
            
            # --- Slot 2 (East) ---
            node_pie_2 = pie.box()
            # Panel Presets
            header = node_pie_2.row(align=True)
            header.label(text="Tabs Presets", icon='SOLO_ON')
            header.scale_x = 0.3
            header.prop(prefs, "pie_panel_preset_columns", text="Cols")
            draw_panel_presets_pie(node_pie_2, context)
            
            # Quick Shortcuts
            if prefs.enable_quick_shortcuts_pie:
                header = node_pie_2.row(align=True)
                header.label(text="Quick Shortcuts", icon='PINNED')
                header.scale_x = 0.3
                header.prop(prefs, "pie_quick_shortcut_columns", text="Cols")
                draw_quick_shortcuts_pie(node_pie_2, context)

            # Filler Slots
            pie.separator()
            pie.separator()
            pie.separator()
            pie.separator()
            pie.separator()
        
        else:
            pie.label(text="No SUPERTABs menu for this editor")
class ST_MT_WindowEditorsRCM(bpy.types.Menu):
    bl_label = "SUPERTABs Window Editors"
    bl_idname = "ST_MT_WindowEditorsRCM"

    @classmethod
    def poll(cls, context):
        prefs = context.preferences.addons[__package__].preferences
        return prefs.enable_window_editors_rcm

    def draw(self, context):
        draw_window_editors_section(self.layout, context)
class ST_MT_QuickShortcutsRCM(bpy.types.Menu):
    bl_label = "SUPERTABs Quick Shortcuts"
    bl_idname = "ST_MT_QuickShortcutsRCM"

    @classmethod
    def poll(cls, context):
        prefs = context.preferences.addons[__package__].preferences
        return prefs.enable_quick_shortcuts_rcm

    def draw(self, context):
        draw_quick_shortcuts_section(self.layout, context)
# =========================
# REGISTRATION FUNCTIONS
# =========================
_menu_types_3d = [
    bpy.types.VIEW3D_MT_object_context_menu,
    bpy.types.VIEW3D_MT_edit_mesh_context_menu,
    bpy.types.VIEW3D_MT_edit_curve_context_menu
]
_menu_type_uv = bpy.types.IMAGE_MT_uvs_context_menu
_menu_type_node = bpy.types.NODE_MT_context_menu

def register_context_menus(prefs):
    """Adds the standard context menu items based on preferences."""
    unregister_context_menus() 
    if prefs.right_click_mode == 'NONE':
        return
    
    position_func_name = 'prepend' if prefs.right_click_menu_position == 'TOP' else 'append'
    if prefs.right_click_mode in {'MENU', 'BOTH'}:
        for menu in _menu_types_3d:
            getattr(menu, position_func_name)(separator_func)
            getattr(menu, position_func_name)(window_editors_menu_func)
            getattr(menu, position_func_name)(quick_shortcuts_menu_func)
            getattr(menu, position_func_name)(panel_presets_menu_func)
            getattr(menu, position_func_name)(menu_func)
            getattr(menu, position_func_name)(separator_func)
            
    if prefs.right_click_mode in {'MENU', 'BOTH'}:
        getattr(_menu_type_uv, position_func_name)(separator_func)
        getattr(_menu_type_uv, position_func_name)(window_editors_menu_func)
        getattr(_menu_type_uv, position_func_name)(quick_shortcuts_menu_func)
        getattr(_menu_type_uv, position_func_name)(panel_presets_menu_func)
        getattr(_menu_type_uv, position_func_name)(uv_rightclick_menu)
        getattr(_menu_type_uv, position_func_name)(separator_func)
    
    if prefs.right_click_mode in {'MENU', 'BOTH'}:
        getattr(_menu_type_node, position_func_name)(separator_func)
        getattr(_menu_type_node, position_func_name)(window_editors_menu_func)
        getattr(_menu_type_node, position_func_name)(quick_shortcuts_menu_func)
        getattr(_menu_type_node, position_func_name)(panel_presets_menu_func)
        getattr(_menu_type_node, position_func_name)(node_add_fav_menu_func)
        getattr(_menu_type_node, position_func_name)(menu_func)
        getattr(_menu_type_node, position_func_name)(separator_func)

def unregister_context_menus():
    """Removes all standard context menu items."""
    for menu in _menu_types_3d:
        try:
            menu.remove(menu_func)
            menu.remove(panel_presets_menu_func)
            menu.remove(window_editors_menu_func)
            menu.remove(quick_shortcuts_menu_func)
            menu.remove(separator_func)
            menu.remove(separator_func) 
        except Exception:
            pass
    
    try:
        _menu_type_uv.remove(menu_func)
        _menu_type_uv.remove(panel_presets_menu_func)
        _menu_type_uv.remove(window_editors_menu_func)
        _menu_type_uv.remove(quick_shortcuts_menu_func)
        _menu_type_uv.remove(separator_func)
        _menu_type_uv.remove(separator_func)
        _menu_type_uv.remove(uv_rightclick_menu)
    except Exception:
        pass
    try:
        _menu_type_node.remove(menu_func)
        _menu_type_node.remove(panel_presets_menu_func)
        _menu_type_node.remove(window_editors_menu_func)
        _menu_type_node.remove(quick_shortcuts_menu_func)
        _menu_type_node.remove(node_add_fav_menu_func)
        _menu_type_node.remove(separator_func)
        _menu_type_node.remove(separator_func)
    except Exception: pass
classes = [
    ST_OT_CallQuickUsePopover,
    ST_MT_FavoritePresetsRCM,
    ST_MT_WindowEditorsRCM,
    ST_MT_QuickShortcutsRCM,
    VIEW_ST_toggle_all_obj_names,
    VIEW_ST_toggle_lock_camera,
    VIEW3D_ST_toggle_show_stats,
    VIEW_ST_toggle_wireframe_overlay,
    VIEW_ST_toggle_cavity,
    VIEW_ST_toggle_face_orientation,
    VIEW3D_ST_purgedata_submenu,
    UV_OT_toggle_stretch,
    UV_OT_toggle_uv_sync,
    UV_OT_toggle_live_unwrap,
    UV_MT_ruv_submenu,
    ST_MT_QuickPie,
]