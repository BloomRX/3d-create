import bpy
import json
import os
from .. import state as addon_state
from ..keymap import update_keymap_callback


def execute_import_from_file(context, filepath, apply_settings_now, operator_instance=None):
    if not filepath or not os.path.exists(filepath):
        message = f"File not found: {filepath}"
        print(f"SUPERTABs Import Error: {message}")
        if operator_instance:
            operator_instance.report({"ERROR"}, "Import file not found.")
        bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='ERROR')
        return False

    addon_state.is_importing = True
    try:
        print(f"SUPERTABs: Executing import logic from '{filepath}'")
        package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
        prefs = context.preferences.addons[package_name].preferences
        
        with open(filepath, "r", encoding="utf-8") as f: 
            data = json.load(f)

        pinned_data = data.get("pinned_states", {})
        manager_ui_data = data.get("manager_ui_settings", {})
        column_layout_data = data.get("column_layout_data", {})
        favorite_preset_data = data.get("favorite_preset_states", {})
        panel_expansion_data = data.get("panel_expansion_states", {})

        tab_groups_data = data.get("tab_groups", []) if isinstance(data, dict) else data if isinstance(data, list) else []
        other_settings_data = data if isinstance(data, dict) else {}

        # Clear existing data
        prefs.tab_groups.clear()
        prefs.favorite_addons.clear()
        prefs.custom_favorite_presets.clear()
        prefs.addon_presets.clear()
        prefs.custom_item_names.clear()
        prefs.quick_shortcuts.clear()
        prefs.hidden_panels.clear()
        prefs.favorite_nodes.clear()

        for group_data in tab_groups_data:
            g = prefs.tab_groups.add()
            g.name = group_data.get("name", "Unnamed")
            g.items = group_data.get("items", "")
            g.icon = group_data.get("icon", "NONE")
            g.is_expanded = group_data.get("is_expanded", False)
            g.is_visible = group_data.get("is_visible", True)
            g.space_type = group_data.get("space_type", 'VIEW_3D')

        for key, value in other_settings_data.items():
            if key == "favorite_addons":
                for fav_name in value:
                    new_fav = prefs.favorite_addons.add()
                    new_fav.name = fav_name
            elif key == "addon_presets":
                for preset_data in value:
                    new_preset = prefs.addon_presets.add()
                    new_preset.name = preset_data.get("name", "Unnamed Preset")
                    
                    for addon_name in preset_data.get("addons", []):
                        new_addon_item = new_preset.addons.add()
                        new_addon_item.name = addon_name
            elif key == "custom_item_names":
                if isinstance(value, list):
                    for item_data in value:
                        new_item = prefs.custom_item_names.add()
                        new_item.identifier = item_data.get("identifier", "")
                        new_item.display_name = item_data.get("display_name", "")
                        new_item.icon = item_data.get("icon", "NONE")
            elif key == "quick_shortcuts":
                if isinstance(value, list):
                    for item_data in value:
                        new_item = prefs.quick_shortcuts.add()
                        new_item.identifier = item_data.get("identifier", "")
                        new_item.display_name = item_data.get("display_name", "")
                        new_item.main_group_name = item_data.get("main_group_name", "")
                        new_item.sub_group_name = item_data.get("sub_group_name", "")
                        new_item.icon = item_data.get("icon", "NONE")
                        new_item.space_type = item_data.get("space_type", "VIEW_3D")
            elif key == "favorite_nodes":
                if isinstance(value, list):
                    for node_data in value:
                        new_item = prefs.favorite_nodes.add()
                        new_item.node_idname = node_data.get("node_idname", "")
                        new_item.label = node_data.get("label", "Unknown Node")
                        new_item.icon = node_data.get("icon", "NONE")
                        new_item.tree_type = node_data.get("tree_type", "")
                        if node_data.get("is_group", False):
                            if hasattr(new_item, "is_group"):
                                new_item.is_group = True
                            if hasattr(new_item, "serialized_data"):
                                new_item.serialized_data = node_data.get("serialized_data", "")
            elif key == "quick_menu_settings":
                if isinstance(value, dict):
                    for setting_key, setting_value in value.items():
                        if hasattr(prefs, setting_key):
                            try:
                                setattr(prefs, setting_key, setting_value)
                            except Exception as e:
                                print(f"SUPERTABs Info: Could not set RCM setting '{setting_key}': {e}")

            elif key == "hidden_panels":
                if isinstance(value, list):
                    for panel_id_str in value:
                        if panel_id_str:
                            new_item = prefs.hidden_panels.add()
                            new_item.panel_id = panel_id_str   

            elif key in ["tab_groups", "auto_apply_after_import", "custom_favorite_presets", "favorite_preset_states"]:
                continue
            elif hasattr(prefs, key):
                try:
                    setattr(prefs, key, value)
                except Exception as e:
                    print(f"SUPERTABs Info: Could not set preference '{key}': {e}")
    
        if apply_settings_now:
            
            print("SUPERTABs: Applying settings immediately after import.")
            from . import manager
            manager.apply_group_settings(context, operator_instance, 
                            pinned_states_data=pinned_data, 
                            column_layout_data=column_layout_data, 
                            favorite_preset_data=favorite_preset_data, 
                            panel_expansion_data=panel_expansion_data)
            context.window_manager.st_ui_applied_once = True
        else:
            print("SUPERTABs: Import successful. Settings were loaded but not applied.")

        if manager_ui_data:
            print("SUPERTABs: Restoring Manager UI Settings...")
            for key, value in manager_ui_data.items():
                if hasattr(prefs, key):
                    try:
                        setattr(prefs, key, value)
                    except Exception as e:
                        print(f"Could not set property {key}: {e}")

        update_keymap_callback(None, context)
        prefs.last_used_path = os.path.dirname(filepath)
        
        report_message = f"Successfully imported from {os.path.basename(filepath)}"
        print(f"SUPERTABs: {report_message}")
        if operator_instance:
            operator_instance.report({"INFO"}, report_message)
        bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=report_message, type='SUCCESS')
        return True

    except Exception as e: 
        error_message = f"Import failed: {e}"
        print(f"SUPERTABs Info: {error_message}")
        if operator_instance:
            operator_instance.report({"ERROR"}, error_message)
        bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=error_message, type='ERROR')
        return False
    finally:
        addon_state.is_importing = False