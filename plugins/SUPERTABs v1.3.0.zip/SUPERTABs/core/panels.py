import bpy
from collections import defaultdict
from .. import state as addon_state

# def create_patch_poll_method(original_poll_func, main_group_name, item_string):
#     @classmethod
#     def new_poll_method(cls, context):
#         if original_poll_func:
#             try:
#                 if not original_poll_func(context):
#                     return False
#             except NotImplementedError:
#                 pass 
#             except Exception as e:
#                 print(f"SUPERTABs Info: Error in original poll for {item_string}: {e}")
                
#         if not hasattr(context.window_manager, "tab_group_states"):
#             return False
#         group_state = context.window_manager.tab_group_states.get(main_group_name)

#         if not group_state:
#             return False

#         is_active = group_state.active_item == item_string

#         pinned_set = {item.strip() for item in group_state.pinned_items.split(',') if item.strip()}
#         is_pinned = item_string in pinned_set
        
#         return is_active or is_pinned
        
#     return new_poll_method

def create_patch_poll_method(original_poll_func, main_group_name, item_string):
    @classmethod
    def new_poll_method(cls, context):
        if original_poll_func:
            try:
                if not original_poll_func(context):
                    return False
            except NotImplementedError:
                pass 
            except Exception as e:
                # print(f"SUPERTABs Info: Error in original poll for {item_string}: {e}")
                pass

        region = getattr(context, 'region', None)
        if region is None or region.type != 'UI':
            return True

        if not hasattr(context.window_manager, "tab_group_states"):
            return False
        group_state = context.window_manager.tab_group_states.get(main_group_name)

        if not group_state:
            return False

        is_active = group_state.active_item == item_string

        pinned_set = {item.strip() for item in group_state.pinned_items.split(',') if item.strip()}
        is_pinned = item_string in pinned_set
        
        return is_active or is_pinned
        
    return new_poll_method

def create_blenderkit_patch_poll_method(original_poll_func, main_group_name, item_string):
    @classmethod
    def new_blenderkit_poll_method(cls, context):
        if original_poll_func and not original_poll_func(context):
            return False

        if getattr(context, 'region', None) and context.region.type != 'UI':
            return True

        if not hasattr(context.window_manager, "tab_group_states"):
            return False
        
        group_state = context.window_manager.tab_group_states.get(main_group_name)
        if not group_state:
            return False

        is_active = group_state.active_item == item_string

        pinned_set = {item.strip() for item in group_state.pinned_items.split(',') if item.strip()}
        is_pinned = item_string in pinned_set
        
        return is_active or is_pinned

    return new_blenderkit_poll_method

def hide_panel(panel_class):
    from ..ui.npanels import ST_PT_HiddenPanel, ST_PT_HiddenPanel_UV, ST_PT_HiddenPanel_Node

    if not hasattr(panel_class, 'st_original_parent_id'):
        panel_class.st_original_parent_id = getattr(panel_class, 'bl_parent_id', None)
    target_space = getattr(panel_class, 'bl_space_type', 'VIEW_3D')
    
    if target_space == 'IMAGE_EDITOR':
        panel_class.bl_parent_id = ST_PT_HiddenPanel_UV.bl_idname
    elif target_space == 'NODE_EDITOR':
        panel_class.bl_parent_id = ST_PT_HiddenPanel_Node.bl_idname
    else:
        panel_class.bl_parent_id = ST_PT_HiddenPanel.bl_idname

def show_panel(panel_class, new_category):
    if hasattr(panel_class, 'st_original_parent_id'):
        original_parent = panel_class.st_original_parent_id
        if original_parent:
            panel_class.bl_parent_id = original_parent
        elif hasattr(panel_class, 'bl_parent_id'):
            delattr(panel_class, 'bl_parent_id')
    panel_class.bl_category = new_category

def get_target_panels_for_item(context, item_string, target_space='VIEW_3D'):
    
    def _get_all_subclasses_recursively(cls):
        """Helper function to guarantee a recursive search for all subclasses."""
        all_subclasses = []
        for subclass in cls.__subclasses__():
            all_subclasses.append(subclass)
            all_subclasses.extend(_get_all_subclasses_recursively(subclass))
        return all_subclasses

    try:
        item_type, item_name = item_string.split(':', 1)
    except ValueError:
        return []

    panel_registration_order = {p: i for i, p in enumerate(bpy.types.Panel.__subclasses__())}

    candidates = [
        p for p in _get_all_subclasses_recursively(bpy.types.Panel)
        if hasattr(p, 'bl_rna') and
        getattr(p, "bl_space_type", None) == target_space and
        getattr(p, "bl_region_type", None) == 'UI'
    ]

    unique_panels = {}
    for p in candidates:
        p_id = getattr(p, "bl_idname", p.__name__)
        
        real_class = getattr(bpy.types, p_id, None)
        
        is_engon = "engon" in getattr(p, "__module__", "").lower()
        
        if is_engon:
            if real_class is not None and real_class is not p:
                continue
            if real_class is None:
                continue

        unique_panels[p_id] = p

    all_panels_in_space = list(unique_panels.values())
    
    top_level_panels = []
    for panel_cls in all_panels_in_space:
        if panel_cls.__name__.startswith("_Abstract_"):
            continue

        if panel_cls.__name__ == "GRABDOC_PT_Baker":
            continue

        if "uvpackmaster4" in getattr(panel_cls, '__module__', '').lower():
            if getattr(panel_cls, 'bl_space_type', '') == 'IMAGE_EDITOR':
                if panel_cls.__name__ != "UVPM4_PT_MultiPanels":
                    continue
            
        original_category = getattr(panel_cls, 'st_original_category', getattr(panel_cls, 'bl_category', ''))
        is_match = False
        if item_type == 'tab' and original_category == item_name:
            is_match = True
        elif item_type == "addon" and item_name in panel_cls.__module__:
            is_match = True
        if is_match:
            top_level_panels.append(panel_cls)

    if not top_level_panels:
        return []

    all_related_panels = list(top_level_panels)
    parent_ids_to_check = {p.bl_idname for p in top_level_panels if hasattr(p, 'bl_idname')}

    parent_ids_to_check = set()
    for p in top_level_panels:
        if hasattr(p, 'bl_idname'): parent_ids_to_check.add(p.bl_idname)
        parent_ids_to_check.add(p.__name__)

    while True:
        newly_found_children = []
        for panel_cls in all_panels_in_space:

            if panel_cls.__name__ == "GRABDOC_PT_Baker":
                continue

            
            parent_id = getattr(panel_cls, 'bl_parent_id', None)
            if parent_id and parent_id in parent_ids_to_check:
                if panel_cls not in all_related_panels:
                    newly_found_children.append(panel_cls)
        
        if not newly_found_children:
            break

        all_related_panels.extend(newly_found_children)
        for p in newly_found_children:
            if hasattr(p, 'bl_idname'): parent_ids_to_check.add(p.bl_idname)
            parent_ids_to_check.add(p.__name__)

    matching_panels = all_related_panels
    panel_map = {cls.bl_idname: cls for cls in matching_panels if hasattr(cls, "bl_idname")}
    for cls in matching_panels:
        if cls.__name__ not in panel_map:
             panel_map[cls.__name__] = cls
    children_map = defaultdict(list)
    final_top_level_panels = []

    for panel in matching_panels:
        parent_id = getattr(panel, "bl_parent_id", None)
        if parent_id and parent_id in panel_map:
            children_map[parent_id].append(panel)
        else:
            final_top_level_panels.append(panel)

    sorted_panels = []
    
    def add_children_recursively(panel):
        sorted_panels.append(panel)
        
        children_key = getattr(panel, 'bl_idname', None)
        children = children_map.get(children_key, [])
        
        if not children:
            children = children_map.get(panel.__name__, [])
            
        sorted_children = sorted(
            children, 
            key=lambda p: (getattr(p, 'bl_order', 0), panel_registration_order.get(p, float('inf')))
        )
        for child in sorted_children:
            add_children_recursively(child)

    sorted_top_level = sorted(
        final_top_level_panels, 
        key=lambda p: (getattr(p, 'bl_order', 0), panel_registration_order.get(p, float('inf')))
    )
    for panel in sorted_top_level:
        if panel not in sorted_panels:
            add_children_recursively(panel)

    return sorted_panels