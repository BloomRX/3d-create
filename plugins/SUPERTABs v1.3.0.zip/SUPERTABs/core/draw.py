import bpy
from .panels import get_target_panels_for_item

def create_controller_header_draw_method():
    def draw_header_method(self, context):
        layout = self.layout
        row = layout.row(align=True)
        row.operator("st.toggle_display_settings", text="", icon='GRIP', emboss=True)
        row.operator("st.toggle_asset_browser", text="", icon='ASSET_MANAGER')
        row.operator("preferences.addon_show", text="", icon='PREFERENCES').module = __package__.split('.')[0]
        
    return draw_header_method

def create_controller_draw_method(main_group_name, hierarchy_data, ejected_items_set, hidden_items_set, ejected_subgroups_set, hidden_subgroups_set):
    from ..ui import npanels as ui_panel_module
    from ..ui.npanels import (
        draw_windoweditor_panel, draw_annotations_panel, 
        draw_node_stats_panel, draw_node_align_panel, draw_nodes_zoom_panel, draw_fav_nodes_panel,
        draw_basic_panel_view3d, draw_frequency_panel_view3d,
        draw_basic_panel_image, draw_frequency_panel_image,
        draw_frequency_panel_nodes, draw_external_data_panel,
    )
    def draw_method(self, context):
        layout = self.layout
        main_col = layout.column()
        context.window_manager.st_last_active_main_group = main_group_name
        package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
        prefs = context.preferences.addons[package_name].preferences
        group_state = context.window_manager.tab_group_states.get(main_group_name)
        custom_item_icon_map = {item.identifier: item.icon for item in prefs.custom_item_names if item.icon != 'NONE'}
        
        if not group_state: 
            main_col.label(text="State not found.", icon="ERROR")
            return
        
        preset_name_to_icon_map = {p.name: p.icon for p in prefs.custom_favorite_presets}

        item_preset_counts = {}
        item_single_icon = {}
        
        for preset_in_state in group_state.favorite_presets:
            icon = preset_name_to_icon_map.get(preset_in_state.name)
            if not icon:
                continue
                
            items = {item.strip() for item in preset_in_state.items.split(',') if item.strip()}
            for item in items:

                item_preset_counts[item] = item_preset_counts.get(item, 0) + 1
                
                if item not in item_single_icon:
                    item_single_icon[item] = icon

        item_to_preset_icon = {}
        for item, count in item_preset_counts.items():
            if count > 1:

                item_to_preset_icon[item] = 'SOLO_ON'
            elif count == 1:

                item_to_preset_icon[item] = item_single_icon.get(item, 'SOLO_OFF')
        if context.space_data.type == 'VIEW_3D':
            
            if prefs.show_header_3d:
                box = main_col.box()
                col = box.column()
                if prefs.show_quick_3d:
                    row = col.row(align=True)
                    draw_frequency_panel_view3d(row, context)
                    if prefs.show_guide:
                        row.separator(factor=0.5)
                        guide_box = row.box()
                        op = guide_box.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                        op.url = "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"
                    draw_annotations_panel(col, context)
                if prefs.show_windoweditor_panel:
                    draw_windoweditor_panel(col, context, group_state)
                if prefs.show_basic_panel:
                        draw_basic_panel_view3d(col, context)

        elif context.space_data.type == 'IMAGE_EDITOR':
            is_uv = (context.space_data.mode == 'UV')
            show_main_header = prefs.show_header_image if is_uv else getattr(prefs, 'show_header_image_only', True)
            if show_main_header:
                box = main_col.box()
                col = box.column()
                show_quick = prefs.show_quick_uv if is_uv else getattr(prefs, 'show_quick_image', True)
                if show_quick:
                    row = col.row(align=True)
                    draw_frequency_panel_image(row, context)
                    if prefs.show_guide:
                        row.separator(factor=0.5)
                        guide_box = row.box()
                        op = guide_box.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                        op.url = "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"
                if prefs.show_external_data_panel:
                    space = context.space_data
                    if space.mode != 'UV':
                        draw_external_data_panel(col, context)

                draw_annotations_panel(col, context)

                if getattr(prefs, "show_image_selector", True):
                    sima = context.space_data
                    temp_box = col.box()
                    temp_col = temp_box.column()
                    temp_col.template_ID(sima, "image", new="image.new", open="image.open")

                show_basic = prefs.show_basic_uv_buttons if is_uv else getattr(prefs, 'show_basic_image_buttons', True)

                if show_basic:
                    if context.space_data.image:
                        draw_basic_panel_image(col, context)

        elif context.space_data.type == 'NODE_EDITOR':
            show_header_current = prefs.show_header_nodes
            valid_node_trees = {'GeometryNodeTree', 'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree'}
            current_tree = getattr(context.space_data, 'tree_type', '')

            if current_tree == 'GeometryNodeTree': show_header_current = prefs.st_node_header_geometry
            elif current_tree == 'ShaderNodeTree': show_header_current = prefs.st_node_header_shading
            elif current_tree == 'CompositorNodeTree': show_header_current = prefs.st_node_header_compositor
            elif current_tree == 'TextureNodeTree': show_header_current = prefs.st_node_header_texture

            if show_header_current:
                box = main_col.box()
                col = box.column()
                
                use_quick_local = False
                use_fav_nodes_local = False
                use_zoom_local = False

                if current_tree == 'GeometryNodeTree':
                    use_quick_local = prefs.st_node_quick_geometry
                    use_fav_nodes_local = prefs.st_node_show_fav_nodes_geometry
                    use_zoom_local = prefs.st_node_zoom_geometry
                elif current_tree == 'ShaderNodeTree':
                    use_quick_local = prefs.st_node_quick_shading
                    use_fav_nodes_local = prefs.st_node_show_fav_nodes_shading
                    use_zoom_local = prefs.st_node_zoom_shading
                elif current_tree == 'CompositorNodeTree':
                    use_quick_local = prefs.st_node_quick_compositor
                    use_fav_nodes_local = prefs.st_node_show_fav_nodes_compositor
                    use_zoom_local = prefs.st_node_zoom_compositor
                elif current_tree == 'TextureNodeTree':
                    use_quick_local = prefs.st_node_quick_texture
                    use_fav_nodes_local = prefs.st_node_show_fav_nodes_texture
                    use_zoom_local = prefs.st_node_zoom_texture

                if use_quick_local:
                    if current_tree in valid_node_trees:
                        row = col.row(align=True)
                        draw_frequency_panel_nodes(row, context)
                        if prefs.show_guide:
                            row.separator(factor=0.5)
                            guide_box = row.box()
                            op = guide_box.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                            op.url = "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"
                draw_annotations_panel(col, context)
                draw_node_stats_panel(col, context)
                draw_node_align_panel(col, context)

                if use_fav_nodes_local:
                    if current_tree in valid_node_trees:
                        draw_fav_nodes_panel(col, context)

                if use_zoom_local:
                    if current_tree in valid_node_trees:
                        draw_nodes_zoom_panel(col, context)

        display_name_map = {f"addon:{item.name}": item.display_name for item in prefs.addon_display_lookup}
        display_name_map.update({f"tab:{item.name}": item.name for item in prefs.available_tabs})
        display_name_map.update({item.identifier: item.display_name for item in prefs.custom_item_names if item.display_name})
        pinned_set = {item.strip() for item in group_state.pinned_items.split(',') if item.strip()}

        search_term = group_state.item_search_query.lower()
        
        def item_filter(item_string):
            if not search_term:
                return True
            display_text = display_name_map.get(item_string, item_string.split(":", 1)[-1])
            return search_term in item_string.lower() or search_term in display_text.lower()

        active_item_str = group_state.active_item
        active_and_pinned_items = pinned_set.union({active_item_str} if active_item_str else set())
        
        active_preset = next((p for p in group_state.favorite_presets if p.name == group_state.active_favorite_preset_name), None)
        favorite_set = set()
        if active_preset:
            favorite_set = {item.strip() for item in active_preset.items.split(',') if item.strip()}
        
        excluded_by_toggle = set()
        if context.space_data.type == 'VIEW_3D':
            if prefs.manage_item_tab: excluded_by_toggle.add("Item")
            if prefs.manage_tool_tab: excluded_by_toggle.add("Tool")
            if prefs.manage_view_tab: excluded_by_toggle.add("View")
            if prefs.manage_edit_tab: excluded_by_toggle.add("Edit")
        elif context.space_data.type == 'IMAGE_EDITOR':
            if prefs.manage_uv_image_tab: excluded_by_toggle.add("Image")
            if prefs.manage_uv_tool_tab: excluded_by_toggle.add("Tool")
            if prefs.manage_uv_view_tab: excluded_by_toggle.add("View")
            if prefs.manage_uv_scope_tab: excluded_by_toggle.add("Scope")
        elif context.space_data.type == 'NODE_EDITOR':
            if prefs.manage_node_options_tab: excluded_by_toggle.add("Options")
            if prefs.manage_node_tool_tab: excluded_by_toggle.add("Tool")
            if prefs.manage_node_view_tab: excluded_by_toggle.add("View")
            if prefs.manage_node_node_tab: excluded_by_toggle.add("Node")
            if prefs.manage_node_group_tab: excluded_by_toggle.add("Group")

        restricted_node_tabs = set()
        standard_tabs_check_list = {'Item', 'Tool', 'View', 'Node', 'Group', 'Options'}
        current_tree_type = getattr(context.space_data, 'tree_type', '')
        
        data_dependent_tabs = {'Options', 'View', 'Group'}

        if context.space_data.type == 'NODE_EDITOR':
            if current_tree_type == 'ShaderNodeTree':
                restricted_node_tabs = {}
                data_dependent_tabs = {'Options', 'View'}
            elif current_tree_type == 'GeometryNodeTree': 
                restricted_node_tabs = {'Options'}
            elif current_tree_type == 'CompositorNodeTree': 
                restricted_node_tabs = {'Group'}
            elif current_tree_type == 'TextureNodeTree': 
                restricted_node_tabs = {'Group', 'Options'}
        default_item_cols = max(1, group_state.item_columns)

        show_fav_panel_local = group_state.show_favorites_panel
        show_fav_node_panel_local = group_state.show_favorite_nodes_panel
        show_group_panel_local = group_state.show_groupaddons_panel
        

        if context.space_data.type == 'NODE_EDITOR':
            current_tree_type = getattr(context.space_data, 'tree_type', '')
            target_suffix = ""
            
            if current_tree_type == 'ShaderNodeTree': target_suffix = "shading"
            elif current_tree_type == 'GeometryNodeTree': target_suffix = "geometry"
            elif current_tree_type == 'CompositorNodeTree': target_suffix = "compositor"
            elif current_tree_type == 'TextureNodeTree': target_suffix = "texture"

            if target_suffix and hasattr(prefs, f"st_node_cols_{target_suffix}"):
                default_item_cols = getattr(prefs, f"st_node_cols_{target_suffix}")
                default_item_cols = max(1, default_item_cols)
                
                show_fav_panel_local = getattr(prefs, f"st_node_fav_{target_suffix}")
                show_fav_node_panel_local = getattr(prefs, f"st_node_fav_{target_suffix}")
                show_group_panel_local = getattr(prefs, f"st_node_opt_{target_suffix}")
                
        main_items_filtered = [item for item in hierarchy_data["__items__"] if item_filter(item)]
        
        current_target_space = 'VIEW_3D'
        if context.space_data.type == 'IMAGE_EDITOR': current_target_space = 'IMAGE_EDITOR'
        elif context.space_data.type == 'NODE_EDITOR': current_target_space = 'NODE_EDITOR'

        quick_shortcut_set = {qs.identifier for qs in prefs.quick_shortcuts if qs.space_type == current_target_space}

        visible_main_items = []
        if main_items_filtered:
            for item_string in main_items_filtered:
                try:
                    item_type, item_name = item_string.split(':', 1)
                    should_hide = False
                    
                    if item_type == 'tab':
                        if item_name in excluded_by_toggle: 
                            should_hide = True
                        
                        elif item_name in standard_tabs_check_list:
                            if context.space_data.type == 'NODE_EDITOR' and item_name in data_dependent_tabs:
                                if not getattr(context.space_data, 'node_tree', None):
                                    should_hide = True
                            if restricted_node_tabs and item_name in restricted_node_tabs:
                                should_hide = True

                    if not should_hide and context.space_data.type == 'NODE_EDITOR' and item_name != 'Node':
                        target_panels = get_target_panels_for_item(context, item_string, 'NODE_EDITOR')
                        if target_panels:
                            has_visible_panel = False
                            for p in target_panels:
                                p_tree = getattr(p, 'bl_tree_type', None)
                                if p_tree and p_tree != current_tree_type:
                                    continue 

                                poll_passed = True
                                try:
                                    if hasattr(p, 'st_original_poll') and p.st_original_poll:
                                        if not p.st_original_poll(context): poll_passed = False
                                    elif hasattr(p, 'poll'):
                                        if getattr(p.poll, '__name__', '') not in ('new_poll_method', 'new_blenderkit_poll_method'):
                                            if not p.poll(context): poll_passed = False
                                except: 
                                    poll_passed = True

                                if poll_passed:
                                    has_visible_panel = True
                                    break
                            
                            if not has_visible_panel:
                                should_hide = True
                    elif not should_hide and context.space_data.type == 'IMAGE_EDITOR':
                        if item_type != 'tab' or item_name not in standard_tabs_check_list:
                            target_panels = get_target_panels_for_item(context, item_string, 'IMAGE_EDITOR')

                            if target_panels:
                                has_visible_panel = False
                                for p in target_panels:
                                    poll_passed = True
                                    try:
                                        if hasattr(p, 'st_original_poll') and p.st_original_poll:
                                            if not p.st_original_poll(context): poll_passed = False
                                        elif hasattr(p, 'poll'):
                                            if getattr(p.poll, '__name__', '') not in ('new_poll_method', 'new_blenderkit_poll_method'):
                                                if not p.poll(context): poll_passed = False
                                    except: 
                                        poll_passed = True

                                    if poll_passed:
                                        has_visible_panel = True
                                        break
                                
                                if not has_visible_panel:
                                    should_hide = True

                            
                    if not should_hide: visible_main_items.append(item_string)
                except ValueError: pass

        if visible_main_items:
            root_item_box = main_col.box()
            root_col = root_item_box.column()
            
            for i in range(0, len(visible_main_items), default_item_cols):
                row = root_col.row(align=True)
                for item_string in visible_main_items[i:i+default_item_cols]:
                    
                    if item_string in ejected_items_set or item_string in hidden_items_set: continue
                    display_text = display_name_map.get(item_string, item_string.split(":", 1)[-1])
                    sub_row = row.row(align=True)

                    item_icon = 'NONE'
                    
                    if item_string in custom_item_icon_map:
                        item_icon = custom_item_icon_map[item_string]
                    
                    is_favorited = item_string in item_to_preset_icon
                    if is_favorited:
                        pass 

                    is_active_or_pinned = (group_state.active_item == item_string) or (item_string in pinned_set)
                    
                    op = sub_row.operator("st.set_item_state", text=display_text, depress=is_active_or_pinned, icon=item_icon if item_icon != 'NONE' else 'NONE')
                    op.group_name = main_group_name
                    op.item_string = item_string

                    if prefs.show_favorite_buttons:
                        is_favorited = item_string in item_to_preset_icon
                        icon_to_show = 'SOLO_ON' if is_favorited else 'SOLO_OFF'
                        op_fav_menu = sub_row.operator("st.call_add_to_favorite_menu", text="", icon=icon_to_show, depress=is_favorited)
                        op_fav_menu.group_name = main_group_name
                        op_fav_menu.item_string = item_string
                    if prefs.show_quick_pin_buttons:
                        is_pinned_qs = item_string in quick_shortcut_set
                        icon_qs = 'PINNED' if is_pinned_qs else 'UNPINNED'
                        op_qs = sub_row.operator("st.toggle_quick_shortcut", text="", icon=icon_qs, emboss=True)
                        op_qs.item_identifier = item_string
                        op_qs.display_name = display_text
                        op_qs.main_group_name = main_group_name
                        op_qs.sub_group_name = ""
                    if prefs.show_hide_buttons:
                        op_hide = sub_row.operator("st.toggle_item_visibility", text="", icon='GHOST_DISABLED', emboss=False)
                        op_hide.item_string = item_string
                    if prefs.show_eject_buttons:
                        eject_row = sub_row.row(align=True)
                        is_uvpm3 = "uvpackmaster3" in item_string.lower()
                        eject_row.active = not is_uvpm3
                        op_eject = eject_row.operator("st.eject_item", text="", icon='TRIA_RIGHT_BAR', emboss=False)
                        op_eject.item_string = item_string
        
        should_show_manager_box = True
        
        if context.space_data.type == 'VIEW_3D':
            if not prefs.show_manager_header_3d:
                should_show_manager_box = False
            elif not (prefs.show_fav_panel_3d or prefs.show_groups_panel_3d):
                should_show_manager_box = False
        
        elif context.space_data.type == 'IMAGE_EDITOR':
            is_uv = (context.space_data.mode == 'UV')
            
            chk_master = prefs.show_manager_header_image if is_uv else getattr(prefs, 'show_manager_header_image_only', True)
            
            if not chk_master:
                should_show_manager_box = False
            else:
                chk_fav = prefs.show_fav_panel_image if is_uv else getattr(prefs, 'show_fav_panel_image_only', True)
                chk_groups = prefs.show_groups_panel_image if is_uv else getattr(prefs, 'show_groups_panel_image_only', True)
                
                if not (chk_fav or chk_groups):
                    should_show_manager_box = False

        elif context.space_data.type == 'NODE_EDITOR':
            if 'target_suffix' in locals() and target_suffix:
                manager_prop_name = f"show_manager_header_{target_suffix}"
                
                fav_prop_name = f"show_fav_panel_{target_suffix}"
                opt_prop_name = f"show_groups_panel_{target_suffix}"
                
                is_master_on = getattr(prefs, manager_prop_name, True)
                
                if not is_master_on:
                    should_show_manager_box = False
                else:
                    is_fav_show = getattr(prefs, fav_prop_name, True)
                    is_opt_show = getattr(prefs, opt_prop_name, True)
                    
                    if not (is_fav_show or is_opt_show):
                        should_show_manager_box = False
            else:
                should_show_manager_box = True

        if should_show_manager_box:
            panel_box = main_col.box()
            panel_col = panel_box.column()
            is_node_override = (context.space_data.type == 'NODE_EDITOR' and 'target_suffix' in locals() and target_suffix)
            is_manager_expanded = True

            if is_manager_expanded:
                show_fav = True
                show_groups = True
                show_collapse = False
                
                if context.space_data.type == 'VIEW_3D':
                    show_fav = prefs.show_fav_panel_3d
                    show_groups = prefs.show_groups_panel_3d
                    show_collapse = getattr(prefs, "show_collapse_all_3d", False)

                elif context.space_data.type == 'IMAGE_EDITOR':
                    is_uv = (context.space_data.mode == 'UV')
                    
                    if is_uv:
                        show_fav = prefs.show_fav_panel_image
                        show_groups = prefs.show_groups_panel_image
                        show_collapse = getattr(prefs, "show_collapse_all_image", False)
                    else:
                        show_fav = getattr(prefs, "show_fav_panel_image_only", True)
                        show_groups = getattr(prefs, "show_groups_panel_image_only", True)
                        show_collapse = getattr(prefs, "show_collapse_all_image_only", False)

                elif context.space_data.type == 'NODE_EDITOR' and 'target_suffix' in locals():
                    show_fav = getattr(prefs, f"show_fav_panel_{target_suffix}", True)
                    show_groups = getattr(prefs, f"show_groups_panel_{target_suffix}", True)
                    show_collapse = getattr(prefs, f"show_collapse_all_{target_suffix}", False)

                header_row = panel_col.row(align=True)

                is_node_override = (context.space_data.type == 'NODE_EDITOR' and 'target_suffix' in locals() and target_suffix)
                if show_fav:
                    fav_tab_box = header_row.box()
                    fav_tab_row = fav_tab_box.row(align=True)
                    if is_node_override:
                        icon = 'TRIA_DOWN' if getattr(prefs, f"st_node_fav_{target_suffix}", True) else 'TRIA_RIGHT'
                        fav_tab_row.prop(prefs, f"st_node_fav_{target_suffix}", text="Favorite Tabs Presets", icon=icon, emboss=False, toggle=True)
                        is_fav_expanded = getattr(prefs, f"st_node_fav_{target_suffix}")
                    else:
                        icon = 'TRIA_DOWN' if group_state.show_favorites_panel else 'TRIA_RIGHT'
                        fav_tab_row.prop(group_state, "show_favorites_panel", text="Favorite Tabs Presets", icon=icon, emboss=False, toggle=True)
                        is_fav_expanded = group_state.show_favorites_panel

                    if prefs.show_guide:
                        op = fav_tab_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                        op.url = "https://www.notion.so/SUPERTABs-Favorite-Tab-Preset-Guide-N-Panel-v1-3-0-29cb1f0a835380469d1bc23587b6b679?source=copy_link"
                else:
                    is_fav_expanded = False

                if show_fav and show_groups:
                    header_row.separator(factor=0.5)

                if show_groups:
                    addons_box = header_row.box()
                    addons_row = addons_box.row(align=True)
                    if is_node_override:
                        icon = 'TRIA_DOWN' if getattr(prefs, f"st_node_opt_{target_suffix}") else 'TRIA_RIGHT'
                        addons_row.prop(prefs, f"st_node_opt_{target_suffix}", text="Groups & Addons", icon=icon, emboss=False, toggle=True)
                        is_group_expanded = getattr(prefs, f"st_node_opt_{target_suffix}")
                    else:
                        icon = 'TRIA_DOWN' if group_state.show_groupaddons_panel else 'TRIA_RIGHT'
                        addons_row.prop(group_state, "show_groupaddons_panel", text="Groups & Addons", icon=icon, emboss=False, toggle=True)
                        is_group_expanded = group_state.show_groupaddons_panel
                    if prefs.show_guide:
                        op = addons_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                        op.url = "https://www.notion.so/SUPERTABs-Groups-Add-on-Section-N-Panel-v1-3-0-29cb1f0a835380c6a4ecd8a2de18dd10?source=copy_link"
                else:
                    is_group_expanded = False
                
                header_row.separator(factor=0.5)
                if show_collapse:
                    collapse_box = header_row.box()
                    collapse_row = collapse_box.row(align=True)
                
                    op_collapse = collapse_row.operator("st.collapse_all_groups", text="", icon='FULLSCREEN_EXIT', emboss=False)
                    op_collapse.group_name = main_group_name

                if is_fav_expanded:
                    fav_box = panel_col.box()
                    main_split = fav_box.split(factor=0.9)
                    left_col = main_split.column(align=True)
                    right_col = main_split.column(align=True)

                    right_col.scale_y = 1
                    right_row = right_col.row(align=True)
                    right_row.scale_x = 2.5

                    prop_info = group_state.bl_rna.properties['favorite_item_columns']
                    current_val = group_state.favorite_item_columns
                    min_val = prop_info.soft_min
                    max_val = prop_info.soft_max

                    minus_row = right_row.row(align=True)
                    minus_row.enabled = current_val > min_val
                    op_minus = minus_row.operator("st.change_favorite_columns", text="", icon='TRIA_LEFT')
                    op_minus.group_name = main_group_name
                    op_minus.delta = -1

                    plus_row = right_row.row(align=True)
                    plus_row.enabled = current_val < max_val
                    op_plus = plus_row.operator("st.change_favorite_columns", text="", icon='TRIA_RIGHT')
                    op_plus.group_name = main_group_name
                    op_plus.delta = 1

                    set_row = right_col.row(align=True)
                    set_row.scale_x = 2.5
                    set_row.prop(prefs,"show_favorite_set_button", text="", icon='DOWNARROW_HLT'if prefs.show_favorite_set_button else "RIGHTARROW")
                    op_expand = right_col.column(align=True)
                    
                    if prefs.show_favorite_set_button:
                        op_expand.separator(factor=0.5)
                        op_row = op_expand.row(align=True)
                        op_row.scale_y = 1.25
                        op_row.scale_x = 2.5
                        op_row.prop(group_state, "show_preset_settings", text="", icon='SETTINGS')
                        

                    right_col.separator()

                    pin_col = right_col.column(align=True)
                    pin_col.scale_y = 2.5
                    are_all_pinned = bool(favorite_set) and favorite_set.issubset(pinned_set)
                    op_toggle_pin = pin_col.operator("st.toggle_pin_all_favorites", text="", icon='PINNED', depress=are_all_pinned)
                    op_toggle_pin.group_name = main_group_name

                    if group_state.show_preset_settings:
                        settings_box = left_col.box()
                        col_settings = settings_box.column(align=True)

                        reorder_row = col_settings.row(align=True)
                        reorder_row.label(text="Favorite Tabs Preset Settings:")
                        col_settings.separator(factor=0.5)
                        icon_row = col_settings.row(align=True)
                        icon_row.prop(group_state, "show_subgroup_icons", text="Tab-Groups Preset Icon", toggle=True)
                        icon_row.prop(group_state, "show_favorite_icons", text="Addons/Tabs Preset Icon", toggle=True)
                        
                        col_settings.separator(factor=0.5)
                        add_row = col_settings.row(align=True)
                        
                        # --- Add Preset ---
                        op_add = add_row.operator("st.add_favorite_preset", text="Add Preset", icon='ADD')
                        op_add.group_name = main_group_name
                        
                        # --- Set Presets ---
                        op_set = add_row.operator("st.set_favorite_presets_dialog", text="Set Presets", icon='PRESET_NEW')
                        op_set.group_name = main_group_name
                        
                        relevant_presets_with_global_index = [
                            (i, p) for i, p in enumerate(prefs.custom_favorite_presets) 
                            if p.main_group_name == main_group_name
                        ]

                        active_index = -1
                        active_name = group_state.active_favorite_preset_name
                        if active_name:
                            for i, (global_index, preset) in enumerate(relevant_presets_with_global_index):
                                if preset.name == active_name:
                                    active_index = i 
                                    break

                        up_op_row = reorder_row.row(align=True)
                        up_op_row.enabled = active_index > 0 
                        op_up = up_op_row.operator("st.reorder_active_favorite_preset", text="", icon='TRIA_UP')
                        op_up.group_name = main_group_name
                        op_up.direction = 'UP'

                        down_op_row = reorder_row.row(align=True)
                        down_op_row.enabled = active_index != -1 and active_index < len(relevant_presets_with_global_index) - 1
                        op_down = down_op_row.operator("st.reorder_active_favorite_preset", text="", icon='TRIA_DOWN')
                        op_down.group_name = main_group_name
                        op_down.direction = 'DOWN'
                        
                        col_settings.separator()

                        if relevant_presets_with_global_index:
                            for global_index, preset in relevant_presets_with_global_index:
                                row = col_settings.row(align=True)
                                op_icon = row.operator("st.open_favorite_icon_picker", text="", icon=preset.icon)
                                op_icon.preset_index = global_index
                                row.prop(preset, "name", text="")

                                op_remove = row.operator("st.remove_favorite_preset", text="", icon='X')
                                op_remove.preset_index = global_index
                                op_remove.group_name = main_group_name
                                
                                row.separator()

                                op_active = row.operator(
                                    "st.set_active_favorite_preset",
                                    text="", 
                                    icon='RADIOBUT_ON' if group_state.active_favorite_preset_name == preset.name else 'RADIOBUT_OFF',
                                    emboss=False
                                )
                                op_active.group_name = main_group_name
                                op_active.preset_name = preset.name
                        else:
                            col_settings.alert = True
                            col_settings.label(text="No presets created yet, press 'Add Preset' to create one.")
                        
                    else:
                        relevant_presets = [p for p in prefs.custom_favorite_presets if p.main_group_name == main_group_name]
                        if relevant_presets:
                            preset_box = left_col.box() 
                            grid = preset_box.grid_flow(row_major=True, columns=8, even_columns=True, align=True)
                            for preset in relevant_presets:
                                op = grid.operator(
                                    "st.set_active_favorite_preset",
                                    text="", 
                                    icon=preset.icon,
                                    depress=(group_state.active_favorite_preset_name == preset.name)
                                )
                                op.group_name = main_group_name
                                op.preset_name = preset.name
                            if prefs.show_favorite_set_button:
                                preset_row = preset_box.row(align=True)
                                op_add_items_to_active = preset_row.operator("st.add_items_to_preset_dialog", text="Add-ons/Tabs Menu", icon='PLUS')
                                op_add_items_to_active.group_name = main_group_name
                                op_add_items_to_active.preset_name = group_state.active_favorite_preset_name
                                if not group_state.active_favorite_preset_name:
                                    op_add_items_to_active.active = False

                                op_remove = preset_row.prop(prefs,"show_remove_fav_button", text="", icon='X')

                                preset_row.separator()
                                row_alert = preset_row.row(align=True)
                                row_alert.alert = True
                                op_clear = row_alert.operator("st.clear_favorites", text="", icon='TRASH')
                                op_clear.group_name = main_group_name

                            if favorite_set:
                                item_cols_for_fav = max(1, group_state.favorite_item_columns)
                                sorted_favorites = sorted(list(favorite_set))
                                for i in range(0, len(sorted_favorites), item_cols_for_fav):
                                    item_row = left_col.row(align=True)
                                    for item_string in sorted_favorites[i:i+item_cols_for_fav]:
                                        display_text = display_name_map.get(item_string, item_string.split(":", 1)[-1])
                                        sub_row = item_row.row(align=True)
                                        item_icon = item_to_preset_icon.get(item_string, 'NONE')
                                        is_active_or_pinned = (group_state.active_item == item_string) or (item_string in pinned_set)
                                        op = sub_row.operator("st.set_item_state", text=display_text, depress=is_active_or_pinned, icon=item_icon)
                                        op.group_name = main_group_name
                                        op.item_string = item_string

                                        if prefs.show_remove_fav_button:
                                            op_remove = sub_row.operator("st.remove_item_from_favorite_preset", text="", icon='X')
                                            op_remove.group_name = main_group_name
                                            op_remove.item_string = item_string
                                            op_remove.preset_name = group_state.active_favorite_preset_name
                            else:
                                left_col.label(text="Preset is empty.")
                        else:
                            align_col = left_col.column(align=True)
                            align_col.alignment = 'CENTER'
                            col_alert = align_col.column()
                            col_alert.alert = True
                            col_alert.label(text="[No presets created yet]")
                            align_col.label(text="You can add presets in the 'Favorite Tabs Preset Settings'.")

                # --- Groups & Addons Section ---
                if is_group_expanded:
                    main_box = panel_col.box()
                    content_col = main_box.column()
                    if prefs.hide_options_subgroups:
                        search_row = content_col.row()
                        search_row.prop(group_state, "item_search_query", text="", icon='VIEWZOOM', emboss=True)

                        content_col.separator(factor=0.5)

                        sub_group_item_map = {
                            group.name.split(" / ", 1)[1]: group 
                            for group in prefs.tab_groups 
                            if "/" in group.name and group.name.startswith(main_group_name + " /")
                        }
                        is_any_subgroup_expanded = False
                        if sub_group_item_map:
                            for sub_name, sub_group_item in sub_group_item_map.items():
                                full_name = f"{main_group_name} / {sub_name}"
                                if sub_group_item.is_expanded and (full_name not in hidden_subgroups_set) and (full_name not in ejected_subgroups_set):
                                    is_any_subgroup_expanded = True
                                    break 
                        are_main_items_visible = False
                        if hierarchy_data["__items__"]:
                            for item_string in hierarchy_data["__items__"]:
                                if item_string not in ejected_items_set and item_string not in hidden_items_set:
                                    try:
                                        item_type, item_name = item_string.split(':', 1)
                                        if item_type == 'tab' and item_name in excluded_by_toggle:
                                            continue 
                                    except ValueError:
                                        pass
                                    
                                    are_main_items_visible = True
                                    break
                                
                        should_enable_button = are_main_items_visible or is_any_subgroup_expanded

                        row = content_col.row(align=True)
                        button_row = row.row(align=True) 

                        fav_button_subrow = button_row.row(align=True)
                        fav_button_subrow.scale_x = 5
                        fav_button_subrow.enabled = should_enable_button
                        fav_button_subrow.prop(prefs, "show_favorite_buttons", text="", icon='SOLO_ON', toggle=True)
                        fav_button_subrow.prop(prefs, "show_quick_pin_buttons", text="", icon='PINNED', toggle=True)

                        button_row.separator()
                        vis_row = button_row.row(align=True)
                        vis_row.scale_x = 3
                        vis_row.prop(prefs, "show_hide_buttons", text="", icon='GHOST_DISABLED', toggle=True)
                        vis_row.prop(prefs, "show_eject_buttons", text="", icon='TRIA_RIGHT_BAR', toggle=True)

                        button_row.separator()

                        prop_info = group_state.bl_rna.properties['subgroup_columns']
                        current_val = group_state.subgroup_columns
                        min_val = prop_info.soft_min
                        max_val = prop_info.soft_max

                        dec_row = button_row.row(align=True)
                        dec_row.enabled = current_val > min_val
                        op_dec = dec_row.operator("tab_group.change_columns", text="", icon='TRIA_LEFT')
                        op_dec.group_name = main_group_name
                        op_dec.target_property = 'subgroup_columns'
                        op_dec.delta = -1

                        inc_row = button_row.row(align=True)
                        inc_row.enabled = current_val < max_val
                        op_inc = inc_row.operator("tab_group.change_columns", text="", icon='TRIA_RIGHT')
                        op_inc.group_name = main_group_name
                        op_inc.target_property = 'subgroup_columns'
                        op_inc.delta = 1

                    content_col.separator(factor=0.25)

                    current_space = context.space_data.type
                    
                    show_ejected_btn = False
                    if prefs.ejected_subgroups:
                        ejected_list = [s.strip() for s in prefs.ejected_subgroups.split(',') if s.strip()]
                        for sub_full_name in ejected_list:
                            target_group = next((g for g in prefs.tab_groups if g.name == sub_full_name), None)
                            if target_group and target_group.space_type == current_space:
                                show_ejected_btn = True
                                break
                    show_hidden_btn = False
                    if prefs.hidden_subgroups:
                        hidden_list = [s.strip() for s in prefs.hidden_subgroups.split(',') if s.strip()]
                        for sub_full_name in hidden_list:
                            target_group = next((g for g in prefs.tab_groups if g.name == sub_full_name), None)
                            if target_group and target_group.space_type == current_space:
                                show_hidden_btn = True
                                break

                    if show_ejected_btn:
                        row.separator()
                        sub = row.row()
                        sub.alert = True
                        sub.operator("st.open_ejected_subgroups_popover", text="", icon='TRIA_LEFT_BAR', emboss=True)
                    if show_hidden_btn:
                        sub = row.row()
                        sub.alert = True
                        sub.operator("st.open_hidden_subgroups_popover", text="", icon='GHOST_ENABLED', emboss=True)
                    
                    subgroup_cols = max(1, group_state.subgroup_columns)
                    display_name_map = {f"addon:{item.name}": item.display_name for item in prefs.addon_display_lookup}
                    display_name_map.update({f"tab:{item.name}": item.name for item in prefs.available_tabs})
                    display_name_map.update({item.identifier: item.display_name for item in prefs.custom_item_names if item.display_name})
                    pinned_set = {item.strip() for item in group_state.pinned_items.split(',') if item.strip()}
                    
                    sub_groups_in_order = hierarchy_data["ordered_sub_groups"]
                    if sub_groups_in_order:
                        toggle_box = content_col.box()
                        sub_group_item_map = {group.name.split(" / ", 1)[1]: group for group in prefs.tab_groups if "/" in group.name and group.name.startswith(main_group_name + " /")}
                        for i in range(0, len(sub_groups_in_order), subgroup_cols):
                            row = toggle_box.row(align=True)

                            for sub_group_name_key, items_in_subgroup_list in sub_groups_in_order[i:i+subgroup_cols]:
                                if sub_group_item := sub_group_item_map.get(sub_group_name_key):
                                    sub_row = row.row(align=True)

                                    items_set = set(items_in_subgroup_list)
                                    is_active_in_group = not active_and_pinned_items.isdisjoint(items_set)

                                    is_favorited_in_group = not item_to_preset_icon.keys().isdisjoint(items_set)
                                    custom_icon = sub_group_item.icon

                                    if custom_icon == 'NONE': 
                                        custom_icon = 'NONE'

                                    if is_active_in_group:
                                        icon_to_show = 'FAKE_USER_ON'
                                    elif is_favorited_in_group and group_state.show_subgroup_icons:
                                        icon_to_show = 'SOLO_ON'
                                    else:
                                        if prefs.show_subgroup_custom_icons:
                                            icon_to_show = custom_icon if custom_icon != 'NONE' else 'NONE'
                                        else:
                                            icon_to_show = 'NONE'

                                    full_name = f"{main_group_name} / {sub_group_name_key}"

                                    has_hidden_items = not items_set.isdisjoint(hidden_items_set)
                                    has_ejected_items = not items_set.isdisjoint(ejected_items_set)

                                    button_text = sub_group_name_key
                                    if has_hidden_items or has_ejected_items:
                                        button_text += " ⚠️"

                                    op_toggle = sub_row.operator(
                                        "st.toggle_subgroup_expansion", 
                                        text=button_text,
                                        depress=sub_group_item.is_expanded,
                                        icon=icon_to_show
                                    )
                                    op_toggle.main_group_name = main_group_name
                                    op_toggle.subgroup_full_name = full_name
                                    
                                    if prefs.show_eject_buttons:
                                        can_eject_subgroup = items_set.isdisjoint(ejected_items_set)
                                        contains_ejected_item = not items_set.isdisjoint(ejected_items_set)
                                        contains_gscatter = any(("gscatter" in item.lower()) or ("gscatters" in item.lower()) for item in items_set)
                                        can_eject_subgroup = not contains_ejected_item and not contains_gscatter and len(sub_groups_in_order) > 1

                                        op_row = sub_row.row(align=True)
                                        op_row.active = can_eject_subgroup
                                        op_eject = op_row.operator("st.eject_subgroup", text="", icon='TRIA_RIGHT_BAR', emboss=False)
                                        op_eject.subgroup_full_name = full_name
                                    
                                    if prefs.show_hide_buttons:
                                        can_hide_subgroup = items_set.isdisjoint(ejected_items_set) and len(sub_groups_in_order) > 1
                                        op_row_hide = sub_row.row(align=True)
                                        op_row_hide.active = can_hide_subgroup
                                        op_hide = op_row_hide.operator("st.toggle_subgroup_visibility", text="", icon='GHOST_DISABLED', emboss=False)
                                        op_hide.subgroup_full_name = full_name

                        for sub_group_name_key, items in sub_groups_in_order:

                            raw_filtered = [item for item in items if item_filter(item)]
                            sub_items_filtered = []
                            for item_string in raw_filtered:
                                try:
                                    item_type, item_name = item_string.split(':', 1)
                                    should_hide = False
                                    
                                    if item_type == 'tab':
                                        if item_name in excluded_by_toggle: should_hide = True
                                        
                                        elif item_name in standard_tabs_check_list:
                                            if context.space_data.type == 'NODE_EDITOR' and item_name in {'Options', 'View', 'Group'}:
                                                if not getattr(context.space_data, 'node_tree', None):
                                                    should_hide = True
                                            if restricted_node_tabs and item_name in restricted_node_tabs:
                                                should_hide = True
                                        
                                    if not should_hide and context.space_data.type == 'NODE_EDITOR' and item_name != 'Node':
                                        target_panels = get_target_panels_for_item(context, item_string, 'NODE_EDITOR')
                                        if target_panels:
                                            has_visible_panel = False
                                            for p in target_panels:
                                                p_tree = getattr(p, 'bl_tree_type', None)
                                                if p_tree and p_tree != current_tree_type:
                                                    continue 

                                                poll_passed = True
                                                try:
                                                    if hasattr(p, 'st_original_poll') and p.st_original_poll:
                                                        if not p.st_original_poll(context): poll_passed = False
                                                    elif hasattr(p, 'poll'):
                                                        if getattr(p.poll, '__name__', '') not in ('new_poll_method', 'new_blenderkit_poll_method'):
                                                            if not p.poll(context): poll_passed = False
                                                except: 
                                                    poll_passed = True

                                                if poll_passed:
                                                    has_visible_panel = True
                                                    break
                                            
                                            if not has_visible_panel:
                                                should_hide = True
                                    elif not should_hide and context.space_data.type == 'IMAGE_EDITOR':
                                        if item_type != 'tab' or item_name not in standard_tabs_check_list:
                                            target_panels = get_target_panels_for_item(context, item_string, 'IMAGE_EDITOR')

                                            if target_panels:
                                                has_visible_panel = False
                                                for p in target_panels:
                                                    poll_passed = True
                                                    try:
                                                        if hasattr(p, 'st_original_poll') and p.st_original_poll:
                                                            if not p.st_original_poll(context): poll_passed = False
                                                        elif hasattr(p, 'poll'):
                                                            if getattr(p.poll, '__name__', '') not in ('new_poll_method', 'new_blenderkit_poll_method'):
                                                                if not p.poll(context): poll_passed = False
                                                    except: poll_passed = True
                                                    
                                                    if poll_passed:
                                                        has_visible_panel = True
                                                        break
                                                
                                                if not has_visible_panel: should_hide = True
                                    
                                    if not should_hide: sub_items_filtered.append(item_string)
                                except ValueError: pass

                            if (sub_group_item := sub_group_item_map.get(sub_group_name_key)) and \
                            (sub_group_item.is_expanded or (search_term and sub_items_filtered)):
                                if search_term and not sub_items_filtered:
                                    continue
                                
                                if prefs.hide_options_items:
                                    row = content_col.row(align=True)
                                    row.label(text=f"{sub_group_name_key}")
                                    controls = row.row(align=True); controls.alignment = 'RIGHT' 
                                    items_set = set(items)
                                    has_hidden_items = not items_set.isdisjoint(hidden_items_set)
                                    has_ejected_items = not items_set.isdisjoint(ejected_items_set)
                                    if has_ejected_items:
                                        sub = controls.row(align=True); sub.alert = True
                                        sub.operator("st.open_ejected_items_popover", text="", icon='TRIA_LEFT_BAR', emboss=True)
                                    if has_hidden_items:
                                        sub = controls.row(align=True); sub.alert = True
                                        sub.operator("st.open_hidden_items_popover", text="", icon='GHOST_ENABLED', emboss=True)
                                    subgroup_settings = group_state.subgroup_column_data.get(sub_group_name_key)
                                    if not subgroup_settings:
                                        subgroup_settings = group_state.subgroup_column_data.add(); subgroup_settings.name = sub_group_name_key
                                        num_items = len(items); initial_cols = max(1, min(default_item_cols, num_items)); subgroup_settings.item_columns = initial_cols
                                    num_items_in_subgroup = len(items); max_cols_for_ui = min(4, max(1, num_items_in_subgroup))
                                    dec_row = controls.row(align=True); dec_row.separator(); dec_row.enabled = subgroup_settings.item_columns > 1
                                    op_dec = dec_row.operator("tab_group.change_columns", text="", icon='TRIA_LEFT'); op_dec.group_name = main_group_name; op_dec.target_property = 'item_columns'; op_dec.delta = -1; op_dec.subgroup_name = sub_group_name_key
                                    inc_row = controls.row(align=True); inc_row.enabled = subgroup_settings.item_columns < max_cols_for_ui
                                    op_inc = inc_row.operator("tab_group.change_columns", text="", icon='TRIA_RIGHT'); op_inc.group_name = main_group_name; op_inc.target_property = 'item_columns'; op_inc.delta = 1; op_inc.subgroup_name = sub_group_name_key
                                subgroup_settings = group_state.subgroup_column_data.get(sub_group_name_key)
                                item_cols_for_subgroup = subgroup_settings.item_columns if subgroup_settings else default_item_cols

                                box = content_col.box()

                                if not sub_items_filtered:
                                    box.label(text="(Empty)", icon='INFO')
                                    continue

                                for i in range(0, len(sub_items_filtered), item_cols_for_subgroup):
                                    row = box.row(align=True)
                                    for item_string in sub_items_filtered[i:i+item_cols_for_subgroup]:
                                        
                                        if item_string in ejected_items_set or item_string in hidden_items_set: continue
                                        display_text = display_name_map.get(item_string, item_string.split(":", 1)[-1])
                                        sub_row = row.row(align=True)

                                        item_icon = item_to_preset_icon.get(item_string) if group_state.show_favorite_icons else None

                                        if not item_icon:
                                            if item_string in custom_item_icon_map:
                                                item_icon = custom_item_icon_map[item_string]
                                            elif prefs.show_subgroup_item_icons:
                                                subgroup_custom_icon = sub_group_item.icon
                                                item_icon = subgroup_custom_icon if subgroup_custom_icon and subgroup_custom_icon != 'NONE' else 'NONE'
                                            else:
                                                item_icon = 'NONE'

                                        is_active_or_pinned = (group_state.active_item == item_string) or (item_string in pinned_set)
                                        op = sub_row.operator("st.set_item_state", text=display_text, depress=is_active_or_pinned, icon=item_icon)
                                        op.group_name = main_group_name
                                        op.item_string = item_string
                                        
                                        if prefs.show_favorite_buttons:
                                            is_favorited = item_string in item_to_preset_icon
                                            icon_to_show = 'SOLO_ON' if is_favorited else 'SOLO_OFF'
                                            op_fav_menu = sub_row.operator("st.call_add_to_favorite_menu", text="", icon=icon_to_show, depress=is_favorited)
                                            op_fav_menu.group_name = main_group_name
                                            op_fav_menu.item_string = item_string
                                        if prefs.show_quick_pin_buttons:
                                            is_pinned_qs = item_string in quick_shortcut_set
                                            icon_qs = 'PINNED' if is_pinned_qs else 'UNPINNED'
                                            op_qs = sub_row.operator("st.toggle_quick_shortcut", text="", icon=icon_qs, emboss=True)
                                            op_qs.item_identifier = item_string
                                            op_qs.display_name = display_text
                                            op_qs.main_group_name = main_group_name
                                            op_qs.sub_group_name = sub_group_name_key
                                        if prefs.show_hide_buttons:
                                            op_hide = sub_row.operator("st.toggle_item_visibility", text="", icon='GHOST_DISABLED', emboss=False)
                                            op_hide.item_string = item_string
                                        if prefs.show_eject_buttons:
                                            eject_row = sub_row.row(align=True)
                                            is_uvpm3 = "uvpackmaster3" in item_string.lower()
                                            eject_row.active = not is_uvpm3
                                            op_eject = eject_row.operator("st.eject_item", text="", icon='TRIA_RIGHT_BAR', emboss=False)
                                            op_eject.item_string = item_string
    return draw_method

def create_ejected_controller_header_draw_method():
    def draw_header_method(self, context):
        layout = self.layout
        row = layout.row(align=True)

        row.operator("st.toggle_display_settings", text="", icon='GRIP', emboss=True)
        row.operator("st.toggle_asset_browser", text="", icon='ASSET_MANAGER')
        row.operator("preferences.addon_show", text="", icon='PREFERENCES').module = __package__.split('.')[0]
    return draw_header_method

def create_ejected_controller_draw_method(main_group_name, hierarchy_data):
    from ..ui import npanels as ui_panel_module
    from ..ui.npanels import (
        draw_windoweditor_panel, draw_annotations_panel, 
        draw_node_stats_panel, draw_node_align_panel, draw_nodes_zoom_panel,
        draw_basic_panel_view3d, draw_frequency_panel_view3d,
        draw_basic_panel_image, draw_frequency_panel_image,
        draw_frequency_panel_nodes
    )
    def draw_method(self, context):
        layout = self.layout
        addon_name = __package__.split('.')[0]
        prefs = context.preferences.addons[addon_name].preferences
        group_state = context.window_manager.tab_group_states.get(main_group_name)
        if not group_state: 
            layout.label(text="State not found.", icon="ERROR")
            return
        if context.space_data.type == 'VIEW_3D':
            col = layout.box()
            if prefs.show_quick_3d:
                draw_frequency_panel_view3d(col, context)
            if prefs.show_annotations_3dview:
                draw_annotations_panel(col, context)
            if prefs.show_windoweditor_panel:
                draw_windoweditor_panel(col, context, group_state)
            if prefs.show_basic_panel:
                draw_basic_panel_view3d(col, context)

        elif context.space_data.type == 'IMAGE_EDITOR':
            col = layout.box()
            if prefs.show_quick_uv:
                draw_frequency_panel_image(col, context)
            if prefs.show_annotations_image:
                draw_annotations_panel(col, context)
            # if prefs.show_windoweditor_panel:
            #     draw_windoweditor_panel(col, context, group_state)
            if prefs.show_basic_image_buttons:
                draw_basic_panel_image(col, context)

        elif context.space_data.type == 'NODE_EDITOR':
            col = layout.column()
            if prefs.show_quick_node:
                if getattr(context.space_data, 'tree_type', '') == 'GeometryNodeTree':
                    draw_frequency_panel_nodes(col, context)
            if prefs.show_geo_zoom_buttons:
                if getattr(context.space_data, 'tree_type', '') == 'GeometryNodeTree':
                    draw_nodes_zoom_panel(col, context)
            draw_node_stats_panel(col, context)
            draw_node_align_panel(col, context)
            if prefs.show_annotations_nodes:
                draw_annotations_panel(col, context)

        row = layout.row(align=True)
        row.label(text="Addons Columns:")
        op_dec = row.operator("tab_group.change_columns", text="", icon='TRIA_LEFT')
        op_dec.group_name = main_group_name; op_dec.target_property = 'item_columns'; op_dec.delta = -1
        op_inc = row.operator("tab_group.change_columns", text="", icon='TRIA_RIGHT')
        op_inc.group_name = main_group_name; op_inc.target_property = 'item_columns'; op_inc.delta = 1

        item_cols = max(1, group_state.item_columns)
        
        display_name_map = {f"addon:{item.name}": item.display_name for item in prefs.addon_display_lookup}
        display_name_map.update({f"tab:{item.name}": item.name for item in prefs.available_tabs})
        display_name_map.update({item.identifier: item.display_name for item in prefs.custom_item_names if item.display_name})

        if hierarchy_data["__items__"]:
            items_box = layout.box()
            pinned_set = {item.strip() for item in group_state.pinned_items.split(',') if item.strip()}
            for i in range(0, len(hierarchy_data["__items__"]), item_cols):
                row = items_box.row(align=True)
                for item_string in hierarchy_data["__items__"][i:i+item_cols]:
                    display_text = display_name_map.get(item_string, item_string.split(":", 1)[-1])

                    is_active_or_pinned = (group_state.active_item == item_string) or (item_string in pinned_set)
                    op = row.operator("st.set_item_state", text=display_text, depress=is_active_or_pinned)
                    op.group_name = main_group_name
                    op.item_string = item_string

    return draw_method