import bpy
from collections import defaultdict
from .. import state as addon_state
from ..utils import sanitize_name
from . import panels
from . import draw

def auto_apply_ui_update(self, context):
    if addon_state.is_importing:
        return None
    if context.area:
        apply_group_settings(context, operator=None)
        bpy.ops.tab_group.refresh_available('INVOKE_DEFAULT')
    return None

def refresh_available_list_callback(self, context):
    """
    Only refreshes the list of available tabs in the preferences panel.
    Used for properties that don't require a full UI rebuild.
    """
    if context.area:
        bpy.ops.tab_group.refresh_available('INVOKE_DEFAULT')
    return None

def reset_ui_to_default(context, operator=None):
    from ..ui.npanels.hidden import ST_PT_HiddenPanel, ST_PT_HiddenPanel_UV
        
    if not addon_state.managed_panels:
        if operator: 
            operator.report({"INFO"}, "UI is already at default state.")
            bpy.ops.st.set_status_message('INVOKE_DEFAULT', message="UI is already at default state.", type='INFO')
        return

    for panel_name, data in list(addon_state.managed_panels.items()):
        if data.get('type') == 'CONTROLLER':
            if controller_class := getattr(bpy.types, panel_name, None):
                try:
                    bpy.utils.unregister_class(controller_class)
                except (RuntimeError, AttributeError):
                    pass
                except Exception as e:
                    print(f"SUPERTABs Info: Failed to unregister controller class '{panel_name}': {e}")
            if panel_name in addon_state.managed_panels:
                del addon_state.managed_panels[panel_name]

    panels_to_refresh = []
    for panel_name, data in list(addon_state.managed_panels.items()):
        original_class = data.get('original_class')
        if not original_class:
            continue
        
        if hasattr(original_class, 'st_original_category'):
            original_class.bl_category = original_class.st_original_category if original_class.st_original_category is not None else ""

        if hasattr(original_class, 'st_original_parent_id'):
            original_parent = original_class.st_original_parent_id
            if original_parent:
                original_class.bl_parent_id = original_parent

            elif hasattr(original_class, 'bl_parent_id') and original_class.bl_parent_id in {ST_PT_HiddenPanel.bl_idname, ST_PT_HiddenPanel_UV.bl_idname}:
                try:
                    delattr(original_class, 'bl_parent_id')
                except AttributeError:
                    pass

        # Restore original poll method
        if hasattr(original_class, 'st_original_poll'):
            original_poll_value = original_class.st_original_poll
            if original_poll_value is not None:
                original_class.poll = original_poll_value
            elif hasattr(original_class, 'poll') and hasattr(original_class.poll, '__name__') and original_class.poll.__name__ in ('new_poll_method', 'new_blenderkit_poll_method'):
                try:
                    delattr(original_class, 'poll')
                except AttributeError:
                    pass
            try:
                delattr(original_class, 'st_original_poll')
            except AttributeError:
                pass

        panels_to_refresh.append(original_class)

    for panel_cls in panels_to_refresh:
        try:
            try:
                bpy.utils.unregister_class(panel_cls)
            except (RuntimeError, AttributeError):
                pass
            bpy.utils.register_class(panel_cls)
        except Exception as e:
            print(f"SUPERTABs Info: Failed to refresh panel '{panel_cls.__name__}': {e}")

    addon_state.managed_panels.clear()
    if hasattr(bpy.context.window_manager, "tab_group_states"):
        bpy.context.window_manager.tab_group_states.clear()
    
    message = "UI has been reset. A restart may be required for all changes to take effect."
    if operator: 
        operator.report({"INFO"}, message)
    bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='SUCCESS')
    context.window_manager.st_ui_applied_once = True

def apply_group_settings(context, operator, pinned_states_data=None, column_layout_data=None, favorite_preset_data=None, panel_expansion_data=None):
    saved_states = {}
    if hasattr(context.window_manager, "tab_group_states"):
        for state in context.window_manager.tab_group_states:
            presets_data = []
            for preset in state.favorite_presets:
                presets_data.append({"name": preset.name, "items": preset.items})
            
            subgroup_cols_data = {}
            for sub_data in state.subgroup_column_data:
                subgroup_cols_data[sub_data.name] = sub_data.item_columns

            saved_states[state.name] = {
                "active_item": state.active_item,
                "pinned_items": state.pinned_items,
                "active_favorite_preset_name": state.active_favorite_preset_name,
                "favorite_presets": presets_data,
                "subgroup_columns": state.subgroup_columns,
                "item_columns": state.item_columns,
                "favorite_item_columns": state.favorite_item_columns,
                "subgroup_column_data": subgroup_cols_data,
                "show_favorites_panel": state.show_favorites_panel,
                "show_groupaddons_panel": state.show_groupaddons_panel,
                "show_windoweditor_panel": state.show_windoweditor_panel,
                "show_subgroup_icons": state.show_subgroup_icons, 
                "show_favorite_icons": state.show_favorite_icons,
            }

    if not saved_states and hasattr(addon_state, 'last_known_states') and addon_state.last_known_states:
        saved_states = addon_state.last_known_states
        addon_state.last_known_states = {}
    elif saved_states:
        addon_state.last_known_states = saved_states.copy()

    reset_ui_to_default(context, operator=None)

    package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
    prefs = context.preferences.addons[package_name].preferences
    poll_exception_list = {
        name.strip().lower() 
        for name in prefs.poll_method_exceptions.split(',') 
        if name.strip()
    }
    
    ejected_subgroups_set = {g.strip() for g in prefs.ejected_subgroups.split(',') if g.strip()}

    potential_panel_idnames = set()
    for group in prefs.tab_groups:
        if not group.name: continue
        
        if group.name in ejected_subgroups_set:
            try:
                subgroup_name_only = group.name.split(' / ', 1)[1]
                safe_sub_name = sanitize_name(subgroup_name_only).upper()
                potential_panel_idnames.add(f"EJECTED_CONTROLLER_PT_{safe_sub_name}")
            except IndexError:
                pass 
        else:
            main_name = group.name.split(" / ")[0]
            safe_main_name = sanitize_name(main_name).upper()
            potential_panel_idnames.add(f"MAIN_CONTROLLER_PT_{safe_main_name}")

    for panel_idname in potential_panel_idnames:
        if hasattr(bpy.types, panel_idname):
            try:
                bpy.utils.unregister_class(getattr(bpy.types, panel_idname))
            except (RuntimeError, AttributeError):
                pass

    wm = context.window_manager

    excluded_by_toggle_3d = set()
    if prefs.manage_item_tab: excluded_by_toggle_3d.add("Item")
    if prefs.manage_tool_tab: excluded_by_toggle_3d.add("Tool")
    if prefs.manage_view_tab: excluded_by_toggle_3d.add("View")
    if prefs.manage_edit_tab: excluded_by_toggle_3d.add("Edit")

    excluded_by_toggle_uv = set()
    if prefs.manage_uv_image_tab: excluded_by_toggle_uv.add("Image")
    if prefs.manage_uv_tool_tab: excluded_by_toggle_uv.add("Tool")
    if prefs.manage_uv_view_tab: excluded_by_toggle_uv.add("View")
    if prefs.manage_uv_scope_tab: excluded_by_toggle_uv.add("Scope")

    excluded_by_toggle_node = set()
    if prefs.manage_node_options_tab: excluded_by_toggle_node.add("Options")
    if prefs.manage_node_tool_tab: excluded_by_toggle_node.add("Tool")
    if prefs.manage_node_view_tab: excluded_by_toggle_node.add("View")
    if prefs.manage_node_node_tab: excluded_by_toggle_node.add("Node")
    if prefs.manage_node_group_tab: excluded_by_toggle_node.add("Group")

    ejected_items_set = {p.strip() for p in prefs.temporarily_ejected_items.split(',') if p.strip()}
    ejected_subgroups_set = {g.strip() for g in prefs.ejected_subgroups.split(',') if g.strip()}
    hidden_subgroups_set = {s.strip() for s in prefs.hidden_subgroups.split(',') if s.strip()}
    hidden_items_set = {i.strip() for i in prefs.hidden_items.split(',') if i.strip()}
    hidden_panel_ids_set = {p.panel_id for p in prefs.hidden_panels}
    panels_managed_by_supertabs = set()

    for space_check in ['VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR']:
        for item_string in hidden_items_set:
            for panel_cls in panels.get_target_panels_for_item(context, item_string, target_space=space_check):
                if not hasattr(panel_cls, 'draw'):
                    continue

                if "ZenUV" in panel_cls.__module__ and getattr(panel_cls, 'bl_label', '') in {"System"}:
                    continue
                if panel_cls in panels_managed_by_supertabs:
                    continue
                
                if not hasattr(panel_cls, 'st_original_category'):
                    panel_cls.st_original_category = getattr(panel_cls, 'bl_category', None)
                if not hasattr(panel_cls, 'st_original_parent_id'):
                    panel_cls.st_original_parent_id = getattr(panel_cls, 'bl_parent_id', None)
                if not hasattr(panel_cls, 'st_original_poll'):
                    panel_cls.st_original_poll = getattr(panel_cls, 'poll', None)
                
                try:
                    try: bpy.utils.unregister_class(panel_cls)
                    except (RuntimeError, AttributeError): pass
                    
                    panels.hide_panel(panel_cls)
                    
                    bpy.utils.register_class(panel_cls)
                    
                    addon_state.managed_panels[panel_cls.__name__] = {'type': 'MANAGED', 'original_class': panel_cls}
                    panels_managed_by_supertabs.add(panel_cls)
                except Exception as e:
                    pass
                    # print(f"SUPERTABs Info: Failed to explicitly hide panel '{panel_cls.__name__}': {e}")

    items_from_hidden_groups_data = []
    for group in prefs.tab_groups:
        if group.name in hidden_subgroups_set:
            items = [item.strip() for item in group.items.split(',') if item.strip()]
            for item in items:
                items_from_hidden_groups_data.append((item, group.space_type))

    for item_string, group_space in items_from_hidden_groups_data:
        if item_string in hidden_items_set: continue
        for panel_cls in panels.get_target_panels_for_item(context, item_string, target_space=group_space):
            if not hasattr(panel_cls, 'draw'):
                continue
            if "ZenUV" in panel_cls.__module__ and getattr(panel_cls, 'bl_label', '') in {"System"}:
                continue
            if panel_cls in panels_managed_by_supertabs:
                continue
            
            if not hasattr(panel_cls, 'st_original_category'):
                panel_cls.st_original_category = getattr(panel_cls, 'bl_category', None)
            if not hasattr(panel_cls, 'st_original_parent_id'):
                panel_cls.st_original_parent_id = getattr(panel_cls, 'bl_parent_id', None)
            if not hasattr(panel_cls, 'st_original_poll'):
                panel_cls.st_original_poll = getattr(panel_cls, 'poll', None)
            
            try:
                try: bpy.utils.unregister_class(panel_cls)
                except (RuntimeError, AttributeError): pass
                
                panels.hide_panel(panel_cls)
                
                bpy.utils.register_class(panel_cls)
                
                addon_state.managed_panels[panel_cls.__name__] = {'type': 'MANAGED', 'original_class': panel_cls}
                panels_managed_by_supertabs.add(panel_cls)

            except Exception as e:
                pass
                # print(f"SUPERTABs Info: Failed to explicitly hide panel from subgroup '{panel_cls.__name__}': {e}")

    main_group_structure = defaultdict(lambda: {"__items__": [], "ordered_sub_groups_data": []})
    for i, group in enumerate(prefs.tab_groups):
        if not group.is_visible or group.name in hidden_subgroups_set:
            continue
            
        if not group.name or not group.items: continue
        parts = [p.strip() for p in group.name.split("/") if p.strip()]
        if len(parts) > 1:
            if group.name not in ejected_subgroups_set:
                main_group_structure[parts[0]]["ordered_sub_groups_data"].append((i, parts[1], [item.strip() for item in group.items.split(",") if item.strip()]))
        else:
            main_group_structure[parts[0]]["__items__"].extend([item.strip() for item in group.items.split(",") if item.strip()])

    ordered_main_names = sorted(list(main_group_structure.keys()), key=lambda name: [g.name for g in prefs.tab_groups].index(name) if name in [g.name for g in prefs.tab_groups] else float('inf'))
    
    final_hierarchy = {
        name: {
            "__items__": main_group_structure[name]["__items__"], 
            "ordered_sub_groups": [
                (s_name, items) for _, s_name, items in main_group_structure[name]["ordered_sub_groups_data"]
            ]
        } 
        for name in ordered_main_names
    }

    ejected_count = 0
    for subgroup_full_name in ejected_subgroups_set:
        subgroup_pref_item = next((g for g in prefs.tab_groups if g.name == subgroup_full_name), None)
        if not subgroup_pref_item: continue

        subgroup_name_only = subgroup_full_name.split(' / ', 1)[1]
        items = [item.strip() for item in subgroup_pref_item.items.split(",") if item.strip()]
        
        ejected_hierarchy = {"__items__": items, "ordered_sub_groups": []}
        
        group_state = wm.tab_group_states.add(); group_state.name = subgroup_name_only

        safe_sub_name = sanitize_name(subgroup_name_only).upper()
        controller_name = f"EJECTED_CONTROLLER_PT_{safe_sub_name}"
        ControllerPanel = type(controller_name, (bpy.types.Panel,), {
            "bl_label": f"{subgroup_name_only}", 
            "bl_idname": controller_name, 
            "bl_space_type": "VIEW_3D", 
            "bl_region_type": "UI", 
            "bl_category": subgroup_name_only, 
            "bl_order": -100, 
            "draw": draw.create_ejected_controller_draw_method(subgroup_name_only, ejected_hierarchy),
            "draw_header": draw.create_ejected_controller_header_draw_method()
        })
        try: 
            bpy.utils.register_class(ControllerPanel)
            addon_state.managed_panels[controller_name] = {'type': 'CONTROLLER'}
            panels_managed_by_supertabs.add(ControllerPanel)
            ejected_count += 1
        except Exception as e: 
            print(f"SUPERTABs Info: Failed to register Ejected Controller Panel '{controller_name}': {e}")

        for item_string in items:
            for panel_cls in panels.get_target_panels_for_item(context, item_string):
                if "ZenUV" in panel_cls.__module__ and getattr(panel_cls, 'bl_label', '') in {"System"}:
                    continue
                panels_managed_by_supertabs.add(panel_cls)
                if not hasattr(panel_cls, 'st_original_category'): panel_cls.st_original_category = getattr(panel_cls, 'bl_category', None)
                if not hasattr(panel_cls, 'st_original_poll'): panel_cls.st_original_poll = getattr(panel_cls, 'poll', None)
                
                try:
                    try: bpy.utils.unregister_class(panel_cls)
                    except (RuntimeError, AttributeError): pass
                    
                    panels.show_panel(panel_cls, subgroup_name_only)

                    module_name_lower = panel_cls.__module__.lower()
                    if any(keyword in module_name_lower for keyword in poll_exception_list):
                        panel_cls.poll = panels.create_blenderkit_patch_poll_method(panel_cls.st_original_poll, subgroup_name_only, item_string)
                    else:
                        panel_cls.poll = panels.create_patch_poll_method(panel_cls.st_original_poll, subgroup_name_only, item_string)

                    bpy.utils.register_class(panel_cls)
                    addon_state.managed_panels[panel_cls.__name__] = {'type': 'MANAGED', 'original_class': panel_cls}
                except Exception as e:
                    pass
                    # print(f"SUPERTABs Info: Failed to process panel for ejected subgroup '{panel_cls.__name__}': {e}")

    normal_count = 0
    for main_group_name, data in final_hierarchy.items():
        group_state = wm.tab_group_states.add(); group_state.name = main_group_name
        
        current_saved_state = saved_states.get(main_group_name, {})
        imported_expansion_dict = panel_expansion_data.get(main_group_name) if panel_expansion_data is not None else None

        imported_state_data = pinned_states_data.get(main_group_name) if pinned_states_data is not None else None
        current_active_item = current_saved_state.get("active_item", "")
        current_pinned_items = current_saved_state.get("pinned_items", "")

        if isinstance(imported_state_data, dict):
            group_state.active_item = imported_state_data.get("active_item", "")
            group_state.pinned_items = imported_state_data.get("pinned_items", "")
        elif isinstance(imported_state_data, str):
            group_state.active_item = ""
            group_state.pinned_items = imported_state_data
        else:
            group_state.active_item = current_active_item
            group_state.pinned_items = current_pinned_items
        
        main_group_pref = next((g for g in prefs.tab_groups if g.name == main_group_name), None)
        current_space_type = main_group_pref.space_type if main_group_pref else 'VIEW_3D'
        if current_space_type == 'VIEW_3D':
            current_exclude_set = excluded_by_toggle_3d
        elif current_space_type == 'IMAGE_EDITOR':
            current_exclude_set = excluded_by_toggle_uv
        else: # NODE_EDITOR
            current_exclude_set = excluded_by_toggle_node

        imported_layout = column_layout_data.get(main_group_name) if column_layout_data else None
        if imported_layout:
            group_state.subgroup_columns = imported_layout.get("subgroup_columns", 4)
            group_state.item_columns = imported_layout.get("item_columns", 4)
            group_state.subgroup_column_data.clear()
            for sub_name, sub_cols in imported_layout.get("subgroup_specific_columns", {}).items():
                new_sub_data = group_state.subgroup_column_data.add()
                new_sub_data.name = sub_name
                new_sub_data.item_columns = sub_cols

        else:
            group_state.subgroup_columns = current_saved_state.get("subgroup_columns", 4)
            group_state.item_columns = current_saved_state.get("item_columns", 4)
            group_state.subgroup_column_data.clear()
            for sub_name, sub_cols in current_saved_state.get("subgroup_column_data", {}).items():
                new_sub_data = group_state.subgroup_column_data.add()
                new_sub_data.name = sub_name
                new_sub_data.item_columns = sub_cols
        
        imported_preset_group_data = favorite_preset_data.get(main_group_name) if favorite_preset_data else None

        if imported_preset_group_data:
            group_state.favorite_presets.clear()
            
            all_preset_names_in_import = {p.get("name") for p in imported_preset_group_data.get("presets", []) if p.get("name")}
            
            for preset_item_data in imported_preset_group_data.get("presets", []):
                preset_name = preset_item_data.get("name", "")
                if not preset_name: continue

                preset_items = preset_item_data.get("items", "")
                preset_owner_group = preset_item_data.get("main_group_name", main_group_name)
                master_preset = next((p for p in prefs.custom_favorite_presets if p.name == preset_name and p.main_group_name == preset_owner_group), None)
                if not master_preset:
                    master_preset = prefs.custom_favorite_presets.add()
                    master_preset.name = preset_name
                    master_preset.icon = preset_item_data.get("icon", "NODE_SOCKET_FLOAT")
                    master_preset.main_group_name = preset_owner_group
                    master_preset.space_type = preset_item_data.get("space_type", 'VIEW_3D')
                master_preset.items = preset_items 

                new_content_preset = group_state.favorite_presets.add()
                new_content_preset.name = preset_name
                new_content_preset.items = preset_items 

            active_preset_name = imported_preset_group_data.get("active_preset", "Preset 1")
            group_state.active_favorite_preset_name = active_preset_name if active_preset_name in all_preset_names_in_import else (list(all_preset_names_in_import)[0] if all_preset_names_in_import else "")

        else:
            relevant_presets = [
                p for p in prefs.custom_favorite_presets 
                if p.main_group_name == main_group_name
            ]

            valid_preset_names = {p.name for p in relevant_presets}
            
            active_preset_name = current_saved_state.get("active_favorite_preset_name", "Preset 1")
            if active_preset_name in valid_preset_names:
                group_state.active_favorite_preset_name = active_preset_name
            elif valid_preset_names:
                group_state.active_favorite_preset_name = list(valid_preset_names)[0]
            else:
                group_state.active_favorite_preset_name = ""

            group_state.favorite_presets.clear()

            for master_preset in relevant_presets:
                new_preset_in_state = group_state.favorite_presets.add()
                new_preset_in_state.name = master_preset.name
                new_preset_in_state.items = master_preset.items

        group_state.favorite_item_columns = current_saved_state.get("favorite_item_columns", 1)
        if imported_expansion_dict:
            group_state.show_favorites_panel = imported_expansion_dict.get("show_favorites_panel", False)
            group_state.show_groupaddons_panel = imported_expansion_dict.get("show_groupaddons_panel", True)
            group_state.show_windoweditor_panel = imported_expansion_dict.get("show_windoweditor_panel", False)
            group_state.panel_manager = imported_expansion_dict.get("panel_manager", True)
            group_state.show_subgroup_icons = imported_expansion_dict.get("show_subgroup_icons", True)
            group_state.show_favorite_icons = imported_expansion_dict.get("show_favorite_icons", True)
        else:
            if main_group_pref:
                group_state.show_favorites_panel = main_group_pref.show_favorites_panel
                group_state.show_groupaddons_panel = main_group_pref.show_groupaddons_panel
                group_state.show_windoweditor_panel = main_group_pref.show_windoweditor_panel
                group_state.panel_manager = main_group_pref.panel_manager
                group_state.show_subgroup_icons = getattr(main_group_pref, "show_subgroup_icons", True)
                group_state.show_favorite_icons = getattr(main_group_pref, "show_favorite_icons", True)
            else:
                group_state.show_favorites_panel = current_saved_state.get("show_favorites_panel", False)
                group_state.show_groupaddons_panel = current_saved_state.get("show_groupaddons_panel", True)
                group_state.show_windoweditor_panel = current_saved_state.get("show_windoweditor_panel", False)
                group_state.panel_manager = current_saved_state.get("panel_manager", True)
                group_state.show_subgroup_icons = current_saved_state.get("show_subgroup_icons", True)
                group_state.show_favorite_icons = current_saved_state.get("show_favorite_icons", True)

        all_items_in_group = data["__items__"] + [item for _, items in data["ordered_sub_groups"] for item in items]
        all_items_in_group = data["__items__"] + [item for _, items in data["ordered_sub_groups"] for item in items]

        safe_main_name = sanitize_name(main_group_name).upper()
        controller_name = f"MAIN_CONTROLLER_PT_{safe_main_name}"
        ControllerPanel = type(controller_name, (bpy.types.Panel,), {
            "bl_label": f"{main_group_name}", 
            "bl_idname": controller_name, 
            "bl_space_type": current_space_type,
            "bl_region_type": "UI", 
            "bl_category": main_group_name, 
            "bl_order": -100, 
            "draw": draw.create_controller_draw_method(main_group_name, data, ejected_items_set, hidden_items_set, ejected_subgroups_set, hidden_subgroups_set),
            "draw_header": draw.create_controller_header_draw_method()
        })
        try: 
            bpy.utils.register_class(ControllerPanel)
            addon_state.managed_panels[controller_name] = {'type': 'CONTROLLER'}
            panels_managed_by_supertabs.add(ControllerPanel)
            normal_count += 1
        except Exception as e: 
            print(f"SUPERTABs Info: Failed to register Controller Panel '{controller_name}': {e}")
        
        for item_string in all_items_in_group:
            try:
                item_type, item_name = item_string.split(':', 1)
                if item_type == 'tab' and item_name in current_exclude_set: continue
            except ValueError: continue
            if item_string in ejected_items_set or item_string in hidden_items_set: continue

            for panel_cls in panels.get_target_panels_for_item(context, item_string, target_space=current_space_type):
                if panel_cls.__name__.startswith("_Abstract_") or panel_cls.__name__ == "AC_PT_MainPanel":
                    continue
                if panel_cls in panels_managed_by_supertabs:
                    try:
                        safe_main_name = sanitize_name(main_group_name).upper()
                        safe_space = sanitize_name(current_space_type).upper()
                        proxy_idname = f"ST_PROXY_{panel_cls.__name__}_{safe_main_name}_{safe_space}"
                        if len(proxy_idname) > 60: proxy_idname = proxy_idname[:60]

                        ProxyPanel = type(proxy_idname, (panel_cls,), {
                            "bl_idname": proxy_idname,
                            "bl_category": main_group_name,
                            "bl_space_type": current_space_type,
                            "bl_region_type": "UI",
                            "bl_parent_id": None,
                            "bl_order": getattr(panel_cls, 'bl_order', 0),
                        })

                        original_poll = getattr(panel_cls, 'st_original_poll', getattr(panel_cls, 'poll', None))
                        module_name_lower = panel_cls.__module__.lower()
                        if any(keyword in module_name_lower for keyword in poll_exception_list):
                            ProxyPanel.poll = panels.create_blenderkit_patch_poll_method(original_poll, main_group_name, item_string)
                        else:
                            ProxyPanel.poll = panels.create_patch_poll_method(original_poll, main_group_name, item_string)

                        bpy.utils.register_class(ProxyPanel)
                        addon_state.managed_panels[proxy_idname] = {'type': 'CONTROLLER'}
                    except Exception as e:
                        print(f"SUPERTABs Info: Proxy creation failed for {panel_cls.__name__}: {e}")
                    
                    continue
                panel_id = getattr(panel_cls, 'bl_idname', panel_cls.__name__)
                if panel_id in hidden_panel_ids_set:
                    if panel_cls in panels_managed_by_supertabs: continue
                    if not hasattr(panel_cls, 'st_original_category'): panel_cls.st_original_category = getattr(panel_cls, 'bl_category', None)
                    if not hasattr(panel_cls, 'st_original_parent_id'): panel_cls.st_original_parent_id = getattr(panel_cls, 'bl_parent_id', None)
                    if not hasattr(panel_cls, 'st_original_poll'): panel_cls.st_original_poll = getattr(panel_cls, 'poll', None)
                    
                    try:
                        try: bpy.utils.unregister_class(panel_cls)
                        except (RuntimeError, AttributeError): pass
                        
                        panels.hide_panel(panel_cls)
                        
                        bpy.utils.register_class(panel_cls)
                        
                        addon_state.managed_panels[panel_cls.__name__] = {'type': 'MANAGED', 'original_class': panel_cls}
                        panels_managed_by_supertabs.add(panel_cls)
                    except Exception as e:
                        pass
                        
                    continue
                if not hasattr(panel_cls, 'draw'):
                    # print(f"SUPERTABs Info: Skipping panel '{panel_cls.__name__}' because it lacks a 'draw' method. This is an issue in the source addon.")
                    continue 
                if "ZenUV" in panel_cls.__module__ and getattr(panel_cls, 'bl_label', '') in {"System"}: continue
                panels_managed_by_supertabs.add(panel_cls)
                if not hasattr(panel_cls, 'st_original_category'): panel_cls.st_original_category = getattr(panel_cls, 'bl_category', None)
                if not hasattr(panel_cls, 'st_original_poll'): panel_cls.st_original_poll = getattr(panel_cls, 'poll', None)
                
                try:
                    try: bpy.utils.unregister_class(panel_cls)
                    except (RuntimeError, AttributeError): pass
                    
                    panels.show_panel(panel_cls, main_group_name)

                    module_name_lower = panel_cls.__module__.lower()
                    if any(keyword in module_name_lower for keyword in poll_exception_list):
                        panel_cls.poll = panels.create_blenderkit_patch_poll_method(panel_cls.st_original_poll, main_group_name, item_string)
                    else:
                        panel_cls.poll = panels.create_patch_poll_method(panel_cls.st_original_poll, main_group_name, item_string)

                    bpy.utils.register_class(panel_cls)
                    addon_state.managed_panels[panel_cls.__name__] = {'type': 'MANAGED', 'original_class': panel_cls}
                except Exception as e:
                    pass
                    # print(f"SUPERTABs Info: Failed to process panel '{panel_cls.__name__}': {e}")

    all_3d_view_panels_current = [p for p in bpy.types.Panel.__subclasses__() if hasattr(p, 'bl_rna') and getattr(p, 'bl_space_type', None) == 'VIEW_3D' and getattr(p, 'bl_region_type', None) == 'UI']
    for panel_cls in all_3d_view_panels_current:
        if panel_cls in panels_managed_by_supertabs: continue

        if "ZenUV" in panel_cls.__module__ and getattr(panel_cls, 'bl_label', '') in {"System"}:
            try:
                if not hasattr(panel_cls, 'st_original_category'): panel_cls.st_original_category = getattr(panel_cls, 'bl_category', None)
                if not hasattr(panel_cls, 'st_original_parent_id'): panel_cls.st_original_parent_id = getattr(panel_cls, 'bl_parent_id', None)
                try: bpy.utils.unregister_class(panel_cls)
                except (RuntimeError, AttributeError): pass
                
                panels.hide_panel(panel_cls)
                panel_cls.bl_category = "ST_HIDDEN"
                
                bpy.utils.register_class(panel_cls)
                
                addon_state.managed_panels[panel_cls.__name__] = {'type': 'MANAGED', 'original_class': panel_cls}
            except Exception as e:
                pass
            continue

        original_category = getattr(panel_cls, 'bl_category', '')
        if original_category == "Misc":
            try:
                if not hasattr(panel_cls, 'st_original_category'): panel_cls.st_original_category = getattr(panel_cls, 'bl_category', None)
                if not hasattr(panel_cls, 'st_original_parent_id'): panel_cls.st_original_parent_id = getattr(panel_cls, 'bl_parent_id', None)
                try: bpy.utils.unregister_class(panel_cls)
                except (RuntimeError, AttributeError): pass
                
                panels.hide_panel(panel_cls)
                panel_cls.bl_category = "ST_HIDDEN"
                
                bpy.utils.register_class(panel_cls)
                
                addon_state.managed_panels[panel_cls.__name__] = {'type': 'MANAGED', 'original_class': panel_cls}
            except Exception as e:
                pass
                # print(f"SUPERTABs Info: Failed to hide Misc panel '{panel_cls.__name__}': {e}")

    if ordered_main_names:
        valid_group_names = set(ordered_main_names)
        current_last_active = getattr(wm, "st_last_active_main_group", "")
        if not current_last_active or current_last_active not in valid_group_names:
            wm.st_last_active_main_group = ordered_main_names[0]

    message = f"Applied settings. Created {normal_count} SuperTab(s) and {ejected_count} Ejected Subgroup-Tab(s)."
    if operator: 
        operator.report({"INFO"}, message)
    bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='SUCCESS')