import bpy
from bpy.app.handlers import persistent
import os
from .. import state as addon_state, keymap
from ..utils import trigger_redraw
from . import core_io 


def status_countdown_timer():
    """
    Timer function that counts down to hide the status message.
    It runs every 0.1 seconds.
    """
    try:
        package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
        prefs = bpy.context.preferences.addons[package_name].preferences
        if prefs.status_timer > 0:
            prefs.status_timer -= 1
            return 0.1 
        else:
            prefs.status_message = ""
            prefs.status_type = 'NONE'
            trigger_redraw(None, bpy.context) 
            addon_state.status_timer = None 
            return None
    except (AttributeError, KeyError):
        addon_state.status_timer = None
        return None

def auto_import_timer():
    """Timer function that executes the auto-import logic directly."""
    print("SUPERTABs: Auto-import timer fired.")
    package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
    prefs = bpy.context.preferences.addons[package_name].preferences
    
    core_io.execute_import_from_file(bpy.context, prefs.auto_import_filepath, apply_settings_now=True)
    
    return None

def keymap_register_timer():
    """Timer function to register the keymap after a delay."""
    keymap.register()
    return None

@persistent
def auto_import_handler(dummy):
    """
    This persistent handler runs after a .blend file is loaded.
    It checks if the auto-import timer needs to be registered.
    """    
    package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
    try:
        prefs = bpy.context.preferences.addons[package_name].preferences
        if prefs.auto_import_enabled and prefs.auto_import_filepath and os.path.exists(prefs.auto_import_filepath):
            if not bpy.app.timers.is_registered(auto_import_timer):
                #print("SUPERTABs: Auto-import enabled, registering timer.")
                bpy.app.timers.register(auto_import_timer, first_interval=max(0.1, prefs.auto_import_delay))
        else:
            if bpy.app.timers.is_registered(auto_import_timer):
                #print("SUPERTABs: Auto-import disabled, unregistering timer.")
                bpy.app.timers.unregister(auto_import_timer)
    except (KeyError, AttributeError):
        pass

def register_handlers():
    if auto_import_handler not in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.append(auto_import_handler)
        
    def initial_check():
        auto_import_handler(None)
        prefs = bpy.context.preferences.addons[__package__.split('.')[0]].preferences
        if not bpy.app.timers.is_registered(keymap_register_timer):
            bpy.app.timers.register(keymap_register_timer, first_interval=prefs.keymap_registration_delay)
        return None
        
    bpy.app.timers.register(initial_check, first_interval=0.1)

def unregister_handlers():
    if auto_import_handler in bpy.app.handlers.load_post:
        bpy.app.handlers.load_post.remove(auto_import_handler)
    
    if bpy.app.timers.is_registered(auto_import_timer):
        bpy.app.timers.unregister(auto_import_timer)
        
    if bpy.app.timers.is_registered(keymap_register_timer):
        bpy.app.timers.unregister(keymap_register_timer)

    if addon_state.status_timer and bpy.app.timers.is_registered(status_countdown_timer):
        bpy.app.timers.unregister(status_countdown_timer)
        addon_state.status_timer = None