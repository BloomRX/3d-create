# -*- coding: utf-8 -*-

bl_info = {
    "name": "SUPERTABs",
    "author": "DohDeh",
    "version": (1, 3, 0,), # Officail-Release Version
    "blender": (4, 2, 0),
    "location": "3D View > Sidebar (N-Panel) & Topbar > Add-on Manager & Hotkey",
    "description": "Organizes the Sidebar with a tab system and provides a hotkey-accessible Add-on Manager.",
    "warning": "This addon dynamically modifies the UI. A restart may be needed to fully restore UI on disabling.",
    "doc_url": "",
    "category": "Development",
}

import bpy
from . import ui, properties, operators, core, keymap, rightclick

# --- Register and Unregister ---

classes = (
    *properties.classes,
    *ui.classes,
    *operators.classes,
    *rightclick.classes,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    properties.register()
    
    prefs = bpy.context.preferences.addons[__package__].preferences
    if prefs:
        rightclick.register_context_menus(prefs)
    else:
        print("SUPERTABs Warning: Could not load preferences for context menus.")
    
    core.register()
    
    ui.register()
    keymap.register()
    
def unregister():

    rightclick.unregister_context_menus()
    keymap.unregister()
    ui.unregister() 
    properties.unregister()
    core.unregister()

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass
