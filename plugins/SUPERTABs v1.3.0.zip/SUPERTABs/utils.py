# -*- coding: utf-8 -*-

import bpy
import addon_utils
import re
import bmesh
from mathutils import Vector

# A set of default Blender tab names that should not be used for SUPERTABs groups
# to avoid conflicts, especially with the 'Eject Subgroup' feature.
RESERVED_TAB_NAMES = {
    "Item", "Tool", "View", "Options", "Node", "Group", "Scope"
}

# "Create", "Misc","Render", "Output", "View Layer",
# "Scene", "World","Physics", "Constraints", "Data",
# "Collections"

def get_all_addons():
    """
    Creates a list of all addons with necessary information.
    """
    items = []
    package_name = __package__

    for module in addon_utils.modules():
        name = module.__name__
        if name == package_name:
            continue
        display = module.bl_info.get("name", name)
        items.append({'mod_name': name, 'display_name': display, 'module_obj': module})
    return sorted(items, key=lambda x: x['display_name'].lower())

def trigger_redraw(self, context):
    """
    This function forces a redraw of all areas to ensure UI updates immediately.
    """
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            area.tag_redraw()

def sanitize_name(name):
    """
    Sanitizes a string to be used as a class name.
    """
    return re.sub(r"\W|^(?=\d)", "_", name)

def check_keymap_conflict(context, key, ctrl, alt, shift):
    """
    Checks for conflicts in both default and addon keymaps.
    Returns the idname of the conflicting operator or an empty string.
    """
    wm = context.window_manager
    
    self_registered_idnames = {
        "st.open_supertabs_manager",
        "st.toggle_asset_browser",
        "view3d.manage_areas",
        "wm.call_menu_pie"
    }

    keymaps_to_check = []
    if wm.keyconfigs.default:
        keymaps_to_check.extend(wm.keyconfigs.default.keymaps)
    if wm.keyconfigs.addon:
        keymaps_to_check.extend(wm.keyconfigs.addon.keymaps)

    for km in keymaps_to_check:
        for kmi in km.keymap_items:
            if kmi.idname in self_registered_idnames:
                continue
            if (kmi.type == key and 
                kmi.ctrl == ctrl and 
                kmi.alt == alt and 
                kmi.shift == shift and 
                kmi.active):
                return kmi.idname
                
    return ""

def get_all_subclasses(cls):
    """
    Function to recursively find all subclasses of the given class.
    Returns a list of all descendant classes.
    """
    all_subclasses = []
    for subclass in cls.__subclasses__():
        all_subclasses.append(subclass)
        all_subclasses.extend(get_all_subclasses(subclass))
    return all_subclasses


def get_proxy_dimensions(self):
    """
    Getter for the proxy dimensions property. 
    Returns the Local Dimensions (aligned to object) derived from Bounding Box.
    """
    obj = bpy.context.object
    if not obj:
        return (0.0, 0.0, 0.0)

    if obj.type in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'} and obj.bound_box:
        bbox = [Vector(v) for v in obj.bound_box]
        
        x_len = max(v[0] for v in bbox) - min(v[0] for v in bbox)
        y_len = max(v[1] for v in bbox) - min(v[1] for v in bbox)
        z_len = max(v[2] for v in bbox) - min(v[2] for v in bbox)
        
        return Vector((x_len * abs(obj.scale[0]), 
                       y_len * abs(obj.scale[1]), 
                       z_len * abs(obj.scale[2])))

    return obj.dimensions

def set_proxy_dimensions(self, value):
    """
    Setter for the proxy dimensions property.
    Calculates scale based on Target Value / Unscaled Data Size.
    This ensures exact values when typing directly.
    """
    obj = bpy.context.object
    if not obj:
        return

    target_dims = Vector(value)
    new_scale = Vector(obj.scale)

    if obj.type in {'MESH', 'CURVE', 'SURFACE', 'FONT', 'META'} and obj.bound_box:
        bbox = [Vector(v) for v in obj.bound_box]
        
        dims_unscaled = Vector((
            max(v[0] for v in bbox) - min(v[0] for v in bbox),
            max(v[1] for v in bbox) - min(v[1] for v in bbox),
            max(v[2] for v in bbox) - min(v[2] for v in bbox)
        ))

        for i in range(3):
            if dims_unscaled[i] != 0:
                sign = 1 if obj.scale[i] >= 0 else -1
                new_scale[i] = (target_dims[i] / dims_unscaled[i]) * sign
            else:
                new_scale[i] = obj.scale[i]

    else:
        current_dims = obj.dimensions
        for i in range(3):
            if current_dims[i] != 0:
                scale_factor = target_dims[i] / abs(current_dims[i])
                new_scale[i] = obj.scale[i] * scale_factor 
    obj.scale = new_scale

def get_selected_curve_points(context):
    """Helper to get all selected points/control points from any spline type."""
    obj = context.edit_object
    if not obj or obj.type != 'CURVE':
        return []

    selected_points = []
    for spline in obj.data.splines:
        if spline.type == 'BEZIER':
            for bp in spline.bezier_points:
                if bp.select_control_point:
                    selected_points.append(bp)
        elif spline.type in ('POLY', 'NURBS'):
            for p in spline.points:
                if p.select:
                    selected_points.append(p)
    return selected_points

def get_mean_curve_attribute(context, attr_name):
    """Generic function to get the mean value of an attribute from selected curve points."""
    selected_points = get_selected_curve_points(context)
    if not selected_points:
        return 0.0

    total_value = 0
    count = 0
    for p in selected_points:
        if hasattr(p, attr_name):
            total_value += getattr(p, attr_name)
            count += 1

    return total_value / count if count > 0 else 0.0

def set_mean_curve_attribute(context, attr_name, value):
    """Generic function to set a value to an attribute for selected curve points."""
    selected_points = get_selected_curve_points(context)
    if not selected_points:
        return

    for p in selected_points:
        if hasattr(p, attr_name):
            setattr(p, attr_name, value)

    obj = context.edit_object
    if obj:
        obj.data.update()

def get_curve_weight(self): return get_mean_curve_attribute(bpy.context, 'weight_softbody')
def set_curve_weight(self, value): set_mean_curve_attribute(bpy.context, 'weight_softbody', value)

def get_curve_radius(self): return get_mean_curve_attribute(bpy.context, 'radius')
def set_curve_radius(self, value): set_mean_curve_attribute(bpy.context, 'radius', value)

def get_curve_tilt(self): return get_mean_curve_attribute(bpy.context, 'tilt')
def set_curve_tilt(self, value): set_mean_curve_attribute(bpy.context, 'tilt', value)

def get_median_curve_vector(self):
    obj = bpy.context.edit_object
    if not obj or bpy.context.mode != 'EDIT_MESH' and obj.type != 'CURVE':
         return self.get("curve_median_vector", (0, 0, 0))

    selected_points = get_selected_curve_points(bpy.context)
    if not selected_points:
        return self.get("curve_median_vector", (0, 0, 0))

    median_local = sum((p.co for p in selected_points), Vector()) / len(selected_points)

    if self.space_mode == 'GLOBAL':
        return obj.matrix_world @ median_local
    else:
        return median_local

def set_median_curve_vector(self, value):
    obj = bpy.context.edit_object
    if not obj: return

    selected_points = get_selected_curve_points(bpy.context)
    if not selected_points: return

    current_median_local = sum((p.co for p in selected_points), Vector()) / len(selected_points)

    target_median_global = Vector(value)

    if self.space_mode == 'GLOBAL':
        target_median_local = obj.matrix_world.inverted() @ target_median_global
    else:
        target_median_local = target_median_global

    translation_local = target_median_local - current_median_local

    for p in selected_points:
        p.co += translation_local
        if hasattr(p, 'handle_left'):
            p.handle_left += translation_local
            p.handle_right += translation_local

    obj.data.update()

# --- BMesh Data Functions ---
def get_layer_value(context, element_type, layer_name):
    """Generic function to get the mean value from a bmesh data layer."""
    obj = context.edit_object
    if not obj or context.mode != 'EDIT_MESH': return 0.0
    bm = bmesh.from_edit_mesh(obj.data)
    elements = getattr(bm, element_type)
    layer = elements.layers.float.get(layer_name)
    if not layer: return 0.0
    selected = [e for e in elements if e.select]
    if not selected: return 0.0
    total_value = sum(e[layer] for e in selected)
    return total_value / len(selected)

def set_layer_value(context, value, element_type, layer_name):
    """Generic function to set a value to a bmesh data layer for selected elements."""
    obj = context.edit_object
    if not obj: return
    bm = bmesh.from_edit_mesh(obj.data)
    elements = getattr(bm, element_type)
    layer = elements.layers.float.get(layer_name)
    if not layer:
        layer = elements.layers.float.new(layer_name)
    selected = [e for e in elements if e.select]
    if not selected: return
    for e in selected:
        e[layer] = value

    bmesh.update_edit_mesh(obj.data)

def get_median_vector(self):
    obj = bpy.context.edit_object
    if not obj or bpy.context.mode != 'EDIT_MESH': return self.get("median_vector", (0, 0, 0))
    bm = bmesh.from_edit_mesh(obj.data)
    selected_verts = [v for v in bm.verts if v.select]
    if not selected_verts: return self.get("median_vector", (0, 0, 0))
    median_local = sum((v.co for v in selected_verts), Vector()) / len(selected_verts)
    if self.space_mode == 'GLOBAL':
        return obj.matrix_world @ median_local
    else:
        return median_local

def set_median_vector(self, value):
    self["median_vector"] = value
    obj = bpy.context.edit_object
    if not obj: return
    bm = bmesh.from_edit_mesh(obj.data)
    selected_verts = [v for v in bm.verts if v.select]
    if not selected_verts: return
    current_median_local = sum((v.co for v in selected_verts), Vector()) / len(selected_verts)
    target_median_global = Vector(value)
    if self.space_mode == 'GLOBAL':
        target_median_local = obj.matrix_world.inverted() @ target_median_global
    else:
        target_median_local = target_median_global
    translation_local = target_median_local - current_median_local
    for v in selected_verts:
        v.co += translation_local
    bmesh.update_edit_mesh(obj.data)

def get_vert_bevel(self): return get_layer_value(bpy.context, 'verts', 'bevel_weight_vert')
def set_vert_bevel(self, value): set_layer_value(bpy.context, value, 'verts', 'bevel_weight_vert')
def get_vert_crease(self): return get_layer_value(bpy.context, 'verts', 'crease_vert')
def set_vert_crease(self, value): set_layer_value(bpy.context, value, 'verts', 'crease_vert')
def get_edge_bevel(self): return get_layer_value(bpy.context, 'edges', 'bevel_weight_edge')
def set_edge_bevel(self, value): set_layer_value(bpy.context, value, 'edges', 'bevel_weight_edge')
def get_edge_crease(self): return get_layer_value(bpy.context, 'edges', 'crease_edge')
def set_edge_crease(self, value): set_layer_value(bpy.context, value, 'edges', 'crease_edge')

def get_vert_data_vector(self): return (get_vert_bevel(self), get_vert_crease(self))
def set_vert_data_vector(self, value): set_vert_bevel(self, value[0]); set_vert_crease(self, value[1])
def get_edge_data_vector(self): return (get_edge_bevel(self), get_edge_crease(self))
def set_edge_data_vector(self, value): set_edge_bevel(self, value[0]); set_edge_crease(self, value[1])
