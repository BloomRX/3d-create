import bpy

DOC_LINKS = [
    ("SUPERTABs Main Documents", "https://www.notion.so/SUPERTABs-Documents-ENG-270b1f0a83538079852bc0077fd71c24"),
    ("Poll Exception Guide", "https://www.notion.so/SUPERTABs-Poll-Exception-feature-Guide-Preferences-2a3b1f0a835380c0b367f098604348b0?source=copy_link"),
    ("Tab Group Management Guide", "https://www.notion.so/SUPERTABs-TAB-GROUP-Management-Guide-Preferences-v1-3-0-REMAKE-29cb1f0a83538185963ec56139a38c99?source=copy_link"),
    ("Import / Export & Settings Guide", "https://www.notion.so/SUPERTABs-Import-Export-Settings-Guide-Preferences-v1-3-0-29cb1f0a8353809dbb50e3b00b4963b1?source=copy_link"),
    ("Add-ons Recovery Guide", "https://www.notion.so/SUPERTABs-Add-ons-Recovery-Guide-Preferences-v1-3-0-NEW-2e5b1f0a835380b9a61de408c02192be?source=copy_link"),
    ("SUPERTABs Settings Guide", "https://www.notion.so/SUPERTABs-SUPERTABs-Settings-Guide-Preferences-v1-3-0-REMAKE-2eab1f0a83538058ae72dcd0b208a51a?source=copy_link"),
    ("Groups & Add-on Section Guide", "https://www.notion.so/SUPERTABs-Groups-Add-on-Section-N-Panel-v1-3-0-29cb1f0a835380c6a4ecd8a2de18dd10?source=copy_link"),
    ("Sub-tabs Management Guide", "https://www.notion.so/SUPERTABs-Subtabs-Management-Guide-Preferences-v1-2-0-2b7b1f0a8353801292bdc0c2d6df3400?source=copy_link"),
    ("Favorite Tabs Preset Guide", "https://www.notion.so/SUPERTABs-Favorite-Tab-Preset-Guide-N-Panel-v1-3-0-29cb1f0a835380469d1bc23587b6b679?source=copy_link"),
    ("Tools Header Guide", "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"),
    ("N-Panel Display Settings Guide", "https://www.notion.so/SUPERTABs-N-Panel-Display-Settings-Guide-N-Panel-v1-3-0-REMAKE-2eab1f0a8353800ca3ccddcf179021bf?source=copy_link"),
    ("Window Editor Guide", "https://www.notion.so/SUPERTABs-Window-Editor-Guide-N-Panel-WIP-29bb1f0a835380b9b9cbff4e8ae5f46a?source=copy_link"),
    ("Addons Manager Guide", "https://www.notion.so/SUPERTABs-Add-ons-Manager-Guide-Popover-v1-3-0-2a1b1f0a8353800aaedae961214e8604?source=copy_link"),
    ("Quick Menu Integration Guide", "https://www.notion.so/SUPERTABs-Quick-Menu-Integration-Guide-296b1f0a8353800aafd9e8f05c5ec78d?source=copy_link"),
    ("Quick Shortcuts Guide", "https://www.notion.so/SUPERTABs-Quick-Shortcuts-Guide-Right-Click-Pie-Menu-v1-1-3-2acb1f0a835380f280d4dceed2bc6567?source=copy_link"),
    ("Favorite Nodes Guide", "https://www.notion.so/SUPERTABs-Favorite-Nodes-Guide-N-Panel-NODE-EDITORS-v1-3-0-NEW-2d1b1f0a835380c89b62de02c7675a96?source=copy_link"),
    ("Tab-Group Icon Guide", "https://www.notion.so/SUPERTABs-Tab-Group-Icon-Guide-Preferences-v1-3-0-NEW-2d0b1f0a835380f5826de8b7b0d8e8de?source=copy_link"),
    ("Collapse All Feature Guide", "https://www.notion.so/SUPERTABs-Collapse-All-Feature-Guide-N-Panel-v1-3-0-NEW-2efb1f0a83538075842fce472e503559?source=copy_link"),
    ("Hide & Eject in Groups & Addons Guide", "https://www.notion.so/SUPERTABs-Hide-Eject-in-Groups-Addons-N-Panel-296b1f0a83538077bcb9dd26bf14d138?source=copy_link"),
    ("Split & Join View Hotkey", "https://www.notion.so/SUPERTABs-Split-Join-View-Hotkey-v1-0-0-2a1b1f0a83538042b046fbbf49f9b16f?source=copy_link"),
]

def draw_info_section(layout, prefs, context):
    box_tabs = layout.box()
    row_tabs = box_tabs.row(align=True)
    if prefs.show_info:
        row_tabs.prop(prefs, "info_section_tab", expand=True)
    row_tabs.separator(factor=0.75)
    row_tabs.prop(prefs, "show_info", text="" if prefs.show_info else "SUPERTABs Info", icon='DOWNARROW_HLT' if prefs.show_info else 'RIGHTARROW', toggle=True, emboss=False)
    if prefs.show_info:
        info_box = layout.box()
        if prefs.info_section_tab == 'WARNING':
            warning_col = info_box.column(align=True)
            warning_col.alert = True 
            warning_col.label(text="NOTIFICATION WARNINGS", icon='WARNING_LARGE')
            warning_col.separator()
            # Text
            warning_col.label(text="• SUPERTABs uses the registers of any Add-ons listed below.")
            warning_col.label(text="• Please remove the tab from the group or press Reset UI before disabling/uninstalling Add-ons.")
            warning_col.label(text="• Restart Blender after updating to reset Panel UI registers.")
            warning_col.label(text="• Adding Tool-Blender Main Tab(3Dview) to a Group will hide the Tool Panel in Properties editor.")

        elif prefs.info_section_tab == 'ANNOUNCEMENT':

            anno_col = info_box.column(align=True)

            # Header
            row_head = anno_col.row()
            row_head.label(text="Check What's New in This Version > (1.3.0)", icon='INFO')
            
            col_alert = anno_col.column()
            col_alert.alert = True
            col_alert.label(text="• Supertabs v1.3.0 includes a new file structure — uninstall the old version before installing to avoid errors.")

            # LINK
            scale_row = row_head.row()
            scale_row.scale_x = 0.35
            op = scale_row.operator("wm.url_open", text="Full Changelog", icon='URL')
            op.url = "https://www.notion.so/SUPERTABs-v1-3-0-Released-Log-Released-30cb1f0a83538031a976cf6dc4b540d8?source=copy_link"
            anno_col.separator()

            # --- 1. Node Editor Section ---
            box_node = anno_col.box()
            col_node = box_node.column(align=True)

            # Text
            row_node = col_node.row(align=True)
            row_alert = row_node.row()
            row_alert.alert = True
            row_alert.label(text="SUPERTABs Node Editors Supported", icon='NODETREE')
            row_node.prop(prefs, "show_info_node", text="", icon='DOWNARROW_HLT' if prefs.show_info_node else 'RIGHTARROW', toggle=True, emboss=False)
            if prefs.show_info_node:
                col_node.separator()
                col_node.label(text="SUPERTABs are now available in all Node Editors.", icon='RIGHTARROW_THIN')
                col_node.label(text="Supported: Shading, Geometry, Texture, Compositor", icon='RIGHTARROW_THIN')
                col_node.separator()
            
                # Utility Tools List
                box_node = col_node.box()
                col_node = box_node.column(align=True)
                row_node = col_node.row(align=True)
                row_alert = row_node.row()
                row_alert.alert = True
                row_alert.label(text="SUPERTABs Tools Header in Node Editors:", icon='PINNED')
                guide_row = row_node.row()
                guide_row.scale_x = 0.3
                op = guide_row.operator("wm.url_open", text="See Guide", icon='QUESTION', emboss=True)
                op.url = "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"
                col_node.separator()
                col_node.label(text="Node Statistic & Arrange Nodes", icon='RIGHTARROW_THIN')
                col_node.label(text="Zoom In/Out/Focus & View Home Buttons", icon='RIGHTARROW_THIN')
                col_node.label(text="Annotations (Specific for Node Editors)", icon='RIGHTARROW_THIN')
                col_node.label(text="Geometry Node Overlay (Timing, Name Attributes)", icon='RIGHTARROW_THIN')
                col_node.label(text="Favorite Nodes (Support Node & Node Groups)", icon='RIGHTARROW_THIN')

            # --- 2. Image & UV Editor Section ---
            box_img = anno_col.box()
            col_img = box_img.column(align=True)
            row_img = col_img.row(align=True)
            row_alert = row_img.row()
            row_alert.alert = True
            row_alert.label(text="Image & UV Editor Updates", icon='IMAGE_DATA')
            row_img.prop(prefs, "show_info_uv", text="", icon='DOWNARROW_HLT' if prefs.show_info_uv else 'RIGHTARROW', toggle=True, emboss=False)
            if prefs.show_info_uv:
                col_img.separator()
                col_img.label(text="Added new Quick use tools for Image & UV Editor", icon='RIGHTARROW_THIN')
                col_img.label(text="Separated N-Panel Display Settings (Independent settings for Image Editor vs UV Editor)", icon='RIGHTARROW_THIN')

            # --- 3. Preferences Section ---
            box_pref = anno_col.box()
            col_pref = box_pref.column(align=True)
            row_pref = col_pref.row(align=True)
            row_alert = row_pref.row()
            row_alert.alert = True
            row_alert.label(text="Preferences Updates", icon='PREFERENCES')
            row_pref.prop(prefs, "show_info_prefs", text="", icon='DOWNARROW_HLT' if prefs.show_info_prefs else 'RIGHTARROW', toggle=True, emboss=False)
            if prefs.show_info_prefs:
                row_pref = col_pref.row()
                col_pref.separator()
                row_pref.label(text="Added: Ability to set an ICON for each Addons/Tabs & Tab-Group", icon='RIGHTARROW_THIN')
                row_scale = row_pref.row()
                row_scale.scale_x = 0.3
                op = row_scale.operator("wm.url_open", text="See Guide", icon='QUESTION', emboss=True)
                op.url = "https://www.notion.so/SUPERTABs-Tab-Group-Icon-Guide-Preferences-v1-3-0-2d0b1f0a835380f5826de8b7b0d8e8de?source=copy_link"
                row_pref = col_pref.row()
                row_pref.label(text="Added: Add-ons Recovery Feature (Backup/Restore)", icon='RIGHTARROW_THIN')
                row_scale = row_pref.row()
                row_scale.scale_x = 0.3
                op = row_scale.operator("wm.url_open", text="See Guide", icon='QUESTION', emboss=True)
                op.url = "https://www.notion.so/SUPERTABs-Add-ons-Recovery-Guide-Preferences-v1-3-0-2e5b1f0a835380b9a61de408c02192be?source=copy_link"
            # --- 4. Fixes & Changes Section ---
            box_fix = anno_col.box()
            col_fix = box_fix.column(align=True)
            row_fix = col_fix.row(align=True)
            row_alert = row_fix.row()
            row_alert.alert = True
            row_alert.label(text="Fixes & Enhancements", icon='TOOL_SETTINGS')
            row_fix.prop(prefs, "show_fix_enhancements", text="", icon='DOWNARROW_HLT' if prefs.show_fix_enhancements else 'RIGHTARROW', toggle=True, emboss=False)
            if prefs.show_fix_enhancements:
                col_fix.separator()
                col_fix.label(text="Compatibility Update:")
                col_fix.label(text="Updated to support UVPackmaster 4", icon='CHECKMARK')
                col_fix.label(text="Fixes:")
                col_fix.label(text="Fixed:(ZenUV) Math Panel creating unwanted 'Misc' tab", icon='CHECKMARK')
                col_fix.label(text="Fixed:Quick Shortcut in Preferences > group showing active when empty", icon='CHECKMARK')
                col_fix.label(text="Fixed:Add, remove and move (Tab & Tab groups) triggering unwanted sort by name", icon='CHECKMARK')
                col_fix.label(text="Fixed:Transform multi-axis editing for Dimensions (X,Y,Z)", icon='CHECKMARK')
                col_fix.label(text="Fixed:Brush Boolean buttons were behaving like Auto Boolean.", icon='CHECKMARK')
                col_fix.label(text="API: Fixed Annotations for Blender 5.0", icon='CHECKMARK')
                col_fix.label(text="API: Fixed Object Properties Pop-Over for Blender 5.0", icon='CHECKMARK')

                box_reserved = col_fix.box()
                col_reserved = box_reserved.column(align=True)

                # Name Validation Fix
                col_fix_name = col_reserved.column(align=True)
                col_fix_name.label(text="Fixed: Improved tab and tab group name validation.", icon='CHECKMARK')
                col_fix_name.label(text="Validation now warns only for Blender’s main reserved tabs.", icon='RIGHTARROW_THIN')
                
                # Reserved Names Box
                col_reserved = col_reserved.column(align=True)
                col_reserved.alert = True
                col_reserved.label(text="Reserved Names (Cannot be used as Group/Tab names):", icon='ERROR')
                col_reserved.label(text="Item, Tool, View, Options, Node, Group, Scope", icon='RIGHTARROW_THIN')

                col_enhance = col_fix.column(align=True)
                col_enhance.label(text="Enhancements:")
                col_enhance.label(text="N-Panel: Added options to Show/Hide 'SUPERTABs Tools Header' (Cleaner Workspace)", icon='CHECKMARK')
                col_enhance.label(text="N-Panel: Added options to Show/Hide Toggles & Search Bar in Groups section (Cleaner Workspace)", icon='CHECKMARK')
                col_enhance.label(text="N-Panel: Added options to Show/Hide 'Favorite Tabs' & 'Groups' sections (Cleaner Workspace)", icon='CHECKMARK')

                row_enhance = col_enhance.row()
                row_enhance.label(text="N-Panel: Added 'Collapse All' with Smart Unified Popover (Shift+Click)", icon='CHECKMARK')
                row_scale = row_enhance.row()
                row_scale.scale_x = 0.3
                op = row_scale.operator("wm.url_open", text="See Guide", icon='QUESTION', emboss=True)
                op.url = "https://www.notion.so/SUPERTABs-Collapse-All-Feature-Guide-N-Panel-v1-3-0-NEW-2efb1f0a83538075842fce472e503559?source=copy_link"
                col_enhance.label(text="Transform > Normal: 'Curve Recalculate Normal' And 'Mesh Recalculate & Flip Normal' can now be used in Object Mode", icon='CHECKMARK')
        elif prefs.info_section_tab == 'LIMITATION':

            lim_col = info_box.column(align=True)
            
            row_head = lim_col.row()
            row_head.alert = True
            row_head.label(text="Unlocked Logic & Limitations", icon='ERROR')
            lim_col.separator()
            row_head = lim_col.row()
            row_head.label(text="We have unlocked the logic to allow adding 'Tool', 'Image', and 'Group' tabs into SUPERTABs.")
            row_head = lim_col.row()
            row_head.label(text="However, the original Blender API limitations still apply as follows:")
            
            lim_col.separator()
            
            main_box = lim_col.box()
            main_col = main_box.column(align=True)
            main_row = main_col.row()

            main_row.label(text="Limitation List for Blender Main Tabs:")
            main_row.prop(prefs, "show_limitations_info", text="", icon='DOWNARROW_HLT' if prefs.show_limitations_info else 'RIGHTARROW', toggle=True, emboss=False)
            
            if prefs.show_limitations_info:

                main_col.separator()

                # 1. Item > Transform
                row_1 = main_col.row(align=True)
                row_1.alignment = 'LEFT'
                row_1.label(text="• [3D View] Item > Transform:", icon='VIEW3D')
                text_row = main_col.row()
                text_row.alert = True
                text_row.label(text="Cannot be moved or merged into SUPERTABs.")
                main_col.separator()

                # 2. Tool
                row_2 = main_col.row(align=True)
                row_2.alignment = 'LEFT'
                row_2.label(text="• [3D View] Tool Tab:", icon='TOOL_SETTINGS')
                text_row = main_col.row()
                text_row.alert = True
                text_row.label(text="When added, the Tool Settings Panel in the Properties Editor will NOT appear.")
                main_col.label(text="(Note: Settings are still fully functional and displayed inside SUPERTABs instead.)")
                main_col.separator()

                # 3. Image
                row_3 = main_col.row(align=True)
                row_3.alignment = 'LEFT'
                row_3.label(text="• [Image/UV Editor] Image Tab:", icon='IMAGE_DATA')
                text_row = main_col.row()
                text_row.alert = True
                text_row.label(text="Cannot be moved or merged into SUPERTABs (Same limitation as Transform).")
                main_col.separator()

                # 4. Group (Node Editor)
                row_4 = main_col.row(align=True)
                row_4.alignment = 'LEFT'
                row_4.label(text="• [Node Editor] Group Tab:", icon='NODETREE')
                
                sub_col = main_col.column(align=True)
                row_v5 = sub_col.row(align=True)
                row_v5.alert = True
                row_v5.label(text="[Blender 5.0+]: Group Socket subtabs CANNOT be merged due to API limitations.")
                row_v4 = sub_col.row(align=True)
                row_v4.label(text="[Blender 4.5]: Group Socket subtabs CAN be merged and are fully supported.")

            lim_col.separator(factor=0.5)

            # === Known Issues ===
            issue_box = lim_col.box()
            issue_col = issue_box.column(align=True)
            issue_row = issue_col.row()
            issue_row.label(text="Known Issues:")

            # 1. UVPackMaster 3 Issue
            row_uv = issue_col.row(align=True)
            row_alert = row_uv.row()
            row_alert.alert = True
            row_alert.label(text="• UVPackMaster 3 (Disabled Eject Addon Feature)")
            row_uv.prop(prefs, "show_packmaster_info", text="", icon='DOWNARROW_HLT' if prefs.show_packmaster_info else 'RIGHTARROW', toggle=True, emboss=False)
            if prefs.show_packmaster_info:
                col_uv = issue_col.column(align=True)
                col_uv.label(text="Minor issue: 'Eject Addon' and 'Remove from Group' features may not work properly.")
            
                # Fix Steps Box
                box_uv = col_uv.box()
                box_uv.label(text="Permanent Fix (For 'Remove' Only):")
                
                col_uv_steps = box_uv.column(align=True)
                col_uv_steps.label(text="1. In SUPERTABs settings, 'Remove' UVPM3 from its group.")
                
                row_uv_imp = col_uv_steps.row(align=True)
                row_uv_imp.label(text="2. (Important!) If you use 'Auto Import': Go to 'Manual Import/Export'.")
                
                col_uv_steps.label(text="3. Click 'Export' to overwrite settings (stops Blender from reloading old group).")
                col_uv_steps.label(text="4. Restart Blender (The UVPM3 panel will return to the Sidebar).")

                issue_col.separator()

            # 2. GScatter Issue
            row_gs = issue_col.row(align=True)
            row_alert = row_gs.row()
            row_alert.alert = True
            row_alert.label(text="• GScatter (Disabled Eject Group Feature)")
            row_gs.prop(prefs, "show_gscatter_info", text="", icon='DOWNARROW_HLT' if prefs.show_gscatter_info else 'RIGHTARROW', toggle=True, emboss=False)
            if prefs.show_gscatter_info:
                col_gs = issue_col.column(align=True)
                col_gs.label(text="Minor issue: 'Eject Group' feature may not function correctly if group contains GScatter.")
                col_gs.label(text="FIXED (Temporary): Eject feature is disabled when GScatter exists within any subgroup.")
    
    # Menu Link below Info box
    layout.separator(factor=0.25)

    manager_box_inner = layout.box()
    col_inner = manager_box_inner.column()
    row_inner = col_inner.row()
    row_inner.label(text="Documents & Support:", icon='QUESTION')
    row_inner.separator()
    row_inner.menu("ST_MT_DocumentationMenu", text="Documents & Guide Link(Notion)", icon='URL')
    op = row_inner.operator("wm.url_open", text="Join Support Discord", icon='USER', emboss=True)
    op.url = "https://discord.gg/SZSFVZF8"
    row_inner.prop(prefs,"show_guide", text="Guide Navigator", icon='QUESTION', toggle=True)