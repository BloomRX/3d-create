import bpy
from .operators import ST_OT_MoveQuickShortcutItem, ST_OT_RemoveQuickShortcutItem
from .ui_lists import ST_UL_QuickShortcutsList

def draw_general_settings(layout, prefs):
    settings_row = layout.row(align=True)
    manager_col = settings_row.column(align=True)
    manager_box = manager_col.box()
    manager_row_inner = manager_box.row(align=True)

    
    manager_row_inner.prop(prefs, "show_st_setting", text="", icon='TRIA_DOWN' if prefs.show_st_setting else 'TRIA_RIGHT', emboss=False)
    manager_row_inner.label(text="SUPERTABs Settings")
    if prefs.show_guide:
        op = manager_row_inner.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
        op.url = "https://www.notion.so/SUPERTABs-SUPERTABs-Settings-Guide-Preferences-v1-3-0-REMAKE-2eab1f0a83538058ae72dcd0b208a51a?source=copy_link"
    if prefs.show_st_setting:
        manager_col_inner = manager_box.column(align=True)
        row_k_delay = manager_col_inner.row(align=True)
        sub_k_delay = row_k_delay.row(align=True)

        sub_k_delay.enabled = not prefs.lock_keymap_delay
        sub_k_delay.scale_x = 0.95
        sub_k_delay.prop(prefs, "keymap_registration_delay", text="Keymap Delay(Sec)")
        row_k_delay.prop(prefs, "lock_keymap_delay", text="", icon='LOCKED' if prefs.lock_keymap_delay else 'UNLOCKED',emboss=True)
        
        manager_col_inner.separator()

        row_manager = manager_col_inner.row(align=True)
        row_manager.prop(prefs, "manager_hotkey_enabled", text="Use Manager Hotkey", toggle=True)
        
        sub_row_manager = row_manager.row(align=True)
        sub_row_manager.enabled = prefs.manager_hotkey_enabled
        sub_row_manager.prop(prefs, "hotkey_ctrl", text="Ctrl", toggle=True)
        sub_row_manager.prop(prefs, "hotkey_alt", text="Alt", toggle=True)
        sub_row_manager.prop(prefs, "hotkey_shift", text="Shift", toggle=True)
        sub_row_manager.prop(prefs, "hotkey_key", text="")
        active_row = sub_row_manager.row(align=True)
        active_row.scale_x = 1
        if prefs.manager_hotkey_conflict:
            active_row.label(text=f"In Use: {prefs.manager_hotkey_conflict}", icon='ERROR')
        else:
            active_row.label(text="Available", icon='CHECKMARK')

        row_asset = manager_col_inner.row(align=True)
        row_asset.prop(prefs, "asset_browser_hotkey_enabled", text="Use Asset Browser Hotkey", toggle=True)

        sub_row_asset = row_asset.row(align=True)
        sub_row_asset.enabled = prefs.asset_browser_hotkey_enabled
        sub_row_asset.prop(prefs, "asset_browser_hotkey_ctrl", text="Ctrl", toggle=True)
        sub_row_asset.prop(prefs, "asset_browser_hotkey_alt", text="Alt", toggle=True)
        sub_row_asset.prop(prefs, "asset_browser_hotkey_shift", text="Shift", toggle=True)
        sub_row_asset.prop(prefs, "asset_browser_hotkey_key", text="")
        active_row = sub_row_asset.row(align=True)
        active_row.scale_x = 1
        if prefs.asset_browser_hotkey_conflict:
            active_row.label(text=f"In Use: {prefs.asset_browser_hotkey_conflict}", icon='ERROR')
        else:
            active_row.label(text="Available", icon='CHECKMARK')
            
        row_split_join = manager_col_inner.row(align=True)
        row_split_join.prop(prefs, "split_join_hotkey_enabled", text="Use Split/Join View Hotkey", toggle=True)

        sub_row_split_join = row_split_join.row(align=True)
        sub_row_split_join.enabled = prefs.split_join_hotkey_enabled
        sub_row_split_join.prop(prefs, "split_join_hotkey_ctrl", text="Ctrl", toggle=True)
        sub_row_split_join.prop(prefs, "split_join_hotkey_alt", text="Alt", toggle=True)
        sub_row_split_join.prop(prefs, "split_join_hotkey_shift", text="Shift", toggle=True)
        sub_row_split_join.prop(prefs, "split_join_hotkey_key", text="")

        active_row = sub_row_split_join.row(align=True)
        active_row.scale_x = 1
        if prefs.split_join_hotkey_conflict:
            active_row.label(text=f"In Use: {prefs.split_join_hotkey_conflict}", icon='ERROR')
        else:
            active_row.label(text="Available", icon='CHECKMARK')

        row_pie = manager_col_inner.row(align=True)
        pie_row_label = row_pie.row(align=True)
        pie_row_label.enabled = (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH')
        pie_row_label.prop(prefs, "pie_menu_hotkey_enabled", text="Use Pie Menu Hotkey", toggle=True)

        sub_row_pie = row_pie.row(align=True)
        sub_row_pie.enabled = (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH') and prefs.pie_menu_hotkey_enabled
        sub_row_pie.prop(prefs, "pie_menu_hotkey_ctrl", text="Ctrl", toggle=True)
        sub_row_pie.prop(prefs, "pie_menu_hotkey_alt", text="Alt", toggle=True)
        sub_row_pie.prop(prefs, "pie_menu_hotkey_shift", text="Shift", toggle=True)
        sub_row_pie.prop(prefs, "pie_menu_hotkey_key", text="")

        active_row = sub_row_pie.row(align=True)
        active_row.scale_x = 1
        if prefs.pie_menu_hotkey_conflict:
            active_row.label(text=f"In Use: {prefs.pie_menu_hotkey_conflict}", icon='ERROR')
        else:
            active_row.label(text="Available", icon='CHECKMARK')

        rightclick_split = manager_col.split(factor=0.5, align=True)
        rightclick_box = rightclick_split.box()
        rightclick_row = rightclick_box.row(align=True)
        rightclick_row.label(text="Quick Menu Integration")

        if prefs.show_guide:
            op = rightclick_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
            op.url = "https://www.notion.so/SUPERTABs-SUPERTABs-Settings-Guide-Preferences-v1-3-0-REMAKE-2eab1f0a83538058ae72dcd0b208a51a?source=copy_link"
            op = rightclick_row.operator("wm.url_open", text="", icon='HELP', emboss=False)
            op.url = "https://www.notion.so/SUPERTABs-Quick-Shortcuts-Guide-Right-Click-Pie-Menu-v1-1-3-2acb1f0a835380f280d4dceed2bc6567?source=copy_link"

        qm_col = rightclick_box.column(align=True)
        qm_col.scale_y = 1.3
        qm_col.prop(prefs, "right_click_mode", expand=True)
        
        # --- RightClick Toggles ---
        win_edit_box = rightclick_split.box()
        win_edit_col = win_edit_box.column()
        win_edit_row = win_edit_col.row()
        win_edit_row.label(text="Right-Click Menu")
        position_row = win_edit_row.row(align=True)
        position_row.scale_x = 0.5
        position_row.prop(prefs, "right_click_menu_position",text="Position", expand=True)
        
        # RCM Toggle
        rcm_qs_row = win_edit_col.row(align=True)
        rcm_qs_row.enabled = (prefs.right_click_mode == 'MENU' or prefs.right_click_mode == 'BOTH')
        rcm_qs_row.prop(prefs, "enable_quick_shortcuts_rcm", text="Quick-Shortcuts", 
                        icon="PINNED" if prefs.enable_quick_shortcuts_rcm else "UNPINNED", toggle=True)
        
        # RCM Toggle
        rcm_win_row = win_edit_col.row(align=True)
        rcm_win_row.enabled = (prefs.right_click_mode == 'MENU' or prefs.right_click_mode == 'BOTH')
        rcm_win_row.prop(prefs, "enable_window_editors_rcm", text="Window Editors", 
                        icon="RESTRICT_VIEW_OFF" if prefs.enable_window_editors_rcm else "RESTRICT_VIEW_ON", toggle=True)

        # --- Pie Menu Toggles ---
        qs_row = win_edit_col.row()
        qs_row.label(text="Pie-Menu:")
        
        # Pie Toggle
        pie_qs_row = win_edit_col.row(align=True)
        pie_qs_row.enabled = (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH')
        pie_qs_row.prop(prefs, "enable_quick_shortcuts_pie", text="Quick-Shortcuts", 
                        icon="PINNED" if prefs.enable_quick_shortcuts_pie else "UNPINNED", toggle=True)
        
        # Pie Toggle
        pie_win_row = win_edit_col.row(align=True)
        pie_win_row.enabled = (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH')
        pie_win_row.prop(prefs, "enable_window_editors_pie", text="Window Editors", 
                        icon="RESTRICT_VIEW_OFF" if prefs.enable_window_editors_pie else "RESTRICT_VIEW_ON", toggle=True)
        
        rightclick_row = manager_col.row(align=True)
        rightclick_row.scale_x = 1.75
        left_col = rightclick_row.column(align=True)
        if prefs.enable_window_editors_rcm or prefs.enable_window_editors_pie:
            rcm_box = left_col.box()
            rcm_box.enabled = ( (prefs.right_click_mode == 'MENU' or prefs.right_click_mode == 'BOTH') and prefs.enable_window_editors_rcm ) or \
                            ( (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH') and prefs.enable_window_editors_pie )
            rcm_box.prop(prefs, "rcm_show_window_editors", text="Favorite Window Editors in Menu", icon="DOWNARROW_HLT" if prefs.rcm_show_window_editors else "RIGHTARROW",emboss=False)
        
            if prefs.rcm_show_window_editors:
                main_split = rcm_box.split(factor=0.35, align=True)
                main_col = main_split.column(align=True)
                
                # --- General ---
                box_general = main_col.box()
                col_general = box_general.column(align=True)
                col_general.label(text="General:")
                grid_general = col_general.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
                grid_general.prop(prefs, "rcm_show_3Dview", text="3D View", toggle=True, icon='VIEW3D')
                grid_general.prop(prefs, "rcm_show_image", text="Image", toggle=True, icon='IMAGE')
                grid_general.prop(prefs, "rcm_show_uv", text="UV", toggle=True, icon='UV')
                grid_general.prop(prefs, "rcm_show_shader", text="Shader", toggle=True, icon='NODE_MATERIAL')
                grid_general.prop(prefs, "rcm_show_geo", text="Geometry Node", toggle=True, icon='GEOMETRY_NODES')
                grid_general.prop(prefs, "rcm_show_comp", text="Compositor", toggle=True, icon='NODE_COMPOSITING')
                grid_general.prop(prefs, "rcm_show_texture", text="Texture Node", toggle=True, icon='NODE_TEXTURE')
                grid_general.prop(prefs, "rcm_show_sequence", text="Sequencer", toggle=True, icon='SEQUENCE')
                grid_general.prop(prefs, "rcm_show_clip", text="Movie Clip", toggle=True, icon='TRACKER')
                grid_general.prop(prefs, "rcm_show_serpen", text="Visual Scripting Editor (Serpen)", toggle=True, icon='FILE_SCRIPT')
                # --- Scripting ---
                main_col = main_split.column(align=True)
                box_script = main_col.box()
                col_script = box_script.column(align=True)
                col_script.label(text="Scripting:")
                grid_script = col_script.grid_flow(row_major=True, columns=1, even_columns=True, align=True)
                grid_script.prop(prefs, "rcm_show_text", text="Text", toggle=True, icon='TEXT')
                grid_script.prop(prefs, "rcm_show_console", text="Python Console", toggle=True, icon='CONSOLE')
                grid_script.prop(prefs, "rcm_show_info", text="Info", toggle=True, icon='INFO')
                grid_script.prop(prefs, "rcm_show_iconviewer", text="Icon Viewer", toggle=False, icon='BLENDER')
                grid_script.prop(prefs, "rcm_show_system_console", text="System Console", toggle=True, icon='SYSTEM')
                # --- Animation ---
                main_col = main_split.column(align=True)
                box_anim = main_col.box()
                col_anim = box_anim.column(align=True)
                col_anim.label(text="Animation:")
                grid_anim = col_anim.grid_flow(row_major=True, columns=1, even_columns=True, align=True)
                grid_anim.prop(prefs, "rcm_show_dopesheet", text="Dope Sheet", toggle=True, icon='ACTION')
                grid_anim.prop(prefs, "rcm_show_timeline", text="Timeline", toggle=True, icon='TIME')
                grid_anim.prop(prefs, "rcm_show_graph", text="Graph", toggle=True, icon='GRAPH')
                grid_anim.prop(prefs, "rcm_show_drivers", text="Drivers", toggle=True, icon='DRIVER')
                grid_anim.prop(prefs, "rcm_show_nla", text="NLA", toggle=True, icon='NLA')
                # --- Data ---
                main_col = main_split.column(align=True)
                box_data = main_col.box()
                col_data = box_data.column(align=True)
                col_data.label(text="Data:")
                grid_data = col_data.grid_flow(row_major=True, columns=1, even_columns=True, align=True)
                grid_data.prop(prefs, "rcm_show_outliner", text="OutLiner", toggle=True, icon='OUTLINER')
                grid_data.prop(prefs, "rcm_show_props", text="Properties", toggle=True, icon='PROPERTIES')
                grid_data.prop(prefs, "rcm_show_file", text="File Browser", toggle=True, icon='TRACKER')
                grid_data.prop(prefs, "rcm_show_spread", text="Spreadsheet", toggle=True, icon='SPREADSHEET')
                grid_data.prop(prefs, "rcm_show_asset", text="Asset Browser", toggle=True, icon='ASSET_MANAGER')
