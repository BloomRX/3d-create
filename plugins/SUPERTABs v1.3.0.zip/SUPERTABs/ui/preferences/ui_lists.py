import bpy

class ST_UL_QuickShortcutsList(bpy.types.UIList):
    """UIList for managing Quick Shortcuts"""
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        # 'item' is the ST_QuickShortcutItem
        # 'data' is MyAddonPreferences
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            row = layout.row(align=True)
            op = row.operator("st.toggle_quick_shortcut", text="", 
                icon='PINNED', emboss=False, depress=True)

            op.item_identifier = item.identifier
            op.display_name = item.display_name
            op.main_group_name = item.main_group_name
            op.sub_group_name = item.sub_group_name

            row.label(text=item.display_name)
            group_label = item.main_group_name
            if item.sub_group_name:
                group_label += f" / {item.sub_group_name}"
            row.label(text=f"({group_label})", icon='EVENT_S')
            
        elif self.layout_type in {'GRID'}:
            layout.alignment = 'CENTER'
            op = layout.operator("st.toggle_quick_shortcut", 
                text=item.display_name, 
                icon='PINNED', depress=True)
            op.item_identifier = item.identifier
            op.display_name = item.display_name
            op.main_group_name = item.main_group_name
            op.sub_group_name = item.sub_group_name
    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        target_space = prefs.active_management_tab 
        
        filtered = []
        ordered = []
        
        for i, item in enumerate(items):
            if item.space_type == target_space:
                filtered.append(self.bitflag_filter_item)
            else:
                filtered.append(0)
            ordered.append(i)

        return filtered, ordered

class AVAILABLE_UL_List(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "selected", text="")
        row.label(text=item.display_name or item.name)

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        filtered = []
        ordered = []

        search_term = ""
        if hasattr(data, "search_query"):
            search_term = data.search_query.lower()
        elif hasattr(data, "tab_search_query"):
            search_term = data.tab_search_query.lower()

        if search_term:
            for i, item in enumerate(items):
                if search_term in item.name.lower() or search_term in item.display_name.lower():
                    filtered.append(self.bitflag_filter_item)
                    ordered.append(i)
                else:
                    filtered.append(0)
        else:
            for i in range(len(items)):
                filtered.append(self.bitflag_filter_item)
                ordered.append(i)
                
        return filtered, ordered