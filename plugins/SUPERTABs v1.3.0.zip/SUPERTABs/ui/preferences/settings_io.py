import bpy
import os
from ... import state as st_state

def draw_import_export_section(layout, prefs, context):

    col = layout.column(align=True)

    import_export_split = col.split(factor=0.5, align=True)
    col_auto_import = import_export_split.column(align=True)
    auto_import_box = col_auto_import.box()
    auto_import_row = auto_import_box.row(align=True)
    auto_import_row.label(text="Auto Import on Startup (SUPERTABs)", icon="AUTO")
    row = auto_import_box.row(); row.prop(prefs, "auto_import_enabled",text="Enabled" if prefs.auto_import_enabled else "Disabled", toggle=True)
    im_col = auto_import_box.column()
    im_col.enabled = prefs.auto_import_enabled
    im_col.prop(prefs, "auto_import_filepath")

    row_startup_delay = im_col.row(align=True)
    sub_startup = row_startup_delay.row(align=True)
    sub_startup.enabled = not prefs.lock_startup_delay
    sub_startup.prop(prefs, "auto_import_delay")
    row_startup_delay.prop(prefs, "lock_startup_delay", text="", icon='LOCKED' if prefs.lock_startup_delay else 'UNLOCKED', emboss=True)

    col_manual_import_export = import_export_split.column(align=True)
    io_box = col_manual_import_export.box()
    
    header_row = io_box.row(align=True)
    header_row.label(text="Recovery Addons List" if prefs.show_recovery_addons else "Import/Export", icon="RECOVER_LAST" if prefs.show_recovery_addons else "FILE_FOLDER") 
    
    im_box = header_row.box()
    im_box.scale_y = 0.5
    im_row = im_box.row(align=True)
    if prefs.auto_import_enabled:
        filepath = prefs.auto_import_filepath
        if filepath and os.path.exists(filepath):
            filename = os.path.basename(filepath)
            im_row.label(text=f"{filename}", icon='FILE_TICK')
        elif filepath:
            im_row.alert = True
            im_row.label(text="Auto-Load file not found!", icon='ERROR')
        else:
            im_row.alert = True
            im_row.label(text="No auto-load file set", icon='ERROR')
    else:
        im_row.enabled = False
        im_row.label(text="Auto-Import Disabled", icon='PAUSE')

    header_row.prop(prefs, "show_recovery_addons", text="", icon='RECOVER_LAST', toggle=True)

    if prefs.show_guide:
        header_row.separator()
        op = header_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
        if prefs.show_recovery_addons:
            op.url = "https://www.notion.so/SUPERTABs-Add-ons-Recovery-Guide-Preferences-v1-3-0-NEW-2e5b1f0a835380b9a61de408c02192be?source=copy_link"
        else:
            op.url = "https://www.notion.so/SUPERTABs-Import-Export-Settings-Guide-Preferences-v1-3-0-29cb1f0a8353809dbb50e3b00b4963b1?source=copy_link"
    
    col.separator(factor=0.25)
    
    if prefs.show_recovery_addons:
        
        col_io = io_box.column()
        col_io.prop(prefs, "addon_state_filepath", text="", icon="FILE_BACKUP")
        row_io = col_io.row()
        row_io.scale_y = 1.4
        row_io.operator("st.load_addon_states", text="Recover Now", icon='IMPORT')
        
        row_danger = col_io.row(align=True)
        row_danger.alert = True 
        row_danger.operator("st.disable_all_addons", text="Disable All", icon='TRASH')

        if prefs.addon_state_filepath and not os.path.exists(prefs.addon_state_filepath):
            io_box.label(text="File not found!", icon='ERROR')

    else:
        row_import = io_box.row(align=True)
        row_import.prop(prefs, "auto_apply_after_import", text="", icon='AUTO', toggle=True)
        row_import.operator("tab_group.import_settings", text="Import JSON", icon="IMPORT")
        
        box_alert = io_box.box()
        row_alert = box_alert.row(align=True)
        row_alert.alert = True
        row_alert.scale_y = 1.6
        row_alert.operator("tab_group.export_settings", text="Export JSON")
        row_alert.scale_x = 2
        row_alert.operator("tab_group.quick_export", text="", icon="EXPORT")