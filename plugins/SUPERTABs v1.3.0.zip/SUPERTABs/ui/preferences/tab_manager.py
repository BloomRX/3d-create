import bpy
from ...utils import RESERVED_TAB_NAMES
from ...core import get_target_panels_for_item
from .operators import ST_OT_TogglePanelVisibility, ST_OT_MoveQuickShortcutItem, ST_OT_RemoveQuickShortcutItem
from .ui_lists import ST_UL_QuickShortcutsList, AVAILABLE_UL_List

def draw_tab_group_management_ui(layout, context):
    """
    Reusable UI function for managing tab groups. Can be called from Preferences or N-Panel.
    """
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    display_name_map = {}
    display_name_map.update({f"addon:{item.name}": item.display_name for item in prefs.addon_display_lookup})
    all_tab_names = {item.name for item in prefs.available_tabs}
    all_tab_names.update(RESERVED_TAB_NAMES)
    display_name_map.update({f"tab:{name}": name for name in all_tab_names})
    display_name_map.update({item.identifier: item.display_name for item in prefs.custom_item_names if item.display_name})
    
    search_term = prefs.prefs_group_search_query.lower()
    item_to_preset_icon = {}
    if hasattr(context.window_manager, "tab_group_states"):
        active_space = prefs.active_management_tab
        preset_name_to_icon_map = {p.name: p.icon for p in prefs.custom_favorite_presets if p.space_type == active_space}
        item_preset_counts = {}
        item_single_icon = {}

        for group_state in context.window_manager.tab_group_states:
            for preset_in_state in group_state.favorite_presets:
                icon = preset_name_to_icon_map.get(preset_in_state.name)
                if not icon:
                    continue
                items = {item.strip() for item in preset_in_state.items.split(',') if item.strip()}
                for item in items:
                    item_preset_counts[item] = item_preset_counts.get(item, 0) + 1
                    if item not in item_single_icon:
                        item_single_icon[item] = icon
        
        for item, count in item_preset_counts.items():
            if count > 1:
                item_to_preset_icon[item] = 'SOLO_ON'
            elif count == 1:
                item_to_preset_icon[item] = item_single_icon.get(item, 'SOLO_OFF')

        all_quick_shortcut_identifiers = {
            sc.identifier for sc in prefs.quick_shortcuts 
            if sc.space_type == prefs.active_management_tab
        }

    def item_filter(item_string):
        if not search_term:
            return True
        if not item_string:
            return False
        display_text = display_name_map.get(item_string, item_string.split(":", 1)[-1])
        return search_term in item_string.lower() or search_term in display_text.lower()
    
    group_box = layout.box()
    group_col = group_box.column()
    orphan_presets = []
    for i, p in enumerate(prefs.custom_favorite_presets):
        if not p.main_group_name:
            orphan_presets.append((i, p)) 

    if orphan_presets:
        orphan_box = group_col.box()
        orphan_box.alert = True
        orphan_col = orphan_box.column()
        orphan_col.label(text="Orphan Presets Found!", icon='ERROR')
        orphan_col.label(text="Assign your old presets to a SUPERTABs group:")
        
        for index, preset in orphan_presets:
            row = orphan_col.row(align=True)
            row.label(text=preset.name, icon=preset.icon)
            op = row.operator_menu_enum(
                "st.assign_orphan_preset", 
                "target_group_name", 
                text="Assign..."
            )
            op.preset_index = index 
        
        group_col.separator(factor=0.5)
    main_row = group_col.row(align=True)
    header_box = main_row.box()
    header_row = header_box.row(align=True)
    header_label = header_row.row(align=True)
    header_label.label(text="Tab Group Management",icon='PACKAGE')
    poll_toggle_row = header_row.row(align=True)
    poll_toggle_row.scale_x = 1.25
    poll_toggle_row.prop(prefs, "show_poll_exceptions", text="", icon='SETTINGS', toggle=True, emboss=True)
    header_row.scale_y = 1.5
    header_row.operator("tab_group.apply_settings", text="Apply / Refresh UI", icon="CHECKMARK")
    reset_button_row = header_row.row(align=True)
    reset_button_row.alert = True
    reset_button_row.operator("tab_group.reset_ui", icon="X")
    
    if prefs.show_guide:
        header_row.separator(factor=0.5)
        sub_head_row = header_row.row()
        op = sub_head_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
        op.url = "https://www.notion.so/SUPERTABs-TAB-GROUP-Management-Guide-Preferences-v1-3-0-REMAKE-29cb1f0a83538185963ec56139a38c99?source=copy_link"
    if prefs.show_poll_exceptions:
        group_col.separator(factor=0.5)
        poll_box = group_col.box()
        poll_row = poll_box.row(align=True)
        op = poll_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
        op.url = "https://www.notion.so/SUPERTABs-Poll-Exception-feature-Guide-Preferences-2a3b1f0a835380c0b367f098604348b0?source=copy_link"
        sub_poll_row = poll_row.row(align=True)
        sub_poll_row.enabled = not prefs.lock_poll_exceptions
        sub_poll_row.prop(prefs, "poll_method_exceptions", text="Poll Exceptions")
        poll_row.operator("st.reset_poll_exceptions", text="", icon='LOOP_BACK', emboss=True)
        poll_row.prop(prefs, "lock_poll_exceptions", text="", icon='LOCKED' if prefs.lock_poll_exceptions else 'UNLOCKED', emboss=True)
    group_col.separator(factor=0.25)

    # header_box = group_col.box()
    toggle_row = group_col.row(align=True)
    toggle_row.scale_y = 1.25
    if prefs.active_management_tab == 'VIEW_3D':
        # toggle_row = group_col.row(align=True)
        toggle_row.prop(prefs, "manage_tool_tab", toggle=True)
        toggle_row.prop(prefs, "manage_item_tab", toggle=True)
        toggle_row.prop(prefs, "manage_view_tab", toggle=True)
        toggle_row.prop(prefs, "manage_edit_tab", toggle=True)
    elif prefs.active_management_tab == 'IMAGE_EDITOR':
        # toggle_row = group_col.row(align=True)
        toggle_row.prop(prefs, "manage_uv_image_tab", toggle=True)
        tool_row = toggle_row.row(align=True)
        tool_row.prop(prefs, "manage_uv_tool_tab", toggle=True)
        toggle_row.prop(prefs, "manage_uv_view_tab", toggle=True)
        toggle_row.prop(prefs, "manage_uv_scope_tab", toggle=True)
    elif prefs.active_management_tab == 'NODE_EDITOR':
        # toggle_row = group_col.row(align=True)

        if bpy.app.version >= (5, 0, 0):
            group_lock_row = toggle_row.row(align=True)
            
            icon = 'LOCKED' if prefs.lock_manage_node_group_tab else 'UNLOCKED'
            group_lock_row.alert = True
            group_lock_row.operator("st.toggle_node_group_tab_lock", text="", icon=icon, emboss=True)
            
            sub_row = toggle_row.row(align=True)
            sub_row.enabled = not prefs.lock_manage_node_group_tab
            sub_row.prop(prefs, "manage_node_group_tab", toggle=True)

            toggle_row.separator(factor=0.5)
        else:
            toggle_row.prop(prefs, "manage_node_group_tab", toggle=True)
        
        toggle_row.prop(prefs, "manage_node_options_tab", toggle=True)
        toggle_row.prop(prefs, "manage_node_tool_tab", toggle=True)
        toggle_row.prop(prefs, "manage_node_view_tab", toggle=True)
        toggle_row.prop(prefs, "manage_node_node_tab", toggle=True)
        
    group_col.separator(factor=0.25)
    main_row.separator(factor=0.5)
    header_box = main_row.box()
    tab_selector_row = header_box.row(align=True)
    tab_selector_row.scale_y = 1.5
    tab_selector_row.prop(prefs, "active_management_tab", expand=True)

    main_split = group_col.split(factor=0.25, align=True)
    group_list_col = main_split.column(align=True)
    
    all_groups = list(prefs.tab_groups)
    main_group_names_in_order = []
    for group in all_groups:
        main_name = group.name.split(" / ")[0]
        if main_name not in main_group_names_in_order:
            main_group_names_in_order.append(main_name)

    header_box_add = group_list_col.box()
    header_row_add = header_box_add.row(align=True)
    header_row_add.scale_y = 1.5
    
    if prefs.active_management_tab == 'VIEW_3D':
        op_add = header_row_add.operator("tab_group.add", text="Create SUPERTABs (3DView)", icon='VIEW3D')
        op_add.target_space = 'VIEW_3D'
    elif prefs.active_management_tab == 'IMAGE_EDITOR':
        op_add = header_row_add.operator("tab_group.add", text="Create SUPERTABs (UV)", icon='IMAGE')
        op_add.target_space = 'IMAGE_EDITOR'
    elif prefs.active_management_tab == 'NODE_EDITOR':
        op_add = header_row_add.operator("tab_group.add", text="Create SUPERTABs (Nodes)", icon='NODETREE')
        op_add.target_space = 'NODE_EDITOR'
    
    for main_name in main_group_names_in_order:
        main_item = next((g for g in all_groups if g.name == main_name), None)
        if not main_item: continue

        if main_item.space_type != prefs.active_management_tab:
            continue

        main_group_idx = all_groups.index(main_item)

        subgroups_for_main = [
            (i, g) for i, g in enumerate(all_groups) 
            if g.name.startswith(f"{main_name} / ")
        ]
        
        filtered_subgroups = []
        if search_term:
            for sub_idx, sub_item in subgroups_for_main:
                sub_name_matches = search_term in sub_item.name.lower()
                items_match = any(item_filter(item.strip()) for item in sub_item.items.split(','))
                if sub_name_matches or items_match:
                    filtered_subgroups.append((sub_idx, sub_item))

        main_name_matches = search_term in main_name.lower()
        main_items_match = any(item_filter(item.strip()) for item in main_item.items.split(','))

        subgroups_match = bool(filtered_subgroups)
        
        if search_term and not main_name_matches and not main_items_match and not subgroups_match:
            continue 

        box = group_list_col.box()
        row = box.row(align=True)
        icon = "TRIA_DOWN" if main_item.is_expanded_in_prefs else "TRIA_RIGHT"
        row.operator("tab_group.set_active", text="", icon="TRIA_DOWN" if main_item.is_expanded_in_prefs else "TRIA_RIGHT").index = main_group_idx

        op_select_group = row.operator("tab_group.set_reorder_selection", text=main_name, emboss=True, depress=(prefs.active_reorder_selection_id == main_item.name))
        op_select_group.selection_type = 'GROUP'
        op_select_group.selection_id = main_item.name
        op_select_group.group_index = main_group_idx
        
        row.operator("tab_group.remove", text="", icon="X").index = main_group_idx
        
        if main_item.is_expanded_in_prefs or (search_term and subgroups_match):
            sub_add_box = box.box()
            sub_add_row = sub_add_box.row()
            op_add_sub = sub_add_row.operator("tab_group.add_sub", text="Add Tab Group", icon="ADD")
            op_add_sub.parent_index = main_group_idx
            op_set_sub = sub_add_row.operator("tab_group.set_sub", text="Set Tab Group", icon="PRESET_NEW")
            op_set_sub.parent_index = main_group_idx

            subgroups_for_main = [
                (i, g) for i, g in enumerate(all_groups) 
                if g.name.startswith(f"{main_name} / ")
            ]

            list_to_draw = filtered_subgroups if search_term else subgroups_for_main

            if list_to_draw:
                sub_col = box.column()
                for sub_idx, sub_item in list_to_draw:
                    sub_name = sub_item.name.split(" / ", 1)[1]
                    sub_row = sub_col.row(align=True)
                    sub_row.separator()
                    if prefs.show_subgroup_icon_menu:
                        icon_ui_row = sub_row.row(align=True)
                        icon_ui_row.scale_x = 1.2
                        current_icon = sub_item.icon if sub_item.icon != 'NONE' else 'DOWNARROW_HLT'
                        op = icon_ui_row.operator("st.set_subgroup_icon", text="", icon=current_icon)
                        op.subgroup_name = sub_item.name

                    sub_row.separator(factor=0.25)
                    items_in_subgroup = {item.strip() for item in sub_item.items.split(',') if item.strip()}
                    
                    is_any_item_pinned = not items_in_subgroup.isdisjoint(all_quick_shortcut_identifiers)
                    if prefs.status_icon_quick:
                        shortcut_status_icon = 'PINNED' if is_any_item_pinned else 'UNPINNED'
                        sub_row.label(text="", icon=shortcut_status_icon)

                    is_active = (prefs.active_reorder_selection_id == sub_item.name) or \
                                (prefs.active_group_index == sub_idx)
                    
                    if prefs.use_label_style_ui:
                        # --- NEW STYLE (Labels) ---
                        op_select_sub = sub_row.operator("tab_group.set_reorder_selection", text="", icon='RADIOBUT_ON' if is_active else 'RADIOBUT_OFF', emboss=False)
                        op_select_sub.selection_type = 'GROUP'
                        op_select_sub.selection_id = sub_item.name
                        op_select_sub.group_index = sub_idx
                        label_row = sub_row.row()
                        if is_active:
                            label_row.prop(prefs, "edit_group_name", text="", emboss=True)
                        else:
                            label_row.label(text=sub_name)
                    
                    else:
                        # --- OLD STYLE (Buttons) ---
                        op_select_sub = sub_row.operator("tab_group.set_reorder_selection", text=sub_name, emboss=True, depress=is_active)
                        op_select_sub.selection_type = 'GROUP'
                        op_select_sub.selection_id = sub_item.name
                        op_select_sub.group_index = sub_idx
                    if prefs.show_move_options:
                        op_move_sub = sub_row.operator("st.call_move_subgroup_menu", text="", icon='ARROW_LEFTRIGHT')
                        op_move_sub.subgroup_index = sub_idx
                    if prefs.show_remove_options:
                        sub_row.operator("tab_group.remove", text="", icon="X").index = sub_idx

                    if prefs.status_icon_fav_panel:
                        is_any_item_favorited = not items_in_subgroup.isdisjoint(item_to_preset_icon.keys())
                        preset_status_icon = 'SOLO_ON' if is_any_item_favorited else 'SOLO_OFF'
                        sub_row.label(text="", icon=preset_status_icon)
            elif search_term:
                box.label(text="No matching subgroups.", icon='INFO')
        box.separator(factor=0.3)        

    right_area = main_split.column(align=True)
    split_2 = right_area.split(factor=0.4, align=True) 
    edit_col = split_2.column(align=True)
    is_active_group_in_view = False
    if 0 <= prefs.active_group_index < len(prefs.tab_groups):
        active_group_check = prefs.tab_groups[prefs.active_group_index]
        if active_group_check.space_type == prefs.active_management_tab:
            is_active_group_in_view = True

    if is_active_group_in_view:
        active_group = prefs.tab_groups[prefs.active_group_index]
        main_group_name = active_group.name.split(" / ")[0]
        active_group_parts = active_group.name.split(" / ", 1)
        sub_group_name_for_pin = active_group_parts[1] if len(active_group_parts) > 1 else ""
        box = edit_col.box()
        col = box.column()
        row = col.row(align=True)
        enum_row = row.row(align=True)
        enum_row.scale_y = 1.25
        enum_row.prop(prefs, "prefs_section_view", expand=True)

        col.separator(factor=0.3)

        row = col.row(align=True)
        # ui_box = row.box()
        ui_row = row.row()
        ui_row.scale_x = 3
        ui_row.prop(prefs, "use_label_style_ui", text="", icon="SYNTAX_OFF", emboss=True)
        ui_row.prop(prefs, "show_move_options", text="", icon="ARROW_LEFTRIGHT", emboss=True)
        ui_row.prop(prefs, "show_remove_options", text="", icon="X", emboss=True)
        # ui_row.prop(prefs, "status_icon_quick", text="", icon="PINNED" if prefs.status_icon_quick else "UNPINNED", emboss=True)
        # ui_row.prop(prefs, "status_icon_fav_panel", text="", icon="SOLO_ON" if prefs.status_icon_fav_panel else "SOLO_OFF", emboss=True)
        ui_row.prop(prefs, "show_subgroup_icon_menu", text="", icon='THREE_DOTS', emboss=True)

        if prefs.show_subgroup_icon_menu:
            col.separator(factor=0.5)
            icon_row = col.row(align=True)
            icon_row.prop(prefs, "show_subgroup_custom_icons", text="Display on Tab-Groups",toggle=True , emboss=True)
            icon_row.prop(prefs, "show_subgroup_item_icons", text="Display on Addons/Tabs",toggle=True , emboss=True)
            icon_row.separator(factor=0.5)

            icon_row.prop(prefs, "clear_icon_toggle", text="", icon='TRASH', toggle=True, emboss=True)
            if prefs.clear_icon_toggle:
                clear_row = col.row()
                # scale_row.scale_x = 0.75
                clear_row.alert = True
                clear_row.operator("st.clear_subgroup_icon", text="Clear Groups Icon", icon='TRASH')
                clear_row.operator("st.clear_item_icon", text="Clear Tabs Icons", icon='TRASH')

            if prefs.show_guide:
                icon_row.separator(factor=0.5)
                op = icon_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                op.url = "https://www.notion.so/SUPERTABs-Tab-Group-Icon-Guide-Preferences-v1-3-0-2d0b1f0a835380f5826de8b7b0d8e8de?source=copy_link"

        col.separator(factor=0.5)

        if not prefs.use_label_style_ui:
            old_ui_box = col.box()
            old_ui_col = old_ui_box.column()
            old_ui_col.label(text=f"Edit: '{active_group.name}'")
            is_main_group = "/" not in active_group.name

            if not prefs.use_label_style_ui or is_main_group:
                old_ui_col.prop(prefs, "edit_group_name", text="Group Name" if not is_main_group else "N-Panel Name")

            if prefs.active_reorder_selection_type == 'ITEM':
                is_built_in_tab = False
                if prefs.active_reorder_selection_id.startswith("tab:"):
                    tab_name = prefs.active_reorder_selection_id.split(":", 1)[-1]
                    if tab_name in {"Item", "Tool", "View", "Edit"}: 
                        is_built_in_tab = True
                if not prefs.use_label_style_ui:
                    old_ui_col.prop(prefs, "edit_item_name", text="Addon Display Name")
        
        # --- NAME CONFLICT WARNING ---
        current_name = prefs.edit_group_name.strip()
        if current_name in RESERVED_TAB_NAMES:
            warning_box = col.box()
            warning_box.alert = True
            col = warning_box.column()
            col.label(text="This name is reserved for Blender", icon='ERROR')
            col.label(text="Using this name may cause issues with the 'Eject Subgroup' function")

        if not prefs.use_label_style_ui:
            reorder_box = col.box()
            reorder_col = reorder_box.column(align=True)
            reorder_row = reorder_col.row(align=True)
            reorder_row.prop(prefs,"show_options", text="", emboss=False, icon="DOWNARROW_HLT" if prefs.show_options else "RIGHTARROW")
            reorder_row.label(text="Options")
            if prefs.show_options:
                reorder_col.separator()

                reorder_row = reorder_col.row(align=True)
                move_up_op = reorder_row.operator("tab_group.move_selected", text="UP", icon="TRIA_UP")
                move_up_op.direction = "UP"
                move_down_op = reorder_row.operator("tab_group.move_selected", text="DOWN", icon="TRIA_DOWN")
                move_down_op.direction = "DOWN"

                reorder_col.separator()

                reorder_row = reorder_col.row(align=True)
                reorder_row.operator("st.sort_all_subgroups", text="Sort Tab-groups", icon="SORTALPHA")
                reorder_row.operator("st.sort_items_in_group", text="Sort Add-ons", icon="SORTALPHA")

        is_main_group = "/" not in active_group.name
        row = col.row(align=True)
        if prefs.use_label_style_ui:
            label_ui_box = row.box()
            if is_main_group:
                label_row = label_ui_box.row(align=True)
                label_row.label(text="N-panel Name:")
                label_row.prop(prefs, "edit_group_name", text="")
            else:
                label_ui_box.label(text=f"Tab-Group: '{active_group.name}'")
        
        if prefs.use_label_style_ui:
            reorder_box = col.box()
            reorder_col = reorder_box.column(align=True)
            reorder_row = reorder_col.row(align=True)
            reorder_row.prop(prefs,"show_options", text="", emboss=False, icon="DOWNARROW_HLT" if prefs.show_options else "RIGHTARROW")
            reorder_row.label(text="Options")
            if prefs.show_options:
                reorder_col.separator()

                reorder_row = reorder_col.row(align=True)
                move_up_op = reorder_row.operator("tab_group.move_selected", text="UP", icon="TRIA_UP")
                move_up_op.direction = "UP"
                move_down_op = reorder_row.operator("tab_group.move_selected", text="DOWN", icon="TRIA_DOWN")
                move_down_op.direction = "DOWN"

                reorder_col.separator()

                reorder_row = reorder_col.row(align=True)
                reorder_row.operator("st.sort_all_subgroups", text="Sort Tab-groups", icon="SORTALPHA")
                reorder_row.operator("st.sort_items_in_group", text="Sort Add-ons", icon="SORTALPHA")

        sub_row = col.row(align=True)
        sub_row.prop(prefs, "prefs_group_search_query", text="", icon='VIEWZOOM', emboss=True)
        op_layout = sub_row.row(align=True)
        op_layout.enabled = (prefs.active_reorder_selection_type == 'GROUP')
        sub_row.separator(factor=0.5)
        op_assign = sub_row.operator("st.open_assign_menu", text="", icon='ADD')
        op_assign.target_group_index = prefs.active_group_index
        
        items_list = [item.strip() for item in active_group.items.split(",") if item.strip()]
        if search_term and items_list:
            items_list = [item for item in items_list if item_filter(item)]

        if items_list:
            item_col = box.column()
            hidden_panel_ids = {p.panel_id for p in prefs.hidden_panels}
            for item_string in items_list:
                row = item_col.row()
                
                item_type, item_name = (item_string.split(":", 1) + [""])[:2]
                display_text = display_name_map.get(item_string, item_name)
                is_active = (prefs.active_reorder_selection_id == item_string)
                
                preset_icon = item_to_preset_icon.get(item_string)
                item_row = row.row(align=True)

                if prefs.show_subgroup_icon_menu: 
                    custom_item_data = next((i for i in prefs.custom_item_names if i.identifier == item_string), None)
                    
                    icon_ui_sub = item_row.row(align=True)
                    icon_ui_sub.scale_x = 1.2

                    current_icon = 'NONE'
                    if custom_item_data and custom_item_data.icon != 'NONE':
                        current_icon = custom_item_data.icon
                    
                    op = icon_ui_sub.operator("st.set_item_icon", text="", icon=current_icon if current_icon != 'NONE' else 'DOWNARROW_HLT')
                    op.item_string = item_string
                    
                    item_row.separator(factor=0.5)

                if prefs.show_move_options:
                    op_move_item = item_row.operator("st.call_move_item_menu", text="", icon='ARROW_LEFTRIGHT')
                    op_move_item.item_to_move = item_string
                    op_move_item.source_group_index = prefs.active_group_index
                if prefs.show_remove_options:
                    op_remove = item_row.operator("tab_group.remove_item", text="", icon="X")
                    op_remove.item_to_remove = item_string
                    op_remove.group_index = prefs.active_group_index

                if prefs.use_label_style_ui:
                    item_row.separator()
                    # --- NEW STYLE (Labels) ---
                    if prefs.status_icon_quick:
                        icon_row = item_row.row(align=True)
                        icon_row.separator()
                        if prefs.enable_quick_shortcuts_rcm or prefs.enable_quick_shortcuts_pie:
                            quick_shortcut_list = {
                                    sc.identifier for sc in prefs.quick_shortcuts 
                                    if sc.space_type == prefs.active_management_tab
                                }
                            is_pinned = item_string in quick_shortcut_list
                            op_pin = icon_row.operator("st.toggle_quick_shortcut", text="", icon='PINNED' if is_pinned else 'UNPINNED', emboss=False, depress=is_pinned)
                            op_pin.item_identifier = item_string
                            op_pin.display_name = display_text
                            op_pin.main_group_name = main_group_name
                            op_pin.sub_group_name = sub_group_name_for_pin
                    op_select_item = item_row.operator("tab_group.set_reorder_selection", text="", icon='RADIOBUT_ON' if is_active else 'RADIOBUT_OFF', emboss=False)
                    op_select_item.selection_type = 'ITEM'
                    op_select_item.selection_id = item_string
                    op_select_item.group_index = prefs.active_group_index
                    
                    label_row = item_row.row()
                    if is_active:
                        label_row.prop(prefs, "edit_item_name", text="", emboss=True)
                    else:
                        label_row.label(text=display_text)

                    if prefs.status_icon_fav_panel:
                        icon_row = item_row.row(align=True)
                        if preset_icon:
                            op = icon_row.operator("st.call_item_in_presets_menu", text="", icon=preset_icon, emboss=False)
                            op.item_string = item_string
                            op.group_name = main_group_name
                        else:
                            op_add_fav = icon_row.operator("st.call_add_to_favorite_menu", text="", icon='SOLO_OFF', emboss=False)
                            op_add_fav.group_name = main_group_name
                            op_add_fav.item_string = item_string
                else:
                    # --- OLD STYLE (Buttons) ---
                    icon_row = item_row.row(align=True)
                    if prefs.status_icon_quick:
                        icon_row.separator()
                        if prefs.enable_quick_shortcuts_rcm or prefs.enable_quick_shortcuts_pie:
                            quick_shortcut_list = {
                                    sc.identifier for sc in prefs.quick_shortcuts 
                                    if sc.space_type == prefs.active_management_tab
                                }
                            is_pinned = item_string in quick_shortcut_list
                            op_pin = icon_row.operator("st.toggle_quick_shortcut", text="", icon='PINNED' if is_pinned else 'UNPINNED', emboss=False, depress=is_pinned)
                            op_pin.item_identifier = item_string
                            op_pin.display_name = display_text
                            op_pin.main_group_name = main_group_name
                            op_pin.sub_group_name = sub_group_name_for_pin
                    icon_row.separator()
                    op_select_item = item_row.operator("tab_group.set_reorder_selection", text=display_text, emboss=True, depress=is_active)
                    op_select_item.selection_type = 'ITEM'
                    op_select_item.selection_id = item_string
                    op_select_item.group_index = prefs.active_group_index
                    if prefs.status_icon_fav_panel:
                        icon_row = item_row.row(align=True)
                        icon_row.separator()
                        if preset_icon:
                            op = icon_row.operator("st.call_item_in_presets_menu", text="", icon=preset_icon, emboss=False)
                            op.item_string = item_string
                            op.group_name = main_group_name
                        else:
                            op_add_fav = icon_row.operator("st.call_add_to_favorite_menu", text="", icon='SOLO_OFF', emboss=False)
                            op_add_fav.group_name = main_group_name
                            op_add_fav.item_string = item_string
                    
        elif search_term:
            box.label(text="No items match search.", icon='INFO')
    else:
        Notice_box = edit_col.box()
        Notice_box.alert = True
        Notice_box.scale_y = 1.5
        Notice_box.label(text="Create a group to begin.", icon='WARNING_LARGE')
        
    col_3 = split_2.column(align=True)
    main_group_name_for_active = None
    active_group_state = None
    if 0 <= prefs.active_group_index < len(prefs.tab_groups):
        active_group_for_state = prefs.tab_groups[prefs.active_group_index]
        main_group_name_for_active = active_group_for_state.name.split(" / ")[0]
        if hasattr(context.window_manager, "tab_group_states"):
            active_group_state = context.window_manager.tab_group_states.get(main_group_name_for_active)
            
    if prefs.prefs_section_view == 'PRESET':
        preset_box = col_3.box()
        preset_col = preset_box.column()
        header_row = preset_col.row(align=True)
        header_row.label(text="Favorite Tabs Presets:", icon="SOLO_ON")
        add_row = header_row.row(align=True)
        add_row.scale_x = 0.75
        op_add = add_row.operator("st.add_favorite_preset", text="Add Preset", icon='ADD')
        op_add.group_name = main_group_name_for_active
        op_set = add_row.operator("st.set_favorite_presets_dialog", text="Set Presets", icon='PRESET_NEW')
        op_set.group_name = main_group_name_for_active
        
        header_row.separator()

        if prefs.show_guide:
                op = header_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                op.url = "https://www.notion.so/SUPERTABs-Favorite-Tab-Preset-Guide-N-Panel-v1-1-0-29cb1f0a835380469d1bc23587b6b679?source=copy_link"

        preset_col.separator(factor=0.5)

        if not main_group_name_for_active:
            preset_col.label(text="Select a group to see its presets.", icon='INFO')
        elif prefs.custom_favorite_presets:
            relevant_presets_with_global_index = [
                (i, p) for i, p in enumerate(prefs.custom_favorite_presets) 
                if p.main_group_name == main_group_name_for_active
            ]
            
            col = preset_col.column()
            
            if relevant_presets_with_global_index:
                for i, preset in relevant_presets_with_global_index:
                    global_index = i
                    
                    pre_sub_col = col.column(align=True)
                    row = pre_sub_col.row(align=True)

                    icon = 'DOWNARROW_HLT' if preset.is_expanded_in_prefs else 'RIGHTARROW'
                    op_expand = row.operator("st.toggle_preset_expand", text="", icon=icon)
                    op_expand.preset_index = global_index

                    op_icon = row.operator("st.open_favorite_icon_picker", text="", icon=preset.icon)
                    op_icon.preset_index = global_index

                    # --- Name ---
                    row.prop(preset, "name", text="")
                    
                    # --- Remove Preset (X) ---
                    op_remove = row.operator("st.remove_favorite_preset", text="", icon='X')
                    op_remove.preset_index = global_index 
                    op_remove.group_name = main_group_name_for_active 

                    # --- Reorder Buttons (Up/Down) ---
                    local_index = -1
                    for j, (idx, p) in enumerate(relevant_presets_with_global_index):
                        if idx == global_index:
                            local_index = j
                            break
                    
                    up_row = row.row(align=True)
                    up_row.enabled = local_index > 0 
                    op_up = up_row.operator("st.reorder_preset_in_prefs", text="", icon='TRIA_UP')
                    op_up.preset_index = global_index 
                    op_up.direction = 'UP'
                    
                    down_row = row.row(align=True)
                    down_row.enabled = local_index != -1 and local_index < len(relevant_presets_with_global_index) - 1
                    op_down = down_row.operator("st.reorder_preset_in_prefs", text="", icon='TRIA_DOWN')
                    op_down.preset_index = global_index 
                    op_down.direction = 'DOWN'
                    
                    if preset.is_expanded_in_prefs:
                        item_box = pre_sub_col.box()
                        add_clear_row = item_box.row(align=True)
                        op_add_items = add_clear_row.operator("st.add_items_to_preset_dialog", text="Add Add-ons/Tabs...", icon='PLUS')
                        op_add_items.group_name = main_group_name_for_active
                        op_add_items.preset_name = preset.name
                        # --- Clear Preset (Trash) ---
                        clear_button_row = add_clear_row.row(align=True)
                        clear_button_row.alert = True 
                        op_clear = clear_button_row.operator("st.clear_preset_in_prefs", text="", icon='TRASH')
                        op_clear.preset_index = global_index
                        # item_box.separator(factor=0.25)
                        item_list = [item.strip() for item in preset.items.split(',') if item.strip()]
                        if item_list:
                            item_box_col = item_box.column(align=True)
                            for item_string in sorted(item_list):

                                item_row = item_box_col.row(align=True)

                                display_text = display_name_map.get(item_string, item_string.split(":", 1)[-1])
                                item_row.label(text=display_text, icon='DOT')

                                op_remove_item = item_row.operator("st.remove_item_from_favorite_preset", text="", icon='X', emboss=False)
                                op_remove_item.item_string = item_string
                                op_remove_item.preset_name = preset.name
                                op_remove_item.group_name = main_group_name_for_active
                        else:
                            item_box.label(text="Preset is empty.", icon='INFO')
                    pre_sub_col.separator(factor=0.7)
            else:
                col = preset_col.column()
                col.label(text=f"No presets created for '{main_group_name_for_active}'.")
        else:
            col = preset_box.column()
            col.label(text="No presets created yet.")
            op_add = col.operator("st.add_favorite_preset", text="Add Preset", icon='ADD')
            op_add.group_name = main_group_name_for_active

    elif prefs.prefs_section_view == 'QUICK':
        if prefs.enable_quick_shortcuts_rcm or prefs.enable_quick_shortcuts_pie:
            quick_shortcut = col_3.column(align=True)
            qs_box = quick_shortcut.box()
            qs_box.enabled = ( (prefs.right_click_mode == 'MENU' or prefs.right_click_mode == 'BOTH') and prefs.enable_quick_shortcuts_rcm ) or \
                            ( (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH') and prefs.enable_quick_shortcuts_pie )
            toggle_row = qs_box.row(align=True)
            toggle_row.label(text="Quick Shortcut Management:", icon="PINNED")

            if prefs.show_guide:
                op = toggle_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                op.url = "https://www.notion.so/SUPERTABs-Quick-Shortcuts-Guide-Right-Click-Pie-Menu-v1-1-3-2acb1f0a835380f280d4dceed2bc6567?source=copy_link"

            list_row = qs_box.row()
            list_col = list_row.column()
            list_col.template_list(
                "ST_UL_QuickShortcutsList", 
                "quick_shortcuts_list", 
                prefs, 
                "quick_shortcuts", 
                prefs, 
                "active_quick_shortcut_index",
                rows=6
            )
            
            button_col = list_row.column(align=True)
            # --- Move Up Button ---
            row_up = button_col.row(align=True)
            row_up.enabled = prefs.active_quick_shortcut_index > 0
            move_up = row_up.operator(ST_OT_MoveQuickShortcutItem.bl_idname, text="", icon='TRIA_UP')
            move_up.direction = 'UP'
            # --- Move Down Button ---
            row_down = button_col.row(align=True)
            row_down.enabled = 0 <= prefs.active_quick_shortcut_index < len(prefs.quick_shortcuts) - 1
            move_down = row_down.operator(ST_OT_MoveQuickShortcutItem.bl_idname, text="", icon='TRIA_DOWN')
            move_down.direction = 'DOWN'
            # --- Remove Button ---
            row_remove = button_col.row(align=True)
            row_remove.enabled = 0 <= prefs.active_quick_shortcut_index < len(prefs.quick_shortcuts)
            remove = row_remove.operator(ST_OT_RemoveQuickShortcutItem.bl_idname, text="", icon='X')
            remove.index_to_remove = prefs.active_quick_shortcut_index
        
    elif prefs.prefs_section_view == 'PANEL':
            is_active_item = (prefs.active_reorder_selection_type == 'ITEM')
            if is_active_item:
                panel_list_box = col_3.box()
                item_string = prefs.active_reorder_selection_id
                display_text = prefs.edit_item_name
                hidden_panel_ids = {p.panel_id for p in prefs.hidden_panels}

                panel_list_row = panel_list_box.row(align=True)

                panel_list_row.label(text=f"Sub-Tabs in '{display_text}':") 
                
                if prefs.show_guide:
                    op = panel_list_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                    op.url = "https://www.notion.so/SUPERTABs-Subtabs-Management-Guide-Preferences-v1-2-0-2b7b1f0a8353801292bdc0c2d6df3400?source=copy_link"

                try:
                    target_panels = get_target_panels_for_item(context, item_string, target_space=prefs.active_management_tab)
                    
                    if not target_panels:
                        panel_list_box.label(text="No Sub-Tabs found", icon='INFO')
                    else:
                        panel_list_grid = panel_list_box.grid_flow(columns=2, align=True)
                        
                        seen_labels = set()

                        for panel_cls in target_panels:
                            panel_label = getattr(panel_cls, 'bl_label', panel_cls.__name__)
                            if not panel_label or not panel_label.strip():
                                continue
                            if panel_label in seen_labels:
                                continue
                            seen_labels.add(panel_label)
                            panel_id = getattr(panel_cls, 'bl_idname', panel_cls.__name__)

                            is_visible = panel_id not in hidden_panel_ids
                            icon = 'HIDE_OFF' if is_visible else 'HIDE_ON'
                            op = panel_list_grid.operator(ST_OT_TogglePanelVisibility.bl_idname, 
                                                        text=panel_label, 
                                                        icon=icon, 
                                                        depress=is_visible)
                            op.panel_id = panel_id
                            
                except Exception as e:
                    panel_list_box.label(text=f"Error getting Sub-tabs: {e}", icon='ERROR')

            else:
                panel_list_box = col_3.box()
                panel_list_row = panel_list_box.row(align=True)
                panel_list_row.label(text="Select an Add-on/Item to see its Sub-tabs.", icon='INFO')
                if prefs.show_guide:
                    op = panel_list_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                    op.url = "https://www.notion.so/SUPERTABs-Subtabs-Management-Guide-Preferences-v1-2-0-2b7b1f0a8353801292bdc0c2d6df3400?source=copy_link"

    elif prefs.prefs_section_view == 'NONE':
        assign_col = col_3
        assign_col.operator("tab_group.refresh_available", icon="FILE_REFRESH")
        
        tab_box = assign_col.box()
        if prefs.active_management_tab == 'VIEW_3D':
            tab_box.prop(prefs, "manual_exclude_tabs", text="Hide Tab in Tablists")
        elif prefs.active_management_tab == 'IMAGE_EDITOR':
            tab_box.prop(prefs, "manual_exclude_tabs_image", text="Hide Tab in Tablists")
        elif prefs.active_management_tab == 'NODE_EDITOR':
            tab_box.prop(prefs, "manual_exclude_tabs_node", text="Hide Tab in Tablists")
        
        header_controls_row = tab_box.row(align=True)
        header_controls_row.prop(prefs, "tab_search_query", text="Search Tabs", icon='VIEWZOOM')
        
        assign_button_row = tab_box.row(align=True)
        op = assign_button_row.operator("tab_group.assign_selected", text="Assign")
        op.item_type = "tab"; op.group_index = prefs.active_group_index
        
        tab_box.template_list("AVAILABLE_UL_List", "tab_assignment_list", prefs, "available_tabs", prefs, "active_available_tab_index", rows=prefs.tab_list_display_rows)