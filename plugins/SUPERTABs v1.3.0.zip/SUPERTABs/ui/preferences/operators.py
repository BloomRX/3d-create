import bpy
from ...properties.items import _subgroup_icon_options

class ST_OT_RemoveQuickShortcutItem(bpy.types.Operator):
    """(SUPERTABs) Removes an item from the Quick Shortcuts list"""
    bl_idname = "st.remove_quick_shortcut_item"
    bl_label = "Remove Quick Shortcut"
    bl_options = {'REGISTER'}

    index_to_remove: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        collection = prefs.quick_shortcuts
        
        if 0 <= self.index_to_remove < len(collection):
            collection.remove(self.index_to_remove)
            if prefs.active_quick_shortcut_index == self.index_to_remove:
                prefs.active_quick_shortcut_index = -1
            elif prefs.active_quick_shortcut_index > self.index_to_remove:
                prefs.active_quick_shortcut_index -= 1
        return {'FINISHED'}

class ST_OT_MoveQuickShortcutItem(bpy.types.Operator):
    """(SUPERTABs) Moves a Quick Shortcut item up or down in the list"""
    bl_idname = "st.move_quick_shortcut_item"
    bl_label = "Move Quick Shortcut"
    bl_options = {'REGISTER'}

    direction: bpy.props.EnumProperty(items=[('UP', 'Up', ''), ('DOWN', 'Down', '')])
    
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        collection = prefs.quick_shortcuts
        active_index = prefs.active_quick_shortcut_index
        
        if self.direction == 'UP':
            target_index = active_index - 1
            if active_index > 0:
                collection.move(active_index, target_index)
                prefs.active_quick_shortcut_index = target_index
        elif self.direction == 'DOWN':
            target_index = active_index + 1
            if active_index < len(collection) - 1:
                collection.move(active_index, target_index)
                prefs.active_quick_shortcut_index = target_index
                
        return {'FINISHED'}

class ST_OT_ToggleToolTabLock(bpy.types.Operator):
    """(SUPERTABs) Toggles the lock for 'Tool' tab management, showing a warning."""
    bl_idname = "st.toggle_tool_tab_lock"
    bl_label = "Unlock Tool Management"
    bl_options = {'REGISTER'}

    _warning_head = "WARNING"
    _warning_message_line1 = "It is not recommended to add Tools into Tabgroups."
    _warning_message_line2 = "This may cause the Tool panel in the Properties Editor to disappear."
    _question = "Do you want to unlock?"

    @classmethod
    def poll(cls, context):
        try:
            prefs = context.preferences.addons[__package__.split('.')[0]].preferences
            return hasattr(prefs, 'lock_manage_tool_tab')
        except Exception:
            return False

    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        if prefs.lock_manage_tool_tab:
            return context.window_manager.invoke_props_dialog(self, width=375)
        else:
            prefs.lock_manage_tool_tab = True
            return {'FINISHED'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.lock_manage_tool_tab = False
        self.report({'INFO'}, "Tool tab management unlocked.")
        return {'FINISHED'}
    
    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        alert_col = col.column(align=True)
        alert_col.alert = True
        alert_col.label(text=self._warning_head, icon='WARNING_LARGE')
        alert_col.label(text=self._warning_message_line1)
        alert_col.label(text=self._warning_message_line2)
        col.separator()
        col.label(text=self._question)

class ST_OT_TogglePanelVisibility(bpy.types.Operator):
    """(SUPERTABs) Toggles the visibility of a specific panel"""
    bl_idname = "st.toggle_panel_visibility"
    bl_label = "Toggle Panel Visibility"
    bl_options = {'REGISTER'}

    panel_id: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        hidden_panels = prefs.hidden_panels
        
        found_item = None
        item_index = -1
        
        for i, item in enumerate(hidden_panels):
            if item.panel_id == self.panel_id:
                found_item = item
                item_index = i
                break
        
        if found_item:
            hidden_panels.remove(item_index)
        else:
            new_item = hidden_panels.add()
            new_item.panel_id = self.panel_id
            
        bpy.ops.tab_group.apply_settings('INVOKE_DEFAULT')
        return {'FINISHED'}

class ST_OT_ToggleUVToolTabLock(bpy.types.Operator):
    """(SUPERTABs) Toggles the lock for 'Tool' tab management in UV Editor."""
    bl_idname = "st.toggle_uv_tool_tab_lock"
    bl_label = "Unlock UV Tool Management"
    bl_options = {'REGISTER'}

    _warning_head = "WARNING"
    _warning_message_line1 = "It is not recommended to add Tools into Tabgroups."
    _warning_message_line2 = "This may cause the Tool panel in the UV Editor to disappear."
    _question = "Do you want to unlock?"

    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if prefs.lock_manage_uv_tool_tab:
            return context.window_manager.invoke_props_dialog(self, width=375)
        else:
            prefs.lock_manage_uv_tool_tab = True
            return {'FINISHED'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.lock_manage_uv_tool_tab = False
        self.report({'INFO'}, "UV Tool tab management unlocked.")
        return {'FINISHED'}
    
    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        alert_col = col.column(align=True)
        alert_col.alert = True
        alert_col.label(text=self._warning_head, icon='WARNING_LARGE')
        alert_col.label(text=self._warning_message_line1)
        alert_col.label(text=self._warning_message_line2)
        col.separator()
        col.label(text=self._question)

class ST_OT_ShowImageTabLockWarning(bpy.types.Operator):
    """(SUPERTABs) Shows warning for Image Tab Lock"""
    bl_idname = "st.show_image_tab_lock_warning"
    bl_label = "Image Tab Locked"
    bl_options = {'INTERNAL'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.alert = True
        col.label(text="WARNING: Access Denied", icon='WARNING_LARGE')
        col.separator()
        col.label(text="The Image Tab panels cannot be moved under Supertabs.")
        col.label(text="This is restricted by Blender's internal API limitations.")

    def execute(self, context):
        return {'FINISHED'}

class ST_OT_ToggleNodeGroupTabLock(bpy.types.Operator):
    """(SUPERTABs) Unlock Node Group Tab Management with Warning"""
    bl_idname = "st.toggle_node_group_tab_lock"
    bl_label = "Unlock Group Tab"
    bl_options = {'REGISTER'}

    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if prefs.lock_manage_node_group_tab:
            return context.window_manager.invoke_props_dialog(self, width=450)
        else:
            prefs.lock_manage_node_group_tab = True
            return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        col = layout.column(align=True)
        col.alert = True
        col.label(text="WARNING: Blender 5.0 Limitation", icon='WARNING_LARGE')
        col.separator()
        
        col.label(text="Blender 5.0: Main Tab 'Group'")
        col.label(text="API limitation in 'Group Socket'")
        col.label(text="It cannot follow its main Tab yet")
        
        col.separator()
        col.label(text="Do you still want to unlock?")

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.lock_manage_node_group_tab = False
        return {'FINISHED'}

class ST_OT_PerformSetItemIcon(bpy.types.Operator):
    bl_idname = "st.perform_set_item_icon"
    bl_label = "Set Item Icon"
    bl_options = {'INTERNAL'} 

    item_string: bpy.props.StringProperty()
    icon: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        item = next((i for i in prefs.custom_item_names if i.identifier == self.item_string), None)
        if not item:
            item = prefs.custom_item_names.add()
            item.identifier = self.item_string
            
            default_name = self.item_string.split(":", 1)[-1]
            
            if self.item_string.startswith("addon:"):
                addon_real_name = self.item_string.split(":", 1)[1]
                for lookup in prefs.addon_display_lookup:
                    if lookup.name == addon_real_name:
                        default_name = lookup.display_name
                        break
            
            item.display_name = default_name
        
        item.icon = self.icon
        
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
        return {'FINISHED'}

class ST_OT_PerformSetSubgroupIcon(bpy.types.Operator):
    bl_idname = "st.perform_set_subgroup_icon"
    bl_label = "Set Group Icon"
    bl_options = {'INTERNAL'}

    subgroup_name: bpy.props.StringProperty()
    icon: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        target_group = next((g for g in prefs.tab_groups if g.name == self.subgroup_name), None)
        if target_group:
            target_group.icon = self.icon
            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    area.tag_redraw()
                    
        return {'FINISHED'}

class ST_OT_SetItemIcon(bpy.types.Operator):
    bl_idname = "st.set_item_icon"
    bl_label = "Select Icon"
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = "icon"

    item_string: bpy.props.StringProperty()
    
    icon: bpy.props.EnumProperty(items=_subgroup_icon_options, name="Icon")

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self)
    
    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        grid = layout.grid_flow(row_major=True, columns=8, even_columns=True, align=True)
        
        for item in _subgroup_icon_options:
            identifier = item[0]
            icon_name = item[3] if len(item) > 3 else identifier
            
            op = grid.operator("st.perform_set_item_icon", text="", icon=icon_name)
            op.item_string = self.item_string
            op.icon = identifier
class ST_OT_SetSubgroupIcon(bpy.types.Operator):
    bl_idname = "st.set_subgroup_icon"
    bl_label = "Select Group Icon"
    bl_options = {'REGISTER', 'UNDO'}
    bl_property = "icon"

    subgroup_name: bpy.props.StringProperty()
    icon: bpy.props.EnumProperty(items=_subgroup_icon_options, name="Icon")

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self)

    def execute(self, context):
        return {'FINISHED'}
    
    def draw(self, context):
        layout = self.layout
        grid = layout.grid_flow(row_major=True, columns=8, even_columns=True, align=True)
        
        for item in _subgroup_icon_options:
            identifier = item[0]
            icon_name = item[3] if len(item) > 3 else identifier
            
            op = grid.operator("st.perform_set_subgroup_icon", text="", icon=icon_name)
            op.subgroup_name = self.subgroup_name
            op.icon = identifier