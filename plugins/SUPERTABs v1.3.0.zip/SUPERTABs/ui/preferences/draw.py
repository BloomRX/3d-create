import bpy
from ... import state as st_state 

from .info import draw_info_section
from .settings_io import draw_import_export_section
from .tab_manager import draw_tab_group_management_ui
from .settings_general import draw_general_settings

def draw_preferences_layout(self, context):
    prefs = self
    layout = self.layout
    col = layout.column()

    if st_state.saved_auto_import_enabled is None:
        st_state.saved_auto_import_enabled = prefs.auto_import_enabled
    if st_state.saved_auto_import_filepath is None:
        st_state.saved_auto_import_filepath = prefs.auto_import_filepath
    if st_state.saved_poll_method_exceptions is None:
        st_state.saved_poll_method_exceptions = prefs.poll_method_exceptions
    
    # 1. Info Section (call info.py)
    draw_info_section(col, prefs, context)

    col.separator(factor=0.25)

    # 2. Import/Export Section (call settings_io.py)
    draw_import_export_section(col, prefs, context)

    col.separator(factor=0.25)
    
    # --- Status Bar ---
    unsaved_changes = False
    if prefs.auto_import_enabled != st_state.saved_auto_import_enabled:
        unsaved_changes = True
    if prefs.auto_import_filepath != st_state.saved_auto_import_filepath:
        unsaved_changes = True
    if prefs.poll_method_exceptions != st_state.saved_poll_method_exceptions:
        unsaved_changes = True

    box = col.box()
    row = box.row(align=True)

    ui_applied = getattr(context.window_manager, "st_ui_applied_once", False)

    if st_state.restart_required_for_poll_exceptions:
        row.alert = True
        row.label(text="SUPERTABs Status: Apply/RefreshUI for changes to take effect.", icon='ERROR')
    
    elif unsaved_changes:
        row.alert = True
        row.label(text="SUPERTABs Status: Unsaved settings!", icon='ERROR')
        op = row.operator("st.commit_auto_import_state", text="Save Preferences", icon='FILE_TICK')
    
    elif prefs.status_timer > 0 and prefs.status_message:
        icon = 'INFO'
        if prefs.status_type == 'SUCCESS': icon = 'CHECKMARK'
        elif prefs.status_type == 'WARNING': icon = 'ERROR'; row.alert = True
        elif prefs.status_type == 'ERROR': icon = 'CANCEL'; row.alert = True
        full_message = f"SUPERTABs Status: {prefs.status_message}"
        row.label(text=full_message, icon=icon)
    elif not ui_applied:
        row.label(text="SUPERTABs Status: Ready", icon='CHECKMARK')
    else:
        main_groups = [g for g in prefs.tab_groups if " / " not in g.name]
        count = len(main_groups)
        
        if count == 0:
            row.label(text="SUPERTABs Status: No Supertabs N-Panel Created")
        else:
            names = ", ".join([g.name for g in main_groups])
            if len(names) > 50:
                names = names[:50] + "..."
            row.label(text=f"Supertabs N-panel Created : {count} Tab(s), [{names}]")

    col.separator(factor=0.3)

    # 3. Tab Management Section (call tab_manager.py)
    draw_tab_group_management_ui(col, context)

    # 4. Settings & Hotkeys (call settings_general.py)
    draw_general_settings(col, prefs)