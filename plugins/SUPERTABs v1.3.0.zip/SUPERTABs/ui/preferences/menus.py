import bpy
from .info import DOC_LINKS 

class ST_MT_DocumentationMenu(bpy.types.Menu):
    bl_label = "Documentation Links"
    bl_idname = "ST_MT_DocumentationMenu"

    def draw(self, context):
        layout = self.layout
        for label, url in DOC_LINKS:
            op = layout.operator("wm.url_open", text=label, icon='RIGHTARROW')
            op.url = url

class ST_MT_MoveItemMenu(bpy.types.Menu):
    bl_label = "Move to Group"
    bl_idname = "ST_MT_MoveItemMenu"

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        wm = context.window_manager

        item_to_move = wm.st_item_to_move
        source_index = wm.st_source_group_index_for_move

        if not item_to_move or source_index < 0 or source_index >= len(prefs.tab_groups):
            layout.label(text="No item context.")
            return

        source_group = prefs.tab_groups[source_index]
        source_space = source_group.space_type #

        targets_found = False

        for i, group in enumerate(prefs.tab_groups):
            if i == source_index:
                continue
            
            if group.space_type != source_space:
                continue
            
            targets_found = True
            op = layout.operator("st.move_item_to_group", text=group.name)
            op.item_to_move = item_to_move
            op.source_group_index = source_index
            op.destination_group_index = i

        if not targets_found:
            layout.label(text="No other groups available.", icon='INFO')

class ST_MT_MoveSubgroupMenu(bpy.types.Menu):
    bl_label = "Move to Main Tab"
    bl_idname = "ST_MT_MoveSubgroupMenu"

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        wm = context.window_manager

        subgroup_index = wm.st_subgroup_index_to_move
        
        try:
            current_subgroup = prefs.tab_groups[subgroup_index]
            current_main_name = current_subgroup.name.split(" / ")[0].strip()
            current_space = current_subgroup.space_type #
        except (IndexError, AttributeError):
            layout.label(text="Invalid context.")
            return

        main_group_names = sorted(list({
            g.name.split(" / ")[0].strip() 
            for g in prefs.tab_groups 
            if "/" not in g.name and g.space_type == current_space
        }))

        targets_found = False

        for main_name in main_group_names:
            if main_name == current_main_name:
                continue
            
            targets_found = True
            op = layout.operator("st.move_subgroup_to_main_group", text=main_name)
            op.subgroup_index = subgroup_index
            op.destination_main_group_name = main_name
            
        if not targets_found:
            layout.label(text="No other main groups available.", icon='INFO')