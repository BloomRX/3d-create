# -*- coding: utf-8 -*-

import bpy

# --- Registration ---
# --- Menu Functions ---
def draw_asset_browser_toggle_header(self, context):
    try:
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if prefs.show_asset_browser_button:
            self.layout.operator("st.toggle_asset_browser", text="Asset Browser", icon='ASSET_MANAGER')
    except (KeyError, AttributeError):
        pass

def register_expand_toggles():
    bpy.types.Scene.show_view_properties = bpy.props.BoolProperty(name="Show View Properties", default=False)
    bpy.types.Scene.show_view_lock = bpy.props.BoolProperty(name="Show View Lock", default=False)
    bpy.types.Scene.show_annotations_controls = bpy.props.BoolProperty(name="Show Annotations", default=False)
    bpy.types.Scene.show_3Dcursor = bpy.props.BoolProperty(name="3D Cursor", default=False)

def unregister_expand_toggles():
    props_to_del = ["st_basic_panel_tab", "show_view_properties", "show_view_lock", "show_annotations_controls"]
    for prop in props_to_del:
        if hasattr(bpy.types.Scene, prop):
            delattr(bpy.types.Scene, prop)

def register():
    register_expand_toggles()

    bpy.types.VIEW3D_HT_header.append(draw_asset_browser_toggle_header)
    

def unregister():
    unregister_expand_toggles()
    
    try:
        bpy.types.VIEW3D_HT_header.remove(draw_asset_browser_toggle_header)
    except (ValueError, AttributeError):
        pass