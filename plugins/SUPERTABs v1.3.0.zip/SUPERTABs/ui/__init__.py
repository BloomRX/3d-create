from . import preferences
from . import manager
from . import npanels
from .registration import register, unregister 

classes = (
    *preferences.classes,
    *manager.classes,
    *npanels.classes,
)