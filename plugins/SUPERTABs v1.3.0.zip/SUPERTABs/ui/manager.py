# -*- coding: utf-8 -*-

import bpy
import os
import addon_utils
from .. import state
from ..utils import get_all_addons

# --- Main Draw Functions ---
def draw_addon_list_ui(layout, context):
    """
    Reusable function to draw the list of all addons with a new two-column layout for favorites.
    """
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    
    wrapped_addon_modules = {data['original_class'].__module__ for data in state.managed_panels.values() if data.get('type') == 'MANAGED' and 'original_class' in data}
    
    all_addons_with_modules = get_all_addons()
    fav_set = {f.name for f in prefs.favorite_addons} 
    
    processed_addons = []
    blender_install_path = os.path.normpath(os.path.dirname(bpy.app.binary_path))

    for item_data in all_addons_with_modules:
        mod_name = item_data['mod_name']
        display_name = item_data['display_name']
        module_obj = item_data['module_obj']
        is_favorite = mod_name in fav_set
        is_enabled, _ = addon_utils.check(mod_name)
        origin = 'UNKNOWN'
        module_path = os.path.normpath(module_obj.__file__) if hasattr(module_obj, '__file__') and module_obj.__file__ else None
        
        if module_path and module_path.startswith(blender_install_path):
            origin = 'BLENDER_BUILTIN'
        elif module_path:
            origin = 'USER'

        processed_addons.append({
            'mod_name': mod_name, 'display_name': display_name, 'is_favorite': is_favorite,
            'is_enabled': is_enabled, 'origin': origin
        })

    # --- Apply Filters ---
    filtered_list = processed_addons
    search_query = prefs.addon_search_query.lower()
    if search_query:
        filtered_list = [item for item in filtered_list if search_query in item['display_name'].lower()]
    if prefs.addon_filter_status != 'ALL':
        filtered_list = [item for item in filtered_list if item['is_enabled'] == (prefs.addon_filter_status == 'ENABLED')]
    if prefs.addon_origin_filter != 'ALL':
        filtered_list = [item for item in filtered_list if item['origin'] == prefs.addon_origin_filter]

    # --- Separate into favorites and others ---
    if prefs.addon_filter_favorite:
        favorite_list = sorted([item for item in filtered_list if item['is_favorite']], key=lambda x: x['display_name'].lower())
        other_list = []
    else:
        favorite_list = sorted([item for item in filtered_list if item['is_favorite']], key=lambda x: x['display_name'].lower())
        other_list = sorted([item for item in filtered_list if not item['is_favorite']], key=lambda x: x['display_name'].lower())


    # --- Draw UI ---
    row_op = layout.row(align=True)
    row_op.scale_y = 1.5
    row_op.operator("tab_group.apply_settings", text="Apply / Refresh", icon="CHECKMARK")
    reset_button_row = row_op.row(align=True)
    reset_button_row.alert = True
    reset_button_row.operator("tab_group.reset_ui", icon="X")
    pref_row = row_op.row(align=True)
    pref_row.scale_x = 1.25
    op = pref_row.operator("preferences.addon_show", text="", icon='PREFERENCES')
    op.module = __package__.split('.')[0]

    if prefs.show_guide:
        op = row_op.operator("wm.url_open", text="", icon='QUESTION')
        op.url = "https://www.notion.so/SUPERTABs-Supertabs-Add-ons-Manager-Guide-N-Panel-WIP-29bb1f0a8353802680e7d6989577bfdb?source=copy_link"
    
    row_commons = layout.row(align=True)
    row_commons.operator("st.open_addon_preset_manager", text="Addon Presets", icon='PRESET')
    row_commons.prop(prefs, "addon_filter_favorite", text="Show Only Favorites", icon='SOLO_ON', toggle=True)
    row_filters = row_commons.row(align=True)
    row_filters.prop(prefs, "addon_filter_status", text="")
    row_filters.prop(prefs, "addon_origin_filter", text="")

    row_search = layout.row(align=True)
    row_search.prop(prefs, "addon_search_query", text="", icon='VIEWZOOM')
    
    layout.separator(factor=0.5)

    show_favs = bool(favorite_list)
    show_others = bool(other_list)

    if show_favs and show_others:
        split = layout.split(factor=prefs.favorite_column_split_factor)
        fav_col_layout = split.column(align=True)
        other_col_layout = split.column(align=True)
    elif show_favs:
        fav_col_layout = layout.column(align=True)
        other_col_layout = None
    elif show_others:
        fav_col_layout = None
        other_col_layout = layout.column(align=True)
    else:
        fav_col_layout = None
        other_col_layout = None

    # --- Favorites Column (Left) ---
    if fav_col_layout:
        fav_box = fav_col_layout.box()
        fav_header_row = fav_box.row(align=True)
        fav_header_row.label(text="Favorites", icon='SOLO_ON')
        
        # --- Favorite Column Controls ---
        row_fav_columns = fav_header_row.row(align=True)
        sub_fav = row_fav_columns.row(align=True); sub_fav.enabled = prefs.favorite_addon_list_columns > 1
        op_minus_fav = sub_fav.operator("st.change_favorite_addon_columns", text="", icon='REMOVE'); op_minus_fav.delta = -1
        row_scale = row_fav_columns.row(align=True)
        row_scale.scale_x = 0.25
        row_scale.prop(prefs, "favorite_addon_list_columns", text="")
        sub_fav = row_fav_columns.row(align=True); sub_fav.enabled = prefs.favorite_addon_list_columns < 8
        op_plus_fav = sub_fav.operator("st.change_favorite_addon_columns", text="", icon='ADD'); op_plus_fav.delta = 1

        # --- Favorite Management Buttons ---
        op_row = fav_box.row(align=True)
        op_row.operator("st.clear_enabled_favorites", text="Clear Enabled")
        op_row.operator("st.clear_disabled_favorites", text="Clear Disabled")
        op_row.operator("st.clear_all_favorites", text="Clear All", icon='TRASH')
        
        if favorite_list:
            grid_fav = fav_box.grid_flow(row_major=True, columns=prefs.favorite_addon_list_columns, even_columns=True, align=True)
            for item in favorite_list:
                _draw_single_addon(grid_fav, item, wrapped_addon_modules)
        else:
            fav_box.label(text="No favorite add-ons found.")

    # --- Other Add-ons Column (Right) ---
    if other_col_layout:
        other_box = other_col_layout.box()
        other_header_row = other_box.row(align=True)
        other_header_row.label(text="Add-ons & Extensions", icon='PLUGIN')

        # --- Other Add-ons Column Controls ---
        row_columns = other_header_row.row(align=True)
        sub = row_columns.row(align=True); sub.enabled = prefs.addon_list_columns > 1
        op_minus = sub.operator("st.change_addon_columns", text="", icon='REMOVE'); op_minus.delta = -1
        row_scale = row_columns.row(align=True)
        row_scale.scale_x = 0.25
        row_scale.prop(prefs, "addon_list_columns", text="")
        sub = row_columns.row(align=True); sub.enabled = prefs.addon_list_columns < 8
        op_plus = sub.operator("st.change_addon_columns", text="", icon='ADD'); op_plus.delta = 1

        if other_list:
            grid_other = other_box.grid_flow(row_major=True, columns=prefs.addon_list_columns, even_columns=True, align=True)
            for item in other_list:
                _draw_single_addon(grid_other, item, wrapped_addon_modules)
        elif not favorite_list:
             other_box.label(text="No Add-ons found matching criteria.")
        else:
            other_box.label(text="No other add-ons found.")
            
    if not fav_col_layout and not other_col_layout and not favorite_list:
        layout.label(text="No Add-ons found matching criteria.")

# --- Helper Function for Drawing ---
def _draw_single_preset(parent_layout, item, wrapped_addon_modules, preset_index):
    """Helper function to draw a single addon item to avoid code duplication."""
    box = parent_layout.box()
    col = box.column(align=True)
    row = col.row(align=True)
    if not item['is_enabled']:
        row.alert = True

    toggle_row = row.row(align=True)
    is_wrapped = any(mod.startswith(item['mod_name']) for mod in wrapped_addon_modules)
    if item['is_enabled'] and is_wrapped:
        toggle_row.enabled = False
    op_toggle = toggle_row.operator("st.toggle_addon_enabled", text=item['display_name'], icon='CHECKBOX_HLT' if item['is_enabled'] else 'CHECKBOX_DEHLT')
    op_toggle.modname = item['mod_name']
    op_toggle.enable = not item['is_enabled']

    op_remove = row.operator("st.remove_addon_from_preset", text="", icon='X', emboss=True)
    op_remove.addon_name = item['mod_name']
    op_remove.preset_index = preset_index

def _draw_single_addon(parent_layout, item, wrapped_addon_modules):
    """Helper function to draw a single addon item to avoid code duplication."""
    box = parent_layout.box()
    col = box.column(align=True)
    row = col.row(align=True)
    if not item['is_enabled']:
        row.alert = True

    op_preset = row.operator("st.call_add_to_preset_menu", text="", icon='ADD')
    op_preset.addon_name = item['mod_name']
    
    op_fav = row.operator("st.toggle_favorite_addon", text="", icon='SOLO_ON' if item['is_favorite'] else 'SOLO_OFF', emboss=True)
    op_fav.modname = item['mod_name']

    toggle_row = row.row(align=True)
    is_wrapped = any(mod.startswith(item['mod_name']) for mod in wrapped_addon_modules)
    if item['is_enabled'] and is_wrapped:
        toggle_row.enabled = False
    op_toggle = toggle_row.operator("st.toggle_addon_enabled", text=item['display_name'], icon='CHECKBOX_HLT' if item['is_enabled'] else 'CHECKBOX_DEHLT')
    op_toggle.modname = item['mod_name']
    op_toggle.enable = not item['is_enabled']
    
    op_prefs = row.operator("preferences.addon_show", text="", icon='TOOL_SETTINGS', emboss=True)
    op_prefs.module = item['mod_name']

# --- Addon Preset ---
class ST_PT_AddonPresetManager(bpy.types.Panel):
    bl_label = "Addon Preset Manager"
    bl_idname = "ST_PT_AddonPresetManager"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 25

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        header_row = layout.row(align=True)
        header_row.label(text="Manage your addon presets.")
        header_row.operator("st.create_addon_preset", text="Create New Preset", icon='ADD')
        
        layout.separator()

        if not prefs.addon_presets:
            layout.label(text="No presets found. Click 'Create' to start.")
            return
        
        all_addons = get_all_addons()
        display_name_map = {addon['mod_name']: addon['display_name'] for addon in all_addons}

        wrapped_addon_modules = {data['original_class'].__module__ for data in state.managed_panels.values() if data.get('type') == 'MANAGED'}
        fav_set = {f.name for f in prefs.favorite_addons}
            
        for i, preset in enumerate(prefs.addon_presets):
            box = layout.box()
            
            header = box.row()
            header.prop(preset, "name", text="")
            op_del = header.operator("st.delete_addon_preset", text="", icon='TRASH', emboss=False)
            op_del.preset_index = i

            action_row = box.row(align=True)
            action_row.scale_y = 1.2
            op_enable = action_row.operator("st.enable_preset_addons", text="Enable All", icon='CHECKBOX_HLT')
            op_enable.preset_index = i

            is_any_addon_managed = False
            for addon_item in preset.addons:
                if any(mod.startswith(addon_item.name) for mod in wrapped_addon_modules):
                    is_any_addon_managed = True
                    break 

            disable_row = action_row.row(align=True)
            disable_row.enabled = not is_any_addon_managed 

            op_disable = disable_row.operator("st.disable_preset_addons", text="Disable All", icon='CHECKBOX_DEHLT')
            op_disable.preset_index = i
            
            if preset.addons:
                grid = box.grid_flow(row_major=True, columns=2, even_columns=True, align=True)
                for addon_item in preset.addons:
                    mod_name = addon_item.name
                    is_enabled, _ = addon_utils.check(mod_name)
                    
                    item_data = {
                        'mod_name': mod_name,
                        'display_name': display_name_map.get(mod_name, mod_name),
                        'is_enabled': is_enabled,
                        'is_favorite': mod_name in fav_set
                    }
                    
                    _draw_single_preset(grid, item_data, wrapped_addon_modules, i)
            else:
                box.label(text="This preset is empty.")

class ST_MT_AddToPresetMenu(bpy.types.Menu):
    bl_label = "Add to Preset"
    bl_idname = "ST_MT_AddToPresetMenu"

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        # --- Get addon name from the context/operator properties if available ---
        addon_name_to_add = getattr(context.window_manager, "st_addon_name_to_add", "")
        if not addon_name_to_add:
            layout.label(text="No Addon Context")
            return

        if not prefs.addon_presets:
            layout.label(text="No Presets Created")
            return

        for i, preset in enumerate(prefs.addon_presets):
            op = layout.operator("st.add_addon_to_preset", text=preset.name)
            op.addon_name = addon_name_to_add
            op.preset_index = i

# --- Registration ---
classes = (
    ST_MT_AddToPresetMenu,
    ST_PT_AddonPresetManager,
)