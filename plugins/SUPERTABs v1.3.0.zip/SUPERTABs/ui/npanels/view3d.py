import bpy
import bmesh
import addon_utils
from ...properties import _restricted_icon_enum_items
from ...utils import get_selected_curve_points

# Helper Functions
def _draw_edit_normal_panel(edit_col, context):
    if not context.object or context.object.type not in {'MESH', 'CURVE'}:
        return
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    if prefs.show_normal_section:
        edit_normal_box = edit_col.box()
        edit_normal_box.prop(prefs, "show_normal_panel", text="Normal", icon="DOWNARROW_HLT" if prefs.show_normal_panel else "RIGHTARROW", emboss=False)

        if prefs.show_normal_panel:
            edit_normal_row = edit_normal_box.row(align=True)

            if context.object.type == 'MESH':
                if context.mode == 'EDIT_MESH':
                    op_fix = edit_normal_row.operator("mesh.normals_make_consistent", text="Recalculate Normal")
                    op_fix.inside = False
                    scale_row = edit_normal_row.row(align=True)
                    scale_row.scale_x = 0.6
                    scale_row.operator("mesh.flip_normals", text="Flip Normals", icon="FILE_REFRESH")
                else:
                    edit_normal_row.operator("st.mesh_recalc_normals_object", text="Recalculate Normal")
                    scale_row = edit_normal_row.row(align=True)
                    scale_row.scale_x = 0.6
                    scale_row.operator("st.mesh_flip_normals_object", text="Flip Normals", icon="FILE_REFRESH")
            elif context.object and context.object.type == 'CURVE':
                if context.mode == 'EDIT_CURVE':
                    edit_normal_row.operator("curve.normals_make_consistent", text="Recalculate Handle")
                else:
                    edit_normal_row.operator("st.curve_recalc_handles", text="Recalculate Handle")

def _draw_curve_data_panel(edit_col, context):
    obj = context.object
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    edit_curve_data = edit_col.box()
    edit_curve_data.prop(prefs, "show_curve_panel",text="Curve Data",icon="DOWNARROW_HLT" if prefs.show_curve_panel else "RIGHTARROW",emboss=False)

    if prefs.show_curve_panel:
        data = obj.data
        edit_curve_col = edit_curve_data.column(align=True)
        shape_box = edit_curve_col.box()
        shape_row = shape_box.row(align=True)
        shape_row.prop(prefs, "show_shape_data",text="",icon="TRIA_DOWN" if prefs.show_shape_data else "TRIA_RIGHT",emboss=False)
        shape_row.label(text="Shape")
        
        if prefs.show_shape_data:
            shape_col = shape_box.column(align=True)
            shape_row = shape_col.row(align=True)
            shape_row.prop(data, "dimensions", text=" ", expand=True)
            shape_col.separator()
            shape_col.prop(data, "resolution_u" , text="Resolution Preview U")
            shape_col.prop(data, "render_resolution_u", text="Render U")
            shape_col.separator()
            shape_row = shape_col.row(align=True)
            shape_row.prop(prefs, "show_shape_twist", text="",icon="DOWNARROW_HLT" if prefs.show_shape_twist else "RIGHTARROW",emboss=False)
            shape_row.label(text="Twist")
            if prefs.show_shape_twist:
                twist_col = shape_col.column()
                twist_box = twist_col.box()
                twist_col = twist_box.column(align=True)
                twist_col.prop(data, "twist_mode")

                twist_row = twist_col.row(align=True)
                twist_row.label(text="")
                row_scale = twist_row.row(align=True)
                row_scale.scale_x = 1.75
                row_scale.prop(data, "twist_smooth")
                twist_col.separator()

                twist_col.prop(data, "fill_mode")
                twist_col.separator()

                twist_row = twist_col.row(align=True)
                twist_row.prop(data, "use_radius")
                twist_row.prop(data, "use_stretch")
                twist_row.prop(data, "use_deform_bounds")

        geo_box = edit_curve_col.box()
        geo_row = geo_box.row(align=True)
        geo_row.prop(prefs, "show_geometry_data",text="",icon="TRIA_DOWN" if prefs.show_geometry_data else "TRIA_RIGHT",emboss=False)
        geo_row.label(text="Geometry")

        if prefs.show_geometry_data:
            geo_col = geo_box.column()
            sub_col = geo_col.column(align=True)
            sub_col.prop(data, "offset", text="Offset")
            sub_col.prop(data, "extrude", text="Extrude")
            geo_row = geo_col.row(align=True)
            geo_row.prop(prefs, "show_geo_taper", text="",icon="DOWNARROW_HLT" if prefs.show_geo_taper else "RIGHTARROW",emboss=False)
            geo_row.label(text="Taper")

            if prefs.show_geo_taper:
                taper_box = geo_col.box()
                taper_col = taper_box.column()
                taper_col.prop(data, "taper_object", text="Taper Object")
                taper_col.prop(data, "taper_radius_mode", text="Taper Radius")
                taper_col.prop(data, "use_map_taper", text="Map Taper")

            bevel_row = geo_col.row(align=True)
            bevel_row.prop(prefs, "show_bevel_data",text="",icon="DOWNARROW_HLT" if prefs.show_bevel_data else "RIGHTARROW",emboss=False)
            bevel_row.label(text="Bevel")
            if prefs.show_bevel_data:
                bevel_box = geo_col.box()
                bevel_col = bevel_box.column(align=True)
                bevel_row = bevel_col.row(align=True)
                bevel_row.prop(data, "bevel_mode", text=" ", expand=True)

                bevel_col.separator()
                if data.bevel_mode == 'OBJECT':
                    bevel_col.prop(data, "bevel_object", text="Object")
                else :
                    bevel_col.prop(data, "bevel_depth", text="Depth")
                    bevel_col.prop(data, "bevel_resolution", text="Resolution")
                bevel_col.prop(data, "use_fill_caps", text="Fill Caps")
                    
                if data.bevel_mode == 'PROFILE':
                    bevel_col.template_curveprofile(data, "bevel_profile")
            
            sem_col = geo_col.column()
            sem_row = sem_col.row(align=True)
            sem_row.prop(prefs, "start_end_map",text="",icon="DOWNARROW_HLT" if prefs.start_end_map else "RIGHTARROW",emboss=False)
            sem_row.label(text="Start & End Mapping")
            if prefs.start_end_map:
                sem_col.active = (
                    ((data.bevel_depth > 0.0) or (data.extrude > 0.0)) or
                    ((data.bevel_mode == 'OBJECT') and data.bevel_object is not None))

                sem_box = sem_col.box()
                sub_col = sem_box.column()
                sem_row = sub_col.row(align=True)
                sem_row.label(text="Factor Start")
                row_scale = sem_row.row(align=True)
                row_scale.scale_x = 1.75
                row_scale.prop(data, "bevel_factor_start", text="")

                sem_row = sub_col.row(align=True)
                sem_row.label(text="End")
                row_scale = sem_row.row(align=True)
                row_scale.scale_x = 1.75
                row_scale.prop(data, "bevel_factor_end", text="")

                sub_col.prop(data, "bevel_factor_mapping_start", text="Mapping Start")
                sub_col.prop(data, "bevel_factor_mapping_end", text="End")

def _draw_transform_ui(parent_layout, data_source, context):
    """Helper function to draw Location, Rotation, Scale, and Dimension UI."""
    main_column_layout = parent_layout.column(align=True)
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences

    if prefs.show_object_name_row:
        name_box = main_column_layout.box()
        name_col = name_box.column(align=True)

        name_data_row = name_col.row(align=True)
        name_data_row.prop(data_source, "name", text="", icon='OBJECT_DATA')
        
        if data_source.data:
            op = name_data_row.operator("st.copy_object_name_to_data_name", text="", icon='COPYDOWN')

            ICON_MAP = {
                'MESH': 'OUTLINER_DATA_MESH',
                'CURVE': 'OUTLINER_DATA_CURVE',
                'SURFACE': 'OUTLINER_DATA_SURFACE',
                'META': 'OUTLINER_DATA_META',
                'FONT': 'OUTLINER_DATA_FONT',
                'ARMATURE': 'OUTLINER_DATA_ARMATURE',
                'LATTICE': 'OUTLINER_DATA_LATTICE',
                'EMPTY': 'OUTLINER_OB_EMPTY',
                'LIGHT': 'OUTLINER_DATA_LIGHT',
                'CAMERA': 'OUTLINER_DATA_CAMERA',
                'SPEAKER': 'OUTLINER_DATA_SPEAKER',
            }
            icon = ICON_MAP.get(data_source.type, 'OBJECT_DATA')

            name_data_row.prop(data_source.data, "name", text="", icon=icon)

        toggle_row = name_data_row.row(align=True)
        toggle_row.operator("st.show_active_in_outliner", text="", icon='VIEWZOOM')
        toggle_row.operator("st.viewport_display_popover", text="", icon='DOWNARROW_HLT')
        
    top_split = main_column_layout.split(factor=0.5, align=True)

    # --- Location ---
    loc_box = top_split.box()
    loc_col = loc_box.column(align=True)
    loc_col.label(text="Location")
    split = loc_col.split(align=True, factor=0.85)
    split.prop(data_source, "location", index=0, text="X")
    split.prop(data_source, "lock_location", index=0, text="")
    split = loc_col.split(align=True, factor=0.85)
    split.prop(data_source, "location", index=1, text="Y")
    split.prop(data_source, "lock_location", index=1, text="")
    split = loc_col.split(align=True, factor=0.85)
    split.prop(data_source, "location", index=2, text="Z")
    split.prop(data_source, "lock_location", index=2, text="")

    # --- Rotation ---
    rot_box = top_split.box()
    rot_col = rot_box.column(align=True)
    rot_section_row = rot_col.row(align=True)
    rot_section_row.label(text="Rotation")
    if context.object.rotation_mode in ("QUATERNION", "AXIS_ANGLE"):
        right_row = rot_section_row.row()
        right_row.alignment = 'RIGHT'
        right_row.prop(data_source, "lock_rotations_4d", text="4L", toggle=True)

    if context.object.rotation_mode == "QUATERNION":
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_quaternion", index=0, text="W")
        if data_source.lock_rotations_4d:
            split.prop(data_source, "lock_rotation_w", text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_quaternion", index=1, text="X")
        split.prop(data_source, "lock_rotation", index=0, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_quaternion", index=2, text="Y")
        split.prop(data_source, "lock_rotation", index=1, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_quaternion", index=3, text="Z")
        split.prop(data_source, "lock_rotation", index=2, text="")
    elif context.object.rotation_mode == "AXIS_ANGLE":
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_axis_angle", index=0, text="W")
        if data_source.lock_rotations_4d:
            split.prop(data_source, "lock_rotation_w", text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_axis_angle", index=1, text="X")
        split.prop(data_source, "lock_rotation", index=0, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_axis_angle", index=2, text="Y")
        split.prop(data_source, "lock_rotation", index=1, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_axis_angle", index=3, text="Z")
        split.prop(data_source, "lock_rotation", index=2, text="")
    else :
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_euler", index=0, text="X")
        split.prop(data_source, "lock_rotation", index=0, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_euler", index=1, text="Y")
        split.prop(data_source, "lock_rotation", index=1, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_euler", index=2, text="Z")
        split.prop(data_source, "lock_rotation", index=2, text="")
    
    bottom_split = main_column_layout.split(factor=0.5, align=True)

    # --- Scale ---
    scale_box = bottom_split.box()
    scale_col = scale_box.column(align=True)
    scale_col.label(text="Scale")
    split = scale_col.split(align=True, factor=0.85)
    split.prop(data_source, "scale", index=0, text="X")
    split.prop(data_source, "lock_scale", index=0, text="")
    split = scale_col.split(align=True, factor=0.85)
    split.prop(data_source, "scale", index=1, text="Y")
    split.prop(data_source, "lock_scale", index=1, text="")
    split = scale_col.split(align=True, factor=0.85)
    split.prop(data_source, "scale", index=2, text="Z")
    split.prop(data_source, "lock_scale", index=2, text="")

    # --- Dimensions ---
    dim_box = bottom_split.box()
    dim_col = dim_box.column(align=True)
    dim_col.label(text="Dimension")

    tool_props = context.scene.my_live_data_tool

    dim_col.prop(tool_props, "proxy_dimensions", index=0, text="X")
    dim_col.prop(tool_props, "proxy_dimensions", index=1, text="Y")
    dim_col.prop(tool_props, "proxy_dimensions", index=2, text="Z")
    
    if hasattr(data_source, "rotation_mode"):
        rotation_mode_layout = main_column_layout.box()
        rotation_mode_layout.prop(data_source, "rotation_mode", text="Rotation Mode")

    obj = context.object
    if prefs.show_curve_section:
        if obj.type =='CURVE':
            col = main_column_layout.column()
            col.separator(factor=0.1)
            _draw_curve_data_panel(col, context)
        if prefs.show_normal_section:
            _draw_edit_normal_panel(main_column_layout, context)
            
def _draw_pose_bone_transform_ui(parent_layout, data_source, context):
    """Helper function to draw Location, Rotation, and Scale UI for a PoseBone."""
    main_column_layout = parent_layout.column(align=True)
    
    top_split = main_column_layout.split(factor=0.5, align=True)

    # --- Location ---
    loc_box = top_split.box()
    loc_col = loc_box.column(align=True)
    loc_col.label(text="Location")
    split = loc_col.split(align=True, factor=0.85)
    split.prop(data_source, "location", index=0, text="X")
    split.prop(data_source, "lock_location", index=0, text="")
    split = loc_col.split(align=True, factor=0.85)
    split.prop(data_source, "location", index=1, text="Y")
    split.prop(data_source, "lock_location", index=1, text="")
    split = loc_col.split(align=True, factor=0.85)
    split.prop(data_source, "location", index=2, text="Z")
    split.prop(data_source, "lock_location", index=2, text="")

    # --- Rotation ---
    rot_box = top_split.box()
    rot_col = rot_box.column(align=True)
    rot_section_row = rot_col.row(align=True)
    rot_section_row.label(text="Rotation")
    if data_source.rotation_mode in ("QUATERNION", "AXIS_ANGLE"):
        right_row = rot_section_row.row()
        right_row.alignment = 'RIGHT'
        right_row.prop(data_source, "lock_rotations_4d", text="4L", toggle=True)

    if data_source.rotation_mode == "QUATERNION":
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_quaternion", index=0, text="W")
        if data_source.lock_rotations_4d:
            split.prop(data_source, "lock_rotation_w", text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_quaternion", index=1, text="X")
        split.prop(data_source, "lock_rotation", index=0, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_quaternion", index=2, text="Y")
        split.prop(data_source, "lock_rotation", index=1, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_quaternion", index=3, text="Z")
        split.prop(data_source, "lock_rotation", index=2, text="")
    elif data_source.rotation_mode == "AXIS_ANGLE":
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_axis_angle", index=0, text="W")
        if data_source.lock_rotations_4d:
            split.prop(data_source, "lock_rotation_w", text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_axis_angle", index=1, text="X")
        split.prop(data_source, "lock_rotation", index=0, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_axis_angle", index=2, text="Y")
        split.prop(data_source, "lock_rotation", index=1, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_axis_angle", index=3, text="Z")
        split.prop(data_source, "lock_rotation", index=2, text="")
    else: # EULER
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_euler", index=0, text="X")
        split.prop(data_source, "lock_rotation", index=0, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_euler", index=1, text="Y")
        split.prop(data_source, "lock_rotation", index=1, text="")
        split = rot_col.split(align=True, factor=0.85)
        split.prop(data_source, "rotation_euler", index=2, text="Z")
        split.prop(data_source, "lock_rotation", index=2, text="")
    
    # --- Scale ---
    scale_box = main_column_layout.box()
    scale_col = scale_box.column(align=True)
    scale_col.label(text="Scale")
    split = scale_col.split(align=True, factor=0.85)
    split.prop(data_source, "scale", index=0, text="X")
    split.prop(data_source, "lock_scale", index=0, text="")
    split = scale_col.split(align=True, factor=0.85)
    split.prop(data_source, "scale", index=1, text="Y")
    split.prop(data_source, "lock_scale", index=1, text="")
    split = scale_col.split(align=True, factor=0.85)
    split.prop(data_source, "scale", index=2, text="Z")
    split.prop(data_source, "lock_scale", index=2, text="")


    rotation_mode_layout = main_column_layout.box()
    rotation_mode_layout.prop(data_source, "rotation_mode", text="Rotation Mode")

def _draw_edit_curve_data_panel(layout, context):
    """Helper function to draw the Curve Edit Data panel UI."""
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    tool_props = context.scene.my_live_data_tool
    
    from ...utils import get_selected_curve_points
    selected_points = get_selected_curve_points(context)
    num_selected = len(selected_points)

    if num_selected == 0:
        layout.label(text="No points selected.")
        return
    
    loc_box = layout.box()
    col = loc_box.column()
    col.label(text="Median:" if num_selected > 1 else "Control Point:")
    
    vec_col = col.column()
    vec_col.use_property_split = True
    vec_col.use_property_decorate = False
    vec_col.prop(tool_props, "curve_median_vector", text="")
    
    row = col.row(align=True)
    row.prop(tool_props, "space_mode", expand=True)


    data_box = layout.box()
    col = data_box.column()
    
    data_props_col = col.column(align=True)
    

    split = data_props_col.split(factor=0.4, align=True) 
    split.label(text="Mean Weight" if num_selected > 1 else "Weight") 
    split.prop(tool_props, "curve_mean_weight", text="") 


    split = data_props_col.split(factor=0.4, align=True)
    split.label(text="Mean Radius" if num_selected > 1 else "Radius")
    split.prop(tool_props, "curve_mean_radius", text="")

    split = data_props_col.split(factor=0.4, align=True)
    split.label(text="Mean Tilt" if num_selected > 1 else "Tilt")
    split.prop(tool_props, "curve_mean_tilt", text="")

    if prefs.show_curve_section:
        _draw_curve_data_panel(layout, context)
    if prefs.show_normal_section:
        _draw_edit_normal_panel(layout, context)

def _draw_edit_mesh_data_panel(layout, context):
    """Helper function to draw the Live Edit Data panel UI."""
    tool_props = context.scene.my_live_data_tool
    obj = context.edit_object
    if not obj: return

    def _draw_quick_set_buttons(parent_layout, op_idname, data_type_str):
        row = parent_layout.row(align=True)
        for i in range(5):
            val = i * 0.25
            op = row.operator(op_idname, text=f"{val:g}")
            op.data_type = data_type_str
            op.value = val

    bm = bmesh.from_edit_mesh(obj.data)
    selected_verts = [v for v in bm.verts if v.select]
    num_selected_verts = len(selected_verts)

    if not selected_verts:
        layout.label(text="Nothing selected.")
        return

    # --- Transform Section ---
    col = layout.column()
    col.label(text="Median:" if len(selected_verts) > 1 else "Vertex:")

    vec_col = col.column()
    vec_col.use_property_split = True
    vec_col.use_property_decorate = False
    vec_col.prop(tool_props, "median_vector", text="")

    row = col.row(align=True)
    row.prop(tool_props, "space_mode", expand=True)

    

    # --- Vertices Data Section ---
    box = layout.box()
    col = box.column()
    row = col.row()
    row.label(text="Vertices Data:")
    quick_row = row.row(align=True)
    quick_row.scale_x = 0.5 
    quick_row.prop(tool_props, "show_quick_set",text="Quick",icon="GESTURE_ROTATE", toggle=True)
    col.use_property_split = True
    col.use_property_decorate = False
    col.prop(tool_props, "vert_bevel", text="Mean Bevel" if num_selected_verts > 1 else "Bevel")
    col.prop(tool_props, "vert_crease", text="Mean Crease" if num_selected_verts > 1 else "Crease")

    if tool_props.show_quick_set:
        quick_set_box = col.box()
        quick_col = quick_set_box.column(align=True)
        
        bevel_row = quick_col.row()
        bevel_row.label(text="Bevel:")
        _draw_quick_set_buttons(bevel_row, "st.set_live_data_value", 'VERT_BEVEL')

        crease_row = quick_col.row()
        crease_row.label(text="Crease:")
        _draw_quick_set_buttons(crease_row, "st.set_live_data_value", 'VERT_CREASE')

    # --- Edges Data Section ---
    selected_edges = [e for e in bm.edges if e.select]
    if selected_edges:
        box = layout.box()
        col = box.column()
        col.label(text="Edge Data:")
        col.use_property_split = True
        col.use_property_decorate = False
        num_selected_edges = len(selected_edges)
        col.prop(tool_props, "edge_bevel", text="Mean Bevel" if num_selected_edges > 1 else "Bevel")
        col.prop(tool_props, "edge_crease", text="Mean Crease" if num_selected_edges > 1 else "Crease")

        if tool_props.show_quick_set:
            quick_set_box = col.box()
            quick_col = quick_set_box.column(align=True)

            bevel_row = quick_col.row()
            bevel_row.label(text="Bevel:")
            _draw_quick_set_buttons(bevel_row, "st.set_live_data_value", 'EDGE_BEVEL')

            crease_row = quick_col.row()
            crease_row.label(text="Crease:")
            _draw_quick_set_buttons(crease_row, "st.set_live_data_value", 'EDGE_CREASE')

    prefs = context.preferences.addons[__package__.split('.')[0]].preferences        
    if prefs.show_normal_section:
        _draw_edit_normal_panel(layout, context)

# Main Draw Functions for 3D View
def draw_basic_panel_view3d(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    scene = context.scene
    obj = context.object
    space_data = context.space_data
    col = layout.column()
    main_row = col.row(align=True)
    if context.space_data.type == 'VIEW_3D':
        if prefs.show_transform_section:
            main_row.prop(prefs, "show_transform_panel", text="Transform", toggle=True)
            if prefs.show_transform_panel:
                if obj:
                    if obj.mode == 'OBJECT':
                        transform_box = layout.box()
                        _draw_transform_ui(transform_box, obj, context)

                    elif obj.mode == 'EDIT':
                        if obj.type == 'MESH':
                            _draw_edit_mesh_data_panel(layout, context)
                        
                        elif obj.type == 'CURVE':
                            _draw_edit_curve_data_panel(layout, context)

                        elif obj.type == 'ARMATURE':
                            transform_box = layout.box()
                            active_bone = obj.data.edit_bones.active
                            if active_bone:
                                col = transform_box.column(align=True)
                                
                                # --- Head & Tail ---
                                head_tail_row = col.row(align=True)
                                
                                # --- Box Head ---
                                head_box = head_tail_row.box()
                                head_col = head_box.column(align=True)
                                head_col.label(text="Head")
                                head_col.prop(active_bone, "head", text="")
                                head_col.prop(active_bone, "head_radius", text="Radius")

                                # --- Box Tail ---
                                tail_box = head_tail_row.box()
                                tail_col = tail_box.column(align=True)
                                tail_col.label(text="Tail")
                                tail_col.prop(active_bone, "tail", text="")
                                tail_col.prop(active_bone, "tail_radius", text="Radius")

                                props_col = col.column(align=True)
                                props_col.prop(active_bone, "roll", text="Roll")
                                props_col.prop(active_bone, "length", text="Length")
                                props_col.prop(active_bone, "envelope_distance", text="Envelope")
                                
                            else:
                                transform_box.label(text="Select a bone in Edit Mode.")
                        else:
                            layout.label(text="Transform data available in Object Mode.")

                    elif obj.mode == 'POSE' and obj.type == 'ARMATURE':
                        transform_box = layout.box()
                        active_pose_bone = context.active_pose_bone
                        if active_pose_bone:
                            _draw_pose_bone_transform_ui(transform_box, active_pose_bone, context)
                        else:
                            transform_box.label(text="Select a bone in Pose Mode.")
                    
                    else:
                        transform_box = layout.box()
                else:
                    layout.label(text="No object selected.")

        if prefs.show_view_section:
            main_row.prop(prefs, "show_view_panel", text="View", toggle=True)
            if prefs.show_view_panel:
                view_box = layout.box()
                if space_data and space_data.type == 'VIEW_3D':
                    view_content_box = view_box.column()
                    
                    view_props_box = view_content_box.box()
                    row = view_props_box.row(align=True)
                    row.prop(scene, "show_view_properties", icon="DOWNARROW_HLT" if scene.show_view_properties else "RIGHTARROW", text="View", emboss=False)
                    # row.label(text="View")
                    if scene.show_view_properties:
                        view_props_box.use_property_split = True
                        view_props_box.use_property_decorate = False
                        view = context.space_data
                        col = view_props_box.column()
                        subcol = col.column()
                        subcol.active = bool(view.region_3d.view_perspective != 'CAMERA' or view.region_quadviews)
                        subcol.prop(view, "lens", text="Focal Length")
                        subcol = col.column(align=True)
                        subcol.prop(view, "clip_start", text="Clip Start")
                        subcol.prop(view, "clip_end", text="End")
                        view_props_box.separator()
                        col = view_props_box.column(align=False, heading="Local Camera")
                        col.use_property_decorate = False
                        row = col.row(align=True)
                        sub = row.row(align=True)
                        sub.prop(view, "use_local_camera", text="")
                        sub = sub.row(align=True)
                        sub.enabled = view.use_local_camera
                        sub.prop(view, "camera", text="")
                        sub = col.row()
                        sub.active = view.region_3d.view_perspective == 'CAMERA'
                        sub.prop(view.overlay, "show_camera_passepartout", text="Passepartout")
                        col = view_props_box.column(align=True)
                        col.prop(view, "use_render_border")
                        col.active = view.region_3d.view_perspective != 'CAMERA'

                        lock_box = view_props_box.box()
                        row = lock_box.row(align=True)
                        row.prop(scene, "show_view_lock", icon="DOWNARROW_HLT" if scene.show_view_lock else "RIGHTARROW", text="", emboss=False)
                        row.label(text="View Lock")
                        if scene.show_view_lock:
                            lock_box.use_property_split = True
                            lock_box.use_property_decorate = False
                            view = context.space_data
                            col = lock_box.column(align=True)
                            sub = col.column()
                            sub.active = bool(view.region_3d.view_perspective != 'CAMERA' or view.region_quadviews)
                            sub.prop(view, "lock_object")
                            if lock_object := view.lock_object:
                                if lock_object.type == 'ARMATURE':
                                    sub.prop_search(view, "lock_bone", lock_object.data, "edit_bones" if lock_object.mode == 'EDIT' else "bones", text="Bone")
                            col = lock_box.column(heading="Lock", align=True)
                            if not lock_object:
                                col.prop(view, "lock_cursor", text="To 3D Cursor")
                            col.prop(view, "lock_camera", text="Camera to View")
                            col.prop(view.region_3d, "lock_rotation", text="Rotation")

                    cursor_box = view_content_box.box()
                    row = cursor_box.row(align=True)
                    row.prop(scene, "show_3Dcursor", icon="DOWNARROW_HLT" if scene.show_3Dcursor else "RIGHTARROW", text="3D Cursor", emboss=False)
                    # row.label(text="3D Cursor")
                    if scene.show_3Dcursor:
                        cursor = scene.cursor
                        cursor_box.use_property_split = True
                        cursor_box.use_property_decorate = False
                        col = cursor_box.column(align=True)
                        # sub = split_sub.column(align=True)
                        col.label(text="Location:")
                        split_sub = col.split(factor=0.1, align=True)
                        left_col = split_sub.column(align=True)

                        left_box = left_col.box()
                        left_box.scale_y = 0.5
                        left_box.label(text= "X")

                        left_box = left_col.box()
                        left_box.scale_y = 0.5
                        left_box.label(text= "Y")

                        left_box = left_col.box()
                        left_box.scale_y = 0.5
                        left_box.label(text= "Z")

                        Right_col = split_sub.column(align=True)
                        Right_col.prop(cursor, "location", text="")
                        
                        rotation_mode = cursor.rotation_mode
                        if rotation_mode == "QUATERNION":
                            col.label(text="Rotation:")
                            split_sub = col.split(factor=0.1, align=True)
                            left_col = split_sub.column(align=True)

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "W")

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "X")

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "Y")

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "Z")

                            Right_col = split_sub.column(align=True)
                            Right_col.prop(cursor, "rotation_quaternion", text="")

                        elif rotation_mode == "AXIS_ANGLE":
                            col.label(text="Rotation:")
                            split_sub = col.split(factor=0.1, align=True)
                            left_col = split_sub.column(align=True)

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "W")

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "X")

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "Y")

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "Z")

                            Right_col = split_sub.column(align=True)
                            Right_col.prop(cursor, "rotation_axis_angle", text="")
                        else:
                            col.label(text="Rotation:")
                            split_sub = col.split(factor=0.1, align=True)
                            left_col = split_sub.column(align=True)

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "X")

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "Y")

                            left_box = left_col.box()
                            left_box.scale_y = 0.5
                            left_box.label(text= "Z")

                            Right_col = split_sub.column(align=True)
                            Right_col.prop(cursor, "rotation_euler", text="")
                        col.prop(cursor, "rotation_mode", text="")
                        
                    
                    annotations_section_layout = view_content_box.box()
                    row = annotations_section_layout.row(align=True)
                    row.prop(scene, "show_annotations_controls", icon="DOWNARROW_HLT" if scene.show_annotations_controls else "RIGHTARROW", text="Annotations", emboss=False)
                    # row.label(text="Annotations")
                    if scene.show_annotations_controls:
                        annotations_content_box = annotations_section_layout.box()
                        if not (gpd_owner := context.annotation_data_owner):
                            annotations_content_box.label(text="No annotation source")
                        else:
                            row = annotations_content_box.row()
                            # Version Check for Grease Pencil ID
                            if hasattr(gpd_owner, "grease_pencil"):
                                row.template_ID(gpd_owner, "grease_pencil", new="gpencil.annotation_add", unlink="gpencil.data_unlink")
                            elif hasattr(gpd_owner, "grease_pencil_annotation"):
                                row.template_ID(gpd_owner, "grease_pencil_annotation", new="gpencil.annotation_add", unlink="gpencil.data_unlink")
                            else:
                                if context.annotation_data:
                                    row.label(text=context.annotation_data.name, icon='GREASEPENCIL')
                                else:
                                    row.operator("gpencil.annotation_add", text="New Annotation", icon='ADD')
                            if (gpd := context.annotation_data) and gpd.layers:
                                row = annotations_content_box.row()
                                col = row.column()
                                col.template_list("GPENCIL_UL_annotation_layer", "", gpd, "layers", gpd.layers, "active_index", rows=5, sort_reverse=True, sort_lock=True)
                                col = row.column(align=True)
                                col.operator("gpencil.layer_annotation_add", icon='ADD', text="")
                                col.operator("gpencil.layer_annotation_remove", icon='REMOVE', text="")
                                if (gpl := context.active_annotation_layer) and len(gpd.layers) > 1:
                                    col.separator()
                                    sub = col.column(align=True)
                                    sub.operator("gpencil.layer_annotation_move", icon='TRIA_UP', text="").type = 'UP'
                                    sub.operator("gpencil.layer_annotation_move", icon='DOWNARROW_HLT', text="").type = 'DOWN'
                                if gpl:
                                    annotations_content_box.prop(gpl, "annotation_opacity", text="Opacity", slider=True)
                                    annotations_content_box.prop(gpl, "thickness")
                                    row = annotations_content_box.row(align=True)
                                    row.active = not gpl.lock
                                    lock_label = f"Frame: {gpl.active_frame.frame_number} (Locked)" if gpl.active_frame and gpl.lock_frame else "Lock Frame"
                                    row.prop(gpl, "lock_frame", text=lock_label, icon='UNLOCKED')
                                    row.operator("gpencil.annotation_active_frame_delete", text="", icon='X')
                else:
                    view_box.label(text="Please switch to a 3D Viewport.")
        if prefs.show_edit_section:
            main_row.prop(prefs, "show_edit_panel", text="Edit", toggle=True)
        
            if prefs.show_edit_panel:

                align_enabled = addon_utils.check("bl_ext.blender_org.align_tools")[1]
                distribute_enabled = addon_utils.check("bl_ext.blender_org.Distribute")[1]

                edit_box = layout.box()
                edit_col = edit_box.column(align=True)

                if prefs.show_aligndis_props:
                    edit_align_box = edit_col.box()
                    edit_align_row = edit_align_box.row()
                    
                    if align_enabled or distribute_enabled:

                        edit_align_row.prop(prefs, "show_align_distribute",text="Align & Distribute",icon="DOWNARROW_HLT" if prefs.show_align_distribute else "RIGHTARROW",emboss=False)

                        if prefs.show_align_distribute:
                            # --- Align Tools ---
                            if align_enabled:
                                align_col = edit_align_box.column()
                                if obj and obj.mode == 'OBJECT':
                                    if space_data and space_data.type == 'VIEW_3D':
                                        if prefs.show_align_advanced:
                                            align_box = align_col.box()
                                            align_row = align_box.row(align=True)

                                            align_alert = align_row.row(align=True)
                                            align_alert.alert = True
                                            align_alert.label(text="Active object:")

                                            obj_icon = f"OUTLINER_OB_{obj.type}"
                                            outliner_row = align_row.row(align=True)
                                            outliner_row.emboss = 'NONE' 
                                            outliner_row.label(text="", icon=obj_icon)
                                            outliner_row.prop(obj, "name", text="", emboss=False)

                                            align_row = align_col.row(align=True)
                                            align_row.label(text="Align Loc + Rot:")
                                            align_row.operator("object.align", text="XYZ")
                                            align_row = align_col.row(align=True)
                                            align_row.label(text="Advanced Align:")
                                            align_row.operator("object.align_tools", text="Advanced")

                                        align_col = edit_align_box.column(align=True)

                                        if prefs.show_align_location:
                                            align_row = align_col.row(align=True)
                                            align_row.label(text="Location:")
                                            align_row.operator("object.align_location_x", text="X")
                                            align_row.operator("object.align_location_y", text="Y")
                                            align_row.operator("object.align_location_z", text="Z")
                                            align_row.operator("object.align_location_all", text="All")

                                        if prefs.show_align_rotaion:
                                            align_row = align_col.row(align=True)
                                            align_row.label(text="Rotation:")
                                            align_row.operator("object.align_rotation_x", text="X")
                                            align_row.operator("object.align_rotation_y", text="Y")
                                            align_row.operator("object.align_rotation_z", text="Z")
                                            align_row.operator("object.align_rotation_all", text="All")

                                        if prefs.show_align_scale:
                                            align_row = align_col.row(align=True)
                                            align_row.label(text="Scale:")
                                            align_row.operator("object.align_objects_scale_x", text="X")
                                            align_row.operator("object.align_objects_scale_y", text="Y")
                                            align_row.operator("object.align_objects_scale_z", text="Z")
                                            align_row.operator("object.align_objects_scale_all", text="All")
                                elif not obj:
                                    align_col.label(text="No active object selected.")
                                else:
                                    align_col.label(text="Align Tools require Object Mode.")
                            # --- Distribute Tools ---
                            if distribute_enabled:
                                if prefs.show_distribute:
                                    dis_row = edit_align_box.row(align=True)
                                    dis_row.label(text="Distribute:")
                                    dis_row.operator("object.distribute_selected", text="X")
                                    dis_row.operator("object.distribute_selected", text="Y")
                                    dis_row.operator("object.distribute_selected", text="Z")
                                    dis_row.operator("object.distribute_selected", text="Diagonal")
                    else:
                        warning_row = edit_align_box.row()
                        warning_row.alert = True
                        warning_row.label(text="Requires 'Align Tools' or 'Distribute' Add-on to use this feature.")

                booltools_enabled = addon_utils.check("bl_ext.blender_org.bool_tool")[1]
                if prefs.show_booltool_props:
                    edit_bool_box = edit_col.box()
                    if booltools_enabled:
                        edit_bool_box.prop(prefs, "show_booltool",text="BoolTools",icon="DOWNARROW_HLT" if prefs.show_booltool else "RIGHTARROW",emboss=False)
                        if prefs.show_booltool:
                            edit_split = edit_bool_box.split(align=True)
                            if prefs.show_auto_bool:
                                edit_bool_box = edit_split.box()
                                edit_bool_col = edit_bool_box.column(align=True)
                                edit_bool_col.label(text="Auto Boolean")
                                edit_bool_col.operator("object.boolean_auto_difference", text="Difference", icon='SELECT_SUBTRACT')
                                edit_bool_col.operator("object.boolean_auto_union", text="Union", icon='SELECT_EXTEND')
                                edit_bool_col.operator("object.boolean_auto_intersect", text="Intersect", icon='SELECT_INTERSECT')
                                edit_bool_col.operator("object.boolean_auto_slice", text="Slice", icon='SELECT_DIFFERENCE')
                            if prefs.show_Brush_bool:
                                edit_bool_box = edit_split.box()
                                edit_bool_col = edit_bool_box.column(align=True)
                                edit_bool_col.label(text="Brush Boolean")
                                edit_bool_col.operator("object.boolean_brush_difference", text="Difference", icon='SELECT_SUBTRACT')
                                edit_bool_col.operator("object.boolean_brush_union", text="Union", icon='SELECT_EXTEND')
                                edit_bool_col.operator("object.boolean_brush_intersect", text="Intersect", icon='SELECT_INTERSECT')
                                edit_bool_col.operator("object.boolean_brush_slice", text="Slice", icon='SELECT_DIFFERENCE')
                    else:
                        warning_row = edit_bool_box.row()
                        warning_row.alert = True
                        warning_row.label(text="Requires 'BoolTool' Add-on/Extension to use this feature.")

                looptools_enabled = addon_utils.check("bl_ext.blender_org.looptools")[1]
                if prefs.show_looptools_props:
                    edit_loop_box = edit_col.box()
                    if looptools_enabled:
                        edit_loop_box.prop(prefs, "show_looptool",text="LoopTools",icon="DOWNARROW_HLT" if prefs.show_looptool else "RIGHTARROW",emboss=False)
                        if prefs.show_looptool:
                            loop_grid = edit_loop_box.grid_flow(columns=2, align=True)
                            if prefs.show_bridge_loop:
                                loop_grid.operator("mesh.looptools_bridge", text="Bridge")
                            if prefs.show_circle_loop:
                                loop_grid.operator("mesh.looptools_circle", text="Circle")
                            if prefs.show_curve_loop:
                                loop_grid.operator("mesh.looptools_curve", text="Curve")
                            if prefs.show_flastten_loop:
                                loop_grid.operator("mesh.looptools_flatten", text="Flastten")
                            if prefs.show_gstretch_loop:
                                loop_grid.operator("mesh.looptools_gstretch", text="Gstretch")
                            if prefs.show_loft_loop:
                                loop_grid.operator("mesh.looptools_bridge", text="Loft")
                            if prefs.show_relax_loop:
                                loop_grid.operator("mesh.looptools_relax", text="Relax")
                            if prefs.show_space_loop:
                                loop_grid.operator("mesh.looptools_space", text="Space")
                    else:
                        warning_row = edit_loop_box.row()
                        warning_row.alert = True
                        warning_row.label(text="Requires 'LoopTools' Add-on/Extension to use this feature.")

    if prefs.show_guide:
        main_row.separator()
        op = main_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
        op.url = "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"

def draw_frequency_panel_view3d(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    space = context.space_data
    if space.type == 'VIEW_3D':
        overlay = space.overlay
        box = layout.box()
        col = box.column(align=True)
        if prefs.show_quick_3d:
            split = col.split()
            if prefs.show_statics_button:
                split.prop(overlay,'show_stats', text="", icon="STATUSBAR", toggle=True)
            if prefs.show_faceorien_button:
                split.prop(overlay,'show_face_orientation', text="", icon="FACE_MAPS", toggle=True)
            if prefs.show_lockcamera_button:
                split.prop(space,'lock_camera', text="", icon="RESTRICT_RENDER_OFF", toggle=True)
            if prefs.show_mesh_edit_overlay_button and context.mode in {"EDIT_MESH","EDIT_CURVE"}:
                split.operator('st.normal_edit_overlay_popover', text="", icon='EDITMODE_HLT')
            if prefs.show_viewportshading_button:
                split.operator('st.viewportoverlay_popover', text="", icon='SHADING_RENDERED')
            if prefs.show_cleandata_3Dview_button:
                split.operator('st.pt_purgedata_menu',text="" , icon='ORPHAN_DATA')
            if prefs.show_render_button:
                split.operator('st.render_popover', text="", icon='SCENE')
            if prefs.show_anno_3d_button:
                split.prop(prefs, 'show_annotations_3dview', text="", icon='GREASEPENCIL', toggle=True)
