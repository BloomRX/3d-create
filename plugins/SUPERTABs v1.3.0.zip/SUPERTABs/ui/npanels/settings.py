import bpy
import os

def shared_draw_display_settings(self, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    layout = self.layout
    
    
    is_3d_view = context.area.type == 'VIEW_3D'
    is_uv_editor = context.area.type == 'IMAGE_EDITOR'
    is_node_editor = context.area.type == 'NODE_EDITOR'

    row = layout.row(align=True)
    
    if is_uv_editor:
        if context.space_data.mode == 'UV':
            row.label(text="N-Panel Display Settings (UV Editor)")
        else:
            row.label(text="N-Panel Display Settings (Image Editor)")
    elif is_node_editor:
        row.label(text="N-Panel Display Settings (Node Editor)")
    else:
        row.label(text="N-Panel Display Settings")

    row.separator()

    common_row = layout.row()
    if is_3d_view:
        common_row.prop(prefs, "show_asset_browser_button", text="Asset Browser(TopBar)", icon="CHECKBOX_HLT" if prefs.show_asset_browser_button else "CHECKBOX_DEHLT", toggle=True)
    common_row.prop(prefs, "hide_options_subgroups", text="Show Options Buttons(Tab Groups)", icon="CHECKBOX_HLT" if prefs.hide_options_subgroups else "CHECKBOX_DEHLT", toggle=True)
    common_row.prop(prefs, "hide_options_items", text="Show Options Buttons(Addons/Tabs)", icon="CHECKBOX_HLT" if prefs.hide_options_items else "CHECKBOX_DEHLT", toggle=True)

    # =========================================================================
    # 3D VIEWPORT UI
    # =========================================================================
    if is_3d_view:
        row_scale = row.row(align=True)
        row_scale.scale_x = 0.35
        row_scale.prop(prefs,"show_guide", text="Guides", icon="QUESTION", toggle=True)
        guide_row = row.row(align=True)
        if prefs.show_guide:
            guide_row.separator(factor=0.5)
            op = guide_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
            op.url = "https://www.notion.so/SUPERTABs-N-Panel-Display-Settings-Guide-N-Panel-v1-3-0-REMAKE-2eab1f0a8353800ca3ccddcf179021bf?source=copy_link"

        show_basic_row = layout.row(align=True)
        scale_row = show_basic_row.row(align=True)
        scale_row.scale_x = 0.6
        scale_row.prop(prefs,"show_header_3d", text="Hide All" if prefs.show_header_3d else"Show SUPERTABs Tools Header", icon="RIGHTARROW" if prefs.show_header_3d else "BLANK1", toggle=True)
        if prefs.show_header_3d:
            show_basic_row.separator(factor=0.5)
            show_basic_row.prop(prefs,"show_quick_3d", text="Quick Use(3DView)", icon="CHECKBOX_HLT" if prefs.show_quick_3d else "CHECKBOX_DEHLT", toggle=True)
            show_basic_row.prop(prefs,"show_editor_shortcuts_panel", text="WindowEditor Section", icon="CHECKBOX_HLT" if prefs.show_editor_shortcuts_panel else "CHECKBOX_DEHLT", toggle=True)
            show_basic_row.prop(prefs,"show_basic_panel", text="Basic Section(3Dview)", icon="CHECKBOX_HLT" if prefs.show_basic_panel else "CHECKBOX_DEHLT", toggle=True)
        show_manager_row = layout.row(align=True)
        scale_manager_row = show_manager_row.row(align=True)
        scale_manager_row.scale_x = 0.5
        
        is_manager_on = prefs.show_manager_header_3d
        scale_manager_row.prop(prefs, "show_manager_header_3d", 
            text="Hide All" if is_manager_on else "Show SUPERTABs Manager Header", 
            icon="RIGHTARROW" if is_manager_on else "BLANK1", 
            toggle=True
        )

        if prefs.show_manager_header_3d:
            show_manager_row.separator(factor=0.5)
            show_manager_row.prop(prefs, "show_fav_panel_3d", text="Favorite Tabs Section", icon="CHECKBOX_HLT" if prefs.show_fav_panel_3d else "CHECKBOX_DEHLT", toggle=True)
            show_manager_row.prop(prefs, "show_groups_panel_3d", text="Groups&Addons Section", icon="CHECKBOX_HLT" if prefs.show_groups_panel_3d else "CHECKBOX_DEHLT", toggle=True)
            show_manager_row.prop(prefs, "show_collapse_all_3d", text="Collapse All", icon="CHECKBOX_HLT" if prefs.show_collapse_all_3d else "CHECKBOX_DEHLT", toggle=True)
            # show_manager_row.prop(prefs, "show_collapse_options", text="", icon="FILTER", toggle=True)

            # if prefs.show_collapse_options:
            #         opt_box = layout.box()
            #         col_row = opt_box.row(align=True)
            #         col_row.label(text="Collapse Targets:", icon="FILTER")
            #         col_row.prop(prefs, "collapse_opt_items", text="Addons/Tabs", toggle=True)
            #         col_row.prop(prefs, "collapse_opt_groups", text="Tab Groups", toggle=True)
            #         col_row.prop(prefs, "collapse_opt_panels", text="Sections Panels", toggle=True)
            
        box = layout.box()
        split = box.split(factor=0.5)
        left_col = split.column(align=True)

        # --- Basic Section (Transform, View, Edit) ---
        if prefs.show_basic_panel:
            box = left_col.box()
            col_box = box.column(align=True)
            col_box.label(text="Basic Section:", icon="BLENDER")
            col_box.separator(factor=0.5)
            row = col_box.row(align=True)
            row.prop(prefs, "show_transform_section")
            if prefs.show_transform_section:
                trans_row = row.row(align=True)
                trans_row.scale_x = 0.7
                trans_row.prop(prefs, "show_object_name_row", text="Active Object Name", toggle=True)
                trans_row.prop(prefs, "show_curve_section", text="Curve Data", toggle=True)
                trans_row.prop(prefs, "show_normal_section", text="Normal", toggle=True)
            col_box.prop(prefs, "show_view_section")
            col_row = col_box.row(align=True)
            col_row.prop(prefs, "show_edit_section", text="Edit Section")
            row_alert = col_row.row(align=True)
            row_alert.alert = True
            row_alert.scale_x = 2
            row_alert.label(text="Needed:Aligntools, Looptools, Booltools & Distribute)")
            if prefs.show_edit_section:
                edit_col_box = col_box.box()
                edit_col = edit_col_box.column()
                edit_row = edit_col.row(align=True)
                edit_row.prop(prefs,"show_aligndis_props")
                if prefs.show_aligndis_props:
                    edit_row.prop(prefs,"show_align_advanced", text="Align Advanced", toggle=True)
                    align_op_row = edit_col.row(align=True)
                    align_op_row.prop(prefs,"show_align_location", text="Align Location", toggle=True)
                    align_op_row.prop(prefs,"show_align_rotaion", text="Align Rotation", toggle=True)
                    align_op_row.prop(prefs,"show_align_scale", text="Align Scale", toggle=True)
                    align_op_row.prop(prefs,"show_distribute", text="Distribute", toggle=True)
                edit_col.prop(prefs,"show_booltool_props")
                if prefs.show_booltool_props:
                    bool_op_row = edit_col.row(align=True)
                    bool_op_row.prop(prefs,"show_auto_bool", text="Auto Boolean", toggle=True)
                    bool_op_row.prop(prefs,"show_Brush_bool", text="Brush Boolean", toggle=True)
                edit_col.prop(prefs,"show_looptools_props")
                if prefs.show_looptools_props:
                    loop_op_row = edit_col.row(align=True)
                    loop_op_row.prop(prefs,"show_bridge_loop", text="Bridge", toggle=True)
                    loop_op_row.prop(prefs,"show_circle_loop", text="Circle", toggle=True)
                    loop_op_row.prop(prefs,"show_curve_loop", text="Curve", toggle=True)
                    loop_op_row.prop(prefs,"show_flastten_loop", text="Flastten", toggle=True)
                    loop_op_row = edit_col.row(align=True)
                    loop_op_row.prop(prefs,"show_gstretch_loop", text="Gstretch", toggle=True)
                    loop_op_row.prop(prefs,"show_loft_loop", text="Loft", toggle=True)
                    loop_op_row.prop(prefs,"show_relax_loop", text="Relax", toggle=True)
                    loop_op_row.prop(prefs,"show_space_loop", text="Space", toggle=True)
        
        # --- Quick Section (3D View) ---
        if prefs.show_quick_3d:
            quick_box = left_col.box()
            quick_box.label(text="Quick Use(3DView):", icon="VIEW3D")
            freq_col_box = quick_box.box()
            freq_split = freq_col_box.split(factor=0.5, align=True)
            freq_col = freq_split.column(align=True)
            freq_col.prop(prefs, "show_statics_button", text="Statistic")
            freq_col.prop(prefs, "show_faceorien_button", text="Face Orientation")
            freq_col.prop(prefs, "show_lockcamera_button", text="Lock Camera")
            freq_col.prop(prefs, "show_anno_3d_button", text="Annotations")
            freq_col = freq_split.column(align=True)
            freq_col.prop(prefs, "show_mesh_edit_overlay_button", text="Mesh Editmode Overlay")
            freq_col.prop(prefs, "show_viewportshading_button", text="Viewport Shading/Overlay")
            freq_col.prop(prefs, "show_cleandata_3Dview_button", text="Clean Unused Data")
            freq_col.prop(prefs, "show_render_button", text="Render Settings")
        
        right_col = split.column(align=True)
        
        # --- Window Editor Section (3D View Only) ---
        if prefs.show_editor_shortcuts_panel:
            main_win_box = right_col.box()
            main_win_box.label(text="WindowEditor Section:", icon="WINDOW")

            win_col = main_win_box.column(align=True)
            main_split = win_col.split(factor=0.5, align=True)

            # --- LEFT ---
            win_left_col = main_split.column(align=True)
            
            # --- General ---
            gen_box = win_left_col.box().column(align=True)
            gen_row = gen_box.row(align=True)
            gen_row.prop(prefs, "show_general", text="General", toggle=True)
            if prefs.show_general:
                row = gen_box.row()
                row.prop(prefs, "show_3Dview")
                row.prop(prefs, "show_image")
                
                row = gen_box.row()
                row.prop(prefs, "show_uv")
                row.prop(prefs, "show_shader")
                
                row = gen_box.row()
                row.prop(prefs, "show_comp")
                row.prop(prefs, "show_geo")
                
                row = gen_box.row()
                row.prop(prefs, "show_texture")
                row.prop(prefs, "show_clip")
                
                row = gen_box.row()
                row.prop(prefs, "show_sequence")

            # --- Scripting ---
            script_box = win_left_col.box().column(align=True)
            script_row = script_box.row()
            script_row.prop(prefs, "show_scripting", text="Scripting", toggle=True)
            if prefs.show_scripting:
                row = script_box.row()
                row.prop(prefs, "show_text")
                row.prop(prefs, "show_console")
                
                row = script_box.row()
                row.prop(prefs, "show_info")
                row.prop(prefs, "show_system_console")
                row = script_box.row()
                row.prop(prefs, "show_iconviewer")
            # --- RIGHT ---
            win_right_col = main_split.column()
            
            # --- Animation ---
            anim_box = win_right_col.box().column(align=True)
            anim_row = anim_box.row(align=True)
            anim_row.prop(prefs, "show_animation", text="Animation", toggle=True)
            if prefs.show_animation:
                row = anim_box.row()
                row.prop(prefs, "show_dopesheet")
                row.prop(prefs, "show_graph")

                row = anim_box.row()
                row.prop(prefs, "show_drivers")
                row.prop(prefs, "show_timeline")

                row = anim_box.row()
                row.prop(prefs, "show_nla")

                row = anim_box.row()
                row.label(text="")
                row = anim_box.row()
                row.label(text="")

            # --- Data ---
            data_box = win_right_col.box().column(align=True)
            data_row = data_box.row(align=True)
            data_row.prop(prefs, "show_data", text="Data", toggle=True)
            if prefs.show_data:
                row = data_box.row()
                row.prop(prefs, "show_outliner")
                row.prop(prefs, "show_props")
                
                row = data_box.row()
                row.prop(prefs, "show_file")
                row.prop(prefs, "show_spread")

                row = data_box.row()
                row.label(text="")

            win_col.separator(factor=0.2)
            win_col.prop(prefs, "show_serpen", text="Visual Scripting Editor [Needed: Serpen Addon]", toggle=True)
    
            right_col.separator(factor=2)

        op_box = right_col.box()
        op_col = op_box.column(align=True)
        im_row = op_col.row(align=True)
        sub_box = im_row.box()
        if prefs.auto_import_enabled:
            filepath = prefs.auto_import_filepath
            if filepath and os.path.exists(filepath):
                filename = os.path.basename(filepath)
                sub_box.label(text=f"{filename}", icon='FILE_TICK')
            elif filepath:
                sub_box.alert = True
                sub_box.label(text="Auto-Load file not found!", icon='ERROR')
            else:
                sub_box.alert = True
                sub_box.label(text="No auto-load file set", icon='ERROR')
        else:
            sub_box.enabled = False
            sub_box.label(text="Auto-Import Disabled", icon='PAUSE')
            
        row_import = im_row.row(align=True)
        row_import.scale_y = 1.5
        row_import.scale_x = 1.25
        row_import.operator("tab_group.import_settings", text="", icon="IMPORT")

        row_export = op_col.row(align=True)
        row_export.alert = True
        row_export.scale_y = 2
        row_export.operator("tab_group.export_settings", text="Export")
        row_export.scale_x = 1.25
        row_export.operator("tab_group.quick_export", text="", icon="EXPORT")
    # =========================================================================
    # UV EDITOR UI
    # =========================================================================
    elif is_uv_editor:
        row_scale = row.row(align=True)
        row_scale.scale_x = 0.5
        row_scale.prop(prefs,"show_guide", text="Guides", icon="QUESTION", toggle=True)
        if prefs.show_guide:
            guide_row = row.row(align=True)
            guide_row.separator(factor=0.5)
            op = guide_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
            op.url = "https://www.notion.so/SUPERTABs-N-Panel-Display-Settings-Guide-N-Panel-v1-3-0-REMAKE-2eab1f0a8353800ca3ccddcf179021bf?source=copy_link"

        is_mode_uv = (context.space_data.mode == 'UV')

        if is_mode_uv:
            # === UV EDITOR Variables ===
            prop_header   = "show_header_image"
            prop_quick    = "show_quick_uv"
            prop_basic    = "show_basic_uv_buttons"
            prop_manager  = "show_manager_header_image"
            prop_fav      = "show_fav_panel_image"
            prop_groups   = "show_groups_panel_image"
            prop_collapse = "show_collapse_all_image"
            text_suffix   = "(UV)"
        else:
            # === IMAGE EDITOR Variables ===
            prop_header   = "show_header_image_only"
            prop_quick    = "show_quick_image"
            prop_basic    = "show_basic_image_buttons"
            prop_manager  = "show_manager_header_image_only"
            prop_fav      = "show_fav_panel_image_only"
            prop_groups   = "show_groups_panel_image_only"
            prop_collapse = "show_collapse_all_image_only"
            text_suffix   = "(Image)"

        show_basic_row = layout.row(align=True)
        scale_row = show_basic_row.row(align=True)
        scale_row.scale_x = 0.6

        is_header_on = getattr(prefs, prop_header)
        
        scale_row.prop(prefs, prop_header, text="Hide All" if is_header_on else "Show SUPERTABs Tools Header", icon="RIGHTARROW" if is_header_on else "BLANK1", toggle=True)

        if is_header_on:
            show_basic_row.separator(factor=0.5)

            is_quick_on = getattr(prefs, prop_quick)
            is_basic_on = getattr(prefs, prop_basic)
            is_img_sel_on = getattr(prefs, "show_image_selector", True)
            
            show_basic_row.prop(prefs, prop_quick, text=f"Quick Use {text_suffix}", icon="CHECKBOX_HLT" if is_quick_on else "CHECKBOX_DEHLT", toggle=True)
            show_basic_row.prop(prefs, prop_basic, text=f"Basic Section {text_suffix}", icon="CHECKBOX_HLT" if is_basic_on else "CHECKBOX_DEHLT", toggle=True)
            show_basic_row.prop(prefs, "show_image_selector", text="Image Selector", icon="CHECKBOX_HLT" if is_img_sel_on else "CHECKBOX_DEHLT", toggle=True)
        
        show_manager_row = layout.row(align=True)
        scale_manager_row = show_manager_row.row(align=True)
        scale_manager_row.scale_x = 0.6
        
        is_manager_on = getattr(prefs, prop_manager)
        scale_manager_row.prop(prefs, prop_manager, text="Hide All" if is_manager_on else "Show SUPERTABs Manager Header", icon="RIGHTARROW" if is_manager_on else "BLANK1", toggle=True)

        if is_manager_on:
            show_manager_row.separator(factor=0.5)
            
            is_fav_on = getattr(prefs, prop_fav)
            is_groups_on = getattr(prefs, prop_groups)
            is_collapse_on = getattr(prefs, prop_collapse)

            show_manager_row.prop(prefs, prop_fav, text="Favorite Tabs Section", icon="CHECKBOX_HLT" if is_fav_on else "CHECKBOX_DEHLT", toggle=True)
            show_manager_row.prop(prefs, prop_groups, text="Groups&Addons Section", icon="CHECKBOX_HLT" if is_groups_on else "CHECKBOX_DEHLT", toggle=True)
            
            # Collapse All + Filter Options
            show_manager_row.prop(prefs, prop_collapse, text="Collapse All", icon="CHECKBOX_HLT" if is_collapse_on else "CHECKBOX_DEHLT", toggle=True)
            # show_manager_row.prop(prefs, "show_collapse_options", text="", icon="FILTER", toggle=True)

            # if prefs.show_collapse_options:
            #     opt_box = layout.box()
            #     col_row = opt_box.row(align=True)
            #     col_row.label(text="Collapse Targets:", icon="FILTER")
            #     col_row.prop(prefs, "collapse_opt_items", text="Addons/Tabs", toggle=True)
            #     col_row.prop(prefs, "collapse_opt_groups", text="Tab Groups", toggle=True)
            #     col_row.prop(prefs, "collapse_opt_panels", text="Sections Panels", toggle=True)

        box = layout.box()
        row = box.row()
        left_col = row.column(align=True)

        if is_mode_uv:
            if prefs.show_quick_uv:
                uv_box = left_col.box()
                uv_col = uv_box.column(align=True)
                uv_col.label(text="UV Editors:", icon="UV")
                row_col = uv_col.row(align=True)
                col = row_col.column(align=True)
                
                col.prop(prefs, "show_uv_stretch")
                col.prop(prefs, "show_uv_sync")
                col.prop(prefs, "show_uv_average_scale")
                col.prop(prefs, "show_uv_pack_islands")
                col.prop(prefs, "show_anno_uv_button", text="Annotations")

                col = row_col.column(align=True)

                col.prop(prefs, "show_uv_select_overlap")
                col.prop(prefs, "show_reset_uv")
                col.prop(prefs, "show_export_uv")
                col.prop(prefs, "show_live_unwrap")
        else:
            if getattr(prefs, "show_quick_image", True):
                img_box = left_col.box()
                img_col = img_box.column(align=True)
                img_col.label(text="Image Editors:", icon="IMAGE")

                col_row = img_col.row(align=True)
                col = col_row.column(align=True)
                
                col.prop(prefs, "show_image_resize")
                col.prop(prefs, "show_image_replace")
                col.prop(prefs, "show_save_all_image")
                col.prop(prefs, "show_anno_image_button", text="Annotations")
                
                col = col_row.column(align=True)
                col.prop(prefs, "show_save_as_copy")
                col.prop(prefs, "show_external_edit")
                col.prop(prefs, "show_external_data")
                if prefs.show_external_data:
                    col.prop(prefs, "auto_pack_toggle", text="Auto Pack Resources", toggle=True)
                    ex_row = col.row(align=True)
                    ex_row.prop(prefs, "toggle_pack_resources", text="External Pack Resources", toggle=True)
                    ex_row.prop(prefs, "toggle_pack_linked", text="External Pack Linked", toggle=True)
                    ex_row = col.row(align=True)
                    ex_row.prop(prefs, "toggle_make_path", text="External Make Path", toggle=True)
                    ex_row.prop(prefs, "toggle_missing_files", text="External Missing Files", toggle=True)
                col.prop(prefs, "show_cleandata_image_button", text="Clean Unused Data")

        right_col = row.column(align=True)
        
        op_box = right_col.box()
        op_col = op_box.column()
        im_row = op_col.row(align=True)
        sub_box = im_row.box()
        if prefs.auto_import_enabled:
            filepath = prefs.auto_import_filepath
            if filepath and os.path.exists(filepath):
                filename = os.path.basename(filepath)
                sub_box.label(text=f"{filename}", icon='FILE_TICK')
            elif filepath:
                sub_box.alert = True
                sub_box.label(text="Auto-Load file not found!", icon='ERROR')
            else:
                sub_box.alert = True
                sub_box.label(text="No auto-load file set", icon='ERROR')
        else:
            sub_box.enabled = False
            sub_box.label(text="Auto-Import Disabled", icon='PAUSE')
            
        row_import = im_row.row(align=True)
        row_import.scale_y = 1.5
        row_import.scale_x = 1.25
        row_import.operator("tab_group.import_settings", text="", icon="IMPORT")

        row_export = op_col.row(align=True)
        row_export.alert = True
        row_export.scale_y = 2
        row_export.operator("tab_group.export_settings", text="Export")
        row_export.scale_x = 1.25
        row_export.operator("tab_group.quick_export", text="", icon="EXPORT")

    # =========================================================================
    # NODE EDITOR UI
    # =========================================================================
    elif is_node_editor:
        row_scale = row.row(align=True)
        row_scale.scale_x = 0.5
        row_scale.prop(prefs,"show_guide", text="Guides", icon="QUESTION", toggle=True)
        if prefs.show_guide:
            guide_row = row.row(align=True)
            guide_row.separator(factor=0.5)
            op = guide_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
            op.url = "https://www.notion.so/SUPERTABs-N-Panel-Display-Settings-Guide-N-Panel-v1-3-0-REMAKE-2eab1f0a8353800ca3ccddcf179021bf?source=copy_link"

        show_basic_row = layout.row(align=True)
        scale_row = show_basic_row.row(align=True)
        scale_row.scale_x = 0.5

        space = context.space_data
        valid_trees = {'GeometryNodeTree', 'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree'}
        current_tree = getattr(space, 'tree_type', '')
        
        target_header_prop = "show_header_nodes"
        target_quick_prop = "show_quick_node"
        target_fav_prop = "show_favorite_nodes_panel"
        target_zoom_prop = "show_geo_zoom_buttons"

        if current_tree == 'GeometryNodeTree': 
            target_header_prop = "st_node_header_geometry"
            target_quick_prop = "st_node_quick_geometry"
            target_fav_prop = "st_node_show_fav_nodes_geometry"
            target_zoom_prop = "st_node_zoom_geometry"
        elif current_tree == 'ShaderNodeTree': 
            target_header_prop = "st_node_header_shading"
            target_quick_prop = "st_node_quick_shading"
            target_fav_prop = "st_node_show_fav_nodes_shading"
            target_zoom_prop = "st_node_zoom_shading"
        elif current_tree == 'CompositorNodeTree': 
            target_header_prop = "st_node_header_compositor"
            target_quick_prop = "st_node_quick_compositor"
            target_fav_prop = "st_node_show_fav_nodes_compositor"
            target_zoom_prop = "st_node_zoom_compositor"
        elif current_tree == 'TextureNodeTree': 
            target_header_prop = "st_node_header_texture"
            target_quick_prop = "st_node_quick_texture"
            target_fav_prop = "st_node_show_fav_nodes_texture"
            target_zoom_prop = "st_node_zoom_texture"
        
        is_header_on = getattr(prefs, target_header_prop, True)
        scale_row.scale_x = 0.75
        scale_row.prop(prefs, target_header_prop, text="Hide All" if is_header_on else "Show SUPERTABs Tools Header", icon="RIGHTARROW" if is_header_on else "BLANK1", toggle=True)
        
        if is_header_on:
            show_basic_row.separator(factor=0.5)
            is_quick_on = getattr(prefs, target_quick_prop, False)
            is_fav_on = getattr(prefs, target_fav_prop, False)
            is_zoom_on = getattr(prefs, target_zoom_prop, False)
            show_basic_row.prop(prefs, target_quick_prop, text="Quick Use(Nodes)", icon="CHECKBOX_HLT" if is_quick_on else "CHECKBOX_DEHLT", toggle=True)
            show_basic_row.prop(prefs, target_fav_prop, text="Favorite Nodes Section(Nodes)", icon="CHECKBOX_HLT" if is_fav_on else "CHECKBOX_DEHLT", toggle=True)
            show_basic_row.prop(prefs, target_zoom_prop, text="Zoom Buttons(Nodes)", icon="CHECKBOX_HLT" if is_zoom_on else "CHECKBOX_DEHLT", toggle=True)
        
        show_manager_row = layout.row(align=True)
        scale_manager_row = show_manager_row.row(align=True)
        scale_manager_row.scale_x = 0.5

        target_suffix = "shading"
        if current_tree == 'GeometryNodeTree':
            target_suffix = "geometry"
        elif current_tree == 'CompositorNodeTree':
            target_suffix = "compositor"
        elif current_tree == 'TextureNodeTree':
            target_suffix = "texture"

        target_manager_prop = f"show_manager_header_{target_suffix}"
        target_fav_prop = f"show_fav_panel_{target_suffix}"
        target_opt_prop = f"show_groups_panel_{target_suffix}"
        target_collapse_prop = f"show_collapse_all_{target_suffix}"

        if hasattr(prefs, target_manager_prop):
            is_manager_on = getattr(prefs, target_manager_prop)
            scale_manager_row.prop(prefs, target_manager_prop, 
                text="Hide All" if is_manager_on else "Show SUPERTABs Manager Header", 
                icon="RIGHTARROW" if is_manager_on else "BLANK1", 
                toggle=True
            )
            
            if is_manager_on:
                show_manager_row.separator(factor=0.5)
                if hasattr(prefs, target_fav_prop):
                    show_manager_row.prop(prefs, target_fav_prop, text="Favorite Tabs Section", toggle=True)
                
                if hasattr(prefs, target_opt_prop):
                    show_manager_row.prop(prefs, target_opt_prop, text="Groups&Addons Section", toggle=True)

                if hasattr(prefs, target_collapse_prop):
                    is_collapse_active = getattr(prefs, target_collapse_prop)
                    
                    show_manager_row.prop(prefs, target_collapse_prop, text="Collapse All", icon="CHECKBOX_HLT" if is_collapse_active else "CHECKBOX_DEHLT", toggle=True)
                    # show_manager_row.prop(prefs, "show_collapse_options", text="", icon="FILTER", toggle=True)

                    # if prefs.show_collapse_options:
                    #     opt_box = layout.box()
                    #     col_row = opt_box.row(align=True)
                    #     col_row.label(text="Collapse Targets:", icon="FILTER")
                    #     col_row.prop(prefs, "collapse_opt_items", text="Addons/Tabs", toggle=True)
                    #     col_row.prop(prefs, "collapse_opt_groups", text="Tab Groups", toggle=True)
                    #     col_row.prop(prefs, "collapse_opt_panels", text="Sections Panels", toggle=True)

        space = context.space_data
        valid_trees = {'GeometryNodeTree', 'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree'}
        current_tree = getattr(space, 'tree_type', '')
    
        node_box = layout.box()
        node_row = node_box.row()
        left_col = node_row.column(align=True)

        if getattr(prefs, target_quick_prop, False) and current_tree in valid_trees:
            box_row = left_col.box()
            box = box_row.box()

            q_label = "Node Tools:"
            q_icon = "NODETREE"
            if current_tree == 'GeometryNodeTree':
                q_label = "Geometry Nodes Tools:"
                q_icon = "GEOMETRY_NODES"
            elif current_tree == 'ShaderNodeTree':
                q_label = "Shader Tools:"
                q_icon = "NODE_MATERIAL"
            elif current_tree == 'CompositorNodeTree':
                q_label = "Compositor Tools:"
                q_icon = "NODE_COMPOSITING"
            elif current_tree == 'TextureNodeTree':
                q_label = "Texture Tools:"
                q_icon = "NODE_TEXTURE"

            box.label(text=q_label, icon=q_icon)

            node_col = box.column(align=True)
            node_col.prop(prefs, "show_node_stats_button", text="Statistics(Node)")
            node_col.prop(prefs, "show_geo_align_button", text="Align Nodes Button")
            node_col.prop(prefs, "show_view_home_button", text="View Home Button")
            if prefs.show_geo_align_button:
                align_row = node_col.row(align=True)
                align_row.prop(prefs, "node_align_buttons", text="Align", toggle=True)
                align_row.prop(prefs, "node_distribute_buttons", text="Distribute", toggle=True)
                align_row.prop(prefs, "node_rotate_buttons", text="Rotate", toggle=True)

            node_col.prop(prefs, "show_collapse_socket_button", text="Collapse Unused Sockets")
            node_col.prop(prefs, "show_anno_node_button", text="Annotations")
            
            if current_tree == 'GeometryNodeTree':
                node_col.prop(prefs, "show_geo_timing_button", text="Show Timing")
                node_col.prop(prefs, "show_geo_named_attribute_button", text="Named Attributes")
            node_col.prop(prefs, "show_cleandata_nodes_button", text="Clean Unused Data")
            
        right_col = node_row.column(align=True)

        op_box = right_col.box()
        op_col = op_box.column()
        im_row = op_col.row(align=True)
        sub_box = im_row.box()
        if prefs.auto_import_enabled:
            filepath = prefs.auto_import_filepath
            if filepath and os.path.exists(filepath):
                filename = os.path.basename(filepath)
                sub_box.label(text=f"{filename}", icon='FILE_TICK')
            elif filepath:
                sub_box.alert = True
                sub_box.label(text="Auto-Load file not found!", icon='ERROR')
            else:
                sub_box.alert = True
                sub_box.label(text="No auto-load file set", icon='ERROR')
        else:
            sub_box.enabled = False
            sub_box.label(text="Auto-Import Disabled", icon='PAUSE')
            
        row_import = im_row.row(align=True)
        row_import.scale_y = 1.5
        row_import.scale_x = 1.25
        row_import.operator("tab_group.import_settings", text="", icon="IMPORT")

        row_export = op_col.row(align=True)
        row_export.alert = True
        row_export.scale_y = 2
        row_export.operator("tab_group.export_settings", text="Export")
        row_export.scale_x = 1.25
        row_export.operator("tab_group.quick_export", text="", icon="EXPORT")

    # --- Quick Menu Integration ---
    quick_row = layout.row(align=True)
    rightclick_box = quick_row.box()
    rightclick_box.label(text="Quick Menu Integration", icon="MOUSE_RMB")
    box_scale = rightclick_box.box()
    box_scale.scale_y = 1.4
    box_scale.prop(prefs, "right_click_mode", expand=True)

    quick_row.separator(factor=0.5)

    # --- RightClick Toggles ---
    qm_main_box = quick_row.box()
    qm_box = qm_main_box.box()
    qm_col = qm_box.column(align=True)
    qm_row = qm_col.row()
    qm_row.label(text="Right-Click Menu")
    pos_row = qm_row.row(align=True)
    pos_row.scale_x = 0.5
    pos_row.prop(prefs, "right_click_menu_position",text="Position", expand=True)
    
    # RCM Toggle
    rcm_qs_row = qm_col.row(align=True)
    rcm_qs_row.enabled = (prefs.right_click_mode == 'MENU' or prefs.right_click_mode == 'BOTH')
    rcm_qs_row.prop(prefs, "enable_quick_shortcuts_rcm", text="Quick-Shortcuts", 
                    icon="PINNED" if prefs.enable_quick_shortcuts_rcm else "UNPINNED", toggle=True)
    
    # RCM Toggle
    rcm_win_row = qm_col.row(align=True)
    rcm_win_row.enabled = (prefs.right_click_mode == 'MENU' or prefs.right_click_mode == 'BOTH')
    rcm_win_row.prop(prefs, "enable_window_editors_rcm", text="Window Editors", 
                    icon="RESTRICT_VIEW_OFF" if prefs.enable_window_editors_rcm else "RESTRICT_VIEW_ON", toggle=True)

    # --- Pie Menu Toggles ---
    qs_box = qm_main_box.box()
    qs_col = qs_box.column(align=True)
    qs_row = qs_col.row()
    qs_row.label(text="Pie-Menu:")
    
    # Pie Toggle
    pie_qs_row = qs_col.row(align=True)
    pie_qs_row.enabled = (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH')
    pie_qs_row.prop(prefs, "enable_quick_shortcuts_pie", text="Quick-Shortcuts", 
                    icon="PINNED" if prefs.enable_quick_shortcuts_pie else "UNPINNED", toggle=True)
    
    # Pie Toggle
    pie_win_row = qs_col.row(align=True)
    pie_win_row.enabled = (prefs.right_click_mode == 'PIE' or prefs.right_click_mode == 'BOTH')
    pie_win_row.prop(prefs, "enable_window_editors_pie", text="Window Editors", 
                    icon="RESTRICT_VIEW_OFF" if prefs.enable_window_editors_pie else "RESTRICT_VIEW_ON", toggle=True)

class ST_PT_DisplaySettingsPopup(bpy.types.Panel):
    bl_label = "N-Panel Display Settings"
    bl_idname = "ST_PT_DisplaySettingsPopup"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 45

    def draw(self, context):
        shared_draw_display_settings(self, context)

class ST_PT_DisplaySettingsPopup_UV(bpy.types.Panel):
    bl_label = "N-Panel Display Settings (UV Editor)"
    bl_idname = "ST_PT_DisplaySettingsPopup_UV"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 25

    def draw(self, context):
        shared_draw_display_settings(self, context)

class ST_PT_DisplaySettingsPopup_Image(bpy.types.Panel):
    bl_label = "N-Panel Display Settings (Image Editor)"
    bl_idname = "ST_PT_DisplaySettingsPopup_Image"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 25

    def draw(self, context):
        shared_draw_display_settings(self, context)

class ST_PT_DisplaySettingsPopup_Node(bpy.types.Panel):
    bl_label = "N-Panel Display Settings (Node)"
    bl_idname = "ST_PT_DisplaySettingsPopup_Node"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 25

    def draw(self, context):
        shared_draw_display_settings(self, context)