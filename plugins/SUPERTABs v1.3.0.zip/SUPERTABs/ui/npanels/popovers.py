import bpy
from ...properties import _restricted_icon_enum_items

class ST_PT_EjectedItemsPopover(bpy.types.Panel):
    bl_label = "Ejected Items"
    bl_idname = "ST_PT_EjectedItemsPopover"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 25
    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if prefs.temporarily_ejected_items:
            box = layout.box()
            box.alert = True
            box.label(text="Ejected Items:")
            items_list = sorted([item.strip() for item in prefs.temporarily_ejected_items.split(',') if item.strip()])
            col = box.column(align=True)
            for item_string in items_list:
                item_type, item_name = (item_string.split(":", 1) + [""])[:2]
                icon = "PLUGIN" if item_type == "addon" else "EVENT_T"
                display_text = next((l.display_name for l in prefs.addon_display_lookup if l.name == item_name), item_name) if item_type == "addon" else item_name
                op = col.operator("st.regroup_item", text=display_text, icon=icon)
                op.item_string = item_string
        else:
            layout.label(text="No items ejected.")

class ST_PT_EjectedSubgroupsPopover(bpy.types.Panel):
    bl_label = "Ejected Subgroups"
    bl_idname = "ST_PT_EjectedSubgroupsPopover"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 20

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        ejected_list = sorted([s.strip() for s in prefs.ejected_subgroups.split(',') if s.strip()])
        if ejected_list:
            box = layout.box()
            box.alert = True
            col = box.column(align=True)
            for subgroup_full_name in ejected_list:
                op = col.operator("st.restore_ejected_subgroup", text=subgroup_full_name, icon='PANEL_CLOSE')
                op.subgroup_full_name = subgroup_full_name
        else:
            layout.label(text="No subgroups are ejected.")
            
class ST_PT_HiddenSubgroupsPopover(bpy.types.Panel):
    bl_label = "Hidden Subgroups"
    bl_idname = "ST_PT_HiddenSubgroupsPopover"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 20

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        hidden_list = sorted([s.strip() for s in prefs.hidden_subgroups.split(',') if s.strip()])
        if hidden_list:
            box = layout.box()
            box.alert = True
            col = box.column(align=True)
            for full_name in hidden_list:
                display_name = full_name.split(' / ', 1)[-1]
                op = col.operator("st.restore_hidden_subgroup", text=display_name, icon='GHOST_ENABLED')
                op.subgroup_full_name = full_name
        else:
            layout.label(text="No subgroups are hidden.")

class ST_PT_HiddenItemsPopover(bpy.types.Panel):
    bl_label = "Hidden Items"
    bl_idname = "ST_PT_HiddenItemsPopover"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 20

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        hidden_list = sorted([s.strip() for s in prefs.hidden_items.split(',') if s.strip()])
        if hidden_list:
            box = layout.box()
            box.alert = True
            col = box.column(align=True)
            for item_string in hidden_list:
                item_type, item_name = (item_string.split(":", 1) + [""])[:2]
                icon = "PLUGIN" if item_type == "addon" else "EVENT_T"
                display_text = next((l.display_name for l in prefs.addon_display_lookup if l.name == item_name), item_name) if item_type == "addon" else item_name
                op = col.operator("st.restore_hidden_item", text=display_text, icon=icon)
                op.item_string = item_string
        else:
            layout.label(text="No items are hidden.")

class ST_PT_FavoriteIconPicker(bpy.types.Panel):
    bl_label = "Select an Icon"
    bl_idname = "ST_PT_FavoriteIconPicker"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_ui_units_x = 15

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        preset_index = getattr(wm, 'st_preset_icon_picker_index', -1)

        if preset_index == -1:
            layout.label(text="Error: No preset context.")
            return

        all_presets = prefs.custom_favorite_presets

        current_slot_icon = all_presets[preset_index].icon if 0 <= preset_index < len(all_presets) else None
        
        used_icons_by_others = {
            preset.icon for i, preset in enumerate(all_presets) if i != preset_index
        }

        icon_list = [item[0] for item in _restricted_icon_enum_items]
        grid = layout.grid_flow(row_major=True, columns=6, even_columns=True, align=True)

        for icon_name in icon_list:
            is_used_by_other = icon_name in used_icons_by_others
            is_current = (icon_name == current_slot_icon)
            col = grid.column()
            col.enabled = not is_used_by_other
            op = col.operator("st.set_favorite_preset_icon", text="", icon=icon_name, depress=is_current)
            op.preset_index = preset_index
            op.icon_name = icon_name