import bpy

def draw_node_stats_panel(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    space = context.space_data
    current_tree = getattr(space, 'tree_type', '')
    should_show = False
    
    if current_tree == 'GeometryNodeTree': should_show = prefs.st_node_stats_geometry
    elif current_tree == 'ShaderNodeTree': should_show = prefs.st_node_stats_shading
    elif current_tree == 'CompositorNodeTree': should_show = prefs.st_node_stats_compositor
    elif current_tree == 'TextureNodeTree': should_show = prefs.st_node_stats_texture
    else: should_show = prefs.show_node_stats_panel

    if should_show:
        space = context.space_data
        
        tree = getattr(space, 'edit_tree', None)
        if not tree:
            tree = space.node_tree
        
        from ...operators.ops_nodes import get_node_statistics
        
        stats_box = layout.box()
        
        if not tree:
            stats_box.label(text="No Node Tree active.")
            return

        is_inside_group = (tree != space.node_tree)
        if is_inside_group:
            box_info = stats_box.box()
            row_info = box_info.row(align=True)
            row_info.label(text=f"Group: {tree.name}", icon='NODE')
            row_info.scale_x = 0.5
            row_info.alert = True
            op_exit = row_info.operator("node.tree_path_parent", text="Back", icon='FILE_PARENT')

        total, linked, unlinked, frames = get_node_statistics(tree)
        
        all_frames = {n for n in tree.nodes if n.type == 'FRAME'}
        used_frames = {n.parent for n in tree.nodes if n.parent}
        empty_frames_count = len(all_frames - used_frames)

        stat_col = stats_box.column()

        row_summary = stat_col.row(align=True)
        row_summary.alignment = 'EXPAND'
        
        row_summary.label(text=f"Total Nodes: {total}")
        row_summary.separator(factor=1.0)
        row_summary.label(text=f"Active Nodes: {linked}")
        row_summary.separator(factor=1.0)
        row_summary.label(text=f"Frames: {frames}")
        if prefs.show_guide:
            row_summary.separator(factor=0.5)
            op = row_summary.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
            op.url = "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"

        # Unlinked Nodes
        if unlinked > 0:
            row_main = stat_col.row(align=True)
            
            row_alert = row_main.row(align=True)
            row_alert.alert = True 
            row_alert.label(text=f"Unused Nodes: {unlinked}", icon='ERROR')
            
            row_scale = row_main.row(align=True)
            row_scale.scale_x = 0.5
            row_scale.operator("st.select_unlinked_nodes", text="Select", icon='RESTRICT_SELECT_OFF')
            row_main.operator("st.delete_unlinked_nodes", text="", icon='TRASH')

        # Empty Frames
        if empty_frames_count > 0:
            row_main = stat_col.row(align=True)
            
            row_alert = row_main.row(align=True)
            row_alert.alert = True
            row_alert.label(text=f"Empty Frames: {empty_frames_count}", icon='ERROR')
            
            row_scale = row_main.row(align=True)
            row_scale.scale_x = 0.5
            row_scale.operator("st.select_empty_frames", text="Select", icon='RESTRICT_SELECT_OFF')
            row_main.operator("st.delete_empty_frames", text="", icon='TRASH')
        

def draw_node_align_panel(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences

    space = context.space_data
    current_tree = getattr(space, 'tree_type', '')
    should_show = False
    
    if current_tree == 'GeometryNodeTree': should_show = prefs.st_node_align_geometry
    elif current_tree == 'ShaderNodeTree': should_show = prefs.st_node_align_shading
    elif current_tree == 'CompositorNodeTree': should_show = prefs.st_node_align_compositor
    elif current_tree == 'TextureNodeTree': should_show = prefs.st_node_align_texture
    else: should_show = prefs.show_node_align_panel

    if should_show:
        align_box = layout.box()
        
        header_row = align_box.row(align=True)
        header_row.label(text="Arrange Nodes", icon="ALIGN_CENTER")
        if prefs.show_guide:
            header_row.separator(factor=0.5)
            op = header_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
            op.url = "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"

        selected_count = 0
        space = context.space_data
        if space.node_tree:
            for node in space.node_tree.nodes:
                if node.select:
                    selected_count += 1

        col = align_box.column(align=True)
        if selected_count < 2:
            row = col.row(align=True)
            row.alert = True
            row.label(text="Select Multiple Nodes(2+)", icon='INFO')
        else:
            if prefs.node_align_buttons:
                row = col.row(align=True)
                row.label(text="Align:")
                op_x = row.operator("st.node_align", text="X")
                op_x.axis = 'X'
                op_y = row.operator("st.node_align", text="Y")
                op_y.axis = 'Y'

            if prefs.node_distribute_buttons:
                row = col.row(align=True)
                row.label(text="Distribute:")
                op_dx = row.operator("st.node_distribute", text="X")
                op_dx.axis = 'X'
                op_dy = row.operator("st.node_distribute", text="Y")
                op_dy.axis = 'Y'

            col.separator(factor=0.5)

            if prefs.node_rotate_buttons:
                row = col.row(align=True)
                row.label(text="Rotate:")
                op_r90 = row.operator("st.node_rotate", text="90°")
                op_r90.angle = 90
                op_r180 = row.operator("st.node_rotate", text="180°")
                op_r180.angle = 180

def draw_nodes_zoom_panel(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    space = context.space_data
    if space.type == 'NODE_EDITOR':
        valid_trees = {'GeometryNodeTree', 'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree'}
        if getattr(space, 'tree_type', '') in valid_trees:
            col = layout.column(align=True)
            if prefs.show_geo_zoom_buttons:
                    zoom_col = col.column() 
                    row = zoom_col.row(align=True)
                    has_selection = False
                    if space.node_tree:
                        for node in space.node_tree.nodes:
                            if node.select:
                                has_selection = True
                                break
                    if has_selection:
                        op_in = row.operator("st.focus_and_zoom", text="Focus", icon='VIEWZOOM')
                        op_in.mode = 'IN'
                    else:
                        op_in = row.operator("st.focus_and_zoom", text="Zoom In", icon='ADD')
                        op_in.mode = 'IN'
                    row.operator("st.reset_node_zoom", text="View Home", icon='HOME')
                    op_out = row.operator("st.focus_and_zoom", text="Zoom Out", icon='REMOVE')
                    op_out.mode = 'OUT'
                    if prefs.show_guide:
                        row.separator(factor=0.5)
                        op = row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                        op.url = "https://www.notion.so/SUPERTABs-Tools-Header-Guide-N-Panel-ALL-EDITORS-v1-3-0-REMAKE-2e9b1f0a835380f1947dfac293265c7d?source=copy_link"

def draw_fav_nodes_panel(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    space = context.space_data
    if space.type == 'NODE_EDITOR':
        valid_trees = {'GeometryNodeTree', 'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree'}
        current_tree = getattr(space, 'tree_type', '')

        target_vis_prop = "show_favorite_nodes_panel"
        target_exp_prop = "show_favorite_nodes_panel"
        target_col_prop = "favorite_nodes_columns"

        if current_tree == 'GeometryNodeTree': 
            target_vis_prop = "st_node_show_fav_nodes_geometry"
            target_exp_prop = "st_node_expand_fav_geometry"
            target_col_prop = "st_node_fav_cols_geometry"
        elif current_tree == 'ShaderNodeTree': 
            target_vis_prop = "st_node_show_fav_nodes_shading"
            target_exp_prop = "st_node_expand_fav_shading"
            target_col_prop = "st_node_fav_cols_shading" 
        elif current_tree == 'CompositorNodeTree': 
            target_vis_prop = "st_node_show_fav_nodes_compositor"
            target_exp_prop = "st_node_expand_fav_compositor"
            target_col_prop = "st_node_fav_cols_compositor"
        elif current_tree == 'TextureNodeTree': 
            target_vis_prop = "st_node_show_fav_nodes_texture"
            target_exp_prop = "st_node_expand_fav_texture"
            target_col_prop = "st_node_fav_cols_texture"

        is_visible = getattr(prefs, target_vis_prop, True)
        if is_visible:
            fav_box = layout.box()
            fav_col = fav_box.column()
            
            is_expanded = getattr(prefs, target_exp_prop, True)
            head_row = fav_col.row(align=True)
            icon = "TRIA_DOWN" if is_expanded else "TRIA_RIGHT"
            
            if hasattr(prefs, target_exp_prop):
                head_row.prop(prefs, target_exp_prop, text="Node Favorites", icon=icon, emboss=False)
            else:
                head_row.label(text="Node Favorite(Error)", icon='ERROR')
            
            if is_expanded:
                all_favs_in_tree = []
                for i, item in enumerate(prefs.favorite_nodes):
                    if item.tree_type == current_tree:
                        all_favs_in_tree.append((i, item))
                
                if all_favs_in_tree:
                    mode_row = fav_col.row(align=True)
                    mode_row.prop(prefs, "fav_node_view_mode", expand=True) 
                    fav_col.separator(factor=0.5)

                    display_list = []
                    current_mode = getattr(prefs, "fav_node_view_mode", 'NODES')

                    for idx, item in all_favs_in_tree:
                        if current_mode == 'NODES' and not item.is_group:
                            display_list.append((idx, item))
                        elif current_mode == 'GROUPS' and item.is_group:
                            display_list.append((idx, item))
                    
                    if not display_list:
                        box_empty = fav_col.box()
                        box_empty.label(text=f"No {current_mode.lower()} found.", icon='INFO')
                    
                    
                    if prefs.show_node_fav_options:
                        # settings_box = fav_col.box()
                        settings_col = fav_col.column(align=True)
                        
                        for idx, item in display_list:
                            row_item = settings_col.row(align=True)
                            btn_icon = row_item.operator("st.set_fav_node_icon_popup", text="", icon=item.icon)
                            btn_icon.fav_index = idx
                            row_item.prop(item, "label", text="")
                            op_rem = row_item.operator("st.remove_favorite_node", text="", icon='X')
                            op_rem.index = idx

                    else:
                        fav_row = fav_col.row(align=True)
                        cols = fav_row.column(align=True)

                        current_cols = getattr(prefs, target_col_prop, 3)
                        grid = cols.grid_flow(columns=current_cols, align=True)
                        
                        for idx, item in display_list:
                            row_btn = grid.row(align=True)
                            op = row_btn.operator("st.place_favorite_node", text=item.label, icon=item.icon) 
                            op.node_idname = item.node_idname
                            op.fav_index = idx

                    if prefs.show_node_fav_options:
                        scale_row = head_row.row()
                        scale_row.scale_x = 0.5

                        if hasattr(prefs, target_col_prop):
                            scale_row.prop(prefs, target_col_prop, text="")
                        else:
                            scale_row.label(text="N/A")
                        
                        head_row.separator(factor=0.5)
                        scale_row = head_row.row(align=True)
                        scale_row.scale_x = 1.25
                        
                        head_row.separator(factor=0.5)
                        row_alert = head_row.row(align=True)
                        row_alert.alert = True
                        row_alert.operator("st.clear_favorite_nodes", text="", icon='TRASH')

                    head_row.separator(factor=0.5)
                    head_row.prop(prefs, "show_node_fav_options", text="", icon="DOWNARROW_HLT" if prefs.show_node_fav_options else "RIGHTARROW", toggle=True)
                    
                else:
                    fav_col.label(text="No Favorites yet.", icon='INFO')
                    fav_col.label(text="Right-click a node to add.", icon='MOUSE_RMB')

            if prefs.show_guide:
                head_row.separator(factor=0.5)
                op = head_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
                op.url = "https://www.notion.so/SUPERTABs-Favorite-Nodes-Guide-N-Panel-NODE-EDITORS-v1-3-0-NEW-2d1b1f0a835380c89b62de02c7675a96?source=copy_link"

def draw_frequency_panel_nodes(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    space = context.space_data
    if space.type == 'NODE_EDITOR':
        valid_trees = {'GeometryNodeTree', 'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree'}
        current_tree = getattr(space, 'tree_type', '')
        if current_tree in valid_trees:
            box = layout.box()
            col = box.column(align=True)

            if prefs.show_quick_node:
                split = col.split()
                target_stats = "show_node_stats_panel"
                target_align = "show_node_align_panel"
                target_anno  = "show_annotations_nodes"

                if current_tree == 'GeometryNodeTree':
                    target_stats = "st_node_stats_geometry"
                    target_align = "st_node_align_geometry"
                    target_anno  = "st_node_anno_geometry"
                elif current_tree == 'ShaderNodeTree':
                    target_stats = "st_node_stats_shading"
                    target_align = "st_node_align_shading"
                    target_anno  = "st_node_anno_shading"
                elif current_tree == 'CompositorNodeTree':
                    target_stats = "st_node_stats_compositor"
                    target_align = "st_node_align_compositor"
                    target_anno  = "st_node_anno_compositor"
                elif current_tree == 'TextureNodeTree':
                    target_stats = "st_node_stats_texture"
                    target_align = "st_node_align_texture"
                    target_anno  = "st_node_anno_texture"

                if prefs.show_node_stats_button:
                    split.prop(prefs, target_stats, text="", icon="STATUSBAR", toggle=True)
                if prefs.show_geo_align_button:
                    split.prop(prefs, target_align, text="", icon="ALIGN_CENTER", toggle=True)
                if prefs.show_view_home_button:
                    split.operator("st.reset_node_zoom", text="", icon='HOME')
                if prefs.show_collapse_socket_button:
                    split.operator("st.collapse_all_unused", text="", icon='FULLSCREEN_EXIT')
                if current_tree == 'GeometryNodeTree':
                    if prefs.show_geo_timing_button:
                        if hasattr(space, "overlay"):
                            split.prop(space.overlay, "show_timing", text="", icon="SORTTIME", toggle=True)
                    if prefs.show_geo_named_attribute_button:
                        if hasattr(space, "overlay"):
                            split.prop(space.overlay, "show_named_attributes", text="", icon="TEXT", toggle=True)
                if prefs.show_anno_node_button:
                    split.prop(prefs, target_anno, text="", icon='GREASEPENCIL', toggle=True)
                if prefs.show_cleandata_nodes_button:
                    split.operator('st.pt_purgedata_menu',text="" , icon='ORPHAN_DATA')
                    