import bpy
import addon_utils
from ...properties import _restricted_icon_enum_items

def draw_external_data_panel(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    space = context.space_data
    if space.type == 'IMAGE_EDITOR':
        box = layout.box()
        col = box.column()
        is_autopack_on = bpy.data.use_autopack
        if prefs.auto_pack_toggle:
            col.operator("file.autopack_toggle", text="Auto Pack Resources", icon="CHECKBOX_HLT" if is_autopack_on else "CHECKBOX_DEHLT", depress=is_autopack_on)

        if prefs.toggle_pack_resources:
            external_row = col.row(align=True)
            external_row.operator('file.pack_all', text="Pack Resources")
            external_row.operator('file.unpack_all', text="Unpack Resources")
        
        if prefs.toggle_pack_linked:
            external_row = col.row(align=True)
            external_row.operator('file.pack_libraries', text="Pack Linked Libraries")
            external_row.operator('file.unpack_libraries', text="Unpack Linked Libraries")

        if prefs.toggle_make_path:
            external_row = col.row(align=True)
            external_row.operator('file.make_paths_relative', text="Make Paths Relative")
            external_row.operator('file.make_paths_absolute', text="Make Paths Absolute")

        if prefs.toggle_missing_files:
            external_row = col.row(align=True)
            external_row.operator('file.report_missing_files', text="Report Missing Files")
            external_row.operator('file.find_missing_files', text="Find Missing Files")

def _draw_image_content(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    sima = context.space_data
    data_source = sima.image
    
    if not data_source:
        box = layout.box()
        box.label(text="No Image Data", icon="INFO")
        return
    
    image_box = layout.box()
    image_col = image_box.column()
    
    # image_row = image_col.row(align=True)
    # image_row.template_ID(sima, "image", new="image.new", open="image.open")
    
    image_col.separator(factor=0.25)
    source_box = image_col.box()
    source_col = source_box.column()
    main_grid = source_col.grid_flow(columns=2, align=True, row_major=True, even_columns=False, even_rows=False)
    main_grid.prop(data_source, "source", text="Source") 
    source_col.separator(factor=0.25)
    
    iuser = context.space_data.image_user
    if data_source.source == 'GENERATED':
        gen_box = source_col.box()
        gen_col = gen_box.column()
        gen_row = gen_col.row(align=True)
        gen_row.prop(data_source, "generated_width", text="W")
        gen_row.prop(data_source, "generated_height", text="H")
        icon = "CHECKBOX_HLT" if data_source.use_generated_float else "CHECKBOX_DEHLT"
        gen_col.prop(data_source, "use_generated_float", text="Float Buffer", icon=icon)

        color_col = source_col.column()
        gen_row = color_col.row(align=True)
        gen_row.label(text="Type:")
        gen_row.prop(data_source, "generated_type", text=" ", expand=True)
        
        gen_row = source_col.row(align=True)
        gen_row.label(text="Color:")
        scale_row = gen_row.row(align=True)
        scale_row.scale_x = 1.75
        scale_row.prop(data_source, "generated_color", text="")
        gen_row = source_col.row(align=True)
        gen_row.label(text="Color Space:")
        scale_row = gen_row.row(align=True)
        scale_row.scale_x = 1.75
        scale_row.prop(data_source.colorspace_settings, "name", text="")

    elif data_source.source == 'TILED':
        tiled_box = source_col.box()
        tiled_col = tiled_box.column()
        tiled_row = tiled_col.row(align=True)
        tiled_row.operator("image.pack", text="", icon="UGLYPACKAGE")
        tiled_row.prop(data_source, "filepath", text="")
        tiled_row.operator("image.reload", text="", icon="FILE_REFRESH")
        tiled_col.separator(factor=0.25)

        tiled_row = tiled_col.row(align=True)
        tiled_row.prop(data_source.colorspace_settings, "name", text="")

        tiled_row = tiled_col.row(align=True)
        tiled_row.prop(data_source, "alpha_mode", text="Alpha:", expand=True)

        udim_main_box = layout.box()
        udim_main_col = udim_main_box.column()
        head_row = udim_main_col.row(align=True)

        head_row.prop(prefs, "udim_tiles_panel", text="", icon="DOWNARROW_HLT" if prefs.udim_tiles_panel else "RIGHTARROW", emboss=False)
        head_row.label(text="UDIM Tiles")

        if prefs.udim_tiles_panel:
            sima = context.space_data
            ima = sima.image
            udim_row = udim_main_box.row(align=True)
            udim_col = udim_row.column()
            udim_col.template_list("IMAGE_UL_udim_tiles", "", ima, "tiles", ima.tiles, "active_index", rows=4)
            udim_row.separator(factor=0.25)
            op_col = udim_row.column()
            sub = op_col.column(align=True)
            sub.operator("image.tile_add", icon='ADD', text="")
            sub.operator("image.tile_remove", icon='REMOVE', text="")

            tile = ima.tiles.active
            if tile:
                udim_main_col.separator(factor=0.25)
                udim_main_col = udim_main_box.column(align=True)
                udim_main_col.operator("image.tile_fill")

            zen_uv_exists, zen_uv_enabled = addon_utils.check("ZenUV")
            if zen_uv_enabled:
                udim_main_col.separator(factor=0.5)
                zen_udim_col = udim_main_col.column()
                zen_udim_row = zen_udim_col.row(align=True)
                zen_udim_row.prop(prefs, "zen_udim_tools", text="", icon="DOWNARROW_HLT" if prefs.zen_udim_tools else "RIGHTARROW", emboss=False)
                row_scale = zen_udim_row.row(align=True)
                row_scale.scale_x = 0.6
                row_scale.label(text="UDIM Tools:")
                alert_row = zen_udim_row.row(align=True)
                alert_row.alert = True
                alert_row.label(text="(ZenUV)")
                if prefs.zen_udim_tools:
                    zen_udim_col = udim_main_col.column()
                    zen_udim_col.enabled = context.space_data.image.source == 'TILED'

                    zen_udim_col.operator( "uv.zenuv_add_missed_udim", text='Add Missed')
                    row = zen_udim_col.row(align=True)
                    row.operator( "uv.zenuv_set_active_udim", text='Set Active')
                    row.operator( "uv.zenuv_remove_active_udim_tile", text='Remove Active')

                    row = zen_udim_col.row(align=True)
                    op = row.operator( "uv.zenuv_select_in_tile", text='Select In Active')
                    op.clear_selection = True
                    op.base = 'ACTIVE_UDIM'
                    op.location = 'INSIDE'
                    op = row.operator( "uv.zenuv_move_to_uv_area", text='Move To Active')
                    op.move_mode = 'ACTIVE_UDIM'

                    zen_udim_col.operator( "uv.zenuv_set_active_udim_mouseover", text='Set Active', icon='EYEDROPPER')
                    zen_udim_col.operator( "uv.zenuv_move_to_uv_area_mouseover", icon='EYEDROPPER')

    elif data_source.source == 'FILE':
        file_box = source_col.box()
        file_col = file_box.column()
        file_row = file_col.row(align=True)
        file_row.operator("image.pack", text="", icon="UGLYPACKAGE")
        file_row.prop(data_source, "filepath", text="")
        file_row.operator("image.reload", text="", icon="FILE_REFRESH")

        file_row = image_col.row(align=True)
        file_row.prop(data_source.colorspace_settings, "name", text="")

    elif data_source.source == 'SEQUENCE':
        seq_box = source_col.box()
        seq_col = seq_box.column()
        seq_row = seq_col.row(align=True)
        seq_row.operator("image.pack", text="", icon="UGLYPACKAGE")
        seq_row.prop(data_source, "filepath", text="")
        seq_row.operator("image.reload", text="", icon="FILE_REFRESH")
        
        seq_col.separator(factor=0.25)

        seq_box = seq_col.box()
        frame_col = seq_box.column()

        seq_row = frame_col.row(align=True)
        seq_row.prop(iuser, "frame_duration", text="Frames")
        seq_row.operator("image.match_movie_length", text="", icon="FILE_REFRESH")
        
        seq_row = frame_col.row(align=True)
        seq_row.prop(iuser, "frame_start", text="Start")
        seq_row.prop(iuser, "frame_offset", text="Offset")

        seq_col.separator(factor=0.25)
        seq_row = seq_col.row(align=True)
        icon = "CHECKBOX_HLT" if iuser.use_cyclic else "CHECKBOX_DEHLT"
        seq_row.prop(iuser, "use_cyclic", text="Cyclic", icon=icon, toggle=True)
        icon = "CHECKBOX_HLT" if iuser.use_auto_refresh else "CHECKBOX_DEHLT"
        seq_row.prop(iuser, "use_auto_refresh", text="Auto Refresh", icon=icon, toggle=True)

        seq_row = image_col.row(align=True)
        seq_row.prop(data_source.colorspace_settings, "name", text="")

    elif data_source.source == 'MOVIE':
        mov_box = source_col.box()
        mov_col = mov_box.column()
        mov_row = mov_col.row(align=True)
        mov_row.operator("image.pack", text="", icon="UGLYPACKAGE")
        mov_row.prop(data_source, "filepath", text="")
        mov_row.operator("image.reload", text="", icon="FILE_REFRESH")

        mov_col.separator(factor=0.25)

        mov_box = mov_col.box()
        frame_col = mov_box.column()

        mov_row = frame_col.row(align=True)
        mov_row.prop(iuser, "frame_duration", text="Frames")
        mov_row.operator("image.match_movie_length", text="", icon="FILE_REFRESH")
        
        mov_row = frame_col.row(align=True)
        mov_row.prop(iuser, "frame_start", text="Start")
        mov_row.prop(iuser, "frame_offset", text="Offset")

        mov_col.separator(factor=0.25)
        mov_row = mov_col.row(align=True)
        icon = "CHECKBOX_HLT" if iuser.use_cyclic else "CHECKBOX_DEHLT"
        mov_row.prop(iuser, "use_cyclic", text="Cyclic", icon=icon, toggle=True)
        icon = "CHECKBOX_HLT" if iuser.use_auto_refresh else "CHECKBOX_DEHLT"
        mov_row.prop(iuser, "use_auto_refresh", text="Auto Refresh",icon=icon, toggle=True)
        icon = "CHECKBOX_HLT" if data_source.use_deinterlace else "CHECKBOX_DEHLT"
        mov_row.prop(data_source, "use_deinterlace", text="Deinterlace", icon=icon, toggle=True)

        mov_row = image_col.row(align=True)
        mov_row.prop(data_source.colorspace_settings, "name", text="")

    image_row = image_col.row(align=True)
    icon = "CHECKBOX_HLT" if data_source.use_view_as_render else "CHECKBOX_DEHLT"
    image_row.prop(data_source, "use_view_as_render", text="View as Render", icon=icon)
    image_row.separator(factor=0.25)
    image_row.prop(data_source, "seam_margin", text="Seam Margin")

def draw_basic_panel_image(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences

    if context.space_data.type == 'IMAGE_EDITOR':
        col = layout.column()
        main_row = col.row(align=True)
        
        if prefs.show_image_section:
            if context.space_data.mode == 'UV':
                is_open = getattr(prefs, "show_image_panel_uv", False)
                main_row.prop(prefs, "show_image_panel_uv", text="Image", toggle=True)
                if is_open:
                    _draw_image_content(col, context)
            else:
                is_open = getattr(prefs, "show_image_panel", False)
                main_row.prop(prefs, "show_image_panel", text="Image", toggle=True)
                if is_open:
                    _draw_image_content(col, context)

def draw_frequency_panel_image(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    space = context.space_data
    if space.type == 'IMAGE_EDITOR':
        box = layout.box()
        col = box.column(align=True)
        if prefs.show_quick_uv:
            split = col.split()
            
            if space.mode == 'UV': # and context.mode == 'EDIT_MESH'
                if hasattr(space, "uv_editor") and prefs.show_uv_stretch:
                    split.prop(space.uv_editor, "show_stretch", text="", icon="OVERLAY")
                if prefs.show_uv_sync:
                    scene = context.scene
                    split.prop(scene.tool_settings, "use_uv_select_sync", text="", icon='UV_SYNC_SELECT')    
                if prefs.show_uv_average_scale:
                    split.operator("uv.average_islands_scale", text="", icon='AUTOMERGE_ON')
                if prefs.show_uv_pack_islands:
                    split.operator("uv.pack_islands", text="", icon='PACKAGE')
                if prefs.show_uv_select_overlap:
                    split.operator("uv.select_overlap", text="", icon='RESTRICT_SELECT_OFF')
                if prefs.show_reset_uv:
                    split.operator("uv.reset", text="", icon='FILE_REFRESH')
                if prefs.show_export_uv:
                    split.operator("uv.export_layout", text="", icon='EXPORT')
                if prefs.show_live_unwrap:
                    icon = "RADIOBUT_ON" if space.uv_editor.use_live_unwrap else "RADIOBUT_OFF"
                    split.prop(space.uv_editor, "use_live_unwrap", text="", icon=icon)    
                if prefs.show_anno_uv_button:
                    split.prop(prefs, 'show_annotations_uv', text="", icon='GREASEPENCIL', toggle=True)
            else:
                if prefs.show_image_resize:
                    split.operator('image.resize', text="", icon='CON_SIZELIKE')
                if prefs.show_image_replace:
                    split.operator('image.replace', text="", icon='GESTURE_ROTATE')
                if prefs.show_save_as_copy:
                    op = split.operator('image.save_as', text="", icon='COPY_ID')
                    op.copy = True
                if prefs.show_save_all_image:
                    split.operator('image.save_all_modified', text="", icon='FILE_TICK')
                if prefs.show_external_edit:
                    split.operator('image.external_edit', text="", icon='FOLDER_REDIRECT')
                if prefs.show_external_data:
                    split.prop(prefs, 'show_external_data_panel', text="", icon='OUTLINER_DATA_GP_LAYER', toggle=True)
                if prefs.show_cleandata_image_button:
                    split.operator('st.pt_purgedata_menu',text="" , icon='ORPHAN_DATA')
                if prefs.show_anno_image_button:
                    split.prop(prefs, 'show_annotations_image', text="", icon='GREASEPENCIL', toggle=True)
