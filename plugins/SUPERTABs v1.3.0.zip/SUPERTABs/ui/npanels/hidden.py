import bpy

class ST_PT_HiddenPanel(bpy.types.Panel):
    bl_idname = "ST_PT_HiddenPanel"
    bl_label = "SuperTabs Hidden Panels"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "ST_HIDDEN"
    @classmethod
    def poll(cls, context): return False
    def draw(self, context): pass

class ST_PT_HiddenPanel_UV(bpy.types.Panel):
    bl_idname = "ST_PT_HiddenPanel_UV"
    bl_label = "SuperTabs Hidden Panels UV"
    bl_space_type = 'IMAGE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "ST_HIDDEN"
    @classmethod
    def poll(cls, context): return False
    def draw(self, context): pass

class ST_PT_HiddenPanel_Node(bpy.types.Panel):
    bl_idname = "ST_PT_HiddenPanel_Node"
    bl_label = "SuperTabs Hidden Panels Node"
    bl_space_type = 'NODE_EDITOR'
    bl_region_type = 'UI'
    bl_category = "ST_HIDDEN"
    @classmethod
    def poll(cls, context): return False
    def draw(self, context): pass