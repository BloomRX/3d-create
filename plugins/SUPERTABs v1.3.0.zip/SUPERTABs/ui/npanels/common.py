import bpy

def draw_annotations_panel(layout, context):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    
    show_panel = False
    if context.space_data.type == 'VIEW_3D':
        show_panel = prefs.show_annotations_3dview
    elif context.space_data.type == 'IMAGE_EDITOR':
        if context.space_data.mode == 'UV':
            show_panel = prefs.show_annotations_uv
        else:
            show_panel = prefs.show_annotations_image
    elif context.space_data.type == 'NODE_EDITOR':
        current_tree = getattr(context.space_data, 'tree_type', '')
        if current_tree == 'GeometryNodeTree': show_panel = prefs.st_node_anno_geometry
        elif current_tree == 'ShaderNodeTree': show_panel = prefs.st_node_anno_shading
        elif current_tree == 'CompositorNodeTree': show_panel = prefs.st_node_anno_compositor
        elif current_tree == 'TextureNodeTree': show_panel = prefs.st_node_anno_texture
        else: show_panel = prefs.show_annotations_nodes

    if show_panel:
        annotations_section_layout = layout.column(align=True)
        annotations_content_box = annotations_section_layout.box()
        
        if not (gpd_owner := context.annotation_data_owner):
            annotations_content_box.label(text="No annotation source")
        else:
            row = annotations_content_box.row()
            prop_name = "grease_pencil"
            if not hasattr(gpd_owner, prop_name) and hasattr(gpd_owner, "annotation"):
                prop_name = "annotation"
            row.template_ID(gpd_owner, prop_name, new="gpencil.annotation_add", unlink="gpencil.data_unlink")
            if (gpd := context.annotation_data) and gpd.layers:
                row = annotations_content_box.row()
                col = row.column()
                col.template_list("GPENCIL_UL_annotation_layer", "", gpd, "layers", gpd.layers, "active_index", rows=5, sort_reverse=True, sort_lock=True)
                col = row.column(align=True)
                col.operator("gpencil.layer_annotation_add", icon='ADD', text="")
                col.operator("gpencil.layer_annotation_remove", icon='REMOVE', text="")
                if (gpl := context.active_annotation_layer) and len(gpd.layers) > 1:
                    col.separator()
                    sub = col.column(align=True)
                    sub.operator("gpencil.layer_annotation_move", icon='TRIA_UP', text="").type = 'UP'
                    sub.operator("gpencil.layer_annotation_move", icon='TRIA_DOWN', text="").type = 'DOWN'
                if gpl:
                    annotations_content_box.prop(gpl, "annotation_opacity", text="Opacity", slider=True)
                    annotations_content_box.prop(gpl, "thickness")
                    row = annotations_content_box.row(align=True)
                    row.active = not gpl.lock
                    lock_label = f"Frame: {gpl.active_frame.frame_number} (Locked)" if gpl.active_frame and gpl.lock_frame else "Lock Frame"
                    row.prop(gpl, "lock_frame", text=lock_label, icon='UNLOCKED')
                    row.operator("gpencil.annotation_active_frame_delete", text="", icon='X')

def draw_windoweditor_panel(layout, context, group_state):
    scene = context.scene
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    
    if prefs.show_editor_shortcuts_panel:
        main_box = layout.box()
        main_col = main_box.column()
    
        header_row = main_col.row()
        header_row.prop(group_state, "show_windoweditor_panel", text="Window Editors", icon="TRIA_DOWN" if group_state.show_windoweditor_panel else "TRIA_RIGHT", emboss=False)
        if prefs.show_guide:
            op = header_row.operator("wm.url_open", text="", icon='QUESTION', emboss=False)
            op.url = "https://www.notion.so/SUPERTABs-Window-Editor-Guide-N-Panel-WIP-29bb1f0a835380b9b9cbff4e8ae5f46a?source=copy_link"
        if group_state.show_windoweditor_panel:
            
            # --- Main Row with 4 Columns ---
            main_row = main_col.row(align=True) 
            
            # --- Column 1 (General) ---
            if prefs.show_general:
                col1 = main_row.column(align=True)
                box_general = col1.box()
                col_general = box_general.column(align=True)
                col_general.label(text="General:")

                if prefs.show_3Dview:
                    op_3d = col_general.operator("st.open_editor_window", text="3D Viewport", icon='VIEW3D')
                    op_3d.editor_type = 'VIEW_3D'
                if prefs.show_image:
                    op_img = col_general.operator("st.open_editor_window", text="Image Editor", icon='IMAGE')
                    op_img.editor_type = 'IMAGE_EDITOR'
                if prefs.show_uv:
                    op_uv = col_general.operator("st.open_editor_window", text="UV Editor", icon='UV')
                    op_uv.editor_type = 'UV'
                    op_uv.mode = 'UV'
                if prefs.show_geo:
                    op_geo = col_general.operator("st.open_editor_window", text="Geometry Node", icon='GEOMETRY_NODES')
                    op_geo.editor_type = 'GeometryNodeTree'
                    op_geo.tree_type = 'GeometryNodeTree'
                if prefs.show_comp:
                    op_comp = col_general.operator("st.open_editor_window", text="Compositor", icon='NODE_COMPOSITING')
                    op_comp.editor_type = 'CompositorNodeTree'
                    op_comp.tree_type = 'CompositorNodeTree'
                if prefs.show_shader:
                    op_shader = col_general.operator("st.open_editor_window", text="Shader Editor", icon='NODE_MATERIAL')
                    op_shader.editor_type = 'ShaderNodeTree'
                    op_shader.tree_type = 'ShaderNodeTree'
                if prefs.show_texture:
                    op_texture = col_general.operator("st.open_editor_window", text="Texture Node Editor", icon='NODE_TEXTURE')
                    op_texture.editor_type = 'TextureNodeTree'
                    op_texture.tree_type = 'TextureNodeTree'
                if prefs.show_sequence:
                    op_sequence = col_general.operator("st.open_editor_window", text="Viedeo Sequencer", icon='SEQUENCE')
                    op_sequence.editor_type = 'SEQUENCE_EDITOR'
                if prefs.show_clip:
                    op_clip = col_general.operator("st.open_editor_window", text="Movie Clip Editor", icon='TRACKER')
                    op_clip.editor_type = 'CLIP_EDITOR'

            # --- Column 2 (Scripting) ---
            if prefs.show_scripting:
                col2 = main_row.column(align=True)
                box_script = col2.box()
                col_script = box_script.column(align=True)
                col_script.label(text="Scripting:")
                
                if prefs.show_system_console:
                    row_script = col_script.row(align=True)
                    row_script.alert = True
                    row_script.operator("wm.console_toggle", text="System Console", icon='SYSTEM')
                if prefs.show_text:
                    op_text = col_script.operator("st.open_editor_window", text="Text Editor", icon='TEXT')
                    op_text.editor_type = 'TEXT_EDITOR'
                if prefs.show_console:
                    op_py_console = col_script.operator("st.open_editor_window", text="Python Console", icon='CONSOLE')
                    op_py_console.editor_type = 'CONSOLE'
                if prefs.show_info:
                    op_info = col_script.operator("st.open_editor_window", text="Info", icon='INFO')
                    op_info.editor_type = 'INFO'
                if prefs.show_iconviewer:
                    row_icon = col_script.row(align=True)
                    row_icon.operator("iv.icons_show",text="Icon Viewer",icon="BLENDER")

            # --- Column 3 (Animation) ---
            if prefs.show_animation:
                col3 = main_row.column(align=True)
                box_anim = col3.box()
                col_anim = box_anim.column(align=True)
                col_anim.label(text="Animation:")
                
                if prefs.show_dopesheet:
                    op_dopesheet = col_anim.operator("st.open_editor_window", text="Dope Sheet", icon='ACTION')
                    op_dopesheet.editor_type = 'DOPESHEET'
                if prefs.show_timeline:
                    op_timeline = col_anim.operator("st.open_editor_window", text="Timeline", icon='TIME')
                    op_timeline.editor_type = 'TIMELINE'
                if prefs.show_graph:
                    op_graph = col_anim.operator("st.open_editor_window", text="Graph Editor", icon='GRAPH')
                    op_graph.editor_type = 'FCURVES'
                if prefs.show_drivers:
                    op_drivers = col_anim.operator("st.open_editor_window", text="Drivers", icon='DRIVER')
                    op_drivers.editor_type = 'DRIVERS'
                if prefs.show_nla:
                    op_nla = col_anim.operator("st.open_editor_window", text="Nonlinear Animation", icon='NLA')
                    op_nla.editor_type = 'NLA_EDITOR'

            # --- Column 4 (Data) ---
            if prefs.show_data:
                col4 = main_row.column(align=True)
                box_data = col4.box()
                col_data = box_data.column(align=True)
                col_data.label(text="Data:")

                if prefs.show_outliner:
                    op_outliner = col_data.operator("st.open_editor_window", text="OutLiner", icon='OUTLINER')
                    op_outliner.editor_type = 'OUTLINER'
                if prefs.show_props:
                    op_props = col_data.operator("st.open_editor_window", text="Properties", icon='PROPERTIES')
                    op_props.editor_type = 'PROPERTIES'
                if prefs.show_file:
                    op_file = col_data.operator("st.open_editor_window", text="File Browser", icon='TRACKER')
                    op_file.editor_type = 'FILES'
                if prefs.show_spread:
                    op_spread = col_data.operator("st.open_editor_window", text="Spreadsheet", icon='SPREADSHEET')
                    op_spread.editor_type = 'SPREADSHEET'

            if prefs.show_serpen:
                op_serpens = main_col.operator("st.open_editor_window", text="Visual Scripting Editor (Serpen)", icon='FILE_SCRIPT')
                op_serpens.editor_type = 'ScriptingNodesTree'
                op_serpens.tree_type = 'ScriptingNodesTree'