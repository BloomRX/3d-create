import bpy

_restricted_node_socket_icons = [
    'NODE_SOCKET_CLOSURE', 'NODE_SOCKET_BUNDLE', 'NODE_SOCKET_FLOAT', 
    'NODE_SOCKET_VECTOR', 'NODE_SOCKET_RGBA', 'NODE_SOCKET_SHADER', 
    'NODE_SOCKET_BOOLEAN', 'NODE_SOCKET_INT', 'NODE_SOCKET_STRING', 
    'NODE_SOCKET_OBJECT', 'NODE_SOCKET_IMAGE', 'NODE_SOCKET_GEOMETRY', 
    'NODE_SOCKET_COLLECTION', 'NODE_SOCKET_TEXTURE', 'NODE_SOCKET_MATERIAL', 
    'NODE_SOCKET_ROTATION', 'NODE_SOCKET_MENU', 'NODE_SOCKET_MATRIX',

    'STRIP_COLOR_01', 'STRIP_COLOR_02', 'STRIP_COLOR_03', 'STRIP_COLOR_04',
    'STRIP_COLOR_05', 'STRIP_COLOR_06', 'STRIP_COLOR_07', 'STRIP_COLOR_08', 'STRIP_COLOR_09',

    'LAYERGROUP_COLOR_01', 'LAYERGROUP_COLOR_02', 'LAYERGROUP_COLOR_03', 'LAYERGROUP_COLOR_04',
    'LAYERGROUP_COLOR_05', 'LAYERGROUP_COLOR_06', 'LAYERGROUP_COLOR_07', 'LAYERGROUP_COLOR_08',

     'COLLECTION_COLOR_01', 'COLLECTION_COLOR_02', 'COLLECTION_COLOR_03', 'COLLECTION_COLOR_04',
    'COLLECTION_COLOR_05', 'COLLECTION_COLOR_06', 'COLLECTION_COLOR_07', 'COLLECTION_COLOR_08', 'OUTLINER_COLLECTION',

    'OUTLINER_OB_MESH', 'OUTLINER_OB_CURVE', 'OUTLINER_OB_CAMERA',
    'OUTLINER_OB_LIGHT', 'OUTLINER_OB_ARMATURE', 'OUTLINER_OB_EMPTY',

    'OUTLINER_DATA_MESH', 'MATERIAL_DATA', 'TEXTURE_DATA', 'BONE_DATA',
    'NODE_MATERIAL', 'PHYSICS', 'PARTICLES',

    'MESH_ICOSPHERE', 'MESH_PLANE', 'SPHERE', 'MESH_TORUS',
    'META_BALL', 'META_CAPSULE', 'META_CUBE',
    'MESH_CONE', 'MESH_CYLINDER', 'MESH_GRID',
    'MODIFIER_DATA', 'MESH_MONKEY',

    'MODIFIER', 'MOD_ARRAY', 'MOD_BEVEL', 'MOD_BOOLEAN', 
    'MOD_MIRROR', 'MOD_SUBSURF', 'MOD_SOLIDIFY', 'GEOMETRY_NODES',

    'RENDER_STILL', 'RENDER_ANIMATION', 'SCENE', 'WORLD',
    'RESTRICT_VIEW_OFF','SOLO_ON', 'RESTRICT_RENDER_OFF', 'VIEW_PAN', 
]

_restricted_icon_enum_items = [
    (name, name.replace('NODE_SOCKET_', '').title(), "") 
    for name in _restricted_node_socket_icons
]

_subgroup_icon_options = [('NONE', "None", "No Icon", 'BLANK1', 0)] + [
    (name, name.replace('NODE_SOCKET_', '').title(), "", name, i + 1) 
    for i, name in enumerate(_restricted_node_socket_icons)
]

def update_subgroup_columns(self, context):
    """Update function to clamp the column count to the number of items."""
    try:
        addon_name = __package__.split('.')[0]
        prefs = context.preferences.addons[addon_name].preferences
        
        target_group = None
        for group in prefs.tab_groups:
            if group.name.endswith(f" / {self.name}"):
                target_group = group
                break
        
        if target_group:
            num_items = len([item for item in target_group.items.split(',') if item.strip()])
            max_val = min(4, max(1, num_items))
            
            if self.item_columns > max_val:
                self.item_columns = max_val
            
            if self.item_columns < 1:
                self.item_columns = 1
    except (AttributeError, KeyError):
        pass

# ===================================================================
#  HELPER FUNCTIONS FOR ITEMS (Sync & Updates)
# ===================================================================
def _sync_fav_node_to_prefs(self, context):
    if not self.name: return
    try:
        addon_name = __package__.split('.')[0]
        prefs = context.preferences.addons[addon_name].preferences
        main_group_pref = next((g for g in prefs.tab_groups if g.name == self.name), None)
        if main_group_pref:
            main_group_pref.show_favorite_nodes_panel = self.show_favorite_nodes_panel
    except (AttributeError, KeyError): pass

def _sync_fav_to_prefs(self, context):
    if not self.name: return
    try:
        addon_name = __package__.split('.')[0]
        prefs = context.preferences.addons[addon_name].preferences
        main_group_pref = next((g for g in prefs.tab_groups if g.name == self.name), None)
        if main_group_pref:
            main_group_pref.show_favorites_panel = self.show_favorites_panel
    except (AttributeError, KeyError): pass

def _sync_group_to_prefs(self, context):
    if not self.name: return
    try:
        addon_name = __package__.split('.')[0]
        prefs = context.preferences.addons[addon_name].preferences
        main_group_pref = next((g for g in prefs.tab_groups if g.name == self.name), None)
        if main_group_pref:
            main_group_pref.show_groupaddons_panel = self.show_groupaddons_panel
    except (AttributeError, KeyError): pass

def _sync_win_to_prefs(self, context):
    if not self.name: return
    try:
        addon_name = __package__.split('.')[0]
        prefs = context.preferences.addons[addon_name].preferences
        main_group_pref = next((g for g in prefs.tab_groups if g.name == self.name), None)
        if main_group_pref:
            main_group_pref.show_windoweditor_panel = self.show_windoweditor_panel
    except (AttributeError, KeyError): pass

def _sync_panel_manager_to_prefs(self, context):
    if not self.name: return
    try:
        addon_name = __package__.split('.')[0]
        prefs = context.preferences.addons[addon_name].preferences
        main_group_pref = next((g for g in prefs.tab_groups if g.name == self.name), None)
        if main_group_pref:
            main_group_pref.panel_manager = self.panel_manager
    except (AttributeError, KeyError): pass


def update_preset_name(self, context):
    """
    When a preset name is changed in the master list (prefs),
    validate it for GLOBAL uniqueness, and if valid,
    find the corresponding preset in the 'content' list (group_state)
    and rename it to match.
    """
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    wm = context.window_manager
    
    if not hasattr(wm, "tab_group_states"):
        return

    new_name = self.name.strip()

    old_name_for_revert = None
    all_master_names_for_find = {p.name for p in prefs.custom_favorite_presets}

    for state_find in wm.tab_group_states:
        orphans_in_this_state_find = []
        for preset_in_state_find in state_find.favorite_presets:
            if preset_in_state_find.name not in all_master_names_for_find:
                orphans_in_this_state_find.append(preset_in_state_find)

        if len(orphans_in_this_state_find) == 1:
            old_name_for_revert = orphans_in_this_state_find[0].name
            break

    if not new_name:
        bpy.ops.st.set_status_message('INVOKE_DEFAULT', message="Preset name cannot be empty.", type='ERROR')
        if old_name_for_revert:
            self.name = old_name_for_revert
        return

    is_duplicate = False
    for p in prefs.custom_favorite_presets:
        if p == self:
            continue
        if p.name == new_name:
            is_duplicate = True
            break
    if is_duplicate:
        message = f"Preset name '{new_name}' already exists. Names must be unique globally."
        bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='ERROR')
        if old_name_for_revert:
            self.name = old_name_for_revert
        return
    
    all_master_names = {p.name for p in prefs.custom_favorite_presets}
    old_name = None
    for state in wm.tab_group_states:
        orphans_in_this_state = []
        for preset_in_state in state.favorite_presets:
            if preset_in_state.name not in all_master_names:
                orphans_in_this_state.append(preset_in_state)

        if len(orphans_in_this_state) == 1:
            orphan_preset = orphans_in_this_state[0]
            old_name = orphan_preset.name
            orphan_preset.name = new_name
            if state.active_favorite_preset_name == old_name:
                state.active_favorite_preset_name = new_name


# ===================================================================
#  PROPERTY GROUP DEFINITIONS (Items)
# ===================================================================

class HiddenPanelItem(bpy.types.PropertyGroup):
    """Stores the identifier of a panel to be hidden"""
    panel_id: bpy.props.StringProperty(name="Panel Identifier")

class CustomItemName(bpy.types.PropertyGroup):
    identifier: bpy.props.StringProperty(name="Identifier")
    display_name: bpy.props.StringProperty(name="Display Name")
    icon: bpy.props.EnumProperty(items=_subgroup_icon_options, name="Icon",default='NONE')
    
class AvailableItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()
    display_name: bpy.props.StringProperty()
    selected: bpy.props.BoolProperty(name="", default=False)
    subgroup_name: bpy.props.StringProperty()

class FavoriteAddonItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Addon Module Name")

class AddonPresetItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Addon Module Name")

class CustomFavoritePreset(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Preset Name", default="Preset", update=update_preset_name)
    icon: bpy.props.EnumProperty(name="Icon", items=_restricted_icon_enum_items, default='NODE_SOCKET_FLOAT')
    items: bpy.props.StringProperty(name="Items")
    is_expanded_in_prefs: bpy.props.BoolProperty(name="Expanded in Preferences", default=True)
    main_group_name: bpy.props.StringProperty(name="Main Group Name")
    space_type: bpy.props.EnumProperty(name="Space Type",items=[('VIEW_3D', "3D View", ""),('IMAGE_EDITOR', "UV / Image Editor", ""),('NODE_EDITOR', "Geometry Nodes", "")],default='VIEW_3D')

class SubgroupColumnState(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()
    item_columns: bpy.props.IntProperty(name="Item Columns", default=4, min=1, update=update_subgroup_columns)

class ST_QuickShortcutItem(bpy.types.PropertyGroup):
    """Stores data for a single Quick Shortcut item"""
    identifier: bpy.props.StringProperty(name="Identifier")
    display_name: bpy.props.StringProperty(name="Display Name")
    main_group_name: bpy.props.StringProperty(name="Main Group Name")
    sub_group_name: bpy.props.StringProperty(name="Subgroup Name")
    icon: bpy.props.StringProperty(name="Icon Name", default='NONE')
    space_type: bpy.props.EnumProperty(name="Space Type",items=[('VIEW_3D', "3D View", ""),('IMAGE_EDITOR', "UV / Image Editor", ""),('NODE_EDITOR', "Geometry Nodes", "")],default='VIEW_3D')
class ST_ExceptionItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty()
    is_exception: bpy.props.BoolProperty(default=False)
    
class TabGroupItem(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Group Name")
    items: bpy.props.StringProperty(name="Items (comma-separated)")
    icon: bpy.props.EnumProperty(name="Icon", items=_subgroup_icon_options, default='NONE')
    is_expanded: bpy.props.BoolProperty(name="Expanded", default=False)
    is_expanded_shading: bpy.props.BoolProperty(name="Expanded Shading", default=False)
    is_expanded_geometry: bpy.props.BoolProperty(name="Expanded Geometry", default=False)
    is_expanded_compositor: bpy.props.BoolProperty(name="Expanded Compositor", default=False)
    is_expanded_texture: bpy.props.BoolProperty(name="Expanded Texture", default=False)
    is_expanded_in_prefs: bpy.props.BoolProperty(name="Expanded in Preferences", default=True)
    is_visible: bpy.props.BoolProperty(name="Visible", description="Toggle the visibility of this group in the N-Panel", default=True)
    show_favorites_panel: bpy.props.BoolProperty(name="Show Favorites Panel", default=False)
    show_groupaddons_panel: bpy.props.BoolProperty(name="Show Groups & Addons Panel", default=True)
    show_windoweditor_panel: bpy.props.BoolProperty(name="Show Window Editor Panel", default=True)
    panel_manager: bpy.props.BoolProperty(name="Show Panel Manager Favorite Tabs Preset & Groups/Add-ons Panels Section", default=True)
    space_type: bpy.props.EnumProperty(name="Space Type",items=[('VIEW_3D', "3D View", ""),('IMAGE_EDITOR', "UV / Image Editor", ""),('NODE_EDITOR', "Geometry Nodes", "")],default='VIEW_3D')
    is_exception: bpy.props.BoolProperty(name="Is Exception",description="Exclude this group from Collapse All action",default=False)

class AddonPreset(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty(name="Preset Name")
    addons: bpy.props.CollectionProperty(type=AddonPresetItem)

class SubTabState(bpy.types.PropertyGroup):
    name: bpy.props.StringProperty() 
    active_item: bpy.props.StringProperty(name="Active Item")
    pinned_items: bpy.props.StringProperty(name="Pinned Items")
    favorite_presets: bpy.props.CollectionProperty(type=CustomFavoritePreset)
    active_favorite_preset_name: bpy.props.StringProperty(name="Active Favorite Preset", default="Preset 1")
    subgroup_columns: bpy.props.IntProperty(name="Sub-Group Columns", default=4, min=1, max=6)
    item_columns: bpy.props.IntProperty(name="Item Columns", default=4, min=1, max=6)
    subgroup_column_data: bpy.props.CollectionProperty(type=SubgroupColumnState)
    favorite_item_columns: bpy.props.IntProperty(name="Favorite Item Columns", description="Number of columns for the favorite items list", default=1, min=1, max=2)
    show_favorites_panel: bpy.props.BoolProperty(name="Show Favorites Panel", default=False, update=_sync_fav_to_prefs)
    show_groupaddons_panel: bpy.props.BoolProperty(name="Show Groups & Addons Panel", default=True, update=_sync_group_to_prefs)
    show_favorite_nodes_panel: bpy.props.BoolProperty(name="Show Favorite Node Panel", default=True, update=_sync_fav_node_to_prefs)
    show_windoweditor_panel: bpy.props.BoolProperty(name="Show Window Editor Panel", default=True, update=_sync_win_to_prefs)
    show_preset_settings: bpy.props.BoolProperty(name="Show Preset Settings", default=False, update=_sync_panel_manager_to_prefs)
    show_subgroup_icons: bpy.props.BoolProperty(name="Show Subgroup Icons", default=True)
    show_favorite_icons: bpy.props.BoolProperty(name="Show Favorite Icons", default=True)
    item_search_query: bpy.props.StringProperty(name="Search Items", default="", options={'TEXTEDIT_UPDATE'})
    panel_manager: bpy.props.BoolProperty(name="Show Panel Manager Favorite Tabs Preset & Groups/Add-ons Panels Section", default=True)

class ST_FavoriteNodeItem(bpy.types.PropertyGroup):
    node_idname: bpy.props.StringProperty(name="Node ID Name") 
    label: bpy.props.StringProperty(name="Label") 
    tree_type: bpy.props.StringProperty(name="Tree Type") 
    is_group: bpy.props.BoolProperty(name="Is Node Group", default=False)
    serialized_data: bpy.props.StringProperty(name="Serialized Data", default="")
    icon: bpy.props.EnumProperty(
        name="Icon", 
        items=_restricted_icon_enum_items, 
        default='NODE_SOCKET_FLOAT'
    )