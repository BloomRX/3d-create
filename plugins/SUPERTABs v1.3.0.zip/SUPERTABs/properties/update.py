import bpy
from ..utils import (
    check_keymap_conflict, 
    trigger_redraw, 
    RESERVED_TAB_NAMES, 
)
from ..keymap import update_keymap_callback
from .. import rightclick

# ===================================================================
#  HELPER FUNCTIONS (Getters, Setters, Updates for Prefs)
# ===================================================================
def get_edit_item_name(self):
    """
    Gets the display name for the currently selected item.
    """
    if self.active_reorder_selection_type != 'ITEM':
        return ""
    
    item_id = self.active_reorder_selection_id
    if not item_id:
        return ""

    for item in self.custom_item_names:
        if item.identifier == item_id:
            return item.display_name

    try:
        item_type, item_name = item_id.split(":", 1)
        if item_type == 'addon':
            for lookup in self.addon_display_lookup:
                if lookup.name == item_name:
                    return lookup.display_name
        return item_name
    except ValueError:
        return item_id
    
def set_edit_item_name(self, value):
    """
    Sets the display name for the currently selected item.
    """
    if self.active_reorder_selection_type != 'ITEM':
        return
    
    item_id = self.active_reorder_selection_id
    if not item_id:
        return
        
    new_display_name = value.strip()

    for item in self.custom_item_names:
        if item.identifier == item_id:
            if new_display_name:
                item.display_name = new_display_name
            else:
                item_key = item.identifier
                items_collection = self.custom_item_names
                item_index = -1
                for i, it in enumerate(items_collection):
                    if it.identifier == item_key:
                        item_index = i
                        break
                if item_index != -1:
                    items_collection.remove(item_index)
            
            trigger_redraw(self, bpy.context)
            bpy.ops.tab_group.apply_settings('INVOKE_DEFAULT')
            return

    if new_display_name:
        new_item = self.custom_item_names.add()
        new_item.identifier = item_id
        new_item.display_name = new_display_name
        
    trigger_redraw(self, bpy.context)
    bpy.ops.tab_group.apply_settings('INVOKE_DEFAULT')
        
def get_edit_name(self):
    if 0 <= self.active_group_index < len(self.tab_groups):
        return self.tab_groups[self.active_group_index].name.split(" / ", 1)[-1].strip()
    return ""

def set_edit_name(self, value):
    if not (0 <= self.active_group_index < len(self.tab_groups)):
        return

    active_group = self.tab_groups[self.active_group_index]
    new_name_part = value.strip()
    if not new_name_part: 
        return

    old_full_name = active_group.name
    old_name_part = old_full_name.split(" / ", 1)[-1].strip()
    if old_name_part == new_name_part:
        return
    
    parts = old_full_name.split(" / ", 1)
    wm = bpy.context.window_manager

    new_full_name = ""
    is_main_group = len(parts) == 1
    
    if is_main_group:
        new_full_name = new_name_part
        if new_full_name in RESERVED_TAB_NAMES:
            return
    else:
        main_name = parts[0].strip()
        new_full_name = f"{main_name} / {new_name_part}"

    all_other_names = {
        g.name for i, g in enumerate(self.tab_groups) 
        if i != self.active_group_index
    }

    if new_full_name in all_other_names:
        return
    if not is_main_group:
        main_name = parts[0].strip()
        old_sub_name = parts[1].strip()

        if old_sub_name != new_name_part:
            active_group.name = new_full_name

            if hasattr(wm, "tab_group_states"):
                group_state = wm.tab_group_states.get(main_name)
                if group_state:
                    column_data = group_state.subgroup_column_data.get(old_sub_name)
                    if column_data:
                        column_data.name = new_name_part
    else:
        old_main_name = parts[0].strip()
        if old_main_name != new_name_part:
            active_group.name = new_full_name

            for group in self.tab_groups:
                if group.name.startswith(old_main_name + " / "):
                    sub_part = group.name.split(" / ", 1)[1]
                    group.name = f"{new_name_part} / {sub_part}"

            if hasattr(wm, "tab_group_states"):
                state_to_rename = wm.tab_group_states.get(old_main_name)
                if state_to_rename:
                    state_to_rename.name = new_name_part

            for preset in self.custom_favorite_presets:
                if preset.main_group_name == old_main_name:
                    preset.main_group_name = new_name_part
                    
            for qs in self.quick_shortcuts:
                if qs.main_group_name == old_main_name:
                    qs.main_group_name = new_name_part

    bpy.ops.tab_group.apply_settings()
    bpy.ops.tab_group.refresh_available('INVOKE_DEFAULT')

def update_node_header_visibility(self, context):
    def _deferred_check():
        # 1. Geometry Nodes
        if not self.st_node_quick_geometry and not self.st_node_show_fav_nodes_geometry and not self.st_node_zoom_geometry:
            if self.st_node_header_geometry:
                self.st_node_header_geometry = False
        
        # 2. Shader Nodes
        if not self.st_node_quick_shading and not self.st_node_show_fav_nodes_shading and not self.st_node_zoom_shading:
            if self.st_node_header_shading:
                self.st_node_header_shading = False

        # 3. Compositor
        if not self.st_node_quick_compositor and not self.st_node_show_fav_nodes_compositor and not self.st_node_zoom_compositor:
            if self.st_node_header_compositor:
                self.st_node_header_compositor = False

        # 4. Texture Nodes
        if not self.st_node_quick_texture and not self.st_node_show_fav_nodes_texture and not self.st_node_zoom_texture:
            if self.st_node_header_texture:
                self.st_node_header_texture = False
                
        return None
    
    bpy.app.timers.register(_deferred_check)

def update_node_header_master(self, context):
    if self.st_node_header_geometry:
        if not self.st_node_quick_geometry and not self.st_node_show_fav_nodes_geometry and not self.st_node_zoom_geometry:
            self.st_node_quick_geometry = True
            self.st_node_show_fav_nodes_geometry = True
            self.st_node_zoom_geometry = True

    # 2. Shader Nodes
    if self.st_node_header_shading:
        if not self.st_node_quick_shading and not self.st_node_show_fav_nodes_shading and not self.st_node_zoom_shading:
            self.st_node_quick_shading = True
            self.st_node_show_fav_nodes_shading = True
            self.st_node_zoom_shading = True

    # 3. Compositor
    if self.st_node_header_compositor:
        if not self.st_node_quick_compositor and not self.st_node_show_fav_nodes_compositor and not self.st_node_zoom_compositor:
            self.st_node_quick_compositor = True
            self.st_node_show_fav_nodes_compositor = True
            self.st_node_zoom_compositor = True

    # 4. Texture Nodes
    if self.st_node_header_texture:
        if not self.st_node_quick_texture and not self.st_node_show_fav_nodes_texture and not self.st_node_zoom_texture:
            self.st_node_quick_texture = True
            self.st_node_show_fav_nodes_texture = True
            self.st_node_zoom_texture = True

def update_image_header_master(self, context):
    if self.show_header_image:
        if not self.show_quick_uv and not self.show_basic_uv_buttons:
            self.show_quick_uv = True
            self.show_basic_uv_buttons = True
            
def update_image_header_visibility(self, context):
    def _deferred_check():
        if not self.show_quick_uv and not self.show_basic_uv_buttons:
            if self.show_header_image:
                self.show_header_image = False
        return None
    bpy.app.timers.register(_deferred_check)

def update_3d_header_master(self, context):
    if self.show_header_3d:
        if not self.show_quick_3d and not self.show_editor_shortcuts_panel and not self.show_basic_panel:
            self.show_quick_3d = True
            self.show_editor_shortcuts_panel = True
            self.show_basic_panel = True

def update_3d_header_visibility(self, context):
    def _deferred_check():
        if not self.show_quick_3d and not self.show_editor_shortcuts_panel and not self.show_basic_panel:
            if self.show_header_3d:
                self.show_header_3d = False
        return None
    
    bpy.app.timers.register(_deferred_check)

# 2. Poll Exceptions
def update_show_poll_exceptions(self, context):
    """
    When the user hides the poll exceptions, automatically lock them.
    """
    if not self.show_poll_exceptions:
        self.lock_poll_exceptions = True

DEFAULT_POLL_EXCEPTIONS = {"blenderkit", "powersave", "boxcutter"}

def update_poll_exceptions(self, context):
    """
    This function runs whenever 'poll_method_exceptions' is modified
    to prevent the user from removing the default values.
    """
    user_addons = {s.strip() for s in self.poll_method_exceptions.split(',') if s.strip()}
    missing_defaults = DEFAULT_POLL_EXCEPTIONS - user_addons
    if missing_defaults:
        final_addons = user_addons.union(DEFAULT_POLL_EXCEPTIONS)
        self.poll_method_exceptions = ", ".join(sorted(list(final_addons)))

# 3. General Updates
def update_show_name(self, context):
    addon_name = __package__.split('.')[0]
    prefs = context.preferences.addons[addon_name].preferences
    for obj in bpy.data.objects:
        obj.show_name = prefs.show_object_names_all

def update_management_tab_selection(self, context):
    """
    This function runs when switching modes between the 3D View and the UV/Image Editor.
    It automatically selects the first group it finds.
    """
    target_space = self.active_management_tab
    
    self.active_group_index = -1
    self.active_reorder_selection_type = 'NONE'
    self.active_reorder_selection_id = ""
    
    found_main_index = -1
    found_main_name = ""
    
    for i, group in enumerate(self.tab_groups):
        if "/" not in group.name and group.space_type == target_space:
            found_main_index = i
            found_main_name = group.name
            break
            
    if found_main_index != -1:
        final_index = found_main_index
        final_name = found_main_name
        
        prefix = f"{found_main_name} / "
        for i, group in enumerate(self.tab_groups):
            if group.name.startswith(prefix):
                final_index = i
                final_name = group.name
                break
        
        self.active_group_index = final_index
        self.active_reorder_selection_type = 'GROUP'
        self.active_reorder_selection_id = final_name

def update_integration_callback(self, context):
    """
    Called when integration preferences change.
    Updates both the standard context menus and the keymaps.
    """
    rightclick.unregister_context_menus()
    rightclick.register_context_menus(self)
    update_keymap_callback(self, context)

def update_header_display(self, context):
    for window in context.window_manager.windows:
        for area in window.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

def update_and_check_keymaps(self, context):
    """Checks for conflicts and then updates the keymap."""
    if self.manager_hotkey_enabled:
        conflict_manager = check_keymap_conflict(
            context, self.hotkey_key, self.hotkey_ctrl, self.hotkey_alt, self.hotkey_shift
        )
        self.manager_hotkey_conflict = conflict_manager
    else:
        self.manager_hotkey_conflict = ""

    # Asset Browser Hotkey
    if self.asset_browser_hotkey_enabled:
        conflict_asset = check_keymap_conflict(
            context, self.asset_browser_hotkey_key, self.asset_browser_hotkey_ctrl, self.asset_browser_hotkey_alt, self.asset_browser_hotkey_shift
        )
        self.asset_browser_hotkey_conflict = conflict_asset
    else:
        self.asset_browser_hotkey_conflict = ""
        
    # Split/Join View Hotkey
    if self.split_join_hotkey_enabled:
        conflict_split_join = check_keymap_conflict(
            context, self.split_join_hotkey_key, self.split_join_hotkey_ctrl, self.split_join_hotkey_alt, self.split_join_hotkey_shift
        )
        self.split_join_hotkey_conflict = conflict_split_join
    else:
        self.split_join_hotkey_conflict = ""

    # Pie Menu Hotkey
    if self.pie_menu_hotkey_enabled and (self.right_click_mode == 'PIE' or self.right_click_mode == 'BOTH'):
        conflict_pie = check_keymap_conflict(
            context, self.pie_menu_hotkey_key, self.pie_menu_hotkey_ctrl, self.pie_menu_hotkey_alt, self.pie_menu_hotkey_shift
        )
        self.pie_menu_hotkey_conflict = conflict_pie
    else:
        self.pie_menu_hotkey_conflict = ""

    update_keymap_callback(self, context)

def update_favorite_expand_toggle(self, context):
    """
    When the main 'Expand Button' for favorites is closed,
    also close the 'show remove' toggle and the 'show settings' panel.
    """
    if not self.show_favorite_set_button:
        self.show_remove_fav_button = False

        if hasattr(context.window_manager, "tab_group_states"):
            for group_state in context.window_manager.tab_group_states:
                group_state.show_preset_settings = False

    trigger_redraw(self, context)

# 1. Header Updates (Master & Visibility)
# --- 3D View ---
def update_manager_3d_master(self, context):
    target_state = self.show_manager_header_3d
    if self.show_fav_panel_3d != target_state:
        self.show_fav_panel_3d = target_state
    if self.show_groups_panel_3d != target_state:
        self.show_groups_panel_3d = target_state
    if self.show_collapse_all_3d != target_state:
        self.show_collapse_all_3d = target_state
def update_manager_3d_child(self, context):
    def _deferred_check():
        if self.show_fav_panel_3d or self.show_groups_panel_3d or self.show_collapse_all_3d:
            if self.show_manager_header_3d != True:
                self.show_manager_header_3d = True
        elif not self.show_fav_panel_3d and not self.show_groups_panel_3d and not self.show_collapse_all_3d:
            if self.show_manager_header_3d != False:
                self.show_manager_header_3d = False
        return None
    
    bpy.app.timers.register(_deferred_check)

# --- Image Editor ---
def update_manager_image_master(self, context):
    target_state = self.show_manager_header_image
    if self.show_fav_panel_image != target_state:
        self.show_fav_panel_image = target_state
    if self.show_groups_panel_image != target_state:
        self.show_groups_panel_image = target_state
    if self.show_collapse_all_image != target_state:
        self.show_collapse_all_image = target_state

def update_manager_image_child(self, context):
    def _deferred_check():
        if self.show_fav_panel_image or self.show_groups_panel_image or self.show_collapse_all_image:
            if self.show_manager_header_image != True:
                self.show_manager_header_image = True
        elif not self.show_fav_panel_image and not self.show_groups_panel_image and not self.show_collapse_all_image:
            if self.show_manager_header_image != False:
                self.show_manager_header_image = False
        return None
    bpy.app.timers.register(_deferred_check)

# (Shading)
def update_shading_master(self, context):
    target_state = self.show_manager_header_shading
    if self.show_fav_panel_shading != target_state:
        self.show_fav_panel_shading = target_state
    if self.show_groups_panel_shading != target_state:
        self.show_groups_panel_shading = target_state
    if self.show_collapse_all_shading != target_state:
        self.show_collapse_all_shading = target_state

def update_shading_child(self, context):
    def _deferred_check():
        if self.show_fav_panel_shading or self.show_groups_panel_shading or self.show_collapse_all_shading:
            if self.show_manager_header_shading != True:
                self.show_manager_header_shading = True
        elif not self.show_fav_panel_shading and not self.show_groups_panel_shading and not self.show_collapse_all_shading:
            if self.show_manager_header_shading != False:
                self.show_manager_header_shading = False
        return None
    bpy.app.timers.register(_deferred_check)

# (Geometry)
def update_geometry_master(self, context):
    target_state = self.show_manager_header_geometry
    if self.show_fav_panel_geometry != target_state:
        self.show_fav_panel_geometry = target_state
    if self.show_groups_panel_geometry != target_state:
        self.show_groups_panel_geometry = target_state
    if self.show_collapse_all_shading != target_state:
        self.show_collapse_all_shading = target_state

def update_geometry_child(self, context):
    def _deferred_check():
        if self.show_fav_panel_geometry or self.show_groups_panel_geometry or self.show_collapse_all_shading:
            if self.show_manager_header_geometry != True:
                self.show_manager_header_geometry = True
        elif not self.show_fav_panel_geometry and not self.show_groups_panel_geometry and not self.show_collapse_all_shading:
            if self.show_manager_header_geometry != False:
                self.show_manager_header_geometry = False
    bpy.app.timers.register(_deferred_check)

# (Compositor)
def update_compositor_master(self, context):
    target_state = self.show_manager_header_compositor
    if self.show_fav_panel_compositor != target_state:
        self.show_fav_panel_compositor = target_state
    if self.show_groups_panel_compositor != target_state:
        self.show_groups_panel_compositor = target_state
    if self.show_collapse_all_shading != target_state:
        self.show_collapse_all_shading = target_state

def update_compositor_child(self, context):
    def _deferred_check():
        if self.show_fav_panel_compositor or self.show_groups_panel_compositor or self.show_collapse_all_shading:
            if self.show_manager_header_compositor != True:
                self.show_manager_header_compositor = True
        elif not self.show_fav_panel_compositor and not self.show_groups_panel_compositor and not self.show_collapse_all_compositor:
            if self.show_manager_header_compositor != False:
                self.show_manager_header_compositor = False
    bpy.app.timers.register(_deferred_check)

# (Texture)
def update_texture_master(self, context):
    target_state = self.show_manager_header_texture
    if self.show_fav_panel_texture != target_state:
        self.show_fav_panel_texture = target_state
    if self.show_groups_panel_texture != target_state:
        self.show_groups_panel_texture = target_state
    if self.show_collapse_all_shading != target_state:
        self.show_collapse_all_shading = target_state

def update_texture_child(self, context):
    def _deferred_check():
        if self.show_fav_panel_texture or self.show_groups_panel_texture or self.show_collapse_all_shading:
            if self.show_manager_header_texture != True:
                self.show_manager_header_texture = True
        elif not self.show_fav_panel_texture and not self.show_groups_panel_texture and not self.show_collapse_all_shading:
            if self.show_manager_header_texture != False:
                self.show_manager_header_texture = False
    bpy.app.timers.register(_deferred_check)

def update_image_header_master_only(self, context):
    if self.show_header_image_only:
        if not self.show_quick_image and not self.show_basic_image_buttons:
            self.show_quick_image = True
            self.show_basic_image_buttons = True

def update_image_header_visibility_only(self, context):
    def _deferred_check():
        if not self.show_quick_image and not self.show_basic_image_buttons:
            if self.show_header_image_only:
                self.show_header_image_only = False
        return None
    bpy.app.timers.register(_deferred_check)

def update_manager_image_master_only(self, context):
    target_state = self.show_manager_header_image_only
    if self.show_fav_panel_image_only != target_state:
        self.show_fav_panel_image_only = target_state
    if self.show_groups_panel_image_only != target_state:
        self.show_groups_panel_image_only = target_state
    if self.show_collapse_all_image_only != target_state:
        self.show_collapse_all_image_only = target_state

def update_manager_image_child_only(self, context):
    def _deferred_check():
        if self.show_fav_panel_image_only or self.show_groups_panel_image_only or self.show_collapse_all_image_only:
            if self.show_manager_header_image_only != True:
                self.show_manager_header_image_only = True
        elif not self.show_fav_panel_image_only and not self.show_groups_panel_image_only and not self.show_collapse_all_image_only:
            if self.show_manager_header_image_only != False:
                self.show_manager_header_image_only = False
        return None
    bpy.app.timers.register(_deferred_check)

def update_section_view_logic(self, context):
    if self.prefs_section_view == 'QUICK':
        self.status_icon_quick = True
    else:
        self.status_icon_quick = False
        
    if self.prefs_section_view == 'PRESET':
        self.status_icon_fav_panel = True
    else:
        self.status_icon_fav_panel = False

def update_image_selector(self, context):
    """
    Update function for Image Selector.
    """
    trigger_redraw(self, context)
    update_image_header_visibility(self, context)
    update_image_header_visibility_only(self, context)

def update_image_header_visibility(self, context):
    def _deferred_check():
        if not self.show_quick_uv and not self.show_basic_uv_buttons and not self.show_image_selector:
            if self.show_header_image:
                self.show_header_image = False
        return None
    bpy.app.timers.register(_deferred_check)

def update_image_header_visibility_only(self, context):
    def _deferred_check():
        if not self.show_quick_image and not self.show_basic_image_buttons and not self.show_image_selector:
            if self.show_header_image_only:
                self.show_header_image_only = False
        return None
    bpy.app.timers.register(_deferred_check)

def update_image_header_master(self, context):
    if self.show_header_image:
        if not self.show_quick_uv and not self.show_basic_uv_buttons and not self.show_image_selector:
            self.show_quick_uv = True
            self.show_basic_uv_buttons = True

def update_image_header_master_only(self, context):
    if self.show_header_image_only:
        if not self.show_quick_image and not self.show_basic_image_buttons and not self.show_image_selector:
            self.show_quick_image = True
            self.show_basic_image_buttons = True


def update_tab_and_refresh(self, context):
    update_management_tab_selection(self, context)
    
    try:
        bpy.ops.tab_group.refresh_available()
    except Exception as e:
        print(f"Auto-refresh failed: {e}")