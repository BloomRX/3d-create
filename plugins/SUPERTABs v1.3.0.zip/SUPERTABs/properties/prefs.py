import bpy
from bpy.props import (StringProperty, BoolProperty, IntProperty, 
                       CollectionProperty, EnumProperty, FloatProperty, 
                       PointerProperty)

from ..core import auto_apply_ui_update, refresh_available_list_callback
from ..utils import check_keymap_conflict, trigger_redraw, RESERVED_TAB_NAMES
from .update import (
    update_3d_header_master, update_compositor_child,
    update_compositor_master, update_favorite_expand_toggle,
    update_geometry_child, update_geometry_master,
    update_image_header_master, update_image_header_visibility,
    update_manager_image_master, update_manager_image_child,
    update_image_header_master_only, update_image_header_visibility_only,
    update_manager_image_master_only, update_manager_image_child_only,
    update_manager_3d_child, update_manager_3d_master,
    update_manager_image_child, update_manager_image_master,
    update_node_header_master, update_node_header_visibility,
    update_management_tab_selection, get_edit_name, set_edit_name,
    get_edit_item_name, set_edit_item_name,
    update_shading_child, update_shading_master,
    update_show_name, update_and_check_keymaps,
    update_integration_callback, update_header_display, 
    update_3d_header_visibility, update_texture_child,
    update_texture_master, update_show_poll_exceptions, update_poll_exceptions,
    update_section_view_logic,update_image_selector,update_tab_and_refresh,
)
 
from .items import (
    TabGroupItem, ST_QuickShortcutItem, CustomItemName, 
    HiddenPanelItem, AvailableItem, FavoriteAddonItem,
    AddonPresetItem, CustomFavoritePreset, SubgroupColumnState,
    AddonPreset, SubTabState, ST_FavoriteNodeItem, _restricted_icon_enum_items, _subgroup_icon_options, ST_ExceptionItem
)

# ===================================================================
#  CONSTANTS & ENUMS
# ===================================================================

key_items_list = \
    [(k, k, "") for k in ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']] + \
    [(f'F{i}', f'F{i}', '') for i in range(1, 13)] + \
    [('LEFTMOUSE', 'Left Mouse', ''), ('MIDDLEMOUSE', 'Middle Mouse', ''), ('RIGHTMOUSE', 'Right Mouse', '')]


# --- Main Preferences Class ---
class ST_AddonPreferences(bpy.types.AddonPreferences):
    bl_idname = "SUPERTABs"
    # bl_idname = __package__

    toggle_width_slider: bpy.props.BoolProperty(name=" Toggle Popover Width Slider", default=False)
    add_items_popover_width: bpy.props.IntProperty(name="Add Items Popover Width",description="Width of the Add Items to Preset popover window in pixels.",
        default=1000,
        min=800, 
        max=1400,
    )
    
    active_management_tab: bpy.props.EnumProperty(
        name="Management Context",
        items=[
            ('VIEW_3D', "3D View", "Manage groups for 3D Viewport", 'VIEW3D', 0),
            ('IMAGE_EDITOR', "UV / Image Editor", "Manage groups for UV/Image Editor", 'IMAGE', 1),
            ('NODE_EDITOR', "Node Editors", "Manage groups ina any Node Editors", 'NODE', 2),
        ],
        default='VIEW_3D',
        update=update_tab_and_refresh,
    )

    show_subgroup_custom_icons: bpy.props.BoolProperty(name="Show Subgroup Icons", description="Show custom icons on Subgroup headers",default=True,update=trigger_redraw)
    show_subgroup_item_icons: bpy.props.BoolProperty(name="Show Item Icons (Inherit)", description="Show Subgroup icons on items inside",default=False,update=trigger_redraw)
    show_subgroup_icon_menu: bpy.props.BoolProperty(name="Show Icon Menu Button", description="Show the icon selector button in Preferences",default=False)
    clear_icon_toggle: bpy.props.BoolProperty(name="Clear Icon Toggle", description="Show Clear Icon buttons", default=True)
    # --- Draw Method ---
    def draw(self, context):
        from ..ui.preferences import draw_preferences_layout
        draw_preferences_layout(self, context)

    # --- Tab Groups & Management ---
    tab_groups: bpy.props.CollectionProperty(type=TabGroupItem)
    active_group_index: bpy.props.IntProperty(default=-1)
    edit_group_name: bpy.props.StringProperty(name="Edit Name", get=get_edit_name, set=set_edit_name)
    edit_item_name: bpy.props.StringProperty(name="Item Display Name", get=get_edit_item_name, set=set_edit_item_name)
    active_reorder_selection_type: bpy.props.EnumProperty(items=[('NONE', "None", ""), ('GROUP', "Group", ""), ('ITEM', "Item", "")], name="Active Selection Type", default='NONE')
    active_reorder_selection_id: bpy.props.StringProperty(name="Active Selection ID")
    custom_item_names: bpy.props.CollectionProperty(type=CustomItemName)
    hidden_panels: bpy.props.CollectionProperty(type=HiddenPanelItem)

    # --- Available Items & Lookups ---
    available_tabs: bpy.props.CollectionProperty(type=AvailableItem)
    active_available_tab_index: bpy.props.IntProperty()
    available_addons: bpy.props.CollectionProperty(type=AvailableItem)
    active_available_addon_index: bpy.props.IntProperty()
    addon_display_lookup: bpy.props.CollectionProperty(type=AvailableItem)

    # --- Addon Presets ---
    addon_presets: bpy.props.CollectionProperty(type=AddonPreset)
    active_preset_index: bpy.props.IntProperty(name="Active Preset Index", default=-1)

    # --- Favorite Addons & Presets ---
    favorite_addons: bpy.props.CollectionProperty(type=FavoriteAddonItem)
    custom_favorite_presets: bpy.props.CollectionProperty(type=CustomFavoritePreset)

    # --- Manager UI & Filters ---
    addon_search_query: bpy.props.StringProperty(name="Search", description="Filter addons by name", default="", update=trigger_redraw, options={'TEXTEDIT_UPDATE'})
    addon_filter_status: bpy.props.EnumProperty(name="Filter Status", items=[('ALL', 'All', ''), ('ENABLED', 'Enabled', ''), ('DISABLED', 'Disabled', '')], default='ALL', update=trigger_redraw)
    addon_origin_filter: bpy.props.EnumProperty(name="Filter Origin", items=[('ALL', 'All', ''), ('USER', 'User', ''), ('BLENDER_BUILTIN', 'Built-in', '')], default='ALL', update=trigger_redraw)
    addon_filter_favorite: bpy.props.BoolProperty(name="Show Only Favorites", default=False, update=trigger_redraw)
    tab_search_query: bpy.props.StringProperty(name="Search", description="Filter available tabs by name", default="", update=trigger_redraw, options={'TEXTEDIT_UPDATE'})
    prefs_group_search_query: bpy.props.StringProperty(name="Search Groups & Items", description="Filter the group list by name or contained items", default="", update=trigger_redraw, options={'TEXTEDIT_UPDATE'})
    
    # --- Import / Export ---
    last_used_path: bpy.props.StringProperty(name="Last Used Path", subtype='DIR_PATH', default="")
    auto_import_enabled: bpy.props.BoolProperty(name="Enable", default=False)
    auto_import_filepath: bpy.props.StringProperty(name="File Path", subtype='FILE_PATH')
    auto_import_delay: bpy.props.FloatProperty(name="Startup Delay", default=3.0, min=2.0, soft_max=5.0, unit='TIME', precision=1)
    auto_apply_after_import: bpy.props.BoolProperty(name="Automatic Create Supertabs After Import", default=True)
    export_favorite_presets: bpy.props.BoolProperty(name="Favorite Presets", default=True)
    export_addon_presets: bpy.props.BoolProperty(name="Addon Presets", default=True)
    export_favorite_addons: bpy.props.BoolProperty(name="Favorite Add-ons", default=True)
    export_auto_import: bpy.props.BoolProperty(name="Auto Import Settings", default=True)
    export_expansion_states: bpy.props.BoolProperty(name="Expansion States", default=True)
    export_visibility_settings: bpy.props.BoolProperty(name="Visibility & Ejection States", default=True)
    export_custom_names: bpy.props.BoolProperty(name="Custom Item Names", default=True)
    export_tab_groups: bpy.props.BoolProperty(name="Tab Groups & Core Settings", default=True)
    export_ui_layout: bpy.props.BoolProperty(name="UI Layout", default=True)
    export_hotkey: bpy.props.BoolProperty(name="Hotkey Settings", default=True)
    
    poll_method_exceptions: bpy.props.StringProperty(name="Poll Method Exceptions",
        description="List of add-ons (separated by commas) that will use a special poll method (to fix issues with BlenderKit and BoxCutter).",
        default="blenderkit, powersave, tool, boxcutter",
        update=update_poll_exceptions
    )
    
    # --- Hotkey Settings ---
    right_click_mode: bpy.props.EnumProperty(
        name="Right-Click Behavior",
        items=[
            ('MENU', "Right-Click Menu", "Integrate with Blender's default right-click context menu."),
            ('PIE', "Pie Menu Hotkey", "Use a dedicated hotkey to open a SUPERTABs pie menu."),
            ('BOTH', "Both", "Enable both the right-click menu and the pie menu hotkey."), 
            ('NONE', "Disabled", "Disable all right-click integration.") 
        ],
        description="Choose how to access quick tools",
        default='MENU',
        update=update_integration_callback
    )
    right_click_menu_position: bpy.props.EnumProperty(name="Position",items=[
        ('TOP', "Top", "Add menu to the top"),
        ('BOTTOM', "Bottom", "Add menu to the bottom")
    ],
        default='TOP',
        update=update_integration_callback
    )

    keymap_registration_delay: bpy.props.FloatProperty(name="Keymap Delay", default=0.5, min=0.1, max=5.0, unit='TIME', precision=2)
    panel_switch_delay: bpy.props.FloatProperty(
        name="Panel Switch Delay",
        description="Delay in seconds before switching panels via hotkey. Increase if panel doesn't switch on first click.",
        default=0.5, min=0.1, max=1, unit='TIME', precision=2
    )

    # SUPERTABS Settings 
    show_st_setting: bpy.props.BoolProperty(name="Show SUPERTABs Settings", default=True)
    # Manager Hotkey
    manager_hotkey_enabled: bpy.props.BoolProperty(name="Enable Manager Hotkey", default=True, update=update_and_check_keymaps)
    hotkey_ctrl: bpy.props.BoolProperty(name="Ctrl", default=False, update=update_and_check_keymaps)
    hotkey_alt: bpy.props.BoolProperty(name="Alt", default=False, update=update_and_check_keymaps)
    hotkey_shift: bpy.props.BoolProperty(name="Shift", default=False, update=update_and_check_keymaps)
    hotkey_key: bpy.props.EnumProperty(name="Key", items=key_items_list, default='F5', update=update_and_check_keymaps)
    manager_hotkey_conflict: bpy.props.StringProperty(name="Manager Hotkey Conflict")

    # Asset Browser Hotkey
    asset_browser_hotkey_enabled: bpy.props.BoolProperty(name="Enable Asset Browser Hotkey", default=True, update=update_and_check_keymaps)
    asset_browser_hotkey_ctrl: bpy.props.BoolProperty(name="Ctrl", default=False, update=update_and_check_keymaps)
    asset_browser_hotkey_alt: bpy.props.BoolProperty(name="Alt", default=False, update=update_and_check_keymaps)
    asset_browser_hotkey_shift: bpy.props.BoolProperty(name="Shift", default=False, update=update_and_check_keymaps)
    asset_browser_hotkey_key: bpy.props.EnumProperty(name="Key", items=key_items_list, default='F6', update=update_and_check_keymaps)
    asset_browser_hotkey_conflict: bpy.props.StringProperty(name="Asset Browser Hotkey Conflict")
    
    # Split/Join Hotkey
    split_join_hotkey_enabled: bpy.props.BoolProperty(name="Enable Split/Join View Hotkey", default=True, update=update_and_check_keymaps)
    split_join_hotkey_ctrl: bpy.props.BoolProperty(name="Ctrl", default=False, update=update_and_check_keymaps)
    split_join_hotkey_alt: bpy.props.BoolProperty(name="Alt", default=False, update=update_and_check_keymaps)
    split_join_hotkey_shift: bpy.props.BoolProperty(name="Shift", default=False, update=update_and_check_keymaps)
    split_join_hotkey_key: bpy.props.EnumProperty(name="Key", items=key_items_list, default='F7', update=update_and_check_keymaps)
    split_join_hotkey_conflict: bpy.props.StringProperty(name="Split/Join View Hotkey Conflict")
    
    # --- Pie Menu Hotkey ---
    pie_menu_hotkey_enabled: bpy.props.BoolProperty(name="Enable Pie Menu Hotkey", default=True, update=update_and_check_keymaps)
    pie_menu_hotkey_ctrl: bpy.props.BoolProperty(name="Ctrl", default=False, update=update_and_check_keymaps)
    pie_menu_hotkey_alt: bpy.props.BoolProperty(name="Alt", default=False, update=update_and_check_keymaps)
    pie_menu_hotkey_shift: bpy.props.BoolProperty(name="Shift", default=False, update=update_and_check_keymaps)
    pie_menu_hotkey_key: bpy.props.EnumProperty(name="Key", items=key_items_list, default='F8', update=update_and_check_keymaps)
    pie_menu_hotkey_conflict: bpy.props.StringProperty(name="Pie Menu Hotkey Conflict")
    
    # --- Favorite Window Editors for Quick Menu ---
    enable_window_editors_rcm: bpy.props.BoolProperty(name="Show in Right-Click Menu",description="Show 'Window Editors' in the Right-Click Menu",default=True,update=update_integration_callback)
    enable_window_editors_pie: bpy.props.BoolProperty(name="Show in Pie Menu",description="Show 'Window Editors' in the Pie Menu",default=True,update=update_integration_callback )
    
    # --- General ---
    rcm_show_window_editors: bpy.props.BoolProperty(name="Show Favorite Window Editors", description="Show selected Window Editors in the Right-Click / Pie Menu",default=True, update=update_integration_callback)
    rcm_show_3Dview: bpy.props.BoolProperty(name="3D Viewport", default=True, update=update_integration_callback)
    rcm_show_image: bpy.props.BoolProperty(name="Image Editor", default=True, update=update_integration_callback)
    rcm_show_uv: bpy.props.BoolProperty(name="UV Editor", default=False, update=update_integration_callback)
    rcm_show_geo: bpy.props.BoolProperty(name="Geometry Node", default=False, update=update_integration_callback)
    rcm_show_comp: bpy.props.BoolProperty(name="Compositor", default=False, update=update_integration_callback)
    rcm_show_shader: bpy.props.BoolProperty(name="Shader Editor", default=False, update=update_integration_callback)
    rcm_show_texture: bpy.props.BoolProperty(name="Texture Node Editor", default=False, update=update_integration_callback)
    rcm_show_sequence: bpy.props.BoolProperty(name="Viedeo Sequencer", default=False, update=update_integration_callback)
    rcm_show_clip: bpy.props.BoolProperty(name="Movie Clip Editor", default=False, update=update_integration_callback)
    
    # --- Scripting ---
    rcm_show_system_console: bpy.props.BoolProperty(name="System Console", default=False, update=update_integration_callback)
    rcm_show_text: bpy.props.BoolProperty(name="Text Editor", default=True, update=update_integration_callback)
    rcm_show_console: bpy.props.BoolProperty(name="Python Console", default=False, update=update_integration_callback)
    rcm_show_info: bpy.props.BoolProperty(name="Info", default=False, update=update_integration_callback)
    rcm_show_iconviewer: bpy.props.BoolProperty(name="Icon Viewer", default=False, update=update_integration_callback)
    rcm_show_serpen: bpy.props.BoolProperty(name="Visual Scripting", default=False, update=update_integration_callback)
    
    # --- Animation ---
    rcm_show_dopesheet: bpy.props.BoolProperty(name="Dope Sheet", default=True, update=update_integration_callback)
    rcm_show_timeline: bpy.props.BoolProperty(name="Timeline", default=False, update=update_integration_callback)
    rcm_show_graph: bpy.props.BoolProperty(name="Graph Editor", default=False, update=update_integration_callback)
    rcm_show_drivers: bpy.props.BoolProperty(name="Drivers", default=False, update=update_integration_callback)
    rcm_show_nla: bpy.props.BoolProperty(name="Nonlinear Animation", default=False, update=update_integration_callback)
    
    # --- Data ---
    rcm_show_outliner: bpy.props.BoolProperty(name="OutLiner", default=True, update=update_integration_callback)
    rcm_show_props: bpy.props.BoolProperty(name="Properties", default=False, update=update_integration_callback)
    rcm_show_file: bpy.props.BoolProperty(name="File Browser", default=False, update=update_integration_callback)
    rcm_show_spread: bpy.props.BoolProperty(name="Spreadsheet", default=False, update=update_integration_callback)
    rcm_show_asset: bpy.props.BoolProperty(name="Asset Browser", default=False, update=update_integration_callback)
    rcm_show_preferences: bpy.props.BoolProperty(name="Preferences", default=False, update=update_integration_callback)
    
    # --- Quick Shortcuts (RCM/Pie Menu) ---
    quick_shortcuts: bpy.props.CollectionProperty(type=ST_QuickShortcutItem,name="Quick Shortcut Items")
    active_quick_shortcut_index: bpy.props.IntProperty(name="Active Quick Shortcut Index", default=-1)
    enable_quick_shortcuts_rcm: bpy.props.BoolProperty(
        name="Show in Right-Click Menu",
        description="Show 'Quick Shortcuts' in the Right-Click Menu",
        default=True,
        update=update_integration_callback
    )
    
    enable_quick_shortcuts_pie: bpy.props.BoolProperty(
        name="Show in Pie Menu",
        description="Show 'Quick Shortcuts' in the Pie Menu",
        default=True,
        update=update_integration_callback
    )
    
    # --- UI Layout & Display Toggles ---
    assign_dialog_column_count: bpy.props.IntProperty(name="Assign Dialog Columns",default=4,min=2,max=4)
    tab_list_display_rows: bpy.props.IntProperty(name="List Rows", default=7, min=3, max=15)
    favorite_addon_list_columns: bpy.props.IntProperty(name="Favorite Addon List Columns", default=1, min=1, max=8, update=trigger_redraw)
    addon_list_columns: bpy.props.IntProperty(name="Addon List Columns", default=4, min=1, max=8, update=trigger_redraw)
    favorite_column_split_factor: bpy.props.FloatProperty(name="Favorites/Addons Split", default=0.33, min=0.1, max=0.9, subtype='FACTOR', update=trigger_redraw)
    
    hotkey_popup_width: bpy.props.IntProperty(name="Hotkey Popup Width", default=100, min=50, max=150)
    pie_quick_shortcut_columns: bpy.props.IntProperty(name="Pie Menu Quick Shortcut Columns", default=2, min=1, max=2, update=trigger_redraw)
    pie_window_editor_columns: bpy.props.IntProperty(name="Pie Menu Window Editor Columns", default=2, min=1, max=2, update=trigger_redraw)
    pie_panel_preset_columns: bpy.props.IntProperty(name="Pie Menu Panel Preset Columns", default=2, min=1, max=2, update=trigger_redraw)
    show_asset_browser_button: bpy.props.BoolProperty(name="Asset Browser",description="Show Asset Browser Button on Viewport Topbar", default=False, update=trigger_redraw)
    show_eject_buttons: bpy.props.BoolProperty(name="Show Eject Buttons", default=False)
    show_hide_buttons: bpy.props.BoolProperty(name="Show Hide Buttons", default=False)
    show_favorite_buttons: bpy.props.BoolProperty(name="Show Favorite Buttons", default=False, update=trigger_redraw)
    show_quick_pin_buttons: bpy.props.BoolProperty(name="Show Pin Quick Buttons", default=False, update=trigger_redraw)
    show_options: bpy.props.BoolProperty(name="Show Options", default=True)

    prefs_section_view: bpy.props.EnumProperty(
        name="Preferences Section View",
        description="Toggle which management section to display in the preferences",
        items=[
            ('NONE', "Assign", "Show Add-on/Tab assignment list", 'ADD', 0),
            ('PANEL', "SubTabs Managment", "Manage individual Sub-tabs for the selected item", 'MENU_PANEL', 1),
            ('QUICK', "Quick Shortcuts", "Manage Quick Shortcuts", 'PINNED', 2),
            ('PRESET', "Tabs Preset", "Manage Favorite Tabs Presets", 'SOLO_ON', 3)
        ],
        default='NONE',
        update=update_section_view_logic
    )
    
    use_label_style_ui: bpy.props.BoolProperty(name="Use Label Style for Groups/Items", description="Use radio icons and labels (New) instead of full-name buttons (Old)", default=True, update=trigger_redraw)
    hide_options_subgroups: bpy.props.BoolProperty(name="Show/Hide Tab Groups Options Buttons",description="Show/Hide Tab Groups Options Buttons(In Groups & Addons)", default=True, update=update_header_display)
    hide_options_items: bpy.props.BoolProperty(name="Show/Hide Addons/Tabs Options Buttons",description="Show/Hide Addons/Tabs Options Buttons(In Groups & Addons)", default=True, update=update_header_display)
    show_editor_shortcuts_panel: bpy.props.BoolProperty(name="Toggle Window Editors",description="Show WindowEditor Section in SUPERTABs N-Panel", default=True, update=update_3d_header_visibility)
    show_windoweditor_panel: bpy.props.BoolProperty(name="Show WindowEditors Section Panel", default=True)
    show_annotations_3dview: bpy.props.BoolProperty(name="Show Annotations Panel(3DView)", default=False)
    show_annotations_image: bpy.props.BoolProperty(name="Show Annotations Panel(Image Editor)", default=False)
    show_annotations_uv: bpy.props.BoolProperty(name="Show Annotations Panel(UV Editor)", default=False)
    show_annotations_nodes: bpy.props.BoolProperty(name="Show Annotations Panel(Nodes Editor)", default=False)

    panel_manager: bpy.props.BoolProperty(name="Show Panel Manager Favorite Tabs Preset & Groups/Add-ons Panels Section", default=True)
    show_3Dview: bpy.props.BoolProperty(name="3D Viewport", default=True)
    show_image: bpy.props.BoolProperty(name="Image Editor", default=True)
    show_uv: bpy.props.BoolProperty(name="UVEditor", default=True)
    show_shader: bpy.props.BoolProperty(name="Shader Editor", default=True)
    show_geo: bpy.props.BoolProperty(name="Geometry Node Editor", default=False)
    show_comp: bpy.props.BoolProperty(name="Compositor Editor", default=False)
    show_texture: bpy.props.BoolProperty(name="Texture Node Editor", default=False)
    show_sequence: bpy.props.BoolProperty(name="Video Sequencer", default=False)
    show_clip: bpy.props.BoolProperty(name="Movie Clip Editor", default=False)
    
    show_external_data_panel: bpy.props.BoolProperty(name="Show External Data Panel(Image/UV Editor)", default=False)
    auto_pack_toggle: bpy.props.BoolProperty(name="Show/Hide Auto Pack Resources", default=False)
    toggle_pack_resources: bpy.props.BoolProperty(name="Show External Pack Resources", default=False)
    toggle_pack_linked: bpy.props.BoolProperty(name="Show External Pack Linked", default=False)
    toggle_make_path: bpy.props.BoolProperty(name="Show External Make Path", default=False)
    toggle_missing_files: bpy.props.BoolProperty(name="Show External Missing Files", default=False)

    show_dopesheet: bpy.props.BoolProperty(name="DopeSheet", default=True)
    show_timeline: bpy.props.BoolProperty(name="Timeline", default=True)
    show_graph: bpy.props.BoolProperty(name="Graph", default=True)
    show_drivers: bpy.props.BoolProperty(name="Drivers", default=True)
    show_nla: bpy.props.BoolProperty(name="NonLinear Animation", default=False)

    show_text: bpy.props.BoolProperty(name="Text Editor", default=True)
    show_console: bpy.props.BoolProperty(name="Python Console", default=True)
    show_info: bpy.props.BoolProperty(name="Info", default=True)
    show_iconviewer: bpy.props.BoolProperty(name="Icon Viewer", default=False)
    show_system_console: bpy.props.BoolProperty(name="System Console", default=True)
    show_serpen: bpy.props.BoolProperty(name="Serpen Editor", default=False)
    
    show_outliner: bpy.props.BoolProperty(name="Outliner", default=True)
    show_props: bpy.props.BoolProperty(name="Properties", default=True)
    show_file: bpy.props.BoolProperty(name="File Browser", default=True)
    show_spread: bpy.props.BoolProperty(name="SpreadSheet", default=True)
    show_preferences: bpy.props.BoolProperty(name="Preferences", default=False)

    show_general: bpy.props.BoolProperty(name="General Editor",description="Show General Editor Section", default=True)
    show_scripting: bpy.props.BoolProperty(name="Scripting Editor",description="Show Scripting Editor Section", default=True)
    show_animation: bpy.props.BoolProperty(name="Animation Editor",description="Show Animation Editor Section", default=True)
    show_data: bpy.props.BoolProperty(name="Data Editor",description="Show Data Editor Section", default=True)

    show_header_3d: bpy.props.BoolProperty(name="SUPERTABs N-Panel Header(3DView)",description="Main SUPERTABs N-Panel Header(3DView)", default=True, update=update_3d_header_master)
    show_header_image: bpy.props.BoolProperty(name="SUPERTABs N-Panel Header(Image/UV)",description="Main SUPERTABs N-Panel Header(Nodes)", default=True, update=update_image_header_master)
    show_header_nodes: bpy.props.BoolProperty(name="SUPERTABs N-Panel Header(Nodes)",description="Main SUPERTABs N-Panel Header(Nodes)", default=True, update=update_node_header_master)
    
    st_node_header_geometry: bpy.props.BoolProperty(name="Show Header (Geometry)", description="Show SUPERTABs Header in Geometry Nodes", default=True,update=update_node_header_master)
    st_node_header_shading: bpy.props.BoolProperty(name="Show Header (Shader)", description="Show SUPERTABs Header in Shader Editor", default=True,update=update_node_header_master)
    st_node_header_compositor: bpy.props.BoolProperty(name="Show Header (Compositor)", description="Show SUPERTABs Header in Compositor", default=True,update=update_node_header_master)
    st_node_header_texture: bpy.props.BoolProperty(name="Show Header (Texture)", description="Show SUPERTABs Header in Texture Node Editor", default=True,update=update_node_header_master)
    
    st_node_expand_fav_geometry: bpy.props.BoolProperty(name="Expand Favorite (Geometry)", default=True)
    st_node_expand_fav_shading: bpy.props.BoolProperty(name="Expand Favorite (Shader)", default=True)
    st_node_expand_fav_compositor: bpy.props.BoolProperty(name="Expand Favorite (Compositor)", default=True)
    st_node_expand_fav_texture: bpy.props.BoolProperty(name="Expand Favorite (Texture)", default=True)

    st_node_fav_cols_geometry: bpy.props.IntProperty(name="Fav Cols (Geometry)", default=2, min=1, max=3)
    st_node_fav_cols_shading: bpy.props.IntProperty(name="Fav Cols (Shader)", default=2, min=1, max=3)
    st_node_fav_cols_compositor: bpy.props.IntProperty(name="Fav Cols (Compositor)", default=2, min=1, max=3)
    st_node_fav_cols_texture: bpy.props.IntProperty(name="Fav Cols (Texture)", default=2, min=1, max=3)
    
    st_node_stats_geometry: bpy.props.BoolProperty(name="Show Stats (Geometry)", default=False)
    st_node_stats_shading: bpy.props.BoolProperty(name="Show Stats (Shader)", default=False)
    st_node_stats_compositor: bpy.props.BoolProperty(name="Show Stats (Compositor)", default=False)
    st_node_stats_texture: bpy.props.BoolProperty(name="Show Stats (Texture)", default=False)

    st_node_align_geometry: bpy.props.BoolProperty(name="Show Align (Geometry)", default=False)
    st_node_align_shading: bpy.props.BoolProperty(name="Show Align (Shader)", default=False)
    st_node_align_compositor: bpy.props.BoolProperty(name="Show Align (Compositor)", default=False)
    st_node_align_texture: bpy.props.BoolProperty(name="Show Align (Texture)", default=False)

    node_align_buttons: bpy.props.BoolProperty(name="Show Align Buttons in Arrange Node Section N-Panel", default=True)
    node_distribute_buttons: bpy.props.BoolProperty(name="Show Distribute Buttons in Arrange Node Section N-Panel", default=True)
    node_rotate_buttons: bpy.props.BoolProperty(name="Show Ratate Buttons in Arrange Node Section N-Panel", default=True)

    st_node_anno_geometry: bpy.props.BoolProperty(name="Show Anno (Geometry)", default=False)
    st_node_anno_shading: bpy.props.BoolProperty(name="Show Anno (Shader)", default=False)
    st_node_anno_compositor: bpy.props.BoolProperty(name="Show Anno (Compositor)", default=False)
    st_node_anno_texture: bpy.props.BoolProperty(name="Show Anno (Texture)", default=False)

    show_quick_3d: bpy.props.BoolProperty(name="Quick Use Section(3DView)",description="Show quick use section in SUPERTABs N-Panel (3DView)", default=True, update=update_3d_header_visibility)
    show_quick_uv: bpy.props.BoolProperty(name="Quick Use Section(UV-Editor)",description="Show quick use section in SUPERTABs N-Panel (UV-Editor)", default=True, update=update_image_header_visibility)
    show_statics_button: bpy.props.BoolProperty(name="Statistics Button", default=True)
    show_faceorien_button: bpy.props.BoolProperty(name="Face Orientation Button", default=True)
    show_lockcamera_button: bpy.props.BoolProperty(name="Lock Camera Button", default=True)
    show_viewportshading_button: bpy.props.BoolProperty(name="Viewport Shading Button", default=True)
    show_mesh_edit_overlay_button: bpy.props.BoolProperty(name="Mesh Editmode Overlay Button", default=True)
    show_cleandata_3Dview_button: bpy.props.BoolProperty(name="Clean Data Button(3D Viewport)", default=True)
    show_cleandata_image_button: bpy.props.BoolProperty(name="Clean Data Button(UV/Image Editors)", default=False)
    show_cleandata_nodes_button: bpy.props.BoolProperty(name="Clean Data Button(Node Editors)", default=False)
    show_render_button: bpy.props.BoolProperty(name="Render Settings Button", default=True)

    show_quick_node: bpy.props.BoolProperty(name="Quick Use Section(Node Editor)", description="Show quick use section in SUPERTABs N-Panel (Node Editor)", default=True, update=update_node_header_visibility)
    show_geo_timing_button: bpy.props.BoolProperty(name="Node Timing", default=True)
    show_geo_named_attribute_button: bpy.props.BoolProperty(name="Named Attributes", default=True)
    show_node_stats_button: bpy.props.BoolProperty(name="Node Stats Button", default=True)
    show_collapse_socket_button: bpy.props.BoolProperty(name="Collapse Unused Sockets Button", default=True)
    show_node_stats_panel: bpy.props.BoolProperty(name="Show Node Stats Panel", default=False)
    show_geo_zoom_buttons: bpy.props.BoolProperty(name="Show Zoom Slider", default=True, update=update_node_header_visibility)
    show_geo_align_button: bpy.props.BoolProperty(name="Align Nodes Button", default=True)
    show_view_home_button: bpy.props.BoolProperty(name="View Home Button", default=True)
    show_node_align_panel: bpy.props.BoolProperty(name="Show Align Panel", default=False) 

    st_node_quick_geometry: bpy.props.BoolProperty(name="Show Quick Section (Geometry)", default=True, update=update_node_header_visibility)
    st_node_quick_shading: bpy.props.BoolProperty(name="Show Quick Section (Shader)", default=True, update=update_node_header_visibility)
    st_node_quick_compositor: bpy.props.BoolProperty(name="Show Quick Section (Compositor)", default=True, update=update_node_header_visibility)
    st_node_quick_texture: bpy.props.BoolProperty(name="Show Quick Section (Texture)", default=True, update=update_node_header_visibility)

    st_node_zoom_geometry: bpy.props.BoolProperty(name="Show Zoom (Geometry)", default=True, update=update_node_header_visibility)
    st_node_zoom_shading: bpy.props.BoolProperty(name="Show Zoom (Shader)", default=True, update=update_node_header_visibility)
    st_node_zoom_compositor: bpy.props.BoolProperty(name="Show Zoom (Compositor)", default=True, update=update_node_header_visibility)
    st_node_zoom_texture: bpy.props.BoolProperty(name="Show Zoom (Texture)", default=True, update=update_node_header_visibility)

    # --- UV Editor Quick Section Sub-toggles ---
    show_uv_stretch: bpy.props.BoolProperty(name="UV Stretch", default=True)
    show_uv_average_scale: bpy.props.BoolProperty(name="Average Island Scale", default=True)
    show_uv_pack_islands: bpy.props.BoolProperty(name="Pack Islands", default=True)
    show_uv_sync: bpy.props.BoolProperty(name="Sync UV", default=True)
    show_uv_select_overlap: bpy.props.BoolProperty(name="Select Overlap", default=True)
    udim_tiles_panel: bpy.props.BoolProperty(name="UDIM Tiles", default=True)
    zen_udim_tools: bpy.props.BoolProperty(name="UDIM Tools (Zen UV operators NEEDED: Zen UV Add-on)", default=True)
    toggle_udim_tools: bpy.props.BoolProperty(name="UDIM Tools", default=False)

    show_image_resize: bpy.props.BoolProperty(name="Image Resize", default=True)
    show_image_replace: bpy.props.BoolProperty(name="Image Replace", default=True)
    show_external_edit: bpy.props.BoolProperty(name="External Edit", default=False)
    show_external_data: bpy.props.BoolProperty(name="External Data", default=False)
    show_save_all_image: bpy.props.BoolProperty(name="Save All Images", default=True)
    show_save_as_copy: bpy.props.BoolProperty(name="Save as Copy", default=True)

    show_reset_uv: bpy.props.BoolProperty(name="Reset UV Projection", default=False)
    show_export_uv: bpy.props.BoolProperty(name="Export UV Layout", default=True)
    show_live_unwrap: bpy.props.BoolProperty(name="Live Unwrap", default=False)

    show_anno_3d_button: bpy.props.BoolProperty(name="Annotations Button (3DView)", default=True)
    show_anno_image_button: bpy.props.BoolProperty(name="Annotations Button (Image Editor)", default=False)
    show_anno_uv_button: bpy.props.BoolProperty(name="Annotations Button (UV Editor)", default=False)
    show_anno_node_button: bpy.props.BoolProperty(name="Annotations Button (Nodes Editor)", default=False)
    show_object_name_row: bpy.props.BoolProperty(name="Show ObjectName In Transform",description="Show active object name row in transform section(Objectmode)", default=True)
    show_remove_fav_button: bpy.props.BoolProperty(name="Show Toggle Remove Button in preset favortires row", default=False)
    show_guide: bpy.props.BoolProperty(name="Show Guide Buttons in any Sections",description="Show Guide Navigator Button in Cores Sections", default=True)
    show_favorite_set_button: bpy.props.BoolProperty(name="Expand Button",description="Show Add , Settings and Clear Preset Button", default=False, update=update_favorite_expand_toggle)
    show_align_distribute: bpy.props.BoolProperty(name="Align & distribute Section", default=False)
    show_booltool: bpy.props.BoolProperty(name="BoolTools Section", default=False)
    show_looptool: bpy.props.BoolProperty(name="LoopTools Section", default=False)
    show_viewport_overlay: bpy.props.BoolProperty(name="Toggle Viewport Overlay", default=False)
    pre_clean_overlay_state: bpy.props.StringProperty(name="Pre-Clean Viewport Overlay State",description="Stores the names of active overlays before cleaning",default="")
    show_object_names_all : bpy.props.BoolProperty(name="Show Object Names (All)",description="Toggle showing all object names in viewport",default=False,update=update_show_name) 
    
    show_remove_options: bpy.props.BoolProperty(name="Show Tab-groups & Addons-tabs Remove Buttons", default=True)
    show_move_options: bpy.props.BoolProperty(name="Show Tab-groups & Addons-tabs Move Buttons", default=True)
    status_icon_quick: bpy.props.BoolProperty(name="Show Icon status 'Quick Shortcut'", default=True)
    status_icon_fav_panel: bpy.props.BoolProperty(name="Show Icon status 'Favorite Tabs Preset'", default=True)
    
    # --- EditSections ---
    show_shape_data: bpy.props.BoolProperty(name="Shape", default=True)
    show_shape_twist: bpy.props.BoolProperty(name="Shape Twist", default=False)
    show_geometry_data: bpy.props.BoolProperty(name="Geometry", default=True)
    show_geo_taper: bpy.props.BoolProperty(name="Geometry Taper", default=False)
    show_bevel_data: bpy.props.BoolProperty(name="Bevel", default=True)
    start_end_map: bpy.props.BoolProperty(name="Start & End Mapping", default=False)

    show_aligndis_props: bpy.props.BoolProperty(name="Align & Distribute", default=True)
    show_align_advanced: bpy.props.BoolProperty(name="Advanced Align", description="Show Advanced Align Buttons in Edit panel section", default=True)
    show_align_location: bpy.props.BoolProperty(name="Align Location", description="Show Align(Location) Button in Edit panel section", default=True)
    show_align_rotaion: bpy.props.BoolProperty(name="Align Rotation", description="Show Align(Rotation) Button in Edit panel section", default=True)
    show_align_scale: bpy.props.BoolProperty(name="Align Scale", description="Show Align(Scale) Button in Edit panel section", default=True)
    show_distribute: bpy.props.BoolProperty(name="Align Scale", description="Show Distribute Buttons in Edit panel section", default=True)

    show_booltool_props: bpy.props.BoolProperty(name="BoolTool", default=True)
    show_auto_bool: bpy.props.BoolProperty(name="Auto Boolean", description="Show Auto(Boolean) buttons in Edit panel section", default=True)
    show_Brush_bool: bpy.props.BoolProperty(name="Brush Boolean", description="Show Brush(Boolean) buttons in Edit panel section", default=True)

    show_looptools_props: bpy.props.BoolProperty(name="LoopTools", default=True)
    show_bridge_loop: bpy.props.BoolProperty(name="Bridge", default=True)
    show_circle_loop: bpy.props.BoolProperty(name="Circle", default=True)
    show_curve_loop: bpy.props.BoolProperty(name="Curve", default=True)
    show_flastten_loop: bpy.props.BoolProperty(name="Flastten", default=True)
    show_gstretch_loop: bpy.props.BoolProperty(name="Gstretch", default=True)
    show_loft_loop: bpy.props.BoolProperty(name="Loft", default=True)
    show_relax_loop: bpy.props.BoolProperty(name="Relax", default=True)
    show_space_loop: bpy.props.BoolProperty(name="Space", default=True)
    
    # --- 3D View Manager Control ---
    show_fav_panel_3d: bpy.props.BoolProperty(name="Show Favorites & Presets (3D View)",description="Show or Hide Favorites and Presets in 3D View",default=True,update=update_manager_3d_child)
    show_groups_panel_3d: bpy.props.BoolProperty(name="Show Groups & Addons (3D View)",description="Show or Hide Groups & Addons in 3D View",default=True,update=update_manager_3d_child)
    show_collapse_all_3d: bpy.props.BoolProperty(name="Show Collapse All (3D View)", default=True, update=update_manager_3d_child)

    # --- Image/UV Editor Manager Control ---
    show_manager_header_3d: bpy.props.BoolProperty(name="Show SUPERTABs Manager Header",description="Toggle entire Favorite and Group Manager section",default=True,update=update_manager_3d_master)
    show_manager_header_image: bpy.props.BoolProperty(name="Show SUPERTABs Manager Header (UV)",description="Toggle entire Favorite and Group Manager section in UV Editor",default=True,update=update_manager_image_master)
    show_fav_panel_image: bpy.props.BoolProperty(name="Show Favorites & Presets (UV)",description="Show or Hide Favorites and Presets in UV Editor",default=True,update=update_manager_image_child)
    show_groups_panel_image: bpy.props.BoolProperty(name="Show Groups & Addons (UV)",description="Show or Hide Groups & Addons in UV Editor",default=True,update=update_manager_image_child)
    show_collapse_all_image: bpy.props.BoolProperty(name="Show Collapse All (UV)", default=True, update=update_manager_image_child)

    # --- Image Editor Specific Controls---
    show_header_image_only: bpy.props.BoolProperty(name="SUPERTABs N-Panel Header (Image)",description="Main SUPERTABs N-Panel Header(Image Editor)",default=True,update=update_image_header_master_only)
    show_quick_image: bpy.props.BoolProperty(name="Quick Use Section (Image)",description="Show quick use section in SUPERTABs N-Panel (Image Editor)",default=True,update=update_image_header_visibility_only)
    show_basic_image_buttons: bpy.props.BoolProperty(name="toggle show/Hide Image Basic Tabs Buttons",default=True,update=update_image_header_visibility_only)

    # Manager Header (Image)
    show_manager_header_image_only: bpy.props.BoolProperty(name="Show SUPERTABs Manager Header (Image)",description="Toggle entire Favorite and Group Manager section in Image Editor",default=True,update=update_manager_image_master_only)
    show_fav_panel_image_only: bpy.props.BoolProperty(name="Show Favorites & Presets (Image)",description="Show or Hide Favorites and Presets in Image Editor",default=True,update=update_manager_image_child_only)
    show_groups_panel_image_only: bpy.props.BoolProperty(name="Show Groups & Addons (Image)",description="Show or Hide Groups & Addons in Image Editor",default=True,update=update_manager_image_child_only)
    show_collapse_all_image_only: bpy.props.BoolProperty(name="Show Collapse All (Image)",default=True,update=update_manager_image_child_only)

    # --- Node Editor Manager Control ---
    show_manager_header_shading: bpy.props.BoolProperty(name="Show SUPERTABs Manager Header (Shader)",description="Toggle Manager Header in Shader Editor",default=True, update=update_shading_master)
    show_manager_header_geometry: bpy.props.BoolProperty(name="Show SUPERTABs Manager Header (Geo)",description="Toggle Manager Header in Geometry Node Editor",default=True, update=update_geometry_master)
    show_manager_header_compositor: bpy.props.BoolProperty(name="Show SUPERTABs Manager Header (Compo)",description="Toggle Manager Header in Compositor",default=True, update=update_compositor_master)
    show_manager_header_texture: bpy.props.BoolProperty(name="Show SUPERTABs Manager Header (Texture)",description="Toggle Manager Header in Texture Node Editor",default=True, update=update_texture_master)
    
    # --- Visibility Node Editor ---
    show_fav_panel_shading: bpy.props.BoolProperty(name="Show Favorites (Shader)", default=True, update=update_shading_child)
    show_groups_panel_shading: bpy.props.BoolProperty(name="Show Groups (Shader)", default=True, update=update_shading_child)
    show_collapse_all_shading: bpy.props.BoolProperty(name="Show Collapse All (Shader)", default=True, update=update_shading_child)

    show_fav_panel_geometry: bpy.props.BoolProperty(name="Show Favorites (Geo)", default=True, update=update_geometry_child)
    show_groups_panel_geometry: bpy.props.BoolProperty(name="Show Groups (Geo)", default=True, update=update_geometry_child)
    show_collapse_all_geometry: bpy.props.BoolProperty(name="Show Collapse All (Geo)", default=True, update=update_geometry_child)

    show_fav_panel_compositor: bpy.props.BoolProperty(name="Show Favorites (Compo)", default=True, update=update_compositor_child)
    show_groups_panel_compositor: bpy.props.BoolProperty(name="Show Groups (Compo)", default=True, update=update_compositor_child)
    show_collapse_all_compositor: bpy.props.BoolProperty(name="Show Collapse All (Compo)", default=True, update=update_compositor_child)

    show_fav_panel_texture: bpy.props.BoolProperty(name="Show Favorites (Texture)", default=True, update=update_texture_child)
    show_groups_panel_texture: bpy.props.BoolProperty(name="Show Groups (Texture)", default=True, update=update_texture_child)
    show_collapse_all_texture: bpy.props.BoolProperty(name="Show Collapse All (Texture)", default=True, update=update_texture_child)

    # --- Collapse All Options ---
    # show_collapse_options: bpy.props.BoolProperty(name="Show Collapse Options",description="Show/Hide detailed collapse settings",default=False)
    # collapse_opt_items: bpy.props.BoolProperty(name="Close Items (Addons/Tabs)",description="Collapse active items (Addons/Tabs) and clear pinned items",default=True)
    # collapse_opt_groups: bpy.props.BoolProperty(name="Close Tab Groups",description="Collapse all expanded subgroups",default=True)
    # collapse_opt_panels: bpy.props.BoolProperty(name="Close Panels (Favorites/Groups)",description="Close Favorite Tabs Panel and Groups & Addons Panel",default=True)

    show_collapse_options: bpy.props.BoolProperty(name="Show Collapse Options", default=False)
    collapse_opt_items: bpy.props.BoolProperty(name="Addons/Tabs", description="Collapse currently opened tabs or addon panels", default=True)
    collapse_opt_groups: bpy.props.BoolProperty(name="Tab-Groups", description="Collapse all expanded folder groups in the N-panel", default=True)
    collapse_opt_panels: bpy.props.BoolProperty(name="Panels(Favorites/Groups)", description="Close Favorites and Groups/Add-ons manager panels", default=True)
    # --------------------------------------------------------
    # --- BasicSections ---
    show_basic_uv_buttons: bpy.props.BoolProperty(name="toggle show/Hide UV Basic Tabs Buttons", default=True, update=update_image_header_visibility)
    show_uv_vertex_section: bpy.props.BoolProperty(name="UV Vertex Section", description="Show UV Vertex section in SUPERTABs N-Panel(Image Editor)", default=True)
    show_uv_vertex_panel: bpy.props.BoolProperty(name="UV Vertex Section Panel", default=False)
    show_image_section: bpy.props.BoolProperty(name="Image Section", description="Show Image section in SUPERTABs N-Panel(Image Editor)", default=True)
    show_external_section: bpy.props.BoolProperty(name="Image Section", description="Show External Data section in SUPERTABs N-Panel(Image Editor)", default=True)
    show_uv_vertex_panel: bpy.props.BoolProperty(name="External Data Section Panel", default=False)

    show_image_panel: bpy.props.BoolProperty(name="Image Section Panel", default=False)
    show_image_panel_uv: bpy.props.BoolProperty(name="Image Section Panel (UV)", default=False)

    show_image_uv_vertex_panel: bpy.props.BoolProperty(name="Image (UV Vertex) Section Panel", default=False)
    show_align_uv: bpy.props.BoolProperty(name="Align UV Vertex Panel", default=False)
    show_edit_section: bpy.props.BoolProperty(name="Edit Section", description="Show Edit section in SUPERTABs N-Panel", default=True)
    show_edit_panel: bpy.props.BoolProperty(name="Edit Panel Section", default=False)
    show_transform_section: bpy.props.BoolProperty(name="Transform Section", description="Show transform section in SUPERTABs N-Panel", default=True)
    show_transform_panel: bpy.props.BoolProperty(name="Transform Section Panel", default=False)
    show_view_section: bpy.props.BoolProperty(name="View Section", description="Show View section in SUPERTABs N-Panel", default=True)
    show_view_panel: bpy.props.BoolProperty(name="View Section Panel", default=False)
    show_normal_section: bpy.props.BoolProperty(name="Show Object Normal Section", default=True)
    show_normal_panel: bpy.props.BoolProperty(name="Expand Object Normal Panel", default=False)
    show_curve_section: bpy.props.BoolProperty(name="Show Curve Data in Transform Section", description="Show Curve Data Panel in Transform panel section", default=True)
    show_curve_panel: bpy.props.BoolProperty(name="Curve Data", default=False)
    show_basic_panel: bpy.props.BoolProperty(name="Transform , View & Edit Section", description="Show Transform , View & Edit Sections in SUERPTABs N-Panel", default=True, update=update_3d_header_visibility)

    # --- General Tab Management ---
    manage_item_tab: bpy.props.BoolProperty(name="Item", default=False, update=auto_apply_ui_update)
    manage_tool_tab: bpy.props.BoolProperty(name="Tool", default=True, update=auto_apply_ui_update)
    manage_view_tab: bpy.props.BoolProperty(name="View", default=False, update=auto_apply_ui_update)
    manage_edit_tab: bpy.props.BoolProperty(name="Edit", default=False, update=auto_apply_ui_update)
    manual_exclude_tabs: bpy.props.StringProperty(name="Manually Exclude Tabs (3D)", default="glTF Variants, Extra Pies", update=refresh_available_list_callback)
    manual_exclude_tabs_image: bpy.props.StringProperty(name="Manually Exclude Tabs (Image)", default="Mask", update=refresh_available_list_callback)
    # lock_manage_tool_tab: bpy.props.BoolProperty(name="Lock Tool Tab Management",description="Lock the 'Tool' tab management setting. Click to unlock.",default=True)

    manage_uv_image_tab: bpy.props.BoolProperty(name="Image", default=True, update=auto_apply_ui_update)
    manage_uv_tool_tab: bpy.props.BoolProperty(name="Tool", default=False, update=auto_apply_ui_update)
    manage_uv_view_tab: bpy.props.BoolProperty(name="View", default=False, update=auto_apply_ui_update)
    manage_uv_scope_tab: bpy.props.BoolProperty(name="Scope", default=False, update=auto_apply_ui_update)
    # lock_manage_uv_tool_tab: bpy.props.BoolProperty(name="Lock UV Tool Tab Management",description="Lock the 'Tool' tab management setting for UV Editor.",default=True)
    
    manage_node_options_tab: bpy.props.BoolProperty(name="Options", default=False, update=auto_apply_ui_update)
    manage_node_tool_tab: bpy.props.BoolProperty(name="Tool", default=False, update=auto_apply_ui_update)
    manage_node_view_tab: bpy.props.BoolProperty(name="View", default=False, update=auto_apply_ui_update)
    manage_node_node_tab: bpy.props.BoolProperty(name="Node", default=False, update=auto_apply_ui_update)
    manage_node_group_tab: bpy.props.BoolProperty(name="Group", default=True if bpy.app.version >= (5, 0, 0) else False, update=auto_apply_ui_update)
    lock_manage_node_group_tab: bpy.props.BoolProperty(name="Lock Group Tab Management", default=True if bpy.app.version >= (5, 0, 0) else False)

    manual_exclude_tabs_node: bpy.props.StringProperty(name="Manually Exclude Tabs (Node)", default="", update=refresh_available_list_callback)

    show_node_fav_options: bpy.props.BoolProperty(name="Show Favorite Nodes Options", default=True)
    toggle_fav_remove_buttons: bpy.props.BoolProperty(name="Show Favorite Nodes Remove Buttons", default=True)

    st_node_cols_shading: bpy.props.IntProperty(name="Shading Item Columns", default=1, min=1, max=5, update=trigger_redraw)
    st_node_fav_shading: bpy.props.BoolProperty(name="Show Shading Favorite Panel", default=True, update=trigger_redraw)
    st_node_opt_shading: bpy.props.BoolProperty(name="Show Shading Options", default=True, update=trigger_redraw)
    st_node_manager_shading: bpy.props.BoolProperty(name="Show Shading Panel Manager", default=True, update=trigger_redraw)
    st_node_show_fav_nodes_shading: bpy.props.BoolProperty(name="Show Shading Favorite Nodes", default=True, update=trigger_redraw)
    
    st_node_cols_geometry: bpy.props.IntProperty(name="Geometry Item Columns", default=1, min=1, max=5, update=trigger_redraw)
    st_node_fav_geometry: bpy.props.BoolProperty(name="Show Geometry Favorite Panel", default=True, update=trigger_redraw)
    st_node_opt_geometry: bpy.props.BoolProperty(name="Show Geometry Options", default=True, update=trigger_redraw)
    st_node_manager_geometry: bpy.props.BoolProperty(name="Show Geometry Panel Manager", default=True, update=trigger_redraw)
    st_node_show_fav_nodes_geometry: bpy.props.BoolProperty(name="Show Geometry Favorite Nodes", default=True, update=trigger_redraw)

    st_node_cols_compositor: bpy.props.IntProperty(name="Compositor Item Columns", default=1, min=1, max=5, update=trigger_redraw)
    st_node_fav_compositor: bpy.props.BoolProperty(name="Show Compositor Favorite Panel", default=True, update=trigger_redraw)
    st_node_opt_compositor: bpy.props.BoolProperty(name="Show Compositor Options", default=True, update=trigger_redraw)
    st_node_manager_compositor: bpy.props.BoolProperty(name="Show Compositor Panel Manager", default=True, update=trigger_redraw)
    st_node_show_fav_nodes_compositor: bpy.props.BoolProperty(name="Show Compositor Favorite Nodes", default=True, update=trigger_redraw)

    st_node_cols_texture: bpy.props.IntProperty(name="Texture Item Columns", default=1, min=1, max=5, update=trigger_redraw)
    st_node_fav_texture: bpy.props.BoolProperty(name="Show Texture Favorite Panel", default=True, update=trigger_redraw)
    st_node_opt_texture: bpy.props.BoolProperty(name="Show Texture Options", default=True, update=trigger_redraw)
    st_node_manager_texture: bpy.props.BoolProperty(name="Show Texture Panel Manager", default=True, update=trigger_redraw)
    st_node_show_fav_nodes_texture: bpy.props.BoolProperty(name="Show Texture Favorite Nodes", default=True, update=trigger_redraw)

    # --- Visibility & Ejection States ---
    hidden_subgroups: bpy.props.StringProperty(name="Hidden Subgroups")
    hidden_items: bpy.props.StringProperty(name="Hidden Items")
    temporarily_ejected_items: bpy.props.StringProperty(name="Temporarily Ejected Items")
    ejected_subgroups: bpy.props.StringProperty(name="Ejected Subgroups")

    # --- Internal & Status ---
    status_message: bpy.props.StringProperty(name="Status Message", default="")
    status_type: bpy.props.EnumProperty(name="Status Type", items=[('NONE', "None", ""), ('INFO', "Info", ""), ('SUCCESS', "Success", ""), ('WARNING', "Warning", ""), ('ERROR', "Error", "")], default='NONE')
    status_timer: bpy.props.IntProperty(name="Status Timer", default=0, min=0)
    temp_target_index: bpy.props.IntProperty(options={'HIDDEN'})
    lock_panel_switch_delay: bpy.props.BoolProperty(name="Lock Panel Switch Delay", default=True)
    lock_keymap_delay: bpy.props.BoolProperty(name="Lock Keymap Delay", default=True)
    lock_startup_delay: bpy.props.BoolProperty(name="Lock Startup Delay", default=True)
    lock_poll_exceptions: bpy.props.BoolProperty(name="Lock Poll Exceptions", default=True)
    show_poll_exceptions: bpy.props.BoolProperty(name="Show Poll Exceptions", description="Toggle visibility of Poll Exceptions setting in preferences",
        default=False,
        update=update_show_poll_exceptions
    )
    # --- Favorite Nodes ---
    favorite_nodes: bpy.props.CollectionProperty(type=ST_FavoriteNodeItem)
    show_favorite_nodes_panel: bpy.props.BoolProperty(name="Show Favorite Nodes Panel", default=True, update=update_node_header_visibility)
    favorite_nodes_columns: bpy.props.IntProperty(name="Favorite Nodes Columns(Texture)", default=2, min=1, max=4)
    
    # --- Addon State Import/Export ---
    addon_state_filepath: bpy.props.StringProperty(name="Addon List JSON",description="Select the JSON file containing addon states",subtype='FILE_PATH',default="")
    show_recovery_addons: bpy.props.BoolProperty(name="Show Recovery Addons Section",description="Toggle visibility of the Recovery Addons section in preferences",default=False)

    info_section_tab: bpy.props.EnumProperty(
        name="Info Section",
        description="Switch between information tabs",
        items=[
            ('WARNING', "Warnings", "Important Warnings", 'WARNING_LARGE', 0),
            ('ANNOUNCEMENT', "News", "Announcements & Updates", 'INFO', 1),
            ('LIMITATION', "Limitations", "Known API Limitations", 'CANCEL', 2),
        ],
        default='WARNING'
    )
    
    fav_node_view_mode: bpy.props.EnumProperty(
        name="View Mode",
        description="Filter between Nodes and Groups",
        items=[
            ('NODES', "Nodes", "Show standard nodes only", 'NODE', 0),
            ('GROUPS', "Node Groups", "Show node groups only", 'NODETREE', 1),
        ],
        default='NODES'
    )

    zoom_strength_in_factor: bpy.props.IntProperty(
        name="Zoom In Strength", 
        default=35,
        min=0, 
        max=100,
        subtype='PERCENTAGE',
        description="Adjust the zoom in speed/strength (Percentage)"
    )

    zoom_strength_out_factor: bpy.props.IntProperty(
        name="Zoom Out Strength", 
        default=35,
        min=0, 
        max=100,
        subtype='PERCENTAGE',
        description="Adjust the zoom out speed/strength (Percentage)"
    )

    zoom_strength_in_saved: bpy.props.IntProperty(default=35, options={'HIDDEN'})
    zoom_strength_out_saved: bpy.props.IntProperty(default=35, options={'HIDDEN'})

    # Exception List
    exception_items: bpy.props.CollectionProperty(type=ST_ExceptionItem)

    show_limitations_info: bpy.props.BoolProperty(name="Limitations List for Blender Main Tabs", default=False)
    # show_known_issues: bpy.props.BoolProperty(name="Known Issues Info", default=False)
    show_info_node: bpy.props.BoolProperty(name="Node Editor Updated Info", default=False)
    show_info_uv: bpy.props.BoolProperty(name="UV Editor Updated Info", default=False)
    show_info_prefs: bpy.props.BoolProperty(name="Preferences Updated Info", default=False)
    show_fix_enhancements: bpy.props.BoolProperty(name="Fixes & Enhancements Info", default=False)

    show_packmaster_info: bpy.props.BoolProperty(name="Packmaster Info", default=False)
    show_gscatter_info: bpy.props.BoolProperty(name="GScatter Info", default=False)
    show_info: bpy.props.BoolProperty(name="Show Info Section", default=True)
    show_fav_node_info: bpy.props.BoolProperty(name="Show Favorite Nodes Info", default=False)

    show_image_selector: BoolProperty(
        name="Show Image Selector",
        description="Show the image selection dropdown (Template ID) in the header",
        default=True,
        update=update_image_selector
    )

    # --- Draw Method ---
    def draw(self, context):
        from ..ui.preferences import draw_preferences_layout
        draw_preferences_layout(self, context)