import bpy
from ..utils import (
    get_proxy_dimensions, set_proxy_dimensions,
    get_median_vector, set_median_vector,
    get_median_curve_vector, set_median_curve_vector,
    get_vert_bevel, set_vert_bevel, 
    get_vert_crease, set_vert_crease, 
    get_edge_bevel, set_edge_bevel,
    get_edge_crease, set_edge_crease, 
    get_curve_weight, set_curve_weight, 
    get_curve_radius, set_curve_radius,
    get_curve_tilt, set_curve_tilt
)

class LiveDataProperties(bpy.types.PropertyGroup):
    """Stores all custom properties needed for the tool."""
    curve_median_vector: bpy.props.FloatVectorProperty(
        name="Curve Median", get=get_median_curve_vector, set=set_median_curve_vector,
        subtype='TRANSLATION', unit='LENGTH', precision=4
    )
    median_vector: bpy.props.FloatVectorProperty(
        name="Median", get=get_median_vector, set=set_median_vector,
        subtype='TRANSLATION', unit='LENGTH', precision=4
    )

    proxy_dimensions: bpy.props.FloatVectorProperty(
        name="Dimensions",
        description="Proxy to allow simultaneous editing of object dimensions",
        get=get_proxy_dimensions,
        set=set_proxy_dimensions,
        subtype='XYZ',
        unit='LENGTH',
        precision=4
    )

    space_mode: bpy.props.EnumProperty(
        name="Space", items=[('GLOBAL', "Global", ""), ('LOCAL', "Local", "")], default='LOCAL'
    )

    show_quick_set: bpy.props.BoolProperty(name="Quick Bevel/Crease", default=False)
    # --- individual floats with vectors ---
    vert_bevel: bpy.props.FloatProperty(
        name="Bevel Weight", get=get_vert_bevel, set=set_vert_bevel,
        min=0.0, max=1.0, precision=3
    )
    vert_crease: bpy.props.FloatProperty(
        name="Vertex Crease", get=get_vert_crease, set=set_vert_crease,
        min=0.0, max=1.0, precision=3
    )
    edge_bevel: bpy.props.FloatProperty(
        name="Bevel Weight", get=get_edge_bevel, set=set_edge_bevel,
        min=0.0, max=1.0, precision=3
    )
    edge_crease: bpy.props.FloatProperty(
        name="Crease", get=get_edge_crease, set=set_edge_crease,
        min=0.0, max=1.0, precision=3
    )

    curve_mean_weight: bpy.props.FloatProperty(
        name="Mean Weight", get=get_curve_weight, set=set_curve_weight,
        min=0.1,max=1.0,precision=3
    )
    curve_mean_radius: bpy.props.FloatProperty(
        name="Mean Radius", get=get_curve_radius, set=set_curve_radius,
        min=0.0, precision=3
    )
    curve_mean_tilt: bpy.props.FloatProperty(
        name="Mean Tilt", get=get_curve_tilt, set=set_curve_tilt,
        subtype='ANGLE', unit='ROTATION', precision=3
    )