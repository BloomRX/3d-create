import bpy

from .items import (
    HiddenPanelItem, CustomItemName, AvailableItem, FavoriteAddonItem,
    AddonPresetItem, CustomFavoritePreset, SubgroupColumnState,
    ST_QuickShortcutItem, TabGroupItem, AddonPreset, SubTabState,
    ST_FavoriteNodeItem, ST_ExceptionItem,

    _restricted_icon_enum_items,
    _subgroup_icon_options,
    _restricted_node_socket_icons,
    update_subgroup_columns
)

from .live_data import LiveDataProperties
from .prefs import ST_AddonPreferences

classes = (
    ST_ExceptionItem,
    HiddenPanelItem,
    CustomItemName,
    AvailableItem,
    FavoriteAddonItem,
    AddonPresetItem,
    CustomFavoritePreset,
    SubgroupColumnState,
    ST_QuickShortcutItem,
    TabGroupItem,
    AddonPreset,
    SubTabState,
    ST_FavoriteNodeItem,
    LiveDataProperties,
    ST_AddonPreferences,
)

def register():
    bpy.types.WindowManager.tab_group_states = bpy.props.CollectionProperty(type=SubTabState)
    bpy.types.WindowManager.st_addon_name_to_add = bpy.props.StringProperty()
    bpy.types.WindowManager.st_item_to_move = bpy.props.StringProperty()
    bpy.types.WindowManager.st_source_group_index_for_move = bpy.props.IntProperty()
    bpy.types.WindowManager.st_item_to_favorite = bpy.props.StringProperty()
    bpy.types.WindowManager.st_group_for_favorite = bpy.props.StringProperty()
    bpy.types.WindowManager.st_subgroup_index_to_move = bpy.props.IntProperty()
    bpy.types.WindowManager.st_preset_icon_picker_index = bpy.props.IntProperty(default=-1)
    bpy.types.WindowManager.st_last_active_main_group = bpy.props.StringProperty(name="Last Active SUPERTABs Group")
    bpy.types.WindowManager.st_item_for_preset_list = bpy.props.StringProperty()
    bpy.types.WindowManager.st_group_for_preset_list = bpy.props.StringProperty()

    bpy.types.Scene.my_live_data_tool = bpy.props.PointerProperty(type=LiveDataProperties)

    bpy.types.WindowManager.st_ui_applied_once = bpy.props.BoolProperty(
        name="Supertabs UI Applied At Least Once",
        description="Tracks if the user has applied/refreshed the UI at least once per session",
        default=False
    )

def unregister():
    try:
        del bpy.types.WindowManager.st_ui_applied_once
        del bpy.types.Scene.my_live_data_tool
        del bpy.types.WindowManager.st_addon_name_to_add
        del bpy.types.WindowManager.tab_group_states
        del bpy.types.WindowManager.st_item_to_move
        del bpy.types.WindowManager.st_source_group_index_for_move
        del bpy.types.WindowManager.st_subgroup_index_to_move
        del bpy.types.WindowManager.st_item_to_favorite
        del bpy.types.WindowManager.st_group_for_favorite
        del bpy.types.WindowManager.st_preset_icon_picker_index
        del bpy.types.WindowManager.st_last_active_main_group
        del bpy.types.WindowManager.st_item_for_preset_list
        del bpy.types.WindowManager.st_group_for_preset_list
    except (AttributeError, RuntimeError):
        pass