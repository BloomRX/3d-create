import bpy
from .. import state as st_state

class ST_OT_CreateAddonPreset(bpy.types.Operator):
    """Creates a new, empty addon preset."""
    bl_idname = "st.create_addon_preset"
    bl_label = "Create Preset"

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        new_preset = prefs.addon_presets.add()
        
        base_name = "New Preset"
        i = 1
        new_name = base_name
        preset_names = {p.name for p in prefs.addon_presets}
        while new_name in preset_names:
            new_name = f"{base_name} {i}"
            i += 1
        new_preset.name = new_name
        
        return {'FINISHED'}
    
class ST_OT_DeleteAddonPreset(bpy.types.Operator):
    """Deletes an addon preset."""
    bl_idname = "st.delete_addon_preset"
    bl_label = "Delete Preset"
    bl_options = {'REGISTER'}

    preset_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.preset_index < len(prefs.addon_presets):
            prefs.addon_presets.remove(self.preset_index)
        return {'FINISHED'}
    
class ST_OT_AddAddonToPreset(bpy.types.Operator):
    """Adds an addon to a specific preset."""
    bl_idname = "st.add_addon_to_preset"
    bl_label = "Add to Preset"
    bl_options = {'REGISTER'}

    addon_name: bpy.props.StringProperty()
    preset_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.preset_index < len(prefs.addon_presets):
            preset = prefs.addon_presets[self.preset_index]
            
            # --- Check if addon already exists in preset ---
            if self.addon_name not in {a.name for a in preset.addons}:
                new_addon = preset.addons.add()
                new_addon.name = self.addon_name
                self.report({'INFO'}, f"Added '{self.addon_name}' to preset '{preset.name}'.")
            else:
                self.report({'INFO'}, f"'{self.addon_name}' is already in preset '{preset.name}'.")
        return {'FINISHED'}
    
class ST_OT_EnablePresetAddons(bpy.types.Operator):
    """Enables all addons in a specific preset."""
    bl_idname = "st.enable_preset_addons"
    bl_label = "Enable All in Preset"
    bl_options = {'REGISTER'}

    preset_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if not (0 <= self.preset_index < len(prefs.addon_presets)):
            return {'CANCELLED'}
            
        preset = prefs.addon_presets[self.preset_index]
        enabled_count = 0
        for addon in preset.addons:
            try:
                bpy.ops.preferences.addon_enable(module=addon.name)
                enabled_count += 1
            except Exception as e:
                print(f"SUPERTABs: Could not enable '{addon.name}': {e}")
        
        self.report({'INFO'}, f"Enabled {enabled_count} addon(s) from preset '{preset.name}'.")
        return {'FINISHED'}
    
class ST_OT_DisablePresetAddons(bpy.types.Operator):
    """Disables all addons in a specific preset, skipping managed addons."""
    bl_idname = "st.disable_preset_addons"
    bl_label = "Disable All in Preset"
    bl_options = {'REGISTER'}

    preset_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if not (0 <= self.preset_index < len(prefs.addon_presets)):
            return {'CANCELLED'}

        preset = prefs.addon_presets[self.preset_index]
        wrapped_modules = {data['original_class'].__module__ for data in st_state.managed_panels.values() if data.get('type') == 'MANAGED'}
        
        disabled_count = 0
        skipped_count = 0
        for addon in preset.addons:
            if addon.name in wrapped_modules:
                skipped_count += 1
                continue
            
            try:
                bpy.ops.preferences.addon_disable(module=addon.name)
                disabled_count += 1
            except Exception as e:
                print(f"SUPERTABs: Could not disable '{addon.name}': {e}")

        message = f"Disabled {disabled_count} addon(s) from preset '{preset.name}'."
        if skipped_count > 0:
            message += f" Skipped {skipped_count} managed addon(s)."

        self.report({'INFO'}, message)
        return {'FINISHED'}
    
class ST_OT_RemoveAddonFromPreset(bpy.types.Operator):
    """Removes an addon from a specific preset."""
    bl_idname = "st.remove_addon_from_preset"
    bl_label = "Remove from Preset"
    bl_options = {'REGISTER'}

    addon_name: bpy.props.StringProperty()
    preset_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.preset_index < len(prefs.addon_presets):
            preset = prefs.addon_presets[self.preset_index]
            
            found_index = -1
            for i, addon in enumerate(preset.addons):
                if addon.name == self.addon_name:
                    found_index = i
                    break
            
            if found_index != -1:
                preset.addons.remove(found_index)
                self.report({'INFO'}, f"Removed '{self.addon_name}' from preset '{preset.name}'.")
            else:
                self.report({'WARNING'}, f"Could not find '{self.addon_name}' in preset '{preset.name}'.")
        else:
            self.report({'WARNING'}, "Preset index out of range.")
            
        return {'FINISHED'}
    
classes = (
    ST_OT_CreateAddonPreset,
    ST_OT_DeleteAddonPreset,
    ST_OT_AddAddonToPreset,
    ST_OT_RemoveAddonFromPreset,
    ST_OT_EnablePresetAddons,
    ST_OT_DisablePresetAddons,
)