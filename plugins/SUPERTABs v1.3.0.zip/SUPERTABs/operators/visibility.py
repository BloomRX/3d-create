import bpy
from ..core import apply_group_settings

class ST_OT_TogglePinItem(bpy.types.Operator):
    """Toggles the pinned state of a UI item in a SuperTab group."""
    bl_idname = "st.toggle_pin_item"
    bl_label = "Pin Item"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    item_string: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}

        pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}

        if self.item_string in pinned_set:
            pinned_set.remove(self.item_string)
            if state.active_item == self.item_string:
                state.active_item = ""
        else:
            pinned_set.add(self.item_string)
            state.active_item = self.item_string

        state.pinned_items = ", ".join(sorted(list(pinned_set)))

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()

        return {'FINISHED'}
    
class ST_OT_PinAllFavorites(bpy.types.Operator):
    """Pins all items currently in the favorites list for a group."""
    bl_idname = "st.pin_all_favorites"
    bl_label = "Pin All Favorite Items"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}

        active_preset = next((p for p in state.favorite_presets if p.name == state.active_favorite_preset_name), None)
        if not active_preset or not active_preset.items:
            self.report({'INFO'}, "No favorite items in the active preset to pin.")
            return {'CANCELLED'}

        favorite_set = {item.strip() for item in active_preset.items.split(',') if item.strip()}
        pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}
        pinned_set.update(favorite_set)
        state.pinned_items = ", ".join(sorted(list(pinned_set)))
        self.report({'INFO'}, "Pinned all items from the active favorite preset.")

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}
    
class ST_OT_UnpinAllFavorites(bpy.types.Operator):
    """Unpins all items currently in the favorites list for a group."""
    bl_idname = "st.unpin_all_favorites"
    bl_label = "Unpin All Favorite Items"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}

        active_preset = next((p for p in state.favorite_presets if p.name == state.active_favorite_preset_name), None)
        if not active_preset or not active_preset.items:
            self.report({'INFO'}, "No favorite items in the active preset to unpin.")
            return {'CANCELLED'}

        favorite_set = {item.strip() for item in active_preset.items.split(',') if item.strip()}
        pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}
        pinned_set.difference_update(favorite_set)
        state.pinned_items = ", ".join(sorted(list(pinned_set)))
        self.report({'INFO'}, "Unpinned all items from the active favorite preset.")

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}
    
class ST_OT_EjectItem(bpy.types.Operator):
    bl_idname = "st.eject_item"
    bl_label = "Eject Item"
    bl_options = {'REGISTER'}
    item_string: bpy.props.StringProperty()
    def execute(self, context):
        if "uvpackmaster3" in self.item_string.lower():
            self.report({'WARNING'}, "UVPackmaster3 cannot be ejected.")
            return {'CANCELLED'}
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        ejected_set = {item.strip() for item in prefs.temporarily_ejected_items.split(',') if item.strip()}
        ejected_set.add(self.item_string)
        prefs.temporarily_ejected_items = ", ".join(sorted(list(ejected_set)))
        apply_group_settings(context, self)
        return {'FINISHED'}
    
class ST_OT_EjectSubgroup(bpy.types.Operator):
    bl_idname = "st.eject_subgroup"
    bl_label = "Eject Tabgroup"
    bl_options = {'REGISTER'}
    subgroup_full_name: bpy.props.StringProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        subgroup_to_check = next((g for g in prefs.tab_groups if g.name == self.subgroup_full_name), None)
        if subgroup_to_check:
            items_in_subgroup = {item.strip() for item in subgroup_to_check.items.split(',') if item.strip()}
            if any("gscatter" in item.lower() for item in items_in_subgroup):
                self.report({'WARNING'}, "Cannot eject a subgroup containing 'GScatter'.")
                return {'CANCELLED'}
            ejected_items_set = {item.strip() for item in prefs.temporarily_ejected_items.split(',') if item.strip()}
            if not items_in_subgroup.isdisjoint(ejected_items_set):
                self.report({'WARNING'}, "Cannot eject a subgroup containing an already ejected item.")
                return {'CANCELLED'}
        ejected_set = {s.strip() for s in prefs.ejected_subgroups.split(',') if s.strip()}
        ejected_set.add(self.subgroup_full_name)
        prefs.ejected_subgroups = ", ".join(sorted(list(ejected_set)))
        apply_group_settings(context, self)
        return {'FINISHED'}
    
class ST_OT_RegroupItem(bpy.types.Operator):
    bl_idname = "st.regroup_item"
    bl_label = "Regroup Item"
    bl_options = {'REGISTER'}
    item_string: bpy.props.StringProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        ejected_set = {item.strip() for item in prefs.temporarily_ejected_items.split(',') if item.strip()}
        ejected_set.discard(self.item_string)
        prefs.temporarily_ejected_items = ", ".join(sorted(list(ejected_set)))
        apply_group_settings(context, self)
        return {'FINISHED'}
    
class ST_OT_RestoreEjectedSubgroup(bpy.types.Operator):
    bl_idname = "st.restore_ejected_subgroup"
    bl_label = "Restore Ejected TabsGroup"
    bl_options = {'REGISTER'}
    subgroup_full_name: bpy.props.StringProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        ejected_set = {s.strip() for s in prefs.ejected_subgroups.split(',') if s.strip()}
        ejected_set.discard(self.subgroup_full_name)
        prefs.ejected_subgroups = ", ".join(sorted(list(ejected_set)))
        apply_group_settings(context, self)
        return {'FINISHED'}
    
class ST_OT_ToggleItemVisibility(bpy.types.Operator):
    bl_idname = "st.toggle_item_visibility"
    bl_label = "Toggle Item Visibility"
    bl_options = {'REGISTER'}
    item_string: bpy.props.StringProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        hidden_set = {s.strip() for s in prefs.hidden_items.split(',') if s.strip()}
        if self.item_string in hidden_set:
            hidden_set.remove(self.item_string)
        else:
            hidden_set.add(self.item_string)
        prefs.hidden_items = ", ".join(sorted(list(hidden_set)))
        apply_group_settings(context, self)
        return {'FINISHED'}
    
class ST_OT_ToggleSubgroupVisibility(bpy.types.Operator):
    """Hide TabsGroup in Supertabs N-panel"""
    bl_idname = "st.toggle_subgroup_visibility"
    bl_label = "Toggle TabsGroup Visibility"
    bl_options = {'REGISTER'}
    subgroup_full_name: bpy.props.StringProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        subgroup_to_check = next((g for g in prefs.tab_groups if g.name == self.subgroup_full_name), None)
        if subgroup_to_check:
            items_set = {item.strip() for item in subgroup_to_check.items.split(',') if item.strip()}
            ejected_items_set = {item.strip() for item in prefs.temporarily_ejected_items.split(',') if item.strip()}

            if not items_set.isdisjoint(ejected_items_set):
                self.report({'WARNING'}, "Cannot hide a subgroup that contains ejected items.")
                return {'CANCELLED'}
            
        hidden_set = {s.strip() for s in prefs.hidden_subgroups.split(',') if s.strip()}
        if self.subgroup_full_name in hidden_set:
            hidden_set.remove(self.subgroup_full_name)
        else:
            hidden_set.add(self.subgroup_full_name)
        prefs.hidden_subgroups = ", ".join(sorted(list(hidden_set)))
        apply_group_settings(context, self)
        return {'FINISHED'}
    
class ST_OT_RestoreHiddenItem(bpy.types.Operator):
    bl_idname = "st.restore_hidden_item"
    bl_label = "Restore Hidden Item"
    bl_options = {'REGISTER'}
    item_string: bpy.props.StringProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        hidden_set = {s.strip() for s in prefs.hidden_items.split(',') if s.strip()}
        hidden_set.discard(self.item_string)
        prefs.hidden_items = ", ".join(sorted(list(hidden_set)))
        apply_group_settings(context, self)
        return {'FINISHED'}
    
class ST_OT_RestoreHiddenSubgroup(bpy.types.Operator):
    """Restore Hidden TabsGroup"""
    bl_idname = "st.restore_hidden_subgroup"
    bl_label = "Restore Hidden TabsGroup"
    bl_options = {'REGISTER'}
    subgroup_full_name: bpy.props.StringProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        hidden_set = {s.strip() for s in prefs.hidden_subgroups.split(',') if s.strip()}
        hidden_set.discard(self.subgroup_full_name)
        prefs.hidden_subgroups = ", ".join(sorted(list(hidden_set)))
        apply_group_settings(context, self)
        return {'FINISHED'}

class ST_OT_UnpinSpecificPresetItems(bpy.types.Operator):
    """Unpins all items from a *specific* favorite preset, respecting other pinned presets."""
    bl_idname = "st.unpin_specific_preset_items"
    bl_label = "Unpin Preset Items"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    preset_name: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            self.report({'WARNING'}, "Group state not found.")
            return {'CANCELLED'}

        target_preset = next((p for p in state.favorite_presets if p.name == self.preset_name), None)
        
        if not target_preset or not target_preset.items:
            self.report({'INFO'}, f"Preset '{self.preset_name}' is empty or not found.")
            return {'CANCELLED'}

        items_to_unpin_set = {item.strip() for item in target_preset.items.split(',') if item.strip()}
        
        if not items_to_unpin_set:
            self.report({'INFO'}, "Preset is empty.")
            return {'CANCELLED'}

        pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}
        
        items_to_keep_pinned = set()

        for preset in state.favorite_presets:
            if preset.name == self.preset_name:
                continue
            
            preset_items = {item.strip() for item in preset.items.split(',') if item.strip()}
            if not preset_items:
                continue

            if preset_items.issubset(pinned_set):
                items_to_keep_pinned.update(preset_items)

        items_that_can_be_unpinned = items_to_unpin_set.difference(items_to_keep_pinned)
        
        if not items_that_can_be_unpinned:
            self.report({'INFO'}, f"Items in '{self.preset_name}' are also pinned by other presets. Nothing to unpin.")
            return {'CANCELLED'}

        pinned_set.difference_update(items_that_can_be_unpinned)
        state.pinned_items = ", ".join(sorted(list(pinned_set)))
        
        if state.active_item in items_that_can_be_unpinned:
            state.active_item = ""

        self.report({'INFO'}, f"Unpinned {len(items_that_can_be_unpinned)} items from '{self.preset_name}'.")

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}

class ST_OT_UnpinAllPresets(bpy.types.Operator):
    """Unpins all items from all favorite presets."""
    bl_idname = "st.unpin_all_presets"
    bl_label = "Unpin All Presets"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            self.report({'WARNING'}, "Group state not found.")
            return {'CANCELLED'}

        state.pinned_items = ""
        state.active_item = ""

        self.report({'INFO'}, "Unpinned all items.")

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}
    
classes = (
    ST_OT_PinAllFavorites,
    ST_OT_UnpinAllFavorites,
    ST_OT_UnpinSpecificPresetItems,
    ST_OT_UnpinAllPresets,
    ST_OT_TogglePinItem,
    ST_OT_RegroupItem,
    ST_OT_EjectItem,
    ST_OT_EjectSubgroup,
    ST_OT_RestoreEjectedSubgroup,
    ST_OT_ToggleSubgroupVisibility,
    ST_OT_RestoreHiddenSubgroup,
    ST_OT_ToggleItemVisibility,
    ST_OT_RestoreHiddenItem,
)