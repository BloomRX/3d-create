import bpy
import os
import json
import addon_utils
from bpy_extras.io_utils import ImportHelper, ExportHelper
from ..core import execute_import_from_file
from ..utils import get_all_addons

def collect_export_data(context, config):
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    settings_to_export = {}

    def get_cfg(attr):
        return getattr(config, attr, True)

    if get_cfg("export_pinned_states"):
        pinned_states = {}
        if hasattr(context.window_manager, "tab_group_states"):
            for state in context.window_manager.tab_group_states:
                if state.pinned_items or state.active_item:
                    pinned_states[state.name] = {
                    "active_item": state.active_item,
                    "pinned_items": state.pinned_items
                }
        if pinned_states:
            settings_to_export["pinned_states"] = pinned_states

    if get_cfg("export_expansion_states"):
        panel_expansion_states = {}
        if hasattr(context.window_manager, "tab_group_states"):
            for state in context.window_manager.tab_group_states:
                panel_expansion_states[state.name] = {
                    "show_favorites_panel": state.show_favorites_panel,
                    "show_favorite_nodes_panel": state.show_favorite_nodes_panel,
                    "show_groupaddons_panel": state.show_groupaddons_panel,
                    "show_windoweditor_panel": state.show_windoweditor_panel,
                    "panel_manager": state.panel_manager,
                    "show_subgroup_icons": state.show_subgroup_icons,
                    "show_favorite_icons": state.show_favorite_icons
                }
        if panel_expansion_states:
            settings_to_export["panel_expansion_states"] = panel_expansion_states

    if get_cfg("export_column_layouts"):
        column_layout_data = {}
        if hasattr(context.window_manager, "tab_group_states"):
            for state in context.window_manager.tab_group_states:
                state_data = {
                    "subgroup_columns": state.subgroup_columns,
                    "item_columns": state.item_columns,
                    "subgroup_specific_columns": {}
                }
                for sub_data in state.subgroup_column_data:
                    state_data["subgroup_specific_columns"][sub_data.name] = sub_data.item_columns
                column_layout_data[state.name] = state_data
        if column_layout_data:
            settings_to_export["column_layout_data"] = column_layout_data
            
    if get_cfg("export_visibility_settings"):
        settings_to_export["temporarily_ejected_items"] = prefs.temporarily_ejected_items
        settings_to_export["ejected_subgroups"] = prefs.ejected_subgroups
        settings_to_export["hidden_subgroups"] = prefs.hidden_subgroups
        settings_to_export["hidden_items"] = prefs.hidden_items
        settings_to_export["hidden_panels"] = [item.panel_id for item in prefs.hidden_panels]

    if prefs.export_favorite_presets:
        favorite_preset_states = {}
        active_preset_map = {}
        if hasattr(context.window_manager, "tab_group_states"):
            for state in context.window_manager.tab_group_states:
                active_preset_map[state.name] = state.active_favorite_preset_name
        for preset in prefs.custom_favorite_presets:
            group_name = preset.main_group_name
            if not group_name: continue
            if group_name not in favorite_preset_states:
                favorite_preset_states[group_name] = {
                    "active_preset": active_preset_map.get(group_name, ""),
                    "presets": []
                }
            favorite_preset_states[group_name]["presets"].append({
                "name": preset.name, "items": preset.items,
                "icon": preset.icon, "main_group_name": preset.main_group_name,
                "space_type": preset.space_type
            })
        if favorite_preset_states:
            settings_to_export["favorite_preset_states"] = favorite_preset_states

    if get_cfg("export_quick_shortcuts"):
        quick_shortcuts_data = []
        for item in prefs.quick_shortcuts:
            quick_shortcuts_data.append({
                "identifier": item.identifier,
                "display_name": item.display_name,
                "main_group_name": item.main_group_name,
                "icon": item.icon,
                "sub_group_name": item.sub_group_name,
                "space_type": item.space_type
            })
        if quick_shortcuts_data:
            settings_to_export["quick_shortcuts"] = quick_shortcuts_data
    
    if get_cfg("export_rcm_window_editors"):
        quick_menu_settings = {
            "enable_quick_shortcuts_rcm": prefs.enable_quick_shortcuts_rcm,
            "enable_quick_shortcuts_pie": prefs.enable_quick_shortcuts_pie,
            "enable_window_editors_pie": prefs.enable_window_editors_pie,
            "enable_window_editors_rcm": prefs.enable_window_editors_rcm,
            "rcm_show_window_editors": prefs.rcm_show_window_editors,
            # General
            "rcm_show_3Dview": prefs.rcm_show_3Dview,
            "rcm_show_image": prefs.rcm_show_image,
            "rcm_show_uv": prefs.rcm_show_uv,
            "rcm_show_geo": prefs.rcm_show_geo,
            "rcm_show_comp": prefs.rcm_show_comp,
            "rcm_show_shader": prefs.rcm_show_shader,
            "rcm_show_texture": prefs.rcm_show_texture,
            "rcm_show_sequence": prefs.rcm_show_sequence,
            "rcm_show_clip": prefs.rcm_show_clip,
            # Scripting
            "rcm_show_system_console": prefs.rcm_show_system_console,
            "rcm_show_text": prefs.rcm_show_text,
            "rcm_show_console": prefs.rcm_show_console,
            "rcm_show_info": prefs.rcm_show_info,
            "rcm_show_iconviewer": prefs.rcm_show_iconviewer,
            "rcm_show_serpen": prefs.rcm_show_serpen,
            # Animation
            "rcm_show_dopesheet": prefs.rcm_show_dopesheet,
            "rcm_show_timeline": prefs.rcm_show_timeline,
            "rcm_show_graph": prefs.rcm_show_graph,
            "rcm_show_drivers": prefs.rcm_show_drivers,
            "rcm_show_nla": prefs.rcm_show_nla,
            # Data
            "rcm_show_outliner": prefs.rcm_show_outliner,
            "rcm_show_props": prefs.rcm_show_props,
            "rcm_show_file": prefs.rcm_show_file,
            "rcm_show_spread": prefs.rcm_show_spread,
            "rcm_show_asset": prefs.rcm_show_asset,
        }
        settings_to_export["quick_menu_settings"] = quick_menu_settings

    if prefs.export_custom_names:
        settings_to_export["custom_item_names"] = [
            {"identifier": item.identifier, "display_name": item.display_name, "icon": item.icon}
            for item in prefs.custom_item_names
        ]

    if prefs.export_tab_groups:
        tab_groups_data = []
        for g in prefs.tab_groups:
            group_data = {"name": g.name,
                          "items": g.items,
                          "is_visible": g.is_visible,
                          "space_type": g.space_type,
                          "icon": g.icon
            }
            if get_cfg("export_expansion_states"):
                group_data["is_expanded"] = g.is_expanded
            tab_groups_data.append(group_data)
        
        settings_to_export["tab_groups"] = tab_groups_data
        settings_to_export["manage_item_tab"] = prefs.manage_item_tab
        settings_to_export["manage_tool_tab"] = prefs.manage_tool_tab
        settings_to_export["manage_view_tab"] = prefs.manage_view_tab
        settings_to_export["manage_edit_tab"] = prefs.manage_edit_tab
        settings_to_export["manage_uv_image_tab"] = prefs.manage_uv_image_tab
        settings_to_export["manage_uv_tool_tab"] = prefs.manage_uv_tool_tab
        settings_to_export["manage_uv_view_tab"] = prefs.manage_uv_view_tab
        settings_to_export["manage_uv_scope_tab"] = prefs.manage_uv_scope_tab
        settings_to_export["manage_node_options_tab"] = prefs.manage_node_options_tab
        settings_to_export["manage_node_tool_tab"] = prefs.manage_node_tool_tab
        settings_to_export["manage_node_view_tab"] = prefs.manage_node_view_tab
        settings_to_export["manage_node_node_tab"] = prefs.manage_node_node_tab
        settings_to_export["manage_node_group_tab"] = prefs.manage_node_group_tab
        settings_to_export["manual_exclude_tabs_node"] = prefs.manual_exclude_tabs_node
        settings_to_export["manual_exclude_tabs"] = prefs.manual_exclude_tabs
        settings_to_export["poll_method_exceptions"] = prefs.poll_method_exceptions

    if prefs.export_addon_presets:
        settings_to_export["addon_presets"] = [{"name": p.name, "addons": [a.name for a in p.addons]  }for p in prefs.addon_presets]
    if prefs.export_favorite_addons:
        settings_to_export["favorite_addons"] = [fav.name for fav in prefs.favorite_addons]
    if prefs.export_auto_import:
        settings_to_export["auto_import_enabled"] = prefs.auto_import_enabled
        
        if hasattr(config, 'filepath') and config.filepath:
             settings_to_export["auto_import_filepath"] = config.filepath
        else:
             settings_to_export["auto_import_filepath"] = prefs.auto_import_filepath
        settings_to_export["auto_import_delay"] = prefs.auto_import_delay

    # Favorite Nodes
    favorite_nodes_data = []
    for item in prefs.favorite_nodes:
        node_data = {
            "node_idname": item.node_idname,
            "label": item.label,
            "icon": item.icon,
            "tree_type": item.tree_type
        }

        if hasattr(item, "is_group") and item.is_group:
            node_data["is_group"] = True
            node_data["serialized_data"] = item.serialized_data
            
        favorite_nodes_data.append(node_data)

    settings_to_export["favorite_nodes"] = favorite_nodes_data
    
    if prefs.export_ui_layout:
        # Main Toggles
        settings_to_export["show_favorite_nodes_panel"] = prefs.show_favorite_nodes_panel
        settings_to_export["favorite_nodes_columns"] = prefs.favorite_nodes_columns
        # --- Original Settings ---
        settings_to_export["tab_list_display_rows"] = prefs.tab_list_display_rows
        settings_to_export["addon_list_columns"] = prefs.addon_list_columns
        # Main Toggles
        settings_to_export["show_basic_panel"] = prefs.show_basic_panel
        settings_to_export["show_quick_3d"] = prefs.show_quick_3d
        settings_to_export["show_quick_uv"] = prefs.show_quick_uv
        settings_to_export["show_basic_uv_buttons"] = prefs.show_basic_uv_buttons
        settings_to_export["show_editor_shortcuts_panel"] = prefs.show_editor_shortcuts_panel
        settings_to_export["show_asset_browser_button"] = prefs.show_asset_browser_button
        settings_to_export["hide_options_subgroups"] = prefs.hide_options_subgroups
        settings_to_export["hide_options_items"] = prefs.hide_options_items
        settings_to_export["show_guide"] = prefs.show_guide
        # Export UV Editor Sub-settings
        settings_to_export["show_uv_stretch"] = prefs.show_uv_stretch
        settings_to_export["show_uv_sync"] = prefs.show_uv_sync
        settings_to_export["show_uv_average_scale"] = prefs.show_uv_average_scale
        settings_to_export["show_uv_pack_islands"] = prefs.show_uv_pack_islands
        settings_to_export["show_uv_select_overlap"] = prefs.show_uv_select_overlap
        settings_to_export["show_header_image_only"] = prefs.show_header_image_only
        settings_to_export["show_quick_image"] = prefs.show_quick_image
        settings_to_export["show_basic_image_buttons"] = prefs.show_basic_image_buttons
        settings_to_export["show_image_selector"] = prefs.show_image_selector
        # Basic Panel Toggles
        settings_to_export["show_transform_section"] = prefs.show_transform_section
        settings_to_export["show_object_name_row"] = prefs.show_object_name_row
        settings_to_export["show_curve_section"] = prefs.show_curve_section
        settings_to_export["show_normal_section"] = prefs.show_normal_section
        settings_to_export["show_view_section"] = prefs.show_view_section
        settings_to_export["show_edit_section"] = prefs.show_edit_section
        # Edit Panel Sub-toggles
        settings_to_export["show_aligndis_props"] = prefs.show_aligndis_props
        settings_to_export["show_align_location"] = prefs.show_align_location
        settings_to_export["show_align_rotaion"] = prefs.show_align_rotaion
        settings_to_export["show_align_scale"] = prefs.show_align_scale
        settings_to_export["show_distribute"] = prefs.show_distribute
        settings_to_export["show_booltool_props"] = prefs.show_booltool_props
        settings_to_export["show_auto_bool"] = prefs.show_auto_bool
        settings_to_export["show_Brush_bool"] = prefs.show_Brush_bool
        settings_to_export["show_looptools_props"] = prefs.show_looptools_props
        settings_to_export["show_bridge_loop"] = prefs.show_bridge_loop
        settings_to_export["show_circle_loop"] = prefs.show_circle_loop
        settings_to_export["show_curve_loop"] = prefs.show_curve_loop
        settings_to_export["show_flastten_loop"] = prefs.show_flastten_loop
        settings_to_export["show_gstretch_loop"] = prefs.show_gstretch_loop
        settings_to_export["show_loft_loop"] = prefs.show_loft_loop
        settings_to_export["show_relax_loop"] = prefs.show_relax_loop
        settings_to_export["show_space_loop"] = prefs.show_space_loop
        # Quick Section Sub-toggles
        settings_to_export["show_statics_button"] = prefs.show_statics_button
        settings_to_export["show_faceorien_button"] = prefs.show_faceorien_button
        settings_to_export["show_lockcamera_button"] = prefs.show_lockcamera_button
        settings_to_export["show_anno_3d_button"] = prefs.show_anno_3d_button
        settings_to_export["show_anno_image_button"] = prefs.show_anno_image_button
        settings_to_export["show_anno_node_button"] = prefs.show_anno_node_button
        settings_to_export["show_mesh_edit_overlay_button"] = prefs.show_mesh_edit_overlay_button
        settings_to_export["show_viewportshading_button"] = prefs.show_viewportshading_button
        # settings_to_export["show_cleandata_button"] = prefs.show_cleandata_button
        settings_to_export["show_cleandata_3Dview_button"] = prefs.show_cleandata_3Dview_button
        settings_to_export["show_cleandata_image_button"] = prefs.show_cleandata_image_button
        settings_to_export["show_cleandata_nodes_button"] = prefs.show_cleandata_nodes_button
        settings_to_export["show_render_button"] = prefs.show_render_button
        # Window Editor Sub-toggles
        settings_to_export["show_general"] = prefs.show_general
        settings_to_export["show_3Dview"] = prefs.show_3Dview
        settings_to_export["show_image"] = prefs.show_image
        settings_to_export["show_uv"] = prefs.show_uv
        settings_to_export["show_shader"] = prefs.show_shader
        settings_to_export["show_geo"] = prefs.show_geo
        settings_to_export["show_comp"] = prefs.show_comp
        settings_to_export["show_texture"] = prefs.show_texture
        settings_to_export["show_sequence"] = prefs.show_sequence
        settings_to_export["show_clip"] = prefs.show_clip
        settings_to_export["show_scripting"] = prefs.show_scripting
        settings_to_export["show_text"] = prefs.show_text
        settings_to_export["show_console"] = prefs.show_console
        settings_to_export["show_info"] = prefs.show_info
        settings_to_export["show_system_console"] = prefs.show_system_console
        settings_to_export["show_serpen"] = prefs.show_serpen
        settings_to_export["show_animation"] = prefs.show_animation
        settings_to_export["show_dopesheet"] = prefs.show_dopesheet
        settings_to_export["show_timeline"] = prefs.show_timeline
        settings_to_export["show_graph"] = prefs.show_graph
        settings_to_export["show_drivers"] = prefs.show_drivers
        settings_to_export["show_nla"] = prefs.show_nla
        settings_to_export["show_data"] = prefs.show_data
        settings_to_export["show_outliner"] = prefs.show_outliner
        settings_to_export["show_props"] = prefs.show_props
        settings_to_export["show_file"] = prefs.show_file
        settings_to_export["show_spread"] = prefs.show_spread
        settings_to_export["show_preferences"] = prefs.show_preferences
        # Shading
        settings_to_export["st_node_cols_shading"] = prefs.st_node_cols_shading
        settings_to_export["st_node_fav_shading"] = prefs.st_node_fav_shading
        settings_to_export["st_node_opt_shading"] = prefs.st_node_opt_shading
        settings_to_export["st_node_manager_shading"] = prefs.st_node_manager_shading
        # Geometry
        settings_to_export["st_node_cols_geometry"] = prefs.st_node_cols_geometry
        settings_to_export["st_node_fav_geometry"] = prefs.st_node_fav_geometry
        settings_to_export["st_node_opt_geometry"] = prefs.st_node_opt_geometry
        settings_to_export["st_node_manager_geometry"] = prefs.st_node_manager_geometry
        # Compositor
        settings_to_export["st_node_cols_compositor"] = prefs.st_node_cols_compositor
        settings_to_export["st_node_fav_compositor"] = prefs.st_node_fav_compositor
        settings_to_export["st_node_opt_compositor"] = prefs.st_node_opt_compositor
        settings_to_export["st_node_manager_compositor"] = prefs.st_node_manager_compositor
        # Texture
        settings_to_export["st_node_cols_texture"] = prefs.st_node_cols_texture
        settings_to_export["st_node_fav_texture"] = prefs.st_node_fav_texture
        settings_to_export["st_node_opt_texture"] = prefs.st_node_opt_texture
        settings_to_export["st_node_manager_texture"] = prefs.st_node_manager_texture
        # Favorite Nodes Panel Sub-toggles
        settings_to_export["st_node_show_fav_nodes_shading"] = prefs.st_node_show_fav_nodes_shading
        settings_to_export["st_node_show_fav_nodes_geometry"] = prefs.st_node_show_fav_nodes_geometry
        settings_to_export["st_node_show_fav_nodes_compositor"] = prefs.st_node_show_fav_nodes_compositor
        settings_to_export["st_node_show_fav_nodes_texture"] = prefs.st_node_show_fav_nodes_texture
        # Node Editor Quick Tools & Toggles
        settings_to_export["show_quick_node"] = prefs.show_quick_node
        settings_to_export["show_geo_zoom_buttons"] = prefs.show_geo_zoom_buttons
        # Node Editor Quick Tools Sub-toggles
        settings_to_export["show_node_stats_button"] = prefs.show_node_stats_button
        settings_to_export["show_geo_align_button"] = prefs.show_geo_align_button
        settings_to_export["show_anno_node_button"] = prefs.show_anno_node_button
        settings_to_export["show_view_home_button"] = prefs.show_view_home_button
        settings_to_export["show_geo_timing_button"] = prefs.show_geo_timing_button
        settings_to_export["show_geo_named_attribute_button"] = prefs.show_geo_named_attribute_button
        settings_to_export["show_image_resize"] = prefs.show_image_resize
        settings_to_export["show_image_replace"] = prefs.show_image_replace
        settings_to_export["show_external_edit"] = prefs.show_external_edit
        settings_to_export["show_save_all_image"] = prefs.show_save_all_image
        settings_to_export["show_save_as_copy"] = prefs.show_save_as_copy
        # External Data
        settings_to_export["show_external_data"] = prefs.show_external_data
        settings_to_export["auto_pack_toggle"] = prefs.auto_pack_toggle
        settings_to_export["toggle_pack_resources"] = prefs.toggle_pack_resources
        settings_to_export["toggle_pack_linked"] = prefs.toggle_pack_linked
        settings_to_export["toggle_make_path"] = prefs.toggle_make_path
        settings_to_export["toggle_missing_files"] = prefs.toggle_missing_files
        # UV Tools
        settings_to_export["show_reset_uv"] = prefs.show_reset_uv
        settings_to_export["show_export_uv"] = prefs.show_export_uv
        settings_to_export["show_live_unwrap"] = prefs.show_live_unwrap
        # Node Tools
        settings_to_export["show_collapse_socket_button"] = prefs.show_collapse_socket_button
        # Node Quick Section (Per Tree)
        settings_to_export["st_node_quick_geometry"] = prefs.st_node_quick_geometry
        settings_to_export["st_node_quick_shading"] = prefs.st_node_quick_shading
        settings_to_export["st_node_quick_compositor"] = prefs.st_node_quick_compositor
        settings_to_export["st_node_quick_texture"] = prefs.st_node_quick_texture
        # Node Zoom Section (Per Tree)
        settings_to_export["st_node_zoom_geometry"] = prefs.st_node_zoom_geometry
        settings_to_export["st_node_zoom_shading"] = prefs.st_node_zoom_shading
        settings_to_export["st_node_zoom_compositor"] = prefs.st_node_zoom_compositor
        settings_to_export["st_node_zoom_texture"] = prefs.st_node_zoom_texture

    if prefs.export_hotkey:
        # Manager Hotkey
        settings_to_export["manager_hotkey_enabled"] = prefs.manager_hotkey_enabled
        settings_to_export["hotkey_ctrl"] = prefs.hotkey_ctrl
        settings_to_export["hotkey_alt"] = prefs.hotkey_alt
        settings_to_export["hotkey_shift"] = prefs.hotkey_shift
        settings_to_export["hotkey_key"] = prefs.hotkey_key
        
        # Asset Browser Hotkey
        settings_to_export["asset_browser_hotkey_enabled"] = prefs.asset_browser_hotkey_enabled
        settings_to_export["asset_browser_hotkey_ctrl"] = prefs.asset_browser_hotkey_ctrl
        settings_to_export["asset_browser_hotkey_alt"] = prefs.asset_browser_hotkey_alt
        settings_to_export["asset_browser_hotkey_shift"] = prefs.asset_browser_hotkey_shift
        settings_to_export["asset_browser_hotkey_key"] = prefs.asset_browser_hotkey_key
        
        # Split/Join View Hotkey
        settings_to_export["split_join_hotkey_enabled"] = prefs.split_join_hotkey_enabled
        settings_to_export["split_join_hotkey_ctrl"] = prefs.split_join_hotkey_ctrl
        settings_to_export["split_join_hotkey_alt"] = prefs.split_join_hotkey_alt
        settings_to_export["split_join_hotkey_shift"] = prefs.split_join_hotkey_shift
        settings_to_export["split_join_hotkey_key"] = prefs.split_join_hotkey_key
        
        # Pie Menu Hotkey
        settings_to_export["pie_menu_hotkey_enabled"] = prefs.pie_menu_hotkey_enabled
        settings_to_export["pie_menu_hotkey_ctrl"] = prefs.pie_menu_hotkey_ctrl
        settings_to_export["pie_menu_hotkey_alt"] = prefs.pie_menu_hotkey_alt
        settings_to_export["pie_menu_hotkey_shift"] = prefs.pie_menu_hotkey_shift
        settings_to_export["pie_menu_hotkey_key"] = prefs.pie_menu_hotkey_key
        
        # Right-Click Integration Settings
        settings_to_export["right_click_mode"] = prefs.right_click_mode
        settings_to_export["right_click_menu_position"] = prefs.right_click_menu_position

        # --- Headers ---
        settings_to_export["show_header_3d"] = prefs.show_header_3d
        settings_to_export["show_header_nodes"] = prefs.show_header_nodes
        settings_to_export["show_header_image"] = prefs.show_header_image
        settings_to_export["st_node_header_shading"] = prefs.st_node_header_shading
        settings_to_export["st_node_header_geometry"] = prefs.st_node_header_geometry
        settings_to_export["st_node_header_compositor"] = prefs.st_node_header_compositor
        settings_to_export["st_node_header_texture"] = prefs.st_node_header_texture

        settings_to_export["st_node_expand_fav_geometry"] = prefs.st_node_expand_fav_geometry
        settings_to_export["st_node_expand_fav_shading"] = prefs.st_node_expand_fav_shading
        settings_to_export["st_node_expand_fav_compositor"] = prefs.st_node_expand_fav_compositor
        settings_to_export["st_node_expand_fav_texture"] = prefs.st_node_expand_fav_texture

        settings_to_export["st_node_fav_cols_geometry"] = prefs.st_node_fav_cols_geometry
        settings_to_export["st_node_fav_cols_shading"] = prefs.st_node_fav_cols_shading
        settings_to_export["st_node_fav_cols_compositor"] = prefs.st_node_fav_cols_compositor
        settings_to_export["st_node_fav_cols_texture"] = prefs.st_node_fav_cols_texture

        settings_to_export["st_node_stats_geometry"] = prefs.st_node_stats_geometry
        settings_to_export["st_node_stats_shading"] = prefs.st_node_stats_shading
        settings_to_export["st_node_stats_compositor"] = prefs.st_node_stats_compositor
        settings_to_export["st_node_stats_texture"] = prefs.st_node_stats_texture

        settings_to_export["st_node_align_geometry"] = prefs.st_node_align_geometry
        settings_to_export["st_node_align_shading"] = prefs.st_node_align_shading
        settings_to_export["st_node_align_compositor"] = prefs.st_node_align_compositor
        settings_to_export["st_node_align_texture"] = prefs.st_node_align_texture
        
        settings_to_export["st_node_anno_geometry"] = prefs.st_node_anno_geometry
        settings_to_export["st_node_anno_shading"] = prefs.st_node_anno_shading
        settings_to_export["st_node_anno_compositor"] = prefs.st_node_anno_compositor
        settings_to_export["st_node_anno_texture"] = prefs.st_node_anno_texture

        settings_to_export["node_align_buttons"] = prefs.node_align_buttons
        settings_to_export["node_distribute_buttons"] = prefs.node_distribute_buttons
        settings_to_export["node_rotate_buttons"] = prefs.node_rotate_buttons

        # --- Edit Section Toggles ---
        settings_to_export["show_align_advanced"] = prefs.show_align_advanced
        # --- Node Editor States ---
        settings_to_export["show_node_stats_panel"] = prefs.show_node_stats_panel
        settings_to_export["show_node_align_panel"] = prefs.show_node_align_panel
        settings_to_export["show_node_fav_options"] = prefs.show_node_fav_options
        settings_to_export["toggle_fav_remove_buttons"] = prefs.toggle_fav_remove_buttons
        # --- Annotation Panels State ---
        settings_to_export["show_annotations_3dview"] = prefs.show_annotations_3dview
        settings_to_export["show_annotations_image"] = prefs.show_annotations_image
        settings_to_export["show_annotations_nodes"] = prefs.show_annotations_nodes
        # --- Basic Panels Expansion States ---
        settings_to_export["show_transform_panel"] = prefs.show_transform_panel
        settings_to_export["show_view_panel"] = prefs.show_view_panel
        settings_to_export["show_edit_panel"] = prefs.show_edit_panel
        settings_to_export["show_normal_panel"] = prefs.show_normal_panel
        settings_to_export["show_curve_panel"] = prefs.show_curve_panel

    manager_ui_settings = {
        # 3D View
        "show_manager_header_3d": prefs.show_manager_header_3d,
        "show_fav_panel_3d": prefs.show_fav_panel_3d,
        "show_groups_panel_3d": prefs.show_groups_panel_3d,
        "show_collapse_all_3d": prefs.show_collapse_all_3d,
        # Image Editor
        "show_manager_header_image": prefs.show_manager_header_image,
        "show_fav_panel_image": prefs.show_fav_panel_image,
        "show_groups_panel_image": prefs.show_groups_panel_image,
        "show_collapse_all_image": prefs.show_collapse_all_image,
        # Image Editor Only
        "show_manager_header_image_only": prefs.show_manager_header_image_only,
        "show_fav_panel_image_only": prefs.show_fav_panel_image_only,
        "show_groups_panel_image_only": prefs.show_groups_panel_image_only,
        "show_collapse_all_image_only": prefs.show_collapse_all_image_only,
        # Shading Editors
        "show_manager_header_shading": getattr(prefs, "show_manager_header_shading", True),
        "show_fav_panel_shading": getattr(prefs, "show_fav_panel_shading", True),
        "show_groups_panel_shading": getattr(prefs, "show_groups_panel_shading", True),
        "show_collapse_all_shading": getattr(prefs, "show_collapse_all_shading", False),
        # Geometry Editors
        "show_manager_header_geometry": getattr(prefs, "show_manager_header_geometry", True),
        "show_fav_panel_geometry": getattr(prefs, "show_fav_panel_geometry", True),
        "show_groups_panel_geometry": getattr(prefs, "show_groups_panel_geometry", True),
        "show_collapse_all_geometry": getattr(prefs, "show_collapse_all_geometry", False),
        # Texture Editors
        "show_manager_header_texture": getattr(prefs, "show_manager_header_texture", True),
        "show_fav_panel_texture": getattr(prefs, "show_fav_panel_texture", True),
        "show_groups_panel_texture": getattr(prefs, "show_groups_panel_texture", True),
        "show_collapse_all_texture": getattr(prefs, "show_collapse_all_texture", False),
        # Compositing Editors
        "show_manager_header_compositor": getattr(prefs, "show_manager_header_compositor", True),
        "show_fav_panel_compositor": getattr(prefs, "show_fav_panel_compositor", True),
        "show_groups_panel_compositor": getattr(prefs, "show_groups_panel_compositor", True),
        "show_collapse_all_compositor": getattr(prefs, "show_collapse_all_compositor", False),
    }
    
    settings_to_export["manager_ui_settings"] = manager_ui_settings

    return settings_to_export

class TABGROUP_OT_ExportSettings(bpy.types.Operator, ExportHelper):
    """Export Setting as JSON File"""
    bl_idname = "tab_group.export_settings"
    bl_label = "Export"
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})

    export_visibility_settings: bpy.props.BoolProperty(name="Visibility & Ejection States", default=True)
    export_expansion_states: bpy.props.BoolProperty(name="Expansion States", default=True)
    export_pinned_states: bpy.props.BoolProperty(name="Pinned States", default=True)
    export_column_layouts: bpy.props.BoolProperty(name="Column Layouts", default=True)
    export_quick_shortcuts: bpy.props.BoolProperty(name="Quick Shortcuts (RCM/Pie)", default=True)
    export_rcm_window_editors: bpy.props.BoolProperty(name="Window Editors (RCM/Pie)", default=True)
    def draw(self, context):
        """Draw the export options in the file browser sidebar."""
        layout = self.layout
        box = layout.box()

        box.label(text="Supertabs Export Settings:")
        
        col = box.column(align=True)
        col.prop(self, "export_visibility_settings")
        col.prop(self, "export_expansion_states")
        col.prop(self, "export_pinned_states")
        col.prop(self, "export_column_layouts")
        # col.separator()
        # col.label(text="RCM / Pie Menu Export:")
        # col.prop(self, "export_quick_shortcuts")
        # col.prop(self, "export_rcm_window_editors")
        
    def execute(self, context):
        if not self.filepath: return {"CANCELLED"}
        settings_to_export = collect_export_data(context, self)
        
        try:
            with open(self.filepath, "w", encoding="utf-8") as f: 
                json.dump(settings_to_export, f, indent=4)
            
            prefs = context.preferences.addons[__package__.split('.')[0]].preferences
            prefs.last_used_path = os.path.dirname(self.filepath)
            message = f"Exported to {os.path.basename(self.filepath)}"
            self.report({"INFO"}, message)
            bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='SUCCESS')
        except Exception as e: 
            message = f"Export failed: {e}"
            self.report({"ERROR"}, message)
            bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='ERROR')
        return {"FINISHED"}
    
    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        default_filename = "SUPERTABs_Settings.json"
        if prefs.last_used_path and os.path.isdir(prefs.last_used_path):
            self.filepath = os.path.join(prefs.last_used_path, default_filename)
        else:
            self.filepath = default_filename
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

class TABGROUP_OT_QuickExport(bpy.types.Operator):
    """Quickly export settings to the currently active auto-import file"""
    bl_idname = "tab_group.quick_export"
    bl_label = "Quick Export"
    bl_description = "Export settings to the current Auto-Import file path"

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        filepath = prefs.auto_import_filepath
        
        if not filepath:
            self.report({"ERROR"}, "No Auto-Import file path set. Please use Export Settings first.")
            return {"CANCELLED"}
        
        if not os.path.isdir(os.path.dirname(filepath)):
             self.report({"ERROR"}, f"Invalid directory: {os.path.dirname(filepath)}")
             return {"CANCELLED"}

        settings_to_export = collect_export_data(context, prefs)

        try:
            with open(filepath, "w", encoding="utf-8") as f: 
                json.dump(settings_to_export, f, indent=4)
            
            prefs.last_used_path = os.path.dirname(filepath)
            message = f"Quick Exported to {os.path.basename(filepath)}"
            self.report({"INFO"}, message)
            bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='SUCCESS')
        except Exception as e: 
            message = f"Quick Export failed: {e}"
            self.report({"ERROR"}, message)
            bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='ERROR')
            return {"CANCELLED"}

        return {"FINISHED"}
    
class TABGROUP_OT_ImportSettings(bpy.types.Operator, ImportHelper):
    """Import Setting JSON File"""
    bl_idname = "tab_group.import_settings"
    bl_label = "Import"
    filepath: bpy.props.StringProperty(subtype="FILE_PATH")
    filename_ext = ".json"
    filter_glob: bpy.props.StringProperty(default="*.json", options={'HIDDEN'})
    def execute(self, context):
        if not self.filepath:
            return {"CANCELLED"}
        should_apply = context.preferences.addons[__package__.split('.')[0]].preferences.auto_apply_after_import
        if execute_import_from_file(context, self.filepath, apply_settings_now=should_apply, operator_instance=self):
            return {"FINISHED"}
        else:
            return {"CANCELLED"}
    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if prefs.last_used_path and os.path.isdir(prefs.last_used_path):
            self.filepath = os.path.join(prefs.last_used_path, "")
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

class ST_OT_ExportInstalledAddons(bpy.types.Operator, ExportHelper):
    """Export the list of all installed addons to a JSON or TXT file"""
    bl_idname = "st.export_installed_addons"
    bl_label = "Export Installed Addon List"

    filename_ext = ".json"

    filter_glob: bpy.props.StringProperty(
        default="*.json;*.txt",
        options={'HIDDEN'},
    )

    file_format: bpy.props.EnumProperty(
        name="File Format",
        description="Choose the export file format",
        items=[
            ('JSON', ".json", "Export as JSON"),
            ('TXT', ".txt", "Export as TXT"),
        ],
        default='TXT',
    )
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Installed Addon List File Format:")
        box.prop(self,"file_format")
    def execute(self, context):
        all_addons_data = get_all_addons()
        data_to_export = []
        for item in all_addons_data:
            mod_name = item['mod_name']
            display_name = item['display_name']
            is_enabled, _ = addon_utils.check(mod_name) 
            data_to_export.append({"name": display_name, "enabled": is_enabled})
        data_to_export.sort(key=lambda x: x['name'])
        filepath = self.filepath
        _filename, extension = os.path.splitext(filepath)
        
        if self.file_format == 'JSON':
            if extension.lower() != '.json':
                filepath = _filename + '.json'
        elif self.file_format == 'TXT':
            if extension.lower() != '.txt':
                filepath = _filename + '.txt'
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                if self.file_format == 'JSON':
                    json.dump(data_to_export, f, indent=4, ensure_ascii=False)
                
                elif self.file_format == 'TXT':
                    f.write("Installed Blender Add-ons (with state):\n")
                    f.write("=========================================\n")
                    for item in data_to_export:
                        status_marker = "[X]" if item['enabled'] else "[ ]"
                        f.write(f"- {status_marker} {item['name']}\n")

            message = f"Exported {len(data_to_export)} addons to {os.path.basename(filepath)}"
            self.report({'INFO'}, message)
            bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='SUCCESS')

        except Exception as e:
            message = f"Export failed: {e}"
            self.report({'ERROR'}, message)
            bpy.ops.st.set_status_message('INVOKE_DEFAULT', message=message, type='ERROR')
            return {'CANCELLED'}
        
        return {'FINISHED'}

    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        default_filename = "blender_addon_list" 
        if prefs.last_used_path and os.path.isdir(prefs.last_used_path):
            self.filepath = os.path.join(prefs.last_used_path, default_filename)
        else:
            self.filepath = default_filename
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

class ST_OT_LoadAddonStates(bpy.types.Operator):
    """Load and Apply Addon States from JSON file (Support Display Name)"""
    bl_idname = "st.load_addon_states"
    bl_label = "Recover Addon States"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        filepath = prefs.addon_state_filepath

        if not filepath or not os.path.exists(filepath):
            self.report({'ERROR'}, "File not found!")
            return {'CANCELLED'}

        try:
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
            
            if not isinstance(data, list):
                 self.report({'ERROR'}, "JSON format invalid (Expected List)")
                 return {'CANCELLED'}

            display_to_module = {}
            for mod in addon_utils.modules():
                info = addon_utils.module_bl_info(mod)
                d_name = info.get('name')
                if d_name:
                    display_to_module[d_name] = mod.__name__

            count_enabled = 0
            count_disabled = 0
            count_not_found = 0

            for item in data:
                name_in_json = item.get('name') # Display Name from JSON
                should_enable = item.get('enabled') # True/False

                target_mod_name = display_to_module.get(name_in_json)
                
                if not target_mod_name:
                    try:
                        if addon_utils.check(name_in_json)[1]: 
                            target_mod_name = name_in_json
                    except:
                        pass

                if target_mod_name:
                    is_loaded, is_installed = addon_utils.check(target_mod_name)
                    
                    try:
                        if should_enable:
                            if not is_loaded:
                                addon_utils.enable(target_mod_name, default_set=True)
                                count_enabled += 1
                        else:
                            if is_loaded:
                                addon_utils.disable(target_mod_name, default_set=True)
                                count_disabled += 1
                    except Exception as e:
                        print(f"Error toggling {target_mod_name}: {e}")
                else:
                    # Warning: Addon not found in the console
                    print(f"[SUPERTABs] Addon not found/installed: {name_in_json}")
                    count_not_found += 1

            self.report({'INFO'}, f"Updated! Enabled: {count_enabled}, Disabled: {count_disabled}, Skipped: {count_not_found}")
            
        except Exception as e:
            self.report({'ERROR'}, f"Error processing JSON: {e}")
            return {'CANCELLED'}

        return {'FINISHED'}

class ST_OT_DisableAllAddons(bpy.types.Operator):
    """Disable ALL enabled addons (Except this manager)"""
    bl_idname = "st.disable_all_addons"
    bl_label = "Disable ALL Addons"
    bl_description = "WARNING: This will disable ALL addons except SUPERTABs. Use with caution."
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        import addon_utils
        
        my_package = __package__.split('.')[0]
        
        count = 0
        for mod in addon_utils.modules():
            mod_name = mod.__name__
            is_enabled, _ = addon_utils.check(mod_name)
            
            if is_enabled and mod_name != my_package:
                try:
                    addon_utils.disable(mod_name, default_set=True)
                    count += 1
                except Exception as e:
                    print(f"Failed to disable {mod_name}: {e}")
        
        self.report({'INFO'}, f"Disabled {count} addons. Clean slate!")
        return {'FINISHED'}
    
classes = (
    ST_OT_LoadAddonStates,
    ST_OT_DisableAllAddons,
    TABGROUP_OT_ExportSettings,
    TABGROUP_OT_QuickExport,
    TABGROUP_OT_ImportSettings,
    ST_OT_ExportInstalledAddons,
)