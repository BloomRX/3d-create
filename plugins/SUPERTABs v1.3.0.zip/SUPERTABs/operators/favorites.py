import bpy
import addon_utils
from ..properties import _restricted_node_socket_icons

def get_main_group_items(self, context):
    """Create dynamic Main Group entries (SuperTabs) for an EnumProperty"""
    prefs = context.preferences.addons[__package__.split('.')[0]].preferences
    main_groups = []

    main_group_names = set()
    for group in prefs.tab_groups:
        main_name = group.name.split(" / ")[0]
        if main_name:
            main_group_names.add(main_name)

    if not main_group_names:
        return [("NONE", "No Main Groups Found", "", "ERROR", 0)]

    items = [(name, name, f"Assign to {name}") for name in sorted(list(main_group_names))]
    return items
class ST_OT_AssignOrphanPreset(bpy.types.Operator):
    """(SUPERTABs) Move orphaned presets (those without a group) into the selected Main Group"""
    bl_idname = "st.assign_orphan_preset"
    bl_label = "Assign Preset to Group"
    bl_options = {'REGISTER'}

    preset_index: bpy.props.IntProperty(options={'HIDDEN'})
    
    target_group_name: bpy.props.EnumProperty(
        name="Target Group",
        items=get_main_group_items
    )
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        try:
            preset = prefs.custom_favorite_presets[self.preset_index]
            old_name = preset.name
            
            preset.main_group_name = self.target_group_name
            
            self.report({'INFO'}, f"Assigned '{old_name}' to '{self.target_group_name}'.")
        except Exception as e:
            self.report({'ERROR'}, f"Failed to assign: {e}")
            return {'CANCELLED'}
        return {'FINISHED'}

class ST_OT_AddItemToFavoritePreset(bpy.types.Operator):
    """Adds or removes an item from a specific favorite preset."""
    bl_idname = "st.add_item_to_favorite_preset"
    bl_label = "Add/Remove from Preset"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    item_string: bpy.props.StringProperty()
    preset_name: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        master_preset = next((p for p in prefs.custom_favorite_presets if p.name == self.preset_name), None)
        if not master_preset:
            master_preset = prefs.custom_favorite_presets.add()
            master_preset.name = self.preset_name

        item_set = {item.strip() for item in master_preset.items.split(',') if item.strip()}

        if self.item_string in item_set:
            item_set.remove(self.item_string)
            self.report({'INFO'}, f"Removed '{self.item_string.split(':')[-1]}' from preset '{self.preset_name}'.")
        else:
            item_set.add(self.item_string)
            self.report({'INFO'}, f"Added '{self.item_string.split(':')[-1]}' to preset '{self.preset_name}'.")

        new_items_str = ", ".join(sorted(list(item_set)))
        master_preset.items = new_items_str

        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}

        target_preset = next((p for p in state.favorite_presets if p.name == self.preset_name), None)
        if not target_preset:
            target_preset = state.favorite_presets.add()
            target_preset.name = self.preset_name
        
        target_preset.items = new_items_str

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'VIEW_3D', 'PREFERENCES'}:
                    area.tag_redraw()

        return {'FINISHED'}
class ST_OT_RemoveItemFromFavoritePreset(bpy.types.Operator):
    """Removes a single item from a specific favorite preset."""
    bl_idname = "st.remove_item_from_favorite_preset"
    bl_label = "Remove Favorite Item"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty(options={'HIDDEN'})
    item_string: bpy.props.StringProperty()
    preset_name: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        master_preset = next((p for p in prefs.custom_favorite_presets if p.name == self.preset_name), None)
        if not master_preset:
            self.report({'WARNING'}, f"Preset '{self.preset_name}' not found in preferences.")
            return {'CANCELLED'}

        item_set = {item.strip() for item in master_preset.items.split(',') if item.strip()}
        if self.item_string not in item_set:
            pass
            
        item_set.discard(self.item_string)
        new_items_str = ", ".join(sorted(list(item_set)))
        master_preset.items = new_items_str

        if self.group_name:
            state = context.window_manager.tab_group_states.get(self.group_name)
            if state:
                state_preset = next((p for p in state.favorite_presets if p.name == self.preset_name), None)
                if state_preset:
                    state_preset.items = new_items_str
        else:
            if hasattr(context.window_manager, "tab_group_states"):
                for state in context.window_manager.tab_group_states:
                    state_preset = next((p for p in state.favorite_presets if p.name == self.preset_name), None)
                    if state_preset:
                        state_preset.items = new_items_str

        self.report({'INFO'}, f"Removed '{self.item_string.split(':')[-1]}' from preset '{self.preset_name}'.")
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'VIEW_3D', 'PREFERENCES'}:
                    area.tag_redraw()
        return {'FINISHED'}
    
class ST_OT_ClearFavorites(bpy.types.Operator):
    """Removes all items from the favorites list for a group."""
    bl_idname = "st.clear_favorites"
    bl_label = "Clear All Favorite Items"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}

        active_preset_name = state.active_favorite_preset_name
        active_preset_in_state = next((p for p in state.favorite_presets if p.name == active_preset_name), None)
        
        if not active_preset_in_state or not active_preset_in_state.items:
            self.report({'INFO'}, "Active favorite preset is already empty.")
            return {'CANCELLED'}

        active_preset_in_state.items = ""

        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        master_preset = next((p for p in prefs.custom_favorite_presets if p.name == active_preset_name), None)
        if master_preset:
            master_preset.items = ""
        
        self.report({'INFO'}, f"Cleared all items from '{active_preset_name}' preset.")

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}

class ST_OT_ClearPresetInPrefs(bpy.types.Operator):
    """Clears all items from a specific preset in the master preferences list."""
    bl_idname = "st.clear_preset_in_prefs"
    bl_label = "Clear All Items from Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset_index: bpy.props.IntProperty()

    @classmethod
    def description(cls, context, properties):
        try:
            prefs = context.preferences.addons[__package__.split('.')[0]].preferences
            preset_name = prefs.custom_favorite_presets[properties.preset_index].name
            return f"Remove all items from '{preset_name}' preset. This CANNOT be undone."
        except:
            return "Clear all items from this preset. This CANNOT be undone."

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if not (0 <= self.preset_index < len(prefs.custom_favorite_presets)):
            self.report({'WARNING'}, "Invalid preset index.")
            return {'CANCELLED'}
        
        preset_to_clear = prefs.custom_favorite_presets[self.preset_index]
        preset_name = preset_to_clear.name
        
        if not preset_to_clear.items:
            self.report({'INFO'}, f"Preset '{preset_name}' is already empty.")
            return {'CANCELLED'}

        preset_to_clear.items = ""

        if hasattr(context.window_manager, "tab_group_states"):
            for state in context.window_manager.tab_group_states:
                state_preset = next((p for p in state.favorite_presets if p.name == preset_name), None)
                if state_preset:
                    state_preset.items = ""
                    
        self.report({'INFO'}, f"Cleared all items from '{preset_name}'.")

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'VIEW_3D', 'PREFERENCES'}:
                    area.tag_redraw()
        
        return {'FINISHED'}

class ST_OT_SetActiveFavoritePreset(bpy.types.Operator):
    """Sets the active favorite preset for a group."""
    bl_idname = "st.set_active_favorite_preset"
    bl_label = "Set Active Favorite Preset"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    preset_name: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}
        
        state.active_favorite_preset_name = self.preset_name
        
        # Redraw UI
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}
    
class ST_OT_ChangeFavoriteColumns(bpy.types.Operator):
    """Change the number of columns for the Favorite items list"""
    bl_idname = "st.change_favorite_columns"
    bl_label = "Change Favorite Item Columns"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    delta: bpy.props.IntProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}

        prop_info = state.bl_rna.properties['favorite_item_columns']
        min_val = prop_info.soft_min
        max_val = prop_info.soft_max

        new_cols = state.favorite_item_columns + self.delta
        state.favorite_item_columns = max(min_val, min(new_cols, max_val))

        return {'FINISHED'}

class ST_OT_ToggleFavoriteAddon(bpy.types.Operator):
    bl_idname = "st.toggle_favorite_addon"
    bl_label = "Toggle Favorite Add-on"
    bl_options = {'REGISTER'}
    modname: bpy.props.StringProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        fav_names = {item.name for item in prefs.favorite_addons}
        if self.modname in fav_names:
            for i, fav in enumerate(prefs.favorite_addons):
                if fav.name == self.modname:
                    prefs.favorite_addons.remove(i)
                    break
        else:
            new_fav = prefs.favorite_addons.add()
            new_fav.name = self.modname
        return {'FINISHED'}

class ST_OT_ClearAllFavorites(bpy.types.Operator):
    bl_idname = "st.clear_all_favorites"
    bl_label = "Clear All Favorites"
    bl_options = {'REGISTER'}
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if prefs.favorite_addons:
            prefs.favorite_addons.clear()
            self.report({'INFO'}, "All favorite addons have been cleared.")
        else:
            self.report({'INFO'}, "Favorite list is already empty.")
        return {'FINISHED'}

class ST_OT_ClearEnabledFavorites(bpy.types.Operator):
    bl_idname = "st.clear_enabled_favorites"
    bl_label = "Clear Enabled Favorites"
    bl_options = {'REGISTER'}
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        enabled_favorites_to_remove = []
        for fav in prefs.favorite_addons:
            is_enabled, _ = addon_utils.check(fav.name)
            if is_enabled:
                enabled_favorites_to_remove.append(fav.name)
        if not enabled_favorites_to_remove:
            self.report({'INFO'}, "No enabled favorites to clear.")
            return {'CANCELLED'}
        for modname in enabled_favorites_to_remove:
            for i, fav in enumerate(prefs.favorite_addons):
                if fav.name == modname:
                    prefs.favorite_addons.remove(i)
                    break
        self.report({'INFO'}, f"Cleared {len(enabled_favorites_to_remove)} enabled favorite(s).")
        return {'FINISHED'}

class ST_OT_ClearDisabledFavorites(bpy.types.Operator):
    bl_idname = "st.clear_disabled_favorites"
    bl_label = "Clear Disabled Favorites"
    bl_options = {'REGISTER'}
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        disabled_favorites_to_remove = []
        for fav in prefs.favorite_addons:
            is_enabled, _ = addon_utils.check(fav.name)
            if not is_enabled:
                disabled_favorites_to_remove.append(fav.name)
        if not disabled_favorites_to_remove:
            self.report({'INFO'}, "No disabled favorites to clear.")
            return {'CANCELLED'}
        for modname in disabled_favorites_to_remove:
            for i, fav in enumerate(prefs.favorite_addons):
                if fav.name == modname:
                    prefs.favorite_addons.remove(i)
                    break
        self.report({'INFO'}, f"Cleared {len(disabled_favorites_to_remove)} disabled favorite(s).")
        return {'FINISHED'}
    
class ST_OT_ChangeFavoriteAddonColumns(bpy.types.Operator):
    bl_idname = "st.change_favorite_addon_columns"
    bl_label = "Change Favorite Addon List Columns"
    bl_options = {'REGISTER'}
    delta: bpy.props.IntProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        new_cols = prefs.favorite_addon_list_columns + self.delta
        prefs.favorite_addon_list_columns = max(1, min(new_cols, 8))
        return {'FINISHED'}

class ST_OT_SetFavoritePresetIcon(bpy.types.Operator):
    """Sets the icon for a specific favorite preset slot."""
    bl_idname = "st.set_favorite_preset_icon"
    bl_label = "Set Favorite Icon"
    bl_options = {'REGISTER'}

    preset_index: bpy.props.IntProperty()
    icon_name: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.preset_index < len(prefs.custom_favorite_presets):
            prefs.custom_favorite_presets[self.preset_index].icon = self.icon_name
        else:
            self.report({'WARNING'}, "Invalid preset index.")
            return {'CANCELLED'}

        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()
        return {'FINISHED'}
    
class ST_OT_TogglePinAllFavorites(bpy.types.Operator):
    """Toggles pinning all items in the active favorite preset."""
    bl_idname = "st.toggle_pin_all_favorites"
    bl_label = "Pin/Unpin All Favorites"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}

        active_preset = next((p for p in state.favorite_presets if p.name == state.active_favorite_preset_name), None)
        if not active_preset or not active_preset.items:
            self.report({'INFO'}, "No favorite items to pin/unpin.")
            return {'CANCELLED'}

        active_favorite_set = {item.strip() for item in active_preset.items.split(',') if item.strip()}
        pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}
        are_all_in_active_preset_pinned = active_favorite_set.issubset(pinned_set)

        if are_all_in_active_preset_pinned:
            items_to_keep_pinned = set()

            for preset in state.favorite_presets:
                if preset.name == state.active_favorite_preset_name:
                    continue
                
                preset_items = {item.strip() for item in preset.items.split(',') if item.strip()}
                if not preset_items:
                    continue
                is_other_preset_pinned = preset_items.issubset(pinned_set)
                if is_other_preset_pinned:
                    items_to_keep_pinned.update(preset_items)

            items_that_can_be_unpinned = active_favorite_set.difference(items_to_keep_pinned)

            pinned_set.difference_update(items_that_can_be_unpinned)
            state.pinned_items = ", ".join(sorted(list(pinned_set)))
            self.report({'INFO'}, f"Unpinned {len(items_that_can_be_unpinned)} items from '{active_preset.name}'.")
            if state.active_item in items_that_can_be_unpinned:
                state.active_item = ""
        else:
            pinned_set.update(active_favorite_set)
            state.pinned_items = ", ".join(sorted(list(pinned_set)))
            if active_favorite_set:
                sorted_favorites = sorted(list(active_favorite_set))
                state.active_item = sorted_favorites[0]
            self.report({'INFO'}, f"Pinned all favorites from '{active_preset.name}'.")

        state.pinned_items = ", ".join(sorted(list(pinned_set)))

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        return {'FINISHED'}

class ST_OT_AddFavoritePreset(bpy.types.Operator):
    """Adds a new, empty favorite preset."""
    bl_idname = "st.add_favorite_preset"
    bl_label = "Add Favorite Preset"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        if not self.group_name:
            self.report({'WARNING'}, "Cannot add preset. No active group context.")
            return {'CANCELLED'}
        
        target_space = 'VIEW_3D'
        owner_group = next((g for g in prefs.tab_groups if g.name == self.group_name), None)
        if owner_group:
            target_space = owner_group.space_type

        state = None
        if self.group_name:
            state = context.window_manager.tab_group_states.get(self.group_name)
        
        used_icons = {p.icon for p in prefs.custom_favorite_presets}

        default_icon = _restricted_node_socket_icons[0] 
        for icon in _restricted_node_socket_icons:
            if icon not in used_icons:
                default_icon = icon
                break 

        new_preset = prefs.custom_favorite_presets.add()
        new_preset.icon = default_icon
        new_preset.main_group_name = self.group_name
        new_preset.space_type = target_space

        existing_names = {
            p.name for p in prefs.custom_favorite_presets 
            if p.main_group_name == self.group_name
        }
        
        i = 1
        new_name_candidate = f"{self.group_name} Preset {i}"
        while new_name_candidate in existing_names:
            i += 1
            new_name_candidate = f"{self.group_name} Preset {i}"
        new_preset.name = new_name_candidate
        
        if state:
            state.active_favorite_preset_name = new_preset.name
        
        self.report({'INFO'}, f"Added new preset: '{new_preset.name}'")
        return {'FINISHED'}
class ST_OT_SetFavoritePresetsDialog(bpy.types.Operator):
    """(SUPERTABs) Opens a dialog to set multiple new presets by name."""
    bl_idname = "st.set_favorite_presets_dialog"
    bl_label = "Set New Presets"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty(options={'HIDDEN'})
    
    preset_names: bpy.props.StringProperty(
        name="Preset Names",
        description="Enter preset names, separated by commas (e.g., Sky, Terrain, Water)"
    )

    def invoke(self, context, event):
        self.preset_names = "Sky, Terrain, Water"
        return context.window_manager.invoke_props_dialog(self, width=400)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Enter preset names, separated by commas:")
        layout.prop(self, "preset_names", text="")

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        if not self.group_name:
            self.report({'ERROR'}, "No group context.")
            return {'CANCELLED'}

        target_space = 'VIEW_3D'
        owner_group = next((g for g in prefs.tab_groups if g.name == self.group_name), None)
        if owner_group:
            target_space = owner_group.space_type

        if not self.preset_names.strip():
            self.report({'INFO'}, "No names entered.")
            return {'CANCELLED'}

        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            self.report({'ERROR'}, "Group state not found.")
            return {'CANCELLED'}

        existing_names_global = {p.name for p in prefs.custom_favorite_presets}
        used_icons_in_group = {p.icon for p in prefs.custom_favorite_presets if p.main_group_name == self.group_name}
        names_to_add = [name.strip() for name in self.preset_names.split(',') if name.strip()]
        added_count = 0
        skipped_count = 0
        
        new_active_name = None

        for name in names_to_add:
            if not name or name in existing_names_global:
                skipped_count += 1
                continue

            default_icon = _restricted_node_socket_icons[0] 
            for icon in _restricted_node_socket_icons:
                if icon not in used_icons_in_group:
                    default_icon = icon
                    break 
            
            new_preset = prefs.custom_favorite_presets.add()
            new_preset.name = name
            new_preset.icon = default_icon
            new_preset.main_group_name = self.group_name
            new_preset.space_type = target_space

            existing_names_global.add(name)
            used_icons_in_group.add(default_icon)
            
            new_active_name = name
            added_count += 1

        if new_active_name and state:
            state.active_favorite_preset_name = new_active_name

        report_message = f"Added {added_count} new preset(s)."
        if skipped_count > 0:
            report_message += f" Skipped {skipped_count} invalid/duplicate name(s)."
            
        self.report({'INFO'}, report_message)
        
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'VIEW_3D', 'PREFERENCES'}:
                    area.tag_redraw()

        return {'FINISHED'}
    
class ST_OT_RemoveFavoritePreset(bpy.types.Operator):
    """Removes a favorite preset by its index."""
    bl_idname = "st.remove_favorite_preset"
    bl_label = "Remove Favorite Preset"
    bl_options = {'REGISTER'}

    preset_index: bpy.props.IntProperty()
    group_name: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        # state = context.window_manager.tab_group_states.get(self.group_name)

        state = None
        if self.group_name:
            state = context.window_manager.tab_group_states.get(self.group_name)

        if not (0 <= self.preset_index < len(prefs.custom_favorite_presets)):
            self.report({'WARNING'}, "Invalid preset index.")
            return {'CANCELLED'}

        preset_to_remove = prefs.custom_favorite_presets[self.preset_index]
        removed_name = preset_to_remove.name
        
        is_active = False
        if state:
            is_active = (state.active_favorite_preset_name == removed_name)
        # is_active = (state.active_favorite_preset_name == removed_name)

        prefs.custom_favorite_presets.remove(self.preset_index)
        
        if is_active:
            if prefs.custom_favorite_presets:
                state.active_favorite_preset_name = prefs.custom_favorite_presets[0].name
            else:
                state.active_favorite_preset_name = ""
        
        self.report({'INFO'}, f"Removed preset: '{removed_name}'")
        return {'FINISHED'}

class ST_OT_OpenFavoriteIconPicker(bpy.types.Operator):
    """Opens the popover to select a favorite preset icon."""
    bl_idname = "st.open_favorite_icon_picker"
    bl_label = "Select Favorite Icon"
    bl_options = {'REGISTER'}

    preset_index: bpy.props.IntProperty()

    def execute(self, context):
        context.window_manager.st_preset_icon_picker_index = self.preset_index
        bpy.ops.wm.call_panel(name="ST_PT_FavoriteIconPicker", keep_open=True)
        return {'FINISHED'}

class ST_OT_CallAddToFavoriteMenu(bpy.types.Operator):
    """Sets context and calls the 'Add to Favorite Preset' menu."""
    bl_idname = "st.call_add_to_favorite_menu"
    bl_label = "Add to Favorite Preset"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    item_string: bpy.props.StringProperty()

    def execute(self, context):
        
        bpy.ops.st.add_to_favorite_preset_dialog('INVOKE_DEFAULT', 
                                                group_name=self.group_name, 
                                                item_string=self.item_string)
        return {'FINISHED'}
    
class ST_OT_ApplyPresetFromPanel(bpy.types.Operator):
    """(SUPERTABs) Applies a preset from within its own N-Panel. (No Panel Switching)"""
    bl_idname = "st.apply_preset_from_panel"
    bl_label = "Apply Favorite Preset from Panel"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    preset_name: bpy.props.StringProperty()
    _shift_pressed: bpy.props.BoolProperty(options={'HIDDEN'})

    def invoke(self, context, event):
        self._shift_pressed = event.shift
        return self.execute(context)

    def execute(self, context):
        context.window_manager.st_last_active_main_group = self.group_name
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state: 
            return {'CANCELLED'}

        target_preset = next((p for p in state.favorite_presets if p.name == self.preset_name), None)

        if not target_preset:
            target_preset = state.favorite_presets.add()
            target_preset.name = self.preset_name

        items_to_toggle_set = set()
        if target_preset.items:
            items_to_toggle_set = {item.strip() for item in target_preset.items.split(',') if item.strip()}

        current_pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}

        if self._shift_pressed:
            # ============================================
            # --- LOGIC 1: ADDITIVE (Shift+Click) ---
            # ============================================
            is_already_pinned = items_to_toggle_set.issubset(current_pinned_set) and bool(items_to_toggle_set)
            
            if is_already_pinned:
                items_to_keep_pinned = set()
                for preset in state.favorite_presets:
                    if preset.name == self.preset_name:
                        continue
                    other_preset_items = {item.strip() for item in preset.items.split(',') if item.strip()}
                    if not other_preset_items:
                        continue
                    if other_preset_items.issubset(current_pinned_set):
                        items_to_keep_pinned.update(other_preset_items)
                items_that_can_be_unpinned = items_to_toggle_set.difference(items_to_keep_pinned)
                if items_that_can_be_unpinned:
                    current_pinned_set.difference_update(items_that_can_be_unpinned)
                    if state.active_item in items_that_can_be_unpinned:
                        state.active_item = ""
            else:
                current_pinned_set.update(items_to_toggle_set)
                if items_to_toggle_set and not state.active_item:
                        state.active_item = sorted(list(items_to_toggle_set))[0]
            state.pinned_items = ", ".join(sorted(list(current_pinned_set)))
        else:
            # ============================================
            # --- LOGIC 2: EXCLUSIVE / TOGGLE (Click) ---
            # ============================================
            is_already_active_preset = (state.active_favorite_preset_name == self.preset_name)
            
            if is_already_active_preset:
                state.active_favorite_preset_name = self.preset_name
                if not items_to_toggle_set.issubset(current_pinned_set):
                    current_pinned_set.update(items_to_toggle_set)
                    state.pinned_items = ", ".join(sorted(list(current_pinned_set)))
                else:
                    state.active_favorite_preset_name = self.preset_name
                    state.pinned_items = ", ".join(sorted(list(items_to_toggle_set)))
                    if items_to_toggle_set:
                        state.active_item = sorted(list(items_to_toggle_set))[0]
                    else:
                        state.active_item = ""
            else:
                state.active_favorite_preset_name = self.preset_name
                state.pinned_items = ", ".join(sorted(list(items_to_toggle_set)))
                if items_to_toggle_set:
                    state.active_item = sorted(list(items_to_toggle_set))[0]
                else:
                    state.active_item = ""

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'VIEW_3D', 'IMAGE_EDITOR'}:
                    area.tag_redraw()
        return {'FINISHED'}

class ST_OT_SetExclusiveFavoritePreset(bpy.types.Operator):
    """Sets the active preset AND pins *only* its items.
    CRASH FIX: Write-Only Mode (Never reads active_panel_category)."""
    bl_idname = "st.set_exclusive_favorite_preset"
    bl_label = "Set Exclusive Favorite Preset"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    preset_name: bpy.props.StringProperty()
    _shift_pressed: bpy.props.BoolProperty(options={'HIDDEN'})

    def invoke(self, context, event):
        self._shift_pressed = event.shift
        return self.execute(context)

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        wm = context.window_manager
        
        target_group_name = self.group_name
        
        target_group_pref = next((g for g in prefs.tab_groups if g.name == target_group_name), None)
        target_space_type = target_group_pref.space_type if target_group_pref else 'VIEW_3D'
        
        state = wm.tab_group_states.get(target_group_name)
        if not state: 
            state = wm.tab_group_states.add()
            state.name = target_group_name

        last_active_group = wm.st_last_active_main_group
        
        is_remote_call = False
        if context.area and context.area.type != target_space_type:
            is_remote_call = True

        is_switching_groups = (last_active_group != target_group_name)
        is_same_preset_active = (state.active_favorite_preset_name == self.preset_name)
        has_pinned_items = bool(state.pinned_items)

        wm.st_last_active_main_group = target_group_name

        target_area = None
        if not is_remote_call and context.area:
            target_area = context.area
        else:
            found = False
            if context.window and context.window.screen:
                for area in context.window.screen.areas:
                    if area.type == target_space_type:
                        target_area = area
                        found = True
                        break
            if not found:
                for window in wm.windows:
                    if window == context.window: continue
                    for area in window.screen.areas:
                        if area.type == target_space_type:
                            target_area = area
                            found = True
                            break
                    if found: break

        # --- [PRESET LOGIC] ---
        target_preset = next((p for p in state.favorite_presets if p.name == self.preset_name), None)
        if not target_preset:
            target_preset = state.favorite_presets.add()
            target_preset.name = self.preset_name

        items_to_toggle_set = set()
        if target_preset.items:
            items_to_toggle_set = {item.strip() for item in target_preset.items.split(',') if item.strip()}
        
        current_pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}

        should_force_panel_open = False

        if self._shift_pressed:
            is_already_pinned = items_to_toggle_set.issubset(current_pinned_set) and bool(items_to_toggle_set)
            if is_already_pinned:
                items_to_keep_pinned = set()
                for preset in state.favorite_presets:
                    if preset.name == self.preset_name: continue
                    other_preset_items = {item.strip() for item in preset.items.split(',') if item.strip()}
                    if not other_preset_items: continue
                    if other_preset_items.issubset(current_pinned_set): items_to_keep_pinned.update(other_preset_items)
                items_that_can_be_unpinned = items_to_toggle_set.difference(items_to_keep_pinned)
                if items_that_can_be_unpinned:
                    current_pinned_set.difference_update(items_that_can_be_unpinned)
                    if state.active_item in items_that_can_be_unpinned: state.active_item = ""
            else:
                current_pinned_set.update(items_to_toggle_set)
                if items_to_toggle_set and not state.active_item: state.active_item = sorted(list(items_to_toggle_set))[0]
            state.pinned_items = ", ".join(sorted(list(current_pinned_set)))
        
        else:
            can_toggle_off = (not is_remote_call) and (not is_switching_groups) and is_same_preset_active and has_pinned_items

            if can_toggle_off:
                state.pinned_items = ""
                state.active_item = ""
            else:
                state.active_favorite_preset_name = self.preset_name
                state.pinned_items = ", ".join(sorted(list(items_to_toggle_set)))
                if items_to_toggle_set:
                    state.active_item = sorted(list(items_to_toggle_set))[0]
                else:
                    state.active_item = ""
                
                should_force_panel_open = True

        if target_area and should_force_panel_open:
            try:
                space = next((s for s in target_area.spaces if s.type == target_space_type), None)
                if space:
                    space.show_region_ui = True
                
                region = next((r for r in target_area.regions if r.type == 'UI'), None)
                if region:
                    try:
                        region.active_panel_category = target_group_name
                        region.tag_redraw()
                    except Exception: 
                        pass
            except Exception:
                pass

        if is_remote_call or is_switching_groups:
            for window in wm.windows:
                for area in window.screen.areas:
                    if area.type in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR'}:
                        area.tag_redraw()
        else:
            if target_area: target_area.tag_redraw()
            elif context.area: context.area.tag_redraw()

        return {'FINISHED'}

class ST_OT_ReorderActiveFavoritePreset(bpy.types.Operator):
    """Reorders the currently active favorite preset up or down."""
    bl_idname = "st.reorder_active_favorite_preset"
    bl_label = "Reorder Active Favorite Preset"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    direction: bpy.props.EnumProperty(
        items=[('UP', 'Up', 'Move preset up'),
               ('DOWN', 'Down', 'Move preset down')]
    )

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        collection = prefs.custom_favorite_presets
        
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            self.report({'WARNING'}, "Group state not found.")
            return {'CANCELLED'}
        
        active_name = state.active_favorite_preset_name
        if not active_name:
            self.report({'INFO'}, "No active preset selected.")
            return {'CANCELLED'}

        group_presets = []
        for i, p in enumerate(collection):
            if p.main_group_name == self.group_name:
                group_presets.append({'global_index': i, 'name': p.name})

        local_active_index = -1
        for i, p_data in enumerate(group_presets):
            if p_data['name'] == active_name:
                local_active_index = i
                break
        
        if local_active_index == -1:
            self.report({'WARNING'}, f"Active preset '{active_name}' not found in group.")
            return {'CANCELLED'}

        if self.direction == 'UP':
            if local_active_index == 0:
                return {'CANCELLED'}
            local_target_index = local_active_index - 1
        else:
            if local_active_index == len(group_presets) - 1:
                return {'CANCELLED'}
            local_target_index = local_active_index + 1

        global_active_index = group_presets[local_active_index]['global_index']
        global_target_index = group_presets[local_target_index]['global_index']

        collection.move(global_active_index, global_target_index)
        
        for window in context.window_manager.windows:
            screen = window.screen
            for area in screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
        
        return {'FINISHED'}

class ST_OT_RemoveItemFromAllPresets(bpy.types.Operator):
    """(SUPERTABs) Removes a specific item from all favorite presets in this group."""
    bl_idname = "st.remove_item_from_all_presets"
    bl_label = "Remove Item From All Presets"
    bl_options = {'REGISTER'}

    item_string: bpy.props.StringProperty()
    group_name: bpy.props.StringProperty()

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            self.report({'WARNING'}, "Group state not found.")
            return {'CANCELLED'}

        count = 0
        for preset in state.favorite_presets:
            item_set = {item.strip() for item in preset.items.split(',') if item.strip()}
            if self.item_string in item_set:
                item_set.remove(self.item_string)
                preset.items = ", ".join(sorted(list(item_set)))
                count += 1
        
        if count > 0:
            self.report({'INFO'}, f"Removed '{self.item_string.split(':')[-1]}' from {count} preset(s).")
            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type in {'VIEW_3D', 'PREFERENCES'}:
                        area.tag_redraw()
        else:
            self.report({'INFO'}, "Item was not found in any presets.")

        return {'FINISHED'}

class ST_MT_ItemInPresetsMenu(bpy.types.Menu):
    bl_label = "Item in Presets"
    bl_idname = "ST_MT_ItemInPresetsMenu"

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        item_string = getattr(wm, "st_item_for_preset_list", "")
        group_name = getattr(wm, "st_group_for_preset_list", "")
        
        if not item_string or not group_name:
            layout.label(text="No item context", icon='ERROR')
            return

        state = context.window_manager.tab_group_states.get(group_name)
        if not state:
            layout.label(text="No state context", icon='ERROR')
            return
        
        active_space = prefs.active_management_tab
        preset_icon_map = {p.name: p.icon for p in prefs.custom_favorite_presets if p.space_type == active_space}

        item_found_in_presets = []
        for preset in state.favorite_presets:
            if preset.name not in preset_icon_map:
                continue
            if item_string in {item.strip() for item in preset.items.split(',')}:
                item_found_in_presets.append(preset.name)
        
        if not item_found_in_presets:
            layout.label(text="Item not found in any presets", icon='INFO')
            return

        layout.label(text=f"'{item_string.split(':')[-1]}' is in:", icon='INFO')

        for preset_name in sorted(item_found_in_presets):
            icon = preset_icon_map.get(preset_name, 'PRESET')
            
            op = layout.operator("st.set_active_favorite_preset", text=preset_name, icon=icon)
            op.group_name = group_name
            op.preset_name = preset_name
            
        layout.separator()

        op = layout.operator(ST_OT_RemoveItemFromAllPresets.bl_idname, text="Clear from All Presets", icon='TRASH')
        op.item_string = item_string
        op.group_name = group_name


class ST_OT_CallItemInPresetsMenu(bpy.types.Operator):
    """(SUPERTABs) Sets context and calls the Item In Presets menu."""
    bl_idname = "st.call_item_in_presets_menu"
    bl_label = "Show Presets Containing Item"
    bl_options = {'REGISTER'}

    item_string: bpy.props.StringProperty()
    group_name: bpy.props.StringProperty()

    def execute(self, context):
        wm = context.window_manager
        wm.st_item_for_preset_list = self.item_string
        wm.st_group_for_preset_list = self.group_name
        
        bpy.ops.wm.call_menu(name=ST_MT_ItemInPresetsMenu.bl_idname)
        return {'FINISHED'}

class ST_OT_AddToFavoritePresetDialog(bpy.types.Operator):
    """(SUPERTABs) A popover dialog to add/remove an item from multiple presets."""
    bl_idname = "st.add_to_favorite_preset_dialog"
    bl_label = "Add to Favorite Presets"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    item_string: bpy.props.StringProperty()

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=200)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        item_string = self.item_string
        group_name = self.group_name
        
        state = context.window_manager.tab_group_states.get(group_name)
        if not state:
            layout.label(text="No state context")
            return
        
        op_add = layout.operator("st.add_favorite_preset", text="Add New Preset", icon='ADD')
        op_add.group_name = group_name

        layout.separator()
        presets_for_this_group = [
            p for p in prefs.custom_favorite_presets 
            if p.main_group_name == self.group_name
        ]

        if not presets_for_this_group:
            layout.label(text="No presets created for this group", icon="INFO")
            return

        item_in_presets = set()
        for preset in state.favorite_presets:
            if preset.name in {p.name for p in presets_for_this_group}:
                if item_string in {item.strip() for item in preset.items.split(',')}:
                    item_in_presets.add(preset.name)
        for preset in presets_for_this_group:
            is_in_this_preset = preset.name in item_in_presets
            op = layout.operator(ST_OT_AddItemToFavoritePreset.bl_idname, text=preset.name,icon=preset.icon,depress=is_in_this_preset)
            op.group_name = group_name
            op.item_string = item_string
            op.preset_name = preset.name
class ST_OT_TogglePresetExpand(bpy.types.Operator):
    """Toggles the expansion state of a preset in the preferences UI."""
    bl_idname = "st.toggle_preset_expand"
    bl_label = "Toggle Preset Expansion"
    bl_options = {'REGISTER'}

    preset_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.preset_index < len(prefs.custom_favorite_presets):
            prefs.custom_favorite_presets[self.preset_index].is_expanded_in_prefs = not prefs.custom_favorite_presets[self.preset_index].is_expanded_in_prefs
        return {'FINISHED'}

class ST_OT_ReorderPresetInPrefs(bpy.types.Operator):
    """Reorders a favorite preset in the master list by its index."""
    bl_idname = "st.reorder_preset_in_prefs"
    bl_label = "Reorder Preset"
    bl_options = {'REGISTER', 'UNDO'}

    preset_index: bpy.props.IntProperty()
    direction: bpy.props.EnumProperty(
        items=[('UP', 'Up', 'Move preset up'),
               ('DOWN', 'Down', 'Move preset down')]
    )

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        collection = prefs.custom_favorite_presets
        
        if not (0 <= self.preset_index < len(collection)):
            self.report({'WARNING'}, "Invalid preset index.")
            return {'CANCELLED'}

        try:
            preset_to_move = collection[self.preset_index]
            target_group_name = preset_to_move.main_group_name
        except IndexError:
            return {'CANCELLED'}
        
        if not target_group_name:
            self.report({'WARNING'}, "Preset has no group. Cannot reorder.")
            return {'CANCELLED'}

        group_presets = []
        for i, p in enumerate(collection):
            if p.main_group_name == target_group_name:
                group_presets.append({'global_index': i, 'name': p.name})

        local_active_index = -1
        for i, p_data in enumerate(group_presets):
            if p_data['global_index'] == self.preset_index:
                local_active_index = i
                break
        
        if local_active_index == -1:
            return {'CANCELLED'}

        if self.direction == 'UP':
            if local_active_index == 0:
                return {'CANCELLED'}
            local_target_index = local_active_index - 1
        else:
            if local_active_index == len(group_presets) - 1:
                return {'CANCELLED'}
            local_target_index = local_active_index + 1

        global_active_index = group_presets[local_active_index]['global_index']
        global_target_index = group_presets[local_target_index]['global_index']

        collection.move(global_active_index, global_target_index)

        for window in context.window_manager.windows:
            for area in window.screen.areas: 
                if area.type == 'PREFERENCES':
                    area.tag_redraw()
        
        return {'FINISHED'}
class ST_OT_ToggleQuickShortcut(bpy.types.Operator):
    """(SUPERTABs) Adds or removes an item from the user's Quick Shortcuts list."""
    bl_idname = "st.toggle_quick_shortcut"
    bl_label = "Toggle Quick Shortcut"
    bl_options = {'REGISTER'}

    item_identifier: bpy.props.StringProperty()
    display_name: bpy.props.StringProperty()
    main_group_name: bpy.props.StringProperty()
    sub_group_name: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        collection = prefs.quick_shortcuts

        target_space = 'VIEW_3D' # Default
        found_group = next((g for g in prefs.tab_groups if g.name.startswith(self.main_group_name)), None)
        if found_group:
            target_space = found_group.space_type
        
        found_index = -1
        for i, item in enumerate(collection):
            if item.identifier == self.item_identifier and item.space_type == target_space:
                found_index = i
                break
        
        if found_index != -1:
            collection.remove(found_index)
            if prefs.active_quick_shortcut_index == found_index:
                prefs.active_quick_shortcut_index = -1
            elif prefs.active_quick_shortcut_index > found_index:
                prefs.active_quick_shortcut_index -= 1
                
            self.report({'INFO'}, f"Removed '{self.display_name}' from Quick Shortcuts ({target_space}).")
        else:
            new_item = collection.add()
            new_item.identifier = self.item_identifier
            new_item.display_name = self.display_name
            new_item.main_group_name = self.main_group_name
            new_item.sub_group_name = self.sub_group_name
            new_item.space_type = target_space
            prefs.active_quick_shortcut_index = len(collection) - 1
            self.report({'INFO'}, f"Added '{self.display_name}' to Quick Shortcuts ({target_space}).")
            
        return {'FINISHED'}

class ST_OT_ActivateQuickShortcut(bpy.types.Operator):
    """(SUPERTABs) Activates a specific item from the Quick Shortcuts menu.
    (Click: Exclusive, Shift+Click: Additive)"""
    bl_idname = "st.activate_quick_shortcut"
    bl_label = "Activate Quick Shortcut"
    bl_options = {'REGISTER'}

    item_identifier: bpy.props.StringProperty()
    main_group_name: bpy.props.StringProperty()
    _shift_pressed: bpy.props.BoolProperty(options={'HIDDEN'})

    def invoke(self, context, event):
        self._shift_pressed = event.shift
        return self.execute(context)

    def execute(self, context):
        target_group_name = self.main_group_name
        should_do_full_redraw = False
        
        supported_types = {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR'}
        target_area_type = 'VIEW_3D'
        
        if context.area and context.area.type in supported_types:
            target_area_type = context.area.type

        target_area = None
        if context.area and context.area.type == target_area_type:
            target_area = context.area
        else:
            for window in context.window_manager.windows:
                screen = window.screen
                for area in screen.areas:
                    if area.type == target_area_type:
                        target_area = area
                        break
                if target_area: break
        
        if target_area:
            try:
                space = None
                for s in target_area.spaces:
                    if s.type == target_area_type:
                        space = s
                        break
                
                if space:
                    if not space.show_region_ui:
                        space.show_region_ui = True
                        should_do_full_redraw = True 
                    
                    ui_region = None
                    for r in target_area.regions:
                        if r.type == 'UI':
                            ui_region = r
                            break
                    
                    if ui_region:
                        try:
                            ui_region.active_panel_category = target_group_name
                            ui_region.tag_redraw()
                        except Exception:
                            pass 

            except Exception as e:
                print(f"SUPERTABs Warning: Panel switch failed: {e}")
                pass

        context.window_manager.st_last_active_main_group = target_group_name
        state = context.window_manager.tab_group_states.get(target_group_name)
        
        if not state: 
            return {'CANCELLED'}
        
        if self._shift_pressed:
            # --- ADDITIVE (Shift+Click) ---
            pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}
            if self.item_identifier in pinned_set:
                pinned_set.remove(self.item_identifier)
            else:
                pinned_set.add(self.item_identifier)
            state.pinned_items = ", ".join(sorted(list(pinned_set)))
        else:
            # --- EXCLUSIVE (Click) ---
            is_already_exclusive_active = (state.active_item == self.item_identifier and not state.pinned_items)
            if is_already_exclusive_active:
                state.active_item = ""
            else:
                state.active_item = self.item_identifier
                state.pinned_items = ""

        # 4. Final Redraw
        if should_do_full_redraw:
            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type in {'VIEW_3D', 'IMAGE_EDITOR', 'NODE_EDITOR'}:
                        area.tag_redraw()
        else:
            if target_area:
                target_area.tag_redraw()
            elif context.area:
                context.area.tag_redraw()

        return {'FINISHED'}
    
classes = (
    ST_OT_ApplyPresetFromPanel,
    ST_OT_AssignOrphanPreset,
    ST_OT_ReorderActiveFavoritePreset,
    ST_OT_SetExclusiveFavoritePreset,
    ST_OT_OpenFavoriteIconPicker,
    ST_OT_RemoveItemFromFavoritePreset,
    ST_OT_ChangeFavoriteColumns,
    ST_OT_SetActiveFavoritePreset,
    ST_OT_ClearFavorites,
    ST_OT_AddItemToFavoritePreset,
    ST_OT_ToggleFavoriteAddon,
    ST_OT_ClearAllFavorites,
    ST_OT_ClearEnabledFavorites,
    ST_OT_ClearDisabledFavorites,
    ST_OT_ChangeFavoriteAddonColumns,
    ST_OT_SetFavoritePresetIcon,
    ST_OT_TogglePinAllFavorites,
    ST_OT_AddFavoritePreset,
    ST_OT_RemoveFavoritePreset,
    ST_OT_AddToFavoritePresetDialog,
    ST_OT_CallAddToFavoriteMenu,
    ST_OT_RemoveItemFromAllPresets, 
    ST_MT_ItemInPresetsMenu,      
    ST_OT_CallItemInPresetsMenu,  
    ST_OT_TogglePresetExpand,
    ST_OT_ClearPresetInPrefs,
    ST_OT_ReorderPresetInPrefs,
    ST_OT_ToggleQuickShortcut,
    ST_OT_ActivateQuickShortcut,
    ST_OT_SetFavoritePresetsDialog,
)