import bpy
import blf
import gpu
import math
import bmesh
from mathutils import Vector
from gpu_extras.batch import batch_for_shader
from ..core import apply_group_settings, reset_ui_to_default, status_countdown_timer
from .. import state as st_state
from ..utils import trigger_redraw, set_layer_value


class APPLY_OT_GroupSettings(bpy.types.Operator):
    """Apply Or Refresh TabGroup Settings"""
    bl_idname = "tab_group.apply_settings"
    bl_label = "Apply / Refresh UI"
    def execute(self, context):
        apply_group_settings(context, self)
        if st_state:
            st_state.restart_required_for_poll_exceptions = False
        
        context.window_manager.st_ui_applied_once = True

        return {"FINISHED"}
    
class RESET_OT_UIToDefault(bpy.types.Operator):
    """Reset UI to Default"""
    bl_idname = "tab_group.reset_ui"
    bl_label = "Reset UI"
    @classmethod
    def poll(cls, context):
        return len(st_state.managed_panels) > 0
    def execute(self, context): 
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        if hasattr(context.window_manager, "tab_group_states"):
            saved_states = {}
            for state in context.window_manager.tab_group_states:
                presets_data = []
                for preset in state.favorite_presets:
                    presets_data.append({"name": preset.name, "items": preset.items})
                
                subgroup_cols_data = {}
                for sub_data in state.subgroup_column_data:
                    subgroup_cols_data[sub_data.name] = sub_data.item_columns

                saved_states[state.name] = {
                    "pinned_items": state.pinned_items,
                    "active_favorite_preset_name": state.active_favorite_preset_name,
                    "favorite_presets": presets_data,
                    "subgroup_columns": state.subgroup_columns,
                    "item_columns": state.item_columns,
                    "favorite_item_columns": state.favorite_item_columns,
                    "subgroup_column_data": subgroup_cols_data,
                    "show_favorites_panel": state.show_favorites_panel,
                    "show_favorite_nodes_panel": state.show_favorite_nodes_panel,
                    "show_groupaddons_panel": state.show_groupaddons_panel,
                    "show_windoweditor_panel": state.show_windoweditor_panel,
                    "panel_manager": state.panel_manager,
                }
            
            if saved_states:
                st_state.last_known_states = saved_states
                
        reset_ui_to_default(context, self)
        # context.window_manager.st_ui_applied_once = True
        prefs.is_ui_reset_for_deletion = True

        self.report({'INFO'}, "UI has been reset. You can now delete tabs.")
        return {"FINISHED"}
    
class ST_OT_ToggleAddonEnabled(bpy.types.Operator):
    bl_idname = "st.toggle_addon_enabled"
    bl_label = "Toggle Add-on"
    bl_options = {'REGISTER'}
    modname: bpy.props.StringProperty()
    enable: bpy.props.BoolProperty()
    def execute(self, context):
        if not self.modname: return {'CANCELLED'}
        if not self.enable:
            wrapped_addon_modules = {data['original_class'].__module__ for data in st_state.managed_panels.values() if data.get('type') == 'MANAGED' and 'original_class' in data}
            if self.modname in wrapped_addon_modules:
                self.report({'INFO'}, f"Add-on '{self.modname}' is managed by SUPERTABs and cannot be disabled from here.")
                return {'CANCELLED'}
        try:
            if self.enable: bpy.ops.preferences.addon_enable(module=self.modname)
            else: bpy.ops.preferences.addon_disable(module=self.modname)
        except Exception as e:
            self.report({'WARNING'}, f"Toggling addon '{self.modname}' reported an error: {e}")
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
        return {'FINISHED'}
    
class ST_OT_ToggleAssetBrowser(bpy.types.Operator):
    bl_idname = "st.toggle_asset_browser"
    bl_label = "Open Asset Browser"
    bl_options = {'REGISTER'}
    @classmethod
    def poll(cls, context): return True
    def execute(self, context):
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.ui_type == 'ASSETS':
                    self.report({'INFO'}, "Asset Browser is already open.")
                    return {'CANCELLED'}
        try:
            bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
            prefs_area_found_and_converted = False
            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'PREFERENCES':
                        area.type = 'FILE_BROWSER'
                        area.ui_type = 'ASSETS'
                        prefs_area_found_and_converted = True
                        break
                if prefs_area_found_and_converted: break
            if prefs_area_found_and_converted:
                self.report({'INFO'}, "Opened Asset Browser in a new window.")
                return {'FINISHED'}
            else:
                self.report({'WARNING'}, "Could not find the new preferences window to convert.")
                return {'CANCELLED'}
        except Exception as e:
            self.report({'ERROR'}, f"Failed to open or convert preferences window: {e}")
            return {'CANCELLED'}
        
# --- Splitting/Joining View ---
class VIEW3D_OT_manage_areas(bpy.types.Operator):
    """Invokes the operator for joining or splitting areas directly"""
    bl_idname = "view3d.manage_areas"
    bl_label = "Split/Join View"
    bl_description = "Enable mode for splitting or joining areas"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if context.area.type != 'VIEW_3D':
            self.report({'WARNING'}, "This operator must be called from a 3D View window")
            return {'CANCELLED'}

        with context.temp_override(area=context.area):
            bpy.ops.screen.area_join('INVOKE_DEFAULT')
            
        return {'FINISHED'}
    
# --- Status Bar Operator ---
class ST_OT_SetStatusMessage(bpy.types.Operator):
    """Sets a status message in the addon preferences to be displayed in the UI."""
    bl_idname = "st.set_status_message"
    bl_label = "Set Status Message"
    bl_options = {'INTERNAL'}

    message: bpy.props.StringProperty()
    type: bpy.props.StringProperty()
    duration: bpy.props.IntProperty(default=5)

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.status_message = self.message
        prefs.status_type = self.type
        prefs.status_timer = self.duration * 10 

        if not st_state.status_timer:
            st_state.status_timer = bpy.app.timers.register(status_countdown_timer, first_interval=0.2)
        
        trigger_redraw(self, context)
        return {'FINISHED'}
    
class ST_OT_OpenEditorWindow(bpy.types.Operator):
    bl_idname = "st.open_editor_window"
    bl_label = "Open Editor"
    bl_options = {'REGISTER'}
    editor_type: bpy.props.StringProperty()
    tree_type: bpy.props.StringProperty(default="")
    mode: bpy.props.StringProperty(default="")
    def execute(self, context):
        bpy.ops.wm.window_new()
        area = context.area
        space = context.space_data
        area.ui_type = self.editor_type
        if self.tree_type and hasattr(space, 'tree_type'):
            space.tree_type = self.tree_type
        if self.mode and hasattr(space, 'mode'):
            space.mode = self.mode
        return {'FINISHED'}
    
class ST_OT_CopyObjectNameToDataName(bpy.types.Operator):
    """Copies the object names to their data-block names for all selected objects"""
    bl_idname = "st.copy_object_name_to_data_name"
    bl_label = "Copy Object Name to Data Name (Selected)"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.selected_objects

    def execute(self, context):
        count = 0

        for obj in context.selected_objects:
            if obj.data:
                obj.data.name = obj.name
                count += 1

        self.report({'INFO'}, f"Copied name to data for {count} objects")
        return {'FINISHED'}

class ST_OT_ChangeTabListRows(bpy.types.Operator):
    bl_idname = "st.change_tab_list_rows"
    bl_label = "Change Tab List Rows"
    bl_options = {'REGISTER'}
    delta: bpy.props.IntProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        new_rows = prefs.tab_list_display_rows + self.delta
        prefs.tab_list_display_rows = max(1, min(new_rows, 15))
        return {'FINISHED'}

class ST_OT_ShowActiveInOutliner(bpy.types.Operator):
    """Finds the active object in the Outliner"""
    bl_idname = "st.show_active_in_outliner"
    bl_label = "Show Active in Outliner"
    bl_description = "Ensures the active object is visible in the Outliner"
    bl_options = {'REGISTER'}

    def execute(self, context):
        if not context.object:
            self.report({'INFO'}, "No active object.")
            return {'CANCELLED'}

        outliner_area = None
        for area in context.screen.areas:
            if area.type == 'OUTLINER':
                outliner_area = area
                break
        
        if outliner_area:
            outliner_region = None
            for region in outliner_area.regions:
                if region.type == 'WINDOW':
                    outliner_region = region
                    break
            
            if outliner_region:
                outliner_area.spaces.active.display_mode = 'VIEW_LAYER'
                
                with context.temp_override(
                    window=context.window,
                    screen=context.screen,
                    area=outliner_area,
                    region=outliner_region
                ):
                    bpy.ops.outliner.show_active()
                
                return {'FINISHED'}

        self.report({'WARNING'}, "Outliner editor not found in the current screen.")
        return {'CANCELLED'}

class ST_OT_SetItemState(bpy.types.Operator):
    """Sets the active/pinned state of an item based on click type (Click: Exclusive, Shift+Click: Additive)"""
    bl_idname = "st.set_item_state"
    bl_label = "Set Item State"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()
    item_string: bpy.props.StringProperty()

    _shift_pressed: bpy.props.BoolProperty(options={'HIDDEN'})

    def invoke(self, context, event):
        self._shift_pressed = event.shift
        return self.execute(context)

    def execute(self, context):
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}

        if self._shift_pressed:
            pinned_set = {item.strip() for item in state.pinned_items.split(',') if item.strip()}
            
            if self.item_string in pinned_set:
                pinned_set.remove(self.item_string)
            else:
                pinned_set.add(self.item_string)
                
            state.pinned_items = ", ".join(sorted(list(pinned_set)))
            
        else:
            is_already_exclusive_active = (state.active_item == self.item_string and not state.pinned_items)

            if is_already_exclusive_active:
                state.active_item = ""
            else:
                state.active_item = self.item_string
                state.pinned_items = ""

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'VIEW_3D':
                    area.tag_redraw()
                    
        return {'FINISHED'}
    
class COLUMN_OT_Change(bpy.types.Operator):
    bl_idname = "tab_group.change_columns"
    bl_label = "Change Columns"
    bl_options = {'REGISTER'}
    group_name: bpy.props.StringProperty()
    target_property: bpy.props.StringProperty()
    delta: bpy.props.IntProperty()

    subgroup_name: bpy.props.StringProperty(default="")
    
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            return {'CANCELLED'}
        
        if self.target_property == 'item_columns' and self.subgroup_name:
            subgroup_settings = state.subgroup_column_data.get(self.subgroup_name)
            
            if not subgroup_settings:
                subgroup_settings = state.subgroup_column_data.add()
                subgroup_settings.name = self.subgroup_name
                subgroup_settings.item_columns = state.item_columns

            max_val = 12 
            full_subgroup_name = f"{self.group_name} / {self.subgroup_name}"
            target_group = next((g for g in prefs.tab_groups if g.name == full_subgroup_name), None)
            
            if target_group:
                num_items = len([item for item in target_group.items.split(',') if item.strip()])
                max_val = max(1, num_items)

            current_val = subgroup_settings.item_columns
            new_val = max(1, min(current_val + self.delta, 4))
            subgroup_settings.item_columns = new_val

        else:
            from ..properties import SubTabState
            prop_info = SubTabState.bl_rna.properties[self.target_property]
            current_val = getattr(state, self.target_property)
            min_val = getattr(prop_info, 'soft_min', 1)
            max_val = getattr(prop_info, 'soft_max', 12)
            new_val = max(min_val, min(current_val + self.delta, max_val))
            setattr(state, self.target_property, new_val)
            
        return {'FINISHED'}
    
class ST_OT_ChangeAddonColumns(bpy.types.Operator):
    bl_idname = "st.change_addon_columns"
    bl_label = "Change Addon List Columns"
    bl_options = {'REGISTER'}
    delta: bpy.props.IntProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        new_cols = prefs.addon_list_columns + self.delta
        prefs.addon_list_columns = max(1, min(new_cols, 8))
        return {'FINISHED'}
    
class ST_OT_SetLiveDataValue(bpy.types.Operator):
    """Sets a specific BMesh data layer value for selected elements"""
    bl_idname = "st.set_live_data_value"
    bl_label = "Set Live Data Value"
    bl_options = {'REGISTER'}
    bl_description = "Quickly set Bevel or Crease values"

    data_type: bpy.props.EnumProperty(
        items=[
            ('VERT_BEVEL', "Vertex Bevel", ""),
            ('VERT_CREASE', "Vertex Crease", ""),
            ('EDGE_BEVEL', "Edge Bevel", ""),
            ('EDGE_CREASE', "Edge Crease", ""),
        ]
    )
    value: bpy.props.FloatProperty()

    @classmethod
    def poll(cls, context):
        return context.mode == 'EDIT_MESH'

    def execute(self, context):
        mapping = {
            'VERT_BEVEL':  ('verts', 'bevel_weight_vert'),
            'VERT_CREASE': ('verts', 'crease_vert'),
            'EDGE_BEVEL':  ('edges', 'bevel_weight_edge'),
            'EDGE_CREASE': ('edges', 'crease_edge'),
        }
        
        if self.data_type not in mapping:
            return {'CANCELLED'}

        element_type, layer_name = mapping[self.data_type]
        
        set_layer_value(context, self.value, element_type, layer_name)

        return {'FINISHED'}

class ST_OT_ToggleCleanView(bpy.types.Operator):
    """Saves the current overlay state and toggles all off, or restores the saved state."""
    bl_idname = "st.toggle_clean_view"
    bl_label = "Toggle Clean View"
    bl_options = {'REGISTER'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        overlay = context.space_data.overlay

        overlay_props_to_manage = [
            "show_floor", "show_axis_x", "show_axis_y", "show_axis_z",
            "show_text", "show_cursor", "show_annotation", "show_extras",
            "show_light_colors", "show_relationship_lines", "show_outline_selected",
            "show_bones", "show_motion_paths", "show_object_origins",
            "show_object_origins_all"
        ]

        is_currently_clean = bool(prefs.pre_clean_overlay_state)

        if not is_currently_clean:
            active_props = []
            for prop_name in overlay_props_to_manage:
                if hasattr(overlay, prop_name) and getattr(overlay, prop_name):
                    active_props.append(prop_name)
            
            prefs.pre_clean_overlay_state = ",".join(active_props)
            
            for prop_name in overlay_props_to_manage:
                if hasattr(overlay, prop_name):
                    setattr(overlay, prop_name, False)
            
            # self.report({'INFO'}, "View Cleaned. Overlay states saved.")

        else:
            saved_active_props = set(prefs.pre_clean_overlay_state.split(','))

            for prop_name in overlay_props_to_manage:
                if hasattr(overlay, prop_name):
                    setattr(overlay, prop_name, prop_name in saved_active_props)

            prefs.pre_clean_overlay_state = ""
            
            # self.report({'INFO'}, "Restored previous overlay states.")

        return {'FINISHED'}

class ST_OT_CommitAutoImportState(bpy.types.Operator):
    """Saves user preferences and updates the internal state for auto-import settings."""
    bl_idname = "st.commit_auto_import_state"
    bl_label = "Save Preferences and Update State"
    bl_options = {'REGISTER'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        try:
            bpy.ops.wm.save_userpref()
        except Exception as e:
            self.report({'ERROR'}, f"Failed to save preferences: {e}")
            return {'CANCELLED'}
        
        if prefs.poll_method_exceptions != st_state.saved_poll_method_exceptions:
            st_state.restart_required_for_poll_exceptions = True

        st_state.saved_auto_import_enabled = prefs.auto_import_enabled
        st_state.saved_auto_import_filepath = prefs.auto_import_filepath
        st_state.saved_poll_method_exceptions = prefs.poll_method_exceptions

        trigger_redraw(self, context)
        
        bpy.ops.st.set_status_message('INVOKE_DEFAULT', message="Preferences Saved", type='SUCCESS', duration=1)
        return {'FINISHED'}

class ST_OT_ResetPollExceptions(bpy.types.Operator):
    """Resets the Poll Exceptions list to the addon default"""
    bl_label = "Reset Poll Exceptions"
    bl_idname = "st.reset_poll_exceptions"

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        default_value = "blenderkit, powersave, boxcutter"
        
        prefs.poll_method_exceptions = default_value
        if st_state:
            st_state.saved_poll_method_exceptions = default_value
            st_state.restart_required_for_poll_exceptions = True
        self.report({'INFO'}, "Poll Exceptions reset to default.")

        trigger_redraw(self, context)
        return {'FINISHED'}

class ST_OT_UV_Action(bpy.types.Operator):
    bl_idname = "st.uv_action"
    bl_label = "UV Action"
    bl_options = {'REGISTER', 'UNDO'}

    action: bpy.props.EnumProperty(
        items=[
            ('ALIGN_X', "Align X", "Align selected to average X (Flatten)"),
            ('ALIGN_Y', "Align Y", "Align selected to average Y (Flatten)"),
            ('ZERO_X', "Snap Left (0)", "Move selection to X=0 while keeping shape"),
            ('ZERO_Y', "Snap Bottom (0)", "Move selection to Y=0 while keeping shape"),
            ('ONE_X', "Snap Right (1)", "Move selection to X=1 while keeping shape"),
            ('ONE_Y', "Snap Top (1)", "Move selection to Y=1 while keeping shape"),
        ]
    )

    @classmethod
    def poll(cls, context):
        obj = context.active_object
        return obj and obj.type == 'MESH' and obj.mode == 'EDIT'

    def execute(self, context):
        obj = context.active_object
        me = obj.data
        bm = bmesh.from_edit_mesh(me)
        uv_layer = bm.loops.layers.uv.verify()

        selected_loops = []
        
        for face in bm.faces:
            for loop in face.loops:
                if loop[uv_layer].select:
                    selected_loops.append(loop)

        if not selected_loops:
            self.report({'WARNING'}, "No UV vertices selected")
            return {'CANCELLED'}

        if self.action == 'ALIGN_X':
            avg_x = sum(l[uv_layer].uv.x for l in selected_loops) / len(selected_loops)
            for l in selected_loops:
                l[uv_layer].uv.x = avg_x
        
        elif self.action == 'ALIGN_Y':
            avg_y = sum(l[uv_layer].uv.y for l in selected_loops) / len(selected_loops)
            for l in selected_loops:
                l[uv_layer].uv.y = avg_y
                
        elif self.action == 'ZERO_X':
            min_x = min(l[uv_layer].uv.x for l in selected_loops)
            offset = 0.0 - min_x
            for l in selected_loops:
                l[uv_layer].uv.x += offset

        elif self.action == 'ZERO_Y':
            min_y = min(l[uv_layer].uv.y for l in selected_loops)
            offset = 0.0 - min_y
            for l in selected_loops:
                l[uv_layer].uv.y += offset

        elif self.action == 'ONE_X':
            max_x = max(l[uv_layer].uv.x for l in selected_loops)
            offset = 1.0 - max_x
            for l in selected_loops:
                l[uv_layer].uv.x += offset

        elif self.action == 'ONE_Y':
            max_y = max(l[uv_layer].uv.y for l in selected_loops)
            offset = 1.0 - max_y
            for l in selected_loops:
                l[uv_layer].uv.y += offset

        bmesh.update_edit_mesh(me)
        return {'FINISHED'}

class ST_OT_ClearSubgroupIcon(bpy.types.Operator):
    """Clear Custom Icon from ALL Tab-groups"""
    bl_idname = "st.clear_subgroup_icon"
    bl_label = "Clear All Icons"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        count = 0
        for group in prefs.tab_groups:
            if group.icon != 'NONE':
                group.icon = 'NONE'
                count += 1

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()

        self.report({'INFO'}, f"Cleared icons from {count} subgroups.")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

class ST_OT_ClearItemIcon(bpy.types.Operator):
    """Clear Custom Icon from ALL Items (Add-ons/Tabs)"""
    bl_idname = "st.clear_item_icon"
    bl_label = "Clear All Item Icons"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        count = 0
        for item in prefs.custom_item_names:
            if item.icon != 'NONE':
                item.icon = 'NONE'
                count += 1
        
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                area.tag_redraw()
        
        self.report({'INFO'}, f"Cleared icons from {count} items.")
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
class ST_OT_CurveRecalcHandles(bpy.types.Operator):
    """Recalculate Curve Handles in Object Mode"""
    bl_idname = "st.curve_recalc_handles"
    bl_label = "Recalculate Handle"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.object and context.object.type == 'CURVE' and context.mode == 'OBJECT'

    def execute(self, context):
        original_mode = context.mode
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        bpy.ops.curve.select_all(action='SELECT')
        
        bpy.ops.curve.normals_make_consistent(calc_length=False)
        
        bpy.ops.object.mode_set(mode=original_mode)
        
        return {'FINISHED'}

class ST_OT_MeshRecalcNormalsObject(bpy.types.Operator):
    """Recalculate Normals in Object Mode"""
    bl_idname = "st.mesh_recalc_normals_object"
    bl_label = "Recalculate Normals (Object)"
    
    def execute(self, context):
        prev_mode = context.object.mode
        
        bpy.ops.object.mode_set(mode='EDIT')
        
        bpy.ops.mesh.select_all(action='SELECT')
        
        bpy.ops.mesh.normals_make_consistent(inside=False)
        
        bpy.ops.object.mode_set(mode=prev_mode)
        return {'FINISHED'}

class ST_OT_MeshFlipNormalsObject(bpy.types.Operator):
    """Flip Normals in Object Mode"""
    bl_idname = "st.mesh_flip_normals_object"
    bl_label = "Flip Normals (Object)"
    
    def execute(self, context):
        prev_mode = context.object.mode
        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.flip_normals()
        bpy.ops.object.mode_set(mode=prev_mode)
        return {'FINISHED'}
    
class ST_OT_CollapseAllGroups(bpy.types.Operator):
    """Collapse all subgroups, close active item and clear pinned items (Shift+Click to set Exceptions)"""
    bl_idname = "st.collapse_all_groups"
    bl_label = "Collapse All"
    bl_options = {'REGISTER'}

    group_name: bpy.props.StringProperty()

    def invoke(self, context, event):
        if event.shift:
            self.sync_exception_items(context)
            return context.window_manager.invoke_popup(self, width=300)
        return self.execute(context)

    def sync_exception_items(self, context):
        """Retrieve all Items from Tab Groups and create them as an Exception list"""
        package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
        prefs = context.preferences.addons[package_name].preferences
        
        all_current_items = set()
        for group in prefs.tab_groups:
            items = [i.strip() for i in group.items.split(',') if i.strip()]
            all_current_items.update(items)

        existing_names = {ex.name for ex in prefs.exception_items}
        for item_name in all_current_items:
            if item_name not in existing_names:
                new_ex = prefs.exception_items.add()
                new_ex.name = item_name
                new_ex.is_exception = False

    def draw(self, context):
        layout = self.layout
        package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
        prefs = context.preferences.addons[package_name].preferences
        wm = context.window_manager

        # --- Collapse Targets ---
        box_targets = layout.box()
        box_targets.label(text="Collapse Targets:", icon='SETTINGS')
        
        col_targets = box_targets.column(align=True)
        row_targets = col_targets.row(align=True)
        row_targets.prop(prefs, "collapse_opt_items", text="Addons/Tabs", icon='PREFERENCES')
        row_targets.prop(prefs, "collapse_opt_groups", text="Tab-Groups", icon='FILE_FOLDER')
        row_targets.prop(prefs, "collapse_opt_panels", text="Panels(Favorites/Groups)", icon='WINDOW')

        # --- Exception List ---
        layout.label(text="Exclude from Collapse (Exceptions):", icon='FILTER')
        
        exception_map = {ex.name: ex for ex in prefs.exception_items}
        current_space_type = context.area.type
        found_any = False

        for group in prefs.tab_groups:
            if hasattr(group, 'is_visible') and not group.is_visible:
                continue
            if hasattr(group, 'space_type') and group.space_type != current_space_type:
                continue

            main_tab_name = group.name.split(' / ')[0]
            group_state = wm.tab_group_states.get(main_tab_name)
            
            if not group_state:
                continue
                
            active_and_pinned = set()
            pinned_list = [p.strip() for p in group_state.pinned_items.split(',') if p.strip()]
            if group_state.active_item:
                active_and_pinned.add(group_state.active_item)
            active_and_pinned.update(pinned_list)

            items_to_show = [
                item for item in [i.strip() for i in group.items.split(',') if i.strip()]
                if item in active_and_pinned or (item in exception_map and exception_map[item].is_exception)
            ]

            if items_to_show:
                found_any = True
                box = layout.box()
                box.label(text=group.name, icon='FILE_FOLDER')
                col = box.column(align=True)
                
                for item_name in items_to_show:
                    if item_name in exception_map:
                        icon = 'DOT' if item_name in active_and_pinned else 'BLANK1'
                        clean_name = item_name.replace("tab:", "")
                        col.prop(exception_map[item_name], "is_exception", text=clean_name, icon=icon)
        
        if not found_any:
            layout.label(text="No active items to exclude.", icon='INFO')

        row = layout.row(align=True)
        has_exceptions = any(ex.is_exception for ex in prefs.exception_items)
        if has_exceptions:
            row.alert = True
            row.scale_y = 1.25
            row.operator("st.clear_all_exceptions", text="Clear All Exceptions", icon='X')

    def execute(self, context):
        package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
        prefs = context.preferences.addons[package_name].preferences
        
        do_collapse_items = prefs.collapse_opt_items
        do_collapse_groups = prefs.collapse_opt_groups
        do_collapse_panels = prefs.collapse_opt_panels

        exception_set = {ex.name for ex in prefs.exception_items if ex.is_exception}

        group_state = context.window_manager.tab_group_states.get(self.group_name)
        
        something_remains_open = False
        current_open_items = set()

        if group_state:
            # 1. Collapse Items
            if do_collapse_items:
                if group_state.active_item:
                    if group_state.active_item in exception_set:
                        something_remains_open = True
                        current_open_items.add(group_state.active_item)
                    else:
                        group_state.active_item = ""

                if hasattr(group_state, "pinned_items") and group_state.pinned_items:
                    current_pinned = [p.strip() for p in group_state.pinned_items.split(',') if p.strip()]
                    kept_pinned = []
                    for p in current_pinned:
                        if p in exception_set:
                            kept_pinned.append(p)
                            something_remains_open = True
                            current_open_items.add(p)
                    group_state.pinned_items = ",".join(kept_pinned)
            
            # 2. Collapse Panels (Favorites/Groups)
            if do_collapse_panels:
                if hasattr(group_state, "show_favorites_panel"):
                    group_state.show_favorites_panel = False
                if hasattr(group_state, "show_groupaddons_panel"):
                    group_state.show_groupaddons_panel = False
                
                # --- 3D VIEW ---
                if context.space_data.type == 'VIEW_3D':
                    if hasattr(group_state, "show_windoweditor_panel"):
                        group_state.show_windoweditor_panel = False
                    
                    if hasattr(prefs, "show_transform_panel"): prefs.show_transform_panel = False
                    if hasattr(prefs, "show_curve_panel"): prefs.show_curve_panel = False
                    if hasattr(prefs, "show_view_panel"): prefs.show_view_panel = False
                    if hasattr(prefs, "show_edit_panel"): prefs.show_edit_panel = False
                    if hasattr(prefs, "show_normal_panel"): prefs.show_normal_panel = False
                    if hasattr(prefs, "show_align_uv"): prefs.show_align_uv = False

                # --- IMAGE / UV EDITOR (NEW) ---
                elif context.space_data.type == 'IMAGE_EDITOR':
                    is_uv = (context.space_data.mode == 'UV')
                    
                    if is_uv:
                        # UV Editor
                        if hasattr(prefs, "show_annotations_uv"): 
                            prefs.show_annotations_uv = False
                        if hasattr(prefs, "show_image_panel_uv"): 
                            prefs.show_image_panel_uv = False
                    else:
                        # Image Editor
                        if hasattr(prefs, "show_image_panel"): 
                            prefs.show_image_panel = False
                        if hasattr(prefs, "show_external_data_panel"): 
                            prefs.show_external_data_panel = False
                        if hasattr(prefs, "show_annotations_image"): 
                            prefs.show_annotations_image = False

        # 3. Handle Node Editor Panels
        if do_collapse_panels and context.space_data.type == 'NODE_EDITOR':
            tree_type = getattr(context.space_data, 'tree_type', '')
            target_suffix = ""
            if tree_type == 'GeometryNodeTree': target_suffix = "geometry"
            elif tree_type == 'ShaderNodeTree': target_suffix = "shading"
            elif tree_type == 'CompositorNodeTree': target_suffix = "compositor"
            elif tree_type == 'TextureNodeTree': target_suffix = "texture"
            
            if target_suffix:
                fav_prop = f"st_node_fav_{target_suffix}"
                opt_prop = f"st_node_opt_{target_suffix}"
                if hasattr(prefs, fav_prop): setattr(prefs, fav_prop, False)
                if hasattr(prefs, opt_prop): setattr(prefs, opt_prop, False)

                fav_expand_prop = f"st_node_expand_fav_{target_suffix}"
                if hasattr(prefs, fav_expand_prop): 
                    setattr(prefs, fav_expand_prop, False)

                stats_prop = f"st_node_stats_{target_suffix}"
                if hasattr(prefs, stats_prop): 
                    setattr(prefs, stats_prop, False)
                
                align_prop = f"st_node_align_{target_suffix}"
                if hasattr(prefs, align_prop): 
                    setattr(prefs, align_prop, False)

                anno_prop = f"st_node_anno_{target_suffix}"
                if hasattr(prefs, anno_prop):
                    setattr(prefs, anno_prop, False)

        # 4. Collapse Tab Groups
        if do_collapse_groups:
            prefix = self.group_name + " / "
            for group in prefs.tab_groups:
                if group.name.startswith(prefix):
                    group_items_list = [i.strip() for i in group.items.split(',')]
                    should_keep_expanded = False
                    
                    if something_remains_open:
                        for open_item in current_open_items:
                            if open_item in group_items_list:
                                should_keep_expanded = True
                                break
                    
                    if not should_keep_expanded:
                        group.is_expanded = False
        
        context.area.tag_redraw()
        return {'FINISHED'}

class ST_OT_ClearAllExceptions(bpy.types.Operator):
    """Clear all items from the exception list"""
    bl_idname = "st.clear_all_exceptions"
    bl_label = "Clear All Exceptions"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        package_name = __package__.split('.')[0] if __package__ else "SUPERTABs"
        prefs = context.preferences.addons[package_name].preferences
        
        for ex in prefs.exception_items:
            ex.is_exception = False
            
        return {'FINISHED'}

# --- Registration ---
classes = (
    ST_OT_CollapseAllGroups,
    ST_OT_ClearAllExceptions,
    ST_OT_ResetPollExceptions,
    ST_OT_ToggleCleanView,
    ST_OT_SetLiveDataValue,
    ST_OT_CopyObjectNameToDataName,
    ST_OT_SetStatusMessage,
    ST_OT_OpenEditorWindow,
    ST_OT_ToggleAssetBrowser,
    ST_OT_ToggleAddonEnabled,
    ST_OT_ShowActiveInOutliner,
    ST_OT_ChangeTabListRows,
    ST_OT_ChangeAddonColumns,
    VIEW3D_OT_manage_areas,
    ST_OT_CommitAutoImportState,
    APPLY_OT_GroupSettings,
    RESET_OT_UIToDefault,
    ST_OT_SetItemState,
    COLUMN_OT_Change,
    ST_OT_ClearSubgroupIcon,
    ST_OT_ClearItemIcon,
    ST_OT_CurveRecalcHandles,
    ST_OT_MeshRecalcNormalsObject,
    ST_OT_MeshFlipNormalsObject,
    #ST_OT_UV_Action,
)