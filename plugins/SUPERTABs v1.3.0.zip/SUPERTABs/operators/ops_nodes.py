import bpy
import json
import math

from mathutils import Vector

def serialize_node_tree(node_tree):
    if not node_tree: return ""
    data = {
        "name": node_tree.name,
        "type": node_tree.bl_idname,
        "inputs": [], "outputs": [], "nodes": [], "links": []
    }
    
    # 1. Interface (Sockets)
    if hasattr(node_tree, "interface"):
        for item in node_tree.interface.items_tree:
            if item.item_type != 'SOCKET': continue
            
            s_type = getattr(item, "socket_type", "NodeSocketFloat")
                
            item_data = {
                "name": item.name, 
                "item_type": item.item_type, 
                "socket_type": s_type
            }
            
            if item.in_out == 'INPUT':
                try:
                    val = item.default_value
                    if isinstance(val, bpy.types.ID):
                        item_data["default_value"] = {"type": "ID", "id_type": type(val).__name__, "name": val.name}
                    elif hasattr(val, "__iter__") and not isinstance(val, str):
                        item_data["default_value"] = {"type": "VECTOR", "value": list(val)}
                    elif isinstance(val, (int, float, str, bool)):
                        item_data["default_value"] = {"type": "VALUE", "value": val}
                except: pass
                
                data["inputs"].append(item_data)
            elif item.in_out == 'OUTPUT':
                data["outputs"].append(item_data)
    else:
        for input in node_tree.inputs: data["inputs"].append({"name": input.name, "type": input.bl_socket_idname})
        for output in node_tree.outputs: data["outputs"].append({"name": output.name, "type": output.bl_socket_idname})
    
    # 2. Nodes
    for node in node_tree.nodes:
        node_data = {
            "name": node.name, 
            "bl_idname": node.bl_idname, 
            "location": (node.location.x, node.location.y),
            "width": node.width, 
            "label": node.label, 
            "properties": {},
            "id_properties": {},
            "socket_values": {}
        }
        
        # 2.1 Save Node Properties (RNA)
        for prop in node.bl_rna.properties:
            if not prop.is_readonly:
                try:
                    val = getattr(node, prop.identifier)
                    if isinstance(val, (int, float, str, bool)): 
                        node_data["properties"][prop.identifier] = val
                    elif isinstance(val, (list, tuple)) and len(val) <= 32: 
                        node_data["properties"][prop.identifier] = list(val)
                    elif isinstance(val, bpy.types.ID):
                        id_type_map = {'Image': 'images', 'Object': 'objects', 'Material': 'materials', 'Collection': 'collections'}
                        type_name = type(val).__name__
                        if type_name in id_type_map:
                            prop_info = {"name": val.name, "data_collection": id_type_map[type_name]}
                            if type_name == 'Image': prop_info["filepath"] = val.filepath
                            node_data["id_properties"][prop.identifier] = prop_info
                except: pass

        # 2.2 Save Socket Default Values (Index-based)
        for i, input in enumerate(node.inputs):
            if not input.is_linked:
                try:
                    val = input.default_value
                    if isinstance(val, bpy.types.ID):
                        node_data["socket_values"][str(i)] = {
                            "type": "ID", "id_type": type(val).__name__, "name": val.name
                        }
                    elif hasattr(val, "__iter__") and not isinstance(val, str):
                        node_data["socket_values"][str(i)] = {
                            "type": "VECTOR", "value": list(val)
                        }
                    elif isinstance(val, (int, float, str, bool)):
                         node_data["socket_values"][str(i)] = {
                            "type": "VALUE", "value": val
                        }
                except: pass

        data["nodes"].append(node_data)
        
    # 3. Links
    for link in node_tree.links:
        link_data = {"from_node": link.from_node.name, "from_socket": link.from_socket.name, "to_node": link.to_node.name, "to_socket": link.to_socket.name}
        for i, out in enumerate(link.from_node.outputs):
            if out == link.from_socket: link_data["from_index"] = i; break
        for i, inp in enumerate(link.to_node.inputs):
            if inp == link.to_socket: link_data["to_index"] = i; break
        data["links"].append(link_data)
        
    return json.dumps(data)

def deserialize_node_tree(data_str):
    try: data = json.loads(data_str)
    except: return None
    
    new_tree = bpy.data.node_groups.new(name=data.get("name", "Imported Group"), type=data.get("type", "GeometryNodeTree"))
    
    id_lookup = {
        'Object': bpy.data.objects, 'Collection': bpy.data.collections,
        'Material': bpy.data.materials, 'Image': bpy.data.images,
        'Texture': bpy.data.textures, 'Action': bpy.data.actions
    }
    
    # 1. Interface
    if hasattr(new_tree, "interface"):
        for inp in data.get("inputs", []):
            if inp.get("item_type") == 'SOCKET': 
                socket = new_tree.interface.new_socket(name=inp["name"], in_out='INPUT', socket_type=inp.get("socket_type", "NodeSocketFloat"))
                
                if "default_value" in inp:
                     dv_data = inp["default_value"]
                     try:
                         val_type = dv_data["type"]
                         if val_type == "ID":
                             id_type = dv_data["id_type"]
                             name = dv_data["name"]
                             if id_type in id_lookup and name in id_lookup[id_type]:
                                 socket.default_value = id_lookup[id_type][name]
                         elif val_type == "VECTOR": socket.default_value = dv_data["value"]
                         elif val_type == "VALUE": socket.default_value = dv_data["value"]
                     except: pass
                     
        for out in data.get("outputs", []):
            if out.get("item_type") == 'SOCKET': 
                new_tree.interface.new_socket(name=out["name"], in_out='OUTPUT', socket_type=out.get("socket_type", "NodeSocketFloat"))
    
    # 2. Nodes
    created_nodes = {}

    for n_data in data["nodes"]:
        try:
            node = new_tree.nodes.new(type=n_data["bl_idname"])
            node.name = n_data["name"]
            node.location = n_data["location"]
            node.width = n_data["width"]
            node.label = n_data["label"]
            
            for prop, val in n_data["properties"].items():
                try: setattr(node, prop, val)
                except: pass
            
            for prop, id_info in n_data.get("id_properties", {}).items():
                try:
                    col = getattr(bpy.data, id_info["data_collection"], None)
                    if col:
                        obj_name = id_info["name"]
                        if obj_name in col: setattr(node, prop, col[obj_name])
                        elif id_info["data_collection"] == 'images' and "filepath" in id_info:
                            try: setattr(node, prop, bpy.data.images.load(id_info["filepath"], check_existing=True))
                            except: pass
                except: pass

            for idx_str, sock_data in n_data.get("socket_values", {}).items():
                try:
                    idx = int(idx_str)
                    if idx < len(node.inputs):
                        socket = node.inputs[idx]
                        val_type = sock_data["type"]
                        if val_type == "ID":
                            id_type = sock_data["id_type"]
                            name = sock_data["name"]
                            if id_type in id_lookup and name in id_lookup[id_type]:
                                socket.default_value = id_lookup[id_type][name]
                        elif val_type == "VECTOR": socket.default_value = sock_data["value"]
                        elif val_type == "VALUE": socket.default_value = sock_data["value"]
                except: pass
            
            created_nodes[n_data["name"]] = node
        except Exception as e: pass
    
    # 3. Links
    for l_data in data["links"]:
        try:
            fn, tn = created_nodes.get(l_data["from_node"]), created_nodes.get(l_data["to_node"])
            if fn and tn:
                fi, ti = l_data.get("from_index", -1), l_data.get("to_index", -1)
                
                if fi != -1 and ti != -1: 
                    try: new_tree.links.new(fn.outputs[fi], tn.inputs[ti])
                    except: 
                        try: new_tree.links.new(fn.outputs[l_data["from_socket"]], tn.inputs[l_data["to_socket"]])
                        except: pass
                else: 
                    try: new_tree.links.new(fn.outputs[l_data["from_socket"]], tn.inputs[l_data["to_socket"]])
                    except: pass
        except: pass
        
    return new_tree

def get_node_statistics(node_tree):
    """Returns (total_nodes, linked_nodes, unlinked_nodes, frames)"""
    if not node_tree:
        return 0, 0, 0, 0
    
    nodes = node_tree.nodes
    total = len(nodes)
    linked_count = 0
    frames = 0
    
    for node in nodes:
        if node.type == 'FRAME':
            frames += 1
            continue

        is_linked = False
        for input_socket in node.inputs:
            if input_socket.is_linked:
                is_linked = True
                break
        
        if not is_linked:
            for output_socket in node.outputs:
                if output_socket.is_linked:
                    is_linked = True
                    break
        
        if is_linked:
            linked_count += 1
            
    unlinked_count = total - linked_count - frames
    return total, linked_count, unlinked_count, frames

class ST_OT_SelectUnlinkedNodes(bpy.types.Operator):
    """Select all nodes that have no connections (Ignoring Frames)"""
    bl_idname = "st.select_unlinked_nodes"
    bl_label = "Select Unlinked Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        space = context.space_data
        tree = getattr(space, 'edit_tree', None)
        if not tree:
            tree = space.node_tree
            
        if not tree:
            self.report({'WARNING'}, "No active node tree.")
            return {'CANCELLED'}
        
        count = 0
        
        for node in tree.nodes:
            node.select = False
            
        for node in tree.nodes:
            if node.type == 'FRAME':
                continue

            is_linked = False
            for input_socket in node.inputs:
                if input_socket.is_linked:
                    is_linked = True
                    break
            if not is_linked:
                for output_socket in node.outputs:
                    if output_socket.is_linked:
                        is_linked = True
                        break
            
            if not is_linked:
                node.select = True
                count += 1
                
        self.report({'INFO'}, f"Selected {count} unlinked nodes.")
        return {'FINISHED'}

class ST_OT_DeleteUnlinkedNodes(bpy.types.Operator):
    """Delete all nodes that have no connections (Ignoring Frames)"""
    bl_idname = "st.delete_unlinked_nodes"
    bl_label = "Delete Unlinked Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        space = context.space_data
        tree = getattr(space, 'edit_tree', None)
        if not tree:
            tree = space.node_tree
            
        if not tree:
            self.report({'WARNING'}, "No active node tree.")
            return {'CANCELLED'}
        
        nodes_to_delete = []
        
        for node in tree.nodes:
            if node.type == 'FRAME':
                continue

            is_linked = False
            for input_socket in node.inputs:
                if input_socket.is_linked:
                    is_linked = True
                    break
            
            if not is_linked:
                for output_socket in node.outputs:
                    if output_socket.is_linked:
                        is_linked = True
                        break
            
            if not is_linked:
                nodes_to_delete.append(node)
        
        count = len(nodes_to_delete)
        
        if count > 0:
            for node in tree.nodes:
                node.select = False
            
            for node in nodes_to_delete:
                node.select = True
            
            bpy.ops.node.delete()
            self.report({'INFO'}, f"Deleted {count} unlinked nodes.")
        else:
            self.report({'INFO'}, "No unlinked nodes found.")
            
        return {'FINISHED'}
    
class ST_OT_PlaceFavoriteNode(bpy.types.Operator):
    """Add this favorite node to the tree"""
    bl_idname = "st.place_favorite_node"
    bl_label = "Place Node"
    bl_options = {'REGISTER', 'UNDO'}

    node_idname: bpy.props.StringProperty()
    fav_index: bpy.props.IntProperty(default=-1)

    def execute(self, context):
        space = context.space_data
        if not space.node_tree:
            self.report({'WARNING'}, "No active node tree.")
            return {'CANCELLED'}

        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        if self.fav_index >= 0 and self.fav_index < len(prefs.favorite_nodes):
            item = prefs.favorite_nodes[self.fav_index]
            if getattr(item, "is_group", False) and getattr(item, "serialized_data", ""):
                imported_tree = deserialize_node_tree(item.serialized_data)
                if imported_tree:
                    bpy.ops.node.add_node('INVOKE_DEFAULT', type=self.node_idname, use_transform=True)
                    if context.active_node:
                        context.active_node.node_tree = imported_tree
                        context.active_node.label = item.label
                    return {'FINISHED'}

        bpy.ops.node.add_node('INVOKE_DEFAULT', type=self.node_idname, use_transform=True)
        return {'FINISHED'}

class ST_OT_AddNodeToFavorites(bpy.types.Operator):
    """Add selected node to Supertabs Favorites (Groups Supported)"""
    bl_idname = "st.add_node_to_favorites"
    bl_label = "Add to Supertabs Favorites"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        return context.active_node is not None and context.active_node.select

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        node = context.active_node
        node_id = node.bl_idname 
        tree_type = context.space_data.tree_type
        
        if node.type == 'GROUP' and node.node_tree:
            label_to_save = node.node_tree.name
        else:
            label_to_save = node.label if node.label else node.name

        for item in prefs.favorite_nodes:
            if item.label == label_to_save and item.tree_type == tree_type:
                self.report({'WARNING'}, f"'{label_to_save}' is already in favorites.")
                return {'CANCELLED'}

        new_item = prefs.favorite_nodes.add()
        new_item.node_idname = node_id
        new_item.label = label_to_save
        new_item.tree_type = tree_type

        if node.type == 'GROUP' and node.node_tree:
            try:
                new_item.serialized_data = serialize_node_tree(node.node_tree)
                new_item.is_group = True
                self.report({'INFO'}, f"Added Group '{label_to_save}' to favorites.")
            except Exception as e:
                print(f"Serialize Error: {e}")
                self.report({'WARNING'}, f"Group added but serialization failed: {e}")
        else:
            self.report({'INFO'}, f"Added '{label_to_save}' to favorites.")

        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type == 'NODE_EDITOR':
                    area.tag_redraw()

        return {'FINISHED'}

class ST_OT_RemoveFavoriteNode(bpy.types.Operator):
    """Remove node from favorites"""
    bl_idname = "st.remove_favorite_node"
    bl_label = "Remove Favorite Node"
    bl_options = {'REGISTER'}

    index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.favorite_nodes.remove(self.index)
        return {'FINISHED'}

class ST_OT_ResetNodeZoom(bpy.types.Operator):
    """Reset Zoom to 100% (Standard View)"""
    bl_idname = "st.reset_node_zoom"
    bl_label = "Reset Zoom"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        node_area = context.area
        
        if not node_area or not node_area.spaces.active.node_tree:
            self.report({'WARNING'}, "No active Node Editor or Node Tree found")
            return {'CANCELLED'}

        win_region = next((r for r in node_area.regions if r.type == 'WINDOW'), None)
        
        if win_region:
            with context.temp_override(
                area=node_area, 
                region=win_region, 
                space_data=node_area.spaces.active
            ):
                try:
                    bpy.ops.node.view_all()
                except RuntimeError as e:
                    self.report({'ERROR'}, f"View All failed: {e}")
                    return {'CANCELLED'}
                
            try:
                addon_id = __package__.split('.')[0]
                prefs = context.preferences.addons[addon_id].preferences
                prefs.node_zoom_slider = 1.0
                prefs.node_zoom_prev = 1.0
            except Exception:
                pass
        else:
            self.report({'WARNING'}, "Could not find WINDOW region to zoom")
            return {'CANCELLED'}
        
        return {'FINISHED'}
    
class ST_OT_FocusAndZoom(bpy.types.Operator):
    """Focus on selected nodes and zoom in closer, or just Zoom In/Out.
    Shift + Click to open settings."""
    bl_idname = "st.focus_and_zoom"
    bl_label = "Focus & Zoom Settings"
    bl_options = {'REGISTER'}

    mode: bpy.props.EnumProperty(items=[('IN', "In", ""), ('OUT', "Out", "")], default='IN')

    def invoke(self, context, event):
        if event.shift:
            return context.window_manager.invoke_props_dialog(self, width=250)
        return self.execute(context)

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        DEFAULT_VAL = 35
        
        is_unsaved = (prefs.zoom_strength_in_factor != prefs.zoom_strength_in_saved) or \
                     (prefs.zoom_strength_out_factor != prefs.zoom_strength_out_saved)

        is_not_default = (prefs.zoom_strength_in_factor != DEFAULT_VAL) or \
                         (prefs.zoom_strength_out_factor != DEFAULT_VAL)

        box = layout.box()
        col = box.column(align=True)
        
        if is_unsaved:
            col_actions = col.column()
            row_actions = col_actions.row(align=True)
            
            row_alert = row_actions.row(align=True)
            row_alert.alert = True
            row_alert.label(text="Changes not saved!", icon='ERROR')
            
            row_btn = row_actions.row(align=True)
            row_btn.scale_x = 0.7
            row_btn.operator("st.save_zoom_settings", text="Save", icon='FILE_TICK')
        
            col.separator()

        # --- Sliders ---
        col.prop(prefs, "zoom_strength_in_factor", text="In Strength")
        col.prop(prefs, "zoom_strength_out_factor", text="Out Strength")

        # --- Action Row ---
        if is_not_default:
            col.separator()

            col_actions = col.column()
            row_actions = col_actions.row(align=True)
            row_actions.scale_y = 1.2
            row_actions.separator(factor=0.5)
            row_actions.alert = True
            row_actions.operator("st.reset_zoom_settings", text="Reset Default", icon='LOOP_BACK')
            
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        MIN_IN, MAX_IN = 100, 3000
        MIN_OUT, MAX_OUT = 100, 1200

        factor_in = prefs.zoom_strength_in_factor / 100.0
        factor_out = prefs.zoom_strength_out_factor / 100.0

        raw_in = MIN_IN + (factor_in * (MAX_IN - MIN_IN))
        raw_out = MIN_OUT + (factor_out * (MAX_OUT - MIN_OUT))

        EXTRA_ZOOM_STRENGTH = int(raw_in)
        STEP_ZOOM_STRENGTH = int(raw_in)
        OUT_ZOOM_STRENGTH = int(raw_out)
 
        win_region = None
        for region in context.area.regions:
            if region.type == 'WINDOW':
                win_region = region
                break
        
        if not win_region:
            return {'CANCELLED'}

        has_selection = False
        space = context.space_data
        if space.type == 'NODE_EDITOR' and space.node_tree:
            for node in space.node_tree.nodes:
                if node.select:
                    has_selection = True
                    break

        with context.temp_override(area=context.area, region=win_region, screen=context.screen):
            try:
                if self.mode == 'IN':
                    if has_selection:
                        bpy.ops.node.view_selected()
                        bpy.ops.view2d.zoom(
                            deltax=EXTRA_ZOOM_STRENGTH, 
                            deltay=EXTRA_ZOOM_STRENGTH, 
                            use_cursor_init=False
                        )
                    else:
                        bpy.ops.view2d.zoom(
                            deltax=STEP_ZOOM_STRENGTH, 
                            deltay=STEP_ZOOM_STRENGTH, 
                            use_cursor_init=False
                        )
                else:
                    bpy.ops.view2d.zoom(
                        deltax=-OUT_ZOOM_STRENGTH, 
                        deltay=-OUT_ZOOM_STRENGTH, 
                        use_cursor_init=False
                    )
            except Exception as e:
                self.report({'WARNING'}, f"Zoom Error: {e}")
        
        return {'FINISHED'}

class ST_OT_NodeAlign(bpy.types.Operator):
    """Align selected nodes along X or Y axis"""
    bl_idname = "st.node_align"
    bl_label = "Align Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(items=[('X', "X", ""), ('Y', "Y", "")])

    def execute(self, context):
        space = context.space_data
        if not space.node_tree: return {'CANCELLED'}
        
        selected_nodes = [n for n in space.node_tree.nodes if n.select]
        if len(selected_nodes) < 2: return {'CANCELLED'}

        avg = 0.0
        for n in selected_nodes:
            avg += n.location.x if self.axis == 'X' else n.location.y
        avg /= len(selected_nodes)

        for n in selected_nodes:
            if self.axis == 'X':
                n.location.x = avg 
            else:
                n.location.y = avg 
                
        return {'FINISHED'}
class ST_OT_NodeDistribute(bpy.types.Operator):
    """Distribute selected nodes evenly along an axis"""
    bl_idname = "st.node_distribute"
    bl_label = "Distribute Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    axis: bpy.props.EnumProperty(items=[('X', "X", ""), ('Y', "Y", "")])

    def execute(self, context):
        space = context.space_data
        if not space.node_tree: return {'CANCELLED'}
        
        selected_nodes = [n for n in space.node_tree.nodes if n.select]
        if len(selected_nodes) < 3: return {'CANCELLED'}

        if self.axis == 'X':
            selected_nodes.sort(key=lambda n: n.location.x)
            start = selected_nodes[0].location.x
            end = selected_nodes[-1].location.x
        else:
            selected_nodes.sort(key=lambda n: n.location.y)
            start = selected_nodes[0].location.y
            end = selected_nodes[-1].location.y

        total_dist = end - start
        step = total_dist / (len(selected_nodes) - 1)

        for i, n in enumerate(selected_nodes):
            new_pos = start + (step * i)
            if self.axis == 'X':
                n.location.x = new_pos
            else:
                n.location.y = new_pos
                
        return {'FINISHED'}
class ST_OT_NodeRotate(bpy.types.Operator):
    """Rotate selected nodes positions around their median center"""
    bl_idname = "st.node_rotate"
    bl_label = "Rotate Nodes"
    bl_options = {'REGISTER', 'UNDO'}

    angle: bpy.props.FloatProperty(name="Angle (Degrees)", default=90.0)

    def execute(self, context):
        space = context.space_data
        if not space.node_tree: return {'CANCELLED'}
        
        selected_nodes = [n for n in space.node_tree.nodes if n.select]
        if len(selected_nodes) < 2: return {'CANCELLED'}

        center = Vector((0.0, 0.0))
        for n in selected_nodes:
            center += n.location
        center /= len(selected_nodes)

        rad = math.radians(self.angle)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)

        for n in selected_nodes:
            local_x = n.location.x - center.x
            local_y = n.location.y - center.y
            
            rot_x = local_x * cos_a - local_y * sin_a
            rot_y = local_x * sin_a + local_y * cos_a
            
            n.location.x = center.x + rot_x
            n.location.y = center.y + rot_y
            
        return {'FINISHED'}

class ST_OT_SelectEmptyFrames(bpy.types.Operator):
    """Select frames that have no nodes inside them"""
    bl_idname = "st.select_empty_frames"
    bl_label = "Select Empty Frames"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        space = context.space_data
        tree = getattr(space, 'edit_tree', None)
        if not tree:
            tree = space.node_tree
            
        if not tree:
            self.report({'WARNING'}, "No active node tree.")
            return {'CANCELLED'}
        
        all_frames = {n for n in tree.nodes if n.type == 'FRAME'}
        
        used_frames = set()
        for node in tree.nodes:
            if node.parent:
                used_frames.add(node.parent)
        
        empty_frames = all_frames - used_frames
        
        if not empty_frames:
            self.report({'INFO'}, "No empty frames found.")
            return {'FINISHED'}

        for node in tree.nodes:
            node.select = False
            
        count = 0
        for frame in empty_frames:
            frame.select = True
            count += 1
            
        self.report({'INFO'}, f"Selected {count} empty frames.")
        return {'FINISHED'}

class ST_OT_DeleteEmptyFrames(bpy.types.Operator):
    """Delete frames that have no nodes inside them"""
    bl_idname = "st.delete_empty_frames"
    bl_label = "Delete Empty Frames"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        space = context.space_data
        tree = getattr(space, 'edit_tree', None)
        if not tree:
            tree = space.node_tree
            
        if not tree:
            self.report({'WARNING'}, "No active node tree.")
            return {'CANCELLED'}

        all_frames = {n for n in tree.nodes if n.type == 'FRAME'}
        used_frames = set()
        for node in tree.nodes:
            if node.parent:
                used_frames.add(node.parent)
        
        empty_frames = all_frames - used_frames
        
        if not empty_frames:
            self.report({'INFO'}, "No empty frames found.")
            return {'FINISHED'}

        for node in tree.nodes:
            node.select = False
            
        for frame in empty_frames:
            frame.select = True
            
        count = len(empty_frames)
        bpy.ops.node.delete()
        
        self.report({'INFO'}, f"Deleted {count} empty frames.")
        return {'FINISHED'}

class ST_OT_ClearFavoriteNodes(bpy.types.Operator):
    """Remove all nodes from favorites"""
    bl_idname = "st.clear_favorite_nodes"
    bl_label = "Clear All Favorites"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        if len(prefs.favorite_nodes) > 0:
            prefs.favorite_nodes.clear()
            self.report({'INFO'}, "All favorite nodes cleared.")
            
            for window in context.window_manager.windows:
                for area in window.screen.areas:
                    if area.type == 'NODE_EDITOR':
                        area.tag_redraw()
        else:
            self.report({'INFO'}, "Favorites list is already empty.")
        
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)
    
class ST_OT_CollapseAllUnused(bpy.types.Operator):
    """Toggle collapse unused sockets (Smart: Selected Only OR All)"""
    bl_idname = "st.collapse_all_unused"
    bl_label = "Collapse Unused Sockets"
    bl_options = {'REGISTER', 'UNDO'}

    @classmethod
    def poll(cls, context):
        return context.space_data.type == 'NODE_EDITOR' and context.space_data.node_tree

    def execute(self, context):
        tree = context.space_data.node_tree
        nodes = tree.nodes
        
        selected_nodes = [n for n in nodes if n.select]
        
        if selected_nodes:
            target_nodes = selected_nodes
            mode_msg = "Selected Nodes"
        else:
            target_nodes = nodes
            mode_msg = "All Nodes"

        should_hide = False
        
        for node in target_nodes:
            if not hasattr(node, "inputs"):
                continue     
            for socket in node.inputs:
                if not socket.is_linked and not socket.hide:
                    should_hide = True
                    break
            if should_hide:
                break
        
        count_processed = 0
        for node in target_nodes:
            if not hasattr(node, "inputs"):
                continue
            
            for socket in node.inputs:
                if not socket.is_linked:
                    socket.hide = should_hide
                    if hasattr(socket, "hide_value"): 
                        socket.hide_value = should_hide
            
            count_processed += 1
            
        action_text = "Hidden" if should_hide else "Shown"
        self.report({'INFO'}, f"{action_text} Unused Sockets ({mode_msg}: {count_processed})")
        
        context.area.tag_redraw()
        
        return {'FINISHED'}

class ST_OT_SetFavNodeIcon(bpy.types.Operator):
    """Set the icon for a favorite node"""
    bl_idname = "st.set_fav_node_icon"
    bl_label = "Set Icon"
    bl_options = {'INTERNAL'}

    fav_index: bpy.props.IntProperty()
    icon_name: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.fav_index < len(prefs.favorite_nodes):
            prefs.favorite_nodes[self.fav_index].icon = self.icon_name
            context.area.tag_redraw()
        return {'FINISHED'}

class ST_OT_SetFavNodeIconPopup(bpy.types.Operator):
    """Popup to select icon for favorite node"""
    bl_idname = "st.set_fav_node_icon_popup"
    bl_label = "Select Icon"
    bl_options = {'REGISTER', 'INTERNAL'}
    
    
    fav_index: bpy.props.IntProperty()

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=400)

    def draw(self, context):
        layout = self.layout
        grid = layout.grid_flow(row_major=True, columns=8, even_columns=True, align=True)
        
        try:
            from ..properties.items import _restricted_node_socket_icons
        except ImportError:
            layout.label(text="Error: Cannot load icons", icon='ERROR')
            return

        for icon in _restricted_node_socket_icons:
            op = grid.operator("st.set_fav_node_icon", text="", icon=icon)
            op.fav_index = self.fav_index
            op.icon_name = icon

class ST_OT_ResetZoomSettings(bpy.types.Operator):
    """Reset Zoom Strength to defaults and Save Preferences"""
    bl_idname = "st.reset_zoom_settings"
    bl_label = "Reset Defaults"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        DEFAULT_VAL = 35

        prefs.zoom_strength_in_factor = DEFAULT_VAL
        prefs.zoom_strength_out_factor = DEFAULT_VAL
        
        prefs.zoom_strength_in_saved = DEFAULT_VAL
        prefs.zoom_strength_out_saved = DEFAULT_VAL
        
        bpy.ops.wm.save_userpref()
        
        self.report({'INFO'}, "Zoom settings reset and saved.")
        return {'FINISHED'}

class ST_OT_SaveZoomSettings(bpy.types.Operator):
    """Save current zoom settings as default"""
    bl_idname = "st.save_zoom_settings"
    bl_label = "Save Settings"
    bl_options = {'REGISTER', 'INTERNAL'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        prefs.zoom_strength_in_saved = prefs.zoom_strength_in_factor
        prefs.zoom_strength_out_saved = prefs.zoom_strength_out_factor
        
        bpy.ops.wm.save_userpref()
        
        self.report({'INFO'}, "Zoom settings saved.")
        return {'FINISHED'}
    
classes = (
    ST_OT_SaveZoomSettings,
    ST_OT_ResetZoomSettings,
    ST_OT_SetFavNodeIcon,
    ST_OT_SetFavNodeIconPopup,
    ST_OT_SelectUnlinkedNodes,
    ST_OT_DeleteUnlinkedNodes,
    ST_OT_PlaceFavoriteNode,
    ST_OT_AddNodeToFavorites,
    ST_OT_RemoveFavoriteNode,
    ST_OT_ResetNodeZoom,
    ST_OT_FocusAndZoom,
    ST_OT_NodeAlign,
    ST_OT_NodeDistribute,
    ST_OT_NodeRotate,
    ST_OT_SelectEmptyFrames,
    ST_OT_DeleteEmptyFrames,
    ST_OT_ClearFavoriteNodes,
    ST_OT_CollapseAllUnused,
)