from . import group_management
from . import visibility
from . import favorites
from . import addon_presets
from . import ops_io
from . import popovers
from . import general
from . import ops_nodes

classes = (
    *group_management.classes,
    *visibility.classes,
    *favorites.classes,
    *addon_presets.classes,
    *ops_io.classes,
    *popovers.classes,
    *general.classes,
    *ops_nodes.classes
)