import bpy
import os
import addon_utils
from ..ui.manager import draw_addon_list_ui
from ..properties import AvailableItem
from collections import defaultdict

class ST_OT_OpenEjectedItemsPopover(bpy.types.Operator):
    bl_idname = "st.open_ejected_items_popover"
    bl_label = "Show Ejected Items"
    def execute(self, context):
        bpy.ops.wm.call_panel(name="ST_PT_EjectedItemsPopover", keep_open=True)
        return {'FINISHED'}

class ST_OT_OpenEjectedSubgroupsPopover(bpy.types.Operator):
    bl_idname = "st.open_ejected_subgroups_popover"
    bl_label = "Manage Ejected TabsGroups"
    def execute(self, context):
        bpy.ops.wm.call_panel(name="ST_PT_EjectedSubgroupsPopover", keep_open=True)
        return {'FINISHED'}

class ST_OT_OpenHiddenSubgroupsPopover(bpy.types.Operator):
    """Show Hidden Tabs or Tabsgroup """
    bl_idname = "st.open_hidden_subgroups_popover"
    bl_label = "Manage Hidden TabsGroups"
    def execute(self, context):
        bpy.ops.wm.call_panel(name="ST_PT_HiddenSubgroupsPopover", keep_open=True)
        return {'FINISHED'}

class ST_OT_OpenHiddenItemsPopover(bpy.types.Operator):
    bl_idname = "st.open_hidden_items_popover"
    bl_label = "Manage Hidden Items"
    def execute(self, context):
        bpy.ops.wm.call_panel(name="ST_PT_HiddenItemsPopover", keep_open=True)
        return {'FINISHED'}
    
class ST_OT_ToggleDisplaySettings(bpy.types.Operator):
    """Supertabs N-Panel Display Setup"""
    bl_idname = "st.toggle_display_settings"
    bl_label = "Open Display Settings"
    bl_options = {'REGISTER'}
    def execute(self, context):
        if context.area.type == 'IMAGE_EDITOR':
            if context.space_data.mode == 'UV':
                bpy.ops.wm.call_panel(name="ST_PT_DisplaySettingsPopup_UV", keep_open=True)
            else:
                bpy.ops.wm.call_panel(name="ST_PT_DisplaySettingsPopup_Image", keep_open=True)
        elif context.area.type == 'NODE_EDITOR':
            bpy.ops.wm.call_panel(name="ST_PT_DisplaySettingsPopup_Node", keep_open=True)
        else:
            bpy.ops.wm.call_panel(name="ST_PT_DisplaySettingsPopup", keep_open=True)
        return {'FINISHED'}

class ST_OT_OpenAddonPresetManager(bpy.types.Operator):
    """Opens the Addon Preset management panel."""
    bl_idname = "st.open_addon_preset_manager"
    bl_label = "Open Addon Presets"

    def execute(self, context):
        bpy.ops.wm.call_panel(name="ST_PT_AddonPresetManager", keep_open=True)
        return {'FINISHED'}

class ST_OT_CallAddToPresetMenu(bpy.types.Operator):
    """Sets context and calls the 'Add to Preset' menu."""
    bl_idname = "st.call_add_to_preset_menu"
    bl_label = "Add to Preset"
    bl_options = {'REGISTER'}

    addon_name: bpy.props.StringProperty()

    def execute(self, context):
        context.window_manager.st_addon_name_to_add = self.addon_name
        bpy.ops.wm.call_menu(name="ST_MT_AddToPresetMenu")
        return {'FINISHED'}

class ST_PT_purgedata_menu(bpy.types.Operator):
    bl_label = "Clean Data"
    bl_idname = "st.pt_purgedata_menu"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):

        layout = self.layout
        
        op_simple = layout.operator("outliner.orphans_purge", text="Purge All (Simple)", icon='ORPHAN_DATA')
        if op_simple:
            op_simple.do_recursive = False

        op_recursive = layout.operator("outliner.orphans_purge", text="Purge All (Recursive)", icon='FILE_REFRESH')
        if op_recursive:
            op_recursive.do_recursive = True

class ST_OT_CavityPopover(bpy.types.Operator):
    """Operator to show Cavity settings in a popup"""
    bl_idname = "st.cavity_popover"
    bl_label = "Cavity Overlay"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        shading = context.space_data.shading

        col.prop(shading,'show_cavity', text="Show Cavity",icon="OVERLAY", toggle=True)
        col.separator()
        act_col = col.column()
        act_col.enabled = shading.show_cavity
        act_col.prop(shading, 'cavity_type', text=" ", expand=True)
        
        if shading.cavity_type in {'SCREEN', 'BOTH'}:
            box_screen = act_col.box()
            col_screen = box_screen.column()
            col_screen.label(text='Screen Space')
            col_screen.prop(shading, 'curvature_ridge_factor', text='Ridge')
            col_screen.prop(shading, 'curvature_valley_factor', text='Valley')

        if shading.cavity_type in {'WORLD', 'BOTH'}:
            box_world = act_col.box()
            col_world = box_world.column()
            col_world.label(text='World Space')
            col_world.prop(shading, 'cavity_ridge_factor', text='Ridge')
            col_world.prop(shading, 'cavity_valley_factor', text='Valley')

class ST_OT_WireframePopover(bpy.types.Operator):
    """Operator to show Wireframe settings in a popup"""
    bl_idname = "st.wireframe_popover"
    bl_label = "Wireframe Overlay"
    
    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        overlay = context.space_data.overlay

        
        col.prop(overlay,'show_wireframes', text="Show Wireframe", icon="MOD_WIREFRAME", toggle=True)
        col.separator()
        act_col = col.column()
        act_col.enabled = overlay.show_wireframes
        act_col.prop(overlay, 'cavity_type', text='', emboss=True)
        act_col.prop(overlay, "wireframe_threshold", text="Wireframe")
        act_col.prop(overlay, "wireframe_opacity", text="Opacity")

class ST_OT_OpenSuperTabsManager(bpy.types.Operator):
    """Operator to show the SUPERTABs Add-ons Manager in a popup"""
    bl_idname = "st.open_supertabs_manager"
    bl_label = "SUPERTABs Add-ons Manager"

    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.addon_search_query = ""
        width_in_pixels = int(prefs.hotkey_popup_width * 10 * context.preferences.system.ui_scale)
        return context.window_manager.invoke_props_dialog(self, width=width_in_pixels)

    def execute(self, context):
        return {'FINISHED'}

    def draw(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        layout = self.layout
        
        box = layout.box()
        settings_row = box.row(align=True)
        op_1 = settings_row.operator("st.set_hotkey_popover_width", text="75")
        op_1.target_width = 75
        op_2 = settings_row.operator("st.set_hotkey_popover_width", text="100")
        op_2.target_width = 100
        op_3 = settings_row.operator("st.set_hotkey_popover_width", text="125")
        op_3.target_width = 125
        op_4 = settings_row.operator("st.set_hotkey_popover_width", text="150")
        op_4.target_width = 150
        
        settings_row.separator(factor=0.5)

        slider_row = settings_row.row(align=True)
        slider_row.prop(prefs, "hotkey_popup_width", text="Popup Width:", slider=True)

        settings_row.separator(factor=0.25)

        split_row = settings_row.row(align=True)
        split_row.prop(prefs, "favorite_column_split_factor", text="Favorites Split", slider=True)

        settings_row.separator(factor=0.5)

        ins_row = settings_row.row(align=True)
        ins_row.scale_x = 1.3
        ins_row.popover(panel="ST_PT_AddonManagerUtilsPopover", text="", icon='TEXT')

        draw_addon_list_ui(self.layout, context)

class ST_OT_CallMoveItemMenu(bpy.types.Operator):
    """Sets context and calls the 'Move Item' menu."""
    bl_idname = "st.call_move_item_menu"
    bl_label = "Move Item to..."
    bl_options = {'REGISTER'}

    item_to_move: bpy.props.StringProperty()
    source_group_index: bpy.props.IntProperty()

    def execute(self, context):
        context.window_manager.st_item_to_move = self.item_to_move
        context.window_manager.st_source_group_index_for_move = self.source_group_index
        bpy.ops.wm.call_menu(name="ST_MT_MoveItemMenu")
        return {'FINISHED'}
class ST_OT_CallMoveSubgroupMenu(bpy.types.Operator):
    """Sets context and calls the 'Move Subgroup' menu."""
    bl_idname = "st.call_move_subgroup_menu"
    bl_label = "Move Subgroup to..."
    bl_options = {'REGISTER'}

    subgroup_index: bpy.props.IntProperty()

    def execute(self, context):
        context.window_manager.st_subgroup_index_to_move = self.subgroup_index
        bpy.ops.wm.call_menu(name="ST_MT_MoveSubgroupMenu")
        return {'FINISHED'}

class ST_OT_ViewportOverlayPopover(bpy.types.Operator):
    """Operator to show Viewport Shading&Overlay Options in a popup"""
    bl_idname = "st.viewportoverlay_popover"
    bl_label = "Viewport Shading&Overlay"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column()
        
        shading = context.space_data.shading
        overlay = context.space_data.overlay
        space_data = context.space_data
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences 
        row = col.row(align=True)
        row.prop(overlay,'show_wireframes', text="Wireframe", icon="MOD_WIREFRAME", toggle=True)
        if overlay.show_wireframes:
            wire_box = col.box()
            wire_col = wire_box.column(align=True)
            wire_col.prop(overlay, "wireframe_threshold", text="Wireframe")
            wire_col.prop(overlay, "wireframe_opacity", text="Opacity")

        row.prop(shading,'show_cavity', text="Cavity", icon="OVERLAY", toggle=True)
        
        if shading.show_cavity:
            act_box = col.box()
            act_col = act_box.column()
            act_col.prop(shading, 'cavity_type', text=" ", expand=True)
            
            if shading.cavity_type in {'SCREEN', 'BOTH'}:
                box_screen = act_col.box()
                col_screen = box_screen.column()
                col_screen.label(text='Screen Space')
                col_screen.prop(shading, 'curvature_ridge_factor', text='Ridge')
                col_screen.prop(shading, 'curvature_valley_factor', text='Valley')

            if shading.cavity_type in {'WORLD', 'BOTH'}:
                box_world = act_col.box()
                col_world = box_world.column()
                col_world.label(text='World Space')
                col_world.prop(shading, 'cavity_ridge_factor', text='Ridge')
                col_world.prop(shading, 'cavity_valley_factor', text='Valley')
        
        col.separator(factor=0.3)
        row = col.row(align=True)
        row.operator("st.toggle_clean_view",text="Clean View",icon='BRUSH_DATA',depress=bool(prefs.pre_clean_overlay_state) )
        row.prop(prefs, "show_object_names_all",text="Object Name(All)", icon='OBJECT_DATAMODE', toggle=True)
        col.separator(factor=0.3)

        row = col.row(align=True)
        row.prop(shading,'show_xray', text="X-Ray", toggle=True)
        if shading.show_xray:
            col.prop(shading,'xray_alpha', text="Opacity")
        row.prop(shading,'show_shadows', text="Shadow", toggle=True)
        if shading.show_shadows:
            col.prop(shading,'shadow_intensity', text="Shadow Intensity")
        row.prop(shading,'use_dof', text="Depth of Field",icon ="CHECKBOX_HLT" if shading.use_dof else "CHECKBOX_DEHLT" , toggle=True)
        
        row = col.row(align=True)
        box = row.box()
        main_col = box.column(align=True)
        main_col.prop(prefs, "show_viewport_overlay", text="ViewportOverlay", icon="TRIA_DOWN" if prefs.show_viewport_overlay else "TRIA_RIGHT", emboss=False)
        if prefs.show_viewport_overlay:
            col = box.column()
            row = col.row(align=True)
            row.prop(space_data, "show_gizmo", text="", icon="GIZMO")
            row.prop(overlay, "grid_scale", text="Grid Scale")

            split_box = col.split(align=True, factor=0.5)
            split_row = split_box.row(align=True)
            split_row.prop(overlay, "show_floor", text="Floor", toggle=True)
            split_row = split_box.row(align=True)
            split_row.label(text="Axes:")
            split_row.prop(overlay, "show_axis_x", text="X", toggle=True)
            split_row.prop(overlay, "show_axis_y", text="Y", toggle=True)
            split_row.prop(overlay, "show_axis_z", text="Z", toggle=True)

            row = col.row(align=True)
            row.prop(overlay, "show_text", text="Text Info", toggle=True)
            row.prop(overlay, "show_cursor", text="3DCursor", toggle=True)
            row.prop(overlay, "show_annotation", text="Annotations", toggle=True)

            col.label(text="Objects:")
            split = col.split(factor=0.5, align=True)
            left_split = split.column(align=True)
            left_split.prop(overlay, "show_extras", text="Extra")
            left_split.prop(overlay, "show_light_colors", text="Light Colors")
            left_split.prop(overlay, "show_relationship_lines", text="Relationship Lines")
            left_split.prop(overlay, "show_outline_selected", text="Outline Selected")
            right_split = split.column(align=True)
            right_split.prop(overlay, "show_bones", text="Bones")
            right_split.prop(overlay, "show_motion_paths", text="Motion Paths")
            right_split.prop(overlay, "show_object_origins", text="Origins")
            col_enabled = right_split.column(align=True)
            if overlay.show_object_origins:
                col_enabled.prop(overlay, "show_object_origins_all", text="All Origins")

class ST_OT_Normal_Edit_Overlay_Popover(bpy.types.Operator):
    """Operator to show Mesh Edit Overlay in a popup"""
    bl_idname = "st.normal_edit_overlay_popover"
    bl_label = "Normal Overlay"
    
    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        obj = context.object
        layout = self.layout
        space = context.space_data
        overlay = space.overlay
        col = layout.column()

        if not obj:
            col.label(text="No Selected Object")
        
        elif obj.type == 'MESH':
            row = col.row(align=True)
            row.prop(overlay, 'show_faces', text="Faces", toggle=True)
            row.prop(overlay, 'show_face_center', text="Center", toggle=True)
            row = col.row(align=True)
            row.prop(overlay, 'show_edge_crease', text="Creases", toggle=True)
            row.prop(overlay, 'show_edge_sharp', text="Sharps", toggle=True)
            row.prop(overlay, 'show_edge_bevel_weight', text="Bevel", toggle=True)
            row.prop(overlay, 'show_edge_seams', text="Seams", toggle=True)
            
            box = col.box()
            row = box.row(align=True)
            row.prop(overlay, 'show_vertex_normals', text="", icon="NORMALS_VERTEX", toggle=True)
            row.prop(overlay, 'show_split_normals', text="", icon="NORMALS_VERTEX_FACE", toggle=True)
            row.prop(overlay, 'show_face_normals', text="", icon="NORMALS_FACE", toggle=True)
            normals_enabled = (
                overlay.show_vertex_normals or
                overlay.show_split_normals or
                overlay.show_face_normals
            )
            dis_row = row.row(align=True)
            dis_row.enabled = normals_enabled
            dis_row.prop(overlay, 'normals_length', text="Size")
            en_row = row.row(align=True)
            en_row.prop(overlay, 'use_normals_constant_screen_size', text="", icon="FIXED_SIZE", toggle=True)
            
            freestyle_row = box.row(align=True)
            freestyle_row.prop(overlay, 'show_freestyle_edge_marks', text="Edge Marks")
            freestyle_row.prop(overlay, 'show_freestyle_face_marks', text="Face Marks")

        elif obj.type == 'CURVE':
            box = col.box()
            row = box.row(align=True)
            row.prop(overlay, 'display_handle', text=" ", expand=True)
            row = box.row(align=True)
            row.prop(overlay, 'show_curve_normals', text="")
            en_row = row.row(align=True)
            en_row.enabled = overlay.show_curve_normals
            en_row.prop(overlay, 'normals_length', text="Normal")

class ST_OT_Render_Popover(bpy.types.Operator):
    """Operator to show Render settings in a popup"""
    bl_idname = "st.render_popover"
    bl_label = "Render Settings"
    
    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        eevee = context.scene.eevee
        cycles = context.scene.cycles
        render = context.scene.render

        col.prop(render, 'filepath', text="Output Path")
        col.separator()

        row = col.row(align=True)
        row.prop(render, 'engine', text="Engine", expand=True)

        if context.scene.render.engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'}:
            col.separator()
            row = col.row(align=True)
            row.prop(eevee, 'taa_samples', text="Viewport")
            row.prop(eevee, 'taa_render_samples', text="Render")

        elif context.scene.render.engine == 'CYCLES':
            row = col.row(align=True)
            row.prop(cycles, 'device', text="Device", expand=True)
            col.separator()
            row = col.row(align=True)
            row.prop(cycles, 'preview_samples', text="Viewport")
            row.prop(cycles, 'samples', text="Render")

        split = col.split(align=True, factor=0.8)
        row = split.row(align=True)
        row.prop(render, 'resolution_x', text="Resolution X")
        row.prop(render, 'resolution_y', text="Resolution Y")
        split.prop(render, 'resolution_percentage', text="Percentage")

        col.separator()

        if context.scene.render.engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'}:

            row = col.row(align=True)
            row.prop(eevee, 'use_taa_reprojection', text="Temporal Reprojection")
            row.prop(eevee, 'use_shadow_jitter_viewport', text="Jittered Shadows")
            col.separator()

        elif context.scene.render.engine == 'CYCLES':
            
            row = col.row(align=True)
            row.prop(cycles, 'caustics_refractive', text="Refractive")
            row.prop(cycles, 'caustics_reflective', text="Reflective")
            col.separator()

        row = col.row(align=True)
        row.prop(render, 'use_border', text="Render Region", icon = "CHECKBOX_HLT" if render.use_border else "CHECKBOX_DEHLT", toggle=True)

        if render.use_border:
            row.prop(render, 'use_crop_to_border', text="Crop to Render Region", icon = "CHECKBOX_HLT" if render.use_crop_to_border else "CHECKBOX_DEHLT", toggle=True)

        if context.scene.render.engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'}:
            col.prop(render, 'film_transparent', text="World Transparent", icon='WORLD', toggle=True)

        elif context.scene.render.engine == 'CYCLES':
            col.prop(render, 'film_transparent', text="World Transparent", icon='WORLD', toggle=True)
            if render.film_transparent:
                col.separator()
                row = col.row(align=True)
                row.prop(context.scene.cycles, 'film_transparent_glass', text="Transparent Glass")
                row_enabled = row.row(align=True)
                row_enabled.enabled = context.scene.cycles.film_transparent_glass
                row_enabled.prop(context.scene.cycles, 'film_transparent_roughness', text="Roughness Threshold")

            col.separator()

            row = col.row(align=True)   
            row.prop(cycles, 'use_auto_tile', text="Use Tilling", icon = "CHECKBOX_HLT" if cycles.use_auto_tile else "CHECKBOX_DEHLT", toggle=True)
            if cycles.use_auto_tile:
                row = col.row(align=True)
                row.prop(cycles, 'tile_size', text="Tile Size")

class ST_OT_ViewportDisplayPopover(bpy.types.Operator):
    """Operator to show Object-specific Display & Visibility settings in a popup"""
    bl_idname = "st.viewport_display_popover"
    bl_label = "Object Properties Popover"

    @classmethod
    def poll(cls, context):
        return context.object is not None

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=350)

    def draw(self, context):
        layout = self.layout
        obj = context.object
        obj_type = obj.type
        obj_data = obj.data
        render_engine = context.scene.render.engine

        vis_box = layout.box()
        vis_main_col = vis_box.column(align=True)
        vis_main_col.label(text="Visibility:",)
        vis_row = vis_main_col.row(align=True)
        vis_col_box = vis_row.box()
        vis_col = vis_col_box.column(align=True)
        vis_col.prop(obj, "hide_select", text="", emboss=False)
        vis_col.prop(obj, "hide_viewport", text="", emboss=False)
        vis_col.prop(obj, "hide_render", text="", emboss=False)

        if obj_type in {'MESH', 'CURVE', 'FONT', 'SURFACE', 'META'}:
            vis_col_box = vis_row.box()
            vis_col_split = vis_col_box.split(factor=0.5)
            
            if render_engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'}:
                vis_col = vis_col_split.column(align=True)
                vis_col.prop(obj, "visible_camera", text="Camera")
                vis_col.prop(obj, "visible_shadow", text="Shadow")

                vis_col = vis_col_split.column(align=True)
                vis_col.prop(obj, "hide_probe_volume", text="Volume")
                vis_col.prop(obj, "hide_probe_sphere", text="Sphere")
                vis_col.prop(obj, "hide_probe_plane", text="Plane")

                mask_box = vis_main_col.box()
                holdout_row = mask_box.row(align=True)
                holdout_row.label(text="Mask:")
                holdout_row.prop(obj, "is_holdout", text="Holdout", toggle=True)

            elif render_engine == 'CYCLES':
                vis_col = vis_col_split.column(align=True)
                vis_col.prop(obj, 'visible_camera', text="Camera")
                vis_col.prop(obj, 'visible_diffuse', text="Diffuse")
                vis_col.prop(obj, 'visible_glossy', text="Glossy")

                vis_col = vis_col_split.column(align=True)
                vis_col.prop(obj, 'visible_transmission', text="Transmission")
                vis_col.prop(obj, 'visible_volume_scatter', text="Volume Scatter")
                vis_col.prop(obj, 'visible_shadow', text="Shadow")
                
                mask_box = vis_main_col.box()
                holdout_row = mask_box.row()
                holdout_row.label(text="Mask:")
                holdout_row.prop(obj, 'is_holdout', text="Holdout", toggle=True)
                holdout_row.prop(obj, 'is_shadow_catcher', text="Shadow Catcher", toggle=True)

                vis_main_col.separator()

                cull_box = vis_main_col.box()
                cull_row = cull_box.row()
                cull_row.label(text="Culling:")
                cull_row.prop(obj.cycles, "use_camera_cull", text="Use Camera Cull", toggle=True)
                cull_row.prop(obj.cycles, "use_distance_cull", text="Use Distance Cull", toggle=True)

            vis_main_col.separator()
            
            vis_main_col.label(text="Viewport Display:")
            vis_main_box = vis_main_col.box()
            grid_box = vis_main_box.grid_flow(columns=2, align=True)
            grid_box.prop(obj, 'show_name', text="Name")
            grid_box.prop(obj, 'show_axis', text="Axes")
            grid_box.prop(obj.display, 'show_shadows', text="Shadow")
            grid_box.prop(obj, 'show_wire', text="Wireframe")
            if obj_type == 'MESH':
                grid_box.prop(obj, 'show_all_edges', text="All Edges")
            grid_box.prop(obj, 'show_texture_space', text="Texture Space")
            grid_box.prop(obj, 'show_in_front', text="In Front")

            data_box_col = vis_main_box.column()

            data_box_col.prop(obj, 'color', text="")
            dis_type_row = data_box_col.row(align=True)
            dis_type_row.prop(obj, 'display_type', text=" ", expand=True)
            
            bound_row = data_box_col.row()
            bound_row.prop(obj, 'show_bounds', text="Bounds", toggle=True)
            if obj.show_bounds:
                bound_row.prop(obj, 'display_bounds_type', text="")

        elif obj_type == 'LIGHT':
            vis_col_box = vis_row.box()
            vis_col_split = vis_col_box.split(factor=0.5)

            if render_engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT'}:
                
                vis_col = vis_col_split.column(align=True)
                vis_col.prop(obj, "visible_diffuse", text="Diffuse")
                vis_col.prop(obj, "visible_glossy", text="Glossy")
                vis_col.separator(factor=2)
                vis_col = vis_col_split.column(align=True)
                vis_col.prop(obj, "visible_transmission", text="Transmission")
                vis_col.prop(obj, "visible_volume_scatter", text="Volume Scatter")

                mask_box = vis_main_col.box()
                holdout_row = mask_box.row(align=True)
                holdout_row.label(text="Mask:")
                holdout_row.prop(obj, "is_holdout", text="Holdout", toggle=True)

            elif render_engine == 'CYCLES':
                vis_col = vis_col_split.column(align=True)
                vis_col.prop(obj, 'visible_camera', text="Camera")
                vis_col.prop(obj, 'visible_diffuse', text="Diffuse")
                vis_col.prop(obj, 'visible_glossy', text="Glossy")

                vis_col = vis_col_split.column(align=True)
                vis_col.prop(obj, 'visible_transmission', text="Transmission")
                vis_col.prop(obj, 'visible_volume_scatter', text="Volume Scatter")

                mask_box = vis_main_col.box()
                holdout_row = mask_box.row()
                holdout_row.label(text="Mask:")
                holdout_row.prop(obj, 'is_holdout', text="Holdout", toggle=True)
                holdout_row.prop(obj, 'is_shadow_catcher', text="Shadow Catcher", toggle=True)

                vis_main_col.separator()

                cull_box = vis_main_col.box()
                cull_row = cull_box.row()
                cull_row.label(text="Culling:")
                cull_row.prop(obj.cycles, "use_camera_cull", text="Use Camera Cull", toggle=True)
                cull_row.prop(obj.cycles, "use_distance_cull", text="Use Distance Cull", toggle=True)

            vis_main_col.label(text="Viewport Display:")
            light_view_box = vis_main_col.box()
            light_view_row = light_view_box.row(align=True)
            light_view_row.prop(obj, 'show_name', text="Name",toggle=True)
            light_view_row.prop(obj, 'show_axis', text="Axis",toggle=True) 
            light_view_row.prop(obj, 'show_in_front', text="In Front",toggle=True)
            light_view_col = light_view_box.column()
            dis_type_row = light_view_col.row(align=True)
            dis_type_row.prop(obj, 'display_type', text=" ", expand=True)

                # vis_main_col.separator()
                # vis_main_col.label(text="Light Data:")
                # light_box = vis_main_col.box()
                # light_col = light_box.column()
                # light_col.prop(obj_data, "type", text="Type", expand=True)

                # light_col.separator()

                # light_row = light_col.row(align=True)
                # light_row.prop(obj_data, "use_temperature")
                # light_row.prop(obj_data, "temperature")

                # light_col.prop(obj_data, "color", text="") 
                # light_col.prop(obj_data, "energy")
                
                # light_col.prop(obj_data, "exposure")
                # # light_col.prop(obj_data, "normalize")

                # # light_col.prop(obj_data, "shadow_soft_size")
                # # light_col.prop(obj_data, "use_soft_falloff")

        elif obj_type == 'CAMERA':
            vis_col_box = vis_row.box()
            vis_col = vis_col_box.column(align=True)

            if render_engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT', 'BLENDER_WORKBENCH'}:
                mask_box = vis_main_col.box()
                holdout_row = mask_box.row()
                holdout_row.label(text="Mask:")
                holdout_row.prop(obj, 'is_holdout', text="Holdout", toggle=True)
                vis_col.label(text="")
                vis_col.label(text="")
                vis_col.label(text="")
            elif render_engine == 'CYCLES':
                vis_col.label(text="")
                vis_col.label(text="")
                vis_col.label(text="")
                
            vis_main_col.separator()
            vis_main_col.label(text="Viewport Display:")
            camera_view_box = vis_main_col.box()
            camera_view_col = camera_view_box.column()
            camera_view_row = camera_view_col.row(align=True)
            camera_view_row.prop(obj, 'show_name', text="Name",toggle=True)
            camera_view_row.prop(obj, 'show_axis', text="Axis",toggle=True) 
            camera_view_row.prop(obj, 'show_in_front', text="In Front",toggle=True)

            # vis_main_col.separator()
            # vis_main_col.label(text="Camera Data:")
            # camera_box = vis_main_col.box()
            # camera_col = camera_box.column()
            # camera_col.prop(obj_data, "type", expand=True)
            # camera_col.separator()
            # if obj_data.type == 'PERSP':
            #     camera_col.prop(obj_data, "lens", text="Focal Length")
            #     camera_col.prop(obj_data, "lens_unit", text="Lens Unit")
            # elif obj_data.type == 'ORTHO':
            #     camera_col.prop(obj_data, "ortho_scale", text="Orthographic Scale")

            # camera_col.label(text="Camera Viewport Display:")
            # camera_box = camera_col.box()
            # camera_col = camera_box.column()
            # camera_col.prop(obj_data, "display_size", text="Size")
            # camera_row = camera_col.row(align=True)
            # camera_row.prop(obj_data, "show_limits", text="Limits")
            # camera_row.prop(obj_data, "show_mist", text="Mist")
            # camera_row = camera_col.row(align=True)
            # camera_row.prop(obj_data, "show_sensor", text="Sensor")
            # camera_row.prop(obj_data, "show_name", text="Name")
            # camera_row = camera_col.row(align=True)
            # camera_row.prop(obj_data, "show_passepartout", text="Passepartout")
            # camera_row.prop(obj_data, "passepartout_alpha", text="")

        elif obj_type == 'ARMATURE':
            vis_col_box = vis_row.box()
            vis_col = vis_col_box.column(align=True)
            if render_engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT', 'BLENDER_WORKBENCH'}:
                mask_box = vis_main_col.box()
                holdout_row = mask_box.row()
                holdout_row.label(text="Mask:")
                holdout_row.prop(obj, 'is_holdout', text="Holdout", toggle=True)
                vis_col.label(text="")
                vis_col.label(text="")
                vis_col.label(text="")
            elif render_engine == 'CYCLES':
                vis_col.label(text="")
                vis_col.label(text="")
                vis_col.label(text="")

            vis_main_col.separator()
            vis_main_col.label(text="Viewport Display:")
            armature_view_box = vis_main_col.box()
            armature_view_col = armature_view_box.column()
            armature_view_row = armature_view_col.row(align=True)
            armature_view_row.prop(obj, 'show_name', text="Name",toggle=True)
            armature_view_row.prop(obj, 'show_axis', text="Axis",toggle=True) 
            armature_view_row.prop(obj, 'show_in_front', text="In Front",toggle=True)
            
            armature_view_col.separator()

            dis_type_row = armature_view_col.row(align=True)
            dis_type_row.prop(obj, 'display_type', text=" ", expand=True)

            bound_row = armature_view_col.row()
            bound_row.prop(obj, 'show_bounds', text="Bounds", toggle=True)
            if obj.show_bounds:
                bound_row.prop(obj, 'display_bounds_type', text="")

            # vis_main_col.separator()
            # vis_main_col.label(text="Armature Data:")
            # arm_box = vis_main_col.box()
            # arm_col = arm_box.column()
            # arm_row = arm_col.row(align=True)
            # arm_row.prop(obj_data, "relation_line_position", text="Relations", expand=True)

            # arm_col.prop(obj_data, "display_type", text="")
            
            # arm_row = arm_col.row(align=True)
            # arm_row.prop(obj_data, "show_axes", text="Axes")
            # row_scale = arm_row.row(align=True)
            # row_scale.scale_x = 1.7
            # row_scale.prop(obj_data, "axes_position", text="Position")

            # arm_row = arm_col.row(align=True)
            # arm_row.prop(obj_data, "show_names", text="Names")
            # arm_row.prop(obj_data, "show_bone_custom_shapes", text="Shapes")

            # arm_row = arm_col.row(align=True)
            # arm_row.prop(obj, 'show_in_front', text="In Front")
            # arm_row.prop(obj_data, "show_bone_colors", text="Bone Colors")
            
        elif obj_type == 'EMPTY':
            vis_col_box = vis_row.box()
            vis_col = vis_col_box.column(align=True)

            if render_engine in {'BLENDER_EEVEE', 'BLENDER_EEVEE_NEXT', 'BLENDER_WORKBENCH'}:
                mask_box = vis_main_col.box()
                holdout_row = mask_box.row()
                holdout_row.label(text="Mask:")
                holdout_row.prop(obj, 'is_holdout', text="Holdout", toggle=True)
                vis_col.label(text="")
                vis_col.label(text="")
                vis_col.label(text="")
            elif render_engine == 'CYCLES':
                vis_col.label(text="")
                vis_col.label(text="")
                vis_col.label(text="")

            vis_main_col.separator()
            vis_main_col.label(text="Viewport Display:")
            camera_view_box = vis_main_col.box()
            camera_view_row = camera_view_box.row(align=True)
            camera_view_row.prop(obj, 'show_name', text="Name",toggle=True)
            camera_view_row.prop(obj, 'show_axis', text="Axis",toggle=True) 
            camera_view_row.prop(obj, 'show_in_front', text="In Front",toggle=True)
        else:
            pass

class ST_OT_QuickUsePopover(bpy.types.Operator):
    """Operator to show Quick Use settings in a popup dialog"""
    bl_idname = "st.quick_use_popover"
    bl_label = "Quick Use Section"

    def execute(self, context):
        return {'FINISHED'}

    def invoke(self, context, event):
        width = 250
        if context.area.type == 'IMAGE_EDITOR':
            width = 250
        elif context.area.type == 'NODE_EDITOR':
            width = 250
        return context.window_manager.invoke_props_dialog(self, width=width)

    def draw(self, context):
        space = context.space_data
        overlay = space.overlay
        
        layout = self.layout
        col = layout.column(align=True)
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        if context.area.type == 'VIEW_3D':
            shading = space.shading
            row = col.row(align=True)
            row_scale = row.row(align=True)
            row_scale.scale_x = 6
            row_scale.prop(overlay,'show_stats', text="", icon="STATUSBAR", toggle=True)
            row_scale.prop(overlay,'show_face_orientation', text="", icon="FACE_MAPS", toggle=True)
            row_scale.prop(space,'lock_camera', text="", icon="RESTRICT_RENDER_OFF", toggle=True)
            icon = "RESTRICT_VIEW_ON" if prefs.pre_clean_overlay_state else "RESTRICT_VIEW_OFF"
            row_scale.operator("st.toggle_clean_view", text="", icon=icon, depress=bool(prefs.pre_clean_overlay_state))
            row_scale.operator("view.toggle_obj_names", text="", icon="SORTALPHA", depress=bool(prefs.show_object_names_all))

            col.separator()
            
            col.prop(overlay,'show_wireframes', text="Wireframe", icon="MOD_WIREFRAME", toggle=True)
            if overlay.show_wireframes:
                wire_box = col.box()
                wire_col = wire_box.column(align=True)
                wire_col.prop(overlay, "wireframe_threshold", text="Wireframe")
                wire_col.prop(overlay, "wireframe_opacity", text="Opacity")

            col.separator(factor=0.5)
            col.prop(shading,'show_cavity', text="Cavity", icon="OVERLAY", toggle=True)
            
            if shading.show_cavity:
                act_box = col.box()
                act_col = act_box.column()
                act_col.prop(shading, 'cavity_type', text=" ", expand=True)
                
                if shading.cavity_type in {'SCREEN', 'BOTH'}:
                    box_screen = act_col.box()
                    col_screen = box_screen.column()
                    col_screen.label(text='Screen Space')
                    col_screen.prop(shading, 'curvature_ridge_factor', text='Ridge')
                    col_screen.prop(shading, 'curvature_valley_factor', text='Valley')

                if shading.cavity_type in {'WORLD', 'BOTH'}:
                    box_world = act_col.box()
                    col_world = box_world.column()
                    col_world.label(text='World Space')
                    col_world.prop(shading, 'cavity_ridge_factor', text='Ridge')
                    col_world.prop(shading, 'cavity_valley_factor', text='Valley')

            col.separator(factor=0.5)
            
            col.menu("VIEW3D_ST_purgedata_submenu", text="Clean Unused", icon='ORPHAN_DATA')

        elif context.area.type == 'IMAGE_EDITOR':
            from ..rightclick import draw_uv_tools_section
            draw_uv_tools_section(layout, context)

        elif context.area.type == 'NODE_EDITOR':
            space = context.space_data
            current_tree_type = getattr(space, 'tree_type', '')
            
            valid_trees = {'GeometryNodeTree', 'ShaderNodeTree', 'CompositorNodeTree', 'TextureNodeTree'}

            if current_tree_type in valid_trees:
                col = layout.column(align=True)
                
                if space.node_tree:
                    selected_count = 0
                    for node in space.node_tree.nodes:
                        if node.select:
                            selected_count += 1

                    if selected_count > 1:
                        row = col.row(align=True)
                        row_scale = row.row(align=True)
                        row_scale.scale_x = 6

                        row_scale.operator("st.reset_node_zoom", text="", icon='HOME')
                        if current_tree_type == 'GeometryNodeTree' and hasattr(space, "overlay"):
                            row_scale.operator("st.collapse_all_unused", text="", icon='FULLSCREEN_EXIT')
                            row_scale.prop(space.overlay, "show_timing", text="", icon="SORTTIME", toggle=True)
                            row_scale.prop(space.overlay, "show_named_attributes", text="", icon="TEXT", toggle=True)
                            # row_scale.menu("VIEW3D_ST_purgedata_submenu", text="", icon='ORPHAN_DATA')
                        
                        col.separator(factor=0.5)

                        box = col.box()
                        col_box = box.column(align=True)
                        
                        row = col_box.row(align=True)
                        row.label(text="Align:")
                        op_x = row.operator("st.node_align", text="X"); op_x.axis = 'X'
                        op_y = row.operator("st.node_align", text="Y"); op_y.axis = 'Y'

                        row = col_box.row(align=True)
                        row.label(text="Distribute:")
                        op_dx = row.operator("st.node_distribute", text="X"); op_dx.axis = 'X'
                        op_dy = row.operator("st.node_distribute", text="Y"); op_dy.axis = 'Y'

                        col_box.separator(factor=0.5)

                        row = col_box.row(align=True)
                        row.label(text="Rotate:")
                        op_r90 = row.operator("st.node_rotate", text="90°"); op_r90.angle = 90
                        op_r180 = row.operator("st.node_rotate", text="180°"); op_r180.angle = 180

                    else:
                        if current_tree_type == 'GeometryNodeTree' and hasattr(space, "overlay"):
                            col.operator("st.reset_node_zoom", text="View Home", icon='HOME')
                            col.operator("st.collapse_all_unused", text="Collapse Unused Sockets", icon='FULLSCREEN_EXIT')
                            col.prop(space.overlay, "show_timing", text="Timings", icon="SORTTIME", toggle=True)
                            col.prop(space.overlay, "show_named_attributes", text="Named Attributes", icon="TEXT", toggle=True)
                            # col.menu("VIEW3D_ST_purgedata_submenu", text="Clean Unused", icon='ORPHAN_DATA')
                else:
                    layout.label(text="No Node Tree", icon='INFO')
                    layout.operator("node.new_node_tree", text="New", icon='ADD')

            else:
                layout.label(text="Not available in this editor.", icon='INFO')
class ST_OT_SetAddItemsPopoverWidth(bpy.types.Operator):
    """(SUPERTABs) Sets the custom width for the Add Items Popover."""
    bl_idname = "st.set_add_items_popover_width"
    bl_label = "Set Popover Width"
    bl_options = {'INTERNAL'}

    target_width: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.add_items_popover_width = self.target_width
        self.report({'INFO'}, f"Popover width set to {self.target_width} pixels. Reopen popover to apply.")
        return {'FINISHED'}
class ST_OT_AddItemsToPresetDialog(bpy.types.Operator):
    """(SUPERTABs) Open a window to add multiple items into the Preset."""
    bl_idname = "st.add_items_to_preset_dialog"
    bl_label = "Add Add-ons/Tabs to Preset"
    bl_options = {'REGISTER', 'BLOCKING'}

    group_name: bpy.props.StringProperty()
    preset_name: bpy.props.StringProperty()
    available_items: bpy.props.CollectionProperty(type=AvailableItem)
    active_item_index: bpy.props.IntProperty()
    search_query: bpy.props.StringProperty(
        name="Search",
        default="",
        options={'TEXTEDIT_UPDATE'}
    )
    
    def invoke(self, context, event):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        self.available_items.clear()
        self.search_query = ""
        
        display_name_map = {f"addon:{item.name}": item.display_name for item in prefs.addon_display_lookup}
        display_name_map.update({f"tab:{item.name}": item.name for item in prefs.available_tabs})
        display_name_map.update({item.identifier: item.display_name for item in prefs.custom_item_names if item.display_name})

        master_preset = next((p for p in prefs.custom_favorite_presets if p.name == self.preset_name and p.main_group_name == self.group_name), None)
        items_already_in_preset = set()
        if master_preset:
            items_already_in_preset = {item.strip() for item in master_preset.items.split(',') if item.strip()}

        items_by_subgroup = defaultdict(list)
        main_group_name = self.group_name
        
        for group in prefs.tab_groups:
            subgroup_label = None
            if group.name == main_group_name:
                subgroup_label = "[Main Items]"
            elif group.name.startswith(f"{main_group_name} / "):
                subgroup_label = group.name.split(" / ", 1)[1]
            else:
                continue

            items = {item.strip() for item in group.items.split(',') if item.strip()}
            for identifier in items:
                if identifier in items_already_in_preset:
                    continue
                items_by_subgroup[subgroup_label].append(identifier)

        for subgroup_label in sorted(items_by_subgroup.keys()):
            for identifier in sorted(items_by_subgroup[subgroup_label]):
                new_item = self.available_items.add()
                new_item.name = identifier
                new_item.display_name = display_name_map.get(identifier, identifier.split(":", 1)[-1])
                new_item.selected = False
                new_item.subgroup_name = subgroup_label
        width_in_pixels = prefs.add_items_popover_width
        return context.window_manager.invoke_props_dialog(self, width=width_in_pixels)

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        master_preset = next((p for p in prefs.custom_favorite_presets if p.name == self.preset_name and p.main_group_name == self.group_name), None)
        if not master_preset:
            self.report({'ERROR'}, f"Preset '{self.preset_name}' not found.")
            return {'CANCELLED'}

        state = context.window_manager.tab_group_states.get(self.group_name)
        if not state:
            self.report({'ERROR'}, f"Group state '{self.group_name}' not found.")
            return {'CANCELLED'}
        content_preset = next((p for p in state.favorite_presets if p.name == self.preset_name), None)
        if not content_preset:
            content_preset = state.favorite_presets.add()
            content_preset.name = self.preset_name

        item_set = {item.strip() for item in master_preset.items.split(',') if item.strip()}
        selected_items = {item.name for item in self.available_items if item.selected}
        item_set.update(selected_items)
        new_items_str = ", ".join(sorted(list(item_set)))
        master_preset.items = new_items_str
        content_preset.items = new_items_str
        self.report({'INFO'}, f"Added {len(selected_items)} items to '{self.preset_name}'.")
        for window in context.window_manager.windows:
            for area in window.screen.areas:
                if area.type in {'VIEW_3D', 'PREFERENCES'}:
                    area.tag_redraw()

        return {'FINISHED'}

    def draw(self, context):
        layout = self.layout
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        preset_row = layout.row(align=True)
        preset_row.label(text="Popover Width:")
        op_800 = preset_row.operator("st.set_add_items_popover_width", text="800")
        op_800.target_width = 800
        op_1000 = preset_row.operator("st.set_add_items_popover_width", text="1000")
        op_1000.target_width = 1000
        op_1200 = preset_row.operator("st.set_add_items_popover_width", text="1200")
        op_1200.target_width = 1200
        op_1400 = preset_row.operator("st.set_add_items_popover_width", text="1400")
        op_1400.target_width = 1400
        
        toggle_row = preset_row.row(align=True)
        toggle_row.prop(prefs, "add_items_popover_width", text="Popover Width",slider=True)
        
        name_box = layout.box()
        name_row = name_box.row(align=True)
        name_row.alert = True
        name_row.label(text=f"Add Add-ons/Tabs to Preset: [{self.preset_name}]")
        layout.prop(self, "search_query", text="", icon='VIEWZOOM')

        search_term = self.search_query.lower()
        filtered_items_by_subgroup = defaultdict(list)
        items_drawn_count = 0
        for item in self.available_items:
            if search_term:
                if search_term not in item.display_name.lower() and search_term not in item.name.lower():
                    continue 
            
            filtered_items_by_subgroup[item.subgroup_name].append(item)
            items_drawn_count += 1

        main_box = layout.box()
        if not filtered_items_by_subgroup:
            if search_term:
                main_box.label(text="No items match your search.", icon='INFO')
            else:
                main_box.label(text="All items from this group are already in the preset.", icon='INFO')
            return
        subgroup_grid = main_box.grid_flow(
            columns=4,
            align=True,
            even_columns=True
        )

        for subgroup_label in sorted(filtered_items_by_subgroup.keys()):
            items_in_subgroup = filtered_items_by_subgroup[subgroup_label]
            subgroup_box = subgroup_grid.box()
            subgroup_box.label(text=subgroup_label, icon='DOT')
            item_count = len(items_in_subgroup)
            max_rows = 4
            calculated_num_columns = (item_count + max_rows - 1) // max_rows 
            num_columns = max(1, calculated_num_columns)

            if item_count > 0:
                inner_grid = subgroup_box.grid_flow(
                    row_major=False,
                    columns=num_columns,
                    even_columns=True, 
                    align=True
                )

                for item in items_in_subgroup:
                    inner_grid.prop(item, "selected", text=item.display_name)
class ST_OT_OpenAssignMenu(bpy.types.Operator):
    """(SUPERTABs) Opens the Assign Add-ons/Tabs dialog for the active group."""
    bl_idname = "st.open_assign_menu"
    bl_label = "Assign Menu"
    bl_options = {'REGISTER'}

    target_group_index: bpy.props.IntProperty()

    def invoke(self, context, event):
        return bpy.ops.st.assign_items_dialog('INVOKE_DEFAULT', 
            target_group_index=self.target_group_index
        )
class ST_OT_AssignItemsDialog(bpy.types.Operator):
    """(SUPERTABs) Dialog to assign multiple Add-ons/Tabs to a group."""
    bl_idname = "st.assign_items_dialog"
    bl_label = "Assign Add-ons/Tabs to Group"
    bl_options = {'REGISTER', 'BLOCKING'}

    target_group_index: bpy.props.IntProperty()
    available_items_list: bpy.props.CollectionProperty(type=AvailableItem)
    active_item_index: bpy.props.IntProperty()
    
    search_query: bpy.props.StringProperty(
        name="Search",
        default="",
        options={'TEXTEDIT_UPDATE'}
    )

    def invoke(self, context, event):
        bpy.ops.tab_group.refresh_available('EXEC_DEFAULT')
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        try:
            active_group = prefs.tab_groups[self.target_group_index]
        except IndexError:
            self.report({'ERROR'}, "Invalid group index.")
            return {'CANCELLED'}
            
        items_already_in_group = {item.strip() for item in active_group.items.split(',') if item.strip()}
        self.available_items_list.clear()

        for item in prefs.available_addons:
            identifier = f"addon:{item.name}"
            if identifier not in items_already_in_group:
                new_item = self.available_items_list.add()
                new_item.name = identifier
                new_item.display_name = item.display_name
                new_item.selected = False

        for item in prefs.available_tabs:
            identifier = f"tab:{item.name}"
            if identifier not in items_already_in_group:
                new_item = self.available_items_list.add()
                new_item.name = identifier
                new_item.display_name = item.display_name
                new_item.selected = False
        return context.window_manager.invoke_props_dialog(self, width=400)

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        try:
            active_group = prefs.tab_groups[self.target_group_index]
        except IndexError:
            self.report({'ERROR'}, "Invalid group index.")
            return {'CANCELLED'}

        current_items = [item.strip() for item in active_group.items.split(',') if item.strip()]
        
        existing_set = set(current_items)
        
        added_count = 0
        new_items_to_add = []

        for item in self.available_items_list:
            if item.selected:
                if item.name not in existing_set:
                    new_items_to_add.append(item.name)
                    added_count += 1
        
        final_list = current_items + new_items_to_add
        
        active_group.items = ", ".join(final_list)
        self.report({'INFO'}, f"Assigned {added_count} Add-ons/Tabs to '{active_group.name}'.")
        
        return {'FINISHED'}

    def draw(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        layout = self.layout
        top_row = layout.row(align=True)
        top_row.prop(self, "search_query", text="", icon='VIEWZOOM')
        
        col_row = top_row.row(align=True)
        col_row.scale_x = 0.5
        col_row.prop(prefs, "assign_dialog_column_count", text="Columns")

        box = layout.box()

        search_term = self.search_query.lower()
        filtered_items = []
        
        if search_term:
            for item in self.available_items_list:
                if search_term in item.name.lower() or search_term in item.display_name.lower():
                    filtered_items.append(item)
        else:
            filtered_items = list(self.available_items_list)

        if not filtered_items:
            if search_term:
                box.label(text="No Add-ons/Tabs match your search.", icon='INFO')
            else:
                box.label(text="No Add-ons/Tabs available to assign.", icon='INFO')
            return

        grid = box.grid_flow(
            columns=prefs.assign_dialog_column_count,
            even_columns=True,
            align=True
        )

        for item in filtered_items:
            grid.prop(item, "selected", text=item.display_name)

class ST_OT_SetHotkeyPopoverWidth(bpy.types.Operator):
    """(SUPERTABs) Sets the custom width for the Manager Popover (Hotkey)."""
    bl_idname = "st.set_hotkey_popover_width"
    bl_label = "Set Hotkey Popover Width"
    bl_options = {'INTERNAL'}

    target_width: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.hotkey_popup_width = self.target_width
        self.report({'INFO'}, f"Hotkey Popover width set to {self.target_width} units.")
        return {'FINISHED'}

class ST_PT_AddonManagerUtilsPopover(bpy.types.Panel):
    """Popover for Addon Manager Utilities & Statistics"""
    bl_label = "Addon Utilities"
    bl_idname = "ST_PT_AddonManagerUtilsPopover"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'

    def draw(self, context):
        layout = self.layout

        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        enabled_count = 0
        disabled_count = 0

        try:
            all_modules = list(addon_utils.modules())
            total_count = len(all_modules)
            
            for mod in all_modules:
                is_enabled, _ = addon_utils.check(mod.__name__)
                if is_enabled:
                    enabled_count += 1
                else:
                    disabled_count += 1
        
        except Exception as e:
            layout.label(text=f"Error counting addons: {e}", icon='ERROR')
            total_count = 0

        # --- Statistics ---
        if total_count > 0:
            layout.label(text="Addon Installed:", icon='INFO')
            box = layout.box()
            col = box.column()

            box_total = col.box()
            row_total = box_total.row(align=True)
            row_total.label(text="Total:", icon='PACKAGE')
            row_total.label(text=str(total_count))

            box_enabled = col.box()
            col_enabled = box_enabled.column()
            row_en = col_enabled.row(align=True)
            row_en.label(text="Enabled:", icon='CHECKBOX_HLT')
            row_en.label(text=str(enabled_count))
            
            box_disabled = col.box()
            col_disabled = box_disabled.column()
            row_dis = col_disabled.row(align=True)
            row_dis.label(text="Disabled:", icon='CHECKBOX_DEHLT')
            row_dis.label(text=str(disabled_count))

            col.operator("st.export_installed_addons", text="Backup", icon='EXPORT')

        layout.label(text="SuperTabs Settings:", icon='SETTINGS')

        box_settings = layout.box()
        op_col = box_settings.column(align=True)
        im_row = op_col.row(align=True)
        im_box = im_row.box()
        
        if prefs.auto_import_enabled:
            filepath = prefs.auto_import_filepath
            if filepath and os.path.exists(filepath):
                filename = os.path.basename(filepath)
                im_box.label(text=f"{filename}", icon='FILE_TICK')
            elif filepath:
                im_box.alert = True
                im_box.label(text="Auto-Load file not found!", icon='ERROR')
            else:
                im_box.alert = True
                im_box.label(text="No auto-load file set", icon='ERROR')
        else:
            im_box.enabled = False
            im_box.label(text="Auto-Import Disabled", icon='PAUSE')
        
        row_import = im_row.row(align=True)
        row_import.scale_y = 1.5
        row_import.scale_x = 1.25
        row_import.operator("tab_group.import_settings", text="", icon="IMPORT")
        
        op_col.separator(factor=0.5)

        row_export = op_col.row(align=True)
        row_export.alert = True
        row_export.scale_y = 1.5
        row_export.operator("tab_group.export_settings", text="Export Settings")
        row_export.scale_x = 1.25
        row_export.operator("tab_group.quick_export", text="", icon="EXPORT")
# --- Registration ---
classes = (
    ST_PT_AddonManagerUtilsPopover,
    ST_OT_AddItemsToPresetDialog,
    ST_OT_QuickUsePopover,
    ST_OT_OpenEjectedItemsPopover,
    ST_OT_Normal_Edit_Overlay_Popover,
    ST_OT_OpenEjectedSubgroupsPopover,
    ST_OT_OpenHiddenSubgroupsPopover,
    ST_OT_OpenHiddenItemsPopover,
    ST_OT_OpenAddonPresetManager,
    ST_OT_CallAddToPresetMenu,
    ST_OT_ToggleDisplaySettings,
    ST_OT_CavityPopover,
    ST_OT_WireframePopover,
    ST_PT_purgedata_menu,
    ST_OT_CallMoveItemMenu,
    ST_OT_CallMoveSubgroupMenu,
    ST_OT_ViewportDisplayPopover,
    ST_OT_ViewportOverlayPopover,
    ST_OT_Render_Popover,  
    ST_OT_OpenSuperTabsManager,
    ST_OT_SetAddItemsPopoverWidth,
    ST_OT_OpenAssignMenu,
    ST_OT_AssignItemsDialog,
    ST_OT_SetHotkeyPopoverWidth,
)