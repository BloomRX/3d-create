import bpy
from collections import defaultdict
import addon_utils 
from ..core import apply_group_settings
from ..utils import get_all_subclasses

class TABGROUP_OT_Add(bpy.types.Operator):
    """Create SUPERTABs N-panel on 3Dview"""
    bl_idname = "tab_group.add"
    bl_label = "Add Main Group"

    target_space: bpy.props.EnumProperty(
        name="Space",
        items=[
            ('VIEW_3D', "3D View", ""),
            ('IMAGE_EDITOR', "UV / Image Editor", ""),
            ('NODE_EDITOR', "Geometry Nodes", "")
        ],
        default='VIEW_3D'
    )

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if self.target_space == 'IMAGE_EDITOR':
            base_name = "SUPERTABs-UV"
        elif self.target_space == 'NODE_EDITOR':
            base_name = "SUPERTABs-Nodes"
        else:
            base_name = "SUPERTABs"
        i = 1
        new_name = base_name
        existing_names = {g.name for g in prefs.tab_groups}

        while new_name in existing_names:
            new_name = f"{base_name} {i}"
            i += 1

        new_group = prefs.tab_groups.add()
        new_group.name = new_name
        new_group.is_expanded = True
        new_group.space_type = self.target_space
        prefs.active_group_index = len(prefs.tab_groups) - 1
        return {"FINISHED"}

class TABGROUP_OT_AddSub(bpy.types.Operator):
    """Create Tab-Group in SUPERTABs N-panel"""
    bl_idname = "tab_group.add_sub"
    bl_label = "Add Tabs-Group"
    parent_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.parent_index < len(prefs.tab_groups):
            parent_group = prefs.tab_groups[self.parent_index]
            parent_name = parent_group.name.split('/')[0].strip()
            parent_space = parent_group.space_type

            base_name = "New Tabs-Group"
            i = 1
            new_sub_name_part = base_name
            all_group_names = {g.name for g in prefs.tab_groups}
            new_full_name = f"{parent_name} / {new_sub_name_part}"
            
            while new_full_name in all_group_names:
                new_sub_name_part = f"{base_name} {i}"
                new_full_name = f"{parent_name} / {new_sub_name_part}"
                i += 1

            new_group = prefs.tab_groups.add()
            new_group.name = new_full_name
            new_group.space_type = parent_space
            
            prefs.active_group_index = len(prefs.tab_groups) - 1
        return {"FINISHED"}

class TABGROUP_OT_Remove(bpy.types.Operator):
    """Remove Tab-Group in Supertabs N-panel"""
    bl_idname = "tab_group.remove"
    bl_label = "Remove Group"
    index: bpy.props.IntProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        to_remove = {self.index}
        if "/" not in prefs.tab_groups[self.index].name:
            main_name = prefs.tab_groups[self.index].name.split("/")[0].strip()
            to_remove.update({i for i, g in enumerate(prefs.tab_groups) if g.name.startswith(f"{main_name} /")})
        for i in sorted(list(to_remove), reverse=True):
            prefs.tab_groups.remove(i)
        prefs.active_group_index = min(max(0, self.index - 1), len(prefs.tab_groups) - 1)
        bpy.ops.tab_group.apply_settings()
        bpy.ops.tab_group.refresh_available('INVOKE_DEFAULT')
        
        return {"FINISHED"}

class TABGROUP_OT_SetActive(bpy.types.Operator):
    """Show TabsGroup in SUPERTABs N-panel"""
    bl_idname = "tab_group.set_active"
    bl_label = "Toggle Expansion"
    index: bpy.props.IntProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.index < len(prefs.tab_groups):
            active_group = prefs.tab_groups[self.index]
            active_group.is_expanded_in_prefs = not active_group.is_expanded_in_prefs
        return {"FINISHED"}
    
class TABGROUP_OT_RemoveItem(bpy.types.Operator):
    """Remove Tab from Group"""
    bl_idname = "tab_group.remove_item"
    bl_label = "Remove Item"
    bl_options = {"REGISTER"}
    item_to_remove: bpy.props.StringProperty()
    group_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        wm = context.window_manager
        item_to_remove = self.item_to_remove

        if 0 <= self.group_index < len(prefs.tab_groups):
            group = prefs.tab_groups[self.group_index]

            items = [t.strip() for t in group.items.split(",") if t.strip()]
            if self.item_to_remove in items:
                items.remove(self.item_to_remove)
            group.items = ", ".join(items)

            quick_shortcut_item = next((item for item in prefs.quick_shortcuts if item.identifier == self.item_to_remove), None)
            if quick_shortcut_item:
                bpy.ops.st.toggle_quick_shortcut(
                    'EXEC_DEFAULT',
                    item_identifier=quick_shortcut_item.identifier,
                    display_name=quick_shortcut_item.display_name,
                    main_group_name=quick_shortcut_item.main_group_name,
                    sub_group_name=quick_shortcut_item.sub_group_name
                )

            item_removed_from_presets = False
            for master_preset in prefs.custom_favorite_presets:
                preset_items = [item.strip() for item in master_preset.items.split(',') if item.strip()]
                
                if item_to_remove in preset_items:
                    preset_items = [i for i in preset_items if i != item_to_remove]
                    
                    master_preset.items = ", ".join(preset_items)
                    item_removed_from_presets = True

            if item_removed_from_presets and hasattr(wm, "tab_group_states"):
                for state in wm.tab_group_states:
                    for preset_in_state in state.favorite_presets:
                        master_preset_match = next((p for p in prefs.custom_favorite_presets if p.name == preset_in_state.name), None)
                        if master_preset_match:
                            preset_in_state.items = master_preset_match.items
                        else:
                            state_items = [item.strip() for item in preset_in_state.items.split(',') if item.strip()]
                            if item_to_remove in state_items:
                                state_items = [i for i in state_items if i != item_to_remove]
                                preset_in_state.items = ", ".join(state_items)
        else:
            self.report({'WARNING'}, "Group not found to remove item from.")
            return {'CANCELLED'}

        bpy.ops.tab_group.apply_settings()
        bpy.ops.tab_group.refresh_available()

        self.report({'INFO'}, f"Item removed and UI refreshed.")
        return {"FINISHED"}
class TABGROUP_OT_MoveSelected(bpy.types.Operator):
    """Reorder Tab or TabsGroup"""
    bl_idname = "tab_group.move_selected"
    bl_label = "Move Selected Item"
    bl_options = {'REGISTER'}
    direction: bpy.props.EnumProperty(items=[("UP", "Up", ""), ("DOWN", "Down", "")])
    @classmethod
    def poll(cls, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        return prefs.active_reorder_selection_type != 'NONE'
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        sel_type = prefs.active_reorder_selection_type
        sel_id = prefs.active_reorder_selection_id
        if sel_type == 'GROUP':
            groups = prefs.tab_groups
            all_groups_data = [{"name": g.name, "items": g.items, "is_expanded": g.is_expanded, "is_visible": g.is_visible} for g in groups]
            main_groups_map = defaultdict(list)
            ordered_main_names = []
            for g_data in all_groups_data:
                main_name = g_data["name"].split(" / ")[0]
                main_groups_map[main_name].append(g_data)
                if main_name not in ordered_main_names:
                    ordered_main_names.append(main_name)
            is_subgroup = "/" in sel_id
            if is_subgroup:
                main_name_of_sub = sel_id.split("/")[0].strip()
                sub_indices = [i for i, g in enumerate(groups) if g.name.startswith(f"{main_name_of_sub} /")]
                try:
                    current_index_in_collection = [g.name for g in groups].index(sel_id)
                    current_pos_in_sublist = sub_indices.index(current_index_in_collection)
                    if self.direction == "UP" and current_pos_in_sublist > 0:
                        target_pos_in_sublist = current_pos_in_sublist - 1
                        target_collection_index = sub_indices[target_pos_in_sublist]
                        groups.move(current_index_in_collection, target_collection_index)
                    elif self.direction == "DOWN" and current_pos_in_sublist < len(sub_indices) - 1:
                        target_pos_in_sublist = current_pos_in_sublist + 1
                        target_collection_index = sub_indices[target_pos_in_sublist]
                        groups.move(current_index_in_collection, target_collection_index)
                except ValueError:
                    return {'CANCELLED'}
            else:
                try:
                    current_pos = ordered_main_names.index(sel_id)
                    if self.direction == "UP" and current_pos > 0:
                        ordered_main_names.insert(current_pos - 1, ordered_main_names.pop(current_pos))
                    elif self.direction == "DOWN" and current_pos < len(ordered_main_names) - 1:
                        ordered_main_names.insert(current_pos + 1, ordered_main_names.pop(current_pos))
                    else:
                        return {'CANCELLED'}
                    new_groups_data = []
                    for main_name in ordered_main_names:
                        new_groups_data.extend(main_groups_map[main_name])
                    prefs.tab_groups.clear()
                    for g_data in new_groups_data:
                        new_g = prefs.tab_groups.add()
                        new_g.name = g_data["name"]
                        new_g.items = g_data["items"]
                        new_g.is_expanded = g_data["is_expanded"]
                        new_g.is_visible = g_data["is_visible"]
                except ValueError:
                    return {'CANCELLED'}
        elif sel_type == 'ITEM':
            if not (0 <= prefs.active_group_index < len(prefs.tab_groups)):
                return {'CANCELLED'}
            group = prefs.tab_groups[prefs.active_group_index]
            items_list = [item.strip() for item in group.items.split(",") if item.strip()]
            try:
                current_index = items_list.index(sel_id)
                if self.direction == "UP" and current_index > 0:
                    items_list.insert(current_index - 1, items_list.pop(current_index))
                elif self.direction == "DOWN" and current_index < len(items_list) - 1:
                    items_list.insert(current_index + 1, items_list.pop(current_index))
                else:
                    return {'CANCELLED'}
                group.items = ", ".join(items_list)
            except ValueError:
                return {'CANCELLED'}
        new_active_index = -1
        for i, g in enumerate(prefs.tab_groups):
            if g.name == sel_id:
                new_active_index = i
                break
        if new_active_index != -1:
            prefs.active_group_index = new_active_index
        apply_group_settings(context, self)
        return {'FINISHED'}
    
class TABGROUP_OT_SetReorderSelection(bpy.types.Operator):
    bl_idname = "tab_group.set_reorder_selection"
    bl_label = "Select Item for Reordering"
    bl_options = {'REGISTER'}
    selection_type: bpy.props.EnumProperty(items=[('GROUP', "Group", ""), ('ITEM', "Item", "")])
    selection_id: bpy.props.StringProperty()
    group_index: bpy.props.IntProperty(default=-1)
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.active_reorder_selection_type = self.selection_type
        prefs.active_reorder_selection_id = self.selection_id
        if self.group_index != -1:
            prefs.active_group_index = self.group_index
        return {'FINISHED'}
    
class ST_OT_MoveItemToGroup(bpy.types.Operator):
    """Executes the move of an item to a new group"""
    bl_idname = "st.move_item_to_group"
    bl_label = "Move Item to Group"
    bl_options = {'REGISTER'}

    item_to_move: bpy.props.StringProperty()
    source_group_index: bpy.props.IntProperty()
    destination_group_index: bpy.props.IntProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        if not (0 <= self.source_group_index < len(prefs.tab_groups) and \
                0 <= self.destination_group_index < len(prefs.tab_groups)):
            self.report({'WARNING'}, "Invalid group index.")
            return {'CANCELLED'}

        source_group = prefs.tab_groups[self.source_group_index]
        dest_group = prefs.tab_groups[self.destination_group_index]

        source_items = [t.strip() for t in source_group.items.split(",") if t.strip()]
        if self.item_to_move in source_items:
            source_items.remove(self.item_to_move)
        source_group.items = ", ".join(source_items)

        dest_items = [t.strip() for t in dest_group.items.split(",") if t.strip()]
        if self.item_to_move not in dest_items:
            dest_items.append(self.item_to_move)
        dest_group.items = ", ".join(dest_items)

        bpy.ops.tab_group.apply_settings()
        self.report({'INFO'}, f"Moved '{self.item_to_move}' to '{dest_group.name}'.")

        return {'FINISHED'}
    
class ST_OT_MoveSubgroupToMainGroup(bpy.types.Operator):
    """Executes the move of a subgroup to a new main group"""
    bl_idname = "st.move_subgroup_to_main_group"
    bl_label = "Move Subgroup to Main Group"
    bl_options = {'REGISTER'}

    subgroup_index: bpy.props.IntProperty()
    destination_main_group_name: bpy.props.StringProperty()

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        if not (0 <= self.subgroup_index < len(prefs.tab_groups)):
            self.report({'WARNING'}, "Invalid subgroup index.")
            return {'CANCELLED'}

        subgroup = prefs.tab_groups[self.subgroup_index]

        parts = subgroup.name.split(" / ", 1)
        if len(parts) != 2:
            self.report({'WARNING'}, "Selected group is not a valid subgroup.")
            return {'CANCELLED'}

        subgroup_name_part = parts[1]
        new_name = f"{self.destination_main_group_name} / {subgroup_name_part}"
        
        subgroup.name = new_name
        
        bpy.ops.tab_group.apply_settings()
        self.report({'INFO'}, f"Moved subgroup to '{self.destination_main_group_name}'.")
        return {'FINISHED'}
    
class TABGROUP_OT_AssignSelected(bpy.types.Operator):
    """Assign Selected Addons Tab into TabGroup"""
    bl_idname = "tab_group.assign_selected"
    bl_label = "Assign Selected"
    item_type: bpy.props.StringProperty()
    group_index: bpy.props.IntProperty()
    @classmethod
    def poll(cls, context): 
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        return 0 <= prefs.active_group_index < len(prefs.tab_groups)
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if not (0 <= self.group_index < len(prefs.tab_groups)):
            return {'CANCELLED'}
        
        group = prefs.tab_groups[self.group_index]
        
        current_items = [t.strip() for t in group.items.split(",") if t.strip()]
        existing_set = set(current_items)
        
        if self.item_type == "tab":
            new_items = [f"tab:{i.name}" for i in prefs.available_tabs if i.selected]
            
            is_changed = False
            for new_item in new_items:
                if new_item not in existing_set:
                    current_items.append(new_item)
                    existing_set.add(new_item)
                    is_changed = True
            
            if is_changed:
                group.items = ", ".join(current_items)

        bpy.ops.tab_group.refresh_available('INVOKE_DEFAULT')
        return {"FINISHED"}
    
class TABGROUP_OT_ToggleVisibility(bpy.types.Operator):
    bl_idname = "tab_group.toggle_visibility"
    bl_label = "Toggle Group Visibility"
    bl_options = {'REGISTER'}
    index: bpy.props.IntProperty()
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if 0 <= self.index < len(prefs.tab_groups):
            group = prefs.tab_groups[self.index]
            group.is_visible = not group.is_visible
            apply_group_settings(context, self)
        return {'FINISHED'}

class TABGROUP_OT_RefreshAvailable(bpy.types.Operator):
    """Refresh AddonsTabs Lists"""
    bl_idname = "tab_group.refresh_available"
    bl_label = "Refresh Tabs Lists"
    
    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        prefs.available_tabs.clear()
        prefs.available_addons.clear()
        prefs.addon_display_lookup.clear()

        # target_space = 'VIEW_3D'
        # if 0 <= prefs.active_group_index < len(prefs.tab_groups):
        #     active_group = prefs.tab_groups[prefs.active_group_index]
        #     target_space = active_group.space_type
        target_space = prefs.active_management_tab

        grouped = set()
        for g in prefs.tab_groups:
            if g.space_type == target_space:
                for t in g.items.split(","):
                    if t.strip():
                        grouped.add(t.strip())

        supertab_names = set()
        for g in prefs.tab_groups:
            if g.space_type == target_space:
                parts = g.name.split(' / ')
                if parts[0].strip():
                    supertab_names.add(parts[0].strip())
                if len(parts) > 1 and parts[1].strip():
                    supertab_names.add(parts[1].strip()) 

        ejected_set = {s.strip() for s in prefs.ejected_subgroups.split(',') if s.strip()}
        for ejected_full_name in ejected_set:
            try:
                category_name = ejected_full_name.split(' / ', 1)[1]
                supertab_names.add(category_name)
            except IndexError:
                continue

        if target_space == 'VIEW_3D':
            manual_exclude_set = {tab.strip() for tab in prefs.manual_exclude_tabs.split(',') if tab.strip()}
        elif target_space == 'IMAGE_EDITOR':
            manual_exclude_set = {tab.strip() for tab in prefs.manual_exclude_tabs_image.split(',') if tab.strip()}
        elif target_space == 'NODE_EDITOR':
            manual_exclude_set = {tab.strip() for tab in prefs.manual_exclude_tabs_node.split(',') if tab.strip()}

        disabled_default_tabs = set()
        if target_space == 'VIEW_3D':
            if prefs.manage_item_tab: disabled_default_tabs.add("Item")
            if prefs.manage_tool_tab: disabled_default_tabs.add("Tool")
            if prefs.manage_view_tab: disabled_default_tabs.add("View")
            if prefs.manage_edit_tab: disabled_default_tabs.add("Edit")
        elif target_space == 'IMAGE_EDITOR':
            if prefs.manage_uv_image_tab: disabled_default_tabs.add("Image")
            if prefs.manage_uv_tool_tab: disabled_default_tabs.add("Tool")
            if prefs.manage_uv_view_tab: disabled_default_tabs.add("View")
            if prefs.manage_uv_scope_tab: disabled_default_tabs.add("Scope")
        elif target_space == 'NODE_EDITOR':
            if prefs.manage_node_options_tab: disabled_default_tabs.add("Options")
            if prefs.manage_node_tool_tab: disabled_default_tabs.add("Tool")
            if prefs.manage_node_view_tab: disabled_default_tabs.add("View")
            if prefs.manage_node_node_tab: disabled_default_tabs.add("Node")
            if prefs.manage_node_group_tab: disabled_default_tabs.add("Group")
        
        valid_categories = set()
        all_panels = [
            p for p in get_all_subclasses(bpy.types.Panel) if (
                getattr(p, 'bl_category', None) and
                getattr(p, 'bl_space_type', None) == target_space and
                getattr(p, 'bl_region_type', None) == 'UI'
            )
        ]
        
        for p_cls in all_panels:
            panel_class_name = p_cls.__name__
            if panel_class_name.startswith("MAIN_CONTROLLER_PT_") or panel_class_name.startswith("EJECTED_CONTROLLER_PT_"):
                continue
            
            category = p_cls.bl_category
            if category in {"ST_HIDDEN", "Misc"} or category in disabled_default_tabs or category in supertab_names or category in manual_exclude_set:
                continue

            if getattr(p_cls, 'bl_parent_id', None):
                continue

            panel_label = getattr(p_cls, 'bl_label', '').lower()
            if (category and category.startswith("U4 ")) or panel_label.startswith("u4 "):
                continue
            if 'library' in panel_label and 'mpfb_' in getattr(p_cls, '__name__', '').lower():
                continue
            if "ZenUV" in p_cls.__module__ and getattr(p_cls, 'bl_label', '') in {"System", "Zen UV Math"}:
                continue

            valid_categories.add(category)

        for name in sorted(list(valid_categories)):
            if f"tab:{name}" not in grouped:
                item = prefs.available_tabs.add()
                item.name = item.display_name = name
    
        for mod in addon_utils.modules():
            if mod.__name__ != __package__:
                lookup = prefs.addon_display_lookup.add()
                lookup.name = mod.__name__
                lookup.display_name = mod.bl_info.get("name", mod.__name__)
        return {"FINISHED"}

class ST_OT_SortAllSubgroups(bpy.types.Operator):
    """Sorts all subgroups alphabetically within their main group"""
    bl_idname = "st.sort_all_subgroups"
    bl_label = "Sort All Subgroups (A-Z)"
    bl_options = {'REGISTER'}

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        all_groups_data = []
        for g in prefs.tab_groups:
            all_groups_data.append({
                "name": g.name,
                "items": g.items,
                "is_expanded": g.is_expanded,
                "is_expanded_in_prefs": g.is_expanded_in_prefs,
                "is_visible": g.is_visible
            })

        main_groups_map = defaultdict(list)
        main_groups_order = []

        for g_data in all_groups_data:
            parts = g_data["name"].split(" / ", 1)
            main_name = parts[0]
            
            if main_name not in main_groups_order:
                main_groups_order.append(main_name)
            
            main_groups_map[main_name].append(g_data)

        new_groups_data = []
        for main_name in main_groups_order:
            groups_list = main_groups_map[main_name]
            
            main_group = None
            sub_groups = []
            
            for g in groups_list:
                if g["name"] == main_name:
                    main_group = g
                else:
                    sub_groups.append(g)

            if main_group:
                new_groups_data.append(main_group)
            
            if sub_groups:
                sorted_sub_groups = sorted(sub_groups, key=lambda x: x['name'])
                new_groups_data.extend(sorted_sub_groups)

        prefs.tab_groups.clear()
        for g_data in new_groups_data:
            new_g = prefs.tab_groups.add()
            new_g.name = g_data["name"]
            new_g.items = g_data["items"]
            new_g.is_expanded = g_data["is_expanded"]
            new_g.is_expanded_in_prefs = g_data["is_expanded_in_prefs"]
            new_g.is_visible = g_data["is_visible"]

        bpy.ops.tab_group.apply_settings()
        self.report({'INFO'}, "All subgroups have been sorted alphabetically.")
        return {'FINISHED'}

class ST_OT_SortItemsInGroup(bpy.types.Operator):
    """Sorts the items within the currently active group alphabetically"""
    bl_idname = "st.sort_items_in_group"
    bl_label = "Sort Items (A-Z)"
    bl_options = {'REGISTER'}

    @classmethod
    def poll(cls, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        if not (0 <= prefs.active_group_index < len(prefs.tab_groups)):
            return False
        active_group = prefs.tab_groups[prefs.active_group_index]
        return bool(active_group.items)

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences

        active_group = prefs.tab_groups[prefs.active_group_index]

        items_list = [item.strip() for item in active_group.items.split(",") if item.strip()]
        
        if not items_list:
            self.report({'INFO'}, "No items to sort.")
            return {'CANCELLED'}

        sorted_items = sorted(items_list)

        active_group.items = ", ".join(sorted_items)
        
        self.report({'INFO'}, f"Items in '{active_group.name}' have been sorted.")

        bpy.ops.tab_group.apply_settings('INVOKE_DEFAULT')
        
        return {'FINISHED'}

class ST_OT_ToggleSubgroupExpansion(bpy.types.Operator):
    """Toggle subgroup expansion with exclusive (Click) or additive (Shift+Click) behavior"""
    bl_idname = "st.toggle_subgroup_expansion"
    bl_label = "Toggle Subgroup Expansion"
    bl_options = {'REGISTER'}

    main_group_name: bpy.props.StringProperty()
    subgroup_full_name: bpy.props.StringProperty()

    _shift_pressed: bpy.props.BoolProperty(options={'HIDDEN'})

    def invoke(self, context, event):
        self._shift_pressed = event.shift
        return self.execute(context)

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        target_subgroup = next((g for g in prefs.tab_groups if g.name == self.subgroup_full_name), None)
        
        if not target_subgroup:
            return {'CANCELLED'}

        if self._shift_pressed:
            target_subgroup.is_expanded = not target_subgroup.is_expanded
        else:
            is_target_currently_expanded = target_subgroup.is_expanded
            new_target_state = not is_target_currently_expanded
            
            if new_target_state is True: 

                for g in prefs.tab_groups:
                    if g.name.startswith(f"{self.main_group_name} / ") and g.name != self.subgroup_full_name:
                        g.is_expanded = False

            target_subgroup.is_expanded = new_target_state
        
        return {'FINISHED'}

class TABGROUP_OT_SetSub(bpy.types.Operator):
    """Create multiple Tab-Groups in SUPERTABs N-panel from a comma-separated list."""
    bl_idname = "tab_group.set_sub"
    bl_label = "Set Multiple Tab Groups"
    bl_options = {'REGISTER', 'UNDO'}

    parent_index: bpy.props.IntProperty(options={'HIDDEN'})
    group_names: bpy.props.StringProperty(
        name="Group Names",
        description="Enter group names, separated by commas (e.g., Modeling, UV, Assets)",
        default="Asset, Modeling, UV, Materials, Renders, Animation"
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self)
    
    def draw(self, context):
        layout = self.layout
        layout.label(text="Enter group names, separated by commas:")
        layout.prop(self, "group_names", text="")

    def execute(self, context):
        prefs = context.preferences.addons[__package__.split('.')[0]].preferences
        
        if not (0 <= self.parent_index < len(prefs.tab_groups)):
            self.report({'WARNING'}, "Invalid parent group index.")
            return {'CANCELLED'}
            
        parent_group = prefs.tab_groups[self.parent_index]
        parent_name = parent_group.name.split('/')[0].strip()
        parent_space = parent_group.space_type
        
        all_group_names = {g.name for g in prefs.tab_groups}

        new_names = [name.strip() for name in self.group_names.split(',') if name.strip()]
        
        if not new_names:
            self.report({'INFO'}, "No names entered.")
            return {'CANCELLED'}

        created_count = 0
        for name in new_names:

            clean_name = name.replace("/", "").strip()
            if not clean_name:
                continue
                
            new_full_name = f"{parent_name} / {clean_name}"

            if new_full_name in all_group_names:
                continue

            new_group = prefs.tab_groups.add()
            new_group.name = new_full_name
            new_group.space_type = parent_space
            
            all_group_names.add(new_full_name)
            created_count += 1

        self.report({'INFO'}, f"Created {created_count} new Tab-Group(s).")
        
        prefs.active_group_index = len(prefs.tab_groups) - 1

        bpy.ops.tab_group.apply_settings('INVOKE_DEFAULT')

        return {'FINISHED'}

# --- Registration ---
classes = (
    TABGROUP_OT_Add,
    TABGROUP_OT_AddSub,
    TABGROUP_OT_SetSub,
    TABGROUP_OT_Remove,
    TABGROUP_OT_SetActive,
    TABGROUP_OT_RemoveItem,
    TABGROUP_OT_AssignSelected,
    TABGROUP_OT_SetReorderSelection,
    TABGROUP_OT_MoveSelected,
    TABGROUP_OT_ToggleVisibility,
    TABGROUP_OT_RefreshAvailable,
    ST_OT_MoveItemToGroup,
    ST_OT_MoveSubgroupToMainGroup,
    ST_OT_SortAllSubgroups,
    ST_OT_SortItemsInGroup,
    ST_OT_ToggleSubgroupExpansion,
)