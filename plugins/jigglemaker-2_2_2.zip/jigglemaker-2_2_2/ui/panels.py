import bpy
from ..utils import library


class GeneralPanel(bpy.types.Panel):
    ver = "2.2.2"
    bl_label = f"Jiggle Maker v{ver}"
    bl_idname = "JIGGLE_MAKER_PT_main"
    bl_order = 0
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "JM"
    #bl_options = {'DEFAULT_OPEN'}

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        layout.use_property_split = True
        layout.use_property_decorate = False

        header = layout.row()
        header.label(text="", icon='PHYSICS')


        header.label(text=f"Jiggle Maker")

        mode_box = layout.box()
        mode_box.label(text="1. Select Mode", icon='COLLAPSEMENU')
        col = mode_box.column(align=True)
        col.prop_enum(scene, "jm_mode_selector", 'OPTION1', text="Preset Mesh Mode")
        col.prop_enum(scene, "jm_mode_selector", 'OPTION2', text="Vertex Mode")
        col.prop_enum(scene, "jm_mode_selector", 'OPTION3', text="Custom Mesh Mode")


        content_box = layout.box()

        if scene.jm_mode_selector == 'OPTION1':
            preset_box = content_box.box()
            preset_box.label(text="2. Preset Library", icon='LIBRARY_DATA_DIRECT')
            names = library.model_names()
            if not names:
                row = preset_box.row(align=True)
                row.operator("wm.refresh_library", text="Refresh Presets", icon='FILE_REFRESH')
                preset_box.label(text="No objects found", icon='ERROR')
                return
            flow = preset_box.grid_flow(row_major=True, columns=3, even_columns=True, even_rows=True, align=True)
            for obj_name in names:
                op = flow.operator("object.add_preset_object", text=obj_name, icon='MESH_DATA')
                op.object_name = obj_name
            preset_box.label(text="Please set a unique name after spawning!")

            bind_box = content_box.box()
            bind_box.label(text="3. Jiggle Setup", icon='MODIFIER')
            bind_box.operator("wm.toggle_armature_pose", icon='ARMATURE_DATA')
            bind_box.label(text="Target Objects:", icon='OBJECT_DATA')
            bind_box.prop(scene, "jm_main", text="Main Mesh")
            bind_box.prop(scene, "jm_proxy", text="Jiggle Mesh")

            if scene.jm_main and scene.jm_proxy:
                bind_box.separator()
                bind_box.label(text="Binding Options:", icon='CONSTRAINT')
                bind_box.prop(context.window_manager, "jm_cloth_preset", text="Physics Preset")
                bind_box.prop(scene, "jm_proxy_parent_dist", text="Bind Distance from jiggle to main mesh")
                bind_box.prop(scene, "jm_mirror_mesh", text="Mirror Mesh")
                
                advanced_box = bind_box.box()
                advanced_box.prop(scene, "jm_advanced", text="Advanced Settings", icon='PREFERENCES', toggle=True)

                if scene.jm_advanced:
                    grid = advanced_box.grid_flow(row_major=True, columns=2, align=True)
                    grid.prop(scene, "jm_cleanup", text="Cleanup Previous")
                    grid.prop(scene, "jm_bind_armature", text="Bind Armature")
                    grid.prop(scene, "jm_surface_deform", text="Surface Deform")
                    grid.prop(scene, "jm_add_cloth", text="Cloth Modifier")
                    grid.prop(scene, "jm_trinagulate_deformer", text="Triangulate Modifier")

                bind_box.separator()
                library._jm_draw_collision_warning(bind_box, scene.jm_proxy)
                library._jm_draw_trs_warning(bind_box, scene.jm_main)
                library._jm_draw_size_warning(bind_box, scene.jm_proxy)


                bind_box.operator("wm.boob_magic", text="Apply Jiggle Physics", icon='PHYSICS')

        elif scene.jm_mode_selector == 'OPTION2':
            content_box.label(text="2. Vertex Group Physics", icon='GROUP_VERTEX')
            content_box.operator("wm.toggle_armature_pose", icon='ARMATURE_DATA')
            content_box.prop(scene, "jm_main", text="Main Mesh")

            if scene.jm_main and scene.jm_main.type == 'MESH':
                content_box.separator()
                content_box.prop_search(scene.jm_main, "main_vertex_group", scene.jm_main, "vertex_groups", text="Vertex Group", icon='VERTEXSEL')
                if scene.jm_main.main_vertex_group:
                    content_box.separator()
                    content_box.prop(context.window_manager, "jm_cloth_preset", text="Physics Preset")
                    # Advanced FIRST
                    adv = content_box.box()
                    adv.prop(scene, "jm_advanced", text="Advanced Settings", icon='PREFERENCES', toggle=True)
                    if scene.jm_advanced:
                        grid = adv.grid_flow(row_major=True, columns=2, align=True)
                        grid.prop(scene, "jm_surface_deform", text="Surface Deform")
                        grid.prop(scene, "jm_add_cloth", text="Cloth Modifier")
                        grid.prop(scene, "jm_cleanup", text="Cleanup Previous")
                        grid.prop(scene, "jm_clean_vgroups", text="Clean vertex groups")
                        grid.prop(scene, "jm_trinagulate_deformer", text="Triangulate Modifier")
                        grid.operator("object.add_collision", text="Convert vertex group to collision", icon='MOD_PHYSICS')

                    content_box.separator()
                    library._jm_draw_collision_warning(content_box, scene.jm_proxy)
                    library._jm_draw_trs_warning(content_box, scene.jm_main)
                    library._jm_draw_size_warning(content_box, scene.jm_proxy)
                    row = content_box.row()
                    row.operator("object.select_vertex_group", text="Apply Jiggle to Group", icon='MOD_PHYSICS')



        elif scene.jm_mode_selector == 'OPTION3':
            content_box.label(text="2. Custom Proxy Setup", icon='STICKY_UVS_LOC')
            content_box.operator("wm.toggle_armature_pose", icon='ARMATURE_DATA')
            content_box.prop(scene, "jm_main", text="Main Mesh")

            if scene.jm_main and scene.jm_main.type == 'MESH':
                content_box.prop(scene, "jm_proxy", text="Proxy Mesh")
                if scene.jm_proxy and scene.jm_proxy.type == 'MESH':
                    content_box.separator()
                    content_box.prop_search(scene.jm_proxy, "custom_mesh_vertex_group", scene.jm_proxy, "vertex_groups", text="Pin Group", icon='PINNED')
                    if scene.jm_proxy.custom_mesh_vertex_group:
                        content_box.separator()
                        content_box.prop(context.window_manager, "jm_cloth_preset", text="Physics Preset")
                        content_box.prop(scene, "jm_proxy_parent_dist", text="Bind Distance from jiggle to main mesh")
                        content_box.prop(scene, "jm_mirror_mesh", text="Mirror Mesh")
                        
                        advanced_box = content_box.box()
                        advanced_box.prop(scene, "jm_advanced", text="Advanced Settings", icon='PREFERENCES', toggle=True)
                        if scene.jm_advanced:
                            grid = advanced_box.grid_flow(row_major=True, columns=2, align=True)
                            grid.prop(scene, "jm_cleanup", text="Cleanup Previous")
                            grid.prop(scene, "jm_bind_armature", text="Bind Armature")
                            grid.prop(scene, "jm_surface_deform", text="Surface Deform")
                            grid.prop(scene, "jm_add_cloth", text="Cloth Modifier")
                            grid.prop(scene, "jm_trinagulate_deformer", text="Triangulate Modifier")
                        library._jm_draw_collision_warning(content_box, scene.jm_proxy)
                        library._jm_draw_trs_warning(content_box, scene.jm_main)
                        library._jm_draw_size_warning(content_box, scene.jm_proxy)
                        content_box.operator("wm.bind_proxy", text="Bind Custom Proxy", icon='LINKED')

class ClothSettings(bpy.types.Panel):
    bl_label = "Cloth Settings"
    bl_idname = "JIGGLE_MAKER_PT_cloth"
    bl_order = 10
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "JM"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        scene = context.scene
        layout = self.layout
        selected_object = context.active_object

        if not selected_object:
            layout.label(text="No active object selected", icon='ERROR')
            return
        if selected_object.type != 'MESH':
            layout.label(text="Active object is not a mesh", icon='MESH_DATA')
            return

        cloth_modifier = next((m for m in selected_object.modifiers if m.type == 'CLOTH'), None)
        if not cloth_modifier:
            layout.label(text="No cloth modifier found", icon='MOD_CLOTH')
            return

        header = layout.row()
        header.label(text=f"Cloth: {selected_object.name}", icon='OUTLINER_OB_MESH')


        # --- JM Cloth Presets (inline) ---
        try:
            wm = context.window_manager
            presets_box = layout.box()
            presets_box.label(text="Presets", icon='PRESET')
            row = presets_box.row(align=True)
            row.prop(wm, "jm_cloth_preset", text="Preset")
            row.operator("wm.jm_apply_cloth_preset", text="Apply", icon='CHECKMARK')
            row.operator("wm.jm_delete_cloth_preset", text="", icon='TRASH')
            row = presets_box.row(align=True)
            row.prop(wm, "jm_new_cloth_preset_name", text="New Preset")
            row.operator("wm.jm_save_cloth_preset", text="Save Current", icon='ADD')
        except Exception as _e:
            pass
        # --- end JM Cloth Presets (inline) ---
        main_box = layout.box()

        general_box = main_box.box()
        general_box.label(text="General Settings", icon='SETTINGS')
        col = general_box.column(align=True)
        col.prop(cloth_modifier.settings, "quality", text="Quality Steps")
        col.prop(cloth_modifier.settings, "time_scale", text="Speed")
        col.prop(cloth_modifier.settings, "mass", text="Mass")
        col.prop(cloth_modifier.settings.effector_weights, "gravity", text="Gravity")

        stiffness_box = main_box.box()
        stiffness_box.label(text="Stiffness", icon='FULLSCREEN_ENTER')
        col = stiffness_box.column(align=True)
        col.prop(cloth_modifier.settings, "tension_stiffness", text="Tension")
        col.prop(cloth_modifier.settings, "compression_stiffness", text="Compression")
        col.prop(cloth_modifier.settings, "shear_stiffness", text="Shear")

        damping_box = main_box.box()
        damping_box.label(text="Damping", icon='FORCE_DRAG')
        col = damping_box.column(align=True)
        col.prop(cloth_modifier.settings, "air_damping", text="Air Damping")
        col.prop(cloth_modifier.settings, "shear_damping", text="Shear Damping")

        pressure_box = main_box.box()
        pressure_box.label(text="Pressure", icon='MOD_EXPLODE')
        col = pressure_box.column(align=True)
        col.prop(cloth_modifier.settings, "use_pressure", text="Enable Pressure")
        if cloth_modifier.settings.use_pressure:
            col.separator()
            col.prop(cloth_modifier.settings, "uniform_pressure_force", text="Inside Air Pressure")
            col.prop(cloth_modifier.settings, "pressure_factor", text="Non Compressability")
            col.prop(cloth_modifier.settings, "fluid_density", text="Fluidity")

        pinning_box = main_box.box()
        pinning_box.label(text="Pinning", icon='PINNED')
        col = pinning_box.column(align=True)
        row = col.row(align=True)
        row.prop_search(cloth_modifier.settings, "vertex_group_mass", selected_object, "vertex_groups", text="Vertex Group")
        col.prop(cloth_modifier.settings, "pin_stiffness", text="Stiffness")
        col.prop(cloth_modifier.settings, "shrink_min", text="Shrinking")

        collision_box = main_box.box()
        collision_box.label(text="Collision", icon='MOD_PHYSICS')
        col = collision_box.column(align=True)
        col.prop(cloth_modifier.collision_settings, "collision_quality", text="Quality")

        split = col.split(factor=0.5, align=True)
        self_col = split.box().column(align=True)
        self_col.prop(cloth_modifier.collision_settings, "use_self_collision", text="Self Collision", toggle=True)
        if cloth_modifier.collision_settings.use_self_collision:
            self_col.separator()
            self_col.prop(cloth_modifier.collision_settings, "self_friction", text="Friction")
            self_col.prop(cloth_modifier.collision_settings, "self_distance_min", text="Distance", slider=True)
            self_col.prop(cloth_modifier.collision_settings, "self_impulse_clamp", text="Impulse Clamp")
            self_col.prop_search(cloth_modifier.collision_settings, "vertex_group_self_collisions",
                                 selected_object, "vertex_groups", text="Vertex Group")

        ext_col = split.box().column(align=True)
        ext_col.prop(cloth_modifier.collision_settings, "use_collision", text="External Collision", toggle=True)
        if cloth_modifier.collision_settings.use_collision:
            ext_col.separator()
            ext_col.prop(cloth_modifier.collision_settings, "distance_min", text="Distance", slider=True)
            ext_col.prop(cloth_modifier.collision_settings, "impulse_clamp", text="Impulse Clamp")
            ext_col.prop_search(cloth_modifier.collision_settings, "vertex_group_object_collisions",
                               selected_object, "vertex_groups", text="Vertex Group")
            ext_col.prop_search(cloth_modifier.collision_settings, "collection",
                               bpy.data, "collections", text="Collider Collection")

class ReadmePanel(bpy.types.Panel):
    bl_label = "###Readme and Changenotes###"
    bl_idname = "JIGGLE_MAKER_PT_readme"
    bl_order = 100
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "JM"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        head = layout.box()
        trow = head.row()
        trow.alignment = 'CENTER'
        trow.label(text="Jiggle Maker — Readme & Changenotes", icon='INFO')


        qa = head.row(align=True)
        qa.operator("wm.open_plugin_directory", text="Open Resources", icon='FILE_FOLDER')
        qa.operator("wm.refresh_library", text="Refresh Presets", icon='FILE_REFRESH')

        # Prerequisites
        box = layout.box()
        box.prop(scene, "jm_readme_prereq", text="Prerequisites", icon='INFO', toggle=True)
        if scene.jm_readme_prereq:
            prereq = box.column(align=True)
            prereq.alert = True
            prereq.scale_y = 1.1
            prereq.label(text="• Armature and Mesh MUST have a Scale of XYZ of 1.0, otherwise generated influence group will be wrong")
            prereq.label(text="• Model must be real-life size (1.6-2m) for settings to work")
            prereq.label(text="• Cannot have more than one Armature on your main mesh")
            prereq.label(text='• Set Armature to Rest mode before binding. Select Armature -> Properties/Data/Pose -> "Rest Position"')

        # Debug: main mesh not following jiggle
        box = layout.box()
        box.prop(scene, "jm_readme_debug_follow", text="If the main mesh is not following the Jiggle", icon='HELP', toggle=True)
        if scene.jm_readme_debug_follow:
            col = box.column()
            col.alert = True
            col.scale_y = 1.05
            col.label(text='1. Check the Surface deform modifier on main mesh, press "Bind".')
            col.label(text="   • If you get Concave error, double check your Jiggle Proxy for concave polygons")
            col.label(text="   • Mesh → Cleanup → Split Concave Faces can help")
            col.label(text='2. Check the "Mesh_Jiggle_Influence.L/ R" vertex group on main mesh')
            col.label(text="   • The area where the proxy is should be Painted red, manual weight painting is possible")
            col.label(text="   • Enable Mirroring in the top right before you start painting")
            col.label(text="3. Proxy Jiggle Mesh CANNOT have concave faces (google it). I also have a free post on patreon about it @lewdineer")
            col.label(text="4. Copy-pasting geometry from Main mesh not recommended due to concave faces")
            col.label(text="5. Jiggle Mesh Faces must be close to the main mesh Faces. Surfaces must be as close together as possible")
            col.label(text="6. Main mesh (and other meshes touching the Jiggle proxy) CANNOT have a collision modifier")
            col.label(text="7. Increase Bind Distance for the ""Preset Mesh Mode"" If influence group is too small")

        # Debug: proxy exploding
        box = layout.box()
        box.prop(scene, "jm_readme_debug_exploding", text="If the Jiggle Proxy is exploding", icon='ERROR', toggle=True)
        if scene.jm_readme_debug_exploding:
            col = box.column()
            col.alert = True
            col.scale_y = 1.05
            col.label(text="1. Disable ALL collision modifiers")
            col.label(text="2. Check your mesh size, must be realistic (1.6-2 meters)")
            col.label(text="3. Apply Scale for Main / Jiggle Mesh / armature / any parent of model")
            col.label(text="4. Increase the Quality Steps or Tension of the jiggle mesh")
            col.label(text="5. Decrease the Pressure and Fluid Density Scale of the jiggle mesh")

        # Debug: proxy falling
        box = layout.box()
        box.prop(scene, "jm_readme_debug_fall", text="If the Jiggle proxy is just falling down", icon='HELP', toggle=True)
        if scene.jm_readme_debug_fall:
            col = box.column()
            col.alert = True
            col.scale_y = 1.0
            col.label(text='1. Select your Jiggle proxy and select the "Pin" Vertex group in the properties Panel')
            col.label(text="   • Go into weight paint mode and check that the back side of the Jiggle mesh is painted Red")
            col.label(text="   • If it is not, you can manually paint it")
            col.label(text='2. Check that the "Pin" group is selected in the cloth settings under Shape->Pin Group')

        # Modifier stack
        box = layout.box()
        box.prop(scene, "jm_readme_stack", text="How should my modifier stack look (main mesh)?", icon='MODIFIER', toggle=True)
        if scene.jm_readme_stack:
            col = box.column()
            col.alert = True
            col.scale_y = 1.0
            col.label(text="Your modifier stack on the main mesh should have the following order, from top to bottom:")
            col.label(text="1. Armature Modifier")
            col.label(text="2. All the Surface deform modifiers for the Jiggle")
            col.label(text="3. Optional Corrective Smooth")
            col.label(text="4. Rest of modifiers")

        # Changenotes
        box = layout.box()
        box.prop(scene, "jm_readme_changes", text="Changenotes", icon='FILE_TEXT', toggle=True)
        if scene.jm_readme_changes:
            sec = box.column()

            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.2.2:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Moved the mirror option out of the advacned section")
            
            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.2.1:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Changed triangulate to false by default since it changes the jiggle physics")
            
            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.2.0:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Fixed bug from 2.1.0 where armature modifier was not added to jiggle mesh")
            
            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.1.0:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Fixed Blender 5.0 fcurves issue causing a error during binding")
            c.label(text="- Added option to triangulate jiggle mesh(helps with target contains concave polygons error)")
            c.label(text="- Added waring if the main mesh has a collsion modifier (this can break binding)")

            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.0.5:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Paint Mask and Vertex mask will now be disable in weight paint mode, those beeing enabled cased the generation of automatic weights to go wrong")
            
            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.0.4:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Added default option to clean vertex group in vertex mode")
            
            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.0.3:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Fixed bug from plugin not beeing instllable on blender 4.2")
            
            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.0.2:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Fixed mesh import failing if mesh with same name already exists")
            c.label(text="- Fixed cloth baking not working properly")

            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.0.1:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Binding process now uses data transfer instead of bind auto process")


            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v2.0:", icon='CHECKMARK')
            c = sub.column(align=True)
            c.label(text="- Premium modular structure finalized (utils/operators/ui/props/handlers)")
            c.label(text="- Collapsible Readme panel with quick actions")
            c.label(text='- "Advanced Settings" now consistent in Preset, Vertex, and Custom modes')
            c.label(text="- Cloth Bake Admin panel to bake/clear cloth caches on multiple objects")
            c.label(text="- Safer Surface Deform & cleanup routines; better mirroring/normals pass")
            c.label(text="- Fixed packaging issues and import edge cases (proper __init__.py in subpackages)")
            c.label(text="- Compatibility shim for legacy imports (jigglemaker_ui) inside package")
            c.label(text="- UI polish + consistent labels; version display made robust")

            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v1.6:", icon='HELP')
            c = sub.column(align=True)
            c.label(text="- Hotfix for preset meshes not loading upon restarting blender (added Refresh button)")

            sub = sec.box()
            r = sub.row(); r.alignment = 'LEFT'
            r.label(text="• v1.5:", icon='HELP')
            c = sub.column(align=True)
            c.label(text='- Current scene no longer must be named "Scene"')
            c.label(text='- Added "Important Notes" panel')
            c.label(text='- Eyedropper "Main" renamed to "Main Mesh"')
            c.label(text='- Eyedropper "Proxy" renamed to "Jiggle Mesh"')
            c.label(text="- Presets now loaded from resources/presets.blend; add your own via Preferences")
            c.label(text="- No console errors when no Mesh is selected")
